"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_new-pre-approval_new-pre-approval_module_ts"],{

/***/ 83299:
/*!*********************************************************************************!*\
  !*** ./src/app/pages/new-pre-approval/claim-details/claim-details.component.ts ***!
  \*********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ClaimDetailsComponent": () => (/* binding */ ClaimDetailsComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _claim_details_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./claim-details.component.html?ngResource */ 39705);
/* harmony import */ var _claim_details_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./claim-details.component.scss?ngResource */ 45223);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var src_app_model_control_control_model__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/model/control/control.model */ 45482);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/shared/data/enum/screen */ 68302);
/* harmony import */ var _healthcare_provider_healthcare_provider_page__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../healthcare-provider/healthcare-provider.page */ 35004);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _awesome_cordova_plugins_firebase_analytics_ngx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @awesome-cordova-plugins/firebase-analytics/ngx */ 48852);
/* harmony import */ var src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/shared/data/enum/event */ 38570);
/* harmony import */ var src_app_service_insurance_insurance_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/service/insurance/insurance.service */ 57072);
/* harmony import */ var src_app_service_new_claim_consent_consent_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/service/new-claim/consent/consent.service */ 41413);
/* harmony import */ var src_app_shared_components_nextgen_dialog_nextgen_dialog_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/shared/components/nextgen-dialog/nextgen-dialog.service */ 96485);
/* harmony import */ var src_app_service_new_re_approval_new_pre_approval_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/app/service/new-re-approval/new-pre-approval.service */ 80518);
/* harmony import */ var src_app_service_new_claim_service_type_service_types_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/app/service/new-claim/service-type/service-types.service */ 99466);
/* harmony import */ var src_app_service_new_claim_coverages_coverages_service__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! src/app/service/new-claim/coverages/coverages.service */ 86280);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! rxjs/operators */ 85921);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! rxjs */ 92218);
/* harmony import */ var _awesome_cordova_plugins_clevertap_ngx__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @awesome-cordova-plugins/clevertap/ngx */ 45363);
/* harmony import */ var src_app_shared_components_privacy_consent_dialog_privacy_consent_dialog_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! src/app/shared/components/privacy-consent-dialog/privacy-consent-dialog.component */ 61262);
/* harmony import */ var src_app_shared_components_popup_message_popup_message_component__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! src/app/shared/components/popup-message/popup-message.component */ 18290);
/* harmony import */ var src_app_service_new_claim_provider_agreement_provider_agreement_service__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! src/app/service/new-claim/provider-agreement/provider-agreement.service */ 40050);
/* harmony import */ var src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! src/app/shared/data/constants */ 74676);


























let ClaimDetailsComponent = class ClaimDetailsComponent {
    constructor(router, modalCtrl, firebaseAnalytics, insuranceService, consentService, dialogSevice, preApprovalService, serviceTypeService, coveragesService, datePipe, clevertap, form, providerAgreementService) {
        this.router = router;
        this.modalCtrl = modalCtrl;
        this.firebaseAnalytics = firebaseAnalytics;
        this.insuranceService = insuranceService;
        this.consentService = consentService;
        this.dialogSevice = dialogSevice;
        this.preApprovalService = preApprovalService;
        this.serviceTypeService = serviceTypeService;
        this.coveragesService = coveragesService;
        this.datePipe = datePipe;
        this.clevertap = clevertap;
        this.form = form;
        this.providerAgreementService = providerAgreementService;
        this.TYPE = src_app_model_control_control_model__WEBPACK_IMPORTED_MODULE_2__.ControlType;
        this.minDate = new Date().toISOString();
        this.unsubscribe$ = new rxjs__WEBPACK_IMPORTED_MODULE_18__.Subject();
        this.customValidation = [
            {
                key: 'required',
                message: 'validationSummary.pleaseSelectServiceDate'
            }
        ];
        this.onContinue = () => {
            this.preAppovalForm.markAllAsTouched();
            this.preAppovalForm.markAsDirty();
            if (this.preAppovalForm.valid) {
                this.firebaseAnalytics.logEvent(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_6__.GA4Event.PreApprovalClaimDetailsConfirmed, {
                    member_name: this.preAppovalForm.value.memberSelect.name,
                    provider_name: this.preAppovalForm.value.serviceType.name,
                    service_type: this.preAppovalForm.value.serviceType.name,
                    service_date: this.preAppovalForm.value.serviceDate
                });
                this.clevertap.recordEventWithNameAndProps(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_6__.GA4Event.PreApprovalClaimDetailsConfirmed, {
                    member_name: this.preAppovalForm.value.memberSelect.name,
                    provider_name: this.preAppovalForm.value.serviceType.name,
                    service_type: this.preAppovalForm.value.serviceType.name,
                    service_date: this.preAppovalForm.value.serviceDate
                });
                this.preApprovalService.preAppovalForm.controls.step.setValue(1);
                this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_3__.Screens.NewPreApprovalUploadDetails]);
            }
        };
    }
    get preAppovalForm() {
        return this.preApprovalService.preAppovalForm.controls.detailForm;
    }
    ngOnInit() {
        this.commands = [
            {
                actionName: 'button.continue',
                action: 'onContinue',
                class: 'primary',
            },
        ];
        this.preAppovalForm.controls.healthcareProviderName.disable({
            emitEvent: false,
            onlySelf: true,
        });
        this.preAppovalForm.controls.healthcareProviderName.updateValueAndValidity({
            emitEvent: false,
            onlySelf: true,
        });
    }
    formAction() {
        if (this.preAppovalForm.controls.memberSelect.value) {
            this.disabled = false;
        }
        else {
            this.disabled = true;
        }
        this.preAppovalForm.controls.memberSelect.valueChanges.subscribe(res => {
            if (res) {
                this.disabled = false;
            }
            else {
                this.disabled = true;
            }
        });
        this.preAppovalForm.valueChanges.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_19__.takeUntil)(this.unsubscribe$)).subscribe((res) => {
            if (res.serviceType) {
                if (!res.memberSelect || !res.serviceDate) {
                    this.preAppovalForm.controls.memberSelect.markAsDirty({ onlySelf: true });
                    this.preAppovalForm.controls.serviceDate.markAsDirty({ onlySelf: true });
                    this.preAppovalForm.controls.serviceType.setValue(null, {
                        emitEvent: false,
                        onlySelf: true,
                    });
                    this.preAppovalForm.controls.healthcareProviderName.setValue(null, {
                        emitEvent: false,
                        onlySelf: true,
                    });
                    this.preAppovalForm.controls.healthcareProviderName.disable({
                        emitEvent: false,
                        onlySelf: true,
                    });
                    this.preAppovalForm.controls.healthcareProviderName.updateValueAndValidity({
                        emitEvent: false,
                        onlySelf: true,
                    });
                }
                else {
                    this.preAppovalForm.controls.healthcareProviderName.enable({
                        emitEvent: false,
                        onlySelf: true,
                    });
                    this.preAppovalForm.controls.healthcareProviderName.updateValueAndValidity({
                        emitEvent: false,
                        onlySelf: true,
                    });
                }
            }
            else {
                this.preAppovalForm.controls.healthcareProviderName.disable({
                    emitEvent: false,
                    onlySelf: true,
                });
                this.preAppovalForm.controls.healthcareProviderName.updateValueAndValidity({
                    emitEvent: false,
                    onlySelf: true,
                });
            }
        });
        this.preAppovalForm.controls.serviceDate.valueChanges.subscribe(res => {
            this.checkCoveredServiceDate(res);
        });
        this.preAppovalForm.controls.healthcareProviderName.valueChanges.subscribe(_ => {
            this.checkProviderAgreement();
        });
    }
    ;
    ionViewWillEnter() {
        this.unsubscribe$ = new rxjs__WEBPACK_IMPORTED_MODULE_18__.Subject();
        this.getInformation();
    }
    ionViewWillLeave() {
        this.unsubscribe$.next();
        this.unsubscribe$.complete();
    }
    getInformation() {
        this.insuranceService.getPolicyInformation().pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_19__.takeUntil)(this.unsubscribe$)).subscribe((res) => {
            if (!res)
                return;
            this.currentPolicy = res;
            this.consentCheck();
            this.getMemberSelect();
            this.getAllServices();
            this.getInformationPolicyDetails(res);
            this.formAction();
        });
    }
    consentCheck() {
        const requestConsent = {
            userPolicyId: this.currentPolicy.userPolicyId,
            beneficiaryId: this.currentPolicy.beneficiaryId,
        };
        this.consentService.getConsent(requestConsent).subscribe((data) => {
            if (!data) {
                this.getPrivacyConsent(requestConsent);
            }
        });
    }
    getPrivacyConsent(requestConsent) {
        this.consentService.getPrivacyConsent().subscribe((data) => {
            this.dialogSevice
                .open(src_app_shared_components_privacy_consent_dialog_privacy_consent_dialog_component__WEBPACK_IMPORTED_MODULE_14__.PrivacyConsentDialogComponent, {
                data: {
                    text: data[0].description,
                    requestConsent: requestConsent,
                },
                title: data[0].title,
                position: 'middle',
                width: '90%',
                height: '80%',
            })
                .afterClosed()
                .subscribe((data) => {
                if (data) {
                    this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_3__.Screens.NewPreApprovalClaimDetail]);
                }
                else {
                    this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_3__.Screens.ClaimHistory,
                    ]);
                }
            });
        });
    }
    getMemberSelect() {
        this.members = this.insuranceService.getMemberListValue().filter((_) => _.isActive === 1).map((item) => ({
            name: item.benefFullName,
            id: item.beneficiaryId.toString(),
        }));
        if (this.currentPolicy.dependent) {
            const member = this.members.find(e => e.name === 'MySelf');
            this.preAppovalForm.controls.memberSelect.setValue(member);
        }
    }
    getAllServices() {
        this.serviceTypes = [];
        const requestServiceTypes = {
            userPolicyId: this.currentPolicy.userPolicyId,
        };
        this.serviceTypeService.getServiceTypes(requestServiceTypes).subscribe((data) => {
            if (!data)
                return;
            this.serviceTypes = data.map((item) => {
                if ((item.id != 2 ||
                    (item.id == 2 && (item.classId == 3 || item.classId == 5))) &&
                    item.classId != 8) {
                    return {
                        name: item.description,
                        id: item.classId.toString(),
                        valueId: item.id,
                    };
                }
            }).filter(e => e).sort(function (a, b) {
                const nameA = a.name.toUpperCase(); // ignore upper and lowercase
                const nameB = b.name.toUpperCase(); // ignore upper and lowercase
                if (nameA < nameB) {
                    return -1;
                }
                if (nameA > nameB) {
                    return 1;
                }
                return 0;
            });
            ;
            // const isCheckColumnName = this.insuranceService.getPayerSettingValue()
            //   .some(
            //     (value) =>
            //       value.columnname === 'MyNCenableservicetypesforpreapp' && value.required == true
            //   );
            const isCheckColumnName = this.insuranceService.checkPayerSetting(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_17__.Constants.ENABLE_SERVICE_TYPES_FOR_PRE_APP, true);
            if (isCheckColumnName == false) {
                this.serviceTypes = this.serviceTypes.filter((_) => _.id == 1);
            }
        });
    }
    providerHandler() {
        var _a;
        return (0,tslib__WEBPACK_IMPORTED_MODULE_20__.__awaiter)(this, void 0, void 0, function* () {
            if (this.preAppovalForm.controls.healthcareProviderName.disabled)
                return;
            const valueForm = this.preAppovalForm.getRawValue();
            const ref = yield this.modalCtrl.create({
                component: _healthcare_provider_healthcare_provider_page__WEBPACK_IMPORTED_MODULE_4__.HealthcareProviderPage,
                componentProps: {
                    dataSource: {
                        fobId: (_a = valueForm === null || valueForm === void 0 ? void 0 : valueForm.serviceType) === null || _a === void 0 ? void 0 : _a.valueId,
                    }
                }
            });
            ref.present();
            const { data } = yield ref.onWillDismiss();
            if (data != null || data != undefined) {
                this.preAppovalForm.patchValue({
                    healthcareProvider: data,
                    healthcareProviderName: data.entityName
                });
            }
        });
    }
    checkCoveredServiceDate(date) {
        date = this.datePipe.transform(date, 'yyyy-M-d');
        if (date) {
            const model = {
                mdAsAtDate: date,
                beneficiaryId: this.currentPolicy.beneficiaryId,
                userPolicyId: this.currentPolicy.userPolicyId
            };
            this.coveragesService.getCoverages(model).subscribe(res => {
                if (res && !res[0].details.isCovered) {
                    this.preAppovalForm.controls.serviceDate.setValue(null, {
                        emitEvent: false
                    });
                    this.dialogSevice.open(src_app_shared_components_popup_message_popup_message_component__WEBPACK_IMPORTED_MODULE_15__.PopupMessageComponent, {
                        data: {
                            content: "Your service date doesn't exits or something went wrong from sever. Please try again or contact administrator to support!",
                            textYes: 'button.ok',
                        },
                        title: 'Coverages Service Date Incorrect',
                        position: 'middle',
                        width: '90%',
                    });
                }
            });
        }
    }
    getInformationPolicyDetails(policy) {
        if (policy) {
            const data = this.insuranceService.getPolicyDetailResponse();
            this.currentPolicyDetail = {
                contractId: policy.policiesDetails[0].contractId,
                mcontractId: policy.policiesDetails[0].mcontractId,
                payerId: policy.policiesDetails[0].payerId,
                payerName: data[0].Payer.entity.name,
                productId: data[0].Beneficiary.product.productId,
                policyStartDay: data[0].Mcontract.STARTDATE,
                policyEndDay: data[0].Mcontract.EXPDATE,
                policyNumber: data[0].Contract.EXTERNALREF,
                policyHolder: data[0].Contract.NAME,
                serviceProvId: data[0].ServiceProviderId,
                endorsementId: data[0].Endorsement.ENDORSEMENTID,
                moralEntity: data[0].Mcontract.MORALENTITY,
                isActive: data[0].Beneficiary.IsActive,
                beneficiaryId: data[0].Beneficiary.BeneficiaryID,
                firstName: data[0].Beneficiary.firstname,
            };
        }
        ;
    }
    checkProviderAgreement() {
        var _a, _b, _c;
        const valueForm = this.preAppovalForm.getRawValue();
        const ProviderAgreement = {
            userPolicyId: this.currentPolicy.userPolicyId,
            beneficiaryId: this.currentPolicy.beneficiaryId,
            productId: (_a = this.currentPolicyDetail) === null || _a === void 0 ? void 0 : _a.productId,
            endorsementId: (_b = this.currentPolicyDetail) === null || _b === void 0 ? void 0 : _b.endorsementId,
            fobId: (_c = valueForm === null || valueForm === void 0 ? void 0 : valueForm.serviceType) === null || _c === void 0 ? void 0 : _c.valueId,
            providerCountryId: valueForm === null || valueForm === void 0 ? void 0 : valueForm.healthcareProvider.addressCountryId,
        };
        this.providerAgreementService.getServiceTypes(ProviderAgreement).subscribe((res) => {
            if (!res || res.agreementId == 0) {
                this.preAppovalForm.controls.serviceType.setValue(null, {
                    emitEvent: false
                });
                this.preAppovalForm.controls.serviceDate.setValue('', {
                    emitEvent: false
                });
                this.preAppovalForm.controls.healthcareProviderName.setValue(null, {
                    emitEvent: false
                });
                this.preAppovalForm.controls.healthcareProviderName.disable({
                    emitEvent: false,
                    onlySelf: true,
                });
                this.preAppovalForm.controls.healthcareProviderName.updateValueAndValidity({
                    emitEvent: false,
                    onlySelf: true,
                });
                this.dialogSevice.open(src_app_shared_components_popup_message_popup_message_component__WEBPACK_IMPORTED_MODULE_15__.PopupMessageComponent, {
                    data: {
                        content: 'This service type is not covered by your insurance policy',
                        textYes: 'button.ok',
                    },
                    title: 'Coverages Service Type Incorrect',
                    position: 'middle',
                    width: '90%',
                });
            }
        }, _ => {
            console.log(_);
            this.preAppovalForm.controls.serviceType.setValue(null, {
                emitEvent: false
            });
            this.preAppovalForm.controls.serviceDate.setValue('', {
                emitEvent: false
            });
            this.preAppovalForm.controls.healthcareProviderName.setValue(null, {
                emitEvent: false
            });
            this.preAppovalForm.controls.healthcareProviderName.disable({
                emitEvent: false,
                onlySelf: true,
            });
            this.preAppovalForm.controls.healthcareProviderName.updateValueAndValidity({
                emitEvent: false,
                onlySelf: true,
            });
        });
    }
};
ClaimDetailsComponent.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_21__.Router },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_22__.ModalController },
    { type: _awesome_cordova_plugins_firebase_analytics_ngx__WEBPACK_IMPORTED_MODULE_5__.FirebaseAnalytics },
    { type: src_app_service_insurance_insurance_service__WEBPACK_IMPORTED_MODULE_7__.InsuranceService },
    { type: src_app_service_new_claim_consent_consent_service__WEBPACK_IMPORTED_MODULE_8__.ConsentService },
    { type: src_app_shared_components_nextgen_dialog_nextgen_dialog_service__WEBPACK_IMPORTED_MODULE_9__.DialogService },
    { type: src_app_service_new_re_approval_new_pre_approval_service__WEBPACK_IMPORTED_MODULE_10__.NewPreApprovalService },
    { type: src_app_service_new_claim_service_type_service_types_service__WEBPACK_IMPORTED_MODULE_11__.ServiceTypesService },
    { type: src_app_service_new_claim_coverages_coverages_service__WEBPACK_IMPORTED_MODULE_12__.CoveragesService },
    { type: _angular_common__WEBPACK_IMPORTED_MODULE_23__.DatePipe },
    { type: _awesome_cordova_plugins_clevertap_ngx__WEBPACK_IMPORTED_MODULE_13__.CleverTap },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_24__.FormBuilder },
    { type: src_app_service_new_claim_provider_agreement_provider_agreement_service__WEBPACK_IMPORTED_MODULE_16__.ProviderAgreementService }
];
ClaimDetailsComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_20__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_25__.Component)({
        selector: 'app-claim-details',
        template: _claim_details_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_claim_details_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], ClaimDetailsComponent);



/***/ }),

/***/ 43461:
/*!*******************************************************************!*\
  !*** ./src/app/pages/new-pre-approval/new-pre-approval.module.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NewPreApprovalPageModule": () => (/* binding */ NewPreApprovalPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/shared/shared.module */ 44466);
/* harmony import */ var _new_pre_approval_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./new-pre-approval.routing.module */ 67737);
/* harmony import */ var src_app_service_new_claim_service_type_service_type_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/service/new-claim/service-type/service-type.service */ 97140);
/* harmony import */ var src_app_service_new_claim_select_member_member_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/service/new-claim/select-member/member.service */ 78447);
/* harmony import */ var _new_pre_approval_page__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./new-pre-approval.page */ 86439);
/* harmony import */ var _claim_details_claim_details_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./claim-details/claim-details.component */ 83299);
/* harmony import */ var _upload_detail_upload_detail_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./upload-detail/upload-detail.component */ 17190);
/* harmony import */ var _review_and_submit_review_and_submit_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./review-and-submit/review-and-submit.component */ 75651);













let NewPreApprovalPageModule = class NewPreApprovalPageModule {
};
NewPreApprovalPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_9__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_10__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_11__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_12__.IonicModule,
            src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_0__.SharedModule,
            _new_pre_approval_routing_module__WEBPACK_IMPORTED_MODULE_1__.NewPreApprovalRoutingModule,
        ],
        declarations: [
            _new_pre_approval_page__WEBPACK_IMPORTED_MODULE_4__.NewPreApprovalPage,
            _claim_details_claim_details_component__WEBPACK_IMPORTED_MODULE_5__.ClaimDetailsComponent,
            _upload_detail_upload_detail_component__WEBPACK_IMPORTED_MODULE_6__.UploadDetailComponent,
            _review_and_submit_review_and_submit_component__WEBPACK_IMPORTED_MODULE_7__.ReviewAndSubmitComponent,
        ],
        providers: [src_app_service_new_claim_select_member_member_service__WEBPACK_IMPORTED_MODULE_3__.MemberService, src_app_service_new_claim_service_type_service_type_service__WEBPACK_IMPORTED_MODULE_2__.ServiceTypeService]
    })
], NewPreApprovalPageModule);



/***/ }),

/***/ 86439:
/*!*****************************************************************!*\
  !*** ./src/app/pages/new-pre-approval/new-pre-approval.page.ts ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NewPreApprovalPage": () => (/* binding */ NewPreApprovalPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _new_pre_approval_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./new-pre-approval.page.html?ngResource */ 39638);
/* harmony import */ var _new_pre_approval_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./new-pre-approval.page.scss?ngResource */ 73435);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/shared/data/enum/screen */ 68302);
/* harmony import */ var src_app_shared_components_nextgen_dialog_nextgen_dialog_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/shared/components/nextgen-dialog/nextgen-dialog.service */ 96485);
/* harmony import */ var _shared_components_save_draft_save_draft_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../shared/components/save-draft/save-draft.component */ 38317);
/* harmony import */ var src_app_service_new_re_approval_new_pre_approval_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/service/new-re-approval/new-pre-approval.service */ 80518);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var src_app_service_insurance_insurance_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/service/insurance/insurance.service */ 57072);
/* harmony import */ var src_app_service_new_claim_upload_document_upload_document_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/service/new-claim/upload-document/upload-document.service */ 66848);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ionic/angular */ 93819);













let NewPreApprovalPage = class NewPreApprovalPage {
    constructor(router, dialogService, preApprovalService, insuranceService, fb, uploadDocumentService, platform) {
        this.router = router;
        this.dialogService = dialogService;
        this.preApprovalService = preApprovalService;
        this.insuranceService = insuranceService;
        this.fb = fb;
        this.uploadDocumentService = uploadDocumentService;
        this.platform = platform;
        this.step = 1;
        this.width = 25;
        this.currentStep = 0;
        this.currentStatus = 'inProgress';
        this.stepProgress = [
            {
                id: 1,
                direction: src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__.Screens.NewPreApprovalClaimDetail,
                step: 0,
            },
            {
                id: 2,
                direction: src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__.Screens.NewPreApprovalUploadDetails,
                step: 1,
            },
            {
                id: 3,
                direction: '',
                step: 2,
            },
        ];
        this.onBack = () => {
            const value = this.preApprovalService.preAppovalForm.controls.detailForm.value;
            const canSaveDraft = Object.keys(value).some(key => {
                if (value[key]) {
                    return true;
                }
            });
            if (canSaveDraft) {
                this.dialogService.open(_shared_components_save_draft_save_draft_component__WEBPACK_IMPORTED_MODULE_4__.SaveDraftComponent, {
                    position: 'middle',
                    width: '90%',
                    title: 'saveDocument.title',
                    data: {
                        disable: false
                    }
                })
                    .afterClosed()
                    .subscribe((isSave) => {
                    if (isSave === undefined)
                        return;
                    if (isSave) {
                        this.preApprovalService.setLocalStorageSubmitPre();
                        this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__.Screens.Home]).then(() => {
                            this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__.Screens.ClaimHistory]);
                        });
                    }
                    else {
                        this.preApprovalService.clearPreapprovals();
                        this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__.Screens.ClaimHistory]);
                    }
                });
            }
            else {
                this.dialogService.open(_shared_components_save_draft_save_draft_component__WEBPACK_IMPORTED_MODULE_4__.SaveDraftComponent, {
                    position: 'middle',
                    width: '90%',
                    title: 'saveDocument.title',
                    data: {
                        disable: true
                    }
                })
                    .afterClosed()
                    .subscribe((isSave) => {
                    if (isSave === undefined)
                        return;
                    if (!isSave) {
                        this.preApprovalService.clearPreapprovals();
                        this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__.Screens.ClaimHistory]);
                    }
                });
            }
        };
    }
    get documentForm() {
        return this.preApprovalService.preAppovalForm.controls.documentForm;
    }
    ngOnInit() {
        if (this.stepProgress[0].id === this.currentStep + 1) {
            this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__.Screens.NewPreApprovalClaimDetail]);
        }
        this.command = {
            actionName: 'button.back',
            action: 'onBack',
            class: '',
        };
        this.checkStep();
    }
    ionViewDidEnter() {
        this.subscription = this.platform.backButton.subscribeWithPriority(9999, () => {
            this.onBack();
        });
    }
    ionViewWillLeave() {
        this.subscription.unsubscribe();
    }
    checkStep() {
        var _a, _b;
        return (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__awaiter)(this, void 0, void 0, function* () {
            const submitPre = yield this.preApprovalService.getLocalStorageSubmitPre();
            if (submitPre) {
                this.preApprovalService.preAppovalForm.patchValue(submitPre, { emitEvent: false });
                if (((_a = submitPre === null || submitPre === void 0 ? void 0 : submitPre.detailForm) === null || _a === void 0 ? void 0 : _a.serviceType) && (submitPre === null || submitPre === void 0 ? void 0 : submitPre.step) > 1) {
                    this.getClaimDocumentTypes((_b = submitPre === null || submitPre === void 0 ? void 0 : submitPre.detailForm) === null || _b === void 0 ? void 0 : _b.serviceType.id);
                }
                else {
                    if ((submitPre === null || submitPre === void 0 ? void 0 : submitPre.step) != null) {
                        switch (submitPre.step) {
                            case 1:
                                this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__.Screens.NewPreApprovalUploadDetails]);
                                break;
                            case 2:
                                this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__.Screens.NewPreApprovalReviewAndSubmit]);
                                break;
                        }
                    }
                }
            }
        });
    }
    getClaimDocumentTypes(serviceType) {
        const request = {
            userPolicyId: this.insuranceService.policyValue.userPolicyId,
            serviceType,
        };
        this.uploadDocumentService
            .getClaimDocumentType(request)
            .subscribe((data) => (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__awaiter)(this, void 0, void 0, function* () {
            this.documentForm.clear();
            const submitPre = yield this.preApprovalService.getLocalStorageSubmitPre();
            data.forEach((item) => {
                var _a;
                const docs = (_a = submitPre === null || submitPre === void 0 ? void 0 : submitPre.documentForm) === null || _a === void 0 ? void 0 : _a.find(e => e.id === item.id);
                this.documentForm.push(this.fb.group({
                    title: item.description,
                    expanded: docs ? docs.expanded : false,
                    document: this.fb.control(docs ? docs.document : []),
                    mandatory: item.code != 'ItemizedInvoice' ? false : true,
                    code: item.code,
                    id: item.id,
                    description: item.instruction,
                }));
            });
            if ((submitPre === null || submitPre === void 0 ? void 0 : submitPre.step) != null) {
                switch (submitPre.step) {
                    case 1:
                        this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__.Screens.NewPreApprovalUploadDetails]);
                        break;
                    case 2:
                        this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__.Screens.NewPreApprovalReviewAndSubmit]);
                        break;
                }
            }
        }));
    }
};
NewPreApprovalPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_9__.Router },
    { type: src_app_shared_components_nextgen_dialog_nextgen_dialog_service__WEBPACK_IMPORTED_MODULE_3__.DialogService },
    { type: src_app_service_new_re_approval_new_pre_approval_service__WEBPACK_IMPORTED_MODULE_5__.NewPreApprovalService },
    { type: src_app_service_insurance_insurance_service__WEBPACK_IMPORTED_MODULE_6__.InsuranceService },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_10__.FormBuilder },
    { type: src_app_service_new_claim_upload_document_upload_document_service__WEBPACK_IMPORTED_MODULE_7__.UploadDocumentService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_11__.Platform }
];
NewPreApprovalPage = (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_12__.Component)({
        selector: 'app-new-pre-approval',
        template: _new_pre_approval_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_new_pre_approval_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], NewPreApprovalPage);



/***/ }),

/***/ 67737:
/*!***************************************************************************!*\
  !*** ./src/app/pages/new-pre-approval/new-pre-approval.routing.module.ts ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NewPreApprovalRoutingModule": () => (/* binding */ NewPreApprovalRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _new_pre_approval_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./new-pre-approval.page */ 86439);
/* harmony import */ var _claim_details_claim_details_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./claim-details/claim-details.component */ 83299);
/* harmony import */ var _upload_detail_upload_detail_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./upload-detail/upload-detail.component */ 17190);
/* harmony import */ var _review_and_submit_review_and_submit_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./review-and-submit/review-and-submit.component */ 75651);







const routes = [
    {
        path: '',
        component: _new_pre_approval_page__WEBPACK_IMPORTED_MODULE_0__.NewPreApprovalPage,
        children: [
            {
                path: 'claim-details',
                component: _claim_details_claim_details_component__WEBPACK_IMPORTED_MODULE_1__.ClaimDetailsComponent,
            },
            {
                path: 'upload-details',
                component: _upload_detail_upload_detail_component__WEBPACK_IMPORTED_MODULE_2__.UploadDetailComponent,
            },
            {
                path: 'review-submit',
                component: _review_and_submit_review_and_submit_component__WEBPACK_IMPORTED_MODULE_3__.ReviewAndSubmitComponent,
            },
            // {
            //   path: '**',
            //   redirectTo: 'claim-details',
            //   pathMatch: 'full',
            // },
        ],
    },
];
let NewPreApprovalRoutingModule = class NewPreApprovalRoutingModule {
};
NewPreApprovalRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_6__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_6__.RouterModule],
    })
], NewPreApprovalRoutingModule);



/***/ }),

/***/ 75651:
/*!*****************************************************************************************!*\
  !*** ./src/app/pages/new-pre-approval/review-and-submit/review-and-submit.component.ts ***!
  \*****************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ReviewAndSubmitComponent": () => (/* binding */ ReviewAndSubmitComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _review_and_submit_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./review-and-submit.component.html?ngResource */ 71742);
/* harmony import */ var _review_and_submit_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./review-and-submit.component.scss?ngResource */ 94173);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _awesome_cordova_plugins_firebase_analytics_ngx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @awesome-cordova-plugins/firebase-analytics/ngx */ 48852);
/* harmony import */ var src_app_service_insurance_insurance_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/service/insurance/insurance.service */ 57072);
/* harmony import */ var src_app_service_new_re_approval_new_pre_approval_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/service/new-re-approval/new-pre-approval.service */ 80518);
/* harmony import */ var src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/shared/data/enum/event */ 38570);
/* harmony import */ var src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/shared/data/enum/screen */ 68302);
/* harmony import */ var src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/shared/data/constants */ 74676);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! rxjs/operators */ 85921);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! rxjs */ 92218);
/* harmony import */ var _awesome_cordova_plugins_clevertap_ngx__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @awesome-cordova-plugins/clevertap/ngx */ 45363);
/* harmony import */ var src_app_shared_components_nextgen_dialog_nextgen_dialog_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/shared/components/nextgen-dialog/nextgen-dialog.service */ 96485);
/* harmony import */ var src_app_shared_components_popup_message_popup_message_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/app/shared/components/popup-message/popup-message.component */ 18290);
/* harmony import */ var _service_language_language_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../../service/language/language.service */ 11281);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @angular/common */ 36362);



















let ReviewAndSubmitComponent = class ReviewAndSubmitComponent {
    constructor(router, firebaseAnalytics, insuranceService, newPreApprovalService, clevertap, dialogService, languageService, platform, location) {
        this.router = router;
        this.firebaseAnalytics = firebaseAnalytics;
        this.insuranceService = insuranceService;
        this.newPreApprovalService = newPreApprovalService;
        this.clevertap = clevertap;
        this.dialogService = dialogService;
        this.languageService = languageService;
        this.platform = platform;
        this.location = location;
        this.documents = [];
        this.commands = [
            {
                actionName: 'button.back',
                action: 'onBack',
                class: 'transparent',
                icon: 'uil uil-arrow-left body-l bold',
                position: 'left',
            },
            {
                actionName: 'button.submit',
                action: 'onSubmit',
                class: 'primary',
            }
        ];
        this.lang = 'en';
        this.unsubscribe$ = new rxjs__WEBPACK_IMPORTED_MODULE_12__.Subject();
        this.onBack = () => {
            // this.router.navigate(['/' + Screens.NewPreApprovalUploadDetails]);
            this.checkNavigateBack();
        };
        this.onSubmit = () => {
            let loading = false;
            // this.firebaseAnalytics.logEvent(GA4Event.PreApprovalClaimReviewsubmitted, {});
            // this.clevertap.recordEventWithName(GA4Event.PreApprovalClaimReviewsubmitted);
            this.clevertap.recordEventWithName(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_5__.GA4Event.PreApprovalClaimSubmitted);
            this.firebaseAnalytics.logEvent(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_5__.GA4Event.PreApprovalClaimSubmitted, {});
            // this.firebaseAnalytics.logEvent(GA4Event.PreApprovalClaimSubmittedMissing, {});
            const submitRequest = {
                userPolicyId: this.currentPolicy.userPolicyId,
                beneficiaryId: this.claimPreInfo.memberSelect.id,
                requestSource: src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_7__.Constants.REQUEST_SOURCE
            };
            if (!loading) {
                this.newPreApprovalService.submitpreapproval(submitRequest)
                    .subscribe((res) => {
                    loading = true;
                    if (res.status == 0) {
                        this.dialogService
                            .open(src_app_shared_components_popup_message_popup_message_component__WEBPACK_IMPORTED_MODULE_10__.PopupMessageComponent, {
                            data: {
                                content: res.message,
                                textYes: 'button.ok',
                            },
                            title: 'submittedSuccessfully.wrongMessage',
                            position: 'middle',
                            width: '90%',
                        });
                    }
                    else {
                        this.newPreApprovalService.clearPreapprovals();
                        this.checkNavigate(res);
                    }
                }, (error) => {
                    console.log(error);
                });
                // TODO
            }
        };
    }
    get preApprovalValue() {
        return this.newPreApprovalService.preAppovalForm.value;
    }
    ngOnInit() {
        this.claimPreInfo = {
            healthcareProvider: this.preApprovalValue.detailForm.healthcareProviderName,
            memberSelect: this.preApprovalValue.detailForm.memberSelect,
            serviceType: this.preApprovalValue.detailForm.serviceType,
            serviceDate: this.preApprovalValue.detailForm.serviceDate
        };
        this.claimDocuments = this.preApprovalValue.documentForm;
    }
    ionViewWillEnter() {
        this.unsubscribe$ = new rxjs__WEBPACK_IMPORTED_MODULE_12__.Subject();
        this.insuranceService.getPolicyInformation().pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_13__.takeUntil)(this.unsubscribe$)).subscribe((res) => {
            if (!res)
                return;
            this.currentPolicy = res;
        });
        this.getLanguage();
    }
    ionViewDidEnter() {
        this.subscription = this.platform.backButton.subscribeWithPriority(9999, () => {
            this.location.back();
        });
    }
    ionViewWillLeave() {
        this.unsubscribe$.next();
        this.unsubscribe$.complete();
        this.subscription.unsubscribe();
    }
    getLanguage() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_14__.__awaiter)(this, void 0, void 0, function* () {
            this.lang = this.languageService.getISOLanguageCode();
        });
    }
    onNavigateToClaimDetails() {
        this.newPreApprovalService.preAppovalForm.controls.step.setValue(0);
        this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_6__.Screens.NewPreApprovalClaimDetail]);
    }
    onNavigateToDocument() {
        this.newPreApprovalService.preAppovalForm.controls.step.setValue(1);
        this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_6__.Screens.NewPreApprovalUploadDetails]);
    }
    checkNavigate(value) {
        if (
        // this.insuranceService
        //   .getPayerSettingValue()
        //   .some(
        //     (_) =>
        //       _.columnname == 'EnableMobileAppRateMyVisit' && _.required == true,
        //   )
        this.insuranceService.checkPayerSetting(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_7__.Constants.ENABLE_MOBILE_APP_RATE_VISIT, true)) {
            this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_6__.Screens.SubmittedSuccessfully], { queryParams: { asoapNbr: value.asoapNbr, asoapPlanId: value.asoapPlanId, externalReference: value.externalReference } });
        }
        else {
            this.router.navigate(['/home/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_6__.Screens.Home]);
        }
    }
    checkNavigateBack() {
        this.newPreApprovalService.preAppovalForm.controls.step.setValue(1);
        this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_6__.Screens.NewPreApprovalUploadDetails]);
    }
};
ReviewAndSubmitComponent.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_15__.Router },
    { type: _awesome_cordova_plugins_firebase_analytics_ngx__WEBPACK_IMPORTED_MODULE_2__.FirebaseAnalytics },
    { type: src_app_service_insurance_insurance_service__WEBPACK_IMPORTED_MODULE_3__.InsuranceService },
    { type: src_app_service_new_re_approval_new_pre_approval_service__WEBPACK_IMPORTED_MODULE_4__.NewPreApprovalService },
    { type: _awesome_cordova_plugins_clevertap_ngx__WEBPACK_IMPORTED_MODULE_8__.CleverTap },
    { type: src_app_shared_components_nextgen_dialog_nextgen_dialog_service__WEBPACK_IMPORTED_MODULE_9__.DialogService },
    { type: _service_language_language_service__WEBPACK_IMPORTED_MODULE_11__.LanguageService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_16__.Platform },
    { type: _angular_common__WEBPACK_IMPORTED_MODULE_17__.Location }
];
ReviewAndSubmitComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_14__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_18__.Component)({
        selector: 'app-review-and-submit',
        template: _review_and_submit_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_review_and_submit_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], ReviewAndSubmitComponent);



/***/ }),

/***/ 17190:
/*!*********************************************************************************!*\
  !*** ./src/app/pages/new-pre-approval/upload-detail/upload-detail.component.ts ***!
  \*********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UploadDetailComponent": () => (/* binding */ UploadDetailComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _upload_detail_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./upload-detail.component.html?ngResource */ 60147);
/* harmony import */ var _upload_detail_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./upload-detail.component.scss?ngResource */ 83446);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _awesome_cordova_plugins_firebase_analytics_ngx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @awesome-cordova-plugins/firebase-analytics/ngx */ 48852);
/* harmony import */ var _awesome_cordova_plugins_clevertap_ngx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @awesome-cordova-plugins/clevertap/ngx */ 45363);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! rxjs */ 92218);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! rxjs/operators */ 85921);
/* harmony import */ var src_app_service_insurance_insurance_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/service/insurance/insurance.service */ 57072);
/* harmony import */ var src_app_service_new_re_approval_new_pre_approval_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/service/new-re-approval/new-pre-approval.service */ 80518);
/* harmony import */ var src_app_service_pre_approval_pre_approval_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/service/pre-approval/pre-approval.service */ 81308);
/* harmony import */ var src_app_shared_components_nextgen_dialog_nextgen_dialog_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/shared/components/nextgen-dialog/nextgen-dialog.service */ 96485);
/* harmony import */ var src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/shared/data/enum/event */ 38570);
/* harmony import */ var src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/shared/data/enum/screen */ 68302);
/* harmony import */ var src_app_service_new_claim_upload_document_upload_document_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/app/service/new-claim/upload-document/upload-document.service */ 66848);
/* harmony import */ var _new_claim_upload_detail_upload_documents_upload_documents_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../new-claim/upload-detail/upload-documents/upload-documents.component */ 89883);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @angular/common */ 36362);




















let UploadDetailComponent = class UploadDetailComponent {
    constructor(dialogSevice, router, firebaseAnalytics, preApprovalService, insuranceService, newPreApprovalService, fb, cdr, clevertap, uploadDocumentService, platform, location) {
        this.dialogSevice = dialogSevice;
        this.router = router;
        this.firebaseAnalytics = firebaseAnalytics;
        this.preApprovalService = preApprovalService;
        this.insuranceService = insuranceService;
        this.newPreApprovalService = newPreApprovalService;
        this.fb = fb;
        this.cdr = cdr;
        this.clevertap = clevertap;
        this.uploadDocumentService = uploadDocumentService;
        this.platform = platform;
        this.location = location;
        this.isShowMandatory = false;
        this.commands = [
            {
                actionName: 'button.back',
                action: 'onBack',
                class: 'transparent',
                icon: 'uil uil-arrow-left body-l bold',
                position: 'left',
            },
            {
                actionName: 'button.next',
                action: 'nextStep',
                class: 'primary',
                icon: 'uil uil-arrow-right body-l bold',
                position: 'right',
            }
        ];
        this.unsubscribe$ = new rxjs__WEBPACK_IMPORTED_MODULE_12__.Subject();
        this.onBack = () => {
            this.newPreApprovalService.preAppovalForm.controls.step.setValue(0);
            this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_9__.Screens.NewPreApprovalClaimDetail]);
        };
        this.nextStep = () => {
            // if (
            //   this.documentForm.value
            //     .some((_) => _.code == 'ItemizedInvoice' && (!_.document || _.document?.length === 0))
            //     .valueOf()
            // ) {
            if (this.documentForm.value[0].document.length === 0) {
                this.isShowMandatory = true;
            }
            else {
                // this.firebaseAnalytics.logEvent(GA4Event.ReimbursmentClaimDocumentAdded,{document_type: document.title,},);
                // this.clevertap.recordEventWithName(GA4Event.ReimbursmentClaimDocumentAdded,);
                this.clevertap.recordEventWithNameAndProps(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_8__.GA4Event.PreApprovalClaimDocumentAdded, { document_type: document.title, });
                this.firebaseAnalytics.logEvent(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_8__.GA4Event.PreApprovalClaimDocumentAdded, { document_type: document.title, });
                // this.firebaseAnalytics.logEvent(GA4Event.PreApprovalClaimDocumentAddedMissing,{},);
                this.claimDocument = [];
                this.newPreApprovalService.preAppovalForm.controls.step.setValue(2);
                this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_9__.Screens.NewPreApprovalReviewAndSubmit]);
            }
        };
    }
    get documentForm() {
        return this.newPreApprovalService.preAppovalForm.controls.documentForm;
    }
    get detailForm() {
        return this.newPreApprovalService.preAppovalForm.controls.detailForm;
    }
    get documentFormControl() {
        return this.documentForm.controls;
    }
    ionViewWillEnter() {
        this.unsubscribe$ = new rxjs__WEBPACK_IMPORTED_MODULE_12__.Subject();
        this.getInformation();
    }
    ionViewDidEnter() {
        this.subscription = this.platform.backButton.subscribeWithPriority(9999, () => {
            this.location.back();
        });
    }
    ionViewWillLeave() {
        this.fillNoteDocuments();
        this.unsubscribe$.next();
        this.unsubscribe$.complete();
        this.subscription.unsubscribe();
    }
    fillNoteDocuments() {
        let invoiceDocuments = this.documentForm.controls[0];
        this.documentForm.controls[0].value.document.forEach((element, index) => {
            const elements = document.getElementsByClassName('noteDoc-' + index);
            const textareaElement = elements[0];
            this.documentForm.controls[0].value.document[index].noteDescription = textareaElement.value;
        });
        this.documentForm.controls[1].value.document.forEach((element, index) => {
            const elements = document.getElementsByClassName('otherNoteDoc-' + index);
            const textareaElement = elements[0];
            this.documentForm.controls[1].value.document[index].noteDescription = textareaElement.value;
        });
    }
    handlerTaggingEvent(item) {
        const document = item.value;
        if (document.title == 'ASOAP Form') {
            this.firebaseAnalytics.logEvent(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_8__.GA4Event.ReimbursmentClaimASOAPDocumentUploaded, { document_type: document.title });
            this.firebaseAnalytics.logEvent(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_8__.GA4Event.ReimbursmentClaimASOAPDocumentUploadedMissing, {});
            this.clevertap.recordEventWithNameAndProps(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_8__.GA4Event.ReimbursmentClaimASOAPDocumentUploaded, { document_type: document.title });
        }
        else if (document.title == 'Discharge Summary') {
            this.firebaseAnalytics.logEvent(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_8__.GA4Event.ReimbursmentClaimDSUploaded, { document_type: document.title, });
            this.firebaseAnalytics.logEvent(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_8__.GA4Event.ReimbursmentClaimDSUploadedMissing, {});
            this.clevertap.recordEventWithNameAndProps(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_8__.GA4Event.ReimbursmentClaimDSUploaded, { document_type: document.title, });
        }
        else if (document.title == 'Lab/Radiology Test') {
            this.firebaseAnalytics.logEvent(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_8__.GA4Event.ReimbursmentClaimLRTUploaded, { document_type: document.title, });
            this.clevertap.recordEventWithNameAndProps(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_8__.GA4Event.ReimbursmentClaimLRTUploaded, { document_type: document.title, });
        }
        else if (document.title == 'Invoice') {
            this.firebaseAnalytics.logEvent(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_8__.GA4Event.ReimbursmentClaimInvoiceUploaded, { document_type: document.title });
            this.clevertap.recordEventWithNameAndProps(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_8__.GA4Event.ReimbursmentClaimInvoiceUploaded, { document_type: document.title });
        }
        else if (document.title == 'Additional Documents') {
            this.firebaseAnalytics.logEvent(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_8__.GA4Event.ReimbursmentClaimAdditionalUploaded, { document_type: document.title });
            this.clevertap.recordEventWithNameAndProps(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_8__.GA4Event.ReimbursmentClaimAdditionalUploaded, { document_type: document.title });
        }
    }
    openDialog(item) {
        const document = item.value;
        this.dialogSevice
            .open(_new_claim_upload_detail_upload_documents_upload_documents_component__WEBPACK_IMPORTED_MODULE_11__.UploadDocumentsComponent, {
            position: 'bottom',
            title: 'uploadDocuments.uploadDocument'
        })
            .afterClosed()
            .subscribe((res) => {
            if (res) {
                if (typeof res.file === 'string') {
                    const result = {
                        id: document.id,
                        rowNum: 0,
                        fileName: res.name,
                        fileType: res.type,
                        fileData: res.file,
                        fileSize: 0,
                        description: document.description,
                        title: document.title,
                        noteDescription: '',
                    };
                    if (!item.controls.document.value) {
                        item.controls.document.setValue([result]);
                    }
                    else {
                        item.controls.document.setValue([...item.controls.document.value, result]);
                    }
                }
                else {
                    this.preApprovalService.convertFile(res.file).subscribe((base64) => {
                        if (!base64)
                            return;
                        const result = {
                            id: document.id,
                            rowNum: 0,
                            fileName: res.name,
                            fileType: res.type,
                            fileData: base64,
                            fileSize: res.file.size,
                            description: document.description,
                            title: document.title,
                            noteDescription: '',
                        };
                        if (!item.controls.document.value) {
                            item.controls.document.setValue([result]);
                        }
                        else {
                            item.controls.document.setValue([...item.controls.document.value, result]);
                        }
                        this.cdr.detectChanges();
                    });
                }
                this.handlerTaggingEvent(item);
            }
            else {
                if (document.mandatory) {
                    this.isShowMandatory = true;
                }
            }
        });
    }
    showDetail(item) {
        item.controls.expanded.setValue(!item.controls.expanded.value);
    }
    onRemoveDocument(item, index) {
        item.document.splice(index, 1);
        this.cdr.detectChanges();
    }
    getInformation() {
        this.insuranceService.getPolicyInformation().pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_13__.takeUntil)(this.unsubscribe$)).subscribe((res) => {
            if (!res)
                return;
            this.currentPolicy = res;
            this.getClaimDocumentTypes();
        });
    }
    toggleNoteCards(arrayControl, indexImage) {
        let noteOpened = false;
        let element = document.querySelector('.noteCardContent-' + indexImage);
        if ((arrayControl === null || arrayControl === void 0 ? void 0 : arrayControl.code) == '2') {
            element = document.querySelector('.otherNoteCardContent-' + indexImage);
        }
        noteOpened = !element.hidden;
        const elements = document.querySelectorAll('.noteCard');
        elements.forEach((element) => {
            element.hidden = true;
        });
        element.hidden = noteOpened;
    }
    getClaimDocumentTypes() {
        // const request: RequestClaimDocumentType = {
        //   userPolicyId: this.currentPolicy.userPolicyId,
        //   serviceType: this.detailForm.controls.serviceType.value.id,
        // };
        if (this.documentForm.length == 0) {
            // this.uploadDocumentService
            //   .getClaimDocumentType(request)
            //   .subscribe(async (data) => {
            //     data.forEach((item) => {
            //       this.documentForm.push(
            //         this.fb.group({
            //           title: item.description,
            //           expanded: false,
            //           document: this.fb.control([]),
            //           mandatory: item.code != 'ItemizedInvoice' ? false : true,
            //           code: item.code,
            //           id: item.id,
            //           description: item.instruction,
            //         }),
            //       );
            //     });
            //   });
            this.documentForm.push(this.fb.group({
                title: 'uploadDocuments.neededDocuments',
                expanded: false,
                document: this.fb.control([]),
                mandatory: true,
                id: 1,
                description: 'uploadDocuments.neededDocumentsDescription'
            }));
        }
    }
};
UploadDetailComponent.ctorParameters = () => [
    { type: src_app_shared_components_nextgen_dialog_nextgen_dialog_service__WEBPACK_IMPORTED_MODULE_7__.DialogService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_14__.Router },
    { type: _awesome_cordova_plugins_firebase_analytics_ngx__WEBPACK_IMPORTED_MODULE_2__.FirebaseAnalytics },
    { type: src_app_service_pre_approval_pre_approval_service__WEBPACK_IMPORTED_MODULE_6__.PreApprovalService },
    { type: src_app_service_insurance_insurance_service__WEBPACK_IMPORTED_MODULE_4__.InsuranceService },
    { type: src_app_service_new_re_approval_new_pre_approval_service__WEBPACK_IMPORTED_MODULE_5__.NewPreApprovalService },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_15__.FormBuilder },
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_16__.ChangeDetectorRef },
    { type: _awesome_cordova_plugins_clevertap_ngx__WEBPACK_IMPORTED_MODULE_3__.CleverTap },
    { type: src_app_service_new_claim_upload_document_upload_document_service__WEBPACK_IMPORTED_MODULE_10__.UploadDocumentService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_17__.Platform },
    { type: _angular_common__WEBPACK_IMPORTED_MODULE_18__.Location }
];
UploadDetailComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_19__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_16__.Component)({
        selector: 'app-upload-detail',
        template: _upload_detail_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_upload_detail_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], UploadDetailComponent);



/***/ }),

/***/ 81308:
/*!**************************************************************!*\
  !*** ./src/app/service/pre-approval/pre-approval.service.ts ***!
  \**************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PreApprovalService": () => (/* binding */ PreApprovalService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ 28784);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @environments/environment */ 92340);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ 61555);





let PreApprovalService = class PreApprovalService {
    constructor(httpClient) {
        this.httpClient = httpClient;
        this.url = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.ApiURL;
    }
    getClaimDocumentTypes(request) {
        return this.httpClient.get(`${this.url}/mds/api/claim/v1.0/claimdocumenttypes`, {
            params: Object.assign({}, request)
        });
    }
    getFileReader() {
        const fileReader = new FileReader();
        const zoneOriginalInstance = fileReader['__zone_symbol__originalInstance'];
        return zoneOriginalInstance || fileReader;
    }
    convertFile(file) {
        const result = new rxjs__WEBPACK_IMPORTED_MODULE_1__.ReplaySubject(1);
        const reader = this.getFileReader();
        reader.readAsDataURL(file);
        reader.onload = () => result.next(btoa(reader.result.toString()));
        return result;
    }
};
PreApprovalService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__.HttpClient }
];
PreApprovalService = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Injectable)({
        providedIn: 'root',
    })
], PreApprovalService);



/***/ }),

/***/ 45223:
/*!**********************************************************************************************!*\
  !*** ./src/app/pages/new-pre-approval/claim-details/claim-details.component.scss?ngResource ***!
  \**********************************************************************************************/
/***/ ((module) => {

module.exports = ":root {\n  --nc-color-nextgen-neutral-grey-50: #f1efef;\n  --nc-color-nextgen-white: #ffffff;\n  --nc-color-nextgen-blue: #0d152e;\n  --nc-color-nextgen-green: #00908d;\n  --nc-color-nextgen-black: #000000;\n  --nc-color-nextgen-grey-background: #c8d3da;\n  --nc-color-nextgen-grey: #92a2ac;\n  --nc-color-nextgen-stone-grey: #fafafa;\n  --nc-color-nextgen-error: #fc1055;\n  --nc-color-nextgen-neutral-grey: #414141;\n  --nc-color-nextgen-fibrant-green: #00bab6;\n  --nc-color-nextgen-warning: #ffd048;\n  --nc-color-nextgen-green-background: #e6f2f2;\n  --nc-color-nextgen-neutral-grey-400: #7a7a7a;\n  --nc-color-nextgen-neutral-grey-100: #eff3f5;\n  --nc-color-nextgen-status-error: #ba0c3f;\n  --nc-color-nextgen-status-error-background: #ffeff4;\n  --nc-color-nextgen-status-warning: #cba127;\n  --nc-color-nextgen-status-warning-background: #fff8e6;\n  --nc-color-nextgen-blue-100: #dfeff2;\n  --nc-color-nextgen-error-red-700: #f62459;\n  --nc-color-nextgen-blue-500: #006192;\n  --nc-color-nextgen-blue-400: #79cdec;\n  --nc-color-nextgen-red-500: #ff6592;\n  --nc-color-nextgen-secondary-blue-300: #13a0d3;\n  --lumi-white-color: #ffffff;\n  --lumi-primary-yellow-color: #fab600;\n}\n\n.ion-color-green {\n  --ion-color-base: var(--nc-color-nextgen-green);\n  --ion-color-base-rgb: var(--nc-color-nextgen-green);\n  --ion-color-contrast: var(--nc-color-nextgen-white);\n  --ion-color-contrast-rgb: var(--nc-color-nextgen-green);\n  --ion-color-shade: var(--nc-color-nextgen-green);\n  --ion-color-tint: var(--nc-color-nextgen-green);\n}\n\n/*\n * 1. Custom CSS \n * ----------------------------------------------------------------------------\n */\n\n:root {\n  --nc-color-nextgen-neutral-grey-50: #f1efef;\n  --nc-color-nextgen-white: #ffffff;\n  --nc-color-nextgen-blue: #0d152e;\n  --nc-color-nextgen-green: #00908d;\n  --nc-color-nextgen-black: #000000;\n  --nc-color-nextgen-grey-background: #c8d3da;\n  --nc-color-nextgen-grey: #92a2ac;\n  --nc-color-nextgen-stone-grey: #fafafa;\n  --nc-color-nextgen-error: #fc1055;\n  --nc-color-nextgen-neutral-grey: #414141;\n  --nc-color-nextgen-fibrant-green: #00bab6;\n  --nc-color-nextgen-warning: #ffd048;\n  --nc-color-nextgen-green-background: #e6f2f2;\n  --nc-color-nextgen-neutral-grey-400: #7a7a7a;\n  --nc-color-nextgen-neutral-grey-100: #eff3f5;\n  --nc-color-nextgen-status-error: #ba0c3f;\n  --nc-color-nextgen-status-error-background: #ffeff4;\n  --nc-color-nextgen-status-warning: #cba127;\n  --nc-color-nextgen-status-warning-background: #fff8e6;\n  --nc-color-nextgen-blue-100: #dfeff2;\n  --nc-color-nextgen-error-red-700: #f62459;\n  --nc-color-nextgen-blue-500: #006192;\n  --nc-color-nextgen-blue-400: #79cdec;\n  --nc-color-nextgen-red-500: #ff6592;\n  --nc-color-nextgen-secondary-blue-300: #13a0d3;\n  --lumi-white-color: #ffffff;\n  --lumi-primary-yellow-color: #fab600;\n}\n\n.ion-color-green {\n  --ion-color-base: var(--nc-color-nextgen-green);\n  --ion-color-base-rgb: var(--nc-color-nextgen-green);\n  --ion-color-contrast: var(--nc-color-nextgen-white);\n  --ion-color-contrast-rgb: var(--nc-color-nextgen-green);\n  --ion-color-shade: var(--nc-color-nextgen-green);\n  --ion-color-tint: var(--nc-color-nextgen-green);\n}\n\n.display-xl {\n  font-size: 41px !important;\n  font-weight: 400 !important;\n  line-height: 120% !important;\n}\n\n.display-md {\n  font-size: 36px !important;\n  font-weight: 400 !important;\n  line-height: 120% !important;\n}\n\n.h1 {\n  font-size: 31px !important;\n  font-weight: 400 !important;\n  line-height: 120% !important;\n}\n\n.h2 {\n  font-size: 28px !important;\n  font-weight: 400 !important;\n  line-height: 120% !important;\n}\n\n.h3 {\n  font-size: 25px !important;\n  font-weight: 400 !important;\n  line-height: 120% !important;\n}\n\n.h4 {\n  font-size: 22px !important;\n  font-weight: 400 !important;\n  line-height: 120% !important;\n}\n\n.h5 {\n  font-size: 19px !important;\n  font-weight: 400 !important;\n  line-height: 120% !important;\n}\n\n.h6 {\n  font-size: 17px !important;\n  font-weight: 400 !important;\n  line-height: 120% !important;\n}\n\n.body-l {\n  font-size: 17px !important;\n  font-weight: 400 !important;\n  line-height: 120% !important;\n}\n\n.body-n {\n  font-size: 15px !important;\n  font-weight: 400 !important;\n  line-height: 120% !important;\n}\n\n.body-sm {\n  font-size: 13px !important;\n  font-weight: 400 !important;\n  line-height: 120% !important;\n}\n\n.body-xs {\n  font-size: 12px !important;\n  font-weight: 400 !important;\n  line-height: 120% !important;\n}\n\n.semibold.display-xl {\n  font-weight: 600 !important;\n}\n\n.semibold.display-md {\n  font-weight: 600 !important;\n}\n\n.semibold.h1 {\n  font-weight: 600 !important;\n}\n\n.semibold.h2 {\n  font-weight: 600 !important;\n}\n\n.semibold.h3 {\n  font-weight: 600 !important;\n}\n\n.semibold.h4 {\n  font-weight: 600 !important;\n}\n\n.semibold.h5 {\n  font-weight: 600 !important;\n}\n\n.semibold.h6 {\n  font-weight: 600 !important;\n}\n\n.semibold.body-l {\n  font-weight: 600 !important;\n}\n\n.semibold.body-n {\n  font-weight: 600 !important;\n}\n\n.semibold.body-sm {\n  font-weight: 600 !important;\n}\n\n.semibold.body-xs {\n  font-weight: 600 !important;\n}\n\n.bold.display-xl {\n  font-weight: 700 !important;\n}\n\n.bold.display-md {\n  font-weight: 700 !important;\n}\n\n.bold.h1 {\n  font-weight: 700 !important;\n}\n\n.bold.h2 {\n  font-weight: 700 !important;\n}\n\n.bold.h3 {\n  font-weight: 700 !important;\n}\n\n.bold.h4 {\n  font-weight: 700 !important;\n}\n\n.bold.h5 {\n  font-weight: 700 !important;\n}\n\n.bold.h6 {\n  font-weight: 700 !important;\n}\n\n.bold.body-l {\n  font-weight: 700 !important;\n}\n\n.bold.body-n {\n  font-weight: 700 !important;\n}\n\n.bold.body-sm {\n  font-weight: 700 !important;\n}\n\n.bold.body-xs {\n  font-weight: 700 !important;\n}\n\n@font-face {\n  font-family: \"Allianz Neo\";\n  font-style: normal;\n  font-weight: 300;\n  font-display: swap;\n  src: url('AllianzNeoW04-Light.woff2') format(\"woff2\"), url('AllianzNeoW04-Light.woff') format(\"woff\");\n}\n\n@font-face {\n  font-family: \"Allianz Neo\";\n  font-style: italic;\n  font-weight: 300;\n  font-display: swap;\n  src: url('AllianzNeoW04-LightItalic.woff2') format(\"woff2\"), url('AllianzNeoW04-LightItalic.woff') format(\"woff\");\n}\n\n@font-face {\n  font-family: \"Allianz Neo\";\n  font-style: normal;\n  font-weight: 400;\n  font-display: swap;\n  src: url('AllianzNeoW04-Regular.woff2') format(\"woff2\"), url('AllianzNeoW04-Regular.woff') format(\"woff\");\n}\n\n@font-face {\n  font-family: \"Allianz Neo\";\n  font-style: italic;\n  font-weight: 400;\n  font-display: swap;\n  src: url('AllianzNeoW04-Italic.woff2') format(\"woff2\"), url('AllianzNeoW04-Italic.woff') format(\"woff\");\n}\n\n@font-face {\n  font-family: \"Allianz Neo\";\n  font-style: normal;\n  font-weight: 600;\n  font-display: swap;\n  src: url('AllianzNeoW04-SemiBold.woff2') format(\"woff2\"), url('AllianzNeoW04-SemiBold.woff') format(\"woff\");\n}\n\n@font-face {\n  font-family: \"Allianz Neo\";\n  font-style: italic;\n  font-weight: 600;\n  font-display: swap;\n  src: url('AllianzNeoW04-SemiBoldIt.woff2') format(\"woff2\"), url('AllianzNeoW04-SemiBoldIt.woff') format(\"woff\");\n}\n\n@font-face {\n  font-family: \"Allianz Neo\";\n  font-style: normal;\n  font-weight: 700;\n  font-display: swap;\n  src: url('AllianzNeoW04-Bold.woff2') format(\"woff2\"), url('AllianzNeoW04-Bold.woff') format(\"woff\");\n}\n\n@font-face {\n  font-family: \"Allianz Neo\";\n  font-style: italic;\n  font-weight: 700;\n  font-display: swap;\n  src: url('AllianzNeoW04-BoldItalic.woff2') format(\"woff2\"), url('AllianzNeoW04-BoldItalic.woff') format(\"woff\");\n}\n\n* {\n  color: var(--nc-color-nextgen-neutral-grey);\n  font-family: \"Allianz Neo\", sans-serif;\n  font-weight: 400;\n  font-size: 16px;\n}\n\nhtml {\n  --ion-safe-area-top: 0px;\n}\n\n.col-1 {\n  width: 8.33%;\n}\n\n.col-2 {\n  width: 16.66%;\n}\n\n.col-3 {\n  width: 25%;\n}\n\n.col-4 {\n  width: 33.33%;\n}\n\n.col-5 {\n  width: 41.66%;\n}\n\n.col-6 {\n  width: 50%;\n}\n\n.col-7 {\n  width: 58.33%;\n}\n\n.col-8 {\n  width: 66.66%;\n}\n\n.col-9 {\n  width: 75%;\n}\n\n.col-10 {\n  width: 83.33%;\n}\n\n.col-11 {\n  width: 91.66%;\n}\n\n.col-12 {\n  width: 100%;\n}\n\n@media only screen and (max-width: 576px) {\n  /* For tablets: */\n  .col-sm-1 {\n    width: 8.33%;\n  }\n\n  .col-sm-2 {\n    width: 16.66%;\n  }\n\n  .col-sm-3 {\n    width: 25%;\n  }\n\n  .col-sm-4 {\n    width: 33.33%;\n  }\n\n  .col-sm-5 {\n    width: 41.66%;\n  }\n\n  .col-sm-6 {\n    width: 50%;\n  }\n\n  .col-sm-7 {\n    width: 58.33%;\n  }\n\n  .col-sm-8 {\n    width: 66.66%;\n  }\n\n  .col-sm-9 {\n    width: 75%;\n  }\n\n  .col-sm-10 {\n    width: 83.33%;\n  }\n\n  .col-sm-11 {\n    width: 91.66%;\n  }\n\n  .col-sm-12 {\n    width: 100%;\n  }\n}\n\n@media only screen and (max-width: 768px) and (min-width: 577px) {\n  /* For tablets: */\n  .col-md-1 {\n    width: 8.33%;\n  }\n\n  .col-md-2 {\n    width: 16.66%;\n  }\n\n  .col-md-3 {\n    width: 25%;\n  }\n\n  .col-md-4 {\n    width: 33.33%;\n  }\n\n  .col-md-5 {\n    width: 41.66%;\n  }\n\n  .col-md-6 {\n    width: 50%;\n  }\n\n  .col-md-7 {\n    width: 58.33%;\n  }\n\n  .col-md-8 {\n    width: 66.66%;\n  }\n\n  .col-md-9 {\n    width: 75%;\n  }\n\n  .col-md-10 {\n    width: 83.33%;\n  }\n\n  .col-md-11 {\n    width: 91.66%;\n  }\n\n  .col-md-12 {\n    width: 100%;\n  }\n}\n\n@media only screen and (min-width: 769px) {\n  /* For tablets: */\n  .col-lg-1 {\n    width: 8.33%;\n  }\n\n  .col-lg-2 {\n    width: 16.66%;\n  }\n\n  .col-lg-3 {\n    width: 25%;\n  }\n\n  .col-lg-4 {\n    width: 33.33%;\n  }\n\n  .col-lg-5 {\n    width: 41.66%;\n  }\n\n  .col-lg-6 {\n    width: 50%;\n  }\n\n  .col-lg-7 {\n    width: 58.33%;\n  }\n\n  .col-lg-8 {\n    width: 66.66%;\n  }\n\n  .col-lg-9 {\n    width: 75%;\n  }\n\n  .col-lg-10 {\n    width: 83.33%;\n  }\n\n  .col-lg-11 {\n    width: 91.66%;\n  }\n\n  .col-lg-12 {\n    width: 100%;\n  }\n}\n\n.row {\n  display: flex;\n  justify-content: center;\n  align-items: center;\n}\n\n.custom-toast {\n  --max-width: fit-content;\n}\n\n/*\n * 2. Custom CSS for compatibility with Edge\n * ----------------------------------------------------------------------------\n */\n\ninput::-ms-reveal,\ninput::-ms-clear {\n  display: none;\n}\n\n.swal2-popup {\n  margin-top: 20px;\n}\n\n/*\n * 3. Custom CSS for loading controller\n * ----------------------------------------------------------------------------\n */\n\n.transparent-loading-class {\n  --background: transparent;\n  --spinner-color: #47e6b1;\n}\n\n.loading-wrapper.sc-ion-loading-md {\n  box-shadow: unset;\n  -webkit-box-shadow: unset;\n}\n\n.uil {\n  color: var(--nc-color-nextgen-grey);\n}\n\n.btn {\n  height: 48px;\n  border-radius: 28px;\n  padding: 0px 41px 0px 41px;\n  box-shadow: none;\n}\n\n.btn.btn-circle {\n  background-color: var(--nc-color-nextgen-stone-grey) !important;\n  color: var(--nc-color-nextgen-black);\n  padding: unset !important;\n  height: 36px !important;\n  width: 36px !important;\n  border-radius: 50% !important;\n}\n\n.btn.btn-circle i {\n  color: var(--nc-color-nextgen-black);\n}\n\n.btn.primary {\n  background: var(--nc-color-nextgen-green);\n  color: var(--nc-color-nextgen-white);\n}\n\n.btn.primary .uil {\n  color: var(--nc-color-nextgen-white);\n}\n\n.btn.primary:disabled {\n  background-color: var(--nc-color-nextgen-grey-background) !important;\n  color: var(--nc-color-nextgen-grey) !important;\n}\n\n.btn.secondary {\n  background: var(--nc-color-nextgen-white) !important;\n  border-color: var(--nc-color-nextgen-green);\n  border: solid 1px;\n  color: var(--nc-color-nextgen-green);\n}\n\n.btn.secondary .uil {\n  color: var(--nc-color-nextgen-green);\n}\n\n.btn.secondary:disabled {\n  background-color: var(--nc-color-nextgen-white) !important;\n  color: var(--nc-color-nextgen-grey) !important;\n  border-color: var(--nc-color-nextgen-grey-background) !important;\n}\n\n.btn.transparent {\n  background: transparent !important;\n  border-color: var(--nc-color-nextgen-green);\n  border: solid 1px;\n  color: var(--nc-color-nextgen-green);\n}\n\n.btn.transparent .uil {\n  color: var(--nc-color-nextgen-green);\n}\n\n.btn.transparent:disabled {\n  background-color: transparent !important;\n  color: var(--nc-color-nextgen-grey) !important;\n  border-color: var(--nc-color-nextgen-grey-background) !important;\n}\n\n.btn.btn-large {\n  height: 56px !important;\n  width: 100%;\n}\n\n.btn.bold {\n  font-weight: 700 !important;\n}\n\n.btn.semibold {\n  font-weight: 600 !important;\n}\n\n.btn-no-space {\n  padding: 5px !important;\n  height: -moz-fit-content;\n  height: fit-content;\n}\n\n.btn-back {\n  width: 31px;\n  height: 28px;\n  background-color: transparent;\n  padding: 0;\n  color: var(--nc-color-nextgen-green);\n}\n\n.container {\n  padding: 2rem;\n  height: 100%;\n}\n\n.body-section {\n  width: 100%;\n  height: 95%;\n  overflow-y: auto;\n  position: relative;\n}\n\n.top-section {\n  width: 100%;\n  height: 10%;\n  justify-content: space-between;\n  display: flex;\n  align-items: center;\n}\n\n.form-control {\n  position: relative;\n  height: 85px;\n  margin-bottom: 8px;\n}\n\n.control {\n  border-radius: 8px;\n  height: 56px;\n  border: 1px solid var(--nc-color-nextgen-grey-background);\n  width: 100%;\n  position: absolute;\n  top: 32px;\n  background-color: var(--nc-color-nextgen-white);\n}\n\n.control table {\n  table-layout: fixed;\n  border-collapse: unset;\n}\n\n.control input {\n  height: 54px;\n  border: unset;\n  border-radius: 8px;\n  width: max-content;\n  width: 100%;\n  pointer-events: auto;\n  background-color: var(--nc-color-nextgen-white);\n}\n\n.control.textarea {\n  height: 108px;\n}\n\n.control textarea {\n  height: 106px;\n  border: unset;\n  border-radius: 8px;\n  width: max-content;\n  width: 100%;\n  pointer-events: auto;\n  resize: none;\n  background-color: var(--nc-color-nextgen-white);\n}\n\n.control input:focus {\n  outline: none;\n}\n\n.control:focus-within {\n  border-color: var(--nc-color-nextgen-green);\n}\n\n.control:focus-within .first-icon {\n  display: none;\n}\n\n.control:focus-within .first-icon.non-hidden {\n  display: table-cell;\n}\n\n.control .first-icon {\n  width: 32px;\n  text-align: center;\n  padding-left: 8px;\n}\n\n.control .first-icon i {\n  font-size: 24px !important;\n}\n\n.control .second-icon {\n  width: 32px;\n  text-align: center;\n}\n\n.control .second-icon i {\n  font-size: 24px !important;\n}\n\n.control:focus-within ~ div .control-label {\n  color: var(--nc-color-nextgen-green);\n}\n\n.control-error .control {\n  border-color: var(--nc-color-nextgen-error);\n}\n\n.control-error .control-label {\n  color: var(--nc-color-nextgen-error) !important;\n}\n\n.validation-summary li {\n  color: var(--nc-color-nextgen-error) !important;\n  list-style: none;\n}\n\n.validation-summary li i {\n  color: var(--nc-color-nextgen-error) !important;\n}\n\n.mr-1 {\n  margin-right: 0.5rem;\n}\n\n.mb-1 {\n  margin-bottom: 0.5rem;\n}\n\n.dialog-pane {\n  position: absolute;\n  pointer-events: auto;\n  box-sizing: border-box;\n  z-index: 1000;\n  display: block;\n  max-width: 100%;\n  max-height: 100%;\n}\n\n.overlay-backdrop {\n  background-color: var(--nc-color-nextgen-neutral-grey);\n  opacity: 0.2 !important;\n}\n\n.dialog-container {\n  animation: fadeIn 0.5s linear;\n  background-color: var(--nc-color-nextgen-white);\n}\n\n@keyframes fadeIn {\n  from {\n    transform: translateY(100%);\n  }\n  to {\n    transform: translateY(0%);\n  }\n}\n\n.error {\n  color: var(--nc-color-nextgen-error);\n}\n\n.error.background {\n  background-color: var(--nc-color-nextgen-error);\n}\n\n.success {\n  color: var(--nc-color-nextgen-fibrant-green);\n}\n\n.success.background {\n  background-color: var(--nc-color-nextgen-fibrant-green);\n}\n\n.warning {\n  color: var(--nc-color-nextgen-warning);\n}\n\n.warning.background {\n  background-color: var(--nc-color-nextgen-warning);\n}\n\n.select {\n  width: 100%;\n  height: 54px;\n  border: unset;\n  border-radius: 8px;\n  display: grid;\n  -webkit-appearance: none;\n          appearance: none;\n  grid-template-areas: \"select\";\n}\n\n.select:focus {\n  outline: unset;\n}\n\n.color-black {\n  color: var(--nc-color-nextgen-black);\n}\n\n.modal-default {\n  --width: 100%;\n  --height: 100%;\n}\n\n.integration-panel {\n  width: 100%;\n  height: 100%;\n  max-width: 100% !important;\n}\n\n.verloop-button {\n  visibility: hidden;\n}\n\n.back-area {\n  position: fixed;\n  top: 0;\n  right: 0;\n  height: 50px;\n  width: 100%;\n  background-color: var(--nc-color-nextgen-neutral-grey-50);\n  z-index: 9999999;\n}\n\n.back-area.ios {\n  height: 80px;\n}\n\n.title-widget {\n  text-align: center;\n  position: sticky;\n  top: 48px;\n}\n\n.button-back {\n  background-color: #fafafa;\n  height: 36px;\n  width: 36px;\n  border-radius: 50%;\n  position: absolute;\n  left: 18px;\n  bottom: 4px;\n}\n\n.icon-close-widget {\n  position: absolute;\n  z-index: 250;\n  left: 11px;\n  bottom: 13px;\n}\n\n.data-default {\n  position: absolute;\n  top: 50%;\n  left: 50%;\n  transform: translate(-50%, -50%);\n  text-align: center;\n  color: var(--nc-color-nextgen-neutral-grey-400);\n  z-index: 1000;\n}\n\n.avaamo__icon {\n  visibility: hidden !important;\n}\n\n.avaamo__chat__widget.ios #avaamo__popup {\n  padding-top: 40px;\n}\n\n.d-flex {\n  display: flex;\n}\n\nnextcare-layout {\n  left: 0;\n  right: 0;\n  top: 0;\n  bottom: 0;\n  display: flex;\n  position: absolute;\n  flex-direction: column;\n  justify-content: space-between;\n  contain: layout size style;\n  overflow: hidden;\n  background-color: var(--nc-color-nextgen-neutral-grey-50);\n  padding-right: 24px;\n  padding-left: 24px;\n}\n\nion-header.ios.header-ios {\n  margin-top: 40px;\n}\n\n.header-ios ion-toolbar:last-of-type {\n  --border-width: 0px !important;\n}\n\n.header-md.md::after {\n  display: none;\n}\n\nion-toolbar {\n  padding-right: unset !important;\n  padding-left: unset !important;\n}\n\ni.icon-back {\n  content: url('long-arrow-left-icon.svg');\n}\n\n.verloop-widget.ios .verloop-container.visible {\n  height: calc(100% - 40px);\n  top: 40px;\n}\n\n#nextcare-ads {\n  display: none;\n  overflow: scroll;\n  height: 180px;\n}\n\n.d-block {\n  display: block;\n}\n\n.title-text {\n  color: var(--nc-color-nextgen-blue);\n}\n\n:host ion-datetime #shadow-root .datetime-calendar .calendar-header .calendar-action-buttons .calendar-month-year {\n  align-items: center;\n  justify-content: center;\n  display: flex;\n  width: 100%;\n}\n\n:host ion-datetime #shadow-root .datetime-calendar .calendar-header .calendar-action-buttons .calendar-month-year ion-icon {\n  display: none;\n}\n\n:host ion-datetime #shadow-root .datetime-calendar .calendar-header .calendar-action-buttons .calendar-next-prev {\n  position: absolute;\n  width: 100%;\n  right: 0;\n}\n\n:host ion-datetime #shadow-root .datetime-calendar .calendar-header .calendar-action-buttons .calendar-next-prev ion-buttons {\n  display: flex;\n  justify-content: space-between;\n  width: 100%;\n}\n\n.mat-dialog-container {\n  padding: unset !important;\n}\n\n/* Change autocomplete styles in WebKit */\n\ninput:-webkit-autofill,\ninput:-webkit-autofill:hover,\ninput:-webkit-autofill:focus,\ntextarea:-webkit-autofill,\ntextarea:-webkit-autofill:hover,\ntextarea:-webkit-autofill:focus,\nselect:-webkit-autofill,\nselect:-webkit-autofill:hover,\nselect:-webkit-autofill:focus {\n  -webkit-text-fill-color: black;\n  -webkit-box-shadow: 0 0 0px 1000px white inset;\n  -webkit-transition: background-color 5000s ease-in-out 0s;\n  transition: background-color 5000s ease-in-out 0s;\n}\n\n.force-update-popup + .cdk-global-overlay-wrapper .save-btn {\n  background: var(--lumi-primary-yellow-color) !important;\n  color: var(--lumi-white-color) !important;\n  font-weight: bold !important;\n}\n\n.force-update-popup + .cdk-global-overlay-wrapper .cancel-btn {\n  color: var(--lumi-primary-yellow-color) !important;\n}\n\n@keyframes slideInRight {\n  0% {\n    transform: translate3d(100%, 0, 0);\n    visibility: visible;\n  }\n  to {\n    transform: translateZ(0);\n  }\n}\n\n.animate__slideInRight {\n  animation-name: slideInRight;\n}\n\n.animate__animated {\n  animation-duration: 0.5s;\n  animation-duration: 0.5s;\n  animation-fill-mode: both;\n}\n\nion-content {\n  --background: #F1EFEF;\n}\n\n.claim-details-main {\n  margin-bottom: 128px;\n}\n\n.claim-details-main .claim-details-content .detail-content {\n  margin-bottom: 1.9rem;\n  cursor: pointer;\n}\n\n.claim-details-main .claim-details-content .detail-content .detail-title {\n  margin-bottom: 0.2rem;\n}\n\n.claim-details-main .claim-details-content .detail-content button {\n  display: flex;\n  justify-content: space-between;\n  background-color: var(--nc-color-nextgen-white);\n  width: 100%;\n  padding: 18px 8px 18px 15px;\n  border: 1px solid var(--nc-color-nextgen-grey-background);\n  border-radius: 8px;\n}\n\n.claim-details-main .claim-details-content .detail-content button span {\n  color: var(--nc-color-nextgen-blue);\n}\n\n.claim-details-main .claim-details-content .currency-content {\n  display: flex;\n  justify-content: space-between;\n}\n\n.claim-details-main .claim-details-content .currency-content .currency {\n  margin-right: 14vw;\n  width: 100%;\n}\n\n.claim-details-main .claim-details-content .currency-content .currency .detail-title {\n  margin-bottom: 0.2rem;\n}\n\n.claim-details-main .claim-details-content .currency-content .currency button {\n  display: flex;\n  justify-content: space-between;\n  background-color: var(--nc-color-nextgen-white);\n  width: 100%;\n  padding: 1.1rem 1rem;\n  border: 1px solid var(--nc-color-nextgen-grey-background);\n  border-radius: 8px;\n}\n\n.claim-details-main .claim-details-content .currency-content .currency button span {\n  color: var(--nc-color-nextgen-blue);\n}\n\n.claim-details-main .claim-details-content .currency-content .amount {\n  width: 100%;\n}\n\n.claim-details-main .claim-details-content .currency-content .amount .detail-title {\n  margin-bottom: 0.2rem;\n}\n\n.claim-details-main .claim-details-content .currency-content .amount ion-card {\n  background-color: var(--nc-color-nextgen-white);\n  width: 100%;\n  padding: 1.1rem 1rem;\n  border: 1px solid var(--nc-color-nextgen-grey-background);\n  border-radius: 8px;\n  box-shadow: none;\n}\n\n.claim-details-main .claim-details-content .currency-content .amount ion-card span {\n  color: var(--nc-color-nextgen-blue);\n}\n\n.another-placehold {\n  color: var(--nc-color-nextgen-grey) !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFxjb2xvci5zY3NzIiwiY2xhaW0tZGV0YWlscy5jb21wb25lbnQuc2NzcyIsIi4uXFwuLlxcLi5cXC4uXFxzdHlsZS5zY3NzIiwiLi5cXC4uXFwuLlxcLi5cXGZvbnQtc2l6ZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0MsMkNBQUE7RUFDQSxpQ0FBQTtFQUNBLGdDQUFBO0VBQ0EsaUNBQUE7RUFDQSxpQ0FBQTtFQUNBLDJDQUFBO0VBQ0EsZ0NBQUE7RUFDQSxzQ0FBQTtFQUNBLGlDQUFBO0VBQ0Esd0NBQUE7RUFDQSx5Q0FBQTtFQUNBLG1DQUFBO0VBQ0EsNENBQUE7RUFDQSw0Q0FBQTtFQUNBLDRDQUFBO0VBQ0Esd0NBQUE7RUFDQSxtREFBQTtFQUNBLDBDQUFBO0VBQ0EscURBQUE7RUFDQSxvQ0FBQTtFQUNBLHlDQUFBO0VBQ0Esb0NBQUE7RUFDQSxvQ0FBQTtFQUNBLG1DQUFBO0VBQ0EsOENBQUE7RUFFQSwyQkFBQTtFQUNBLG9DQUFBO0FDQUQ7O0FEZ0NBO0VBQ0MsK0NBQUE7RUFDQSxtREFBQTtFQUNBLG1EQUFBO0VBQ0EsdURBQUE7RUFDQSxnREFBQTtFQUNBLCtDQUFBO0FDN0JEOztBQ3JDQTs7O0VBQUE7O0FGQUE7RUFDQywyQ0FBQTtFQUNBLGlDQUFBO0VBQ0EsZ0NBQUE7RUFDQSxpQ0FBQTtFQUNBLGlDQUFBO0VBQ0EsMkNBQUE7RUFDQSxnQ0FBQTtFQUNBLHNDQUFBO0VBQ0EsaUNBQUE7RUFDQSx3Q0FBQTtFQUNBLHlDQUFBO0VBQ0EsbUNBQUE7RUFDQSw0Q0FBQTtFQUNBLDRDQUFBO0VBQ0EsNENBQUE7RUFDQSx3Q0FBQTtFQUNBLG1EQUFBO0VBQ0EsMENBQUE7RUFDQSxxREFBQTtFQUNBLG9DQUFBO0VBQ0EseUNBQUE7RUFDQSxvQ0FBQTtFQUNBLG9DQUFBO0VBQ0EsbUNBQUE7RUFDQSw4Q0FBQTtFQUVBLDJCQUFBO0VBQ0Esb0NBQUE7QUMyQ0Q7O0FEWEE7RUFDQywrQ0FBQTtFQUNBLG1EQUFBO0VBQ0EsbURBQUE7RUFDQSx1REFBQTtFQUNBLGdEQUFBO0VBQ0EsK0NBQUE7QUNjRDs7QUVoRkE7RUFDSSwwQkFBQTtFQUNBLDJCQUFBO0VBQ0EsNEJBQUE7QUZtRko7O0FFaEZBO0VBQ0ksMEJBQUE7RUFDQSwyQkFBQTtFQUNBLDRCQUFBO0FGbUZKOztBRWhGQTtFQUNJLDBCQUFBO0VBQ0EsMkJBQUE7RUFDQSw0QkFBQTtBRm1GSjs7QUVoRkE7RUFDSSwwQkFBQTtFQUNBLDJCQUFBO0VBQ0EsNEJBQUE7QUZtRko7O0FFaEZBO0VBQ0ksMEJBQUE7RUFDQSwyQkFBQTtFQUNBLDRCQUFBO0FGbUZKOztBRWhGQTtFQUNJLDBCQUFBO0VBQ0EsMkJBQUE7RUFDQSw0QkFBQTtBRm1GSjs7QUVoRkE7RUFDSSwwQkFBQTtFQUNBLDJCQUFBO0VBQ0EsNEJBQUE7QUZtRko7O0FFaEZBO0VBQ0ksMEJBQUE7RUFDQSwyQkFBQTtFQUNBLDRCQUFBO0FGbUZKOztBRWhGQTtFQUNJLDBCQUFBO0VBQ0EsMkJBQUE7RUFDQSw0QkFBQTtBRm1GSjs7QUVoRkE7RUFDSSwwQkFBQTtFQUNBLDJCQUFBO0VBQ0EsNEJBQUE7QUZtRko7O0FFaEZBO0VBQ0ksMEJBQUE7RUFDQSwyQkFBQTtFQUNBLDRCQUFBO0FGbUZKOztBRWhGQTtFQUNJLDBCQUFBO0VBQ0EsMkJBQUE7RUFDQSw0QkFBQTtBRm1GSjs7QUUvRUk7RUFDSSwyQkFBQTtBRmtGUjs7QUVoRkk7RUFDSSwyQkFBQTtBRmtGUjs7QUVoRkk7RUFDSSwyQkFBQTtBRmtGUjs7QUVoRkk7RUFDSSwyQkFBQTtBRmtGUjs7QUVoRkk7RUFDSSwyQkFBQTtBRmtGUjs7QUVoRkk7RUFDSSwyQkFBQTtBRmtGUjs7QUVoRkk7RUFDSSwyQkFBQTtBRmtGUjs7QUVoRkk7RUFDSSwyQkFBQTtBRmtGUjs7QUVoRkk7RUFDSSwyQkFBQTtBRmtGUjs7QUVoRkk7RUFDSSwyQkFBQTtBRmtGUjs7QUVoRkk7RUFDSSwyQkFBQTtBRmtGUjs7QUVoRkk7RUFDSSwyQkFBQTtBRmtGUjs7QUU3RUk7RUFDSSwyQkFBQTtBRmdGUjs7QUU5RUk7RUFDSSwyQkFBQTtBRmdGUjs7QUU5RUk7RUFDSSwyQkFBQTtBRmdGUjs7QUU5RUk7RUFDSSwyQkFBQTtBRmdGUjs7QUU5RUk7RUFDSSwyQkFBQTtBRmdGUjs7QUU5RUk7RUFDSSwyQkFBQTtBRmdGUjs7QUU5RUk7RUFDSSwyQkFBQTtBRmdGUjs7QUU5RUk7RUFDSSwyQkFBQTtBRmdGUjs7QUU5RUk7RUFDSSwyQkFBQTtBRmdGUjs7QUU5RUk7RUFDSSwyQkFBQTtBRmdGUjs7QUU5RUk7RUFDSSwyQkFBQTtBRmdGUjs7QUU5RUk7RUFDSSwyQkFBQTtBRmdGUjs7QUN2TkE7RUFDQywwQkFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrQkFBQTtFQUNBLHFHQUFBO0FEME5EOztBQ3BOQTtFQUNDLDBCQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtFQUNBLGtCQUFBO0VBQ0EsaUhBQUE7QURzTkQ7O0FDaE5BO0VBQ0MsMEJBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0Esa0JBQUE7RUFDQSx5R0FBQTtBRGtORDs7QUM1TUE7RUFDQywwQkFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrQkFBQTtFQUNBLHVHQUFBO0FEOE1EOztBQ3hNQTtFQUNDLDBCQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtFQUNBLGtCQUFBO0VBQ0EsMkdBQUE7QUQwTUQ7O0FDcE1BO0VBQ0MsMEJBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0Esa0JBQUE7RUFDQSwrR0FBQTtBRHNNRDs7QUNoTUE7RUFDQywwQkFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrQkFBQTtFQUNBLG1HQUFBO0FEa01EOztBQzVMQTtFQUNDLDBCQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtFQUNBLGtCQUFBO0VBQ0EsK0dBQUE7QUQ4TEQ7O0FDeExBO0VBQ0MsMkNGOUQ0QjtFRStENUIsc0NBQUE7RUFDQSxnQkFBQTtFQUNBLGVBQUE7QUQwTEQ7O0FDdkxBO0VBQ0Msd0JBQUE7QUQwTEQ7O0FDdkxBO0VBQ0MsWUFBQTtBRDBMRDs7QUN2TEE7RUFDQyxhQUFBO0FEMExEOztBQ3ZMQTtFQUNDLFVBQUE7QUQwTEQ7O0FDdkxBO0VBQ0MsYUFBQTtBRDBMRDs7QUN2TEE7RUFDQyxhQUFBO0FEMExEOztBQ3ZMQTtFQUNDLFVBQUE7QUQwTEQ7O0FDdkxBO0VBQ0MsYUFBQTtBRDBMRDs7QUN2TEE7RUFDQyxhQUFBO0FEMExEOztBQ3ZMQTtFQUNDLFVBQUE7QUQwTEQ7O0FDdkxBO0VBQ0MsYUFBQTtBRDBMRDs7QUN2TEE7RUFDQyxhQUFBO0FEMExEOztBQ3ZMQTtFQUNDLFdBQUE7QUQwTEQ7O0FDdkxBO0VBQ0MsaUJBQUE7RUFDQTtJQUNDLFlBQUE7RUQwTEE7O0VDdkxEO0lBQ0MsYUFBQTtFRDBMQTs7RUN2TEQ7SUFDQyxVQUFBO0VEMExBOztFQ3ZMRDtJQUNDLGFBQUE7RUQwTEE7O0VDdkxEO0lBQ0MsYUFBQTtFRDBMQTs7RUN2TEQ7SUFDQyxVQUFBO0VEMExBOztFQ3ZMRDtJQUNDLGFBQUE7RUQwTEE7O0VDdkxEO0lBQ0MsYUFBQTtFRDBMQTs7RUN2TEQ7SUFDQyxVQUFBO0VEMExBOztFQ3ZMRDtJQUNDLGFBQUE7RUQwTEE7O0VDdkxEO0lBQ0MsYUFBQTtFRDBMQTs7RUN2TEQ7SUFDQyxXQUFBO0VEMExBO0FBQ0Y7O0FDdkxBO0VBQ0MsaUJBQUE7RUFDQTtJQUNDLFlBQUE7RUR5TEE7O0VDdExEO0lBQ0MsYUFBQTtFRHlMQTs7RUN0TEQ7SUFDQyxVQUFBO0VEeUxBOztFQ3RMRDtJQUNDLGFBQUE7RUR5TEE7O0VDdExEO0lBQ0MsYUFBQTtFRHlMQTs7RUN0TEQ7SUFDQyxVQUFBO0VEeUxBOztFQ3RMRDtJQUNDLGFBQUE7RUR5TEE7O0VDdExEO0lBQ0MsYUFBQTtFRHlMQTs7RUN0TEQ7SUFDQyxVQUFBO0VEeUxBOztFQ3RMRDtJQUNDLGFBQUE7RUR5TEE7O0VDdExEO0lBQ0MsYUFBQTtFRHlMQTs7RUN0TEQ7SUFDQyxXQUFBO0VEeUxBO0FBQ0Y7O0FDdExBO0VBQ0MsaUJBQUE7RUFDQTtJQUNDLFlBQUE7RUR3TEE7O0VDckxEO0lBQ0MsYUFBQTtFRHdMQTs7RUNyTEQ7SUFDQyxVQUFBO0VEd0xBOztFQ3JMRDtJQUNDLGFBQUE7RUR3TEE7O0VDckxEO0lBQ0MsYUFBQTtFRHdMQTs7RUNyTEQ7SUFDQyxVQUFBO0VEd0xBOztFQ3JMRDtJQUNDLGFBQUE7RUR3TEE7O0VDckxEO0lBQ0MsYUFBQTtFRHdMQTs7RUNyTEQ7SUFDQyxVQUFBO0VEd0xBOztFQ3JMRDtJQUNDLGFBQUE7RUR3TEE7O0VDckxEO0lBQ0MsYUFBQTtFRHdMQTs7RUNyTEQ7SUFDQyxXQUFBO0VEd0xBO0FBQ0Y7O0FDckxBO0VBQ0MsYUFBQTtFQUNBLHVCQUFBO0VBQ0EsbUJBQUE7QUR1TEQ7O0FDbkxBO0VBQ0Msd0JBQUE7QURzTEQ7O0FDbkxBOzs7RUFBQTs7QUFJQTs7RUFFQyxhQUFBO0FEc0xEOztBQ25MQTtFQUNDLGdCQUFBO0FEc0xEOztBQ25MQTs7O0VBQUE7O0FBSUE7RUFDQyx5QkFBQTtFQUNBLHdCQUFBO0FEc0xEOztBQ25MQTtFQUNDLGlCQUFBO0VBQ0EseUJBQUE7QURzTEQ7O0FDbkxBO0VBQ0MsbUNGM1RvQjtBQ2lmckI7O0FDbkxBO0VBQ0MsWUFBQTtFQUNBLG1CQUFBO0VBQ0EsMEJBQUE7RUFDQSxnQkFBQTtBRHNMRDs7QUNwTEM7RUFDQywrREFBQTtFQUNBLG9DRnhVb0I7RUV5VXBCLHlCQUFBO0VBQ0EsdUJBQUE7RUFDQSxzQkFBQTtFQUNBLDZCQUFBO0FEc0xGOztBQ3BMRTtFQUNDLG9DRi9VbUI7QUNxZ0J0Qjs7QUNsTEM7RUFDQyx5Q0Z0Vm9CO0VFdVZwQixvQ0Z0Vm9CO0FDMGdCdEI7O0FDbExFO0VBQ0Msb0NGelZtQjtBQzZnQnRCOztBQ2pMRTtFQUNDLG9FQUFBO0VBQ0EsOENBQUE7QURtTEg7O0FDL0tDO0VBQ0Msb0RBQUE7RUFDQSwyQ0ZyV29CO0VFc1dwQixpQkFBQTtFQUNBLG9DRnZXb0I7QUN3aEJ0Qjs7QUMvS0U7RUFDQyxvQ0YxV21CO0FDMmhCdEI7O0FDOUtFO0VBQ0MsMERBQUE7RUFDQSw4Q0FBQTtFQUNBLGdFQUFBO0FEZ0xIOztBQzVLQztFQUNDLGtDQUFBO0VBQ0EsMkNGdFhvQjtFRXVYcEIsaUJBQUE7RUFDQSxvQ0Z4WG9CO0FDc2lCdEI7O0FDNUtFO0VBQ0Msb0NGM1htQjtBQ3lpQnRCOztBQzNLRTtFQUNDLHdDQUFBO0VBQ0EsOENBQUE7RUFDQSxnRUFBQTtBRDZLSDs7QUN6S0M7RUFDQyx1QkFBQTtFQUNBLFdBQUE7QUQyS0Y7O0FDeEtDO0VBQ0MsMkJBQUE7QUQwS0Y7O0FDdktDO0VBQ0MsMkJBQUE7QUR5S0Y7O0FDcktBO0VBQ0MsdUJBQUE7RUFDQSx3QkFBQTtFQUFBLG1CQUFBO0FEd0tEOztBQ3JLQTtFQUNDLFdBQUE7RUFDQSxZQUFBO0VBQ0EsNkJBQUE7RUFDQSxVQUFBO0VBQ0Esb0NGN1pxQjtBQ3FrQnRCOztBQ3JLQTtFQUNDLGFBQUE7RUFDQSxZQUFBO0FEd0tEOztBQ3JLQTtFQUNDLFdBQUE7RUFDQSxXQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrQkFBQTtBRHdLRDs7QUNyS0E7RUFDQyxXQUFBO0VBQ0EsV0FBQTtFQUNBLDhCQUFBO0VBQ0EsYUFBQTtFQUNBLG1CQUFBO0FEd0tEOztBQ3JLQTtFQUNDLGtCQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0FEd0tEOztBQ3JLQTtFQUNDLGtCQUFBO0VBQ0EsWUFBQTtFQUNBLHlEQUFBO0VBQ0EsV0FBQTtFQUNBLGtCQUFBO0VBQ0EsU0FBQTtFQUNBLCtDRmhjcUI7QUN3bUJ0Qjs7QUN0S0M7RUFDQyxtQkFBQTtFQUNBLHNCQUFBO0FEd0tGOztBQ3JLQztFQUNDLFlBQUE7RUFDQSxhQUFBO0VBQ0Esa0JBQUE7RUFDQSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxvQkFBQTtFQUNBLCtDRjljb0I7QUNxbkJ0Qjs7QUNwS0M7RUFDQyxhQUFBO0FEc0tGOztBQ25LQztFQUNDLGFBQUE7RUFDQSxhQUFBO0VBQ0Esa0JBQUE7RUFDQSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxvQkFBQTtFQUNBLFlBQUE7RUFDQSwrQ0Y3ZG9CO0FDa29CdEI7O0FDbEtDO0VBQ0MsYUFBQTtBRG9LRjs7QUNqS0M7RUFDQywyQ0Z0ZW9CO0FDeW9CdEI7O0FDaktFO0VBQ0MsYUFBQTtBRG1LSDs7QUNoS0U7RUFDQyxtQkFBQTtBRGtLSDs7QUM5SkM7RUFDQyxXQUFBO0VBQ0Esa0JBQUE7RUFDQSxpQkFBQTtBRGdLRjs7QUM5SkU7RUFDQywwQkFBQTtBRGdLSDs7QUM1SkM7RUFDQyxXQUFBO0VBQ0Esa0JBQUE7QUQ4SkY7O0FDM0pFO0VBQ0MsMEJBQUE7QUQ2Skg7O0FDeEpBO0VBQ0Msb0NGdmdCcUI7QUNrcUJ0Qjs7QUN2SkM7RUFDQywyQ0Z0Z0JvQjtBQ2dxQnRCOztBQ3ZKQztFQUNDLCtDQUFBO0FEeUpGOztBQ3BKQztFQUNDLCtDQUFBO0VBQ0EsZ0JBQUE7QUR1SkY7O0FDckpFO0VBQ0MsK0NBQUE7QUR1Skg7O0FDbEpBO0VBQ0Msb0JBQUE7QURxSkQ7O0FDbEpBO0VBQ0MscUJBQUE7QURxSkQ7O0FDbEpBO0VBQ0Msa0JBQUE7RUFDQSxvQkFBQTtFQUNBLHNCQUFBO0VBQ0EsYUFBQTtFQUNBLGNBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7QURxSkQ7O0FDbEpBO0VBQ0Msc0RGM2lCNEI7RUU0aUI1Qix1QkFBQTtBRHFKRDs7QUNsSkE7RUFDQyw2QkFBQTtFQUNBLCtDRnZqQnFCO0FDNHNCdEI7O0FDbEpBO0VBQ0M7SUFDQywyQkFBQTtFRHFKQTtFQ2xKRDtJQUNDLHlCQUFBO0VEb0pBO0FBQ0Y7O0FDakpBO0VBQ0Msb0NGaGtCcUI7QUNtdEJ0Qjs7QUNqSkM7RUFDQywrQ0Zua0JvQjtBQ3N0QnRCOztBQy9JQTtFQUNDLDRDRnRrQjZCO0FDd3RCOUI7O0FDaEpDO0VBQ0MsdURGemtCNEI7QUMydEI5Qjs7QUM5SUE7RUFDQyxzQ0Y3a0J1QjtBQzh0QnhCOztBQy9JQztFQUNDLGlERmhsQnNCO0FDaXVCeEI7O0FDN0lBO0VBQ0MsV0FBQTtFQUNBLFlBQUE7RUFDQSxhQUFBO0VBQ0Esa0JBQUE7RUFDQSxhQUFBO0VBQ0Esd0JBQUE7VUFBQSxnQkFBQTtFQUNBLDZCQUFBO0FEZ0pEOztBQzlJQztFQUNDLGNBQUE7QURnSkY7O0FDNUlBO0VBQ0Msb0NGMW1CcUI7QUN5dkJ0Qjs7QUM1SUE7RUFDQyxhQUFBO0VBQ0EsY0FBQTtBRCtJRDs7QUM1SUE7RUFDQyxXQUFBO0VBQ0EsWUFBQTtFQUNBLDBCQUFBO0FEK0lEOztBQzVJQTtFQUNDLGtCQUFBO0FEK0lEOztBQzVJQTtFQUNDLGVBQUE7RUFDQSxNQUFBO0VBQ0EsUUFBQTtFQUNBLFlBQUE7RUFDQSxXQUFBO0VBQ0EseURGem5CK0I7RUUwbkIvQixnQkFBQTtBRCtJRDs7QUM3SUM7RUFDQyxZQUFBO0FEK0lGOztBQzNJQTtFQUNDLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxTQUFBO0FEOElEOztBQzNJQTtFQUNDLHlCQUFBO0VBQ0EsWUFBQTtFQUNBLFdBQUE7RUFDQSxrQkFBQTtFQUNBLGtCQUFBO0VBQ0EsVUFBQTtFQUNBLFdBQUE7QUQ4SUQ7O0FDM0lBO0VBQ0Msa0JBQUE7RUFDQSxZQUFBO0VBQ0EsVUFBQTtFQUNBLFlBQUE7QUQ4SUQ7O0FDM0lBO0VBQ0Msa0JBQUE7RUFDQSxRQUFBO0VBQ0EsU0FBQTtFQUNBLGdDQUFBO0VBQ0Esa0JBQUE7RUFDQSwrQ0Y3cEJnQztFRThwQmhDLGFBQUE7QUQ4SUQ7O0FDM0lBO0VBQ0MsNkJBQUE7QUQ4SUQ7O0FDMUlDO0VBQ0MsaUJBQUE7QUQ2SUY7O0FDeklBO0VBQ0MsYUFBQTtBRDRJRDs7QUN6SUE7RUFDQyxPQUFBO0VBQ0EsUUFBQTtFQUNBLE1BQUE7RUFDQSxTQUFBO0VBQ0EsYUFBQTtFQUNBLGtCQUFBO0VBQ0Esc0JBQUE7RUFDQSw4QkFBQTtFQUNBLDBCQUFBO0VBQ0EsZ0JBQUE7RUFDQSx5REYzckIrQjtFRTRyQi9CLG1CQUFBO0VBQ0Esa0JBQUE7QUQ0SUQ7O0FDeklBO0VBQ0MsZ0JBQUE7QUQ0SUQ7O0FDeklBO0VBQ0MsOEJBQUE7QUQ0SUQ7O0FDeklBO0VBQ0MsYUFBQTtBRDRJRDs7QUN6SUE7RUFDQywrQkFBQTtFQUNBLDhCQUFBO0FENElEOztBQ3pJQTtFQUNDLHdDQUFBO0FENElEOztBQ3hJQztFQUNDLHlCQUFBO0VBQ0EsU0FBQTtBRDJJRjs7QUN2SUE7RUFDQyxhQUFBO0VBQ0EsZ0JBQUE7RUFDQSxhQUFBO0FEMElEOztBQ3ZJQTtFQUNDLGNBQUE7QUQwSUQ7O0FDdklBO0VBQ0MsbUNGbnZCb0I7QUM2M0JyQjs7QUNuSUk7RUFDQyxtQkFBQTtFQUNBLHVCQUFBO0VBQ0EsYUFBQTtFQUNBLFdBQUE7QURzSUw7O0FDcElLO0VBQ0MsYUFBQTtBRHNJTjs7QUNsSUk7RUFDQyxrQkFBQTtFQUNBLFdBQUE7RUFDQSxRQUFBO0FEb0lMOztBQ2xJSztFQUNDLGFBQUE7RUFDQSw4QkFBQTtFQUNBLFdBQUE7QURvSU47O0FDNUhBO0VBQ0MseUJBQUE7QUQrSEQ7O0FDNUhBLHlDQUFBOztBQUNBOzs7Ozs7Ozs7RUFTQyw4QkFBQTtFQUNBLDhDQUFBO0VBQ0EseURBQUE7RUFBQSxpREFBQTtBRCtIRDs7QUMzSEM7RUFDQyx1REFBQTtFQUNBLHlDQUFBO0VBQ0EsNEJBQUE7QUQ4SEY7O0FDM0hDO0VBQ0Msa0RBQUE7QUQ2SEY7O0FDNUdBO0VBQ0M7SUFFQyxrQ0FBQTtJQUNBLG1CQUFBO0VEMEhBO0VDdkhEO0lBRUMsd0JBQUE7RUR5SEE7QUFDRjs7QUN0SEE7RUFFQyw0QkFBQTtBRHdIRDs7QUNySEE7RUFFQyx3QkFBQTtFQUVBLHdCQUFBO0VBRUEseUJBQUE7QUR3SEQ7O0FBNStCQTtFQUNJLHFCQUFBO0FBKytCSjs7QUE1K0JBO0VBQ0ksb0JBQUE7QUErK0JKOztBQTMrQlE7RUFDSSxxQkFBQTtFQUNBLGVBQUE7QUE2K0JaOztBQTMrQlk7RUFDSSxxQkFBQTtBQTYrQmhCOztBQTErQlk7RUFDSSxhQUFBO0VBQ0EsOEJBQUE7RUFDQSwrQ0RTTTtFQ1JOLFdBQUE7RUFDQSwyQkFBQTtFQUNBLHlEQUFBO0VBQ0Esa0JBQUE7QUE0K0JoQjs7QUExK0JnQjtFQUNJLG1DQUFBO0FBNCtCcEI7O0FBcitCUTtFQUNJLGFBQUE7RUFDQSw4QkFBQTtBQXUrQlo7O0FBcitCWTtFQUNJLGtCQUFBO0VBQ0EsV0FBQTtBQXUrQmhCOztBQXIrQmdCO0VBQ0kscUJBQUE7QUF1K0JwQjs7QUFwK0JnQjtFQUNJLGFBQUE7RUFDQSw4QkFBQTtFQUNBLCtDRHBCRTtFQ3FCRixXQUFBO0VBQ0Esb0JBQUE7RUFDQSx5REFBQTtFQUNBLGtCQUFBO0FBcytCcEI7O0FBcCtCb0I7RUFDSSxtQ0Q3Qkg7QUNtZ0NyQjs7QUFoK0JZO0VBQ0ksV0FBQTtBQWsrQmhCOztBQWgrQmdCO0VBQ0kscUJBQUE7QUFrK0JwQjs7QUEvOUJnQjtFQUNJLCtDRHpDRTtFQzBDRixXQUFBO0VBQ0Esb0JBQUE7RUFDQSx5REFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7QUFpK0JwQjs7QUEvOUJvQjtFQUNJLG1DRG5ESDtBQ29oQ3JCOztBQXo5QkE7RUFDSSw4Q0FBQTtBQTQ5QkoiLCJmaWxlIjoiY2xhaW0tZGV0YWlscy5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIjpyb290IHtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTUwOiAjZjFlZmVmO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi13aGl0ZTogI2ZmZmZmZjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZTogIzBkMTUyZTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW46ICMwMDkwOGQ7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWJsYWNrOiAjMDAwMDAwO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ncmV5LWJhY2tncm91bmQ6ICNjOGQzZGE7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWdyZXk6ICM5MmEyYWM7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0b25lLWdyZXk6ICNmYWZhZmE7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWVycm9yOiAjZmMxMDU1O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXk6ICM0MTQxNDE7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWZpYnJhbnQtZ3JlZW46ICMwMGJhYjY7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXdhcm5pbmc6ICNmZmQwNDg7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuLWJhY2tncm91bmQ6ICNlNmYyZjI7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS00MDA6ICM3YTdhN2E7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS0xMDA6ICNlZmYzZjU7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy1lcnJvcjogI2JhMGMzZjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yLWJhY2tncm91bmQ6ICNmZmVmZjQ7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy13YXJuaW5nOiAjY2JhMTI3O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtd2FybmluZy1iYWNrZ3JvdW5kOiAjZmZmOGU2O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlLTEwMDogI2RmZWZmMjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tZXJyb3ItcmVkLTcwMDogI2Y2MjQ1OTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZS01MDA6ICMwMDYxOTI7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWJsdWUtNDAwOiAjNzljZGVjO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1yZWQtNTAwOiAjZmY2NTkyO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zZWNvbmRhcnktYmx1ZS0zMDA6ICMxM2EwZDM7XHJcblxyXG5cdC0tbHVtaS13aGl0ZS1jb2xvcjogI2ZmZmZmZjtcclxuXHQtLWx1bWktcHJpbWFyeS15ZWxsb3ctY29sb3I6ICNmYWI2MDA7XHJcbn1cclxuJGNvbG9yLW5leHRnZW4tYmx1ZTogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlKTtcclxuJGNvbG9yLW5leHRnZW4tZ3JlZW46IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4pO1xyXG4kY29sb3ItbmV4dGdlbi13aGl0ZTogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi13aGl0ZSk7XHJcbiRjb2xvci1uZXh0Z2VuLWJsYWNrOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWJsYWNrKTtcclxuJGNvbG9yLW5leHRnZW4tZ3JleS1iYWNrZ3JvdW5kOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZXktYmFja2dyb3VuZCk7XHJcbiRjb2xvci1uZXh0Z2VuLWdyZXk6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JleSk7XHJcbiRjb2xvci1uZXh0Z2VuLXN0b25lLWdyZXk6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tc3RvbmUtZ3JleSk7XHJcbiRjb2xvci1uZXh0Z2VuLWVycm9yOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWVycm9yKTtcclxuJGNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5OiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleSk7XHJcbiRjb2xvci1uZXh0Z2VuLWZpYnJhbnQtZ3JlZW46IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZmlicmFudC1ncmVlbik7XHJcbiRjb2xvci1uZXh0Z2VuLXdhcm5pbmc6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4td2FybmluZyk7XHJcbiRjb2xvci1uZXh0Z2VuLWdyZWVuLWJhY2tncm91bmQ6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4tYmFja2dyb3VuZCk7XHJcbiRjb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS01MDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNTApO1xyXG4kY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNDAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS00MDApO1xyXG4kY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktMTAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS0xMDApO1xyXG4kY29sb3ItbmV4dGdlbi1zdGF0dXMtZXJyb3I6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yKTtcclxuJGNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yLWJhY2tncm91bmQ6IHZhcihcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yLWJhY2tncm91bmRcclxuKTtcclxuJGNvbG9yLW5leHRnZW4tc3RhdHVzLXdhcm5pbmc6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLXdhcm5pbmcpO1xyXG4kY29sb3ItbmV4dGdlbi1zdGF0dXMtd2FybmluZy1iYWNrZ3JvdW5kOiB2YXIoXHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy13YXJuaW5nLWJhY2tncm91bmRcclxuKTtcclxuJGNvbG9yLW5leHRnZW4tYmx1ZS0xMDA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZS0xMDApO1xyXG4kY29sb3ItbmV4dGdlbi1lcnJvci1yZWQtNzAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWVycm9yLXJlZC03MDApO1xyXG4kY29sb3ItbmV4dGdlbi1ibHVlLTUwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlLTUwMCk7XHJcbiRjb2xvci1uZXh0Z2VuLWJsdWUtNDAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWJsdWUtNDAwKTtcclxuJGNvbG9yLW5leHRnZW4tcmVkLTUwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1yZWQtNTAwKTtcclxuJGNvbG9yLW5leHRnZW4tc2Vjb25kYXJ5LWJsdWUtMzAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXNlY29uZGFyeS1ibHVlLTMwMCk7XHJcblxyXG4uaW9uLWNvbG9yLWdyZWVuIHtcclxuXHQtLWlvbi1jb2xvci1iYXNlOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuKTtcclxuXHQtLWlvbi1jb2xvci1iYXNlLXJnYjogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbik7XHJcblx0LS1pb24tY29sb3ItY29udHJhc3Q6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4td2hpdGUpO1xyXG5cdC0taW9uLWNvbG9yLWNvbnRyYXN0LXJnYjogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbik7XHJcblx0LS1pb24tY29sb3Itc2hhZGU6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4pO1xyXG5cdC0taW9uLWNvbG9yLXRpbnQ6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4pO1xyXG59XHJcbiIsIkBpbXBvcnQgXCIuLi8uLi8uLi8uLi9jb2xvci5zY3NzXCI7XHJcbkBpbXBvcnQgXCIuLi8uLi8uLi8uLi9zdHlsZS5zY3NzXCI7XHJcblxyXG5pb24tY29udGVudCB7XHJcbiAgICAtLWJhY2tncm91bmQ6ICNGMUVGRUY7XHJcbn1cclxuXHJcbi5jbGFpbS1kZXRhaWxzLW1haW4ge1xyXG4gICAgbWFyZ2luLWJvdHRvbTogMTI4cHg7XHJcbiAgICAuY2xhaW0tZGV0YWlscy10aXRsZSB7fVxyXG5cclxuICAgIC5jbGFpbS1kZXRhaWxzLWNvbnRlbnQge1xyXG4gICAgICAgIC5kZXRhaWwtY29udGVudCB7XHJcbiAgICAgICAgICAgIG1hcmdpbi1ib3R0b206IDEuOXJlbTtcclxuICAgICAgICAgICAgY3Vyc29yOiBwb2ludGVyO1xyXG5cclxuICAgICAgICAgICAgLmRldGFpbC10aXRsZSB7XHJcbiAgICAgICAgICAgICAgICBtYXJnaW4tYm90dG9tOiAwLjJyZW07XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIGJ1dHRvbiB7XHJcbiAgICAgICAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICAgICAgICAgICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xyXG4gICAgICAgICAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogJGNvbG9yLW5leHRnZW4td2hpdGUgO1xyXG4gICAgICAgICAgICAgICAgd2lkdGg6IDEwMCU7XHJcbiAgICAgICAgICAgICAgICBwYWRkaW5nOiAxOHB4IDhweCAxOHB4IDE1cHg7XHJcbiAgICAgICAgICAgICAgICBib3JkZXI6IDFweCBzb2xpZCAkY29sb3ItbmV4dGdlbi1ncmV5LWJhY2tncm91bmQ7XHJcbiAgICAgICAgICAgICAgICBib3JkZXItcmFkaXVzOiA4cHg7XHJcblxyXG4gICAgICAgICAgICAgICAgc3BhbiB7XHJcbiAgICAgICAgICAgICAgICAgICAgY29sb3I6ICRjb2xvci1uZXh0Z2VuLWJsdWUgO1xyXG4gICAgICAgICAgICAgICAgfVxyXG5cclxuXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC5jdXJyZW5jeS1jb250ZW50IHtcclxuICAgICAgICAgICAgZGlzcGxheTogZmxleDtcclxuICAgICAgICAgICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xyXG5cclxuICAgICAgICAgICAgLmN1cnJlbmN5IHtcclxuICAgICAgICAgICAgICAgIG1hcmdpbi1yaWdodDogMTR2dztcclxuICAgICAgICAgICAgICAgIHdpZHRoOiAxMDAlO1xyXG5cclxuICAgICAgICAgICAgICAgIC5kZXRhaWwtdGl0bGUge1xyXG4gICAgICAgICAgICAgICAgICAgIG1hcmdpbi1ib3R0b206IDAuMnJlbTtcclxuICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICBidXR0b24ge1xyXG4gICAgICAgICAgICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICAgICAgICAgICAgICAgICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xyXG4gICAgICAgICAgICAgICAgICAgIGJhY2tncm91bmQtY29sb3I6ICRjb2xvci1uZXh0Z2VuLXdoaXRlIDtcclxuICAgICAgICAgICAgICAgICAgICB3aWR0aDogMTAwJTtcclxuICAgICAgICAgICAgICAgICAgICBwYWRkaW5nOiAxLjFyZW0gMXJlbTtcclxuICAgICAgICAgICAgICAgICAgICBib3JkZXI6IDFweCBzb2xpZCAkY29sb3ItbmV4dGdlbi1ncmV5LWJhY2tncm91bmQ7XHJcbiAgICAgICAgICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogOHB4O1xyXG5cclxuICAgICAgICAgICAgICAgICAgICBzcGFuIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I6ICRjb2xvci1uZXh0Z2VuLWJsdWUgO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIC5hbW91bnQge1xyXG4gICAgICAgICAgICAgICAgd2lkdGg6IDEwMCU7XHJcblxyXG4gICAgICAgICAgICAgICAgLmRldGFpbC10aXRsZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgbWFyZ2luLWJvdHRvbTogMC4ycmVtO1xyXG4gICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgIGlvbi1jYXJkIHtcclxuICAgICAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiAkY29sb3ItbmV4dGdlbi13aGl0ZSA7XHJcbiAgICAgICAgICAgICAgICAgICAgd2lkdGg6IDEwMCU7XHJcbiAgICAgICAgICAgICAgICAgICAgcGFkZGluZzogMS4xcmVtIDFyZW07XHJcbiAgICAgICAgICAgICAgICAgICAgYm9yZGVyOiAxcHggc29saWQgJGNvbG9yLW5leHRnZW4tZ3JleS1iYWNrZ3JvdW5kO1xyXG4gICAgICAgICAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDhweDtcclxuICAgICAgICAgICAgICAgICAgICBib3gtc2hhZG93OiBub25lO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICBzcGFuIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I6ICRjb2xvci1uZXh0Z2VuLWJsdWUgO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG5cclxuLmFub3RoZXItcGxhY2Vob2xkIHtcclxuICAgIGNvbG9yOiAkY29sb3ItbmV4dGdlbi1ncmV5ICAhaW1wb3J0YW50O1xyXG59IiwiLypcclxuICogMS4gQ3VzdG9tIENTUyBcclxuICogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG4gKi9cclxuXHJcbi8vIGNvbG9yIHZhcmlhYmxlXHJcbkBpbXBvcnQgXCIuL2NvbG9yLnNjc3NcIjtcclxuLy8gdHlwb2dyYXBoeVxyXG5AaW1wb3J0IFwiLi9mb250LXNpemUuc2Nzc1wiO1xyXG5cclxuLy8gRm9udHNcclxuQGZvbnQtZmFjZSB7XHJcblx0Zm9udC1mYW1pbHk6IFwiQWxsaWFueiBOZW9cIjtcclxuXHRmb250LXN0eWxlOiBub3JtYWw7XHJcblx0Zm9udC13ZWlnaHQ6IDMwMDtcclxuXHRmb250LWRpc3BsYXk6IHN3YXA7XHJcblx0c3JjOiB1cmwoXCIuL2Fzc2V0cy9mb250cy9BbGxpYW56TmVvL0FsbGlhbnpfTmVvX3dlYmZvbnRzL3dvZmYyL0FsbGlhbnpOZW9XMDQtTGlnaHQud29mZjJcIilcclxuXHRcdFx0Zm9ybWF0KFwid29mZjJcIiksXHJcblx0XHR1cmwoXCIuL2Fzc2V0cy9mb250cy9BbGxpYW56TmVvL0FsbGlhbnpfTmVvX3dlYmZvbnRzL3dvZmYvQWxsaWFuek5lb1cwNC1MaWdodC53b2ZmXCIpXHJcblx0XHRcdGZvcm1hdChcIndvZmZcIik7XHJcbn1cclxuXHJcbkBmb250LWZhY2Uge1xyXG5cdGZvbnQtZmFtaWx5OiBcIkFsbGlhbnogTmVvXCI7XHJcblx0Zm9udC1zdHlsZTogaXRhbGljO1xyXG5cdGZvbnQtd2VpZ2h0OiAzMDA7XHJcblx0Zm9udC1kaXNwbGF5OiBzd2FwO1xyXG5cdHNyYzogdXJsKFwiLi9hc3NldHMvZm9udHMvQWxsaWFuek5lby9BbGxpYW56X05lb193ZWJmb250cy93b2ZmMi9BbGxpYW56TmVvVzA0LUxpZ2h0SXRhbGljLndvZmYyXCIpXHJcblx0XHRcdGZvcm1hdChcIndvZmYyXCIpLFxyXG5cdFx0dXJsKFwiLi9hc3NldHMvZm9udHMvQWxsaWFuek5lby9BbGxpYW56X05lb193ZWJmb250cy93b2ZmL0FsbGlhbnpOZW9XMDQtTGlnaHRJdGFsaWMud29mZlwiKVxyXG5cdFx0XHRmb3JtYXQoXCJ3b2ZmXCIpO1xyXG59XHJcblxyXG5AZm9udC1mYWNlIHtcclxuXHRmb250LWZhbWlseTogXCJBbGxpYW56IE5lb1wiO1xyXG5cdGZvbnQtc3R5bGU6IG5vcm1hbDtcclxuXHRmb250LXdlaWdodDogNDAwO1xyXG5cdGZvbnQtZGlzcGxheTogc3dhcDtcclxuXHRzcmM6IHVybChcIi4vYXNzZXRzL2ZvbnRzL0FsbGlhbnpOZW8vQWxsaWFuel9OZW9fd2ViZm9udHMvd29mZjIvQWxsaWFuek5lb1cwNC1SZWd1bGFyLndvZmYyXCIpXHJcblx0XHRcdGZvcm1hdChcIndvZmYyXCIpLFxyXG5cdFx0dXJsKFwiLi9hc3NldHMvZm9udHMvQWxsaWFuek5lby9BbGxpYW56X05lb193ZWJmb250cy93b2ZmL0FsbGlhbnpOZW9XMDQtUmVndWxhci53b2ZmXCIpXHJcblx0XHRcdGZvcm1hdChcIndvZmZcIik7XHJcbn1cclxuXHJcbkBmb250LWZhY2Uge1xyXG5cdGZvbnQtZmFtaWx5OiBcIkFsbGlhbnogTmVvXCI7XHJcblx0Zm9udC1zdHlsZTogaXRhbGljO1xyXG5cdGZvbnQtd2VpZ2h0OiA0MDA7XHJcblx0Zm9udC1kaXNwbGF5OiBzd2FwO1xyXG5cdHNyYzogdXJsKFwiLi9hc3NldHMvZm9udHMvQWxsaWFuek5lby9BbGxpYW56X05lb193ZWJmb250cy93b2ZmMi9BbGxpYW56TmVvVzA0LUl0YWxpYy53b2ZmMlwiKVxyXG5cdFx0XHRmb3JtYXQoXCJ3b2ZmMlwiKSxcclxuXHRcdHVybChcIi4vYXNzZXRzL2ZvbnRzL0FsbGlhbnpOZW8vQWxsaWFuel9OZW9fd2ViZm9udHMvd29mZi9BbGxpYW56TmVvVzA0LUl0YWxpYy53b2ZmXCIpXHJcblx0XHRcdGZvcm1hdChcIndvZmZcIik7XHJcbn1cclxuXHJcbkBmb250LWZhY2Uge1xyXG5cdGZvbnQtZmFtaWx5OiBcIkFsbGlhbnogTmVvXCI7XHJcblx0Zm9udC1zdHlsZTogbm9ybWFsO1xyXG5cdGZvbnQtd2VpZ2h0OiA2MDA7XHJcblx0Zm9udC1kaXNwbGF5OiBzd2FwO1xyXG5cdHNyYzogdXJsKFwiLi9hc3NldHMvZm9udHMvQWxsaWFuek5lby9BbGxpYW56X05lb193ZWJmb250cy93b2ZmMi9BbGxpYW56TmVvVzA0LVNlbWlCb2xkLndvZmYyXCIpXHJcblx0XHRcdGZvcm1hdChcIndvZmYyXCIpLFxyXG5cdFx0dXJsKFwiLi9hc3NldHMvZm9udHMvQWxsaWFuek5lby9BbGxpYW56X05lb193ZWJmb250cy93b2ZmL0FsbGlhbnpOZW9XMDQtU2VtaUJvbGQud29mZlwiKVxyXG5cdFx0XHRmb3JtYXQoXCJ3b2ZmXCIpO1xyXG59XHJcblxyXG5AZm9udC1mYWNlIHtcclxuXHRmb250LWZhbWlseTogXCJBbGxpYW56IE5lb1wiO1xyXG5cdGZvbnQtc3R5bGU6IGl0YWxpYztcclxuXHRmb250LXdlaWdodDogNjAwO1xyXG5cdGZvbnQtZGlzcGxheTogc3dhcDtcclxuXHRzcmM6IHVybChcIi4vYXNzZXRzL2ZvbnRzL0FsbGlhbnpOZW8vQWxsaWFuel9OZW9fd2ViZm9udHMvd29mZjIvQWxsaWFuek5lb1cwNC1TZW1pQm9sZEl0LndvZmYyXCIpXHJcblx0XHRcdGZvcm1hdChcIndvZmYyXCIpLFxyXG5cdFx0dXJsKFwiLi9hc3NldHMvZm9udHMvQWxsaWFuek5lby9BbGxpYW56X05lb193ZWJmb250cy93b2ZmL0FsbGlhbnpOZW9XMDQtU2VtaUJvbGRJdC53b2ZmXCIpXHJcblx0XHRcdGZvcm1hdChcIndvZmZcIik7XHJcbn1cclxuXHJcbkBmb250LWZhY2Uge1xyXG5cdGZvbnQtZmFtaWx5OiBcIkFsbGlhbnogTmVvXCI7XHJcblx0Zm9udC1zdHlsZTogbm9ybWFsO1xyXG5cdGZvbnQtd2VpZ2h0OiA3MDA7XHJcblx0Zm9udC1kaXNwbGF5OiBzd2FwO1xyXG5cdHNyYzogdXJsKFwiLi9hc3NldHMvZm9udHMvQWxsaWFuek5lby9BbGxpYW56X05lb193ZWJmb250cy93b2ZmMi9BbGxpYW56TmVvVzA0LUJvbGQud29mZjJcIilcclxuXHRcdFx0Zm9ybWF0KFwid29mZjJcIiksXHJcblx0XHR1cmwoXCIuL2Fzc2V0cy9mb250cy9BbGxpYW56TmVvL0FsbGlhbnpfTmVvX3dlYmZvbnRzL3dvZmYvQWxsaWFuek5lb1cwNC1Cb2xkLndvZmZcIilcclxuXHRcdFx0Zm9ybWF0KFwid29mZlwiKTtcclxufVxyXG5cclxuQGZvbnQtZmFjZSB7XHJcblx0Zm9udC1mYW1pbHk6IFwiQWxsaWFueiBOZW9cIjtcclxuXHRmb250LXN0eWxlOiBpdGFsaWM7XHJcblx0Zm9udC13ZWlnaHQ6IDcwMDtcclxuXHRmb250LWRpc3BsYXk6IHN3YXA7XHJcblx0c3JjOiB1cmwoXCIuL2Fzc2V0cy9mb250cy9BbGxpYW56TmVvL0FsbGlhbnpfTmVvX3dlYmZvbnRzL3dvZmYyL0FsbGlhbnpOZW9XMDQtQm9sZEl0YWxpYy53b2ZmMlwiKVxyXG5cdFx0XHRmb3JtYXQoXCJ3b2ZmMlwiKSxcclxuXHRcdHVybChcIi4vYXNzZXRzL2ZvbnRzL0FsbGlhbnpOZW8vQWxsaWFuel9OZW9fd2ViZm9udHMvd29mZi9BbGxpYW56TmVvVzA0LUJvbGRJdGFsaWMud29mZlwiKVxyXG5cdFx0XHRmb3JtYXQoXCJ3b2ZmXCIpO1xyXG59XHJcblxyXG4qIHtcclxuXHRjb2xvcjogJGNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5O1xyXG5cdGZvbnQtZmFtaWx5OiBcIkFsbGlhbnogTmVvXCIsIHNhbnMtc2VyaWY7XHJcblx0Zm9udC13ZWlnaHQ6IDQwMDtcclxuXHRmb250LXNpemU6IDE2cHg7XHJcbn1cclxuXHJcbmh0bWwge1xyXG5cdC0taW9uLXNhZmUtYXJlYS10b3A6IDBweDtcclxufVxyXG5cclxuLmNvbC0xIHtcclxuXHR3aWR0aDogOC4zMyU7XHJcbn1cclxuXHJcbi5jb2wtMiB7XHJcblx0d2lkdGg6IDE2LjY2JTtcclxufVxyXG5cclxuLmNvbC0zIHtcclxuXHR3aWR0aDogMjUlO1xyXG59XHJcblxyXG4uY29sLTQge1xyXG5cdHdpZHRoOiAzMy4zMyU7XHJcbn1cclxuXHJcbi5jb2wtNSB7XHJcblx0d2lkdGg6IDQxLjY2JTtcclxufVxyXG5cclxuLmNvbC02IHtcclxuXHR3aWR0aDogNTAlO1xyXG59XHJcblxyXG4uY29sLTcge1xyXG5cdHdpZHRoOiA1OC4zMyU7XHJcbn1cclxuXHJcbi5jb2wtOCB7XHJcblx0d2lkdGg6IDY2LjY2JTtcclxufVxyXG5cclxuLmNvbC05IHtcclxuXHR3aWR0aDogNzUlO1xyXG59XHJcblxyXG4uY29sLTEwIHtcclxuXHR3aWR0aDogODMuMzMlO1xyXG59XHJcblxyXG4uY29sLTExIHtcclxuXHR3aWR0aDogOTEuNjYlO1xyXG59XHJcblxyXG4uY29sLTEyIHtcclxuXHR3aWR0aDogMTAwJTtcclxufVxyXG5cclxuQG1lZGlhIG9ubHkgc2NyZWVuIGFuZCAobWF4LXdpZHRoOiA1NzZweCkge1xyXG5cdC8qIEZvciB0YWJsZXRzOiAqL1xyXG5cdC5jb2wtc20tMSB7XHJcblx0XHR3aWR0aDogOC4zMyU7XHJcblx0fVxyXG5cclxuXHQuY29sLXNtLTIge1xyXG5cdFx0d2lkdGg6IDE2LjY2JTtcclxuXHR9XHJcblxyXG5cdC5jb2wtc20tMyB7XHJcblx0XHR3aWR0aDogMjUlO1xyXG5cdH1cclxuXHJcblx0LmNvbC1zbS00IHtcclxuXHRcdHdpZHRoOiAzMy4zMyU7XHJcblx0fVxyXG5cclxuXHQuY29sLXNtLTUge1xyXG5cdFx0d2lkdGg6IDQxLjY2JTtcclxuXHR9XHJcblxyXG5cdC5jb2wtc20tNiB7XHJcblx0XHR3aWR0aDogNTAlO1xyXG5cdH1cclxuXHJcblx0LmNvbC1zbS03IHtcclxuXHRcdHdpZHRoOiA1OC4zMyU7XHJcblx0fVxyXG5cclxuXHQuY29sLXNtLTgge1xyXG5cdFx0d2lkdGg6IDY2LjY2JTtcclxuXHR9XHJcblxyXG5cdC5jb2wtc20tOSB7XHJcblx0XHR3aWR0aDogNzUlO1xyXG5cdH1cclxuXHJcblx0LmNvbC1zbS0xMCB7XHJcblx0XHR3aWR0aDogODMuMzMlO1xyXG5cdH1cclxuXHJcblx0LmNvbC1zbS0xMSB7XHJcblx0XHR3aWR0aDogOTEuNjYlO1xyXG5cdH1cclxuXHJcblx0LmNvbC1zbS0xMiB7XHJcblx0XHR3aWR0aDogMTAwJTtcclxuXHR9XHJcbn1cclxuXHJcbkBtZWRpYSBvbmx5IHNjcmVlbiBhbmQgKG1heC13aWR0aDogNzY4cHgpIGFuZCAobWluLXdpZHRoOiA1NzdweCkge1xyXG5cdC8qIEZvciB0YWJsZXRzOiAqL1xyXG5cdC5jb2wtbWQtMSB7XHJcblx0XHR3aWR0aDogOC4zMyU7XHJcblx0fVxyXG5cclxuXHQuY29sLW1kLTIge1xyXG5cdFx0d2lkdGg6IDE2LjY2JTtcclxuXHR9XHJcblxyXG5cdC5jb2wtbWQtMyB7XHJcblx0XHR3aWR0aDogMjUlO1xyXG5cdH1cclxuXHJcblx0LmNvbC1tZC00IHtcclxuXHRcdHdpZHRoOiAzMy4zMyU7XHJcblx0fVxyXG5cclxuXHQuY29sLW1kLTUge1xyXG5cdFx0d2lkdGg6IDQxLjY2JTtcclxuXHR9XHJcblxyXG5cdC5jb2wtbWQtNiB7XHJcblx0XHR3aWR0aDogNTAlO1xyXG5cdH1cclxuXHJcblx0LmNvbC1tZC03IHtcclxuXHRcdHdpZHRoOiA1OC4zMyU7XHJcblx0fVxyXG5cclxuXHQuY29sLW1kLTgge1xyXG5cdFx0d2lkdGg6IDY2LjY2JTtcclxuXHR9XHJcblxyXG5cdC5jb2wtbWQtOSB7XHJcblx0XHR3aWR0aDogNzUlO1xyXG5cdH1cclxuXHJcblx0LmNvbC1tZC0xMCB7XHJcblx0XHR3aWR0aDogODMuMzMlO1xyXG5cdH1cclxuXHJcblx0LmNvbC1tZC0xMSB7XHJcblx0XHR3aWR0aDogOTEuNjYlO1xyXG5cdH1cclxuXHJcblx0LmNvbC1tZC0xMiB7XHJcblx0XHR3aWR0aDogMTAwJTtcclxuXHR9XHJcbn1cclxuXHJcbkBtZWRpYSBvbmx5IHNjcmVlbiBhbmQgKG1pbi13aWR0aDogNzY5cHgpIHtcclxuXHQvKiBGb3IgdGFibGV0czogKi9cclxuXHQuY29sLWxnLTEge1xyXG5cdFx0d2lkdGg6IDguMzMlO1xyXG5cdH1cclxuXHJcblx0LmNvbC1sZy0yIHtcclxuXHRcdHdpZHRoOiAxNi42NiU7XHJcblx0fVxyXG5cclxuXHQuY29sLWxnLTMge1xyXG5cdFx0d2lkdGg6IDI1JTtcclxuXHR9XHJcblxyXG5cdC5jb2wtbGctNCB7XHJcblx0XHR3aWR0aDogMzMuMzMlO1xyXG5cdH1cclxuXHJcblx0LmNvbC1sZy01IHtcclxuXHRcdHdpZHRoOiA0MS42NiU7XHJcblx0fVxyXG5cclxuXHQuY29sLWxnLTYge1xyXG5cdFx0d2lkdGg6IDUwJTtcclxuXHR9XHJcblxyXG5cdC5jb2wtbGctNyB7XHJcblx0XHR3aWR0aDogNTguMzMlO1xyXG5cdH1cclxuXHJcblx0LmNvbC1sZy04IHtcclxuXHRcdHdpZHRoOiA2Ni42NiU7XHJcblx0fVxyXG5cclxuXHQuY29sLWxnLTkge1xyXG5cdFx0d2lkdGg6IDc1JTtcclxuXHR9XHJcblxyXG5cdC5jb2wtbGctMTAge1xyXG5cdFx0d2lkdGg6IDgzLjMzJTtcclxuXHR9XHJcblxyXG5cdC5jb2wtbGctMTEge1xyXG5cdFx0d2lkdGg6IDkxLjY2JTtcclxuXHR9XHJcblxyXG5cdC5jb2wtbGctMTIge1xyXG5cdFx0d2lkdGg6IDEwMCU7XHJcblx0fVxyXG59XHJcblxyXG4ucm93IHtcclxuXHRkaXNwbGF5OiBmbGV4O1xyXG5cdGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG5cdGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbn1cclxuXHJcbi8vIENTU1xyXG4uY3VzdG9tLXRvYXN0IHtcclxuXHQtLW1heC13aWR0aDogZml0LWNvbnRlbnQ7XHJcbn1cclxuXHJcbi8qXHJcbiAqIDIuIEN1c3RvbSBDU1MgZm9yIGNvbXBhdGliaWxpdHkgd2l0aCBFZGdlXHJcbiAqIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuICovXHJcbmlucHV0OjotbXMtcmV2ZWFsLFxyXG5pbnB1dDo6LW1zLWNsZWFyIHtcclxuXHRkaXNwbGF5OiBub25lO1xyXG59XHJcblxyXG4uc3dhbDItcG9wdXAge1xyXG5cdG1hcmdpbi10b3A6IDIwcHg7XHJcbn1cclxuXHJcbi8qXHJcbiAqIDMuIEN1c3RvbSBDU1MgZm9yIGxvYWRpbmcgY29udHJvbGxlclxyXG4gKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcbiAqL1xyXG4udHJhbnNwYXJlbnQtbG9hZGluZy1jbGFzcyB7XHJcblx0LS1iYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcclxuXHQtLXNwaW5uZXItY29sb3I6ICM0N2U2YjE7XHJcbn1cclxuXHJcbi5sb2FkaW5nLXdyYXBwZXIuc2MtaW9uLWxvYWRpbmctbWQge1xyXG5cdGJveC1zaGFkb3c6IHVuc2V0O1xyXG5cdC13ZWJraXQtYm94LXNoYWRvdzogdW5zZXQ7XHJcbn1cclxuXHJcbi51aWwge1xyXG5cdGNvbG9yOiAkY29sb3ItbmV4dGdlbi1ncmV5O1xyXG59XHJcblxyXG4uYnRuIHtcclxuXHRoZWlnaHQ6IDQ4cHg7XHJcblx0Ym9yZGVyLXJhZGl1czogMjhweDtcclxuXHRwYWRkaW5nOiAwcHggNDFweCAwcHggNDFweDtcclxuXHRib3gtc2hhZG93OiBub25lO1xyXG5cclxuXHQmLmJ0bi1jaXJjbGUge1xyXG5cdFx0YmFja2dyb3VuZC1jb2xvcjogJGNvbG9yLW5leHRnZW4tc3RvbmUtZ3JleSAhaW1wb3J0YW50O1xyXG5cdFx0Y29sb3I6ICRjb2xvci1uZXh0Z2VuLWJsYWNrO1xyXG5cdFx0cGFkZGluZzogdW5zZXQgIWltcG9ydGFudDtcclxuXHRcdGhlaWdodDogMzZweCAhaW1wb3J0YW50O1xyXG5cdFx0d2lkdGg6IDM2cHggIWltcG9ydGFudDtcclxuXHRcdGJvcmRlci1yYWRpdXM6IDUwJSAhaW1wb3J0YW50O1xyXG5cclxuXHRcdGkge1xyXG5cdFx0XHRjb2xvcjogJGNvbG9yLW5leHRnZW4tYmxhY2s7XHJcblx0XHR9XHJcblx0fVxyXG5cclxuXHQmLnByaW1hcnkge1xyXG5cdFx0YmFja2dyb3VuZDogJGNvbG9yLW5leHRnZW4tZ3JlZW47XHJcblx0XHRjb2xvcjogJGNvbG9yLW5leHRnZW4td2hpdGU7XHJcblxyXG5cdFx0LnVpbCB7XHJcblx0XHRcdGNvbG9yOiAkY29sb3ItbmV4dGdlbi13aGl0ZTtcclxuXHRcdH1cclxuXHJcblx0XHQmOmRpc2FibGVkIHtcclxuXHRcdFx0YmFja2dyb3VuZC1jb2xvcjogJGNvbG9yLW5leHRnZW4tZ3JleS1iYWNrZ3JvdW5kICFpbXBvcnRhbnQ7XHJcblx0XHRcdGNvbG9yOiAkY29sb3ItbmV4dGdlbi1ncmV5ICFpbXBvcnRhbnQ7XHJcblx0XHR9XHJcblx0fVxyXG5cclxuXHQmLnNlY29uZGFyeSB7XHJcblx0XHRiYWNrZ3JvdW5kOiAkY29sb3ItbmV4dGdlbi13aGl0ZSAhaW1wb3J0YW50O1xyXG5cdFx0Ym9yZGVyLWNvbG9yOiAkY29sb3ItbmV4dGdlbi1ncmVlbjtcclxuXHRcdGJvcmRlcjogc29saWQgMXB4O1xyXG5cdFx0Y29sb3I6ICRjb2xvci1uZXh0Z2VuLWdyZWVuO1xyXG5cclxuXHRcdC51aWwge1xyXG5cdFx0XHRjb2xvcjogJGNvbG9yLW5leHRnZW4tZ3JlZW47XHJcblx0XHR9XHJcblxyXG5cdFx0JjpkaXNhYmxlZCB7XHJcblx0XHRcdGJhY2tncm91bmQtY29sb3I6ICRjb2xvci1uZXh0Z2VuLXdoaXRlICFpbXBvcnRhbnQ7XHJcblx0XHRcdGNvbG9yOiAkY29sb3ItbmV4dGdlbi1ncmV5ICFpbXBvcnRhbnQ7XHJcblx0XHRcdGJvcmRlci1jb2xvcjogJGNvbG9yLW5leHRnZW4tZ3JleS1iYWNrZ3JvdW5kICFpbXBvcnRhbnQ7XHJcblx0XHR9XHJcblx0fVxyXG5cclxuXHQmLnRyYW5zcGFyZW50IHtcclxuXHRcdGJhY2tncm91bmQ6IHRyYW5zcGFyZW50ICFpbXBvcnRhbnQ7XHJcblx0XHRib3JkZXItY29sb3I6ICRjb2xvci1uZXh0Z2VuLWdyZWVuO1xyXG5cdFx0Ym9yZGVyOiBzb2xpZCAxcHg7XHJcblx0XHRjb2xvcjogJGNvbG9yLW5leHRnZW4tZ3JlZW47XHJcblxyXG5cdFx0LnVpbCB7XHJcblx0XHRcdGNvbG9yOiAkY29sb3ItbmV4dGdlbi1ncmVlbjtcclxuXHRcdH1cclxuXHJcblx0XHQmOmRpc2FibGVkIHtcclxuXHRcdFx0YmFja2dyb3VuZC1jb2xvcjogdHJhbnNwYXJlbnQgIWltcG9ydGFudDtcclxuXHRcdFx0Y29sb3I6ICRjb2xvci1uZXh0Z2VuLWdyZXkgIWltcG9ydGFudDtcclxuXHRcdFx0Ym9yZGVyLWNvbG9yOiAkY29sb3ItbmV4dGdlbi1ncmV5LWJhY2tncm91bmQgIWltcG9ydGFudDtcclxuXHRcdH1cclxuXHR9XHJcblxyXG5cdCYuYnRuLWxhcmdlIHtcclxuXHRcdGhlaWdodDogNTZweCAhaW1wb3J0YW50O1xyXG5cdFx0d2lkdGg6IDEwMCU7XHJcblx0fVxyXG5cclxuXHQmLmJvbGQge1xyXG5cdFx0Zm9udC13ZWlnaHQ6IDcwMCAhaW1wb3J0YW50O1xyXG5cdH1cclxuXHJcblx0Ji5zZW1pYm9sZCB7XHJcblx0XHRmb250LXdlaWdodDogNjAwICFpbXBvcnRhbnQ7XHJcblx0fVxyXG59XHJcblxyXG4uYnRuLW5vLXNwYWNlIHtcclxuXHRwYWRkaW5nOiA1cHggIWltcG9ydGFudDtcclxuXHRoZWlnaHQ6IGZpdC1jb250ZW50O1xyXG59XHJcblxyXG4uYnRuLWJhY2sge1xyXG5cdHdpZHRoOiAzMXB4O1xyXG5cdGhlaWdodDogMjhweDtcclxuXHRiYWNrZ3JvdW5kLWNvbG9yOiB0cmFuc3BhcmVudDtcclxuXHRwYWRkaW5nOiAwO1xyXG5cdGNvbG9yOiAkY29sb3ItbmV4dGdlbi1ncmVlbjtcclxufVxyXG5cclxuLmNvbnRhaW5lciB7XHJcblx0cGFkZGluZzogMnJlbTtcclxuXHRoZWlnaHQ6IDEwMCU7XHJcbn1cclxuXHJcbi5ib2R5LXNlY3Rpb24ge1xyXG5cdHdpZHRoOiAxMDAlO1xyXG5cdGhlaWdodDogOTUlO1xyXG5cdG92ZXJmbG93LXk6IGF1dG87XHJcblx0cG9zaXRpb246IHJlbGF0aXZlO1xyXG59XHJcblxyXG4udG9wLXNlY3Rpb24ge1xyXG5cdHdpZHRoOiAxMDAlO1xyXG5cdGhlaWdodDogMTAlO1xyXG5cdGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcclxuXHRkaXNwbGF5OiBmbGV4O1xyXG5cdGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbn1cclxuXHJcbi5mb3JtLWNvbnRyb2wge1xyXG5cdHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuXHRoZWlnaHQ6IDg1cHg7XHJcblx0bWFyZ2luLWJvdHRvbTogOHB4O1xyXG59XHJcblxyXG4uY29udHJvbCB7XHJcblx0Ym9yZGVyLXJhZGl1czogOHB4O1xyXG5cdGhlaWdodDogNTZweDtcclxuXHRib3JkZXI6IDFweCBzb2xpZCAkY29sb3ItbmV4dGdlbi1ncmV5LWJhY2tncm91bmQ7XHJcblx0d2lkdGg6IDEwMCU7XHJcblx0cG9zaXRpb246IGFic29sdXRlO1xyXG5cdHRvcDogMzJweDtcclxuXHRiYWNrZ3JvdW5kLWNvbG9yOiAkY29sb3ItbmV4dGdlbi13aGl0ZTtcclxuXHJcblx0JiB0YWJsZSB7XHJcblx0XHR0YWJsZS1sYXlvdXQ6IGZpeGVkO1xyXG5cdFx0Ym9yZGVyLWNvbGxhcHNlOiB1bnNldDtcclxuXHR9XHJcblxyXG5cdCYgaW5wdXQge1xyXG5cdFx0aGVpZ2h0OiA1NHB4O1xyXG5cdFx0Ym9yZGVyOiB1bnNldDtcclxuXHRcdGJvcmRlci1yYWRpdXM6IDhweDtcclxuXHRcdHdpZHRoOiBtYXgtY29udGVudDtcclxuXHRcdHdpZHRoOiAxMDAlO1xyXG5cdFx0cG9pbnRlci1ldmVudHM6IGF1dG87XHJcblx0XHRiYWNrZ3JvdW5kLWNvbG9yOiAkY29sb3ItbmV4dGdlbi13aGl0ZTtcclxuXHR9XHJcblxyXG5cdCYudGV4dGFyZWEge1xyXG5cdFx0aGVpZ2h0OiAxMDhweDtcclxuXHR9XHJcblxyXG5cdCYgdGV4dGFyZWEge1xyXG5cdFx0aGVpZ2h0OiAxMDZweDtcclxuXHRcdGJvcmRlcjogdW5zZXQ7XHJcblx0XHRib3JkZXItcmFkaXVzOiA4cHg7XHJcblx0XHR3aWR0aDogbWF4LWNvbnRlbnQ7XHJcblx0XHR3aWR0aDogMTAwJTtcclxuXHRcdHBvaW50ZXItZXZlbnRzOiBhdXRvO1xyXG5cdFx0cmVzaXplOiBub25lO1xyXG5cdFx0YmFja2dyb3VuZC1jb2xvcjogJGNvbG9yLW5leHRnZW4td2hpdGU7XHJcblx0fVxyXG5cclxuXHQmIGlucHV0OmZvY3VzIHtcclxuXHRcdG91dGxpbmU6IG5vbmU7XHJcblx0fVxyXG5cclxuXHQmOmZvY3VzLXdpdGhpbiB7XHJcblx0XHRib3JkZXItY29sb3I6ICRjb2xvci1uZXh0Z2VuLWdyZWVuO1xyXG5cclxuXHRcdC5maXJzdC1pY29uIHtcclxuXHRcdFx0ZGlzcGxheTogbm9uZTtcclxuXHRcdH1cclxuXHJcblx0XHQuZmlyc3QtaWNvbi5ub24taGlkZGVuIHtcclxuXHRcdFx0ZGlzcGxheTogdGFibGUtY2VsbDtcclxuXHRcdH1cclxuXHR9XHJcblxyXG5cdC5maXJzdC1pY29uIHtcclxuXHRcdHdpZHRoOiAzMnB4O1xyXG5cdFx0dGV4dC1hbGlnbjogY2VudGVyO1xyXG5cdFx0cGFkZGluZy1sZWZ0OiA4cHg7XHJcblxyXG5cdFx0aSB7XHJcblx0XHRcdGZvbnQtc2l6ZTogMjRweCAhaW1wb3J0YW50O1xyXG5cdFx0fVxyXG5cdH1cclxuXHJcblx0LnNlY29uZC1pY29uIHtcclxuXHRcdHdpZHRoOiAzMnB4O1xyXG5cdFx0dGV4dC1hbGlnbjogY2VudGVyO1xyXG5cdFx0Ly8gcGFkZGluZy1yaWdodDogOHB4O1xyXG5cclxuXHRcdGkge1xyXG5cdFx0XHRmb250LXNpemU6IDI0cHggIWltcG9ydGFudDtcclxuXHRcdH1cclxuXHR9XHJcbn1cclxuXHJcbi5jb250cm9sOmZvY3VzLXdpdGhpbiB+IGRpdiAuY29udHJvbC1sYWJlbCB7XHJcblx0Y29sb3I6ICRjb2xvci1uZXh0Z2VuLWdyZWVuO1xyXG59XHJcblxyXG4uY29udHJvbC1lcnJvciB7XHJcblx0LmNvbnRyb2wge1xyXG5cdFx0Ym9yZGVyLWNvbG9yOiAkY29sb3ItbmV4dGdlbi1lcnJvcjtcclxuXHR9XHJcblxyXG5cdC5jb250cm9sLWxhYmVsIHtcclxuXHRcdGNvbG9yOiAkY29sb3ItbmV4dGdlbi1lcnJvciAhaW1wb3J0YW50O1xyXG5cdH1cclxufVxyXG5cclxuLnZhbGlkYXRpb24tc3VtbWFyeSB7XHJcblx0bGkge1xyXG5cdFx0Y29sb3I6ICRjb2xvci1uZXh0Z2VuLWVycm9yICFpbXBvcnRhbnQ7XHJcblx0XHRsaXN0LXN0eWxlOiBub25lO1xyXG5cclxuXHRcdGkge1xyXG5cdFx0XHRjb2xvcjogJGNvbG9yLW5leHRnZW4tZXJyb3IgIWltcG9ydGFudDtcclxuXHRcdH1cclxuXHR9XHJcbn1cclxuXHJcbi5tci0xIHtcclxuXHRtYXJnaW4tcmlnaHQ6IDAuNXJlbTtcclxufVxyXG5cclxuLm1iLTEge1xyXG5cdG1hcmdpbi1ib3R0b206IDAuNXJlbTtcclxufVxyXG5cclxuLmRpYWxvZy1wYW5lIHtcclxuXHRwb3NpdGlvbjogYWJzb2x1dGU7XHJcblx0cG9pbnRlci1ldmVudHM6IGF1dG87XHJcblx0Ym94LXNpemluZzogYm9yZGVyLWJveDtcclxuXHR6LWluZGV4OiAxMDAwO1xyXG5cdGRpc3BsYXk6IGJsb2NrO1xyXG5cdG1heC13aWR0aDogMTAwJTtcclxuXHRtYXgtaGVpZ2h0OiAxMDAlO1xyXG59XHJcblxyXG4ub3ZlcmxheS1iYWNrZHJvcCB7XHJcblx0YmFja2dyb3VuZC1jb2xvcjogJGNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5O1xyXG5cdG9wYWNpdHk6IDAuMiAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4uZGlhbG9nLWNvbnRhaW5lciB7XHJcblx0YW5pbWF0aW9uOiBmYWRlSW4gMC41cyBsaW5lYXI7XHJcblx0YmFja2dyb3VuZC1jb2xvcjogJGNvbG9yLW5leHRnZW4td2hpdGU7XHJcbn1cclxuXHJcbkBrZXlmcmFtZXMgZmFkZUluIHtcclxuXHRmcm9tIHtcclxuXHRcdHRyYW5zZm9ybTogdHJhbnNsYXRlWSgxMDAlKTtcclxuXHR9XHJcblxyXG5cdHRvIHtcclxuXHRcdHRyYW5zZm9ybTogdHJhbnNsYXRlWSgwJSk7XHJcblx0fVxyXG59XHJcblxyXG4uZXJyb3Ige1xyXG5cdGNvbG9yOiAkY29sb3ItbmV4dGdlbi1lcnJvcjtcclxuXHJcblx0Ji5iYWNrZ3JvdW5kIHtcclxuXHRcdGJhY2tncm91bmQtY29sb3I6ICRjb2xvci1uZXh0Z2VuLWVycm9yO1xyXG5cdH1cclxufVxyXG5cclxuLnN1Y2Nlc3Mge1xyXG5cdGNvbG9yOiAkY29sb3ItbmV4dGdlbi1maWJyYW50LWdyZWVuO1xyXG5cclxuXHQmLmJhY2tncm91bmQge1xyXG5cdFx0YmFja2dyb3VuZC1jb2xvcjogJGNvbG9yLW5leHRnZW4tZmlicmFudC1ncmVlbjtcclxuXHR9XHJcbn1cclxuXHJcbi53YXJuaW5nIHtcclxuXHRjb2xvcjogJGNvbG9yLW5leHRnZW4td2FybmluZztcclxuXHJcblx0Ji5iYWNrZ3JvdW5kIHtcclxuXHRcdGJhY2tncm91bmQtY29sb3I6ICRjb2xvci1uZXh0Z2VuLXdhcm5pbmc7XHJcblx0fVxyXG59XHJcblxyXG4uc2VsZWN0IHtcclxuXHR3aWR0aDogMTAwJTtcclxuXHRoZWlnaHQ6IDU0cHg7XHJcblx0Ym9yZGVyOiB1bnNldDtcclxuXHRib3JkZXItcmFkaXVzOiA4cHg7XHJcblx0ZGlzcGxheTogZ3JpZDtcclxuXHRhcHBlYXJhbmNlOiBub25lO1xyXG5cdGdyaWQtdGVtcGxhdGUtYXJlYXM6IFwic2VsZWN0XCI7XHJcblxyXG5cdCY6Zm9jdXMge1xyXG5cdFx0b3V0bGluZTogdW5zZXQ7XHJcblx0fVxyXG59XHJcblxyXG4uY29sb3ItYmxhY2sge1xyXG5cdGNvbG9yOiAkY29sb3ItbmV4dGdlbi1ibGFjaztcclxufVxyXG5cclxuLm1vZGFsLWRlZmF1bHQge1xyXG5cdC0td2lkdGg6IDEwMCU7XHJcblx0LS1oZWlnaHQ6IDEwMCU7XHJcbn1cclxuXHJcbi5pbnRlZ3JhdGlvbi1wYW5lbCB7XHJcblx0d2lkdGg6IDEwMCU7XHJcblx0aGVpZ2h0OiAxMDAlO1xyXG5cdG1heC13aWR0aDogMTAwJSAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4udmVybG9vcC1idXR0b24ge1xyXG5cdHZpc2liaWxpdHk6IGhpZGRlbjtcclxufVxyXG5cclxuLmJhY2stYXJlYSB7XHJcblx0cG9zaXRpb246IGZpeGVkO1xyXG5cdHRvcDogMDtcclxuXHRyaWdodDogMDtcclxuXHRoZWlnaHQ6IDUwcHg7XHJcblx0d2lkdGg6IDEwMCU7XHJcblx0YmFja2dyb3VuZC1jb2xvcjogJGNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTUwO1xyXG5cdHotaW5kZXg6IDk5OTk5OTk7XHJcblxyXG5cdCYuaW9zIHtcclxuXHRcdGhlaWdodDogODBweDtcclxuXHR9XHJcbn1cclxuXHJcbi50aXRsZS13aWRnZXQge1xyXG5cdHRleHQtYWxpZ246IGNlbnRlcjtcclxuXHRwb3NpdGlvbjogc3RpY2t5O1xyXG5cdHRvcDogNDhweDtcclxufVxyXG5cclxuLmJ1dHRvbi1iYWNrIHtcclxuXHRiYWNrZ3JvdW5kLWNvbG9yOiAjZmFmYWZhO1xyXG5cdGhlaWdodDogMzZweDtcclxuXHR3aWR0aDogMzZweDtcclxuXHRib3JkZXItcmFkaXVzOiA1MCU7XHJcblx0cG9zaXRpb246IGFic29sdXRlO1xyXG5cdGxlZnQ6IDE4cHg7XHJcblx0Ym90dG9tOiA0cHg7XHJcbn1cclxuXHJcbi5pY29uLWNsb3NlLXdpZGdldCB7XHJcblx0cG9zaXRpb246IGFic29sdXRlO1xyXG5cdHotaW5kZXg6IDI1MDtcclxuXHRsZWZ0OiAxMXB4O1xyXG5cdGJvdHRvbTogMTNweDtcclxufVxyXG5cclxuLmRhdGEtZGVmYXVsdCB7XHJcblx0cG9zaXRpb246IGFic29sdXRlO1xyXG5cdHRvcDogNTAlO1xyXG5cdGxlZnQ6IDUwJTtcclxuXHR0cmFuc2Zvcm06IHRyYW5zbGF0ZSgtNTAlLCAtNTAlKTtcclxuXHR0ZXh0LWFsaWduOiBjZW50ZXI7XHJcblx0Y29sb3I6ICRjb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS00MDA7XHJcblx0ei1pbmRleDogMTAwMDtcclxufVxyXG5cclxuLmF2YWFtb19faWNvbiB7XHJcblx0dmlzaWJpbGl0eTogaGlkZGVuICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5hdmFhbW9fX2NoYXRfX3dpZGdldC5pb3Mge1xyXG5cdCNhdmFhbW9fX3BvcHVwIHtcclxuXHRcdHBhZGRpbmctdG9wOiA0MHB4O1xyXG5cdH1cclxufVxyXG5cclxuLmQtZmxleCB7XHJcblx0ZGlzcGxheTogZmxleDtcclxufVxyXG5cclxubmV4dGNhcmUtbGF5b3V0IHtcclxuXHRsZWZ0OiAwO1xyXG5cdHJpZ2h0OiAwO1xyXG5cdHRvcDogMDtcclxuXHRib3R0b206IDA7XHJcblx0ZGlzcGxheTogZmxleDtcclxuXHRwb3NpdGlvbjogYWJzb2x1dGU7XHJcblx0ZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxuXHRqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XHJcblx0Y29udGFpbjogbGF5b3V0IHNpemUgc3R5bGU7XHJcblx0b3ZlcmZsb3c6IGhpZGRlbjtcclxuXHRiYWNrZ3JvdW5kLWNvbG9yOiAkY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNTA7XHJcblx0cGFkZGluZy1yaWdodDogMjRweDtcclxuXHRwYWRkaW5nLWxlZnQ6IDI0cHg7XHJcbn1cclxuXHJcbmlvbi1oZWFkZXIuaW9zLmhlYWRlci1pb3Mge1xyXG5cdG1hcmdpbi10b3A6IDQwcHg7XHJcbn1cclxuXHJcbi5oZWFkZXItaW9zIGlvbi10b29sYmFyOmxhc3Qtb2YtdHlwZSB7XHJcblx0LS1ib3JkZXItd2lkdGg6IDBweCAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4uaGVhZGVyLW1kLm1kOjphZnRlciB7XHJcblx0ZGlzcGxheTogbm9uZTtcclxufVxyXG5cclxuaW9uLXRvb2xiYXIge1xyXG5cdHBhZGRpbmctcmlnaHQ6IHVuc2V0ICFpbXBvcnRhbnQ7XHJcblx0cGFkZGluZy1sZWZ0OiB1bnNldCAhaW1wb3J0YW50O1xyXG59XHJcblxyXG5pLmljb24tYmFjayB7XHJcblx0Y29udGVudDogdXJsKGFzc2V0cy9pY29uL2xvbmctYXJyb3ctbGVmdC1pY29uLnN2Zyk7XHJcbn1cclxuXHJcbi52ZXJsb29wLXdpZGdldC5pb3Mge1xyXG5cdC52ZXJsb29wLWNvbnRhaW5lci52aXNpYmxlIHtcclxuXHRcdGhlaWdodDogY2FsYygxMDAlIC0gNDBweCk7XHJcblx0XHR0b3A6IDQwcHg7XHJcblx0fVxyXG59XHJcblxyXG4jbmV4dGNhcmUtYWRzIHtcclxuXHRkaXNwbGF5OiBub25lO1xyXG5cdG92ZXJmbG93OiBzY3JvbGw7XHJcblx0aGVpZ2h0OiAxODBweDtcclxufVxyXG5cclxuLmQtYmxvY2sge1xyXG5cdGRpc3BsYXk6IGJsb2NrO1xyXG59XHJcblxyXG4udGl0bGUtdGV4dCB7XHJcblx0Y29sb3I6ICRjb2xvci1uZXh0Z2VuLWJsdWU7XHJcbn1cclxuXHJcbjpob3N0IGlvbi1kYXRldGltZSAjc2hhZG93LXJvb3Qge1xyXG5cdC5kYXRldGltZS1jYWxlbmRhciB7XHJcblx0XHQuY2FsZW5kYXItaGVhZGVyIHtcclxuXHRcdFx0LmNhbGVuZGFyLWFjdGlvbi1idXR0b25zIHtcclxuXHRcdFx0XHQuY2FsZW5kYXItbW9udGgteWVhciB7XHJcblx0XHRcdFx0XHRhbGlnbi1pdGVtczogY2VudGVyO1xyXG5cdFx0XHRcdFx0anVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcblx0XHRcdFx0XHRkaXNwbGF5OiBmbGV4O1xyXG5cdFx0XHRcdFx0d2lkdGg6IDEwMCU7XHJcblxyXG5cdFx0XHRcdFx0aW9uLWljb24ge1xyXG5cdFx0XHRcdFx0XHRkaXNwbGF5OiBub25lO1xyXG5cdFx0XHRcdFx0fVxyXG5cdFx0XHRcdH1cclxuXHJcblx0XHRcdFx0LmNhbGVuZGFyLW5leHQtcHJldiB7XHJcblx0XHRcdFx0XHRwb3NpdGlvbjogYWJzb2x1dGU7XHJcblx0XHRcdFx0XHR3aWR0aDogMTAwJTtcclxuXHRcdFx0XHRcdHJpZ2h0OiAwO1xyXG5cclxuXHRcdFx0XHRcdGlvbi1idXR0b25zIHtcclxuXHRcdFx0XHRcdFx0ZGlzcGxheTogZmxleDtcclxuXHRcdFx0XHRcdFx0anVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xyXG5cdFx0XHRcdFx0XHR3aWR0aDogMTAwJTtcclxuXHRcdFx0XHRcdH1cclxuXHRcdFx0XHR9XHJcblx0XHRcdH1cclxuXHRcdH1cclxuXHR9XHJcbn1cclxuXHJcbi5tYXQtZGlhbG9nLWNvbnRhaW5lciB7XHJcblx0cGFkZGluZzogdW5zZXQgIWltcG9ydGFudDtcclxufVxyXG5cclxuLyogQ2hhbmdlIGF1dG9jb21wbGV0ZSBzdHlsZXMgaW4gV2ViS2l0ICovXHJcbmlucHV0Oi13ZWJraXQtYXV0b2ZpbGwsXHJcbmlucHV0Oi13ZWJraXQtYXV0b2ZpbGw6aG92ZXIsXHJcbmlucHV0Oi13ZWJraXQtYXV0b2ZpbGw6Zm9jdXMsXHJcbnRleHRhcmVhOi13ZWJraXQtYXV0b2ZpbGwsXHJcbnRleHRhcmVhOi13ZWJraXQtYXV0b2ZpbGw6aG92ZXIsXHJcbnRleHRhcmVhOi13ZWJraXQtYXV0b2ZpbGw6Zm9jdXMsXHJcbnNlbGVjdDotd2Via2l0LWF1dG9maWxsLFxyXG5zZWxlY3Q6LXdlYmtpdC1hdXRvZmlsbDpob3Zlcixcclxuc2VsZWN0Oi13ZWJraXQtYXV0b2ZpbGw6Zm9jdXMge1xyXG5cdC13ZWJraXQtdGV4dC1maWxsLWNvbG9yOiBibGFjaztcclxuXHQtd2Via2l0LWJveC1zaGFkb3c6IDAgMCAwcHggMTAwMHB4IHdoaXRlIGluc2V0O1xyXG5cdHRyYW5zaXRpb246IGJhY2tncm91bmQtY29sb3IgNTAwMHMgZWFzZS1pbi1vdXQgMHM7XHJcbn1cclxuXHJcbi5mb3JjZS11cGRhdGUtcG9wdXAgKyAuY2RrLWdsb2JhbC1vdmVybGF5LXdyYXBwZXIge1xyXG5cdC5zYXZlLWJ0biB7XHJcblx0XHRiYWNrZ3JvdW5kOiB2YXIoLS1sdW1pLXByaW1hcnkteWVsbG93LWNvbG9yKSAhaW1wb3J0YW50O1xyXG5cdFx0Y29sb3I6IHZhcigtLWx1bWktd2hpdGUtY29sb3IpICFpbXBvcnRhbnQ7XHJcblx0XHRmb250LXdlaWdodDogYm9sZCAhaW1wb3J0YW50O1xyXG5cdH1cclxuXHJcblx0LmNhbmNlbC1idG4ge1xyXG5cdFx0Y29sb3I6IHZhcigtLWx1bWktcHJpbWFyeS15ZWxsb3ctY29sb3IpICFpbXBvcnRhbnQ7XHJcblx0fVxyXG59XHJcblxyXG5ALXdlYmtpdC1rZXlmcmFtZXMgc2xpZGVJblJpZ2h0IHtcclxuXHQwJSB7XHJcblx0XHQtd2Via2l0LXRyYW5zZm9ybTogdHJhbnNsYXRlM2QoMTAwJSwgMCwgMCk7XHJcblx0XHR0cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKDEwMCUsIDAsIDApO1xyXG5cdFx0dmlzaWJpbGl0eTogdmlzaWJsZTtcclxuXHR9XHJcblxyXG5cdHRvIHtcclxuXHRcdC13ZWJraXQtdHJhbnNmb3JtOiB0cmFuc2xhdGVaKDApO1xyXG5cdFx0dHJhbnNmb3JtOiB0cmFuc2xhdGVaKDApO1xyXG5cdH1cclxufVxyXG5cclxuQGtleWZyYW1lcyBzbGlkZUluUmlnaHQge1xyXG5cdDAlIHtcclxuXHRcdC13ZWJraXQtdHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgxMDAlLCAwLCAwKTtcclxuXHRcdHRyYW5zZm9ybTogdHJhbnNsYXRlM2QoMTAwJSwgMCwgMCk7XHJcblx0XHR2aXNpYmlsaXR5OiB2aXNpYmxlO1xyXG5cdH1cclxuXHJcblx0dG8ge1xyXG5cdFx0LXdlYmtpdC10cmFuc2Zvcm06IHRyYW5zbGF0ZVooMCk7XHJcblx0XHR0cmFuc2Zvcm06IHRyYW5zbGF0ZVooMCk7XHJcblx0fVxyXG59XHJcblxyXG4uYW5pbWF0ZV9fc2xpZGVJblJpZ2h0IHtcclxuXHQtd2Via2l0LWFuaW1hdGlvbi1uYW1lOiBzbGlkZUluUmlnaHQ7XHJcblx0YW5pbWF0aW9uLW5hbWU6IHNsaWRlSW5SaWdodDtcclxufVxyXG5cclxuLmFuaW1hdGVfX2FuaW1hdGVkIHtcclxuXHQtd2Via2l0LWFuaW1hdGlvbi1kdXJhdGlvbjogMC41cztcclxuXHRhbmltYXRpb24tZHVyYXRpb246IDAuNXM7XHJcblx0LXdlYmtpdC1hbmltYXRpb24tZHVyYXRpb246IDAuNXM7XHJcblx0YW5pbWF0aW9uLWR1cmF0aW9uOiAwLjVzO1xyXG5cdC13ZWJraXQtYW5pbWF0aW9uLWZpbGwtbW9kZTogYm90aDtcclxuXHRhbmltYXRpb24tZmlsbC1tb2RlOiBib3RoO1xyXG59XHJcbiIsIi5kaXNwbGF5LXhsIHtcclxuICAgIGZvbnQtc2l6ZTogNDFweCAhaW1wb3J0YW50O1xyXG4gICAgZm9udC13ZWlnaHQ6IDQwMCAhaW1wb3J0YW50O1xyXG4gICAgbGluZS1oZWlnaHQ6IDEyMCUgIWltcG9ydGFudDtcclxufVxyXG5cclxuLmRpc3BsYXktbWQge1xyXG4gICAgZm9udC1zaXplOiAzNnB4ICFpbXBvcnRhbnQ7XHJcbiAgICBmb250LXdlaWdodDogNDAwICFpbXBvcnRhbnQ7XHJcbiAgICBsaW5lLWhlaWdodDogMTIwJSAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4uaDEge1xyXG4gICAgZm9udC1zaXplOiAzMXB4ICFpbXBvcnRhbnQ7XHJcbiAgICBmb250LXdlaWdodDogNDAwICFpbXBvcnRhbnQ7XHJcbiAgICBsaW5lLWhlaWdodDogMTIwJSAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4uaDIge1xyXG4gICAgZm9udC1zaXplOiAyOHB4ICFpbXBvcnRhbnQ7XHJcbiAgICBmb250LXdlaWdodDogNDAwICFpbXBvcnRhbnQ7XHJcbiAgICBsaW5lLWhlaWdodDogMTIwJSAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4uaDMge1xyXG4gICAgZm9udC1zaXplOiAyNXB4ICFpbXBvcnRhbnQ7XHJcbiAgICBmb250LXdlaWdodDogNDAwICFpbXBvcnRhbnQ7XHJcbiAgICBsaW5lLWhlaWdodDogMTIwJSAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4uaDQge1xyXG4gICAgZm9udC1zaXplOiAyMnB4ICFpbXBvcnRhbnQ7XHJcbiAgICBmb250LXdlaWdodDogNDAwICFpbXBvcnRhbnQ7XHJcbiAgICBsaW5lLWhlaWdodDogMTIwJSAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4uaDUge1xyXG4gICAgZm9udC1zaXplOiAxOXB4ICFpbXBvcnRhbnQ7XHJcbiAgICBmb250LXdlaWdodDogNDAwICFpbXBvcnRhbnQ7XHJcbiAgICBsaW5lLWhlaWdodDogMTIwJSAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4uaDYge1xyXG4gICAgZm9udC1zaXplOiAxN3B4ICFpbXBvcnRhbnQ7XHJcbiAgICBmb250LXdlaWdodDogNDAwICFpbXBvcnRhbnQ7XHJcbiAgICBsaW5lLWhlaWdodDogMTIwJSAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4uYm9keS1sIHtcclxuICAgIGZvbnQtc2l6ZTogMTdweCAhaW1wb3J0YW50O1xyXG4gICAgZm9udC13ZWlnaHQ6IDQwMCAhaW1wb3J0YW50O1xyXG4gICAgbGluZS1oZWlnaHQ6IDEyMCUgIWltcG9ydGFudDtcclxufVxyXG5cclxuLmJvZHktbiB7XHJcbiAgICBmb250LXNpemU6IDE1cHggIWltcG9ydGFudDtcclxuICAgIGZvbnQtd2VpZ2h0OiA0MDAgIWltcG9ydGFudDtcclxuICAgIGxpbmUtaGVpZ2h0OiAxMjAlICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5ib2R5LXNtIHtcclxuICAgIGZvbnQtc2l6ZTogMTNweCAhaW1wb3J0YW50O1xyXG4gICAgZm9udC13ZWlnaHQ6IDQwMCAhaW1wb3J0YW50O1xyXG4gICAgbGluZS1oZWlnaHQ6IDEyMCUgIWltcG9ydGFudDtcclxufVxyXG5cclxuLmJvZHkteHMge1xyXG4gICAgZm9udC1zaXplOiAxMnB4ICFpbXBvcnRhbnQ7XHJcbiAgICBmb250LXdlaWdodDogNDAwICFpbXBvcnRhbnQ7XHJcbiAgICBsaW5lLWhlaWdodDogMTIwJSAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4uc2VtaWJvbGQge1xyXG4gICAgJi5kaXNwbGF5LXhsIHtcclxuICAgICAgICBmb250LXdlaWdodDogNjAwICFpbXBvcnRhbnQ7XHJcbiAgICB9XHJcbiAgICAmLmRpc3BsYXktbWQge1xyXG4gICAgICAgIGZvbnQtd2VpZ2h0OiA2MDAgIWltcG9ydGFudDtcclxuICAgIH1cclxuICAgICYuaDEge1xyXG4gICAgICAgIGZvbnQtd2VpZ2h0OiA2MDAgIWltcG9ydGFudDtcclxuICAgIH1cclxuICAgICYuaDIge1xyXG4gICAgICAgIGZvbnQtd2VpZ2h0OiA2MDAgIWltcG9ydGFudDtcclxuICAgIH1cclxuICAgICYuaDMge1xyXG4gICAgICAgIGZvbnQtd2VpZ2h0OiA2MDAgIWltcG9ydGFudDtcclxuICAgIH1cclxuICAgICYuaDQge1xyXG4gICAgICAgIGZvbnQtd2VpZ2h0OiA2MDAgIWltcG9ydGFudDtcclxuICAgIH1cclxuICAgICYuaDUge1xyXG4gICAgICAgIGZvbnQtd2VpZ2h0OiA2MDAgIWltcG9ydGFudDtcclxuICAgIH1cclxuICAgICYuaDYge1xyXG4gICAgICAgIGZvbnQtd2VpZ2h0OiA2MDAgIWltcG9ydGFudDtcclxuICAgIH1cclxuICAgICYuYm9keS1sIHtcclxuICAgICAgICBmb250LXdlaWdodDogNjAwICFpbXBvcnRhbnQ7XHJcbiAgICB9XHJcbiAgICAmLmJvZHktbiB7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IDYwMCAhaW1wb3J0YW50O1xyXG4gICAgfVxyXG4gICAgJi5ib2R5LXNtIHtcclxuICAgICAgICBmb250LXdlaWdodDogNjAwICFpbXBvcnRhbnQ7XHJcbiAgICB9XHJcbiAgICAmLmJvZHkteHMge1xyXG4gICAgICAgIGZvbnQtd2VpZ2h0OiA2MDAgIWltcG9ydGFudDtcclxuICAgIH1cclxufVxyXG5cclxuLmJvbGQge1xyXG4gICAgJi5kaXNwbGF5LXhsIHtcclxuICAgICAgICBmb250LXdlaWdodDogNzAwICFpbXBvcnRhbnQ7XHJcbiAgICB9XHJcbiAgICAmLmRpc3BsYXktbWQge1xyXG4gICAgICAgIGZvbnQtd2VpZ2h0OiA3MDAgIWltcG9ydGFudDtcclxuICAgIH1cclxuICAgICYuaDEge1xyXG4gICAgICAgIGZvbnQtd2VpZ2h0OiA3MDAgIWltcG9ydGFudDtcclxuICAgIH1cclxuICAgICYuaDIge1xyXG4gICAgICAgIGZvbnQtd2VpZ2h0OiA3MDAgIWltcG9ydGFudDtcclxuICAgIH1cclxuICAgICYuaDMge1xyXG4gICAgICAgIGZvbnQtd2VpZ2h0OiA3MDAgIWltcG9ydGFudDtcclxuICAgIH1cclxuICAgICYuaDQge1xyXG4gICAgICAgIGZvbnQtd2VpZ2h0OiA3MDAgIWltcG9ydGFudDtcclxuICAgIH1cclxuICAgICYuaDUge1xyXG4gICAgICAgIGZvbnQtd2VpZ2h0OiA3MDAgIWltcG9ydGFudDtcclxuICAgIH1cclxuICAgICYuaDYge1xyXG4gICAgICAgIGZvbnQtd2VpZ2h0OiA3MDAgIWltcG9ydGFudDtcclxuICAgIH1cclxuICAgICYuYm9keS1sIHtcclxuICAgICAgICBmb250LXdlaWdodDogNzAwICFpbXBvcnRhbnQ7XHJcbiAgICB9XHJcbiAgICAmLmJvZHktbiB7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IDcwMCAhaW1wb3J0YW50O1xyXG4gICAgfVxyXG4gICAgJi5ib2R5LXNtIHtcclxuICAgICAgICBmb250LXdlaWdodDogNzAwICFpbXBvcnRhbnQ7XHJcbiAgICB9XHJcbiAgICAmLmJvZHkteHMge1xyXG4gICAgICAgIGZvbnQtd2VpZ2h0OiA3MDAgIWltcG9ydGFudDtcclxuICAgIH1cclxufSJdfQ== */";

/***/ }),

/***/ 73435:
/*!******************************************************************************!*\
  !*** ./src/app/pages/new-pre-approval/new-pre-approval.page.scss?ngResource ***!
  \******************************************************************************/
/***/ ((module) => {

module.exports = ":root {\n  --nc-color-nextgen-neutral-grey-50: #f1efef;\n  --nc-color-nextgen-white: #ffffff;\n  --nc-color-nextgen-blue: #0d152e;\n  --nc-color-nextgen-green: #00908d;\n  --nc-color-nextgen-black: #000000;\n  --nc-color-nextgen-grey-background: #c8d3da;\n  --nc-color-nextgen-grey: #92a2ac;\n  --nc-color-nextgen-stone-grey: #fafafa;\n  --nc-color-nextgen-error: #fc1055;\n  --nc-color-nextgen-neutral-grey: #414141;\n  --nc-color-nextgen-fibrant-green: #00bab6;\n  --nc-color-nextgen-warning: #ffd048;\n  --nc-color-nextgen-green-background: #e6f2f2;\n  --nc-color-nextgen-neutral-grey-400: #7a7a7a;\n  --nc-color-nextgen-neutral-grey-100: #eff3f5;\n  --nc-color-nextgen-status-error: #ba0c3f;\n  --nc-color-nextgen-status-error-background: #ffeff4;\n  --nc-color-nextgen-status-warning: #cba127;\n  --nc-color-nextgen-status-warning-background: #fff8e6;\n  --nc-color-nextgen-blue-100: #dfeff2;\n  --nc-color-nextgen-error-red-700: #f62459;\n  --nc-color-nextgen-blue-500: #006192;\n  --nc-color-nextgen-blue-400: #79cdec;\n  --nc-color-nextgen-red-500: #ff6592;\n  --nc-color-nextgen-secondary-blue-300: #13a0d3;\n  --lumi-white-color: #ffffff;\n  --lumi-primary-yellow-color: #fab600;\n}\n\n.ion-color-green {\n  --ion-color-base: var(--nc-color-nextgen-green);\n  --ion-color-base-rgb: var(--nc-color-nextgen-green);\n  --ion-color-contrast: var(--nc-color-nextgen-white);\n  --ion-color-contrast-rgb: var(--nc-color-nextgen-green);\n  --ion-color-shade: var(--nc-color-nextgen-green);\n  --ion-color-tint: var(--nc-color-nextgen-green);\n}\n\n/*\n * 1. Custom CSS \n * ----------------------------------------------------------------------------\n */\n\n:root {\n  --nc-color-nextgen-neutral-grey-50: #f1efef;\n  --nc-color-nextgen-white: #ffffff;\n  --nc-color-nextgen-blue: #0d152e;\n  --nc-color-nextgen-green: #00908d;\n  --nc-color-nextgen-black: #000000;\n  --nc-color-nextgen-grey-background: #c8d3da;\n  --nc-color-nextgen-grey: #92a2ac;\n  --nc-color-nextgen-stone-grey: #fafafa;\n  --nc-color-nextgen-error: #fc1055;\n  --nc-color-nextgen-neutral-grey: #414141;\n  --nc-color-nextgen-fibrant-green: #00bab6;\n  --nc-color-nextgen-warning: #ffd048;\n  --nc-color-nextgen-green-background: #e6f2f2;\n  --nc-color-nextgen-neutral-grey-400: #7a7a7a;\n  --nc-color-nextgen-neutral-grey-100: #eff3f5;\n  --nc-color-nextgen-status-error: #ba0c3f;\n  --nc-color-nextgen-status-error-background: #ffeff4;\n  --nc-color-nextgen-status-warning: #cba127;\n  --nc-color-nextgen-status-warning-background: #fff8e6;\n  --nc-color-nextgen-blue-100: #dfeff2;\n  --nc-color-nextgen-error-red-700: #f62459;\n  --nc-color-nextgen-blue-500: #006192;\n  --nc-color-nextgen-blue-400: #79cdec;\n  --nc-color-nextgen-red-500: #ff6592;\n  --nc-color-nextgen-secondary-blue-300: #13a0d3;\n  --lumi-white-color: #ffffff;\n  --lumi-primary-yellow-color: #fab600;\n}\n\n.ion-color-green {\n  --ion-color-base: var(--nc-color-nextgen-green);\n  --ion-color-base-rgb: var(--nc-color-nextgen-green);\n  --ion-color-contrast: var(--nc-color-nextgen-white);\n  --ion-color-contrast-rgb: var(--nc-color-nextgen-green);\n  --ion-color-shade: var(--nc-color-nextgen-green);\n  --ion-color-tint: var(--nc-color-nextgen-green);\n}\n\n.display-xl {\n  font-size: 41px !important;\n  font-weight: 400 !important;\n  line-height: 120% !important;\n}\n\n.display-md {\n  font-size: 36px !important;\n  font-weight: 400 !important;\n  line-height: 120% !important;\n}\n\n.h1 {\n  font-size: 31px !important;\n  font-weight: 400 !important;\n  line-height: 120% !important;\n}\n\n.h2 {\n  font-size: 28px !important;\n  font-weight: 400 !important;\n  line-height: 120% !important;\n}\n\n.h3 {\n  font-size: 25px !important;\n  font-weight: 400 !important;\n  line-height: 120% !important;\n}\n\n.h4 {\n  font-size: 22px !important;\n  font-weight: 400 !important;\n  line-height: 120% !important;\n}\n\n.h5 {\n  font-size: 19px !important;\n  font-weight: 400 !important;\n  line-height: 120% !important;\n}\n\n.h6 {\n  font-size: 17px !important;\n  font-weight: 400 !important;\n  line-height: 120% !important;\n}\n\n.body-l {\n  font-size: 17px !important;\n  font-weight: 400 !important;\n  line-height: 120% !important;\n}\n\n.body-n {\n  font-size: 15px !important;\n  font-weight: 400 !important;\n  line-height: 120% !important;\n}\n\n.body-sm {\n  font-size: 13px !important;\n  font-weight: 400 !important;\n  line-height: 120% !important;\n}\n\n.body-xs {\n  font-size: 12px !important;\n  font-weight: 400 !important;\n  line-height: 120% !important;\n}\n\n.semibold.display-xl {\n  font-weight: 600 !important;\n}\n\n.semibold.display-md {\n  font-weight: 600 !important;\n}\n\n.semibold.h1 {\n  font-weight: 600 !important;\n}\n\n.semibold.h2 {\n  font-weight: 600 !important;\n}\n\n.semibold.h3 {\n  font-weight: 600 !important;\n}\n\n.semibold.h4 {\n  font-weight: 600 !important;\n}\n\n.semibold.h5 {\n  font-weight: 600 !important;\n}\n\n.semibold.h6 {\n  font-weight: 600 !important;\n}\n\n.semibold.body-l {\n  font-weight: 600 !important;\n}\n\n.semibold.body-n {\n  font-weight: 600 !important;\n}\n\n.semibold.body-sm {\n  font-weight: 600 !important;\n}\n\n.semibold.body-xs {\n  font-weight: 600 !important;\n}\n\n.bold.display-xl {\n  font-weight: 700 !important;\n}\n\n.bold.display-md {\n  font-weight: 700 !important;\n}\n\n.bold.h1 {\n  font-weight: 700 !important;\n}\n\n.bold.h2 {\n  font-weight: 700 !important;\n}\n\n.bold.h3 {\n  font-weight: 700 !important;\n}\n\n.bold.h4 {\n  font-weight: 700 !important;\n}\n\n.bold.h5 {\n  font-weight: 700 !important;\n}\n\n.bold.h6 {\n  font-weight: 700 !important;\n}\n\n.bold.body-l {\n  font-weight: 700 !important;\n}\n\n.bold.body-n {\n  font-weight: 700 !important;\n}\n\n.bold.body-sm {\n  font-weight: 700 !important;\n}\n\n.bold.body-xs {\n  font-weight: 700 !important;\n}\n\n@font-face {\n  font-family: \"Allianz Neo\";\n  font-style: normal;\n  font-weight: 300;\n  font-display: swap;\n  src: url('AllianzNeoW04-Light.woff2') format(\"woff2\"), url('AllianzNeoW04-Light.woff') format(\"woff\");\n}\n\n@font-face {\n  font-family: \"Allianz Neo\";\n  font-style: italic;\n  font-weight: 300;\n  font-display: swap;\n  src: url('AllianzNeoW04-LightItalic.woff2') format(\"woff2\"), url('AllianzNeoW04-LightItalic.woff') format(\"woff\");\n}\n\n@font-face {\n  font-family: \"Allianz Neo\";\n  font-style: normal;\n  font-weight: 400;\n  font-display: swap;\n  src: url('AllianzNeoW04-Regular.woff2') format(\"woff2\"), url('AllianzNeoW04-Regular.woff') format(\"woff\");\n}\n\n@font-face {\n  font-family: \"Allianz Neo\";\n  font-style: italic;\n  font-weight: 400;\n  font-display: swap;\n  src: url('AllianzNeoW04-Italic.woff2') format(\"woff2\"), url('AllianzNeoW04-Italic.woff') format(\"woff\");\n}\n\n@font-face {\n  font-family: \"Allianz Neo\";\n  font-style: normal;\n  font-weight: 600;\n  font-display: swap;\n  src: url('AllianzNeoW04-SemiBold.woff2') format(\"woff2\"), url('AllianzNeoW04-SemiBold.woff') format(\"woff\");\n}\n\n@font-face {\n  font-family: \"Allianz Neo\";\n  font-style: italic;\n  font-weight: 600;\n  font-display: swap;\n  src: url('AllianzNeoW04-SemiBoldIt.woff2') format(\"woff2\"), url('AllianzNeoW04-SemiBoldIt.woff') format(\"woff\");\n}\n\n@font-face {\n  font-family: \"Allianz Neo\";\n  font-style: normal;\n  font-weight: 700;\n  font-display: swap;\n  src: url('AllianzNeoW04-Bold.woff2') format(\"woff2\"), url('AllianzNeoW04-Bold.woff') format(\"woff\");\n}\n\n@font-face {\n  font-family: \"Allianz Neo\";\n  font-style: italic;\n  font-weight: 700;\n  font-display: swap;\n  src: url('AllianzNeoW04-BoldItalic.woff2') format(\"woff2\"), url('AllianzNeoW04-BoldItalic.woff') format(\"woff\");\n}\n\n* {\n  color: var(--nc-color-nextgen-neutral-grey);\n  font-family: \"Allianz Neo\", sans-serif;\n  font-weight: 400;\n  font-size: 16px;\n}\n\nhtml {\n  --ion-safe-area-top: 0px;\n}\n\n.col-1 {\n  width: 8.33%;\n}\n\n.col-2 {\n  width: 16.66%;\n}\n\n.col-3 {\n  width: 25%;\n}\n\n.col-4 {\n  width: 33.33%;\n}\n\n.col-5 {\n  width: 41.66%;\n}\n\n.col-6 {\n  width: 50%;\n}\n\n.col-7 {\n  width: 58.33%;\n}\n\n.col-8 {\n  width: 66.66%;\n}\n\n.col-9 {\n  width: 75%;\n}\n\n.col-10 {\n  width: 83.33%;\n}\n\n.col-11 {\n  width: 91.66%;\n}\n\n.col-12 {\n  width: 100%;\n}\n\n@media only screen and (max-width: 576px) {\n  /* For tablets: */\n  .col-sm-1 {\n    width: 8.33%;\n  }\n\n  .col-sm-2 {\n    width: 16.66%;\n  }\n\n  .col-sm-3 {\n    width: 25%;\n  }\n\n  .col-sm-4 {\n    width: 33.33%;\n  }\n\n  .col-sm-5 {\n    width: 41.66%;\n  }\n\n  .col-sm-6 {\n    width: 50%;\n  }\n\n  .col-sm-7 {\n    width: 58.33%;\n  }\n\n  .col-sm-8 {\n    width: 66.66%;\n  }\n\n  .col-sm-9 {\n    width: 75%;\n  }\n\n  .col-sm-10 {\n    width: 83.33%;\n  }\n\n  .col-sm-11 {\n    width: 91.66%;\n  }\n\n  .col-sm-12 {\n    width: 100%;\n  }\n}\n\n@media only screen and (max-width: 768px) and (min-width: 577px) {\n  /* For tablets: */\n  .col-md-1 {\n    width: 8.33%;\n  }\n\n  .col-md-2 {\n    width: 16.66%;\n  }\n\n  .col-md-3 {\n    width: 25%;\n  }\n\n  .col-md-4 {\n    width: 33.33%;\n  }\n\n  .col-md-5 {\n    width: 41.66%;\n  }\n\n  .col-md-6 {\n    width: 50%;\n  }\n\n  .col-md-7 {\n    width: 58.33%;\n  }\n\n  .col-md-8 {\n    width: 66.66%;\n  }\n\n  .col-md-9 {\n    width: 75%;\n  }\n\n  .col-md-10 {\n    width: 83.33%;\n  }\n\n  .col-md-11 {\n    width: 91.66%;\n  }\n\n  .col-md-12 {\n    width: 100%;\n  }\n}\n\n@media only screen and (min-width: 769px) {\n  /* For tablets: */\n  .col-lg-1 {\n    width: 8.33%;\n  }\n\n  .col-lg-2 {\n    width: 16.66%;\n  }\n\n  .col-lg-3 {\n    width: 25%;\n  }\n\n  .col-lg-4 {\n    width: 33.33%;\n  }\n\n  .col-lg-5 {\n    width: 41.66%;\n  }\n\n  .col-lg-6 {\n    width: 50%;\n  }\n\n  .col-lg-7 {\n    width: 58.33%;\n  }\n\n  .col-lg-8 {\n    width: 66.66%;\n  }\n\n  .col-lg-9 {\n    width: 75%;\n  }\n\n  .col-lg-10 {\n    width: 83.33%;\n  }\n\n  .col-lg-11 {\n    width: 91.66%;\n  }\n\n  .col-lg-12 {\n    width: 100%;\n  }\n}\n\n.row {\n  display: flex;\n  justify-content: center;\n  align-items: center;\n}\n\n.custom-toast {\n  --max-width: fit-content;\n}\n\n/*\n * 2. Custom CSS for compatibility with Edge\n * ----------------------------------------------------------------------------\n */\n\ninput::-ms-reveal,\ninput::-ms-clear {\n  display: none;\n}\n\n.swal2-popup {\n  margin-top: 20px;\n}\n\n/*\n * 3. Custom CSS for loading controller\n * ----------------------------------------------------------------------------\n */\n\n.transparent-loading-class {\n  --background: transparent;\n  --spinner-color: #47e6b1;\n}\n\n.loading-wrapper.sc-ion-loading-md {\n  box-shadow: unset;\n  -webkit-box-shadow: unset;\n}\n\n.uil {\n  color: var(--nc-color-nextgen-grey);\n}\n\n.btn {\n  height: 48px;\n  border-radius: 28px;\n  padding: 0px 41px 0px 41px;\n  box-shadow: none;\n}\n\n.btn.btn-circle {\n  background-color: var(--nc-color-nextgen-stone-grey) !important;\n  color: var(--nc-color-nextgen-black);\n  padding: unset !important;\n  height: 36px !important;\n  width: 36px !important;\n  border-radius: 50% !important;\n}\n\n.btn.btn-circle i {\n  color: var(--nc-color-nextgen-black);\n}\n\n.btn.primary {\n  background: var(--nc-color-nextgen-green);\n  color: var(--nc-color-nextgen-white);\n}\n\n.btn.primary .uil {\n  color: var(--nc-color-nextgen-white);\n}\n\n.btn.primary:disabled {\n  background-color: var(--nc-color-nextgen-grey-background) !important;\n  color: var(--nc-color-nextgen-grey) !important;\n}\n\n.btn.secondary {\n  background: var(--nc-color-nextgen-white) !important;\n  border-color: var(--nc-color-nextgen-green);\n  border: solid 1px;\n  color: var(--nc-color-nextgen-green);\n}\n\n.btn.secondary .uil {\n  color: var(--nc-color-nextgen-green);\n}\n\n.btn.secondary:disabled {\n  background-color: var(--nc-color-nextgen-white) !important;\n  color: var(--nc-color-nextgen-grey) !important;\n  border-color: var(--nc-color-nextgen-grey-background) !important;\n}\n\n.btn.transparent {\n  background: transparent !important;\n  border-color: var(--nc-color-nextgen-green);\n  border: solid 1px;\n  color: var(--nc-color-nextgen-green);\n}\n\n.btn.transparent .uil {\n  color: var(--nc-color-nextgen-green);\n}\n\n.btn.transparent:disabled {\n  background-color: transparent !important;\n  color: var(--nc-color-nextgen-grey) !important;\n  border-color: var(--nc-color-nextgen-grey-background) !important;\n}\n\n.btn.btn-large {\n  height: 56px !important;\n  width: 100%;\n}\n\n.btn.bold {\n  font-weight: 700 !important;\n}\n\n.btn.semibold {\n  font-weight: 600 !important;\n}\n\n.btn-no-space {\n  padding: 5px !important;\n  height: -moz-fit-content;\n  height: fit-content;\n}\n\n.btn-back {\n  width: 31px;\n  height: 28px;\n  background-color: transparent;\n  padding: 0;\n  color: var(--nc-color-nextgen-green);\n}\n\n.container {\n  padding: 2rem;\n  height: 100%;\n}\n\n.body-section {\n  width: 100%;\n  height: 95%;\n  overflow-y: auto;\n  position: relative;\n}\n\n.top-section {\n  width: 100%;\n  height: 10%;\n  justify-content: space-between;\n  display: flex;\n  align-items: center;\n}\n\n.form-control {\n  position: relative;\n  height: 85px;\n  margin-bottom: 8px;\n}\n\n.control {\n  border-radius: 8px;\n  height: 56px;\n  border: 1px solid var(--nc-color-nextgen-grey-background);\n  width: 100%;\n  position: absolute;\n  top: 32px;\n  background-color: var(--nc-color-nextgen-white);\n}\n\n.control table {\n  table-layout: fixed;\n  border-collapse: unset;\n}\n\n.control input {\n  height: 54px;\n  border: unset;\n  border-radius: 8px;\n  width: max-content;\n  width: 100%;\n  pointer-events: auto;\n  background-color: var(--nc-color-nextgen-white);\n}\n\n.control.textarea {\n  height: 108px;\n}\n\n.control textarea {\n  height: 106px;\n  border: unset;\n  border-radius: 8px;\n  width: max-content;\n  width: 100%;\n  pointer-events: auto;\n  resize: none;\n  background-color: var(--nc-color-nextgen-white);\n}\n\n.control input:focus {\n  outline: none;\n}\n\n.control:focus-within {\n  border-color: var(--nc-color-nextgen-green);\n}\n\n.control:focus-within .first-icon {\n  display: none;\n}\n\n.control:focus-within .first-icon.non-hidden {\n  display: table-cell;\n}\n\n.control .first-icon {\n  width: 32px;\n  text-align: center;\n  padding-left: 8px;\n}\n\n.control .first-icon i {\n  font-size: 24px !important;\n}\n\n.control .second-icon {\n  width: 32px;\n  text-align: center;\n}\n\n.control .second-icon i {\n  font-size: 24px !important;\n}\n\n.control:focus-within ~ div .control-label {\n  color: var(--nc-color-nextgen-green);\n}\n\n.control-error .control {\n  border-color: var(--nc-color-nextgen-error);\n}\n\n.control-error .control-label {\n  color: var(--nc-color-nextgen-error) !important;\n}\n\n.validation-summary li {\n  color: var(--nc-color-nextgen-error) !important;\n  list-style: none;\n}\n\n.validation-summary li i {\n  color: var(--nc-color-nextgen-error) !important;\n}\n\n.mr-1 {\n  margin-right: 0.5rem;\n}\n\n.mb-1 {\n  margin-bottom: 0.5rem;\n}\n\n.dialog-pane {\n  position: absolute;\n  pointer-events: auto;\n  box-sizing: border-box;\n  z-index: 1000;\n  display: block;\n  max-width: 100%;\n  max-height: 100%;\n}\n\n.overlay-backdrop {\n  background-color: var(--nc-color-nextgen-neutral-grey);\n  opacity: 0.2 !important;\n}\n\n.dialog-container {\n  animation: fadeIn 0.5s linear;\n  background-color: var(--nc-color-nextgen-white);\n}\n\n@keyframes fadeIn {\n  from {\n    transform: translateY(100%);\n  }\n  to {\n    transform: translateY(0%);\n  }\n}\n\n.error {\n  color: var(--nc-color-nextgen-error);\n}\n\n.error.background {\n  background-color: var(--nc-color-nextgen-error);\n}\n\n.success {\n  color: var(--nc-color-nextgen-fibrant-green);\n}\n\n.success.background {\n  background-color: var(--nc-color-nextgen-fibrant-green);\n}\n\n.warning {\n  color: var(--nc-color-nextgen-warning);\n}\n\n.warning.background {\n  background-color: var(--nc-color-nextgen-warning);\n}\n\n.select {\n  width: 100%;\n  height: 54px;\n  border: unset;\n  border-radius: 8px;\n  display: grid;\n  -webkit-appearance: none;\n          appearance: none;\n  grid-template-areas: \"select\";\n}\n\n.select:focus {\n  outline: unset;\n}\n\n.color-black {\n  color: var(--nc-color-nextgen-black);\n}\n\n.modal-default {\n  --width: 100%;\n  --height: 100%;\n}\n\n.integration-panel {\n  width: 100%;\n  height: 100%;\n  max-width: 100% !important;\n}\n\n.verloop-button {\n  visibility: hidden;\n}\n\n.back-area {\n  position: fixed;\n  top: 0;\n  right: 0;\n  height: 50px;\n  width: 100%;\n  background-color: var(--nc-color-nextgen-neutral-grey-50);\n  z-index: 9999999;\n}\n\n.back-area.ios {\n  height: 80px;\n}\n\n.title-widget {\n  text-align: center;\n  position: sticky;\n  top: 48px;\n}\n\n.button-back {\n  background-color: #fafafa;\n  height: 36px;\n  width: 36px;\n  border-radius: 50%;\n  position: absolute;\n  left: 18px;\n  bottom: 4px;\n}\n\n.icon-close-widget {\n  position: absolute;\n  z-index: 250;\n  left: 11px;\n  bottom: 13px;\n}\n\n.data-default {\n  position: absolute;\n  top: 50%;\n  left: 50%;\n  transform: translate(-50%, -50%);\n  text-align: center;\n  color: var(--nc-color-nextgen-neutral-grey-400);\n  z-index: 1000;\n}\n\n.avaamo__icon {\n  visibility: hidden !important;\n}\n\n.avaamo__chat__widget.ios #avaamo__popup {\n  padding-top: 40px;\n}\n\n.d-flex {\n  display: flex;\n}\n\nnextcare-layout {\n  left: 0;\n  right: 0;\n  top: 0;\n  bottom: 0;\n  display: flex;\n  position: absolute;\n  flex-direction: column;\n  justify-content: space-between;\n  contain: layout size style;\n  overflow: hidden;\n  background-color: var(--nc-color-nextgen-neutral-grey-50);\n  padding-right: 24px;\n  padding-left: 24px;\n}\n\nion-header.ios.header-ios {\n  margin-top: 40px;\n}\n\n.header-ios ion-toolbar:last-of-type {\n  --border-width: 0px !important;\n}\n\n.header-md.md::after {\n  display: none;\n}\n\nion-toolbar {\n  padding-right: unset !important;\n  padding-left: unset !important;\n}\n\ni.icon-back {\n  content: url('long-arrow-left-icon.svg');\n}\n\n.verloop-widget.ios .verloop-container.visible {\n  height: calc(100% - 40px);\n  top: 40px;\n}\n\n#nextcare-ads {\n  display: none;\n  overflow: scroll;\n  height: 180px;\n}\n\n.d-block {\n  display: block;\n}\n\n.title-text {\n  color: var(--nc-color-nextgen-blue);\n}\n\n:host ion-datetime #shadow-root .datetime-calendar .calendar-header .calendar-action-buttons .calendar-month-year {\n  align-items: center;\n  justify-content: center;\n  display: flex;\n  width: 100%;\n}\n\n:host ion-datetime #shadow-root .datetime-calendar .calendar-header .calendar-action-buttons .calendar-month-year ion-icon {\n  display: none;\n}\n\n:host ion-datetime #shadow-root .datetime-calendar .calendar-header .calendar-action-buttons .calendar-next-prev {\n  position: absolute;\n  width: 100%;\n  right: 0;\n}\n\n:host ion-datetime #shadow-root .datetime-calendar .calendar-header .calendar-action-buttons .calendar-next-prev ion-buttons {\n  display: flex;\n  justify-content: space-between;\n  width: 100%;\n}\n\n.mat-dialog-container {\n  padding: unset !important;\n}\n\n/* Change autocomplete styles in WebKit */\n\ninput:-webkit-autofill,\ninput:-webkit-autofill:hover,\ninput:-webkit-autofill:focus,\ntextarea:-webkit-autofill,\ntextarea:-webkit-autofill:hover,\ntextarea:-webkit-autofill:focus,\nselect:-webkit-autofill,\nselect:-webkit-autofill:hover,\nselect:-webkit-autofill:focus {\n  -webkit-text-fill-color: black;\n  -webkit-box-shadow: 0 0 0px 1000px white inset;\n  -webkit-transition: background-color 5000s ease-in-out 0s;\n  transition: background-color 5000s ease-in-out 0s;\n}\n\n.force-update-popup + .cdk-global-overlay-wrapper .save-btn {\n  background: var(--lumi-primary-yellow-color) !important;\n  color: var(--lumi-white-color) !important;\n  font-weight: bold !important;\n}\n\n.force-update-popup + .cdk-global-overlay-wrapper .cancel-btn {\n  color: var(--lumi-primary-yellow-color) !important;\n}\n\n@keyframes slideInRight {\n  0% {\n    transform: translate3d(100%, 0, 0);\n    visibility: visible;\n  }\n  to {\n    transform: translateZ(0);\n  }\n}\n\n.animate__slideInRight {\n  animation-name: slideInRight;\n}\n\n.animate__animated {\n  animation-duration: 0.5s;\n  animation-duration: 0.5s;\n  animation-fill-mode: both;\n}\n\n.new-claim-container {\n  background-color: var(--nc-color-nextgen-neutral-grey-50);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXGNvbG9yLnNjc3MiLCJuZXctcHJlLWFwcHJvdmFsLnBhZ2Uuc2NzcyIsIi4uXFwuLlxcLi5cXHN0eWxlLnNjc3MiLCIuLlxcLi5cXC4uXFxmb250LXNpemUuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNDLDJDQUFBO0VBQ0EsaUNBQUE7RUFDQSxnQ0FBQTtFQUNBLGlDQUFBO0VBQ0EsaUNBQUE7RUFDQSwyQ0FBQTtFQUNBLGdDQUFBO0VBQ0Esc0NBQUE7RUFDQSxpQ0FBQTtFQUNBLHdDQUFBO0VBQ0EseUNBQUE7RUFDQSxtQ0FBQTtFQUNBLDRDQUFBO0VBQ0EsNENBQUE7RUFDQSw0Q0FBQTtFQUNBLHdDQUFBO0VBQ0EsbURBQUE7RUFDQSwwQ0FBQTtFQUNBLHFEQUFBO0VBQ0Esb0NBQUE7RUFDQSx5Q0FBQTtFQUNBLG9DQUFBO0VBQ0Esb0NBQUE7RUFDQSxtQ0FBQTtFQUNBLDhDQUFBO0VBRUEsMkJBQUE7RUFDQSxvQ0FBQTtBQ0FEOztBRGdDQTtFQUNDLCtDQUFBO0VBQ0EsbURBQUE7RUFDQSxtREFBQTtFQUNBLHVEQUFBO0VBQ0EsZ0RBQUE7RUFDQSwrQ0FBQTtBQzdCRDs7QUNyQ0E7OztFQUFBOztBRkFBO0VBQ0MsMkNBQUE7RUFDQSxpQ0FBQTtFQUNBLGdDQUFBO0VBQ0EsaUNBQUE7RUFDQSxpQ0FBQTtFQUNBLDJDQUFBO0VBQ0EsZ0NBQUE7RUFDQSxzQ0FBQTtFQUNBLGlDQUFBO0VBQ0Esd0NBQUE7RUFDQSx5Q0FBQTtFQUNBLG1DQUFBO0VBQ0EsNENBQUE7RUFDQSw0Q0FBQTtFQUNBLDRDQUFBO0VBQ0Esd0NBQUE7RUFDQSxtREFBQTtFQUNBLDBDQUFBO0VBQ0EscURBQUE7RUFDQSxvQ0FBQTtFQUNBLHlDQUFBO0VBQ0Esb0NBQUE7RUFDQSxvQ0FBQTtFQUNBLG1DQUFBO0VBQ0EsOENBQUE7RUFFQSwyQkFBQTtFQUNBLG9DQUFBO0FDMkNEOztBRFhBO0VBQ0MsK0NBQUE7RUFDQSxtREFBQTtFQUNBLG1EQUFBO0VBQ0EsdURBQUE7RUFDQSxnREFBQTtFQUNBLCtDQUFBO0FDY0Q7O0FFaEZBO0VBQ0ksMEJBQUE7RUFDQSwyQkFBQTtFQUNBLDRCQUFBO0FGbUZKOztBRWhGQTtFQUNJLDBCQUFBO0VBQ0EsMkJBQUE7RUFDQSw0QkFBQTtBRm1GSjs7QUVoRkE7RUFDSSwwQkFBQTtFQUNBLDJCQUFBO0VBQ0EsNEJBQUE7QUZtRko7O0FFaEZBO0VBQ0ksMEJBQUE7RUFDQSwyQkFBQTtFQUNBLDRCQUFBO0FGbUZKOztBRWhGQTtFQUNJLDBCQUFBO0VBQ0EsMkJBQUE7RUFDQSw0QkFBQTtBRm1GSjs7QUVoRkE7RUFDSSwwQkFBQTtFQUNBLDJCQUFBO0VBQ0EsNEJBQUE7QUZtRko7O0FFaEZBO0VBQ0ksMEJBQUE7RUFDQSwyQkFBQTtFQUNBLDRCQUFBO0FGbUZKOztBRWhGQTtFQUNJLDBCQUFBO0VBQ0EsMkJBQUE7RUFDQSw0QkFBQTtBRm1GSjs7QUVoRkE7RUFDSSwwQkFBQTtFQUNBLDJCQUFBO0VBQ0EsNEJBQUE7QUZtRko7O0FFaEZBO0VBQ0ksMEJBQUE7RUFDQSwyQkFBQTtFQUNBLDRCQUFBO0FGbUZKOztBRWhGQTtFQUNJLDBCQUFBO0VBQ0EsMkJBQUE7RUFDQSw0QkFBQTtBRm1GSjs7QUVoRkE7RUFDSSwwQkFBQTtFQUNBLDJCQUFBO0VBQ0EsNEJBQUE7QUZtRko7O0FFL0VJO0VBQ0ksMkJBQUE7QUZrRlI7O0FFaEZJO0VBQ0ksMkJBQUE7QUZrRlI7O0FFaEZJO0VBQ0ksMkJBQUE7QUZrRlI7O0FFaEZJO0VBQ0ksMkJBQUE7QUZrRlI7O0FFaEZJO0VBQ0ksMkJBQUE7QUZrRlI7O0FFaEZJO0VBQ0ksMkJBQUE7QUZrRlI7O0FFaEZJO0VBQ0ksMkJBQUE7QUZrRlI7O0FFaEZJO0VBQ0ksMkJBQUE7QUZrRlI7O0FFaEZJO0VBQ0ksMkJBQUE7QUZrRlI7O0FFaEZJO0VBQ0ksMkJBQUE7QUZrRlI7O0FFaEZJO0VBQ0ksMkJBQUE7QUZrRlI7O0FFaEZJO0VBQ0ksMkJBQUE7QUZrRlI7O0FFN0VJO0VBQ0ksMkJBQUE7QUZnRlI7O0FFOUVJO0VBQ0ksMkJBQUE7QUZnRlI7O0FFOUVJO0VBQ0ksMkJBQUE7QUZnRlI7O0FFOUVJO0VBQ0ksMkJBQUE7QUZnRlI7O0FFOUVJO0VBQ0ksMkJBQUE7QUZnRlI7O0FFOUVJO0VBQ0ksMkJBQUE7QUZnRlI7O0FFOUVJO0VBQ0ksMkJBQUE7QUZnRlI7O0FFOUVJO0VBQ0ksMkJBQUE7QUZnRlI7O0FFOUVJO0VBQ0ksMkJBQUE7QUZnRlI7O0FFOUVJO0VBQ0ksMkJBQUE7QUZnRlI7O0FFOUVJO0VBQ0ksMkJBQUE7QUZnRlI7O0FFOUVJO0VBQ0ksMkJBQUE7QUZnRlI7O0FDdk5BO0VBQ0MsMEJBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0Esa0JBQUE7RUFDQSxxR0FBQTtBRDBORDs7QUNwTkE7RUFDQywwQkFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrQkFBQTtFQUNBLGlIQUFBO0FEc05EOztBQ2hOQTtFQUNDLDBCQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtFQUNBLGtCQUFBO0VBQ0EseUdBQUE7QURrTkQ7O0FDNU1BO0VBQ0MsMEJBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0Esa0JBQUE7RUFDQSx1R0FBQTtBRDhNRDs7QUN4TUE7RUFDQywwQkFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrQkFBQTtFQUNBLDJHQUFBO0FEME1EOztBQ3BNQTtFQUNDLDBCQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtFQUNBLGtCQUFBO0VBQ0EsK0dBQUE7QURzTUQ7O0FDaE1BO0VBQ0MsMEJBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0Esa0JBQUE7RUFDQSxtR0FBQTtBRGtNRDs7QUM1TEE7RUFDQywwQkFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrQkFBQTtFQUNBLCtHQUFBO0FEOExEOztBQ3hMQTtFQUNDLDJDRjlENEI7RUUrRDVCLHNDQUFBO0VBQ0EsZ0JBQUE7RUFDQSxlQUFBO0FEMExEOztBQ3ZMQTtFQUNDLHdCQUFBO0FEMExEOztBQ3ZMQTtFQUNDLFlBQUE7QUQwTEQ7O0FDdkxBO0VBQ0MsYUFBQTtBRDBMRDs7QUN2TEE7RUFDQyxVQUFBO0FEMExEOztBQ3ZMQTtFQUNDLGFBQUE7QUQwTEQ7O0FDdkxBO0VBQ0MsYUFBQTtBRDBMRDs7QUN2TEE7RUFDQyxVQUFBO0FEMExEOztBQ3ZMQTtFQUNDLGFBQUE7QUQwTEQ7O0FDdkxBO0VBQ0MsYUFBQTtBRDBMRDs7QUN2TEE7RUFDQyxVQUFBO0FEMExEOztBQ3ZMQTtFQUNDLGFBQUE7QUQwTEQ7O0FDdkxBO0VBQ0MsYUFBQTtBRDBMRDs7QUN2TEE7RUFDQyxXQUFBO0FEMExEOztBQ3ZMQTtFQUNDLGlCQUFBO0VBQ0E7SUFDQyxZQUFBO0VEMExBOztFQ3ZMRDtJQUNDLGFBQUE7RUQwTEE7O0VDdkxEO0lBQ0MsVUFBQTtFRDBMQTs7RUN2TEQ7SUFDQyxhQUFBO0VEMExBOztFQ3ZMRDtJQUNDLGFBQUE7RUQwTEE7O0VDdkxEO0lBQ0MsVUFBQTtFRDBMQTs7RUN2TEQ7SUFDQyxhQUFBO0VEMExBOztFQ3ZMRDtJQUNDLGFBQUE7RUQwTEE7O0VDdkxEO0lBQ0MsVUFBQTtFRDBMQTs7RUN2TEQ7SUFDQyxhQUFBO0VEMExBOztFQ3ZMRDtJQUNDLGFBQUE7RUQwTEE7O0VDdkxEO0lBQ0MsV0FBQTtFRDBMQTtBQUNGOztBQ3ZMQTtFQUNDLGlCQUFBO0VBQ0E7SUFDQyxZQUFBO0VEeUxBOztFQ3RMRDtJQUNDLGFBQUE7RUR5TEE7O0VDdExEO0lBQ0MsVUFBQTtFRHlMQTs7RUN0TEQ7SUFDQyxhQUFBO0VEeUxBOztFQ3RMRDtJQUNDLGFBQUE7RUR5TEE7O0VDdExEO0lBQ0MsVUFBQTtFRHlMQTs7RUN0TEQ7SUFDQyxhQUFBO0VEeUxBOztFQ3RMRDtJQUNDLGFBQUE7RUR5TEE7O0VDdExEO0lBQ0MsVUFBQTtFRHlMQTs7RUN0TEQ7SUFDQyxhQUFBO0VEeUxBOztFQ3RMRDtJQUNDLGFBQUE7RUR5TEE7O0VDdExEO0lBQ0MsV0FBQTtFRHlMQTtBQUNGOztBQ3RMQTtFQUNDLGlCQUFBO0VBQ0E7SUFDQyxZQUFBO0VEd0xBOztFQ3JMRDtJQUNDLGFBQUE7RUR3TEE7O0VDckxEO0lBQ0MsVUFBQTtFRHdMQTs7RUNyTEQ7SUFDQyxhQUFBO0VEd0xBOztFQ3JMRDtJQUNDLGFBQUE7RUR3TEE7O0VDckxEO0lBQ0MsVUFBQTtFRHdMQTs7RUNyTEQ7SUFDQyxhQUFBO0VEd0xBOztFQ3JMRDtJQUNDLGFBQUE7RUR3TEE7O0VDckxEO0lBQ0MsVUFBQTtFRHdMQTs7RUNyTEQ7SUFDQyxhQUFBO0VEd0xBOztFQ3JMRDtJQUNDLGFBQUE7RUR3TEE7O0VDckxEO0lBQ0MsV0FBQTtFRHdMQTtBQUNGOztBQ3JMQTtFQUNDLGFBQUE7RUFDQSx1QkFBQTtFQUNBLG1CQUFBO0FEdUxEOztBQ25MQTtFQUNDLHdCQUFBO0FEc0xEOztBQ25MQTs7O0VBQUE7O0FBSUE7O0VBRUMsYUFBQTtBRHNMRDs7QUNuTEE7RUFDQyxnQkFBQTtBRHNMRDs7QUNuTEE7OztFQUFBOztBQUlBO0VBQ0MseUJBQUE7RUFDQSx3QkFBQTtBRHNMRDs7QUNuTEE7RUFDQyxpQkFBQTtFQUNBLHlCQUFBO0FEc0xEOztBQ25MQTtFQUNDLG1DRjNUb0I7QUNpZnJCOztBQ25MQTtFQUNDLFlBQUE7RUFDQSxtQkFBQTtFQUNBLDBCQUFBO0VBQ0EsZ0JBQUE7QURzTEQ7O0FDcExDO0VBQ0MsK0RBQUE7RUFDQSxvQ0Z4VW9CO0VFeVVwQix5QkFBQTtFQUNBLHVCQUFBO0VBQ0Esc0JBQUE7RUFDQSw2QkFBQTtBRHNMRjs7QUNwTEU7RUFDQyxvQ0YvVW1CO0FDcWdCdEI7O0FDbExDO0VBQ0MseUNGdFZvQjtFRXVWcEIsb0NGdFZvQjtBQzBnQnRCOztBQ2xMRTtFQUNDLG9DRnpWbUI7QUM2Z0J0Qjs7QUNqTEU7RUFDQyxvRUFBQTtFQUNBLDhDQUFBO0FEbUxIOztBQy9LQztFQUNDLG9EQUFBO0VBQ0EsMkNGcldvQjtFRXNXcEIsaUJBQUE7RUFDQSxvQ0Z2V29CO0FDd2hCdEI7O0FDL0tFO0VBQ0Msb0NGMVdtQjtBQzJoQnRCOztBQzlLRTtFQUNDLDBEQUFBO0VBQ0EsOENBQUE7RUFDQSxnRUFBQTtBRGdMSDs7QUM1S0M7RUFDQyxrQ0FBQTtFQUNBLDJDRnRYb0I7RUV1WHBCLGlCQUFBO0VBQ0Esb0NGeFhvQjtBQ3NpQnRCOztBQzVLRTtFQUNDLG9DRjNYbUI7QUN5aUJ0Qjs7QUMzS0U7RUFDQyx3Q0FBQTtFQUNBLDhDQUFBO0VBQ0EsZ0VBQUE7QUQ2S0g7O0FDektDO0VBQ0MsdUJBQUE7RUFDQSxXQUFBO0FEMktGOztBQ3hLQztFQUNDLDJCQUFBO0FEMEtGOztBQ3ZLQztFQUNDLDJCQUFBO0FEeUtGOztBQ3JLQTtFQUNDLHVCQUFBO0VBQ0Esd0JBQUE7RUFBQSxtQkFBQTtBRHdLRDs7QUNyS0E7RUFDQyxXQUFBO0VBQ0EsWUFBQTtFQUNBLDZCQUFBO0VBQ0EsVUFBQTtFQUNBLG9DRjdacUI7QUNxa0J0Qjs7QUNyS0E7RUFDQyxhQUFBO0VBQ0EsWUFBQTtBRHdLRDs7QUNyS0E7RUFDQyxXQUFBO0VBQ0EsV0FBQTtFQUNBLGdCQUFBO0VBQ0Esa0JBQUE7QUR3S0Q7O0FDcktBO0VBQ0MsV0FBQTtFQUNBLFdBQUE7RUFDQSw4QkFBQTtFQUNBLGFBQUE7RUFDQSxtQkFBQTtBRHdLRDs7QUNyS0E7RUFDQyxrQkFBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtBRHdLRDs7QUNyS0E7RUFDQyxrQkFBQTtFQUNBLFlBQUE7RUFDQSx5REFBQTtFQUNBLFdBQUE7RUFDQSxrQkFBQTtFQUNBLFNBQUE7RUFDQSwrQ0ZoY3FCO0FDd21CdEI7O0FDdEtDO0VBQ0MsbUJBQUE7RUFDQSxzQkFBQTtBRHdLRjs7QUNyS0M7RUFDQyxZQUFBO0VBQ0EsYUFBQTtFQUNBLGtCQUFBO0VBQ0Esa0JBQUE7RUFDQSxXQUFBO0VBQ0Esb0JBQUE7RUFDQSwrQ0Y5Y29CO0FDcW5CdEI7O0FDcEtDO0VBQ0MsYUFBQTtBRHNLRjs7QUNuS0M7RUFDQyxhQUFBO0VBQ0EsYUFBQTtFQUNBLGtCQUFBO0VBQ0Esa0JBQUE7RUFDQSxXQUFBO0VBQ0Esb0JBQUE7RUFDQSxZQUFBO0VBQ0EsK0NGN2RvQjtBQ2tvQnRCOztBQ2xLQztFQUNDLGFBQUE7QURvS0Y7O0FDaktDO0VBQ0MsMkNGdGVvQjtBQ3lvQnRCOztBQ2pLRTtFQUNDLGFBQUE7QURtS0g7O0FDaEtFO0VBQ0MsbUJBQUE7QURrS0g7O0FDOUpDO0VBQ0MsV0FBQTtFQUNBLGtCQUFBO0VBQ0EsaUJBQUE7QURnS0Y7O0FDOUpFO0VBQ0MsMEJBQUE7QURnS0g7O0FDNUpDO0VBQ0MsV0FBQTtFQUNBLGtCQUFBO0FEOEpGOztBQzNKRTtFQUNDLDBCQUFBO0FENkpIOztBQ3hKQTtFQUNDLG9DRnZnQnFCO0FDa3FCdEI7O0FDdkpDO0VBQ0MsMkNGdGdCb0I7QUNncUJ0Qjs7QUN2SkM7RUFDQywrQ0FBQTtBRHlKRjs7QUNwSkM7RUFDQywrQ0FBQTtFQUNBLGdCQUFBO0FEdUpGOztBQ3JKRTtFQUNDLCtDQUFBO0FEdUpIOztBQ2xKQTtFQUNDLG9CQUFBO0FEcUpEOztBQ2xKQTtFQUNDLHFCQUFBO0FEcUpEOztBQ2xKQTtFQUNDLGtCQUFBO0VBQ0Esb0JBQUE7RUFDQSxzQkFBQTtFQUNBLGFBQUE7RUFDQSxjQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0FEcUpEOztBQ2xKQTtFQUNDLHNERjNpQjRCO0VFNGlCNUIsdUJBQUE7QURxSkQ7O0FDbEpBO0VBQ0MsNkJBQUE7RUFDQSwrQ0Z2akJxQjtBQzRzQnRCOztBQ2xKQTtFQUNDO0lBQ0MsMkJBQUE7RURxSkE7RUNsSkQ7SUFDQyx5QkFBQTtFRG9KQTtBQUNGOztBQ2pKQTtFQUNDLG9DRmhrQnFCO0FDbXRCdEI7O0FDakpDO0VBQ0MsK0NGbmtCb0I7QUNzdEJ0Qjs7QUMvSUE7RUFDQyw0Q0Z0a0I2QjtBQ3d0QjlCOztBQ2hKQztFQUNDLHVERnprQjRCO0FDMnRCOUI7O0FDOUlBO0VBQ0Msc0NGN2tCdUI7QUM4dEJ4Qjs7QUMvSUM7RUFDQyxpREZobEJzQjtBQ2l1QnhCOztBQzdJQTtFQUNDLFdBQUE7RUFDQSxZQUFBO0VBQ0EsYUFBQTtFQUNBLGtCQUFBO0VBQ0EsYUFBQTtFQUNBLHdCQUFBO1VBQUEsZ0JBQUE7RUFDQSw2QkFBQTtBRGdKRDs7QUM5SUM7RUFDQyxjQUFBO0FEZ0pGOztBQzVJQTtFQUNDLG9DRjFtQnFCO0FDeXZCdEI7O0FDNUlBO0VBQ0MsYUFBQTtFQUNBLGNBQUE7QUQrSUQ7O0FDNUlBO0VBQ0MsV0FBQTtFQUNBLFlBQUE7RUFDQSwwQkFBQTtBRCtJRDs7QUM1SUE7RUFDQyxrQkFBQTtBRCtJRDs7QUM1SUE7RUFDQyxlQUFBO0VBQ0EsTUFBQTtFQUNBLFFBQUE7RUFDQSxZQUFBO0VBQ0EsV0FBQTtFQUNBLHlERnpuQitCO0VFMG5CL0IsZ0JBQUE7QUQrSUQ7O0FDN0lDO0VBQ0MsWUFBQTtBRCtJRjs7QUMzSUE7RUFDQyxrQkFBQTtFQUNBLGdCQUFBO0VBQ0EsU0FBQTtBRDhJRDs7QUMzSUE7RUFDQyx5QkFBQTtFQUNBLFlBQUE7RUFDQSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSxrQkFBQTtFQUNBLFVBQUE7RUFDQSxXQUFBO0FEOElEOztBQzNJQTtFQUNDLGtCQUFBO0VBQ0EsWUFBQTtFQUNBLFVBQUE7RUFDQSxZQUFBO0FEOElEOztBQzNJQTtFQUNDLGtCQUFBO0VBQ0EsUUFBQTtFQUNBLFNBQUE7RUFDQSxnQ0FBQTtFQUNBLGtCQUFBO0VBQ0EsK0NGN3BCZ0M7RUU4cEJoQyxhQUFBO0FEOElEOztBQzNJQTtFQUNDLDZCQUFBO0FEOElEOztBQzFJQztFQUNDLGlCQUFBO0FENklGOztBQ3pJQTtFQUNDLGFBQUE7QUQ0SUQ7O0FDeklBO0VBQ0MsT0FBQTtFQUNBLFFBQUE7RUFDQSxNQUFBO0VBQ0EsU0FBQTtFQUNBLGFBQUE7RUFDQSxrQkFBQTtFQUNBLHNCQUFBO0VBQ0EsOEJBQUE7RUFDQSwwQkFBQTtFQUNBLGdCQUFBO0VBQ0EseURGM3JCK0I7RUU0ckIvQixtQkFBQTtFQUNBLGtCQUFBO0FENElEOztBQ3pJQTtFQUNDLGdCQUFBO0FENElEOztBQ3pJQTtFQUNDLDhCQUFBO0FENElEOztBQ3pJQTtFQUNDLGFBQUE7QUQ0SUQ7O0FDeklBO0VBQ0MsK0JBQUE7RUFDQSw4QkFBQTtBRDRJRDs7QUN6SUE7RUFDQyx3Q0FBQTtBRDRJRDs7QUN4SUM7RUFDQyx5QkFBQTtFQUNBLFNBQUE7QUQySUY7O0FDdklBO0VBQ0MsYUFBQTtFQUNBLGdCQUFBO0VBQ0EsYUFBQTtBRDBJRDs7QUN2SUE7RUFDQyxjQUFBO0FEMElEOztBQ3ZJQTtFQUNDLG1DRm52Qm9CO0FDNjNCckI7O0FDbklJO0VBQ0MsbUJBQUE7RUFDQSx1QkFBQTtFQUNBLGFBQUE7RUFDQSxXQUFBO0FEc0lMOztBQ3BJSztFQUNDLGFBQUE7QURzSU47O0FDbElJO0VBQ0Msa0JBQUE7RUFDQSxXQUFBO0VBQ0EsUUFBQTtBRG9JTDs7QUNsSUs7RUFDQyxhQUFBO0VBQ0EsOEJBQUE7RUFDQSxXQUFBO0FEb0lOOztBQzVIQTtFQUNDLHlCQUFBO0FEK0hEOztBQzVIQSx5Q0FBQTs7QUFDQTs7Ozs7Ozs7O0VBU0MsOEJBQUE7RUFDQSw4Q0FBQTtFQUNBLHlEQUFBO0VBQUEsaURBQUE7QUQrSEQ7O0FDM0hDO0VBQ0MsdURBQUE7RUFDQSx5Q0FBQTtFQUNBLDRCQUFBO0FEOEhGOztBQzNIQztFQUNDLGtEQUFBO0FENkhGOztBQzVHQTtFQUNDO0lBRUMsa0NBQUE7SUFDQSxtQkFBQTtFRDBIQTtFQ3ZIRDtJQUVDLHdCQUFBO0VEeUhBO0FBQ0Y7O0FDdEhBO0VBRUMsNEJBQUE7QUR3SEQ7O0FDckhBO0VBRUMsd0JBQUE7RUFFQSx3QkFBQTtFQUVBLHlCQUFBO0FEd0hEOztBQTcrQkE7RUFDSSx5RER1QzRCO0FDeThCaEMiLCJmaWxlIjoibmV3LXByZS1hcHByb3ZhbC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyI6cm9vdCB7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS01MDogI2YxZWZlZjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4td2hpdGU6ICNmZmZmZmY7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWJsdWU6ICMwZDE1MmU7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuOiAjMDA5MDhkO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ibGFjazogIzAwMDAwMDtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tZ3JleS1iYWNrZ3JvdW5kOiAjYzhkM2RhO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ncmV5OiAjOTJhMmFjO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zdG9uZS1ncmV5OiAjZmFmYWZhO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1lcnJvcjogI2ZjMTA1NTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5OiAjNDE0MTQxO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1maWJyYW50LWdyZWVuOiAjMDBiYWI2O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi13YXJuaW5nOiAjZmZkMDQ4O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbi1iYWNrZ3JvdW5kOiAjZTZmMmYyO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNDAwOiAjN2E3YTdhO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktMTAwOiAjZWZmM2Y1O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtZXJyb3I6ICNiYTBjM2Y7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy1lcnJvci1iYWNrZ3JvdW5kOiAjZmZlZmY0O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtd2FybmluZzogI2NiYTEyNztcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLXdhcm5pbmctYmFja2dyb3VuZDogI2ZmZjhlNjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZS0xMDA6ICNkZmVmZjI7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWVycm9yLXJlZC03MDA6ICNmNjI0NTk7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWJsdWUtNTAwOiAjMDA2MTkyO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlLTQwMDogIzc5Y2RlYztcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tcmVkLTUwMDogI2ZmNjU5MjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc2Vjb25kYXJ5LWJsdWUtMzAwOiAjMTNhMGQzO1xyXG5cclxuXHQtLWx1bWktd2hpdGUtY29sb3I6ICNmZmZmZmY7XHJcblx0LS1sdW1pLXByaW1hcnkteWVsbG93LWNvbG9yOiAjZmFiNjAwO1xyXG59XHJcbiRjb2xvci1uZXh0Z2VuLWJsdWU6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZSk7XHJcbiRjb2xvci1uZXh0Z2VuLWdyZWVuOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuKTtcclxuJGNvbG9yLW5leHRnZW4td2hpdGU6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4td2hpdGUpO1xyXG4kY29sb3ItbmV4dGdlbi1ibGFjazogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ibGFjayk7XHJcbiRjb2xvci1uZXh0Z2VuLWdyZXktYmFja2dyb3VuZDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmV5LWJhY2tncm91bmQpO1xyXG4kY29sb3ItbmV4dGdlbi1ncmV5OiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZXkpO1xyXG4kY29sb3ItbmV4dGdlbi1zdG9uZS1ncmV5OiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXN0b25lLWdyZXkpO1xyXG4kY29sb3ItbmV4dGdlbi1lcnJvcjogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1lcnJvcik7XHJcbiRjb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleTogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXkpO1xyXG4kY29sb3ItbmV4dGdlbi1maWJyYW50LWdyZWVuOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWZpYnJhbnQtZ3JlZW4pO1xyXG4kY29sb3ItbmV4dGdlbi13YXJuaW5nOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXdhcm5pbmcpO1xyXG4kY29sb3ItbmV4dGdlbi1ncmVlbi1iYWNrZ3JvdW5kOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuLWJhY2tncm91bmQpO1xyXG4kY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNTA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTUwKTtcclxuJGNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTQwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNDAwKTtcclxuJGNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTEwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktMTAwKTtcclxuJGNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy1lcnJvcik7XHJcbiRjb2xvci1uZXh0Z2VuLXN0YXR1cy1lcnJvci1iYWNrZ3JvdW5kOiB2YXIoXHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy1lcnJvci1iYWNrZ3JvdW5kXHJcbik7XHJcbiRjb2xvci1uZXh0Z2VuLXN0YXR1cy13YXJuaW5nOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy13YXJuaW5nKTtcclxuJGNvbG9yLW5leHRnZW4tc3RhdHVzLXdhcm5pbmctYmFja2dyb3VuZDogdmFyKFxyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtd2FybmluZy1iYWNrZ3JvdW5kXHJcbik7XHJcbiRjb2xvci1uZXh0Z2VuLWJsdWUtMTAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWJsdWUtMTAwKTtcclxuJGNvbG9yLW5leHRnZW4tZXJyb3ItcmVkLTcwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1lcnJvci1yZWQtNzAwKTtcclxuJGNvbG9yLW5leHRnZW4tYmx1ZS01MDA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZS01MDApO1xyXG4kY29sb3ItbmV4dGdlbi1ibHVlLTQwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlLTQwMCk7XHJcbiRjb2xvci1uZXh0Z2VuLXJlZC01MDA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tcmVkLTUwMCk7XHJcbiRjb2xvci1uZXh0Z2VuLXNlY29uZGFyeS1ibHVlLTMwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1zZWNvbmRhcnktYmx1ZS0zMDApO1xyXG5cclxuLmlvbi1jb2xvci1ncmVlbiB7XHJcblx0LS1pb24tY29sb3ItYmFzZTogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbik7XHJcblx0LS1pb24tY29sb3ItYmFzZS1yZ2I6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4pO1xyXG5cdC0taW9uLWNvbG9yLWNvbnRyYXN0OiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXdoaXRlKTtcclxuXHQtLWlvbi1jb2xvci1jb250cmFzdC1yZ2I6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4pO1xyXG5cdC0taW9uLWNvbG9yLXNoYWRlOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuKTtcclxuXHQtLWlvbi1jb2xvci10aW50OiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuKTtcclxufVxyXG4iLCJAaW1wb3J0IFwiLi4vLi4vLi4vY29sb3Iuc2Nzc1wiO1xyXG5AaW1wb3J0IFwiLi4vLi4vLi4vc3R5bGUuc2Nzc1wiO1xyXG4ubmV3LWNsYWltLWNvbnRhaW5lciB7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAkY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNTA7XHJcbn0iLCIvKlxyXG4gKiAxLiBDdXN0b20gQ1NTIFxyXG4gKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcbiAqL1xyXG5cclxuLy8gY29sb3IgdmFyaWFibGVcclxuQGltcG9ydCBcIi4vY29sb3Iuc2Nzc1wiO1xyXG4vLyB0eXBvZ3JhcGh5XHJcbkBpbXBvcnQgXCIuL2ZvbnQtc2l6ZS5zY3NzXCI7XHJcblxyXG4vLyBGb250c1xyXG5AZm9udC1mYWNlIHtcclxuXHRmb250LWZhbWlseTogXCJBbGxpYW56IE5lb1wiO1xyXG5cdGZvbnQtc3R5bGU6IG5vcm1hbDtcclxuXHRmb250LXdlaWdodDogMzAwO1xyXG5cdGZvbnQtZGlzcGxheTogc3dhcDtcclxuXHRzcmM6IHVybChcIi4vYXNzZXRzL2ZvbnRzL0FsbGlhbnpOZW8vQWxsaWFuel9OZW9fd2ViZm9udHMvd29mZjIvQWxsaWFuek5lb1cwNC1MaWdodC53b2ZmMlwiKVxyXG5cdFx0XHRmb3JtYXQoXCJ3b2ZmMlwiKSxcclxuXHRcdHVybChcIi4vYXNzZXRzL2ZvbnRzL0FsbGlhbnpOZW8vQWxsaWFuel9OZW9fd2ViZm9udHMvd29mZi9BbGxpYW56TmVvVzA0LUxpZ2h0LndvZmZcIilcclxuXHRcdFx0Zm9ybWF0KFwid29mZlwiKTtcclxufVxyXG5cclxuQGZvbnQtZmFjZSB7XHJcblx0Zm9udC1mYW1pbHk6IFwiQWxsaWFueiBOZW9cIjtcclxuXHRmb250LXN0eWxlOiBpdGFsaWM7XHJcblx0Zm9udC13ZWlnaHQ6IDMwMDtcclxuXHRmb250LWRpc3BsYXk6IHN3YXA7XHJcblx0c3JjOiB1cmwoXCIuL2Fzc2V0cy9mb250cy9BbGxpYW56TmVvL0FsbGlhbnpfTmVvX3dlYmZvbnRzL3dvZmYyL0FsbGlhbnpOZW9XMDQtTGlnaHRJdGFsaWMud29mZjJcIilcclxuXHRcdFx0Zm9ybWF0KFwid29mZjJcIiksXHJcblx0XHR1cmwoXCIuL2Fzc2V0cy9mb250cy9BbGxpYW56TmVvL0FsbGlhbnpfTmVvX3dlYmZvbnRzL3dvZmYvQWxsaWFuek5lb1cwNC1MaWdodEl0YWxpYy53b2ZmXCIpXHJcblx0XHRcdGZvcm1hdChcIndvZmZcIik7XHJcbn1cclxuXHJcbkBmb250LWZhY2Uge1xyXG5cdGZvbnQtZmFtaWx5OiBcIkFsbGlhbnogTmVvXCI7XHJcblx0Zm9udC1zdHlsZTogbm9ybWFsO1xyXG5cdGZvbnQtd2VpZ2h0OiA0MDA7XHJcblx0Zm9udC1kaXNwbGF5OiBzd2FwO1xyXG5cdHNyYzogdXJsKFwiLi9hc3NldHMvZm9udHMvQWxsaWFuek5lby9BbGxpYW56X05lb193ZWJmb250cy93b2ZmMi9BbGxpYW56TmVvVzA0LVJlZ3VsYXIud29mZjJcIilcclxuXHRcdFx0Zm9ybWF0KFwid29mZjJcIiksXHJcblx0XHR1cmwoXCIuL2Fzc2V0cy9mb250cy9BbGxpYW56TmVvL0FsbGlhbnpfTmVvX3dlYmZvbnRzL3dvZmYvQWxsaWFuek5lb1cwNC1SZWd1bGFyLndvZmZcIilcclxuXHRcdFx0Zm9ybWF0KFwid29mZlwiKTtcclxufVxyXG5cclxuQGZvbnQtZmFjZSB7XHJcblx0Zm9udC1mYW1pbHk6IFwiQWxsaWFueiBOZW9cIjtcclxuXHRmb250LXN0eWxlOiBpdGFsaWM7XHJcblx0Zm9udC13ZWlnaHQ6IDQwMDtcclxuXHRmb250LWRpc3BsYXk6IHN3YXA7XHJcblx0c3JjOiB1cmwoXCIuL2Fzc2V0cy9mb250cy9BbGxpYW56TmVvL0FsbGlhbnpfTmVvX3dlYmZvbnRzL3dvZmYyL0FsbGlhbnpOZW9XMDQtSXRhbGljLndvZmYyXCIpXHJcblx0XHRcdGZvcm1hdChcIndvZmYyXCIpLFxyXG5cdFx0dXJsKFwiLi9hc3NldHMvZm9udHMvQWxsaWFuek5lby9BbGxpYW56X05lb193ZWJmb250cy93b2ZmL0FsbGlhbnpOZW9XMDQtSXRhbGljLndvZmZcIilcclxuXHRcdFx0Zm9ybWF0KFwid29mZlwiKTtcclxufVxyXG5cclxuQGZvbnQtZmFjZSB7XHJcblx0Zm9udC1mYW1pbHk6IFwiQWxsaWFueiBOZW9cIjtcclxuXHRmb250LXN0eWxlOiBub3JtYWw7XHJcblx0Zm9udC13ZWlnaHQ6IDYwMDtcclxuXHRmb250LWRpc3BsYXk6IHN3YXA7XHJcblx0c3JjOiB1cmwoXCIuL2Fzc2V0cy9mb250cy9BbGxpYW56TmVvL0FsbGlhbnpfTmVvX3dlYmZvbnRzL3dvZmYyL0FsbGlhbnpOZW9XMDQtU2VtaUJvbGQud29mZjJcIilcclxuXHRcdFx0Zm9ybWF0KFwid29mZjJcIiksXHJcblx0XHR1cmwoXCIuL2Fzc2V0cy9mb250cy9BbGxpYW56TmVvL0FsbGlhbnpfTmVvX3dlYmZvbnRzL3dvZmYvQWxsaWFuek5lb1cwNC1TZW1pQm9sZC53b2ZmXCIpXHJcblx0XHRcdGZvcm1hdChcIndvZmZcIik7XHJcbn1cclxuXHJcbkBmb250LWZhY2Uge1xyXG5cdGZvbnQtZmFtaWx5OiBcIkFsbGlhbnogTmVvXCI7XHJcblx0Zm9udC1zdHlsZTogaXRhbGljO1xyXG5cdGZvbnQtd2VpZ2h0OiA2MDA7XHJcblx0Zm9udC1kaXNwbGF5OiBzd2FwO1xyXG5cdHNyYzogdXJsKFwiLi9hc3NldHMvZm9udHMvQWxsaWFuek5lby9BbGxpYW56X05lb193ZWJmb250cy93b2ZmMi9BbGxpYW56TmVvVzA0LVNlbWlCb2xkSXQud29mZjJcIilcclxuXHRcdFx0Zm9ybWF0KFwid29mZjJcIiksXHJcblx0XHR1cmwoXCIuL2Fzc2V0cy9mb250cy9BbGxpYW56TmVvL0FsbGlhbnpfTmVvX3dlYmZvbnRzL3dvZmYvQWxsaWFuek5lb1cwNC1TZW1pQm9sZEl0LndvZmZcIilcclxuXHRcdFx0Zm9ybWF0KFwid29mZlwiKTtcclxufVxyXG5cclxuQGZvbnQtZmFjZSB7XHJcblx0Zm9udC1mYW1pbHk6IFwiQWxsaWFueiBOZW9cIjtcclxuXHRmb250LXN0eWxlOiBub3JtYWw7XHJcblx0Zm9udC13ZWlnaHQ6IDcwMDtcclxuXHRmb250LWRpc3BsYXk6IHN3YXA7XHJcblx0c3JjOiB1cmwoXCIuL2Fzc2V0cy9mb250cy9BbGxpYW56TmVvL0FsbGlhbnpfTmVvX3dlYmZvbnRzL3dvZmYyL0FsbGlhbnpOZW9XMDQtQm9sZC53b2ZmMlwiKVxyXG5cdFx0XHRmb3JtYXQoXCJ3b2ZmMlwiKSxcclxuXHRcdHVybChcIi4vYXNzZXRzL2ZvbnRzL0FsbGlhbnpOZW8vQWxsaWFuel9OZW9fd2ViZm9udHMvd29mZi9BbGxpYW56TmVvVzA0LUJvbGQud29mZlwiKVxyXG5cdFx0XHRmb3JtYXQoXCJ3b2ZmXCIpO1xyXG59XHJcblxyXG5AZm9udC1mYWNlIHtcclxuXHRmb250LWZhbWlseTogXCJBbGxpYW56IE5lb1wiO1xyXG5cdGZvbnQtc3R5bGU6IGl0YWxpYztcclxuXHRmb250LXdlaWdodDogNzAwO1xyXG5cdGZvbnQtZGlzcGxheTogc3dhcDtcclxuXHRzcmM6IHVybChcIi4vYXNzZXRzL2ZvbnRzL0FsbGlhbnpOZW8vQWxsaWFuel9OZW9fd2ViZm9udHMvd29mZjIvQWxsaWFuek5lb1cwNC1Cb2xkSXRhbGljLndvZmYyXCIpXHJcblx0XHRcdGZvcm1hdChcIndvZmYyXCIpLFxyXG5cdFx0dXJsKFwiLi9hc3NldHMvZm9udHMvQWxsaWFuek5lby9BbGxpYW56X05lb193ZWJmb250cy93b2ZmL0FsbGlhbnpOZW9XMDQtQm9sZEl0YWxpYy53b2ZmXCIpXHJcblx0XHRcdGZvcm1hdChcIndvZmZcIik7XHJcbn1cclxuXHJcbioge1xyXG5cdGNvbG9yOiAkY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXk7XHJcblx0Zm9udC1mYW1pbHk6IFwiQWxsaWFueiBOZW9cIiwgc2Fucy1zZXJpZjtcclxuXHRmb250LXdlaWdodDogNDAwO1xyXG5cdGZvbnQtc2l6ZTogMTZweDtcclxufVxyXG5cclxuaHRtbCB7XHJcblx0LS1pb24tc2FmZS1hcmVhLXRvcDogMHB4O1xyXG59XHJcblxyXG4uY29sLTEge1xyXG5cdHdpZHRoOiA4LjMzJTtcclxufVxyXG5cclxuLmNvbC0yIHtcclxuXHR3aWR0aDogMTYuNjYlO1xyXG59XHJcblxyXG4uY29sLTMge1xyXG5cdHdpZHRoOiAyNSU7XHJcbn1cclxuXHJcbi5jb2wtNCB7XHJcblx0d2lkdGg6IDMzLjMzJTtcclxufVxyXG5cclxuLmNvbC01IHtcclxuXHR3aWR0aDogNDEuNjYlO1xyXG59XHJcblxyXG4uY29sLTYge1xyXG5cdHdpZHRoOiA1MCU7XHJcbn1cclxuXHJcbi5jb2wtNyB7XHJcblx0d2lkdGg6IDU4LjMzJTtcclxufVxyXG5cclxuLmNvbC04IHtcclxuXHR3aWR0aDogNjYuNjYlO1xyXG59XHJcblxyXG4uY29sLTkge1xyXG5cdHdpZHRoOiA3NSU7XHJcbn1cclxuXHJcbi5jb2wtMTAge1xyXG5cdHdpZHRoOiA4My4zMyU7XHJcbn1cclxuXHJcbi5jb2wtMTEge1xyXG5cdHdpZHRoOiA5MS42NiU7XHJcbn1cclxuXHJcbi5jb2wtMTIge1xyXG5cdHdpZHRoOiAxMDAlO1xyXG59XHJcblxyXG5AbWVkaWEgb25seSBzY3JlZW4gYW5kIChtYXgtd2lkdGg6IDU3NnB4KSB7XHJcblx0LyogRm9yIHRhYmxldHM6ICovXHJcblx0LmNvbC1zbS0xIHtcclxuXHRcdHdpZHRoOiA4LjMzJTtcclxuXHR9XHJcblxyXG5cdC5jb2wtc20tMiB7XHJcblx0XHR3aWR0aDogMTYuNjYlO1xyXG5cdH1cclxuXHJcblx0LmNvbC1zbS0zIHtcclxuXHRcdHdpZHRoOiAyNSU7XHJcblx0fVxyXG5cclxuXHQuY29sLXNtLTQge1xyXG5cdFx0d2lkdGg6IDMzLjMzJTtcclxuXHR9XHJcblxyXG5cdC5jb2wtc20tNSB7XHJcblx0XHR3aWR0aDogNDEuNjYlO1xyXG5cdH1cclxuXHJcblx0LmNvbC1zbS02IHtcclxuXHRcdHdpZHRoOiA1MCU7XHJcblx0fVxyXG5cclxuXHQuY29sLXNtLTcge1xyXG5cdFx0d2lkdGg6IDU4LjMzJTtcclxuXHR9XHJcblxyXG5cdC5jb2wtc20tOCB7XHJcblx0XHR3aWR0aDogNjYuNjYlO1xyXG5cdH1cclxuXHJcblx0LmNvbC1zbS05IHtcclxuXHRcdHdpZHRoOiA3NSU7XHJcblx0fVxyXG5cclxuXHQuY29sLXNtLTEwIHtcclxuXHRcdHdpZHRoOiA4My4zMyU7XHJcblx0fVxyXG5cclxuXHQuY29sLXNtLTExIHtcclxuXHRcdHdpZHRoOiA5MS42NiU7XHJcblx0fVxyXG5cclxuXHQuY29sLXNtLTEyIHtcclxuXHRcdHdpZHRoOiAxMDAlO1xyXG5cdH1cclxufVxyXG5cclxuQG1lZGlhIG9ubHkgc2NyZWVuIGFuZCAobWF4LXdpZHRoOiA3NjhweCkgYW5kIChtaW4td2lkdGg6IDU3N3B4KSB7XHJcblx0LyogRm9yIHRhYmxldHM6ICovXHJcblx0LmNvbC1tZC0xIHtcclxuXHRcdHdpZHRoOiA4LjMzJTtcclxuXHR9XHJcblxyXG5cdC5jb2wtbWQtMiB7XHJcblx0XHR3aWR0aDogMTYuNjYlO1xyXG5cdH1cclxuXHJcblx0LmNvbC1tZC0zIHtcclxuXHRcdHdpZHRoOiAyNSU7XHJcblx0fVxyXG5cclxuXHQuY29sLW1kLTQge1xyXG5cdFx0d2lkdGg6IDMzLjMzJTtcclxuXHR9XHJcblxyXG5cdC5jb2wtbWQtNSB7XHJcblx0XHR3aWR0aDogNDEuNjYlO1xyXG5cdH1cclxuXHJcblx0LmNvbC1tZC02IHtcclxuXHRcdHdpZHRoOiA1MCU7XHJcblx0fVxyXG5cclxuXHQuY29sLW1kLTcge1xyXG5cdFx0d2lkdGg6IDU4LjMzJTtcclxuXHR9XHJcblxyXG5cdC5jb2wtbWQtOCB7XHJcblx0XHR3aWR0aDogNjYuNjYlO1xyXG5cdH1cclxuXHJcblx0LmNvbC1tZC05IHtcclxuXHRcdHdpZHRoOiA3NSU7XHJcblx0fVxyXG5cclxuXHQuY29sLW1kLTEwIHtcclxuXHRcdHdpZHRoOiA4My4zMyU7XHJcblx0fVxyXG5cclxuXHQuY29sLW1kLTExIHtcclxuXHRcdHdpZHRoOiA5MS42NiU7XHJcblx0fVxyXG5cclxuXHQuY29sLW1kLTEyIHtcclxuXHRcdHdpZHRoOiAxMDAlO1xyXG5cdH1cclxufVxyXG5cclxuQG1lZGlhIG9ubHkgc2NyZWVuIGFuZCAobWluLXdpZHRoOiA3NjlweCkge1xyXG5cdC8qIEZvciB0YWJsZXRzOiAqL1xyXG5cdC5jb2wtbGctMSB7XHJcblx0XHR3aWR0aDogOC4zMyU7XHJcblx0fVxyXG5cclxuXHQuY29sLWxnLTIge1xyXG5cdFx0d2lkdGg6IDE2LjY2JTtcclxuXHR9XHJcblxyXG5cdC5jb2wtbGctMyB7XHJcblx0XHR3aWR0aDogMjUlO1xyXG5cdH1cclxuXHJcblx0LmNvbC1sZy00IHtcclxuXHRcdHdpZHRoOiAzMy4zMyU7XHJcblx0fVxyXG5cclxuXHQuY29sLWxnLTUge1xyXG5cdFx0d2lkdGg6IDQxLjY2JTtcclxuXHR9XHJcblxyXG5cdC5jb2wtbGctNiB7XHJcblx0XHR3aWR0aDogNTAlO1xyXG5cdH1cclxuXHJcblx0LmNvbC1sZy03IHtcclxuXHRcdHdpZHRoOiA1OC4zMyU7XHJcblx0fVxyXG5cclxuXHQuY29sLWxnLTgge1xyXG5cdFx0d2lkdGg6IDY2LjY2JTtcclxuXHR9XHJcblxyXG5cdC5jb2wtbGctOSB7XHJcblx0XHR3aWR0aDogNzUlO1xyXG5cdH1cclxuXHJcblx0LmNvbC1sZy0xMCB7XHJcblx0XHR3aWR0aDogODMuMzMlO1xyXG5cdH1cclxuXHJcblx0LmNvbC1sZy0xMSB7XHJcblx0XHR3aWR0aDogOTEuNjYlO1xyXG5cdH1cclxuXHJcblx0LmNvbC1sZy0xMiB7XHJcblx0XHR3aWR0aDogMTAwJTtcclxuXHR9XHJcbn1cclxuXHJcbi5yb3cge1xyXG5cdGRpc3BsYXk6IGZsZXg7XHJcblx0anVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcblx0YWxpZ24taXRlbXM6IGNlbnRlcjtcclxufVxyXG5cclxuLy8gQ1NTXHJcbi5jdXN0b20tdG9hc3Qge1xyXG5cdC0tbWF4LXdpZHRoOiBmaXQtY29udGVudDtcclxufVxyXG5cclxuLypcclxuICogMi4gQ3VzdG9tIENTUyBmb3IgY29tcGF0aWJpbGl0eSB3aXRoIEVkZ2VcclxuICogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG4gKi9cclxuaW5wdXQ6Oi1tcy1yZXZlYWwsXHJcbmlucHV0OjotbXMtY2xlYXIge1xyXG5cdGRpc3BsYXk6IG5vbmU7XHJcbn1cclxuXHJcbi5zd2FsMi1wb3B1cCB7XHJcblx0bWFyZ2luLXRvcDogMjBweDtcclxufVxyXG5cclxuLypcclxuICogMy4gQ3VzdG9tIENTUyBmb3IgbG9hZGluZyBjb250cm9sbGVyXHJcbiAqIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuICovXHJcbi50cmFuc3BhcmVudC1sb2FkaW5nLWNsYXNzIHtcclxuXHQtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xyXG5cdC0tc3Bpbm5lci1jb2xvcjogIzQ3ZTZiMTtcclxufVxyXG5cclxuLmxvYWRpbmctd3JhcHBlci5zYy1pb24tbG9hZGluZy1tZCB7XHJcblx0Ym94LXNoYWRvdzogdW5zZXQ7XHJcblx0LXdlYmtpdC1ib3gtc2hhZG93OiB1bnNldDtcclxufVxyXG5cclxuLnVpbCB7XHJcblx0Y29sb3I6ICRjb2xvci1uZXh0Z2VuLWdyZXk7XHJcbn1cclxuXHJcbi5idG4ge1xyXG5cdGhlaWdodDogNDhweDtcclxuXHRib3JkZXItcmFkaXVzOiAyOHB4O1xyXG5cdHBhZGRpbmc6IDBweCA0MXB4IDBweCA0MXB4O1xyXG5cdGJveC1zaGFkb3c6IG5vbmU7XHJcblxyXG5cdCYuYnRuLWNpcmNsZSB7XHJcblx0XHRiYWNrZ3JvdW5kLWNvbG9yOiAkY29sb3ItbmV4dGdlbi1zdG9uZS1ncmV5ICFpbXBvcnRhbnQ7XHJcblx0XHRjb2xvcjogJGNvbG9yLW5leHRnZW4tYmxhY2s7XHJcblx0XHRwYWRkaW5nOiB1bnNldCAhaW1wb3J0YW50O1xyXG5cdFx0aGVpZ2h0OiAzNnB4ICFpbXBvcnRhbnQ7XHJcblx0XHR3aWR0aDogMzZweCAhaW1wb3J0YW50O1xyXG5cdFx0Ym9yZGVyLXJhZGl1czogNTAlICFpbXBvcnRhbnQ7XHJcblxyXG5cdFx0aSB7XHJcblx0XHRcdGNvbG9yOiAkY29sb3ItbmV4dGdlbi1ibGFjaztcclxuXHRcdH1cclxuXHR9XHJcblxyXG5cdCYucHJpbWFyeSB7XHJcblx0XHRiYWNrZ3JvdW5kOiAkY29sb3ItbmV4dGdlbi1ncmVlbjtcclxuXHRcdGNvbG9yOiAkY29sb3ItbmV4dGdlbi13aGl0ZTtcclxuXHJcblx0XHQudWlsIHtcclxuXHRcdFx0Y29sb3I6ICRjb2xvci1uZXh0Z2VuLXdoaXRlO1xyXG5cdFx0fVxyXG5cclxuXHRcdCY6ZGlzYWJsZWQge1xyXG5cdFx0XHRiYWNrZ3JvdW5kLWNvbG9yOiAkY29sb3ItbmV4dGdlbi1ncmV5LWJhY2tncm91bmQgIWltcG9ydGFudDtcclxuXHRcdFx0Y29sb3I6ICRjb2xvci1uZXh0Z2VuLWdyZXkgIWltcG9ydGFudDtcclxuXHRcdH1cclxuXHR9XHJcblxyXG5cdCYuc2Vjb25kYXJ5IHtcclxuXHRcdGJhY2tncm91bmQ6ICRjb2xvci1uZXh0Z2VuLXdoaXRlICFpbXBvcnRhbnQ7XHJcblx0XHRib3JkZXItY29sb3I6ICRjb2xvci1uZXh0Z2VuLWdyZWVuO1xyXG5cdFx0Ym9yZGVyOiBzb2xpZCAxcHg7XHJcblx0XHRjb2xvcjogJGNvbG9yLW5leHRnZW4tZ3JlZW47XHJcblxyXG5cdFx0LnVpbCB7XHJcblx0XHRcdGNvbG9yOiAkY29sb3ItbmV4dGdlbi1ncmVlbjtcclxuXHRcdH1cclxuXHJcblx0XHQmOmRpc2FibGVkIHtcclxuXHRcdFx0YmFja2dyb3VuZC1jb2xvcjogJGNvbG9yLW5leHRnZW4td2hpdGUgIWltcG9ydGFudDtcclxuXHRcdFx0Y29sb3I6ICRjb2xvci1uZXh0Z2VuLWdyZXkgIWltcG9ydGFudDtcclxuXHRcdFx0Ym9yZGVyLWNvbG9yOiAkY29sb3ItbmV4dGdlbi1ncmV5LWJhY2tncm91bmQgIWltcG9ydGFudDtcclxuXHRcdH1cclxuXHR9XHJcblxyXG5cdCYudHJhbnNwYXJlbnQge1xyXG5cdFx0YmFja2dyb3VuZDogdHJhbnNwYXJlbnQgIWltcG9ydGFudDtcclxuXHRcdGJvcmRlci1jb2xvcjogJGNvbG9yLW5leHRnZW4tZ3JlZW47XHJcblx0XHRib3JkZXI6IHNvbGlkIDFweDtcclxuXHRcdGNvbG9yOiAkY29sb3ItbmV4dGdlbi1ncmVlbjtcclxuXHJcblx0XHQudWlsIHtcclxuXHRcdFx0Y29sb3I6ICRjb2xvci1uZXh0Z2VuLWdyZWVuO1xyXG5cdFx0fVxyXG5cclxuXHRcdCY6ZGlzYWJsZWQge1xyXG5cdFx0XHRiYWNrZ3JvdW5kLWNvbG9yOiB0cmFuc3BhcmVudCAhaW1wb3J0YW50O1xyXG5cdFx0XHRjb2xvcjogJGNvbG9yLW5leHRnZW4tZ3JleSAhaW1wb3J0YW50O1xyXG5cdFx0XHRib3JkZXItY29sb3I6ICRjb2xvci1uZXh0Z2VuLWdyZXktYmFja2dyb3VuZCAhaW1wb3J0YW50O1xyXG5cdFx0fVxyXG5cdH1cclxuXHJcblx0Ji5idG4tbGFyZ2Uge1xyXG5cdFx0aGVpZ2h0OiA1NnB4ICFpbXBvcnRhbnQ7XHJcblx0XHR3aWR0aDogMTAwJTtcclxuXHR9XHJcblxyXG5cdCYuYm9sZCB7XHJcblx0XHRmb250LXdlaWdodDogNzAwICFpbXBvcnRhbnQ7XHJcblx0fVxyXG5cclxuXHQmLnNlbWlib2xkIHtcclxuXHRcdGZvbnQtd2VpZ2h0OiA2MDAgIWltcG9ydGFudDtcclxuXHR9XHJcbn1cclxuXHJcbi5idG4tbm8tc3BhY2Uge1xyXG5cdHBhZGRpbmc6IDVweCAhaW1wb3J0YW50O1xyXG5cdGhlaWdodDogZml0LWNvbnRlbnQ7XHJcbn1cclxuXHJcbi5idG4tYmFjayB7XHJcblx0d2lkdGg6IDMxcHg7XHJcblx0aGVpZ2h0OiAyOHB4O1xyXG5cdGJhY2tncm91bmQtY29sb3I6IHRyYW5zcGFyZW50O1xyXG5cdHBhZGRpbmc6IDA7XHJcblx0Y29sb3I6ICRjb2xvci1uZXh0Z2VuLWdyZWVuO1xyXG59XHJcblxyXG4uY29udGFpbmVyIHtcclxuXHRwYWRkaW5nOiAycmVtO1xyXG5cdGhlaWdodDogMTAwJTtcclxufVxyXG5cclxuLmJvZHktc2VjdGlvbiB7XHJcblx0d2lkdGg6IDEwMCU7XHJcblx0aGVpZ2h0OiA5NSU7XHJcblx0b3ZlcmZsb3cteTogYXV0bztcclxuXHRwb3NpdGlvbjogcmVsYXRpdmU7XHJcbn1cclxuXHJcbi50b3Atc2VjdGlvbiB7XHJcblx0d2lkdGg6IDEwMCU7XHJcblx0aGVpZ2h0OiAxMCU7XHJcblx0anVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xyXG5cdGRpc3BsYXk6IGZsZXg7XHJcblx0YWxpZ24taXRlbXM6IGNlbnRlcjtcclxufVxyXG5cclxuLmZvcm0tY29udHJvbCB7XHJcblx0cG9zaXRpb246IHJlbGF0aXZlO1xyXG5cdGhlaWdodDogODVweDtcclxuXHRtYXJnaW4tYm90dG9tOiA4cHg7XHJcbn1cclxuXHJcbi5jb250cm9sIHtcclxuXHRib3JkZXItcmFkaXVzOiA4cHg7XHJcblx0aGVpZ2h0OiA1NnB4O1xyXG5cdGJvcmRlcjogMXB4IHNvbGlkICRjb2xvci1uZXh0Z2VuLWdyZXktYmFja2dyb3VuZDtcclxuXHR3aWR0aDogMTAwJTtcclxuXHRwb3NpdGlvbjogYWJzb2x1dGU7XHJcblx0dG9wOiAzMnB4O1xyXG5cdGJhY2tncm91bmQtY29sb3I6ICRjb2xvci1uZXh0Z2VuLXdoaXRlO1xyXG5cclxuXHQmIHRhYmxlIHtcclxuXHRcdHRhYmxlLWxheW91dDogZml4ZWQ7XHJcblx0XHRib3JkZXItY29sbGFwc2U6IHVuc2V0O1xyXG5cdH1cclxuXHJcblx0JiBpbnB1dCB7XHJcblx0XHRoZWlnaHQ6IDU0cHg7XHJcblx0XHRib3JkZXI6IHVuc2V0O1xyXG5cdFx0Ym9yZGVyLXJhZGl1czogOHB4O1xyXG5cdFx0d2lkdGg6IG1heC1jb250ZW50O1xyXG5cdFx0d2lkdGg6IDEwMCU7XHJcblx0XHRwb2ludGVyLWV2ZW50czogYXV0bztcclxuXHRcdGJhY2tncm91bmQtY29sb3I6ICRjb2xvci1uZXh0Z2VuLXdoaXRlO1xyXG5cdH1cclxuXHJcblx0Ji50ZXh0YXJlYSB7XHJcblx0XHRoZWlnaHQ6IDEwOHB4O1xyXG5cdH1cclxuXHJcblx0JiB0ZXh0YXJlYSB7XHJcblx0XHRoZWlnaHQ6IDEwNnB4O1xyXG5cdFx0Ym9yZGVyOiB1bnNldDtcclxuXHRcdGJvcmRlci1yYWRpdXM6IDhweDtcclxuXHRcdHdpZHRoOiBtYXgtY29udGVudDtcclxuXHRcdHdpZHRoOiAxMDAlO1xyXG5cdFx0cG9pbnRlci1ldmVudHM6IGF1dG87XHJcblx0XHRyZXNpemU6IG5vbmU7XHJcblx0XHRiYWNrZ3JvdW5kLWNvbG9yOiAkY29sb3ItbmV4dGdlbi13aGl0ZTtcclxuXHR9XHJcblxyXG5cdCYgaW5wdXQ6Zm9jdXMge1xyXG5cdFx0b3V0bGluZTogbm9uZTtcclxuXHR9XHJcblxyXG5cdCY6Zm9jdXMtd2l0aGluIHtcclxuXHRcdGJvcmRlci1jb2xvcjogJGNvbG9yLW5leHRnZW4tZ3JlZW47XHJcblxyXG5cdFx0LmZpcnN0LWljb24ge1xyXG5cdFx0XHRkaXNwbGF5OiBub25lO1xyXG5cdFx0fVxyXG5cclxuXHRcdC5maXJzdC1pY29uLm5vbi1oaWRkZW4ge1xyXG5cdFx0XHRkaXNwbGF5OiB0YWJsZS1jZWxsO1xyXG5cdFx0fVxyXG5cdH1cclxuXHJcblx0LmZpcnN0LWljb24ge1xyXG5cdFx0d2lkdGg6IDMycHg7XHJcblx0XHR0ZXh0LWFsaWduOiBjZW50ZXI7XHJcblx0XHRwYWRkaW5nLWxlZnQ6IDhweDtcclxuXHJcblx0XHRpIHtcclxuXHRcdFx0Zm9udC1zaXplOiAyNHB4ICFpbXBvcnRhbnQ7XHJcblx0XHR9XHJcblx0fVxyXG5cclxuXHQuc2Vjb25kLWljb24ge1xyXG5cdFx0d2lkdGg6IDMycHg7XHJcblx0XHR0ZXh0LWFsaWduOiBjZW50ZXI7XHJcblx0XHQvLyBwYWRkaW5nLXJpZ2h0OiA4cHg7XHJcblxyXG5cdFx0aSB7XHJcblx0XHRcdGZvbnQtc2l6ZTogMjRweCAhaW1wb3J0YW50O1xyXG5cdFx0fVxyXG5cdH1cclxufVxyXG5cclxuLmNvbnRyb2w6Zm9jdXMtd2l0aGluIH4gZGl2IC5jb250cm9sLWxhYmVsIHtcclxuXHRjb2xvcjogJGNvbG9yLW5leHRnZW4tZ3JlZW47XHJcbn1cclxuXHJcbi5jb250cm9sLWVycm9yIHtcclxuXHQuY29udHJvbCB7XHJcblx0XHRib3JkZXItY29sb3I6ICRjb2xvci1uZXh0Z2VuLWVycm9yO1xyXG5cdH1cclxuXHJcblx0LmNvbnRyb2wtbGFiZWwge1xyXG5cdFx0Y29sb3I6ICRjb2xvci1uZXh0Z2VuLWVycm9yICFpbXBvcnRhbnQ7XHJcblx0fVxyXG59XHJcblxyXG4udmFsaWRhdGlvbi1zdW1tYXJ5IHtcclxuXHRsaSB7XHJcblx0XHRjb2xvcjogJGNvbG9yLW5leHRnZW4tZXJyb3IgIWltcG9ydGFudDtcclxuXHRcdGxpc3Qtc3R5bGU6IG5vbmU7XHJcblxyXG5cdFx0aSB7XHJcblx0XHRcdGNvbG9yOiAkY29sb3ItbmV4dGdlbi1lcnJvciAhaW1wb3J0YW50O1xyXG5cdFx0fVxyXG5cdH1cclxufVxyXG5cclxuLm1yLTEge1xyXG5cdG1hcmdpbi1yaWdodDogMC41cmVtO1xyXG59XHJcblxyXG4ubWItMSB7XHJcblx0bWFyZ2luLWJvdHRvbTogMC41cmVtO1xyXG59XHJcblxyXG4uZGlhbG9nLXBhbmUge1xyXG5cdHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuXHRwb2ludGVyLWV2ZW50czogYXV0bztcclxuXHRib3gtc2l6aW5nOiBib3JkZXItYm94O1xyXG5cdHotaW5kZXg6IDEwMDA7XHJcblx0ZGlzcGxheTogYmxvY2s7XHJcblx0bWF4LXdpZHRoOiAxMDAlO1xyXG5cdG1heC1oZWlnaHQ6IDEwMCU7XHJcbn1cclxuXHJcbi5vdmVybGF5LWJhY2tkcm9wIHtcclxuXHRiYWNrZ3JvdW5kLWNvbG9yOiAkY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXk7XHJcblx0b3BhY2l0eTogMC4yICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5kaWFsb2ctY29udGFpbmVyIHtcclxuXHRhbmltYXRpb246IGZhZGVJbiAwLjVzIGxpbmVhcjtcclxuXHRiYWNrZ3JvdW5kLWNvbG9yOiAkY29sb3ItbmV4dGdlbi13aGl0ZTtcclxufVxyXG5cclxuQGtleWZyYW1lcyBmYWRlSW4ge1xyXG5cdGZyb20ge1xyXG5cdFx0dHJhbnNmb3JtOiB0cmFuc2xhdGVZKDEwMCUpO1xyXG5cdH1cclxuXHJcblx0dG8ge1xyXG5cdFx0dHJhbnNmb3JtOiB0cmFuc2xhdGVZKDAlKTtcclxuXHR9XHJcbn1cclxuXHJcbi5lcnJvciB7XHJcblx0Y29sb3I6ICRjb2xvci1uZXh0Z2VuLWVycm9yO1xyXG5cclxuXHQmLmJhY2tncm91bmQge1xyXG5cdFx0YmFja2dyb3VuZC1jb2xvcjogJGNvbG9yLW5leHRnZW4tZXJyb3I7XHJcblx0fVxyXG59XHJcblxyXG4uc3VjY2VzcyB7XHJcblx0Y29sb3I6ICRjb2xvci1uZXh0Z2VuLWZpYnJhbnQtZ3JlZW47XHJcblxyXG5cdCYuYmFja2dyb3VuZCB7XHJcblx0XHRiYWNrZ3JvdW5kLWNvbG9yOiAkY29sb3ItbmV4dGdlbi1maWJyYW50LWdyZWVuO1xyXG5cdH1cclxufVxyXG5cclxuLndhcm5pbmcge1xyXG5cdGNvbG9yOiAkY29sb3ItbmV4dGdlbi13YXJuaW5nO1xyXG5cclxuXHQmLmJhY2tncm91bmQge1xyXG5cdFx0YmFja2dyb3VuZC1jb2xvcjogJGNvbG9yLW5leHRnZW4td2FybmluZztcclxuXHR9XHJcbn1cclxuXHJcbi5zZWxlY3Qge1xyXG5cdHdpZHRoOiAxMDAlO1xyXG5cdGhlaWdodDogNTRweDtcclxuXHRib3JkZXI6IHVuc2V0O1xyXG5cdGJvcmRlci1yYWRpdXM6IDhweDtcclxuXHRkaXNwbGF5OiBncmlkO1xyXG5cdGFwcGVhcmFuY2U6IG5vbmU7XHJcblx0Z3JpZC10ZW1wbGF0ZS1hcmVhczogXCJzZWxlY3RcIjtcclxuXHJcblx0Jjpmb2N1cyB7XHJcblx0XHRvdXRsaW5lOiB1bnNldDtcclxuXHR9XHJcbn1cclxuXHJcbi5jb2xvci1ibGFjayB7XHJcblx0Y29sb3I6ICRjb2xvci1uZXh0Z2VuLWJsYWNrO1xyXG59XHJcblxyXG4ubW9kYWwtZGVmYXVsdCB7XHJcblx0LS13aWR0aDogMTAwJTtcclxuXHQtLWhlaWdodDogMTAwJTtcclxufVxyXG5cclxuLmludGVncmF0aW9uLXBhbmVsIHtcclxuXHR3aWR0aDogMTAwJTtcclxuXHRoZWlnaHQ6IDEwMCU7XHJcblx0bWF4LXdpZHRoOiAxMDAlICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi52ZXJsb29wLWJ1dHRvbiB7XHJcblx0dmlzaWJpbGl0eTogaGlkZGVuO1xyXG59XHJcblxyXG4uYmFjay1hcmVhIHtcclxuXHRwb3NpdGlvbjogZml4ZWQ7XHJcblx0dG9wOiAwO1xyXG5cdHJpZ2h0OiAwO1xyXG5cdGhlaWdodDogNTBweDtcclxuXHR3aWR0aDogMTAwJTtcclxuXHRiYWNrZ3JvdW5kLWNvbG9yOiAkY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNTA7XHJcblx0ei1pbmRleDogOTk5OTk5OTtcclxuXHJcblx0Ji5pb3Mge1xyXG5cdFx0aGVpZ2h0OiA4MHB4O1xyXG5cdH1cclxufVxyXG5cclxuLnRpdGxlLXdpZGdldCB7XHJcblx0dGV4dC1hbGlnbjogY2VudGVyO1xyXG5cdHBvc2l0aW9uOiBzdGlja3k7XHJcblx0dG9wOiA0OHB4O1xyXG59XHJcblxyXG4uYnV0dG9uLWJhY2sge1xyXG5cdGJhY2tncm91bmQtY29sb3I6ICNmYWZhZmE7XHJcblx0aGVpZ2h0OiAzNnB4O1xyXG5cdHdpZHRoOiAzNnB4O1xyXG5cdGJvcmRlci1yYWRpdXM6IDUwJTtcclxuXHRwb3NpdGlvbjogYWJzb2x1dGU7XHJcblx0bGVmdDogMThweDtcclxuXHRib3R0b206IDRweDtcclxufVxyXG5cclxuLmljb24tY2xvc2Utd2lkZ2V0IHtcclxuXHRwb3NpdGlvbjogYWJzb2x1dGU7XHJcblx0ei1pbmRleDogMjUwO1xyXG5cdGxlZnQ6IDExcHg7XHJcblx0Ym90dG9tOiAxM3B4O1xyXG59XHJcblxyXG4uZGF0YS1kZWZhdWx0IHtcclxuXHRwb3NpdGlvbjogYWJzb2x1dGU7XHJcblx0dG9wOiA1MCU7XHJcblx0bGVmdDogNTAlO1xyXG5cdHRyYW5zZm9ybTogdHJhbnNsYXRlKC01MCUsIC01MCUpO1xyXG5cdHRleHQtYWxpZ246IGNlbnRlcjtcclxuXHRjb2xvcjogJGNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTQwMDtcclxuXHR6LWluZGV4OiAxMDAwO1xyXG59XHJcblxyXG4uYXZhYW1vX19pY29uIHtcclxuXHR2aXNpYmlsaXR5OiBoaWRkZW4gIWltcG9ydGFudDtcclxufVxyXG5cclxuLmF2YWFtb19fY2hhdF9fd2lkZ2V0LmlvcyB7XHJcblx0I2F2YWFtb19fcG9wdXAge1xyXG5cdFx0cGFkZGluZy10b3A6IDQwcHg7XHJcblx0fVxyXG59XHJcblxyXG4uZC1mbGV4IHtcclxuXHRkaXNwbGF5OiBmbGV4O1xyXG59XHJcblxyXG5uZXh0Y2FyZS1sYXlvdXQge1xyXG5cdGxlZnQ6IDA7XHJcblx0cmlnaHQ6IDA7XHJcblx0dG9wOiAwO1xyXG5cdGJvdHRvbTogMDtcclxuXHRkaXNwbGF5OiBmbGV4O1xyXG5cdHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuXHRmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG5cdGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcclxuXHRjb250YWluOiBsYXlvdXQgc2l6ZSBzdHlsZTtcclxuXHRvdmVyZmxvdzogaGlkZGVuO1xyXG5cdGJhY2tncm91bmQtY29sb3I6ICRjb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS01MDtcclxuXHRwYWRkaW5nLXJpZ2h0OiAyNHB4O1xyXG5cdHBhZGRpbmctbGVmdDogMjRweDtcclxufVxyXG5cclxuaW9uLWhlYWRlci5pb3MuaGVhZGVyLWlvcyB7XHJcblx0bWFyZ2luLXRvcDogNDBweDtcclxufVxyXG5cclxuLmhlYWRlci1pb3MgaW9uLXRvb2xiYXI6bGFzdC1vZi10eXBlIHtcclxuXHQtLWJvcmRlci13aWR0aDogMHB4ICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5oZWFkZXItbWQubWQ6OmFmdGVyIHtcclxuXHRkaXNwbGF5OiBub25lO1xyXG59XHJcblxyXG5pb24tdG9vbGJhciB7XHJcblx0cGFkZGluZy1yaWdodDogdW5zZXQgIWltcG9ydGFudDtcclxuXHRwYWRkaW5nLWxlZnQ6IHVuc2V0ICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbmkuaWNvbi1iYWNrIHtcclxuXHRjb250ZW50OiB1cmwoYXNzZXRzL2ljb24vbG9uZy1hcnJvdy1sZWZ0LWljb24uc3ZnKTtcclxufVxyXG5cclxuLnZlcmxvb3Atd2lkZ2V0LmlvcyB7XHJcblx0LnZlcmxvb3AtY29udGFpbmVyLnZpc2libGUge1xyXG5cdFx0aGVpZ2h0OiBjYWxjKDEwMCUgLSA0MHB4KTtcclxuXHRcdHRvcDogNDBweDtcclxuXHR9XHJcbn1cclxuXHJcbiNuZXh0Y2FyZS1hZHMge1xyXG5cdGRpc3BsYXk6IG5vbmU7XHJcblx0b3ZlcmZsb3c6IHNjcm9sbDtcclxuXHRoZWlnaHQ6IDE4MHB4O1xyXG59XHJcblxyXG4uZC1ibG9jayB7XHJcblx0ZGlzcGxheTogYmxvY2s7XHJcbn1cclxuXHJcbi50aXRsZS10ZXh0IHtcclxuXHRjb2xvcjogJGNvbG9yLW5leHRnZW4tYmx1ZTtcclxufVxyXG5cclxuOmhvc3QgaW9uLWRhdGV0aW1lICNzaGFkb3ctcm9vdCB7XHJcblx0LmRhdGV0aW1lLWNhbGVuZGFyIHtcclxuXHRcdC5jYWxlbmRhci1oZWFkZXIge1xyXG5cdFx0XHQuY2FsZW5kYXItYWN0aW9uLWJ1dHRvbnMge1xyXG5cdFx0XHRcdC5jYWxlbmRhci1tb250aC15ZWFyIHtcclxuXHRcdFx0XHRcdGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcblx0XHRcdFx0XHRqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuXHRcdFx0XHRcdGRpc3BsYXk6IGZsZXg7XHJcblx0XHRcdFx0XHR3aWR0aDogMTAwJTtcclxuXHJcblx0XHRcdFx0XHRpb24taWNvbiB7XHJcblx0XHRcdFx0XHRcdGRpc3BsYXk6IG5vbmU7XHJcblx0XHRcdFx0XHR9XHJcblx0XHRcdFx0fVxyXG5cclxuXHRcdFx0XHQuY2FsZW5kYXItbmV4dC1wcmV2IHtcclxuXHRcdFx0XHRcdHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuXHRcdFx0XHRcdHdpZHRoOiAxMDAlO1xyXG5cdFx0XHRcdFx0cmlnaHQ6IDA7XHJcblxyXG5cdFx0XHRcdFx0aW9uLWJ1dHRvbnMge1xyXG5cdFx0XHRcdFx0XHRkaXNwbGF5OiBmbGV4O1xyXG5cdFx0XHRcdFx0XHRqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XHJcblx0XHRcdFx0XHRcdHdpZHRoOiAxMDAlO1xyXG5cdFx0XHRcdFx0fVxyXG5cdFx0XHRcdH1cclxuXHRcdFx0fVxyXG5cdFx0fVxyXG5cdH1cclxufVxyXG5cclxuLm1hdC1kaWFsb2ctY29udGFpbmVyIHtcclxuXHRwYWRkaW5nOiB1bnNldCAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4vKiBDaGFuZ2UgYXV0b2NvbXBsZXRlIHN0eWxlcyBpbiBXZWJLaXQgKi9cclxuaW5wdXQ6LXdlYmtpdC1hdXRvZmlsbCxcclxuaW5wdXQ6LXdlYmtpdC1hdXRvZmlsbDpob3ZlcixcclxuaW5wdXQ6LXdlYmtpdC1hdXRvZmlsbDpmb2N1cyxcclxudGV4dGFyZWE6LXdlYmtpdC1hdXRvZmlsbCxcclxudGV4dGFyZWE6LXdlYmtpdC1hdXRvZmlsbDpob3ZlcixcclxudGV4dGFyZWE6LXdlYmtpdC1hdXRvZmlsbDpmb2N1cyxcclxuc2VsZWN0Oi13ZWJraXQtYXV0b2ZpbGwsXHJcbnNlbGVjdDotd2Via2l0LWF1dG9maWxsOmhvdmVyLFxyXG5zZWxlY3Q6LXdlYmtpdC1hdXRvZmlsbDpmb2N1cyB7XHJcblx0LXdlYmtpdC10ZXh0LWZpbGwtY29sb3I6IGJsYWNrO1xyXG5cdC13ZWJraXQtYm94LXNoYWRvdzogMCAwIDBweCAxMDAwcHggd2hpdGUgaW5zZXQ7XHJcblx0dHJhbnNpdGlvbjogYmFja2dyb3VuZC1jb2xvciA1MDAwcyBlYXNlLWluLW91dCAwcztcclxufVxyXG5cclxuLmZvcmNlLXVwZGF0ZS1wb3B1cCArIC5jZGstZ2xvYmFsLW92ZXJsYXktd3JhcHBlciB7XHJcblx0LnNhdmUtYnRuIHtcclxuXHRcdGJhY2tncm91bmQ6IHZhcigtLWx1bWktcHJpbWFyeS15ZWxsb3ctY29sb3IpICFpbXBvcnRhbnQ7XHJcblx0XHRjb2xvcjogdmFyKC0tbHVtaS13aGl0ZS1jb2xvcikgIWltcG9ydGFudDtcclxuXHRcdGZvbnQtd2VpZ2h0OiBib2xkICFpbXBvcnRhbnQ7XHJcblx0fVxyXG5cclxuXHQuY2FuY2VsLWJ0biB7XHJcblx0XHRjb2xvcjogdmFyKC0tbHVtaS1wcmltYXJ5LXllbGxvdy1jb2xvcikgIWltcG9ydGFudDtcclxuXHR9XHJcbn1cclxuXHJcbkAtd2Via2l0LWtleWZyYW1lcyBzbGlkZUluUmlnaHQge1xyXG5cdDAlIHtcclxuXHRcdC13ZWJraXQtdHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgxMDAlLCAwLCAwKTtcclxuXHRcdHRyYW5zZm9ybTogdHJhbnNsYXRlM2QoMTAwJSwgMCwgMCk7XHJcblx0XHR2aXNpYmlsaXR5OiB2aXNpYmxlO1xyXG5cdH1cclxuXHJcblx0dG8ge1xyXG5cdFx0LXdlYmtpdC10cmFuc2Zvcm06IHRyYW5zbGF0ZVooMCk7XHJcblx0XHR0cmFuc2Zvcm06IHRyYW5zbGF0ZVooMCk7XHJcblx0fVxyXG59XHJcblxyXG5Aa2V5ZnJhbWVzIHNsaWRlSW5SaWdodCB7XHJcblx0MCUge1xyXG5cdFx0LXdlYmtpdC10cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKDEwMCUsIDAsIDApO1xyXG5cdFx0dHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgxMDAlLCAwLCAwKTtcclxuXHRcdHZpc2liaWxpdHk6IHZpc2libGU7XHJcblx0fVxyXG5cclxuXHR0byB7XHJcblx0XHQtd2Via2l0LXRyYW5zZm9ybTogdHJhbnNsYXRlWigwKTtcclxuXHRcdHRyYW5zZm9ybTogdHJhbnNsYXRlWigwKTtcclxuXHR9XHJcbn1cclxuXHJcbi5hbmltYXRlX19zbGlkZUluUmlnaHQge1xyXG5cdC13ZWJraXQtYW5pbWF0aW9uLW5hbWU6IHNsaWRlSW5SaWdodDtcclxuXHRhbmltYXRpb24tbmFtZTogc2xpZGVJblJpZ2h0O1xyXG59XHJcblxyXG4uYW5pbWF0ZV9fYW5pbWF0ZWQge1xyXG5cdC13ZWJraXQtYW5pbWF0aW9uLWR1cmF0aW9uOiAwLjVzO1xyXG5cdGFuaW1hdGlvbi1kdXJhdGlvbjogMC41cztcclxuXHQtd2Via2l0LWFuaW1hdGlvbi1kdXJhdGlvbjogMC41cztcclxuXHRhbmltYXRpb24tZHVyYXRpb246IDAuNXM7XHJcblx0LXdlYmtpdC1hbmltYXRpb24tZmlsbC1tb2RlOiBib3RoO1xyXG5cdGFuaW1hdGlvbi1maWxsLW1vZGU6IGJvdGg7XHJcbn1cclxuIiwiLmRpc3BsYXkteGwge1xyXG4gICAgZm9udC1zaXplOiA0MXB4ICFpbXBvcnRhbnQ7XHJcbiAgICBmb250LXdlaWdodDogNDAwICFpbXBvcnRhbnQ7XHJcbiAgICBsaW5lLWhlaWdodDogMTIwJSAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4uZGlzcGxheS1tZCB7XHJcbiAgICBmb250LXNpemU6IDM2cHggIWltcG9ydGFudDtcclxuICAgIGZvbnQtd2VpZ2h0OiA0MDAgIWltcG9ydGFudDtcclxuICAgIGxpbmUtaGVpZ2h0OiAxMjAlICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5oMSB7XHJcbiAgICBmb250LXNpemU6IDMxcHggIWltcG9ydGFudDtcclxuICAgIGZvbnQtd2VpZ2h0OiA0MDAgIWltcG9ydGFudDtcclxuICAgIGxpbmUtaGVpZ2h0OiAxMjAlICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5oMiB7XHJcbiAgICBmb250LXNpemU6IDI4cHggIWltcG9ydGFudDtcclxuICAgIGZvbnQtd2VpZ2h0OiA0MDAgIWltcG9ydGFudDtcclxuICAgIGxpbmUtaGVpZ2h0OiAxMjAlICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5oMyB7XHJcbiAgICBmb250LXNpemU6IDI1cHggIWltcG9ydGFudDtcclxuICAgIGZvbnQtd2VpZ2h0OiA0MDAgIWltcG9ydGFudDtcclxuICAgIGxpbmUtaGVpZ2h0OiAxMjAlICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5oNCB7XHJcbiAgICBmb250LXNpemU6IDIycHggIWltcG9ydGFudDtcclxuICAgIGZvbnQtd2VpZ2h0OiA0MDAgIWltcG9ydGFudDtcclxuICAgIGxpbmUtaGVpZ2h0OiAxMjAlICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5oNSB7XHJcbiAgICBmb250LXNpemU6IDE5cHggIWltcG9ydGFudDtcclxuICAgIGZvbnQtd2VpZ2h0OiA0MDAgIWltcG9ydGFudDtcclxuICAgIGxpbmUtaGVpZ2h0OiAxMjAlICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5oNiB7XHJcbiAgICBmb250LXNpemU6IDE3cHggIWltcG9ydGFudDtcclxuICAgIGZvbnQtd2VpZ2h0OiA0MDAgIWltcG9ydGFudDtcclxuICAgIGxpbmUtaGVpZ2h0OiAxMjAlICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5ib2R5LWwge1xyXG4gICAgZm9udC1zaXplOiAxN3B4ICFpbXBvcnRhbnQ7XHJcbiAgICBmb250LXdlaWdodDogNDAwICFpbXBvcnRhbnQ7XHJcbiAgICBsaW5lLWhlaWdodDogMTIwJSAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4uYm9keS1uIHtcclxuICAgIGZvbnQtc2l6ZTogMTVweCAhaW1wb3J0YW50O1xyXG4gICAgZm9udC13ZWlnaHQ6IDQwMCAhaW1wb3J0YW50O1xyXG4gICAgbGluZS1oZWlnaHQ6IDEyMCUgIWltcG9ydGFudDtcclxufVxyXG5cclxuLmJvZHktc20ge1xyXG4gICAgZm9udC1zaXplOiAxM3B4ICFpbXBvcnRhbnQ7XHJcbiAgICBmb250LXdlaWdodDogNDAwICFpbXBvcnRhbnQ7XHJcbiAgICBsaW5lLWhlaWdodDogMTIwJSAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4uYm9keS14cyB7XHJcbiAgICBmb250LXNpemU6IDEycHggIWltcG9ydGFudDtcclxuICAgIGZvbnQtd2VpZ2h0OiA0MDAgIWltcG9ydGFudDtcclxuICAgIGxpbmUtaGVpZ2h0OiAxMjAlICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5zZW1pYm9sZCB7XHJcbiAgICAmLmRpc3BsYXkteGwge1xyXG4gICAgICAgIGZvbnQtd2VpZ2h0OiA2MDAgIWltcG9ydGFudDtcclxuICAgIH1cclxuICAgICYuZGlzcGxheS1tZCB7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IDYwMCAhaW1wb3J0YW50O1xyXG4gICAgfVxyXG4gICAgJi5oMSB7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IDYwMCAhaW1wb3J0YW50O1xyXG4gICAgfVxyXG4gICAgJi5oMiB7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IDYwMCAhaW1wb3J0YW50O1xyXG4gICAgfVxyXG4gICAgJi5oMyB7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IDYwMCAhaW1wb3J0YW50O1xyXG4gICAgfVxyXG4gICAgJi5oNCB7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IDYwMCAhaW1wb3J0YW50O1xyXG4gICAgfVxyXG4gICAgJi5oNSB7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IDYwMCAhaW1wb3J0YW50O1xyXG4gICAgfVxyXG4gICAgJi5oNiB7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IDYwMCAhaW1wb3J0YW50O1xyXG4gICAgfVxyXG4gICAgJi5ib2R5LWwge1xyXG4gICAgICAgIGZvbnQtd2VpZ2h0OiA2MDAgIWltcG9ydGFudDtcclxuICAgIH1cclxuICAgICYuYm9keS1uIHtcclxuICAgICAgICBmb250LXdlaWdodDogNjAwICFpbXBvcnRhbnQ7XHJcbiAgICB9XHJcbiAgICAmLmJvZHktc20ge1xyXG4gICAgICAgIGZvbnQtd2VpZ2h0OiA2MDAgIWltcG9ydGFudDtcclxuICAgIH1cclxuICAgICYuYm9keS14cyB7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IDYwMCAhaW1wb3J0YW50O1xyXG4gICAgfVxyXG59XHJcblxyXG4uYm9sZCB7XHJcbiAgICAmLmRpc3BsYXkteGwge1xyXG4gICAgICAgIGZvbnQtd2VpZ2h0OiA3MDAgIWltcG9ydGFudDtcclxuICAgIH1cclxuICAgICYuZGlzcGxheS1tZCB7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IDcwMCAhaW1wb3J0YW50O1xyXG4gICAgfVxyXG4gICAgJi5oMSB7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IDcwMCAhaW1wb3J0YW50O1xyXG4gICAgfVxyXG4gICAgJi5oMiB7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IDcwMCAhaW1wb3J0YW50O1xyXG4gICAgfVxyXG4gICAgJi5oMyB7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IDcwMCAhaW1wb3J0YW50O1xyXG4gICAgfVxyXG4gICAgJi5oNCB7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IDcwMCAhaW1wb3J0YW50O1xyXG4gICAgfVxyXG4gICAgJi5oNSB7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IDcwMCAhaW1wb3J0YW50O1xyXG4gICAgfVxyXG4gICAgJi5oNiB7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IDcwMCAhaW1wb3J0YW50O1xyXG4gICAgfVxyXG4gICAgJi5ib2R5LWwge1xyXG4gICAgICAgIGZvbnQtd2VpZ2h0OiA3MDAgIWltcG9ydGFudDtcclxuICAgIH1cclxuICAgICYuYm9keS1uIHtcclxuICAgICAgICBmb250LXdlaWdodDogNzAwICFpbXBvcnRhbnQ7XHJcbiAgICB9XHJcbiAgICAmLmJvZHktc20ge1xyXG4gICAgICAgIGZvbnQtd2VpZ2h0OiA3MDAgIWltcG9ydGFudDtcclxuICAgIH1cclxuICAgICYuYm9keS14cyB7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IDcwMCAhaW1wb3J0YW50O1xyXG4gICAgfVxyXG59Il19 */";

/***/ }),

/***/ 94173:
/*!******************************************************************************************************!*\
  !*** ./src/app/pages/new-pre-approval/review-and-submit/review-and-submit.component.scss?ngResource ***!
  \******************************************************************************************************/
/***/ ((module) => {

module.exports = ":root {\n  --nc-color-nextgen-neutral-grey-50: #f1efef;\n  --nc-color-nextgen-white: #ffffff;\n  --nc-color-nextgen-blue: #0d152e;\n  --nc-color-nextgen-green: #00908d;\n  --nc-color-nextgen-black: #000000;\n  --nc-color-nextgen-grey-background: #c8d3da;\n  --nc-color-nextgen-grey: #92a2ac;\n  --nc-color-nextgen-stone-grey: #fafafa;\n  --nc-color-nextgen-error: #fc1055;\n  --nc-color-nextgen-neutral-grey: #414141;\n  --nc-color-nextgen-fibrant-green: #00bab6;\n  --nc-color-nextgen-warning: #ffd048;\n  --nc-color-nextgen-green-background: #e6f2f2;\n  --nc-color-nextgen-neutral-grey-400: #7a7a7a;\n  --nc-color-nextgen-neutral-grey-100: #eff3f5;\n  --nc-color-nextgen-status-error: #ba0c3f;\n  --nc-color-nextgen-status-error-background: #ffeff4;\n  --nc-color-nextgen-status-warning: #cba127;\n  --nc-color-nextgen-status-warning-background: #fff8e6;\n  --nc-color-nextgen-blue-100: #dfeff2;\n  --nc-color-nextgen-error-red-700: #f62459;\n  --nc-color-nextgen-blue-500: #006192;\n  --nc-color-nextgen-blue-400: #79cdec;\n  --nc-color-nextgen-red-500: #ff6592;\n  --nc-color-nextgen-secondary-blue-300: #13a0d3;\n  --lumi-white-color: #ffffff;\n  --lumi-primary-yellow-color: #fab600;\n}\n\n.ion-color-green {\n  --ion-color-base: var(--nc-color-nextgen-green);\n  --ion-color-base-rgb: var(--nc-color-nextgen-green);\n  --ion-color-contrast: var(--nc-color-nextgen-white);\n  --ion-color-contrast-rgb: var(--nc-color-nextgen-green);\n  --ion-color-shade: var(--nc-color-nextgen-green);\n  --ion-color-tint: var(--nc-color-nextgen-green);\n}\n\n.menu-content {\n  --background: #F1EFEF;\n}\n\n.menu-content .body {\n  margin-bottom: 128px;\n}\n\n.menu-content .body .review-text {\n  padding-top: 0.5rem;\n  color: var(--nc-color-nextgen-blue);\n}\n\n.menu-content .body .review-detail {\n  margin-top: 1rem;\n  padding: 1rem;\n  background-color: var(--nc-color-nextgen-white);\n  border-radius: 8px;\n  box-shadow: 0px 1px 2px rgba(0, 0, 0, 0.1);\n}\n\n.menu-content .body .review-detail .review-detail-title {\n  display: flex;\n  align-content: space-between;\n  justify-content: space-between;\n}\n\n.menu-content .body .review-detail .review-detail-title .title-text {\n  color: var(--nc-color-nextgen-grey);\n  padding-left: 0.5rem;\n  padding-bottom: 1rem;\n  text-transform: uppercase;\n}\n\n.menu-content .body .review-detail .border-box {\n  border-bottom: 1px solid #EFF3F5;\n  width: 100%;\n  margin-bottom: 0.5rem;\n}\n\n.menu-content .body .review-detail .review-detail-subtitle {\n  padding-top: 0.5rem;\n  padding-bottom: 0.5rem;\n  padding-left: 0.5rem;\n}\n\n.menu-content .body .review-detail .review-detail-subtitle .review-detail-text {\n  color: var(--nc-color-nextgen-neutral-grey-400);\n}\n\n.menu-content .body .review-detail .review-detail-subtitle .review-detail-content {\n  color: var(--nc-color-nextgen-blue);\n  padding-top: 1rem;\n}\n\n.menu-content .body .review-detail .review-detail-subtitle .document-text {\n  color: var(--nc-color-nextgen-blue);\n}\n\n.menu-content .body .review-detail .review-detail-subtitle .document-content {\n  color: var(--nc-color-nextgen-neutral-grey);\n  padding-top: 1rem;\n}\n\n.menu-content .body .review-detail .review-detail-subtitle .no-file {\n  padding-top: 1rem;\n  color: var(--nc-color-nextgen-error-red-700);\n}\n\n.menu-content .body .review-detail .review-detail-subtitle .documents-add {\n  color: var(--nc-color-nextgen-error-red-700);\n}\n\n.menu-content .body .review-detail .uil-edit:before {\n  content: \"\\e990\";\n  color: var(--nc-color-nextgen-grey);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFxjb2xvci5zY3NzIiwicmV2aWV3LWFuZC1zdWJtaXQuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDQywyQ0FBQTtFQUNBLGlDQUFBO0VBQ0EsZ0NBQUE7RUFDQSxpQ0FBQTtFQUNBLGlDQUFBO0VBQ0EsMkNBQUE7RUFDQSxnQ0FBQTtFQUNBLHNDQUFBO0VBQ0EsaUNBQUE7RUFDQSx3Q0FBQTtFQUNBLHlDQUFBO0VBQ0EsbUNBQUE7RUFDQSw0Q0FBQTtFQUNBLDRDQUFBO0VBQ0EsNENBQUE7RUFDQSx3Q0FBQTtFQUNBLG1EQUFBO0VBQ0EsMENBQUE7RUFDQSxxREFBQTtFQUNBLG9DQUFBO0VBQ0EseUNBQUE7RUFDQSxvQ0FBQTtFQUNBLG9DQUFBO0VBQ0EsbUNBQUE7RUFDQSw4Q0FBQTtFQUVBLDJCQUFBO0VBQ0Esb0NBQUE7QUNBRDs7QURnQ0E7RUFDQywrQ0FBQTtFQUNBLG1EQUFBO0VBQ0EsbURBQUE7RUFDQSx1REFBQTtFQUNBLGdEQUFBO0VBQ0EsK0NBQUE7QUM3QkQ7O0FBcENBO0VBQ0kscUJBQUE7QUF1Q0o7O0FBdENJO0VBQ0ksb0JBQUE7QUF3Q1I7O0FBdENRO0VBQ0ksbUJBQUE7RUFDQSxtQ0RzQlM7QUNrQnJCOztBQXRDUTtFQUNJLGdCQUFBO0VBQ0EsYUFBQTtFQUNBLCtDRG1CVTtFQ2xCVixrQkFBQTtFQUNBLDBDQUFBO0FBd0NaOztBQXZDWTtFQUNJLGFBQUE7RUFDQSw0QkFBQTtFQUNBLDhCQUFBO0FBeUNoQjs7QUF4Q2dCO0VBQ0ksbUNEY0M7RUNiRCxvQkFBQTtFQUNBLG9CQUFBO0VBQ0EseUJBQUE7QUEwQ3BCOztBQXZDWTtFQUNJLGdDQUFBO0VBQ0EsV0FBQTtFQUNBLHFCQUFBO0FBeUNoQjs7QUF2Q1k7RUFDSSxtQkFBQTtFQUNBLHNCQUFBO0VBQ0Esb0JBQUE7QUF5Q2hCOztBQXhDZ0I7RUFDSSwrQ0RNYTtBQ29DakM7O0FBeENnQjtFQUNJLG1DRFZDO0VDV0QsaUJBQUE7QUEwQ3BCOztBQXhDZ0I7RUFDSSxtQ0RkQztBQ3dEckI7O0FBeENnQjtFQUNJLDJDRFRTO0VDVVQsaUJBQUE7QUEwQ3BCOztBQXhDZ0I7RUFDSSxpQkFBQTtFQUNBLDRDREVVO0FDd0M5Qjs7QUF4Q2dCO0VBQ0ksNENERFU7QUMyQzlCOztBQXZDWTtFQUNJLGdCQUFBO0VBQ0EsbUNEekJLO0FDa0VyQiIsImZpbGUiOiJyZXZpZXctYW5kLXN1Ym1pdC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIjpyb290IHtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTUwOiAjZjFlZmVmO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi13aGl0ZTogI2ZmZmZmZjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZTogIzBkMTUyZTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW46ICMwMDkwOGQ7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWJsYWNrOiAjMDAwMDAwO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ncmV5LWJhY2tncm91bmQ6ICNjOGQzZGE7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWdyZXk6ICM5MmEyYWM7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0b25lLWdyZXk6ICNmYWZhZmE7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWVycm9yOiAjZmMxMDU1O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXk6ICM0MTQxNDE7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWZpYnJhbnQtZ3JlZW46ICMwMGJhYjY7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXdhcm5pbmc6ICNmZmQwNDg7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuLWJhY2tncm91bmQ6ICNlNmYyZjI7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS00MDA6ICM3YTdhN2E7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS0xMDA6ICNlZmYzZjU7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy1lcnJvcjogI2JhMGMzZjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yLWJhY2tncm91bmQ6ICNmZmVmZjQ7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy13YXJuaW5nOiAjY2JhMTI3O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtd2FybmluZy1iYWNrZ3JvdW5kOiAjZmZmOGU2O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlLTEwMDogI2RmZWZmMjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tZXJyb3ItcmVkLTcwMDogI2Y2MjQ1OTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZS01MDA6ICMwMDYxOTI7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWJsdWUtNDAwOiAjNzljZGVjO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1yZWQtNTAwOiAjZmY2NTkyO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zZWNvbmRhcnktYmx1ZS0zMDA6ICMxM2EwZDM7XHJcblxyXG5cdC0tbHVtaS13aGl0ZS1jb2xvcjogI2ZmZmZmZjtcclxuXHQtLWx1bWktcHJpbWFyeS15ZWxsb3ctY29sb3I6ICNmYWI2MDA7XHJcbn1cclxuJGNvbG9yLW5leHRnZW4tYmx1ZTogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlKTtcclxuJGNvbG9yLW5leHRnZW4tZ3JlZW46IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4pO1xyXG4kY29sb3ItbmV4dGdlbi13aGl0ZTogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi13aGl0ZSk7XHJcbiRjb2xvci1uZXh0Z2VuLWJsYWNrOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWJsYWNrKTtcclxuJGNvbG9yLW5leHRnZW4tZ3JleS1iYWNrZ3JvdW5kOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZXktYmFja2dyb3VuZCk7XHJcbiRjb2xvci1uZXh0Z2VuLWdyZXk6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JleSk7XHJcbiRjb2xvci1uZXh0Z2VuLXN0b25lLWdyZXk6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tc3RvbmUtZ3JleSk7XHJcbiRjb2xvci1uZXh0Z2VuLWVycm9yOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWVycm9yKTtcclxuJGNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5OiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleSk7XHJcbiRjb2xvci1uZXh0Z2VuLWZpYnJhbnQtZ3JlZW46IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZmlicmFudC1ncmVlbik7XHJcbiRjb2xvci1uZXh0Z2VuLXdhcm5pbmc6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4td2FybmluZyk7XHJcbiRjb2xvci1uZXh0Z2VuLWdyZWVuLWJhY2tncm91bmQ6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4tYmFja2dyb3VuZCk7XHJcbiRjb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS01MDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNTApO1xyXG4kY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNDAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS00MDApO1xyXG4kY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktMTAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS0xMDApO1xyXG4kY29sb3ItbmV4dGdlbi1zdGF0dXMtZXJyb3I6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yKTtcclxuJGNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yLWJhY2tncm91bmQ6IHZhcihcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yLWJhY2tncm91bmRcclxuKTtcclxuJGNvbG9yLW5leHRnZW4tc3RhdHVzLXdhcm5pbmc6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLXdhcm5pbmcpO1xyXG4kY29sb3ItbmV4dGdlbi1zdGF0dXMtd2FybmluZy1iYWNrZ3JvdW5kOiB2YXIoXHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy13YXJuaW5nLWJhY2tncm91bmRcclxuKTtcclxuJGNvbG9yLW5leHRnZW4tYmx1ZS0xMDA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZS0xMDApO1xyXG4kY29sb3ItbmV4dGdlbi1lcnJvci1yZWQtNzAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWVycm9yLXJlZC03MDApO1xyXG4kY29sb3ItbmV4dGdlbi1ibHVlLTUwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlLTUwMCk7XHJcbiRjb2xvci1uZXh0Z2VuLWJsdWUtNDAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWJsdWUtNDAwKTtcclxuJGNvbG9yLW5leHRnZW4tcmVkLTUwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1yZWQtNTAwKTtcclxuJGNvbG9yLW5leHRnZW4tc2Vjb25kYXJ5LWJsdWUtMzAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXNlY29uZGFyeS1ibHVlLTMwMCk7XHJcblxyXG4uaW9uLWNvbG9yLWdyZWVuIHtcclxuXHQtLWlvbi1jb2xvci1iYXNlOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuKTtcclxuXHQtLWlvbi1jb2xvci1iYXNlLXJnYjogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbik7XHJcblx0LS1pb24tY29sb3ItY29udHJhc3Q6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4td2hpdGUpO1xyXG5cdC0taW9uLWNvbG9yLWNvbnRyYXN0LXJnYjogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbik7XHJcblx0LS1pb24tY29sb3Itc2hhZGU6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4pO1xyXG5cdC0taW9uLWNvbG9yLXRpbnQ6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4pO1xyXG59XHJcbiIsIkBpbXBvcnQgXCIuLi8uLi8uLi8uLi9jb2xvci5zY3NzXCI7XHJcbi5tZW51LWNvbnRlbnQge1xyXG4gICAgLS1iYWNrZ3JvdW5kOiAjRjFFRkVGO1xyXG4gICAgLmJvZHkge1xyXG4gICAgICAgIG1hcmdpbi1ib3R0b206IDEyOHB4O1xyXG4gICAgICAgIC8vIHBhZGRpbmc6IDByZW0gMXJlbSAxcmVtIDFyZW07XHJcbiAgICAgICAgLnJldmlldy10ZXh0IHtcclxuICAgICAgICAgICAgcGFkZGluZy10b3A6IDAuNXJlbTtcclxuICAgICAgICAgICAgY29sb3I6ICRjb2xvci1uZXh0Z2VuLWJsdWU7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC5yZXZpZXctZGV0YWlsIHtcclxuICAgICAgICAgICAgbWFyZ2luLXRvcDogMXJlbTtcclxuICAgICAgICAgICAgcGFkZGluZzogMXJlbTtcclxuICAgICAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogJGNvbG9yLW5leHRnZW4td2hpdGU7XHJcbiAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDhweDtcclxuICAgICAgICAgICAgYm94LXNoYWRvdzogMHB4IDFweCAycHggcmdiYSgwLCAwLCAwLCAwLjEpO1xyXG4gICAgICAgICAgICAucmV2aWV3LWRldGFpbC10aXRsZSB7XHJcbiAgICAgICAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICAgICAgICAgICAgYWxpZ24tY29udGVudDogc3BhY2UtYmV0d2VlbjtcclxuICAgICAgICAgICAgICAgIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcclxuICAgICAgICAgICAgICAgIC50aXRsZS10ZXh0IHtcclxuICAgICAgICAgICAgICAgICAgICBjb2xvcjogJGNvbG9yLW5leHRnZW4tZ3JleTtcclxuICAgICAgICAgICAgICAgICAgICBwYWRkaW5nLWxlZnQ6IDAuNXJlbTtcclxuICAgICAgICAgICAgICAgICAgICBwYWRkaW5nLWJvdHRvbTogMXJlbTtcclxuICAgICAgICAgICAgICAgICAgICB0ZXh0LXRyYW5zZm9ybTogdXBwZXJjYXNlO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIC5ib3JkZXItYm94IHtcclxuICAgICAgICAgICAgICAgIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjRUZGM0Y1O1xyXG4gICAgICAgICAgICAgICAgd2lkdGg6IDEwMCU7XHJcbiAgICAgICAgICAgICAgICBtYXJnaW4tYm90dG9tOiAwLjVyZW07XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgLnJldmlldy1kZXRhaWwtc3VidGl0bGUge1xyXG4gICAgICAgICAgICAgICAgcGFkZGluZy10b3A6IDAuNXJlbTtcclxuICAgICAgICAgICAgICAgIHBhZGRpbmctYm90dG9tOiAwLjVyZW07XHJcbiAgICAgICAgICAgICAgICBwYWRkaW5nLWxlZnQ6IDAuNXJlbTtcclxuICAgICAgICAgICAgICAgIC5yZXZpZXctZGV0YWlsLXRleHQge1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbG9yOiAkY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNDAwO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgLnJldmlldy1kZXRhaWwtY29udGVudCB7XHJcbiAgICAgICAgICAgICAgICAgICAgY29sb3I6ICRjb2xvci1uZXh0Z2VuLWJsdWU7XHJcbiAgICAgICAgICAgICAgICAgICAgcGFkZGluZy10b3A6IDFyZW07XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAuZG9jdW1lbnQtdGV4dCB7XHJcbiAgICAgICAgICAgICAgICAgICAgY29sb3I6ICRjb2xvci1uZXh0Z2VuLWJsdWU7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAuZG9jdW1lbnQtY29udGVudCB7XHJcbiAgICAgICAgICAgICAgICAgICAgY29sb3I6ICRjb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleTtcclxuICAgICAgICAgICAgICAgICAgICBwYWRkaW5nLXRvcDogMXJlbTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIC5uby1maWxle1xyXG4gICAgICAgICAgICAgICAgICAgIHBhZGRpbmctdG9wOiAxcmVtO1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbG9yOiAkY29sb3ItbmV4dGdlbi1lcnJvci1yZWQtNzAwO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIC5kb2N1bWVudHMtYWRkIHtcclxuICAgICAgICAgICAgICAgICAgICBjb2xvcjogJGNvbG9yLW5leHRnZW4tZXJyb3ItcmVkLTcwMDtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAudWlsLWVkaXQ6YmVmb3JlIHtcclxuICAgICAgICAgICAgICAgIGNvbnRlbnQ6ICdcXGU5OTAnO1xyXG4gICAgICAgICAgICAgICAgY29sb3I6ICRjb2xvci1uZXh0Z2VuLWdyZXk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcbn0iXX0= */";

/***/ }),

/***/ 83446:
/*!**********************************************************************************************!*\
  !*** ./src/app/pages/new-pre-approval/upload-detail/upload-detail.component.scss?ngResource ***!
  \**********************************************************************************************/
/***/ ((module) => {

module.exports = ":root {\n  --nc-color-nextgen-neutral-grey-50: #f1efef;\n  --nc-color-nextgen-white: #ffffff;\n  --nc-color-nextgen-blue: #0d152e;\n  --nc-color-nextgen-green: #00908d;\n  --nc-color-nextgen-black: #000000;\n  --nc-color-nextgen-grey-background: #c8d3da;\n  --nc-color-nextgen-grey: #92a2ac;\n  --nc-color-nextgen-stone-grey: #fafafa;\n  --nc-color-nextgen-error: #fc1055;\n  --nc-color-nextgen-neutral-grey: #414141;\n  --nc-color-nextgen-fibrant-green: #00bab6;\n  --nc-color-nextgen-warning: #ffd048;\n  --nc-color-nextgen-green-background: #e6f2f2;\n  --nc-color-nextgen-neutral-grey-400: #7a7a7a;\n  --nc-color-nextgen-neutral-grey-100: #eff3f5;\n  --nc-color-nextgen-status-error: #ba0c3f;\n  --nc-color-nextgen-status-error-background: #ffeff4;\n  --nc-color-nextgen-status-warning: #cba127;\n  --nc-color-nextgen-status-warning-background: #fff8e6;\n  --nc-color-nextgen-blue-100: #dfeff2;\n  --nc-color-nextgen-error-red-700: #f62459;\n  --nc-color-nextgen-blue-500: #006192;\n  --nc-color-nextgen-blue-400: #79cdec;\n  --nc-color-nextgen-red-500: #ff6592;\n  --nc-color-nextgen-secondary-blue-300: #13a0d3;\n  --lumi-white-color: #ffffff;\n  --lumi-primary-yellow-color: #fab600;\n}\n\n.ion-color-green {\n  --ion-color-base: var(--nc-color-nextgen-green);\n  --ion-color-base-rgb: var(--nc-color-nextgen-green);\n  --ion-color-contrast: var(--nc-color-nextgen-white);\n  --ion-color-contrast-rgb: var(--nc-color-nextgen-green);\n  --ion-color-shade: var(--nc-color-nextgen-green);\n  --ion-color-tint: var(--nc-color-nextgen-green);\n}\n\n* {\n  box-shadow: none !important;\n}\n\n.upload-page {\n  background: var(--nc-color-nextgen-neutral-grey-50);\n}\n\n.menu-content {\n  --background: #F1EFEF;\n}\n\n.menu-content .body {\n  margin-bottom: 128px;\n}\n\n.upload-text {\n  color: var(--nc-color-nextgen-blue);\n}\n\n.title-upload {\n  color: var(--nc-color-nextgen-neutral-grey);\n  padding: 10px 0 16px 0;\n}\n\n.card-content {\n  margin-bottom: 8px;\n  padding: 16px 18px 16px 18px;\n  border-radius: 8px;\n  background: white;\n}\n\n.card-subtitle {\n  color: var(--nc-color-nextgen-neutral-grey);\n  padding-bottom: 6px;\n}\n\n.card-title {\n  color: var(--nc-color-nextgen-grey);\n  margin-bottom: 2px;\n}\n\n.card-header {\n  display: flex;\n}\n\n.card-header ion-grid {\n  width: 100%;\n}\n\n.body-button {\n  display: flex;\n  margin-bottom: auto;\n  margin-top: auto;\n}\n\n.button-add-document {\n  --background: $color-nextgen-status-warning-background;\n  height: 24px;\n  width: 24px;\n  border-radius: 50%;\n  border: 1px solid var(--nc-color-nextgen-green);\n  float: right;\n}\n\n.button-add-document .icon-button {\n  margin-left: 3px;\n  color: var(--nc-color-nextgen-green);\n}\n\n.button-add-document-done {\n  --background: $color-nextgen-status-warning-background;\n  height: 24px;\n  width: 24px;\n  border-radius: 50%;\n  float: right;\n  background: var(--nc-color-nextgen-fibrant-green);\n}\n\n.button-add-document-done .icon-button-done {\n  margin-left: 3px;\n  color: #ffff;\n}\n\n.icon-template {\n  margin-bottom: 40px;\n}\n\n.button-add {\n  margin-top: 1rem;\n  width: 100%;\n  height: 48px;\n  background: #E6F2F2;\n  border: 1.5px dashed var(--nc-color-nextgen-green);\n  border-radius: 9px;\n  display: flex;\n  justify-content: center;\n  padding-top: 10px;\n}\n\n.button-add .icon-button {\n  color: var(--nc-color-nextgen-green);\n  height: 24px;\n  width: 24px;\n}\n\n.button-add .title-button {\n  color: var(--nc-color-nextgen-green);\n  padding: 3px 0 0 9px;\n}\n\n.image-card {\n  display: flex;\n  align-items: center;\n  background: var(--nc-color-nextgen-neutral-grey-100);\n  border: 1px solid var(--nc-color-nextgen-grey-background);\n  height: 48px;\n  margin-bottom: 0.5rem;\n  padding-left: 1rem;\n  padding-right: 1rem;\n  border-radius: 8px;\n}\n\n.d-flex {\n  display: flex;\n}\n\n.d-flex.space-between {\n  justify-content: space-between;\n}\n\n.d-flex.item-center {\n  align-items: center;\n}\n\n.d-flex.flex-direction {\n  flex-direction: row-reverse;\n}\n\n.document-name {\n  max-width: 60vw;\n  white-space: nowrap;\n  overflow: hidden;\n  text-overflow: ellipsis;\n}\n\n.uil.uil-trash {\n  right: 0px;\n  position: absolute;\n  border-width: 6px;\n  border-radius: 20px;\n  border: solid #d3271a;\n  border-width: 1px 1px;\n  padding: 3px;\n  color: #d3271a;\n  display: grid;\n  z-index: 1;\n  margin-top: -9px;\n  margin-right: -2px;\n  background: white;\n}\n\n.ion-border {\n  background: #d3d3d36b;\n  border: 1px solid var(--nc-color-nextgen-grey-background);\n  border-radius: 8px;\n  margin-bottom: 15px;\n  width: 100%;\n}\n\n.textAreaCard {\n  background: white;\n  border: 1px solid var(--nc-color-nextgen-grey-background);\n  border-radius: 8px;\n  padding-left: 10px;\n}\n\n.noteIcon {\n  position: absolute;\n  right: 40px;\n  color: #0000009c;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFxjb2xvci5zY3NzIiwidXBsb2FkLWRldGFpbC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNDLDJDQUFBO0VBQ0EsaUNBQUE7RUFDQSxnQ0FBQTtFQUNBLGlDQUFBO0VBQ0EsaUNBQUE7RUFDQSwyQ0FBQTtFQUNBLGdDQUFBO0VBQ0Esc0NBQUE7RUFDQSxpQ0FBQTtFQUNBLHdDQUFBO0VBQ0EseUNBQUE7RUFDQSxtQ0FBQTtFQUNBLDRDQUFBO0VBQ0EsNENBQUE7RUFDQSw0Q0FBQTtFQUNBLHdDQUFBO0VBQ0EsbURBQUE7RUFDQSwwQ0FBQTtFQUNBLHFEQUFBO0VBQ0Esb0NBQUE7RUFDQSx5Q0FBQTtFQUNBLG9DQUFBO0VBQ0Esb0NBQUE7RUFDQSxtQ0FBQTtFQUNBLDhDQUFBO0VBRUEsMkJBQUE7RUFDQSxvQ0FBQTtBQ0FEOztBRGdDQTtFQUNDLCtDQUFBO0VBQ0EsbURBQUE7RUFDQSxtREFBQTtFQUNBLHVEQUFBO0VBQ0EsZ0RBQUE7RUFDQSwrQ0FBQTtBQzdCRDs7QUFwQ0E7RUFDSSwyQkFBQTtBQXVDSjs7QUFwQ0E7RUFDSSxtRERvQzRCO0FDR2hDOztBQXBDQTtFQUNJLHFCQUFBO0FBdUNKOztBQXRDSTtFQUVJLG9CQUFBO0FBdUNSOztBQW5DQTtFQUNJLG1DRFlpQjtBQzBCckI7O0FBbkNBO0VBQ0ksMkNEZ0J5QjtFQ2Z6QixzQkFBQTtBQXNDSjs7QUFuQ0E7RUFDSSxrQkFBQTtFQUNBLDRCQUFBO0VBQ0Esa0JBQUE7RUFDQSxpQkFBQTtBQXNDSjs7QUFuQ0E7RUFDSSwyQ0RJeUI7RUNIekIsbUJBQUE7QUFzQ0o7O0FBbkNBO0VBQ0ksbUNESmlCO0VDS2pCLGtCQUFBO0FBc0NKOztBQW5DQTtFQUNJLGFBQUE7QUFzQ0o7O0FBckNJO0VBQ0ksV0FBQTtBQXVDUjs7QUFuQ0E7RUFDSSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSxnQkFBQTtBQXNDSjs7QUFuQ0E7RUFDSSxzREFBQTtFQUNBLFlBQUE7RUFDQSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSwrQ0FBQTtFQUNBLFlBQUE7QUFzQ0o7O0FBckNJO0VBQ0ksZ0JBQUE7RUFDQSxvQ0RsQ2M7QUN5RXRCOztBQW5DQTtFQUNJLHNEQUFBO0VBQ0EsWUFBQTtFQUNBLFdBQUE7RUFDQSxrQkFBQTtFQUNBLFlBQUE7RUFDQSxpRERwQzBCO0FDMEU5Qjs7QUFyQ0k7RUFDSSxnQkFBQTtFQUNBLFlBQUE7QUF1Q1I7O0FBbkNBO0VBQ0ksbUJBQUE7QUFzQ0o7O0FBbkNBO0VBQ0ksZ0JBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtFQUNBLG1CQUFBO0VBQ0Esa0RBQUE7RUFDQSxrQkFBQTtFQUNBLGFBQUE7RUFDQSx1QkFBQTtFQUNBLGlCQUFBO0FBc0NKOztBQXJDSTtFQUNJLG9DRGxFYztFQ21FZCxZQUFBO0VBQ0EsV0FBQTtBQXVDUjs7QUFyQ0k7RUFDSSxvQ0R2RWM7RUN3RWQsb0JBQUE7QUF1Q1I7O0FBbkNBO0VBQ0ksYUFBQTtFQUNBLG1CQUFBO0VBQ0Esb0REbEU2QjtFQ21FN0IseURBQUE7RUFDQSxZQUFBO0VBQ0EscUJBQUE7RUFDQSxrQkFBQTtFQUNBLG1CQUFBO0VBQ0Esa0JBQUE7QUFzQ0o7O0FBbkNBO0VBQ0ksYUFBQTtBQXNDSjs7QUFyQ0k7RUFDSSw4QkFBQTtBQXVDUjs7QUFyQ0k7RUFDSSxtQkFBQTtBQXVDUjs7QUFyQ0k7RUFDSSwyQkFBQTtBQXVDUjs7QUFuQ0E7RUFDSSxlQUFBO0VBQ0EsbUJBQUE7RUFDQSxnQkFBQTtFQUNBLHVCQUFBO0FBc0NKOztBQW5DQTtFQUVJLFVBQUE7RUFDQSxrQkFBQTtFQUNBLGlCQUFBO0VBQ0EsbUJBQUE7RUFDQSxxQkFBQTtFQUNBLHFCQUFBO0VBQ0EsWUFBQTtFQUNBLGNBQUE7RUFDQSxhQUFBO0VBQ0EsVUFBQTtFQUNBLGdCQUFBO0VBQ0Esa0JBQUE7RUFDQSxpQkFBQTtBQXFDSjs7QUFqQ0E7RUFFSSxxQkFBQTtFQUNBLHlEQUFBO0VBQ0Esa0JBQUE7RUFDQSxtQkFBQTtFQUNBLFdBQUE7QUFtQ0o7O0FBaENBO0VBQ0ksaUJBQUE7RUFDQSx5REFBQTtFQUNBLGtCQUFBO0VBQ0Esa0JBQUE7QUFtQ0o7O0FBaENBO0VBQ0ksa0JBQUE7RUFDQSxXQUFBO0VBQ0EsZ0JBQUE7QUFtQ0oiLCJmaWxlIjoidXBsb2FkLWRldGFpbC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIjpyb290IHtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTUwOiAjZjFlZmVmO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi13aGl0ZTogI2ZmZmZmZjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZTogIzBkMTUyZTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW46ICMwMDkwOGQ7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWJsYWNrOiAjMDAwMDAwO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ncmV5LWJhY2tncm91bmQ6ICNjOGQzZGE7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWdyZXk6ICM5MmEyYWM7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0b25lLWdyZXk6ICNmYWZhZmE7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWVycm9yOiAjZmMxMDU1O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXk6ICM0MTQxNDE7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWZpYnJhbnQtZ3JlZW46ICMwMGJhYjY7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXdhcm5pbmc6ICNmZmQwNDg7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuLWJhY2tncm91bmQ6ICNlNmYyZjI7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS00MDA6ICM3YTdhN2E7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS0xMDA6ICNlZmYzZjU7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy1lcnJvcjogI2JhMGMzZjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yLWJhY2tncm91bmQ6ICNmZmVmZjQ7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy13YXJuaW5nOiAjY2JhMTI3O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtd2FybmluZy1iYWNrZ3JvdW5kOiAjZmZmOGU2O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlLTEwMDogI2RmZWZmMjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tZXJyb3ItcmVkLTcwMDogI2Y2MjQ1OTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZS01MDA6ICMwMDYxOTI7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWJsdWUtNDAwOiAjNzljZGVjO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1yZWQtNTAwOiAjZmY2NTkyO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zZWNvbmRhcnktYmx1ZS0zMDA6ICMxM2EwZDM7XHJcblxyXG5cdC0tbHVtaS13aGl0ZS1jb2xvcjogI2ZmZmZmZjtcclxuXHQtLWx1bWktcHJpbWFyeS15ZWxsb3ctY29sb3I6ICNmYWI2MDA7XHJcbn1cclxuJGNvbG9yLW5leHRnZW4tYmx1ZTogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlKTtcclxuJGNvbG9yLW5leHRnZW4tZ3JlZW46IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4pO1xyXG4kY29sb3ItbmV4dGdlbi13aGl0ZTogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi13aGl0ZSk7XHJcbiRjb2xvci1uZXh0Z2VuLWJsYWNrOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWJsYWNrKTtcclxuJGNvbG9yLW5leHRnZW4tZ3JleS1iYWNrZ3JvdW5kOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZXktYmFja2dyb3VuZCk7XHJcbiRjb2xvci1uZXh0Z2VuLWdyZXk6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JleSk7XHJcbiRjb2xvci1uZXh0Z2VuLXN0b25lLWdyZXk6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tc3RvbmUtZ3JleSk7XHJcbiRjb2xvci1uZXh0Z2VuLWVycm9yOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWVycm9yKTtcclxuJGNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5OiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleSk7XHJcbiRjb2xvci1uZXh0Z2VuLWZpYnJhbnQtZ3JlZW46IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZmlicmFudC1ncmVlbik7XHJcbiRjb2xvci1uZXh0Z2VuLXdhcm5pbmc6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4td2FybmluZyk7XHJcbiRjb2xvci1uZXh0Z2VuLWdyZWVuLWJhY2tncm91bmQ6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4tYmFja2dyb3VuZCk7XHJcbiRjb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS01MDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNTApO1xyXG4kY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNDAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS00MDApO1xyXG4kY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktMTAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS0xMDApO1xyXG4kY29sb3ItbmV4dGdlbi1zdGF0dXMtZXJyb3I6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yKTtcclxuJGNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yLWJhY2tncm91bmQ6IHZhcihcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yLWJhY2tncm91bmRcclxuKTtcclxuJGNvbG9yLW5leHRnZW4tc3RhdHVzLXdhcm5pbmc6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLXdhcm5pbmcpO1xyXG4kY29sb3ItbmV4dGdlbi1zdGF0dXMtd2FybmluZy1iYWNrZ3JvdW5kOiB2YXIoXHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy13YXJuaW5nLWJhY2tncm91bmRcclxuKTtcclxuJGNvbG9yLW5leHRnZW4tYmx1ZS0xMDA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZS0xMDApO1xyXG4kY29sb3ItbmV4dGdlbi1lcnJvci1yZWQtNzAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWVycm9yLXJlZC03MDApO1xyXG4kY29sb3ItbmV4dGdlbi1ibHVlLTUwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlLTUwMCk7XHJcbiRjb2xvci1uZXh0Z2VuLWJsdWUtNDAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWJsdWUtNDAwKTtcclxuJGNvbG9yLW5leHRnZW4tcmVkLTUwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1yZWQtNTAwKTtcclxuJGNvbG9yLW5leHRnZW4tc2Vjb25kYXJ5LWJsdWUtMzAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXNlY29uZGFyeS1ibHVlLTMwMCk7XHJcblxyXG4uaW9uLWNvbG9yLWdyZWVuIHtcclxuXHQtLWlvbi1jb2xvci1iYXNlOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuKTtcclxuXHQtLWlvbi1jb2xvci1iYXNlLXJnYjogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbik7XHJcblx0LS1pb24tY29sb3ItY29udHJhc3Q6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4td2hpdGUpO1xyXG5cdC0taW9uLWNvbG9yLWNvbnRyYXN0LXJnYjogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbik7XHJcblx0LS1pb24tY29sb3Itc2hhZGU6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4pO1xyXG5cdC0taW9uLWNvbG9yLXRpbnQ6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4pO1xyXG59XHJcbiIsIkBpbXBvcnQgXCIuLi8uLi8uLi8uLi9jb2xvci5zY3NzXCI7XHJcbioge1xyXG4gICAgYm94LXNoYWRvdzogbm9uZSAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4udXBsb2FkLXBhZ2Uge1xyXG4gICAgYmFja2dyb3VuZDogJGNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTUwO1xyXG59XHJcblxyXG4ubWVudS1jb250ZW50IHtcclxuICAgIC0tYmFja2dyb3VuZDogI0YxRUZFRjtcclxuICAgIC5ib2R5IHtcclxuICAgICAgICAvLyBwYWRkaW5nOiAwcmVtIDFyZW0gMXJlbSAxcmVtO1xyXG4gICAgICAgIG1hcmdpbi1ib3R0b206IDEyOHB4O1xyXG4gICAgfVxyXG59XHJcblxyXG4udXBsb2FkLXRleHQge1xyXG4gICAgY29sb3I6ICRjb2xvci1uZXh0Z2VuLWJsdWU7XHJcbn1cclxuXHJcbi50aXRsZS11cGxvYWQge1xyXG4gICAgY29sb3I6ICRjb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleTtcclxuICAgIHBhZGRpbmc6IDEwcHggMCAxNnB4IDA7XHJcbn1cclxuXHJcbi5jYXJkLWNvbnRlbnQge1xyXG4gICAgbWFyZ2luLWJvdHRvbTogOHB4O1xyXG4gICAgcGFkZGluZzogMTZweCAxOHB4IDE2cHggMThweDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDhweDtcclxuICAgIGJhY2tncm91bmQ6IHdoaXRlO1xyXG59XHJcblxyXG4uY2FyZC1zdWJ0aXRsZSB7XHJcbiAgICBjb2xvcjogJGNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5O1xyXG4gICAgcGFkZGluZy1ib3R0b206IDZweDtcclxufVxyXG5cclxuLmNhcmQtdGl0bGUge1xyXG4gICAgY29sb3I6ICRjb2xvci1uZXh0Z2VuLWdyZXk7XHJcbiAgICBtYXJnaW4tYm90dG9tOiAycHg7XHJcbn1cclxuXHJcbi5jYXJkLWhlYWRlciB7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgJiBpb24tZ3JpZCB7XHJcbiAgICAgICAgd2lkdGg6IDEwMCU7XHJcbiAgICB9XHJcbn1cclxuXHJcbi5ib2R5LWJ1dHRvbiB7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgbWFyZ2luLWJvdHRvbTogYXV0bztcclxuICAgIG1hcmdpbi10b3A6IGF1dG87XHJcbn1cclxuXHJcbi5idXR0b24tYWRkLWRvY3VtZW50IHtcclxuICAgIC0tYmFja2dyb3VuZDogJGNvbG9yLW5leHRnZW4tc3RhdHVzLXdhcm5pbmctYmFja2dyb3VuZDtcclxuICAgIGhlaWdodDogMjRweDtcclxuICAgIHdpZHRoOiAyNHB4O1xyXG4gICAgYm9yZGVyLXJhZGl1czogNTAlO1xyXG4gICAgYm9yZGVyOiAxcHggc29saWQgJGNvbG9yLW5leHRnZW4tZ3JlZW47XHJcbiAgICBmbG9hdDogcmlnaHQ7XHJcbiAgICAuaWNvbi1idXR0b24ge1xyXG4gICAgICAgIG1hcmdpbi1sZWZ0OiAzcHg7XHJcbiAgICAgICAgY29sb3I6ICRjb2xvci1uZXh0Z2VuLWdyZWVuO1xyXG4gICAgfVxyXG59XHJcblxyXG4uYnV0dG9uLWFkZC1kb2N1bWVudC1kb25lIHtcclxuICAgIC0tYmFja2dyb3VuZDogJGNvbG9yLW5leHRnZW4tc3RhdHVzLXdhcm5pbmctYmFja2dyb3VuZDtcclxuICAgIGhlaWdodDogMjRweDtcclxuICAgIHdpZHRoOiAyNHB4O1xyXG4gICAgYm9yZGVyLXJhZGl1czogNTAlO1xyXG4gICAgZmxvYXQ6IHJpZ2h0O1xyXG4gICAgYmFja2dyb3VuZDogJGNvbG9yLW5leHRnZW4tZmlicmFudC1ncmVlbjtcclxuICAgIC5pY29uLWJ1dHRvbi1kb25lIHtcclxuICAgICAgICBtYXJnaW4tbGVmdDogM3B4O1xyXG4gICAgICAgIGNvbG9yOiAjZmZmZjtcclxuICAgIH1cclxufVxyXG5cclxuLmljb24tdGVtcGxhdGUge1xyXG4gICAgbWFyZ2luLWJvdHRvbTogNDBweDtcclxufVxyXG5cclxuLmJ1dHRvbi1hZGQge1xyXG4gICAgbWFyZ2luLXRvcDogMXJlbTtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgaGVpZ2h0OiA0OHB4O1xyXG4gICAgYmFja2dyb3VuZDogI0U2RjJGMjtcclxuICAgIGJvcmRlcjogMS41cHggZGFzaGVkICRjb2xvci1uZXh0Z2VuLWdyZWVuO1xyXG4gICAgYm9yZGVyLXJhZGl1czogOXB4O1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgcGFkZGluZy10b3A6IDEwcHg7XHJcbiAgICAuaWNvbi1idXR0b24ge1xyXG4gICAgICAgIGNvbG9yOiAkY29sb3ItbmV4dGdlbi1ncmVlbjtcclxuICAgICAgICBoZWlnaHQ6IDI0cHg7XHJcbiAgICAgICAgd2lkdGg6IDI0cHg7XHJcbiAgICB9XHJcbiAgICAudGl0bGUtYnV0dG9uIHtcclxuICAgICAgICBjb2xvcjogJGNvbG9yLW5leHRnZW4tZ3JlZW47XHJcbiAgICAgICAgcGFkZGluZzogM3B4IDAgMCA5cHg7XHJcbiAgICB9XHJcbn1cclxuXHJcbi5pbWFnZS1jYXJkIHtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgYmFja2dyb3VuZDogJGNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTEwMDtcclxuICAgIGJvcmRlcjogMXB4IHNvbGlkICRjb2xvci1uZXh0Z2VuLWdyZXktYmFja2dyb3VuZDtcclxuICAgIGhlaWdodDogNDhweDtcclxuICAgIG1hcmdpbi1ib3R0b206IDAuNXJlbTtcclxuICAgIHBhZGRpbmctbGVmdDogMXJlbTtcclxuICAgIHBhZGRpbmctcmlnaHQ6IDFyZW07XHJcbiAgICBib3JkZXItcmFkaXVzOiA4cHg7XHJcbn1cclxuXHJcbi5kLWZsZXgge1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgICYuc3BhY2UtYmV0d2VlbiB7XHJcbiAgICAgICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xyXG4gICAgfVxyXG4gICAgJi5pdGVtLWNlbnRlciB7XHJcbiAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgIH1cclxuICAgICYuZmxleC1kaXJlY3Rpb24ge1xyXG4gICAgICAgIGZsZXgtZGlyZWN0aW9uOiByb3ctcmV2ZXJzZTtcclxuICAgIH1cclxufVxyXG5cclxuLmRvY3VtZW50LW5hbWUge1xyXG4gICAgbWF4LXdpZHRoOiA2MHZ3O1xyXG4gICAgd2hpdGUtc3BhY2U6IG5vd3JhcDtcclxuICAgIG92ZXJmbG93OiBoaWRkZW47XHJcbiAgICB0ZXh0LW92ZXJmbG93OiBlbGxpcHNpcztcclxufVxyXG5cclxuLnVpbC51aWwtdHJhc2gge1xyXG5cclxuICAgIHJpZ2h0OiAwcHg7XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICBib3JkZXItd2lkdGg6IDZweDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDIwcHg7XHJcbiAgICBib3JkZXI6IHNvbGlkICNkMzI3MWE7XHJcbiAgICBib3JkZXItd2lkdGg6IDFweCAxcHg7XHJcbiAgICBwYWRkaW5nOiAzcHg7XHJcbiAgICBjb2xvcjogI2QzMjcxYTtcclxuICAgIGRpc3BsYXk6IGdyaWQ7XHJcbiAgICB6LWluZGV4OiAxO1xyXG4gICAgbWFyZ2luLXRvcDogLTlweDtcclxuICAgIG1hcmdpbi1yaWdodDogLTJweDtcclxuICAgIGJhY2tncm91bmQ6IHdoaXRlO1xyXG59XHJcblxyXG5cclxuLmlvbi1ib3JkZXIgIHtcclxuIFxyXG4gICAgYmFja2dyb3VuZDogI2QzZDNkMzZiO1xyXG4gICAgYm9yZGVyOiAxcHggc29saWQgdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmV5LWJhY2tncm91bmQpO1xyXG4gICAgYm9yZGVyLXJhZGl1czogOHB4O1xyXG4gICAgbWFyZ2luLWJvdHRvbTogMTVweDtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG59XHJcblxyXG4udGV4dEFyZWFDYXJkIHtcclxuICAgIGJhY2tncm91bmQ6IHdoaXRlO1xyXG4gICAgYm9yZGVyOiAxcHggc29saWQgdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmV5LWJhY2tncm91bmQpO1xyXG4gICAgYm9yZGVyLXJhZGl1czogOHB4O1xyXG4gICAgcGFkZGluZy1sZWZ0OiAxMHB4O1xyXG59XHJcblxyXG4ubm90ZUljb257XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICByaWdodDogNDBweDtcclxuICAgIGNvbG9yOiAjMDAwMDAwOWM7XHJcbn1cclxuIl19 */";

/***/ }),

/***/ 39705:
/*!**********************************************************************************************!*\
  !*** ./src/app/pages/new-pre-approval/claim-details/claim-details.component.html?ngResource ***!
  \**********************************************************************************************/
/***/ ((module) => {

module.exports = "<ion-content>\r\n  <form [formGroup]=\"preAppovalForm\">\r\n    <div class=\"claim-details-main mb-2\">\r\n      <div class=\"claim-details-title\">\r\n        <p class=\"h4 bold\">{{'claimDetails.title'|translate}}</p>\r\n      </div>\r\n      <div class=\"claim-details-content\">\r\n        <div class=\"detail-content\">\r\n          <nextgen-control [type]=\"TYPE.SELECTDIALOG\" [label-property]=\"'claimDetails.memberLabel'|translate\"\r\n            [items]=\"members\" [dialogTitle]=\"'claimDetails.selectMemberLabel'|translate\" [hasIcon]=\"true\"\r\n            formControlName=\"memberSelect\" [height]=\"'45%'\" [placeholder]=\"'claimDetails.chooseMember'|translate\">\r\n          </nextgen-control>\r\n        </div>\r\n        <div class=\"detail-content\">\r\n          <nextgen-control [disabled]=\"disabled\" [type]=\"TYPE.DATETIMEDIALOG\" [label-property]=\"'claimDetails.serviceDate'|translate\"\r\n            formControlName=\"serviceDate\" [placeholder]=\"'claimDetails.selectServiceDate'|translate\"\r\n            [minDate]=\"minDate\" [custom-validation]=\"customValidation\">\r\n          </nextgen-control>\r\n        </div>\r\n        <div class=\"detail-content\">\r\n          <nextgen-control [disabled]=\"disabled\" [type]=\"TYPE.SELECTDIALOG\" [label-property]=\"'claimDetails.serviceType'|translate\"\r\n            [items]=\"serviceTypes\" [dialogTitle]=\"'claimDetails.serviceType'|translate\"\r\n            [height]=\"'45%'\"\r\n            [placeholder]=\"'claimDetails.chooseServiceType'|translate\" formControlName=\"serviceType\"></nextgen-control>\r\n        </div>\r\n        <div class=\"detail-content\">\r\n          <nextgen-control [type]=\"TYPE.INPUT\"\r\n            [placeholder]=\"'preApprovalClaimDetail.chooseHealthcareProvider'|translate\"\r\n            [label-property]=\"'preApprovalClaimDetail.healthcareProvider'|translate\"\r\n            formControlName=\"healthcareProviderName\" second-icon=\"uil uil-arrow-right\"\r\n            (click)=\"providerHandler()\"></nextgen-control>\r\n        </div>\r\n      </div>\r\n    </div>\r\n  </form>\r\n</ion-content>\r\n<nextcare-workflow-commands [this]=\"this\" [commands]=\"commands\"></nextcare-workflow-commands>";

/***/ }),

/***/ 39638:
/*!******************************************************************************!*\
  !*** ./src/app/pages/new-pre-approval/new-pre-approval.page.html?ngResource ***!
  \******************************************************************************/
/***/ ((module) => {

module.exports = "<div class=\"new-claim-container\">\r\n  <nextcare-workflow title=\"{{'newPreApproval.title'|translate}}\" [steps]=\"stepProgress\" [this]=\"this\" [command]=\"command\"></nextcare-workflow>\r\n</div>\r\n";

/***/ }),

/***/ 71742:
/*!******************************************************************************************************!*\
  !*** ./src/app/pages/new-pre-approval/review-and-submit/review-and-submit.component.html?ngResource ***!
  \******************************************************************************************************/
/***/ ((module) => {

module.exports = "<ion-content class=\"menu-content\">\r\n    <div class=\"body\">\r\n        <div>\r\n            <div class=\"review-text h4 bold \">{{'claimReview.reviewSubmission'| translate}}</div>\r\n        </div>\r\n\r\n        <div class=\"review-detail\">\r\n            <div class=\"review-detail-title\">\r\n                <span class=\"title-text\">{{'claimReview.claimDetail'| translate}}</span>\r\n                <i class=\"icon-edit uil uil-edit\" (click)=\"onNavigateToClaimDetails()\"></i>\r\n            </div>\r\n            <div class=\"border-box\"></div>\r\n            <div class=\"review-detail-subtitle\">\r\n                <span class=\"review-detail-text body-sm\">{{'claimReview.member'| translate}}</span><br>\r\n                <span class=\"review-detail-content body-n bold\">{{claimPreInfo.memberSelect?.name |replaceMySelf |translate}}</span>\r\n            </div>\r\n            <div class=\"review-detail-subtitle\">\r\n                <span class=\"review-detail-text body-sm\">{{'claimReview.healthcare'| translate}}</span><br>\r\n                <span class=\"review-detail-content body-n bold\">{{claimPreInfo?.healthcareProvider}}</span>\r\n            </div>\r\n            <div class=\"review-detail-subtitle\">\r\n                <span class=\"review-detail-text body-sm\">{{'claimReview.servicetype'| translate}}</span><br>\r\n                <span class=\"review-detail-content body-n bold\">{{claimPreInfo.serviceType?.name}}</span>\r\n            </div>\r\n            <div class=\"review-detail-subtitle\">\r\n                <span class=\"review-detail-text body-sm\">{{'claimReview.serviceDate'| translate}}</span><br>\r\n                <span class=\"review-detail-content body-n bold\">{{claimPreInfo.serviceDate | date: 'd MMMM y':'':lang}}</span>\r\n            </div>\r\n        </div>\r\n\r\n        <div class=\"review-detail\" *ngIf=\"claimDocuments\">\r\n            <div class=\"review-detail-title\">\r\n                <span class=\"title-text\">{{'claimReview.document'| translate}}</span>\r\n                <i class=\"icon-edit uil uil-edit\" (click)=\"onNavigateToDocument()\"></i>\r\n            </div>\r\n            <div class=\"border-box\"></div>\r\n            <div class=\"review-detail-subtitle\" *ngFor=\"let item of claimDocuments\" >\r\n                <span class=\"document-text body-n bold\">{{item.title |translate}}</span><br>\r\n                <div *ngIf=\"item.document?.length>0\">\r\n                    <span class=\"document-content body-sm\" *ngFor=\"let document of item.document\"  >\r\n                        - {{document.fileName}}<br>\r\n                    </span>\r\n                </div>\r\n                <span class=\"no-file body-sm\" *ngIf=\"item.document?.length<1\">{{'uploadDocuments.noDocumentUploaded'| translate}}</span>\r\n            </div>\r\n        </div>\r\n    </div>\r\n</ion-content>\r\n<nextcare-workflow-commands [this]=\"this\" [commands]=\"commands\"></nextcare-workflow-commands>";

/***/ }),

/***/ 60147:
/*!**********************************************************************************************!*\
  !*** ./src/app/pages/new-pre-approval/upload-detail/upload-detail.component.html?ngResource ***!
  \**********************************************************************************************/
/***/ ((module) => {

module.exports = "<ion-content class=\"menu-content\">\r\n    <div class=\"body\">\r\n        <div>\r\n            <div class=\"upload-text h4 bold \">{{ 'uploadDocuments.uploadDocument' | translate }}</div>\r\n            <p class=\"title-upload body-sm\">{{ 'uploadDocuments.title' | translate }}</p>\r\n        </div>\r\n        <ion-grid>\r\n            <ion-row>\r\n                <ion-col>\r\n                    <ng-container *ngFor=\"let arrayControl of documentFormControl, index as i\">\r\n                        <ion-card class=\"card-content\">\r\n                            <ion-card-header class=\"card-header\">\r\n                                <ion-grid>\r\n                                    <ng-container *ngIf=\"arrayControl.controls.expanded?.value, else defaultTemplate\">\r\n                                        <ion-row>\r\n                                            <ion-col>\r\n                                                <div class=\"d-flex space-between\">\r\n                                                    <ion-card-title class=\"card-subtitle body-n bold\">{{arrayControl.controls.title?.value | translate}}\r\n                                                    </ion-card-title>\r\n                                                    <i class=\"uil uil-angle-up\" (click)=\"showDetail(arrayControl)\"></i>\r\n                                                </div>\r\n                                            </ion-col>\r\n                                        </ion-row>\r\n                                        <ion-row>\r\n                                            <ion-col>\r\n                                                <ion-card-title class=\"card-title body-sm\"\r\n                                                    *ngIf=\"!arrayControl?.value.document?.length\">\r\n                                                    {{ arrayControl?.controls.description?.value |translate}}\r\n                                                </ion-card-title>\r\n                                                <ng-container *ngIf=\"arrayControl?.value.document?.length > 0\">\r\n                                                    <ion-row *ngFor=\"let control of arrayControl.controls.document?.value, index as indexImage\">\r\n                                                        <i class=\"uil uil-trash\" (click)=\"onRemoveDocument(arrayControl?.value, indexImage)\"></i>\r\n                                                        <ion-card   class=\"ion-border\">                                                           \r\n                                                                <ion-card-header class=\"image-card d-flex space-between\">\r\n                                                                \r\n                                                                    <ion-label \r\n                                                                    class=\"document-name\">{{control.fileName}}</ion-label>\r\n                                                                    <i  class=\"uil h3 noteIcon\"  (click)=\"toggleNoteCards(arrayControl?.value , indexImage)\">\r\n                                                                        <img src=\"../../../assets/icon/NewNote.svg\" alt=\"Icon\">\r\n                                                                    </i>\r\n                                                                </ion-card-header>                                                   \r\n                                                            <ion-card-content *ngIf=\"i ===0\"  hidden=\"true\"   [ngClass]=\"'noteCardContent-' + indexImage\"  class=\"noteCard\">\r\n                                                              <ion-textarea value=\"{{control.noteDescription}}\" [ngClass]=\"'noteDoc-'+ indexImage\" class=\"textAreaCard\" placeholder=\"{{ 'uploadDocuments.notePlaceHolder' |\r\n                                                              translate }}\"></ion-textarea>\r\n                                                            </ion-card-content>\r\n                                                            <ion-card-content *ngIf=\"i !=0\" hidden=\"true\"   [ngClass]=\"'otherNoteCardContent-' + indexImage \"  class=\"noteCard\">\r\n                                                                <ion-textarea value=\"{{control.noteDescription}}\" [ngClass]=\"'otherNoteDoc-'+ indexImage + ''\" class=\"textAreaCard\" placeholder=\"{{ 'uploadDocuments.notePlaceHolder' |\r\n                                                                translate }}\"></ion-textarea>\r\n                                                              </ion-card-content>\r\n                                                          </ion-card>\r\n                                                    </ion-row>\r\n                                                    <!-- <ion-card\r\n                                                        *ngFor=\"let control of arrayControl?.value.document, index as indexImage\"\r\n                                                        class=\"image-card d-flex space-between\">\r\n                                                        <ion-label class=\"document-name\">{{control.fileName}}</ion-label>\r\n                                                        <i class=\"uil uil-trash\"\r\n                                                            (click)=\"onRemoveDocument(arrayControl?.value, indexImage)\"></i>\r\n                                                    </ion-card> -->\r\n                                                    <ion-card-title class=\"card-title body-sm\">\r\n                                                        {{arrayControl.controls.document?.value?.length}} {{ 'uploadDocuments.titleAdd' |\r\n                                                        translate }}\r\n                                                    </ion-card-title>\r\n                                                </ng-container>\r\n                                            </ion-col>\r\n                                        </ion-row>\r\n                                        <button class=\"button-add\" (click)=\"openDialog(arrayControl)\">\r\n                                            <ion-icon class=\"icon-button\" name=\"add-circle-outline\"></ion-icon>\r\n                                            <p class=\"title-button body-n bold\">{{ 'uploadDocuments.buttonAddDocument' |\r\n                                                translate }}</p>\r\n                                        </button>\r\n                                    </ng-container>\r\n                                    <ng-template #defaultTemplate>\r\n                                        <ion-row>\r\n                                            <ion-col size=\"10\">\r\n                                                <ion-card-title class=\"card-subtitle body-n bold\">{{arrayControl.controls.title?.value | translate}}\r\n                                                </ion-card-title>\r\n                                                <ion-card-title class=\"card-title body-sm\"\r\n                                                    *ngIf=\"arrayControl.controls.document?.value?.length === 0\">\r\n                                                    {{ arrayControl.controls.description?.value | translate }}\r\n                                                </ion-card-title>\r\n                                                <ion-card-title class=\"card-title body-sm\"\r\n                                                    *ngIf=\"arrayControl.controls.document?.value?.length > 0\">\r\n                                                    {{arrayControl.controls.document?.value?.length}} {{ 'uploadDocuments.titleAdd' | translate\r\n                                                    }}\r\n                                                </ion-card-title>\r\n                                            </ion-col>\r\n                                            <ion-col size=\"2\" class=\"d-flex item-center flex-direction\">\r\n                                                <ion-chip class=\"button-add-document\" (click)=\"showDetail(arrayControl)\"\r\n                                                    *ngIf=\"!arrayControl?.value?.document?.length\">\r\n                                                    <ion-icon class=\"icon-button\" name=\"add-sharp\"></ion-icon>\r\n                                                </ion-chip>\r\n                                                <ion-chip class=\"button-add-document-done\"\r\n                                                    *ngIf=\"arrayControl?.value?.document?.length > 0\">\r\n                                                    <ion-icon class=\"icon-button-done\" name=\"checkmark-outline\">\r\n                                                    </ion-icon>\r\n                                                </ion-chip>\r\n                                            </ion-col>\r\n                                        </ion-row>\r\n                                    </ng-template>\r\n                                </ion-grid>\r\n                            </ion-card-header>\r\n                        </ion-card>\r\n                        <ul class=\"validation-summary\">\r\n                            <li class=\"body-sm mb-1\"\r\n                                *ngIf=\"arrayControl?.value?.document?.length < 1 && arrayControl.controls.mandatory?.value && isShowMandatory\">\r\n                                <i class=\"uil uil-info-circle mr-1 body-sm\"></i>{{ 'validationSummary.required' | translate }}\r\n                            </li>\r\n                        </ul>\r\n                    </ng-container>\r\n                </ion-col>\r\n            </ion-row>\r\n        </ion-grid>\r\n    </div>\r\n</ion-content>\r\n<nextcare-workflow-commands [this]=\"this\" [commands]=\"commands\"></nextcare-workflow-commands>";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_new-pre-approval_new-pre-approval_module_ts.js.map