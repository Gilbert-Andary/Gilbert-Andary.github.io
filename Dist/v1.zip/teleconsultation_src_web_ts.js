"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["teleconsultation_src_web_ts"],{

/***/ 38994:
/*!*************************************!*\
  !*** ./teleconsultation/src/web.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TeleconsultationWeb": () => (/* binding */ TeleconsultationWeb)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _capacitor_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @capacitor/core */ 72155);


class TeleconsultationWeb extends _capacitor_core__WEBPACK_IMPORTED_MODULE_0__.WebPlugin {
    echo(options) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__awaiter)(this, void 0, void 0, function* () {
            console.log('ECHO', options);
            return options;
        });
    }
    openHahconnectSdk(_options) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__awaiter)(this, void 0, void 0, function* () {
            console.log('Start Customer consultation: ');
        });
    }
    openHahconnectFromNofify(_options) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__awaiter)(this, void 0, void 0, function* () {
            console.log('Start Customer consultation: ');
        });
    }
}


/***/ })

}]);
//# sourceMappingURL=teleconsultation_src_web_ts.js.map