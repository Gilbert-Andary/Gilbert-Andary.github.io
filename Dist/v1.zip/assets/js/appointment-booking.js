// var width = '';

// if (screen.width > 768) {
//   width = "100%";
// }
// else {
//   width = "100vw";
// }

var hgwConfig = {
  el: 'next-care-hg-widget',
  width: "100vw",
};


// var male = true;
// var female = false;
// var isRatedApp = 0;
// var updateRateLog = true;
// var rateLevel = 0;
// var claimRefernce = "";
// will replace it when integrate user profile flow
// var hgwUserInfo = {
//   "name": "Firstname _9 Familyname_9",
//   "gender": "Female",
//   "dob": "1975-11-26",
//   "email": "mynextcare.06@gmail.com",
//   "dial_code": "+961",
//   "short_code": "AE",
//   "mobile": "3418554",
//   "insuranceCardNo": "E74D5E26D99C8405",
//   "insuranceName": "Orient Insurance PJSC - Bahrain",
//   "networkName": "General Network",
//   "networkId": 8,
//   "networkCategory": "GN",
//   "governmentIdNumber": "",
//   "memberToken": "OUTN/0hCySBnCa6AqA7GDzJgukBznv3jYkgF/bZKIMKTz9G05+qejL3Xlk5PjT4fnaX7pPlAKIgayPO4JmnuOBgr+o5hsldJAD6cAmuehj/tvtEC8QdAkQ==",
//   "partner_country": "AE",
//   "location": {
//     "lat": 0,
//     "lng": 0
//   }
// };
var hgwAction = null;
var hgwDataHandler = null;
var latitude = 51.507351;
var longitude = -0.127758;
// var url = 'https://demo.healthigo.com/js/widget/hg-widget-v2.js';
// var widgetid = 'HGWIDGE00033';
// hgwUserInfo.location = { lat: latitude, lng: longitude };
// (function (d, s, i, tid) {
//   var h = d.getElementsByTagName(s)[0], j = d.createElement(s);
//   j.async = true;
//   j.src = `https://demo.healthigo.com/js/widget/hg-widget-v2.js?id=${i}`;
//   j.id = tid;
//   h.parentNode.insertBefore(j, h);
// })(document, 'script', 'HGWIDGE00033', 'hg-widget-script')