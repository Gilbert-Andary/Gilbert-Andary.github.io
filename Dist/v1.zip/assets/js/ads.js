// var width = '';

// if (screen.width > 768) {
//   width = "100%";
// }
// else {
//   width = "100vw";
// }
var hgwConfig={
  el:'nextcare-ads',
  width: "100vw",
  height: '100vh'
};
// var hgwUserInfo = {
//     dial_code: "+961",
//     dob: "1966-12-31",
//     email: "mynextcare.06@gmail.com",
//     gender: "Female",
//     governmentIdNumber: "GOV_9969970",
//     insuranceCardNo: "E74D5E26D99C8405",
//     insuranceName: "Yallaxyz",
//     mobile: "3447748",
//     name: "FIRSTNAME_1968465 FAMILYNAME_1968465",
//     networkId: 8,
//     networkName: "General Network",
//     networkCategory: "GN",
//     short_code: "LB",
//     memberToken: 'e/ICt8mbNmZ9DbpBAP9HjTJgukBznv3j3WHjoGbF9fp/ADOQhCKTWljiOoq8wupknaX7pPlAKIgayPO4JmnuOBgr+o5hsldJr7tsRUyCEd64ey48w72AU/Ig85ijVRYM'
// }