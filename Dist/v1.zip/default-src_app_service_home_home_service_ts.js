"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["default-src_app_service_home_home_service_ts"],{

/***/ 58425:
/*!**********************************************!*\
  !*** ./src/app/service/home/home.service.ts ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HomeService": () => (/* binding */ HomeService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! rxjs */ 92218);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! rxjs */ 64139);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/shared/data/constants */ 74676);
/* harmony import */ var src_app_shared_data_enum_language__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/shared/data/enum/language */ 49856);
/* harmony import */ var src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/shared/data/enum/screen */ 68302);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _awesome_cordova_plugins_clevertap_ngx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @awesome-cordova-plugins/clevertap/ngx */ 45363);
/* harmony import */ var _awesome_cordova_plugins_firebase_analytics_ngx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @awesome-cordova-plugins/firebase-analytics/ngx */ 48852);
/* harmony import */ var _awesome_cordova_plugins_in_app_browser_ngx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @awesome-cordova-plugins/in-app-browser/ngx */ 12407);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @ionic/storage-angular */ 80190);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! rxjs/operators */ 85921);
/* harmony import */ var src_app_providers_common_loading_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/providers/common/loading.service */ 90574);
/* harmony import */ var src_app_shared_components_nextgen_dialog_nextgen_dialog_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/shared/components/nextgen-dialog/nextgen-dialog.service */ 96485);
/* harmony import */ var src_app_shared_components_popup_message_popup_message_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/shared/components/popup-message/popup-message.component */ 18290);
/* harmony import */ var src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/shared/data/enum/event */ 38570);
/* harmony import */ var src_app_shared_data_enum_login_type__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/app/shared/data/enum/login-type */ 3674);
/* harmony import */ var _insurance_insurance_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../insurance/insurance.service */ 57072);
/* harmony import */ var _symptom_checker_symptom_checker_integration_service__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../symptom-checker/symptom-checker-integration.service */ 49710);
/* harmony import */ var _utilities_third_party_service__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../utilities/third-party.service */ 47617);
/* harmony import */ var src_app_providers_api_api_service__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! src/app/providers/api/api.service */ 57985);
/* harmony import */ var _signin_signin_service__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../signin/signin.service */ 91265);






// import { environment } from '@environments/environment';

















let HomeService = class HomeService {
    constructor(insuranceService, dialogService, storage, router, thirdPartyService, iab, platform, firebaseAnalytics, clevertap, loadingService, symptomCheckerIntegrationService, apiService, signinService) {
        this.insuranceService = insuranceService;
        this.dialogService = dialogService;
        this.storage = storage;
        this.router = router;
        this.thirdPartyService = thirdPartyService;
        this.iab = iab;
        this.platform = platform;
        this.firebaseAnalytics = firebaseAnalytics;
        this.clevertap = clevertap;
        this.loadingService = loadingService;
        this.symptomCheckerIntegrationService = symptomCheckerIntegrationService;
        this.apiService = apiService;
        this.signinService = signinService;
        this.unsubscribe$ = new rxjs__WEBPACK_IMPORTED_MODULE_16__.Subject();
        this.getPolicyInformation();
    }
    getAllCareCard() {
        return (0,rxjs__WEBPACK_IMPORTED_MODULE_17__.of)([
            {
                avatar: 'assets/icon/CheckSymptoms.svg',
                title: 'homeCare.checkyourSymptoms',
                subtitle: 'homeCare.subTitle1',
                link: src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__.Screens.SymptomChecker,
            },
            {
                avatar: 'assets/images/chat-with-doctor.svg',
                title: 'homeCare.chatwithadoctor',
                subtitle: 'homeCare.subTitle2',
                callback: () => {
                    var _a;
                    this.handleExpiredPolicy((_a = this.currentPolicy) === null || _a === void 0 ? void 0 : _a.status, () => (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__awaiter)(this, void 0, void 0, function* () {
                        var _b, _c;
                        if (
                        // this.insuranceService.getPayerSettingValue().some(
                        //   (_) =>
                        //     (_.columnname == 'MyncEnableDrChat') &&
                        //     _.required == true,
                        // )
                        this.insuranceService.checkPayerSetting(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_0__.Constants.ENABLE_DR_CHAT, true)) {
                            if (this.platform.is('android')) {
                                const languageId = yield this.apiService.loadLanguageId();
                                this.thirdPartyService.setupAvaamoChat((_b = this.currentPolicy) === null || _b === void 0 ? void 0 : _b.userPolicyId, languageId);
                                // window?.Avaamo.openChatBox();
                                yield this.storage.set(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_0__.Constants.OPENNED_CHAT_WITH_DOCTOR, true);
                            }
                            else {
                                const languageId = yield this.apiService.loadLanguageId();
                                const userProfile = yield this.storage.get(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_0__.Constants.USER_PROFILE);
                                let lang = 'en';
                                if (languageId == 1) {
                                    lang = 'en';
                                }
                                else if (languageId == 2) {
                                    lang = 'fr';
                                }
                                else if (languageId == 3) {
                                    lang = 'ar';
                                }
                                const userID = yield this.storage.get(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_0__.Constants.USERID);
                                const drChatRequest = {
                                    partnerCode: 'NEXTCARELIGHT',
                                    userKey: userID.toString(),
                                    userDataNickName: (userProfile === null || userProfile === void 0 ? void 0 : userProfile.firstName) + ' ' + (userProfile === null || userProfile === void 0 ? void 0 : userProfile.lastName),
                                    userDataGender: userProfile.genderId == 1 ? 'MALE' :  true && 'FEMALE' !== void 0 ? 'FEMALE' : 'N_A',
                                    userDataYearOfBirth: new Date(userProfile.dateOfBirth).getFullYear(),
                                    language: lang,
                                };
                                this.insuranceService.getLinkDrChat(drChatRequest, (_c = this.currentPolicy) === null || _c === void 0 ? void 0 : _c.userPolicyId).subscribe((value) => (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__awaiter)(this, void 0, void 0, function* () {
                                    this.iab.create(`${value.redirectUrl}`, '_blank', 'location=no,toolbarposition=top,lefttoright=yes,clearcache=yes,clearsessioncache=yes,closebuttoncaption=X,toolbarcolor=#ffffff,closebuttoncolor=#92A2AC,hidenavigationbuttons=yes');
                                }));
                            }
                            // const config = {
                            //   disableClose: true,
                            //   panelClass: 'integration-panel',
                            // };
                            // this.dialog.open(ChatWithDoctorComponent, config);
                            // Get token for rendering symptom checker
                            // this.symptomCheckerIntegrationService.getToken().subscribe(
                            //   (response) => {
                            //     this.loadingService.dismissLoading();
                            //     // Config and open Symptom Checker dialog
                            //     const data = {
                            //       language: Constants.PREFERED_LANGUAGE,
                            //       token: response.token,
                            //     };
                            //     const config = {
                            //       disableClose: true,
                            //       panelClass: 'integration-panel',
                            //       data,
                            //     };
                            //     this.dialog.open(SymptomCheckerDialogComponent, config);
                            //   },
                            //   (error) => {
                            //     this.toastService.presentToast(error.message);
                            //   }
                            // );
                        }
                        else {
                            this.disableDrChat();
                        }
                    }));
                }
            },
            {
                avatar: 'assets/icon/TalkDoctor.svg',
                title: 'homeCare.videocallaDoctor',
                subtitle: 'homeCare.subTitle3',
                callback: () => {
                    var _a;
                    this.handleExpiredPolicy((_a = this.currentPolicy) === null || _a === void 0 ? void 0 : _a.status, () => (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__awaiter)(this, void 0, void 0, function* () {
                        if (
                        // this.insuranceService.getPayerSettingValue().some(
                        //   (_) =>
                        //     (_.columnname == 'MyncEnableDrChat') &&
                        //     _.required == true,
                        // )
                        // this.insuranceService.checkPayerSetting(Constants.SYMPTOM_CHECKER, false) ||
                        this.insuranceService.checkPayerSetting(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_0__.Constants.TELECONSULTATION, true)) {
                            this.thirdPartyService.startTeleconsulutationSDK();
                        }
                        else {
                            this.disableDrChat();
                        }
                    }));
                }
            },
            {
                avatar: 'assets/icon/BookAppointment.svg',
                title: 'homeCare.bookanAppointment',
                subtitle: 'homeCare.subTitle4',
                callback: () => (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__awaiter)(this, void 0, void 0, function* () {
                    this.thirdPartyService.openBookAppointment();
                })
            },
            {
                avatar: 'assets/icon/OrderMedication.svg',
                title: 'homeCare.orderyourMedication',
                subtitle: 'homeCare.subTitle5',
                callback: () => {
                    var _a;
                    this.handleExpiredPolicy((_a = this.currentPolicy) === null || _a === void 0 ? void 0 : _a.status, () => (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__awaiter)(this, void 0, void 0, function* () {
                        const myNCDrugDelivery = this.insuranceService.checkPayerSetting(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_0__.Constants.ENABLE_DRUG_DELIVERY, true);
                        if (
                        // this.insuranceService.getPayerSettingValue().some(
                        //   (_) => _.columnname == 'MyNCDrugDelivery'
                        // )
                        myNCDrugDelivery == true) {
                            this.router.navigate(['/' + 'auth/medication-delivery']);
                            yield this.storage.set(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_0__.Constants.OPENNED_MEDICATION_DELIVERY, true);
                        }
                        else {
                            this.dialogService
                                .open(src_app_shared_components_popup_message_popup_message_component__WEBPACK_IMPORTED_MODULE_8__.PopupMessageComponent, {
                                data: {
                                    content: 'disableDrChat.messageDisable',
                                    textYes: 'button.ok',
                                },
                                position: 'middle',
                                width: '90%',
                                // title: 'Message',
                                title: 'title.wrongTitleMessage',
                            })
                                .afterClosed()
                                .subscribe((isYes) => {
                                if (isYes) {
                                    this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__.Screens.HomeCare]);
                                }
                                else {
                                    this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__.Screens.HomeCare]);
                                }
                            });
                        }
                    }));
                }
            },
            {
                avatar: 'assets/icon/ViewMedicalUpdate.svg',
                title: 'homeCare.viewyourmedicalupdates',
                subtitle: 'homeCare.subTitle6',
                callback: () => (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__awaiter)(this, void 0, void 0, function* () {
                    const enableReferalsAndPrescriptions = this.insuranceService.checkPayerSetting(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_0__.Constants.ENABLE_REFERRALS_AND_PRESCRIPTIONS, true);
                    if (enableReferalsAndPrescriptions) {
                        this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__.Screens.ClaimsPrescription]);
                        yield this.storage.set(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_0__.Constants.OPENNED_CLAIMS_PRESCRIPTION, true);
                    }
                    else {
                        this.dialogService
                            .open(src_app_shared_components_popup_message_popup_message_component__WEBPACK_IMPORTED_MODULE_8__.PopupMessageComponent, {
                            data: {
                                content: 'linkinsurance.messageNotPolicy',
                                textYes: 'button.ok',
                            },
                            // title: 'Message',
                            title: 'title.wrongTitleMessage',
                            width: '90%',
                            position: 'middle',
                            canClose: true,
                        });
                    }
                })
            },
        ]);
    }
    getListDashboardCard() {
        return (0,rxjs__WEBPACK_IMPORTED_MODULE_17__.of)([
            {
                backgroundCard: 'linear-gradient(111.46deg, #1C2B5B 10.06%, #131F47 86.5%)',
                textColorHeader: '#FFFFFF',
                textColorContent: '#EFF3F5',
                imageCard: '../../../../assets/images/welcome.png',
                //button
                textColorButton: '#FFFFFF',
                backgroundButton: '#00BAB6',
                //text
                textHeader: 'welcome.welcome',
                textContent: 'welcome.welcomeDescription',
                textButton: 'welcome.welcomeButton',
                icon: '',
                colorIcon: '#FFFFFF',
                link: '',
                iconPosition: 'bottom',
                code: 'policy',
                callback: () => {
                    this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__.Screens.policyPage]);
                }
            },
            {
                backgroundCard: '#00BAB6',
                textColorHeader: '#FFFFFF',
                textColorContent: '#EFF3F5',
                imageCard: '../../../../assets/images/covered-network.png',
                //button
                textColorButton: '#FFFFFF',
                backgroundButton: 'linear-gradient(111.46deg, #1C2B5B 10.06%, #131F47 86.5%)',
                //text
                textHeader: 'coveredNetwork.coveredNetwork',
                textContent: 'coveredNetwork.coveredNetworkDescription',
                textButton: 'coveredNetwork.coveredNetworkButton',
                icon: '',
                colorIcon: '#FFFFFF',
                link: '',
                iconPosition: 'bottom',
                code: '',
                callback: () => (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__awaiter)(this, void 0, void 0, function* () {
                    this.thirdPartyService.openBookAppointment();
                })
            },
            // {
            //   backgroundCard:
            //     'linear-gradient(111.46deg, #1C2B5B 10.06%, #131F47 86.5%)',
            //   textColorHeader: '#FFFFFF',
            //   textColorContent: '#EFF3F5',
            //   imageCard: '../../../../assets/images/image-dashboard-card.svg',
            //   //button
            //   textColorButton: '#FFFFFF',
            //   backgroundButton: '#00BAB6',
            //   //text
            //   textHeader: 'listDashboardCard.didyouknow',
            //   textContent:
            //     'listDashboardCard.textContent1',
            //   textButton: 'listDashboardCard.textButton1',
            //   icon: '',
            //   colorIcon: '#FFFFFF',
            //   link: '',
            //   iconPosition: 'bottom',
            //   code: 'seeDoctor',
            //   callback: () => {
            //     this.handleExpirdPolyci(this.currentPolicy.status, async () => {
            //       if (
            //         this.insuranceService.getPayerSettingValue().some(
            //           (_) =>
            //             (_.columnname == 'MyncEnableDrChat') &&
            //             _.required == true,
            //         )
            //       ) {
            //         const info = await this.storage.get(Constants.HAH_INFO);
            //         Teleconsultation.openHahconnectSdk({ data: { user_object: info } }).then(() => {
            //           console.log('Done start teleconsultant');
            //         });
            //       } else {
            //         this.disableDrChat();
            //       }
            //     })
            //   }
            // },
            {
                backgroundCard: '#F4C8DD',
                textColorHeader: '#0D152E',
                textColorContent: '#0D152E',
                imageCard: '../../../../assets/images/image-dashboard-card-2.svg',
                //button
                textColorButton: '#FFFFFF',
                backgroundButton: '#99336C',
                //text
                textHeader: 'listDashboardCard.profilecompletion',
                textContent: 'listDashboardCard.textContent2',
                textButton: 'listDashboardCard.textButton2',
                icon: '',
                colorIcon: '#FFFFFF',
                link: '',
                iconPosition: 'center',
                code: 'profile',
                callback: () => (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__awaiter)(this, void 0, void 0, function* () {
                    const contacts = yield this.storage.get(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_0__.Constants.USER_CONTACT);
                    this.userContact = {
                        emails: contacts.filter(e => e.type === 'email'),
                        phones: contacts.filter(e => e.type === 'phone')
                    };
                    if (this.userContact.phones.length > 0) {
                        if (this.userContact.phones.some(e => e.isVerified === 1)) {
                            this.canVerifyPhone = false;
                        }
                        else {
                            this.canVerifyPhone = true;
                            this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__.Screens.OTPVerification], {
                                queryParams: {
                                    type: src_app_shared_data_enum_login_type__WEBPACK_IMPORTED_MODULE_10__.LoginType.Mobile,
                                    login: this.userContact.phones[0].contactInfo,
                                    redirectTo: src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__.Screens.Home,
                                    message: 'otpPhoneNumber.verify-phone-desc',
                                    redirectBack: src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__.Screens.Home,
                                    isShow: true
                                }
                            });
                        }
                        ;
                    }
                    else {
                        this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__.Screens.UpdatePhoneNumber], {
                            state: {
                                contact: {
                                    contactInfo: null,
                                    isVerified: null,
                                    contactID: null,
                                    isPrefered: null,
                                    type: src_app_shared_data_enum_login_type__WEBPACK_IMPORTED_MODULE_10__.LoginType.Mobile,
                                    userID: null,
                                },
                            }
                        });
                    }
                })
            },
            // {
            //   backgroundCard: '#B7DFDE',
            //   textColorHeader: '#0D152E',
            //   textColorContent: '#0D152E',
            //   imageCard: '../../../../assets/images/image-dashboard-card-3.svg',
            //   //button
            //   textColorButton: '#FFFFFF',
            //   backgroundButton: '#00BAB6',
            //   //text
            //   textHeader: 'listDashboardCard.E-Referral',
            //   textContent:
            //     'listDashboardCard.textContent3',
            //   textButton: 'listDashboardCard.textButton3',
            //   icon: '',
            //   colorIcon: '#FFFFFF',
            //   link: '',
            //   iconPosition: 'top',
            //   code : 'bookApointment',
            // },
            // {
            //   backgroundCard: '#F8CDD8',
            //   textColorHeader: '#0D152E',
            //   textColorContent: '#0D152E',
            //   imageCard: '../../../../assets/images/image-dashboard-card-3.svg',
            //   //button
            //   textColorButton: '#FFFFFF',
            //   backgroundButton: '#FF6592',
            //   //text
            //   textHeader: 'listDashboardCard.missingDocument',
            //   textContent: 'listDashboardCard.textContent4',
            //   textButton: 'listDashboardCard.textButton4',
            //   icon: '',
            //   colorIcon: '#FFFFFF',
            //   link: '',
            //   iconPosition: 'top',
            //   code : 'missDocument',
            // },
        ]);
    }
    getListMedicalCard() {
        return (0,rxjs__WEBPACK_IMPORTED_MODULE_17__.of)([
            this.symptomCheckerConfig(),
            {
                backgroundCard: '#FFFFFF',
                textColorHeader: '#0D152E',
                imageCard: '../../../../assets/images/medical-01.svg',
                textHeader: 'listMedicalCard.doctorTeleconsultation',
                link: '',
                callback: () => {
                    var _a;
                    this.handleExpiredPolicy((_a = this.currentPolicy) === null || _a === void 0 ? void 0 : _a.status, () => (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__awaiter)(this, void 0, void 0, function* () {
                        if (
                        // this.insuranceService.getPayerSettingValue().some(
                        //   (_) =>
                        //     (_.columnname == 'EnableTeleconsultation') &&
                        //     _.required == true,
                        // )
                        this.insuranceService.checkPayerSetting(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_0__.Constants.TELECONSULTATION, true)) {
                            this.thirdPartyService.startTeleconsulutationSDK();
                        }
                        else {
                            this.disableDrChat();
                        }
                    }));
                }
            },
            {
                backgroundCard: '#FFFFFF',
                textColorHeader: '#0D152E',
                imageCard: '../../../../assets/images/medical-02.svg',
                textHeader: 'listMedicalCard.facilitySearchBooking',
                link: '',
                callback: () => (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__awaiter)(this, void 0, void 0, function* () {
                    this.thirdPartyService.openBookAppointment();
                })
            },
            {
                backgroundCard: '#FFFFFF',
                textColorHeader: '#0D152E',
                imageCard: '../../../../assets/images/medical-03.svg',
                textHeader: 'listMedicalCard.medicationDelivery',
                link: '',
                callback: () => {
                    var _a;
                    this.handleExpiredPolicy((_a = this.currentPolicy) === null || _a === void 0 ? void 0 : _a.status, () => (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__awaiter)(this, void 0, void 0, function* () {
                        const myNCDrugDelivery = this.insuranceService.checkPayerSetting(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_0__.Constants.ENABLE_DRUG_DELIVERY, true);
                        if (
                        // this.insuranceService.getPayerSettingValue().some(
                        //   (_) => _.columnname == 'MyNCDrugDelivery'
                        // )
                        myNCDrugDelivery == true) {
                            this.router.navigate(['/' + 'auth/medication-delivery']);
                            yield this.storage.set(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_0__.Constants.OPENNED_MEDICATION_DELIVERY, true);
                        }
                        else {
                            this.dialogService
                                .open(src_app_shared_components_popup_message_popup_message_component__WEBPACK_IMPORTED_MODULE_8__.PopupMessageComponent, {
                                data: {
                                    content: 'disableDrChat.messageDisable',
                                    textYes: 'button.ok',
                                },
                                position: 'middle',
                                width: '90%',
                                // title: 'Message',
                                title: 'title.wrongTitleMessage',
                            })
                                .afterClosed()
                                .subscribe((isYes) => {
                                if (isYes) {
                                    // TODO
                                }
                                else {
                                    //
                                }
                            });
                        }
                    }));
                }
            },
        ]);
    }
    getListInsuranceCard() {
        return (0,rxjs__WEBPACK_IMPORTED_MODULE_17__.of)([
            {
                backgroundCard: '#FFFFFF',
                imageCard: '../../../../assets/images/insurance.svg',
                textHeader: 'listInsuranceCard.insuranceCoverage',
                textColorHeader: '#0D152E',
                textContent: 'listInsuranceCard.textContent1',
                textColorContent: '#7A7A7A',
                colorIcon: '#92A2AC',
                icon: '',
                link: 'auth/home/policy-page',
            },
            {
                backgroundCard: '#FFFFFF',
                imageCard: '../../../../assets/images/insurance-2.svg',
                textHeader: 'listInsuranceCard.claimsandPre-approvals',
                textColorHeader: '#0D152E',
                textContent: 'listInsuranceCard.textContent2',
                textColorContent: '#7A7A7A',
                colorIcon: '#92A2AC',
                icon: '',
                link: 'auth/home/claims-history',
            },
            {
                backgroundCard: '#FFFFFF',
                imageCard: '../../../../assets/images/insurance-3.svg',
                textHeader: 'listInsuranceCard.referralsandPrescriptions',
                textColorHeader: '#0D152E',
                textContent: 'listInsuranceCard.textContent3',
                textColorContent: '#7A7A7A',
                colorIcon: '#92A2AC',
                icon: '',
                link: 'auth/claims-prescription',
            },
            {
                backgroundCard: '#FFFFFF',
                imageCard: '../../../../assets/images/insurance-4.svg',
                textHeader: 'listInsuranceCard.healthcareProvider',
                textColorHeader: '#0D152E',
                textContent: 'listInsuranceCard.textContent4',
                textColorContent: '#7A7A7A',
                colorIcon: '#92A2AC',
                icon: '',
                link: '',
            },
        ]);
    }
    // public getListMemberCard(): Observable<MemberCard[]> {
    //   return of([{
    //     backgroundCard: '#FFFFFF',
    //     avatar: '../../../../assets/images/member.svg',
    //     name: 'Jenny Larson I',
    //     colorName: '#000000',
    //     textCardNumber: 'Card Number',
    //     textColorCardNumber: '#7A7A7A',
    //     cardNumber: '3DCA 1234 RD72 1212',
    //     colorCardNumber: '#0D152E',
    //     //button
    //     textButton: 'View Card',
    //     textColorButton: '#FFFFFF',
    //     backgroundButton: '#00BAB6',
    //     link: ''
    //   },
    //   {
    //     backgroundCard: '#FFFFFF',
    //     avatar: '../../../../assets/images/member.svg',
    //     name: 'Jenny Larson',
    //     colorName: '#000000',
    //     textCardNumber: 'Card Number',
    //     textColorCardNumber: '#7A7A7A',
    //     cardNumber: '3DCA 1234 RD72 1212',
    //     colorCardNumber: '#0D152E',
    //     //button
    //     textButton: 'View Card',
    //     textColorButton: '#FFFFFF',
    //     backgroundButton: '#00BAB6',
    //     link: ''
    //   }, {
    //     backgroundCard: '#FFFFFF',
    //     avatar: '../../../../assets/images/member.svg',
    //     name: 'Jenny Larson',
    //     colorName: '#000000',
    //     textCardNumber: 'Card Number',
    //     textColorCardNumber: '#7A7A7A',
    //     cardNumber: '3DCA 1234 RD72 1212',
    //     colorCardNumber: '#0D152E',
    //     //button
    //     textButton: 'View Card',
    //     textColorButton: '#FFFFFF',
    //     backgroundButton: '#00BAB6',
    //     link: ''
    //   }]);
    // }
    // getTermsLanguage(): Observable<TermsLanguage[]> {
    //   return of([
    //     {
    //       iso: SupportedLanguage.English,
    //       content: 'In Vietnam, there are many special gestures and customs. First of all, in terms of gestures, Vietnamese people greet each other by shaking hands. This is also a polite way of greeting that many people use. When meeting young people, they greet with a slight nod and when meeting elderly people, they often fold their arms and bow. When we meet friends, we often raise our hands. Vietnamese people often exchange business cards in the first meeting. When handing business cards to each other, they often use two hands to show respect for each other. In addition, Vietnamese people often talk about daily life, job, food or interest in small talk. They should avoid sensitive topics for small talk such as age, salary because it can make the others unpleasant. In short, we should keep and pass down our customs through the generations.',
    //     },
    //     {
    //       iso: SupportedLanguage.Arabic,
    //       // eslint-disable-next-line @typescript-eslint/quotes
    //       content: "في فيتنام ، هناك العديد من الإيماءات والعادات الخاصة. بادئ ذي بدء ، من حيث الإيماءات ، يحيي الفيتناميون بعضهم البعض بالمصافحة. هذه أيضًا طريقة مهذبة في التحية يستخدمها كثير من الناس. عند لقاء الشباب ، فإنهم يستقبلون بإيماءة طفيفة ، وعند مقابلة كبار السن ، غالبًا ما يطويون أذرعهم وقوسهم. عندما نلتقي بأصدقاء ، نرفع أيدينا غالبًا. غالبًا ما يتبادل الفيتناميون بطاقات العمل في الاجتماع الأول. عند تسليم بطاقات العمل لبعضهم البعض ، غالبًا ما يستخدمون اليدين لإظهار الاحترام لبعضهم البعض. بالإضافة إلى ذلك ، يتحدث الفيتناميون غالبًا عن الحياة اليومية أو العمل أو الطعام أو الاهتمام بالحديث الصغير. يجب عليهم تجنب الموضوعات الحساسة للحديث الصغير مثل العمر والراتب لأنها يمكن أن تجعل الآخرين غير سارة. باختصار ، يجب أن نحافظ على عاداتنا وننقلها عبر الأجيال.",
    //     },
    //     {
    //       iso: SupportedLanguage.China,
    //       content: '在越南，有許多特殊的手勢和習俗。首先，在手勢方面，越南人以握手的方式打招呼。這也是很多人使用的一種禮貌的打招呼方式。遇到年輕人時，他們會微微點頭打招呼，遇到老人時，他們往往會交叉雙臂鞠躬。當我們遇到朋友時，我們經常舉手。越南人經常在第一次見面時交換名片。在互相遞名片時，他們經常用兩隻手來表示對對方的尊重。此外，越南人經常聊起日常生活、工作、美食或閒聊的興趣。他們應該避免閒聊的敏感話題，例如年齡、薪水，因為這會使其他人不愉快。簡而言之，我們應該將我們的風俗習慣代代相傳。',
    //     },
    //     {
    //       iso: SupportedLanguage.French,
    //       content: "Au Vietnam, il existe de nombreux gestes et coutumes particuliers. Tout d'abord, en termes de gestes, les Vietnamiens se saluent en se serrant la main. C'est aussi une façon polie de saluer que beaucoup de gens utilisent. Lorsqu'ils rencontrent des jeunes, ils saluent d'un léger hochement de tête et lorsqu'ils rencontrent des personnes âgées, ils croisent souvent les bras et s'inclinent. Lorsque nous rencontrons des amis, nous levons souvent la main. Les Vietnamiens échangent souvent des cartes de visite lors de la première rencontre. Lorsqu'ils se remettent des cartes de visite, ils utilisent souvent leurs deux mains pour se respecter mutuellement. De plus, les Vietnamiens parlent souvent de la vie quotidienne, du travail, de la nourriture ou de l'intérêt pour de petites conversations. Ils doivent éviter les sujets sensibles pour les bavardages tels que l'âge, le salaire car cela peut rendre les autres désagréables. En bref, nous devons conserver et transmettre nos coutumes à travers les générations.",
    //     },
    //     {
    //       iso: SupportedLanguage.Greek,
    //       content: "Στο Βιετνάμ, υπάρχουν πολλές ειδικές χειρονομίες και έθιμα. Πρώτα απ 'όλα, όσον αφορά τις χειρονομίες, οι Βιετναμέζοι χαιρετούν ο ένας τον άλλο με χειραψία. Αυτός είναι επίσης ένας ευγενικός τρόπος χαιρετισμού που χρησιμοποιούν πολλοί άνθρωποι. Όταν συναντούν νέους, χαιρετούν με ένα ελαφρύ νεύμα και όταν συναντούν ηλικιωμένους, συχνά διπλώνουν τα χέρια και υποκλίνονται. Όταν συναντάμε φίλους, συχνά σηκώνουμε τα χέρια ψηλά. Οι Βιετναμέζοι ανταλλάσσουν συχνά επαγγελματικές κάρτες στην πρώτη συνάντηση. Όταν δίνουν επαγγελματικές κάρτες ο ένας στον άλλον, χρησιμοποιούν συχνά δύο χέρια για να δείξουν σεβασμό ο ένας για τον άλλον. Επιπλέον, οι Βιετναμέζοι μιλούν συχνά για την καθημερινή ζωή, τη δουλειά, το φαγητό ή το ενδιαφέρον τους για κουβέντα. Πρέπει να αποφεύγουν ευαίσθητα θέματα για κουβέντες όπως η ηλικία, ο μισθός γιατί μπορεί να κάνει τους άλλους δυσάρεστους. Εν ολίγοις, πρέπει να διατηρήσουμε και να μεταφέρουμε τα έθιμά μας στις γενιές.",
    //     },
    //     {
    //       iso: SupportedLanguage.Italian,
    //       content: "In Vietnam ci sono molti gesti e usanze speciali. Innanzitutto, in termini di gesti, i vietnamiti si salutano stringendosi la mano. Questo è anche un modo educato di salutare che molte persone usano. Quando incontrano i giovani, salutano con un leggero cenno del capo e quando incontrano gli anziani, spesso incrociano le braccia e si inchinano. Quando incontriamo amici, spesso alziamo la mano. I vietnamiti si scambiano spesso i biglietti da visita nel primo incontro. Quando si scambiano biglietti da visita, usano spesso due mani per mostrare rispetto reciproco. Inoltre, i vietnamiti parlano spesso di vita quotidiana, lavoro, cibo o interesse per chiacchiere. Dovrebbero evitare argomenti delicati per chiacchiere come l'età, lo stipendio perché possono rendere sgradevoli gli altri. In breve, dovremmo mantenere e tramandare le nostre usanze attraverso le generazioni.",
    //     },
    //   ]);
    // }
    getPolicyLanguage() {
        return (0,rxjs__WEBPACK_IMPORTED_MODULE_17__.of)([
            {
                iso: src_app_shared_data_enum_language__WEBPACK_IMPORTED_MODULE_1__.SupportedLanguage.English,
                content: 'In Vietnam, there are many special gestures and customs. First of all, in terms of gestures, Vietnamese people greet each other by shaking hands. This is also a polite way of greeting that many people use. When meeting young people, they greet with a slight nod and when meeting elderly people, they often fold their arms and bow. When we meet friends, we often raise our hands. Vietnamese people often exchange business cards in the first meeting. When handing business cards to each other, they often use two hands to show respect for each other. In addition, Vietnamese people often talk about daily life, job, food or interest in small talk. They should avoid sensitive topics for small talk such as age, salary because it can make the others unpleasant. In short, we should keep and pass down our customs through the generations.',
            },
            {
                iso: src_app_shared_data_enum_language__WEBPACK_IMPORTED_MODULE_1__.SupportedLanguage.Arabic,
                content: 'في فيتنام ، هناك العديد من الإيماءات والعادات الخاصة. بادئ ذي بدء ، من حيث الإيماءات ، يحيي الفيتناميون بعضهم البعض بالمصافحة. هذه أيضًا طريقة مهذبة في التحية يستخدمها كثير من الناس. عند لقاء الشباب ، فإنهم يستقبلون بإيماءة طفيفة ، وعند مقابلة كبار السن ، غالبًا ما يطويون أذرعهم وقوسهم. عندما نلتقي بأصدقاء ، نرفع أيدينا غالبًا. غالبًا ما يتبادل الفيتناميون بطاقات العمل في الاجتماع الأول. عند تسليم بطاقات العمل لبعضهم البعض ، غالبًا ما يستخدمون اليدين لإظهار الاحترام لبعضهم البعض. بالإضافة إلى ذلك ، يتحدث الفيتناميون غالبًا عن الحياة اليومية أو العمل أو الطعام أو الاهتمام بالحديث الصغير. يجب عليهم تجنب الموضوعات الحساسة للحديث الصغير مثل العمر والراتب لأنها يمكن أن تجعل الآخرين غير سارة. باختصار ، يجب أن نحافظ على عاداتنا وننقلها عبر الأجيال.',
            },
            {
                iso: src_app_shared_data_enum_language__WEBPACK_IMPORTED_MODULE_1__.SupportedLanguage.China,
                content: '在越南，有許多特殊的手勢和習俗。首先，在手勢方面，越南人以握手的方式打招呼。這也是很多人使用的一種禮貌的打招呼方式。遇到年輕人時，他們會微微點頭打招呼，遇到老人時，他們往往會交叉雙臂鞠躬。當我們遇到朋友時，我們經常舉手。越南人經常在第一次見面時交換名片。在互相遞名片時，他們經常用兩隻手來表示對對方的尊重。此外，越南人經常聊起日常生活、工作、美食或閒聊的興趣。他們應該避免閒聊的敏感話題，例如年齡、薪水，因為這會使其他人不愉快。簡而言之，我們應該將我們的風俗習慣代代相傳。',
            },
            {
                iso: src_app_shared_data_enum_language__WEBPACK_IMPORTED_MODULE_1__.SupportedLanguage.French,
                content: "Au Vietnam, il existe de nombreux gestes et coutumes particuliers. Tout d'abord, en termes de gestes, les Vietnamiens se saluent en se serrant la main. C'est aussi une façon polie de saluer que beaucoup de gens utilisent. Lorsqu'ils rencontrent des jeunes, ils saluent d'un léger hochement de tête et lorsqu'ils rencontrent des personnes âgées, ils croisent souvent les bras et s'inclinent. Lorsque nous rencontrons des amis, nous levons souvent la main. Les Vietnamiens échangent souvent des cartes de visite lors de la première rencontre. Lorsqu'ils se remettent des cartes de visite, ils utilisent souvent leurs deux mains pour se respecter mutuellement. De plus, les Vietnamiens parlent souvent de la vie quotidienne, du travail, de la nourriture ou de l'intérêt pour de petites conversations. Ils doivent éviter les sujets sensibles pour les bavardages tels que l'âge, le salaire car cela peut rendre les autres désagréables. En bref, nous devons conserver et transmettre nos coutumes à travers les générations.",
            },
            {
                iso: src_app_shared_data_enum_language__WEBPACK_IMPORTED_MODULE_1__.SupportedLanguage.Greek,
                content: "Στο Βιετνάμ, υπάρχουν πολλές ειδικές χειρονομίες και έθιμα. Πρώτα απ 'όλα, όσον αφορά τις χειρονομίες, οι Βιετναμέζοι χαιρετούν ο ένας τον άλλο με χειραψία. Αυτός είναι επίσης ένας ευγενικός τρόπος χαιρετισμού που χρησιμοποιούν πολλοί άνθρωποι. Όταν συναντούν νέους, χαιρετούν με ένα ελαφρύ νεύμα και όταν συναντούν ηλικιωμένους, συχνά διπλώνουν τα χέρια και υποκλίνονται. Όταν συναντάμε φίλους, συχνά σηκώνουμε τα χέρια ψηλά. Οι Βιετναμέζοι ανταλλάσσουν συχνά επαγγελματικές κάρτες στην πρώτη συνάντηση. Όταν δίνουν επαγγελματικές κάρτες ο ένας στον άλλον, χρησιμοποιούν συχνά δύο χέρια για να δείξουν σεβασμό ο ένας για τον άλλον. Επιπλέον, οι Βιετναμέζοι μιλούν συχνά για την καθημερινή ζωή, τη δουλειά, το φαγητό ή το ενδιαφέρον τους για κουβέντα. Πρέπει να αποφεύγουν ευαίσθητα θέματα για κουβέντες όπως η ηλικία, ο μισθός γιατί μπορεί να κάνει τους άλλους δυσάρεστους. Εν ολίγοις, πρέπει να διατηρήσουμε και να μεταφέρουμε τα έθιμά μας στις γενιές.",
            },
            {
                iso: src_app_shared_data_enum_language__WEBPACK_IMPORTED_MODULE_1__.SupportedLanguage.Italian,
                content: "In Vietnam ci sono molti gesti e usanze speciali. Innanzitutto, in termini di gesti, i vietnamiti si salutano stringendosi la mano. Questo è anche un modo educato di salutare che molte persone usano. Quando incontrano i giovani, salutano con un leggero cenno del capo e quando incontrano gli anziani, spesso incrociano le braccia e si inchinano. Quando incontriamo amici, spesso alziamo la mano. I vietnamiti si scambiano spesso i biglietti da visita nel primo incontro. Quando si scambiano biglietti da visita, usano spesso due mani per mostrare rispetto reciproco. Inoltre, i vietnamiti parlano spesso di vita quotidiana, lavoro, cibo o interesse per chiacchiere. Dovrebbero evitare argomenti delicati per chiacchiere come l'età, lo stipendio perché possono rendere sgradevoli gli altri. In breve, dovremmo mantenere e tramandare le nostre usanze attraverso le generazioni.",
            },
        ]);
    }
    getPolicyInformation() {
        this.insuranceService.getPolicyInformation().pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_19__.takeUntil)(this.unsubscribe$)).subscribe((res) => {
            if (!res)
                return;
            this.currentPolicy = res;
        });
    }
    handleExpiredPolicy(status, callback) {
        if (status) {
            if (status == 'expired') {
                this.dialogService
                    .open(src_app_shared_components_popup_message_popup_message_component__WEBPACK_IMPORTED_MODULE_8__.PopupMessageComponent, {
                    data: {
                        content: 'disableDrChat.serviceNotAvailablePolicy',
                        textYes: 'button.ok',
                    },
                    position: 'middle',
                    width: '90%',
                    title: 'disableDrChat.attention',
                });
            }
            else {
                callback();
            }
        }
        else {
            this.dialogService.open(src_app_shared_components_popup_message_popup_message_component__WEBPACK_IMPORTED_MODULE_8__.PopupMessageComponent, {
                data: {
                    content: 'policy.message',
                    textYes: 'policy.linkNewPolicy',
                },
                position: 'middle',
                title: 'title.wrongTitleMessage',
                width: '90%',
            }).afterClosed().subscribe(isYes => {
                console.log(isYes);
                if (isYes === true) {
                    this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__.Screens.addInsurance]).then(() => { });
                }
                else if (isYes === false) {
                    this.signinService.logout();
                }
            });
        }
    }
    disableDrChat() {
        this.dialogService
            .open(src_app_shared_components_popup_message_popup_message_component__WEBPACK_IMPORTED_MODULE_8__.PopupMessageComponent, {
            data: {
                content: 'disableDrChat.messageDisable',
                textYes: 'button.ok',
            },
            position: 'middle',
            width: '90%',
            title: 'disableDrChat.attention',
        })
            .afterClosed()
            .subscribe((isYes) => {
            if (isYes) {
                // TODO
            }
            else {
                //
            }
        });
    }
    showpopup(item) {
        var _a;
        if (!this.currentPolicy) {
            this.dialogService.open(src_app_shared_components_popup_message_popup_message_component__WEBPACK_IMPORTED_MODULE_8__.PopupMessageComponent, {
                data: {
                    content: 'policy.message',
                    textYes: 'policy.linkNewPolicy',
                },
                position: 'middle',
                title: 'title.wrongTitleMessage',
                width: '90%',
            }).afterClosed().subscribe(isYes => {
                console.log(isYes);
                if (isYes === true) {
                    this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__.Screens.addInsurance]).then(() => { });
                }
                else if (isYes === false) {
                    this.signinService.logout();
                }
            });
        }
        else if (((_a = this.currentPolicy) === null || _a === void 0 ? void 0 : _a.status) === 'expired') {
            this.dialogService
                .open(src_app_shared_components_popup_message_popup_message_component__WEBPACK_IMPORTED_MODULE_8__.PopupMessageComponent, {
                data: {
                    content: 'linkinsurance.messageNotPolicy',
                    textYes: 'button.ok',
                },
                position: 'middle',
                // title: 'Message',
                title: 'title.wrongTitleMessage',
                width: '90%',
            });
        }
        else {
            this.onClickMedicalCard(item);
        }
    }
    onClickMedicalCard(value) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__awaiter)(this, void 0, void 0, function* () {
            if (value.link == src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__.Screens.SymptomChecker
                || value.link == 'video-call-a-doctor') {
                this.firebaseAnalytics.logEvent(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_9__.GA4Event.SymptomCheckerSelected, { source: 'home' });
                this.clevertap.recordEventWithNameAndProps(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_9__.GA4Event.SymptomCheckerSelected, { source: 'home' });
                const symptomChecker = this.insuranceService.checkPayerSetting(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_0__.Constants.SYMPTOM_CHECKER, false);
                const teleconsultation = this.insuranceService.checkPayerSetting(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_0__.Constants.TELECONSULTATION, true);
                if (
                // this.insuranceService.getPayerSettingValue().some(
                //   (_) =>
                //     (_.columnname == 'Symptom Checker' ||
                //       _.columnname == 'EnableTeleconsultation') &&
                //     _.required == true,
                // )
                symptomChecker == true || teleconsultation == true) {
                    let canNavigate = true;
                    if (symptomChecker) {
                        canNavigate = yield this.symptomCheckersetting();
                    }
                    if (canNavigate) {
                        this.router.navigate(['/' + value.link]);
                    }
                }
                else {
                    this.dialogService
                        .open(src_app_shared_components_popup_message_popup_message_component__WEBPACK_IMPORTED_MODULE_8__.PopupMessageComponent, {
                        data: {
                            content: 'linkinsurance.messageNotPolicy',
                            textYes: 'button.yes',
                        },
                        // title: 'Message',
                        title: 'title.wrongTitleMessage',
                        position: 'middle',
                        width: '90%',
                    })
                        .afterClosed()
                        .subscribe((isYes) => {
                        if (isYes) {
                            // TODO
                        }
                        else {
                            //
                        }
                    });
                }
            }
            else {
                if (value.textHeader == 'Video Call a Doctor') {
                    this.firebaseAnalytics.logEvent(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_9__.GA4Event.VideoCallDoctorStarted, {});
                    this.clevertap.recordEventWithName(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_9__.GA4Event.VideoCallDoctorStarted);
                }
                else if (value.textHeader == 'Appointment Booking') {
                    this.firebaseAnalytics.logEvent(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_9__.GA4Event.InpersonAppointmentStarted, {});
                    this.clevertap.recordEventWithName(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_9__.GA4Event.InpersonAppointmentStarted);
                    this.iab.create(value.link);
                }
                this.router.navigate(['/' + value.link]);
            }
        });
    }
    symptomCheckersetting() {
        var _a, _b;
        return (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__awaiter)(this, void 0, void 0, function* () {
            const policyDetails = this.insuranceService.getPolicyDetailResponse();
            const requestSympChecker = {
                userPolicyId: (_a = this.currentPolicy) === null || _a === void 0 ? void 0 : _a.userPolicyId,
                mcontractId: (_b = this.currentPolicy) === null || _b === void 0 ? void 0 : _b.policiesDetails[0].mcontractId,
                productId: policyDetails[0].Beneficiary.PRODUCTID,
            };
            let enablechecker = false;
            // const columnname = this.payerSetting?.find(res => res.columnname === 'Symptom Checker')
            const columnname = this.insuranceService.checkPayerSetting(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_0__.Constants.SYMPTOM_CHECKER, true);
            if (columnname == true) {
                let symptomChecker = yield this.symptomCheckerIntegrationService.getSympChecker(requestSympChecker).toPromise();
                //  .subscribe(symptomChecker => {
                if (symptomChecker) {
                    if (symptomChecker.enablesymptomchecker === 1) {
                        enablechecker = true;
                        return enablechecker;
                    }
                    else {
                        this.stopSymptomAccess();
                        return enablechecker;
                    }
                }
                else {
                    this.stopSymptomAccess();
                    return enablechecker;
                }
                // })
            }
            else {
                this.stopSymptomAccess();
                return enablechecker;
            }
        });
    }
    stopSymptomAccess() {
        this.disableDrChat();
    }
    symptomCheckerConfig() {
        return {
            backgroundCard: '#FFFFFF',
            textColorHeader: '#0D152E',
            imageCard: '../../../../assets/images/medical.svg',
            textHeader: 'listMedicalCard.symptomChecker',
            link: src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__.Screens.SymptomChecker,
        };
    }
};
HomeService.ctorParameters = () => [
    { type: _insurance_insurance_service__WEBPACK_IMPORTED_MODULE_11__.InsuranceService },
    { type: src_app_shared_components_nextgen_dialog_nextgen_dialog_service__WEBPACK_IMPORTED_MODULE_7__.DialogService },
    { type: _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_20__.Storage },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_21__.Router },
    { type: _utilities_third_party_service__WEBPACK_IMPORTED_MODULE_13__.ThirdPartyService },
    { type: _awesome_cordova_plugins_in_app_browser_ngx__WEBPACK_IMPORTED_MODULE_5__.InAppBrowser },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_22__.Platform },
    { type: _awesome_cordova_plugins_firebase_analytics_ngx__WEBPACK_IMPORTED_MODULE_4__.FirebaseAnalytics },
    { type: _awesome_cordova_plugins_clevertap_ngx__WEBPACK_IMPORTED_MODULE_3__.CleverTap },
    { type: src_app_providers_common_loading_service__WEBPACK_IMPORTED_MODULE_6__.LoadingService },
    { type: _symptom_checker_symptom_checker_integration_service__WEBPACK_IMPORTED_MODULE_12__.SymptomCheckerIntegrationService },
    { type: src_app_providers_api_api_service__WEBPACK_IMPORTED_MODULE_14__.ApiService },
    { type: _signin_signin_service__WEBPACK_IMPORTED_MODULE_15__.SigninService }
];
HomeService = (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_23__.Injectable)({
        providedIn: 'root',
    })
], HomeService);



/***/ })

}]);
//# sourceMappingURL=default-src_app_service_home_home_service_ts.js.map