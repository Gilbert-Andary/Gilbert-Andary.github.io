"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_service-register_service-register_module_ts"],{

/***/ 66199:
/*!***************************************************************************!*\
  !*** ./src/app/pages/service-register/service-register-routing.module.ts ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ServiceRegisterPageRoutingModule": () => (/* binding */ ServiceRegisterPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _service_register_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./service-register.page */ 99678);




const routes = [
    {
        path: '',
        component: _service_register_page__WEBPACK_IMPORTED_MODULE_0__.ServiceRegisterPage
    }
];
let ServiceRegisterPageRoutingModule = class ServiceRegisterPageRoutingModule {
};
ServiceRegisterPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], ServiceRegisterPageRoutingModule);



/***/ }),

/***/ 36785:
/*!*******************************************************************!*\
  !*** ./src/app/pages/service-register/service-register.module.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ServiceRegisterPageModule": () => (/* binding */ ServiceRegisterPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _service_register_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./service-register-routing.module */ 66199);
/* harmony import */ var _service_register_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./service-register.page */ 99678);
/* harmony import */ var src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/shared/shared.module */ 44466);








let ServiceRegisterPageModule = class ServiceRegisterPageModule {
};
ServiceRegisterPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonicModule,
            _service_register_routing_module__WEBPACK_IMPORTED_MODULE_0__.ServiceRegisterPageRoutingModule,
            src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_2__.SharedModule,
        ],
        declarations: [_service_register_page__WEBPACK_IMPORTED_MODULE_1__.ServiceRegisterPage]
    })
], ServiceRegisterPageModule);



/***/ }),

/***/ 99678:
/*!*****************************************************************!*\
  !*** ./src/app/pages/service-register/service-register.page.ts ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ServiceRegisterPage": () => (/* binding */ ServiceRegisterPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _service_register_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./service-register.page.html?ngResource */ 86207);
/* harmony import */ var _service_register_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./service-register.page.scss?ngResource */ 92726);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ionic/storage-angular */ 80190);
/* harmony import */ var src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/shared/data/constants */ 74676);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/shared/data/enum/screen */ 68302);
/* harmony import */ var _capacitor_geolocation__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @capacitor/geolocation */ 7621);
/* harmony import */ var src_app_shared_data_enum_platform__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/shared/data/enum/platform */ 8760);
/* harmony import */ var src_app_providers_api_api_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/providers/api/api.service */ 57985);
/* harmony import */ var src_app_service_signup_signup_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/service/signup/signup.service */ 71234);
/* harmony import */ var src_app_providers_common_toast_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/providers/common/toast.service */ 42028);















let ServiceRegisterPage = class ServiceRegisterPage {
    constructor(storage, location, translate, router, apiService, signupService, toastService) {
        this.storage = storage;
        this.location = location;
        this.translate = translate;
        this.router = router;
        this.apiService = apiService;
        this.signupService = signupService;
        this.toastService = toastService;
        this.userLocation = {};
    }
    ngOnInit() {
        if (src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_2__.Constants.PLATFORM_NAME == src_app_shared_data_enum_platform__WEBPACK_IMPORTED_MODULE_5__.PlatformEnum.Browser) {
            this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_3__.Screens.Welcome]);
        }
        else {
            this.saveNotioficationRequestData();
            this.requestUserLocationPermission();
        }
    }
    saveNotioficationRequestData() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__awaiter)(this, void 0, void 0, function* () {
            yield this.storage.set(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_2__.Constants.NOTIFICATION_REQUESTED, 'true');
        });
    }
    requestUserLocationPermission() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__awaiter)(this, void 0, void 0, function* () {
            yield _capacitor_geolocation__WEBPACK_IMPORTED_MODULE_4__.Geolocation.requestPermissions().then((result) => {
                console.log('Request user location permission result: ' + result);
                // this.router.navigate(["/" + Screens.Welcome]);
            });
        });
    }
    onClickButtonBack() {
        this.location.back();
    }
};
ServiceRegisterPage.ctorParameters = () => [
    { type: _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_10__.Storage },
    { type: _angular_common__WEBPACK_IMPORTED_MODULE_11__.Location },
    { type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_12__.TranslateService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_13__.Router },
    { type: src_app_providers_api_api_service__WEBPACK_IMPORTED_MODULE_6__.ApiService },
    { type: src_app_service_signup_signup_service__WEBPACK_IMPORTED_MODULE_7__.SignupService },
    { type: src_app_providers_common_toast_service__WEBPACK_IMPORTED_MODULE_8__.ToastService }
];
ServiceRegisterPage = (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_14__.Component)({
        selector: 'app-service-register',
        template: _service_register_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_service_register_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], ServiceRegisterPage);



/***/ }),

/***/ 92726:
/*!******************************************************************************!*\
  !*** ./src/app/pages/service-register/service-register.page.scss?ngResource ***!
  \******************************************************************************/
/***/ ((module) => {

module.exports = ".service-register-container {\n  background-color: #FFFFFF;\n  height: 100%;\n}\n\n.service-register-back {\n  position: absolute;\n  width: 31px;\n  height: 28px;\n  left: 23px;\n  top: 40px;\n  background-color: transparent;\n  padding: 0;\n}\n\n.service-register-top {\n  background-color: #93DAD7;\n  width: 100%;\n  padding: 50px 0;\n}\n\n.service-register-img {\n  width: 50%;\n  display: block;\n  margin-left: auto;\n  margin-right: auto;\n}\n\n.service-register-notification-title {\n  font-size: 34px;\n  line-height: 42px;\n  color: #595959;\n  margin: 60px 60px 30px 60px;\n  text-align: center;\n  font-weight: 700;\n}\n\n.service-register-notification-description {\n  font-size: 19px;\n  line-height: 23px;\n  text-align: center;\n  color: #3C3C3C;\n  margin: 0 40px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNlcnZpY2UtcmVnaXN0ZXIucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0kseUJBQUE7RUFDQSxZQUFBO0FBQ0o7O0FBRUE7RUFDSSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0VBQ0EsVUFBQTtFQUNBLFNBQUE7RUFDQSw2QkFBQTtFQUNBLFVBQUE7QUFDSjs7QUFFQTtFQUNJLHlCQUFBO0VBQ0EsV0FBQTtFQUNBLGVBQUE7QUFDSjs7QUFFQTtFQUNJLFVBQUE7RUFDQSxjQUFBO0VBQ0EsaUJBQUE7RUFDQSxrQkFBQTtBQUNKOztBQUVBO0VBQ0ksZUFBQTtFQUNBLGlCQUFBO0VBQ0EsY0FBQTtFQUNBLDJCQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtBQUNKOztBQUVBO0VBQ0ksZUFBQTtFQUNBLGlCQUFBO0VBQ0Esa0JBQUE7RUFDQSxjQUFBO0VBQ0EsY0FBQTtBQUNKIiwiZmlsZSI6InNlcnZpY2UtcmVnaXN0ZXIucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLnNlcnZpY2UtcmVnaXN0ZXItY29udGFpbmVyIHtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICNGRkZGRkY7XHJcbiAgICBoZWlnaHQ6IDEwMCU7XHJcbn1cclxuXHJcbi5zZXJ2aWNlLXJlZ2lzdGVyLWJhY2sge1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgd2lkdGg6IDMxcHg7XHJcbiAgICBoZWlnaHQ6IDI4cHg7XHJcbiAgICBsZWZ0OiAyM3B4O1xyXG4gICAgdG9wOiA0MHB4O1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogdHJhbnNwYXJlbnQ7XHJcbiAgICBwYWRkaW5nOiAwO1xyXG59XHJcblxyXG4uc2VydmljZS1yZWdpc3Rlci10b3Age1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogIzkzREFENztcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgcGFkZGluZzogNTBweCAwO1xyXG59XHJcblxyXG4uc2VydmljZS1yZWdpc3Rlci1pbWcge1xyXG4gICAgd2lkdGg6IDUwJTtcclxuICAgIGRpc3BsYXk6IGJsb2NrO1xyXG4gICAgbWFyZ2luLWxlZnQ6IGF1dG87XHJcbiAgICBtYXJnaW4tcmlnaHQ6IGF1dG87XHJcbn1cclxuXHJcbi5zZXJ2aWNlLXJlZ2lzdGVyLW5vdGlmaWNhdGlvbi10aXRsZSB7XHJcbiAgICBmb250LXNpemU6IDM0cHg7XHJcbiAgICBsaW5lLWhlaWdodDogNDJweDtcclxuICAgIGNvbG9yOiAjNTk1OTU5O1xyXG4gICAgbWFyZ2luOiA2MHB4IDYwcHggMzBweCA2MHB4O1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgZm9udC13ZWlnaHQ6IDcwMDtcclxufVxyXG5cclxuLnNlcnZpY2UtcmVnaXN0ZXItbm90aWZpY2F0aW9uLWRlc2NyaXB0aW9uIHtcclxuICAgIGZvbnQtc2l6ZTogMTlweDtcclxuICAgIGxpbmUtaGVpZ2h0OiAyM3B4O1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgY29sb3I6ICMzQzNDM0M7XHJcbiAgICBtYXJnaW46IDAgNDBweDtcclxufSJdfQ== */";

/***/ }),

/***/ 86207:
/*!******************************************************************************!*\
  !*** ./src/app/pages/service-register/service-register.page.html?ngResource ***!
  \******************************************************************************/
/***/ ((module) => {

module.exports = "<div class=\"service-register-container\">\r\n  <button class=\"service-register-back\" (click)=\"onClickButtonBack()\"><img src=\"../../assets/icon/back-white.svg\" /></button>\r\n  <div class=\"service-register-top\"><img src=\"../../assets/images/notification-image.svg\" class=\"service-register-img\" /></div>\r\n  <p class=\"service-register-notification-title\">{{ 'serviceRegister.notificationTitle' | translate }}</p>\r\n  <p class=\"service-register-notification-description\">{{ 'serviceRegister.notificationDescription' | translate }}</p>\r\n</div>";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_service-register_service-register_module_ts.js.map