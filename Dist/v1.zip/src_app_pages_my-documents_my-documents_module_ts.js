"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_my-documents_my-documents_module_ts"],{

/***/ 99171:
/*!*****************************************************************************!*\
  !*** ./src/app/pages/my-documents/change-member/change-member.component.ts ***!
  \*****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ChangeMemberComponent": () => (/* binding */ ChangeMemberComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _change_member_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./change-member.component.html?ngResource */ 55753);
/* harmony import */ var _change_member_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./change-member.component.scss?ngResource */ 52719);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var src_app_providers_common_common_helper_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/providers/common/common-helper.service */ 27704);
/* harmony import */ var src_app_service_home_home_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/service/home/home.service */ 58425);
/* harmony import */ var src_app_service_insurance_insurance_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/service/insurance/insurance.service */ 57072);
/* harmony import */ var src_app_service_my_documents_my_documents_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/service/my-documents/my-documents.service */ 70929);
/* harmony import */ var src_app_shared_components_nextgen_dialog_nextgen_dialog_ref__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/shared/components/nextgen-dialog/nextgen-dialog-ref */ 99922);
/* harmony import */ var src_app_shared_components_nextgen_dialog_nextgen_dialog_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/shared/components/nextgen-dialog/nextgen-dialog.service */ 96485);










let ChangeMemberComponent = class ChangeMemberComponent {
    constructor(data, homeService, commonService, myDocumentService, dialogRef, insuranceService) {
        this.data = data;
        this.homeService = homeService;
        this.commonService = commonService;
        this.myDocumentService = myDocumentService;
        this.dialogRef = dialogRef;
        this.insuranceService = insuranceService;
        this.commonService.settingScreenLanguage();
        this.memberActive = data;
    }
    ngOnInit() {
        this.getMembers();
    }
    getMembers() {
        this.listMemberCard = this.insuranceService.getMemberListValue().map((item) => ({
            id: item.beneficiaryId,
            name: item.benefFullName,
            age: item.age.toString(),
            sex: item.gender == 1 ? 'Male' : 'Female',
            image: item.benefFullName.match(/(^\S\S?|\s\S)?/g).map(v => v.trim()).join('').match(/(^\S|\S$)?/g).join('').toLocaleUpperCase(),
        }));
    }
    onSelectMember(item) {
        this.dialogRef.close(item);
    }
};
ChangeMemberComponent.ctorParameters = () => [
    { type: undefined, decorators: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.Inject, args: [src_app_shared_components_nextgen_dialog_nextgen_dialog_service__WEBPACK_IMPORTED_MODULE_7__.DIALOG_DATA,] }] },
    { type: src_app_service_home_home_service__WEBPACK_IMPORTED_MODULE_3__.HomeService },
    { type: src_app_providers_common_common_helper_service__WEBPACK_IMPORTED_MODULE_2__.CommonHelperService },
    { type: src_app_service_my_documents_my_documents_service__WEBPACK_IMPORTED_MODULE_5__.MyDocumentsService },
    { type: src_app_shared_components_nextgen_dialog_nextgen_dialog_ref__WEBPACK_IMPORTED_MODULE_6__.NextgenDialogRef },
    { type: src_app_service_insurance_insurance_service__WEBPACK_IMPORTED_MODULE_4__.InsuranceService }
];
ChangeMemberComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.Component)({
        selector: 'app-change-member',
        template: _change_member_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_change_member_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], ChangeMemberComponent);



/***/ }),

/***/ 50077:
/*!***********************************************************************************!*\
  !*** ./src/app/pages/my-documents/edit-national-id/edit-national-id.component.ts ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EditNationalIDComponent": () => (/* binding */ EditNationalIDComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _edit_national_id_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./edit-national-id.component.html?ngResource */ 28050);
/* harmony import */ var _edit_national_id_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./edit-national-id.component.scss?ngResource */ 86817);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @ionic/storage-angular */ 80190);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs */ 92218);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! rxjs/operators */ 85921);
/* harmony import */ var src_app_model_control_control_model__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/model/control/control.model */ 45482);
/* harmony import */ var src_app_service_country_countries_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/service/country/countries.service */ 51249);
/* harmony import */ var src_app_service_insurance_insurance_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/service/insurance/insurance.service */ 57072);
/* harmony import */ var src_app_service_my_documents_my_documents_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/service/my-documents/my-documents.service */ 70929);
/* harmony import */ var src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/shared/data/constants */ 74676);
/* harmony import */ var src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/shared/data/enum/screen */ 68302);
















let EditNationalIDComponent = class EditNationalIDComponent {
    constructor(fb, navControl, countryService, myDocumentService, insuranceService, route, router, storage, platform) {
        var _a, _b, _c;
        this.fb = fb;
        this.navControl = navControl;
        this.countryService = countryService;
        this.myDocumentService = myDocumentService;
        this.insuranceService = insuranceService;
        this.route = route;
        this.router = router;
        this.storage = storage;
        this.platform = platform;
        this.TYPE = src_app_model_control_control_model__WEBPACK_IMPORTED_MODULE_2__.ControlType;
        this.errorMessage = '';
        this.isDisableUpdate = true;
        this.unsubscribe$ = new rxjs__WEBPACK_IMPORTED_MODULE_8__.Subject();
        this.params = this.route.snapshot.queryParams;
        this.nameMember = ((_a = this.params) === null || _a === void 0 ? void 0 : _a.nameMember) + "'s";
        this.beneficiaryId = (_b = this.params) === null || _b === void 0 ? void 0 : _b.beneficiaryId;
        if (!((_c = this.params) === null || _c === void 0 ? void 0 : _c.beneficiaryId)) {
            this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_7__.Screens.MyDocument]);
        }
    }
    ngOnInit() {
        this.nationalIDForm = this.fb.group({
            fullName: [null, [_angular_forms__WEBPACK_IMPORTED_MODULE_9__.Validators.required]],
            idNumber: [null, [_angular_forms__WEBPACK_IMPORTED_MODULE_9__.Validators.required]],
            nationality: [null, [_angular_forms__WEBPACK_IMPORTED_MODULE_9__.Validators.required]],
        });
        // this.getCountryList();
    }
    ionViewWillEnter() {
        this.unsubscribe$ = new rxjs__WEBPACK_IMPORTED_MODULE_8__.Subject();
        this.getInformation();
        this.checkDisableUpdate();
    }
    ionViewDidEnter() {
        this.subscription = this.platform.backButton.subscribeWithPriority(9999, () => {
            this.idBack = null;
            this.idFont = null;
            // this.navControl.back();
            this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_7__.Screens.MyDocument], { queryParams: { beneficiaryId: this.beneficiaryId } });
        });
    }
    ionViewWillLeave() {
        this.unsubscribe$.next();
        this.unsubscribe$.complete();
        this.subscription.unsubscribe();
    }
    onBack() {
        this.idBack = null;
        this.idFont = null;
        // this.navControl.back();
        this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_7__.Screens.MyDocument], { queryParams: { beneficiaryId: this.beneficiaryId } });
    }
    checkDisableUpdate() {
        if (this.idBack) {
            this.isDisableUpdate = false;
        }
        else {
            this.isDisableUpdate = true;
        }
    }
    onUpdate() {
        var _a, _b, _c, _d, _e, _f, _g;
        if (!this.idBack) {
            this.errorMessage = 'myDocument.uploadBackOf';
            return;
        }
        if (!this.idFont) {
            this.errorMessage = 'myDocument.uploadFontOf';
            return;
        }
        if (this.idFont && this.idBack) {
            this.errorMessage = '';
        }
        this.nationalIDForm.markAllAsTouched();
        this.nationalIDForm.markAsDirty();
        if (this.nationalIDForm.valid && this.enrolmentDTO) {
            // we will call api here!
            const fontbase64_1 = this.idFont.split(',');
            const fontbase64 = this.myDocumentService.resizeImage(fontbase64_1).split(',');
            const backbase64_1 = this.idBack.split(',');
            const backbase64 = this.myDocumentService.resizeImage(backbase64_1).split(',');
            this.myDocumentRequest = {
                seqId: 0,
                beneficiaryId: this.beneficiaryId,
                fileType: 1,
                userId: 0,
                fileId: 0,
                lastUpdateDate: '',
                creationDate: '',
                issueDate: '',
                expiryDate: this.enrolmentDTO.mrzDateOfExpiry,
                cardNumber: (_a = this.enrolmentDTO.mrzOptionalData) !== null && _a !== void 0 ? _a : (_b = this.dataDetect[0]) === null || _b === void 0 ? void 0 : _b.cardNumber,
                fileSource: 'Mobile',
                fileExtension: (_d = (_c = this.fileName) === null || _c === void 0 ? void 0 : _c.split('.').slice(-1)[0]) !== null && _d !== void 0 ? _d : (_e = this.dataDetect[0]) === null || _e === void 0 ? void 0 : _e.fileExtension,
                description: 'description test',
                originalFilename: (_f = this.fileName) !== null && _f !== void 0 ? _f : this.dataDetect[0].fileSource,
                uploadPath: '',
                fileTypeDescription: '',
                recto: `${fontbase64[1]}`,
                verso: `${backbase64[1]}`,
                dob: this.enrolmentDTO.mrzDOB,
                nationality: 0,
                beneficiaryWallet: null,
                enrolmentDTO: this.enrolmentDTO,
            };
            //check data
            if (this.isDisableUpdate == false && ((_g = this.dataDetect) === null || _g === void 0 ? void 0 : _g.length) > 0) {
                const data = {
                    beneficiaryId: this.beneficiaryId,
                    userPolicyId: this.currentPolicy.userPolicyId,
                    fileId: this.dataDetect[0].fileId,
                    filetype: this.dataDetect[0].fileType,
                    seqId: this.dataDetect[0].seqId,
                };
                // const passport={
                //   seqId: this.dataDetect[0].seqId,
                //   beneficiaryId: this.beneficiaryId,
                //   fileType: 1, //1-nationalID
                //   // userId: 
                //   // fileId: number;
                //   expiryDate: this.enrolmentDTO.mrzDateOfExpiry,
                //   cardNumber: this.enrolmentDTO.mrzOptionalData,
                //   fileSource: 'Mobile',
                //   fileExtension: this.fileName?.split('.').slice(-1)[0],
                //   description: 'description test',
                //   originalFilename: this.fileName,//
                //   // uploadPath: '',
                //   // fileTypeDescription: '',
                //   recto: `${base64[1]}`,
                //   // verso: '',
                //   dob: new Date('1/1/0001 12:00:00 AM'),
                //   // nationality: 0,
                //   // beneficiaryWallet:null,
                //   enrolmentDTO: this.enrolmentDTO??this.dataDetect[0].enrolmentDTO
                // }
                // this.editMyDocument(passport);
                this.deleteMyDocument(data, this.myDocumentRequest);
            }
            else {
                this.addMyDocument(this.myDocumentRequest);
            }
        }
    }
    onClickFont(evt) {
        if (evt.type === 'front' && evt.value) {
            this.idFont = evt.value;
            this.fileName = evt.name;
            this.fileFormat = evt.format;
            if (this.currentPolicy == undefined || !this.beneficiaryId) {
                this.idBack = null,
                    this.idFont = null;
            }
        }
    }
    onClickBack(evt) {
        if (evt.type === 'back' && evt.value) {
            this.idBack = evt.value;
            this.detectNationalID();
        }
        this.checkDisableUpdate();
    }
    getCountryList() {
        this.countryService.getCountries().pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_10__.takeUntil)(this.unsubscribe$)).subscribe((res) => {
            this.countryList = res.map(res => ({ id: res.countryId, name: res.countryDescription }));
        });
    }
    detectNationalID() {
        var _a;
        if (this.currentPolicy == undefined) {
            this.idBack = null,
                this.idFont = null;
        }
        if (this.idBack && this.currentPolicy != undefined) {
            const base64 = this.idBack.split(',');
            const request = {
                userPolicyId: (_a = this.currentPolicy) === null || _a === void 0 ? void 0 : _a.userPolicyId,
                beneficiaryId: this.beneficiaryId,
                requestSource: src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_6__.Constants.REQUEST_SOURCE
            };
            this.myDocumentService
                .detectNationalID(request, `"${base64[1]}"`).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_10__.takeUntil)(this.unsubscribe$)).subscribe((data) => {
                if (data) {
                    const dataDocument = {
                        fullName: data === null || data === void 0 ? void 0 : data.mrzName,
                        idNumber: data === null || data === void 0 ? void 0 : data.mrzOptionalData,
                        nationality: data.mrzNAtionaliy,
                    };
                    this.nationalIDForm.patchValue(dataDocument);
                    this.enrolmentDTO = data;
                }
            }, () => {
                this.isDisableUpdate = true;
            });
        }
    }
    getInformation() {
        this.insuranceService.getPolicyInformation().pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_10__.takeUntil)(this.unsubscribe$)).subscribe((res) => {
            if (!res)
                return;
            this.currentPolicy = res;
            // this.detectNationalID();  
            this.getNationalID();
        });
    }
    getNationalID() {
        const request = {
            beneficiaryId: this.beneficiaryId,
            userPolicyId: this.currentPolicy.userPolicyId,
            filetype: parseInt(this.route.snapshot.paramMap.get('id'))
        };
        this.myDocumentService.getMydocuments(request).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_10__.takeUntil)(this.unsubscribe$)).subscribe((res) => {
            var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l;
            if (res) {
                this.dataDetect = res;
                this.enrolmentDTO = (_a = res[0]) === null || _a === void 0 ? void 0 : _a.enrolmentDTO;
                const dataDocument = {
                    fullName: (_c = (_b = res[0]) === null || _b === void 0 ? void 0 : _b.enrolmentDTO) === null || _c === void 0 ? void 0 : _c.mrzName,
                    idNumber: (_f = (_e = (_d = res[0]) === null || _d === void 0 ? void 0 : _d.enrolmentDTO) === null || _e === void 0 ? void 0 : _e.mrzOptionalData) !== null && _f !== void 0 ? _f : (_g = res[0]) === null || _g === void 0 ? void 0 : _g.cardNumber,
                    nationality: (_j = (_h = res[0]) === null || _h === void 0 ? void 0 : _h.enrolmentDTO) === null || _j === void 0 ? void 0 : _j.mrzNAtionaliy,
                };
                this.nationalIDForm.patchValue(dataDocument);
                (_l = (_k = res[0]) === null || _k === void 0 ? void 0 : _k.enrolmentDTO) === null || _l === void 0 ? void 0 : _l.mrzDownload.forEach((value) => {
                    var _a;
                    if (value.fileType == '1' && res[0].recto != '' && this.idFont == null) {
                        const fileData = (_a = res[0].recto) !== null && _a !== void 0 ? _a : value.fileData;
                        this.idFont = `data:image/jpeg;base64,${fileData}`;
                    }
                    if (value.fileType == '2' && value.fileData != '' && this.idBack == null) {
                        this.idBack = `data:image/jpeg;base64,${value.fileData}`;
                    }
                });
            }
        });
    }
    addMyDocument(body) {
        this.myDocumentService.addMyDocument(this.currentPolicy.userPolicyId, body).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_10__.takeUntil)(this.unsubscribe$)).subscribe(() => {
            this.onBack();
        });
    }
    editMyDocument(body) {
        this.myDocumentService.editMyDocument(this.currentPolicy.userPolicyId, body).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_10__.takeUntil)(this.unsubscribe$)).subscribe(() => {
            this.onBack();
        });
    }
    deleteMyDocument(request, body) {
        this.myDocumentService.deleteMyDocument(request).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_10__.takeUntil)(this.unsubscribe$)).subscribe(() => {
            this.addMyDocument(body);
        });
    }
};
EditNationalIDComponent.ctorParameters = () => [
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_9__.FormBuilder },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_11__.NavController },
    { type: src_app_service_country_countries_service__WEBPACK_IMPORTED_MODULE_3__.CountriesService },
    { type: src_app_service_my_documents_my_documents_service__WEBPACK_IMPORTED_MODULE_5__.MyDocumentsService },
    { type: src_app_service_insurance_insurance_service__WEBPACK_IMPORTED_MODULE_4__.InsuranceService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_12__.ActivatedRoute },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_12__.Router },
    { type: _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_13__.Storage },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_11__.Platform }
];
EditNationalIDComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_14__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_15__.Component)({
        selector: 'app-edit-national-id',
        template: _edit_national_id_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_edit_national_id_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], EditNationalIDComponent);



/***/ }),

/***/ 56286:
/*!*******************************************************************!*\
  !*** ./src/app/pages/my-documents/my-documents-routing.module.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MyDocumentsRoutingModule": () => (/* binding */ MyDocumentsRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _edit_national_id_edit_national_id_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./edit-national-id/edit-national-id.component */ 50077);
/* harmony import */ var _my_documents_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./my-documents.page */ 25061);
/* harmony import */ var _other_other_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./other/other.component */ 89354);
/* harmony import */ var _passport_passport_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./passport/passport.component */ 76383);
/* harmony import */ var _visa_visa_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./visa/visa.component */ 5052);








const routes = [
    {
        path: '',
        component: _my_documents_page__WEBPACK_IMPORTED_MODULE_1__.MyDocumentsPage,
    },
    {
        path: 'edit-national-id/:id',
        component: _edit_national_id_edit_national_id_component__WEBPACK_IMPORTED_MODULE_0__.EditNationalIDComponent,
    },
    {
        path: 'passport/:id',
        component: _passport_passport_component__WEBPACK_IMPORTED_MODULE_3__.PassportComponent,
    },
    {
        path: 'visa/:id',
        component: _visa_visa_component__WEBPACK_IMPORTED_MODULE_4__.VisaComponent,
    },
    {
        path: 'other/:id',
        component: _other_other_component__WEBPACK_IMPORTED_MODULE_2__.OtherComponent,
    },
];
let MyDocumentsRoutingModule = class MyDocumentsRoutingModule {
};
MyDocumentsRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_7__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_7__.RouterModule],
    })
], MyDocumentsRoutingModule);



/***/ }),

/***/ 6901:
/*!***********************************************************!*\
  !*** ./src/app/pages/my-documents/my-documents.module.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MyDocumentsModule": () => (/* binding */ MyDocumentsModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _my_documents_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./my-documents-routing.module */ 56286);
/* harmony import */ var src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/shared/shared.module */ 44466);
/* harmony import */ var _my_documents_page__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./my-documents.page */ 25061);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _change_member_change_member_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./change-member/change-member.component */ 99171);
/* harmony import */ var _edit_national_id_edit_national_id_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./edit-national-id/edit-national-id.component */ 50077);
/* harmony import */ var _passport_passport_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./passport/passport.component */ 76383);
/* harmony import */ var _visa_visa_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./visa/visa.component */ 5052);
/* harmony import */ var _other_other_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./other/other.component */ 89354);













let MyDocumentsModule = class MyDocumentsModule {
};
MyDocumentsModule = (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_9__.NgModule)({
        declarations: [
            _my_documents_page__WEBPACK_IMPORTED_MODULE_2__.MyDocumentsPage,
            _change_member_change_member_component__WEBPACK_IMPORTED_MODULE_3__.ChangeMemberComponent,
            _edit_national_id_edit_national_id_component__WEBPACK_IMPORTED_MODULE_4__.EditNationalIDComponent,
            _passport_passport_component__WEBPACK_IMPORTED_MODULE_5__.PassportComponent,
            _visa_visa_component__WEBPACK_IMPORTED_MODULE_6__.VisaComponent,
            _other_other_component__WEBPACK_IMPORTED_MODULE_7__.OtherComponent
        ],
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_10__.CommonModule,
            _my_documents_routing_module__WEBPACK_IMPORTED_MODULE_0__.MyDocumentsRoutingModule,
            src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_1__.SharedModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_11__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_12__.IonicModule,
        ],
    })
], MyDocumentsModule);



/***/ }),

/***/ 25061:
/*!*********************************************************!*\
  !*** ./src/app/pages/my-documents/my-documents.page.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MyDocumentsPage": () => (/* binding */ MyDocumentsPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _my_documents_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./my-documents.page.html?ngResource */ 94137);
/* harmony import */ var _my_documents_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./my-documents.page.scss?ngResource */ 52984);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @ionic/storage-angular */ 80190);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! rxjs */ 92218);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! rxjs/operators */ 85921);
/* harmony import */ var src_app_providers_common_common_helper_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/providers/common/common-helper.service */ 27704);
/* harmony import */ var src_app_service_insurance_insurance_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/service/insurance/insurance.service */ 57072);
/* harmony import */ var src_app_service_my_documents_my_documents_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/service/my-documents/my-documents.service */ 70929);
/* harmony import */ var src_app_shared_components_nextgen_dialog_nextgen_dialog_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/shared/components/nextgen-dialog/nextgen-dialog.service */ 96485);
/* harmony import */ var src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/shared/data/constants */ 74676);
/* harmony import */ var src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/shared/data/enum/screen */ 68302);
/* harmony import */ var _change_member_change_member_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./change-member/change-member.component */ 99171);
















let MyDocumentsPage = class MyDocumentsPage {
    constructor(navCtrl, menu, commonService, modalCtrl, dialogSevice, router, insuranceService, myDocumentService, route, storage, platform) {
        this.navCtrl = navCtrl;
        this.menu = menu;
        this.commonService = commonService;
        this.modalCtrl = modalCtrl;
        this.dialogSevice = dialogSevice;
        this.router = router;
        this.insuranceService = insuranceService;
        this.myDocumentService = myDocumentService;
        this.route = route;
        this.storage = storage;
        this.platform = platform;
        this.EnableMapMyID = false;
        this.listDocument = [];
        this.idNumber = null;
        this.isLoading = false;
        this.listDefault = [{
                nameDocument: 'myDocument.nationalID',
                type: 1,
                idNumber: null,
                enable: this.EnableMapMyID
            },
            {
                nameDocument: 'myDocument.visa',
                type: 3,
                idNumber: null,
                enable: true
            },
            {
                nameDocument: 'myDocument.titleOther',
                type: 4,
                idNumber: null,
                enable: true
            }];
        this.unsubscribe$ = new rxjs__WEBPACK_IMPORTED_MODULE_9__.Subject();
        this.commonService.settingScreenLanguage();
    }
    ngOnInit() {
        this.EnableMapMyID = this.insuranceService.checkPayerSetting(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_6__.Constants.ENABLE_MAP_MyID, true);
    }
    ionViewWillEnter() {
        this.unsubscribe$ = new rxjs__WEBPACK_IMPORTED_MODULE_9__.Subject();
        this.getInformation();
    }
    ionViewDidEnter() {
        this.subscription = this.platform.backButton.subscribeWithPriority(9999, () => (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__awaiter)(this, void 0, void 0, function* () {
            this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_7__.Screens.Home]);
            this.menu.open('profile-menu');
        }));
    }
    ionViewWillLeave() {
        this.unsubscribe$.next();
        this.unsubscribe$.complete();
        this.subscription.unsubscribe();
    }
    onBack() {
        // this.router.navigate(['/' + Screens.Home]);
        this.router.navigate([
            '/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_7__.Screens.Home
        ]).then((_) => {
            this.menu.open('profile-menu');
        });
        // this.navCtrl.back();
        // this.menu.open('profile-menu');
    }
    onUploadNationalID(linkDocument) {
        switch (linkDocument === null || linkDocument === void 0 ? void 0 : linkDocument.type) {
            case 1:
                this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_7__.Screens.EditNationalId + '/' + linkDocument.type], { queryParams: { nameMember: this.memberActive.name, beneficiaryId: this.memberActive.id } });
                break;
            case 2:
                this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_7__.Screens.Passport + '/' + linkDocument.type], { queryParams: { nameMember: this.memberActive.name, beneficiaryId: this.memberActive.id } });
                break;
            case 3:
                this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_7__.Screens.Visa + '/' + linkDocument.type], { queryParams: { nameMember: this.memberActive.name, beneficiaryId: this.memberActive.id } });
                break;
            case 4:
                this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_7__.Screens.Other + '/' + linkDocument.type], { queryParams: { nameMember: this.memberActive.name, beneficiaryId: this.memberActive.id } });
                break;
        }
    }
    onChangeMember() {
        this.dialogSevice
            .open(_change_member_change_member_component__WEBPACK_IMPORTED_MODULE_8__.ChangeMemberComponent, {
            data: this.memberActive,
            height: '50%'
        })
            .afterClosed()
            .subscribe((res) => {
            if (res) {
                this.memberActive = res;
                const policy = Object.assign(Object.assign({}, this.currentPolicy), { beneficiaryId: res.id });
                this.getMyDocuments(policy, null);
            }
        });
    }
    getInformation() {
        this.insuranceService.getPolicyInformation().pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_11__.takeUntil)(this.unsubscribe$)).subscribe((res) => {
            var _a;
            if (!res)
                return;
            this.currentPolicy = res;
            this.getMyDocuments(this.currentPolicy, (_a = this.route.snapshot.queryParams) === null || _a === void 0 ? void 0 : _a.beneficiaryId);
            this.getMembers();
        });
    }
    getMyDocuments(policy, changebeneficiaryId) {
        var _a;
        const request = {
            beneficiaryId: changebeneficiaryId ? (_a = this.route.snapshot.queryParams) === null || _a === void 0 ? void 0 : _a.beneficiaryId : policy.beneficiaryId,
            userPolicyId: policy.userPolicyId,
            filetype: 0
        };
        this.myDocumentService.getMydocuments(request).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_11__.takeUntil)(this.unsubscribe$)).subscribe((res) => {
            if (res) {
                this.listDocument = res.map((data) => {
                    let myDocument;
                    if (data.fileType == 1)
                        myDocument = {
                            nameDocument: 'myDocument.nationalID',
                            type: data.fileType,
                            idNumber: data.cardNumber,
                            enable: this.EnableMapMyID
                        };
                    else if (data.fileType == 2)
                        myDocument = {
                            nameDocument: 'myDocument.passport',
                            type: data.fileType,
                            idNumber: data.cardNumber,
                            enable: true
                        };
                    else if (data.fileType == 3)
                        myDocument = {
                            nameDocument: 'myDocument.visa',
                            type: data.fileType,
                            idNumber: data.cardNumber,
                            enable: true
                        };
                    else
                        myDocument = {
                            nameDocument: 'myDocument.titleOther',
                            type: data.fileType,
                            idNumber: data.cardNumber,
                            enable: true
                        };
                    return myDocument;
                }).sort((a, b) => a.type - b.type);
            }
            else {
                this.listDocument = this.listDefault;
            }
            if (this.listDocument.filter(_ => _.type == 1).length == 0) {
                this.listDocument.splice(0, 0, {
                    nameDocument: 'myDocument.nationalID',
                    type: 1,
                    idNumber: null,
                    enable: this.EnableMapMyID
                });
            }
            if (this.listDocument.filter(_ => _.type == 2).length == 0) {
                this.listDocument.splice(1, 0, {
                    nameDocument: 'myDocument.passport',
                    type: 2,
                    idNumber: null,
                    enable: true
                });
            }
            if (this.listDocument.filter(_ => _.type == 3).length == 0) {
                this.listDocument.splice(2, 0, {
                    nameDocument: 'myDocument.visa',
                    type: 3,
                    idNumber: null,
                    enable: true
                });
            }
            if (this.listDocument.filter(_ => _.type == 4).length == 0) {
                this.listDocument.splice(3, 0, {
                    nameDocument: 'myDocument.titleOther',
                    type: 4,
                    idNumber: null,
                    enable: true
                });
            }
            this.isLoading = true;
        });
    }
    getMembers() {
        var _a;
        let currentMember = null;
        if ((_a = this.route.snapshot.queryParams) === null || _a === void 0 ? void 0 : _a.beneficiaryId) {
            currentMember = this.insuranceService.getMemberListValue().find(item => { var _a; return item.beneficiaryId.toString() === ((_a = this.route.snapshot.queryParams) === null || _a === void 0 ? void 0 : _a.beneficiaryId); });
        }
        else {
            currentMember = this.insuranceService.getMemberListValue().find(item => item.beneficiaryId === this.currentPolicy.beneficiaryId);
        }
        this.memberActive = {
            id: currentMember.beneficiaryId,
            name: currentMember.benefFullName,
            age: currentMember.age.toString(),
            sex: currentMember.gender == 1 ? 'Male' : 'Female',
            image: currentMember.benefFullName.match(/(^\S\S?|\s\S)?/g).map(v => v.trim()).join('').match(/(^\S|\S$)?/g).join('').toLocaleUpperCase()
        };
    }
};
MyDocumentsPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_12__.NavController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_12__.MenuController },
    { type: src_app_providers_common_common_helper_service__WEBPACK_IMPORTED_MODULE_2__.CommonHelperService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_12__.ModalController },
    { type: src_app_shared_components_nextgen_dialog_nextgen_dialog_service__WEBPACK_IMPORTED_MODULE_5__.DialogService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_13__.Router },
    { type: src_app_service_insurance_insurance_service__WEBPACK_IMPORTED_MODULE_3__.InsuranceService },
    { type: src_app_service_my_documents_my_documents_service__WEBPACK_IMPORTED_MODULE_4__.MyDocumentsService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_13__.ActivatedRoute },
    { type: _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_14__.Storage },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_12__.Platform }
];
MyDocumentsPage = (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_15__.Component)({
        selector: 'app-my-documents',
        template: _my_documents_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_my_documents_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], MyDocumentsPage);



/***/ }),

/***/ 89354:
/*!*************************************************************!*\
  !*** ./src/app/pages/my-documents/other/other.component.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "OtherComponent": () => (/* binding */ OtherComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _other_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./other.component.html?ngResource */ 5350);
/* harmony import */ var _other_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./other.component.scss?ngResource */ 15764);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ionic/storage-angular */ 80190);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs */ 92218);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs/operators */ 85921);
/* harmony import */ var src_app_model_control_control_model__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/model/control/control.model */ 45482);
/* harmony import */ var src_app_service_insurance_insurance_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/service/insurance/insurance.service */ 57072);
/* harmony import */ var src_app_service_my_documents_my_documents_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/service/my-documents/my-documents.service */ 70929);
/* harmony import */ var src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/shared/data/enum/screen */ 68302);














let OtherComponent = class OtherComponent {
    constructor(fb, navControl, myDocumentService, insuranceService, route, router, storage, platform) {
        var _a, _b, _c;
        this.fb = fb;
        this.navControl = navControl;
        this.myDocumentService = myDocumentService;
        this.insuranceService = insuranceService;
        this.route = route;
        this.router = router;
        this.storage = storage;
        this.platform = platform;
        this.TYPE = src_app_model_control_control_model__WEBPACK_IMPORTED_MODULE_2__.ControlType;
        this.errorMessage = '';
        this.issueDate = new Date().toISOString();
        this.expiryDate = new Date(new Date().setDate(new Date().getDate() + 7300)).toISOString();
        this.unsubscribe$ = new rxjs__WEBPACK_IMPORTED_MODULE_6__.Subject();
        this.params = this.route.snapshot.queryParams;
        this.nameMember = ((_a = this.params) === null || _a === void 0 ? void 0 : _a.nameMember) + "'s";
        this.beneficiaryId = (_b = this.params) === null || _b === void 0 ? void 0 : _b.beneficiaryId;
        if (!((_c = this.params) === null || _c === void 0 ? void 0 : _c.beneficiaryId)) {
            this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_5__.Screens.MyDocument]);
        }
    }
    ngOnInit() {
        this.otherForm = this.fb.group({
            otherNumber: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.required]],
            issueDate: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.required]],
            expiryDate: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.required]],
        });
    }
    ionViewWillEnter() {
        this.unsubscribe$ = new rxjs__WEBPACK_IMPORTED_MODULE_6__.Subject();
        this.getInformation();
    }
    ionViewDidEnter() {
        this.subscription = this.platform.backButton.subscribeWithPriority(9999, () => {
            this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_5__.Screens.MyDocument], { queryParams: { beneficiaryId: this.beneficiaryId } });
        });
    }
    ionViewWillLeave() {
        this.unsubscribe$.next();
        this.unsubscribe$.complete();
        this.subscription.unsubscribe();
    }
    getInformation() {
        this.insuranceService.getPolicyInformation().pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_8__.takeUntil)(this.unsubscribe$)).subscribe((res) => {
            if (!res)
                return;
            this.currentPolicy = res;
            this.getOther();
        });
    }
    onBack() {
        // this.navControl.back();
        this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_5__.Screens.MyDocument], { queryParams: { beneficiaryId: this.beneficiaryId } });
    }
    onUpdate() {
        var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q;
        if (!this.idFont) {
            this.errorMessage = 'myDocument.uploadOther';
            return;
        }
        this.otherForm.markAllAsTouched();
        this.otherForm.markAsDirty();
        if (this.otherForm.valid) {
            const idNumber = this.otherForm.controls['otherNumber'].value;
            const issueDate = this.otherForm.controls['issueDate'].value;
            const expiryDate = this.otherForm.controls['expiryDate'].value;
            const base64_1 = this.idFont.split(',');
            const base64 = this.myDocumentService.resizeImage(base64_1).split(',');
            this.other = {
                beneficiaryId: this.beneficiaryId,
                fileType: 4,
                issueDate: issueDate,
                expiryDate: expiryDate,
                cardNumber: idNumber,
                fileSource: 'NextGen Mobile App',
                fileExtension: (_b = (_a = this.fileName) === null || _a === void 0 ? void 0 : _a.split('.').slice(-1)[0]) !== null && _b !== void 0 ? _b : (_c = this.other) === null || _c === void 0 ? void 0 : _c.fileExtension,
                originalFilename: (_d = this.fileName) !== null && _d !== void 0 ? _d : (_e = this.other) === null || _e === void 0 ? void 0 : _e.originalFilename,
                recto: `${base64[1]}`
            };
            // console.log(this.passport);
            //check data
            if (this.otherValue) {
                // const data = {
                //   beneficiaryId: this.currentPolicy.beneficiaryId,
                //   userPolicyId: this.currentPolicy.userPolicyId,
                //   fileId: this.otherValue.fileId,
                //   filetype: this.otherValue.fileType
                // }
                // this.deleteMyDocument(data,this.other);
                const passport = {
                    seqId: (_f = this.otherValue) === null || _f === void 0 ? void 0 : _f.seqId,
                    beneficiaryId: (_g = this.otherValue) === null || _g === void 0 ? void 0 : _g.beneficiaryId,
                    fileType: (_h = this.otherValue) === null || _h === void 0 ? void 0 : _h.fileType,
                    userId: (_j = this.otherValue) === null || _j === void 0 ? void 0 : _j.userId,
                    fileId: (_k = this.otherValue) === null || _k === void 0 ? void 0 : _k.fileId,
                    issueDate: issueDate,
                    expiryDate: expiryDate,
                    cardNumber: idNumber,
                    fileSource: 'NextGen Mobile App',
                    fileExtension: (_m = (_l = this.fileName) === null || _l === void 0 ? void 0 : _l.split('.').slice(-1)[0]) !== null && _m !== void 0 ? _m : (_o = this.otherValue) === null || _o === void 0 ? void 0 : _o.fileExtension,
                    // description: this.passportValue?.seqId,
                    originalFilename: (_p = this.fileName) !== null && _p !== void 0 ? _p : (_q = this.otherValue) === null || _q === void 0 ? void 0 : _q.originalFilename,
                    // fileTypeDescription: this.passportValue?.fileTypeDescription,
                    recto: `${base64[1]}`,
                    // verso: this.passportValue?.verso,
                    // dob: this.passportValue?.dob,
                    // nationality: this.passportValue?.nationality,
                    // beneficiaryWallet:this.passportValue?.beneficiaryWallet,
                    // enrolmentDTO: this.passportValue?.enrolmentDTO
                };
                this.editMyDocument(passport);
            }
            else {
                this.addMyDocument(this.other);
            }
        }
    }
    onClickFont(evt) {
        if (evt.type === 'front' && evt.value) {
            this.idFont = evt.value;
            this.fileName = evt.name;
            this.fileFormat = evt.format;
            if (this.currentPolicy == undefined || !this.beneficiaryId) {
                this.idFont = null;
            }
        }
    }
    onChange(value) {
        this.issueDate = value;
        const expiryDate = this.otherForm.controls['expiryDate'].value;
        if (value > expiryDate) {
            this.otherForm.controls['expiryDate'].reset();
            this.otherForm.controls['expiryDate'].updateValueAndValidity();
        }
    }
    getOther() {
        const request = {
            beneficiaryId: this.beneficiaryId,
            userPolicyId: this.currentPolicy.userPolicyId,
            filetype: parseInt(this.route.snapshot.paramMap.get('id'))
        };
        this.myDocumentService.getMydocuments(request).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_8__.takeUntil)(this.unsubscribe$)).subscribe((res) => {
            var _a, _b, _c, _d, _e;
            if (res) {
                this.otherValue = res[0];
                const dataDocument = {
                    otherNumber: (_a = res[0]) === null || _a === void 0 ? void 0 : _a.cardNumber,
                    issueDate: (_b = res[0]) === null || _b === void 0 ? void 0 : _b.issueDate,
                    expiryDate: (_c = res[0]) === null || _c === void 0 ? void 0 : _c.expiryDate,
                };
                this.otherForm.patchValue(dataDocument);
                if (((_d = res[0]) === null || _d === void 0 ? void 0 : _d.recto) != null && this.idFont == null) {
                    this.idFont = `data:image/jpeg;base64,${(_e = res[0]) === null || _e === void 0 ? void 0 : _e.recto}`;
                }
            }
        });
    }
    addMyDocument(body) {
        this.myDocumentService.addMyDocument(this.currentPolicy.userPolicyId, body).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_8__.takeUntil)(this.unsubscribe$)).subscribe(() => {
            this.onBack();
        });
    }
    // deleteMyDocument(request:RequestDeleteMyDocument,body){
    //   this.myDocumentService.deleteMyDocument(request).pipe(takeUntil(this.unsubscribe$)).subscribe(()=>{      
    //     this.addMyDocument(body);
    //   });
    // }
    editMyDocument(body) {
        this.myDocumentService.editMyDocument(this.currentPolicy.userPolicyId, body).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_8__.takeUntil)(this.unsubscribe$)).subscribe(() => {
            this.onBack();
        });
    }
};
OtherComponent.ctorParameters = () => [
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormBuilder },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.NavController },
    { type: src_app_service_my_documents_my_documents_service__WEBPACK_IMPORTED_MODULE_4__.MyDocumentsService },
    { type: src_app_service_insurance_insurance_service__WEBPACK_IMPORTED_MODULE_3__.InsuranceService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_10__.ActivatedRoute },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_10__.Router },
    { type: _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_11__.Storage },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.Platform }
];
OtherComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_12__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_13__.Component)({
        selector: 'app-other',
        template: _other_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_other_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], OtherComponent);



/***/ }),

/***/ 76383:
/*!*******************************************************************!*\
  !*** ./src/app/pages/my-documents/passport/passport.component.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PassportComponent": () => (/* binding */ PassportComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _passport_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./passport.component.html?ngResource */ 35171);
/* harmony import */ var _passport_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./passport.component.scss?ngResource */ 50179);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ionic/storage-angular */ 80190);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs */ 92218);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs/operators */ 85921);
/* harmony import */ var src_app_model_control_control_model__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/model/control/control.model */ 45482);
/* harmony import */ var src_app_service_insurance_insurance_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/service/insurance/insurance.service */ 57072);
/* harmony import */ var src_app_service_my_documents_my_documents_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/service/my-documents/my-documents.service */ 70929);
/* harmony import */ var src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/shared/data/enum/screen */ 68302);














let PassportComponent = class PassportComponent {
    constructor(fb, navControl, myDocumentService, insuranceService, route, router, storage, platform) {
        var _a, _b, _c;
        this.fb = fb;
        this.navControl = navControl;
        this.myDocumentService = myDocumentService;
        this.insuranceService = insuranceService;
        this.route = route;
        this.router = router;
        this.storage = storage;
        this.platform = platform;
        this.TYPE = src_app_model_control_control_model__WEBPACK_IMPORTED_MODULE_2__.ControlType;
        this.errorMessage = '';
        this.issueDate = new Date().toISOString();
        this.expiryDate = new Date(new Date().setDate(new Date().getDate() + 7300)).toISOString();
        this.unsubscribe$ = new rxjs__WEBPACK_IMPORTED_MODULE_6__.Subject();
        this.params = this.route.snapshot.queryParams;
        this.nameMember = ((_a = this.params) === null || _a === void 0 ? void 0 : _a.nameMember) + "'s";
        this.beneficiaryId = (_b = this.params) === null || _b === void 0 ? void 0 : _b.beneficiaryId;
        if (!((_c = this.params) === null || _c === void 0 ? void 0 : _c.beneficiaryId)) {
            this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_5__.Screens.MyDocument]);
        }
    }
    ngOnInit() {
        var _a;
        this.passportForm = this.fb.group({
            passportNumber: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.required]],
            issueDate: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.required]],
            expiryDate: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.required]],
        });
        if ((_a = this.dataDocument) === null || _a === void 0 ? void 0 : _a.idNumber) {
            this.passportForm.patchValue(this.dataDocument);
            this.idFont = this.dataDocument.imageFront;
        }
    }
    ionViewWillEnter() {
        this.unsubscribe$ = new rxjs__WEBPACK_IMPORTED_MODULE_6__.Subject();
        this.getInformation();
    }
    ionViewDidEnter() {
        this.subscription = this.platform.backButton.subscribeWithPriority(9999, () => {
            this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_5__.Screens.MyDocument], { queryParams: { beneficiaryId: this.beneficiaryId } });
        });
    }
    ionViewWillLeave() {
        this.unsubscribe$.next();
        this.unsubscribe$.complete();
        this.subscription.unsubscribe();
    }
    getInformation() {
        this.insuranceService.getPolicyInformation().pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_8__.takeUntil)(this.unsubscribe$)).subscribe((res) => {
            if (!res)
                return;
            this.currentPolicy = res;
            this.getPassport();
        });
    }
    onBack() {
        // this.navControl.back();
        this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_5__.Screens.MyDocument], { queryParams: { beneficiaryId: this.beneficiaryId } });
    }
    onUpdate() {
        var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q;
        if (!this.idFont) {
            this.errorMessage = 'myDocument.uploadPassport';
            return;
        }
        else {
            this.errorMessage = '';
        }
        this.passportForm.markAllAsTouched();
        this.passportForm.markAsDirty();
        if (this.passportForm.valid) {
            const idNumber = this.passportForm.controls['passportNumber'].value;
            const issueDate = this.passportForm.controls['issueDate'].value;
            const expiryDate = this.passportForm.controls['expiryDate'].value;
            const base64_1 = this.idFont.split(',');
            const base64 = this.myDocumentService.resizeImage(base64_1).split(',');
            this.passport = {
                beneficiaryId: this.beneficiaryId,
                fileType: 2,
                issueDate: issueDate,
                expiryDate: expiryDate,
                cardNumber: idNumber,
                fileSource: 'NextGen Mobile App',
                fileExtension: (_b = (_a = this.fileName) === null || _a === void 0 ? void 0 : _a.split('.').slice(-1)[0]) !== null && _b !== void 0 ? _b : (_c = this.passportValue) === null || _c === void 0 ? void 0 : _c.fileExtension,
                originalFilename: (_d = this.fileName) !== null && _d !== void 0 ? _d : (_e = this.passportValue) === null || _e === void 0 ? void 0 : _e.originalFilename,
                recto: `${base64[1]}`
            };
            // console.log(this.passport);
            //check data
            if (this.passportValue) {
                // const data = {
                //   beneficiaryId: this.currentPolicy.beneficiaryId,
                //   userPolicyId: this.currentPolicy.userPolicyId,
                //   fileId: this.passportValue.fileId,
                //   filetype: this.passportValue.fileType
                // }
                const passport = {
                    seqId: (_f = this.passportValue) === null || _f === void 0 ? void 0 : _f.seqId,
                    beneficiaryId: (_g = this.passportValue) === null || _g === void 0 ? void 0 : _g.beneficiaryId,
                    fileType: (_h = this.passportValue) === null || _h === void 0 ? void 0 : _h.fileType,
                    userId: (_j = this.passportValue) === null || _j === void 0 ? void 0 : _j.userId,
                    fileId: (_k = this.passportValue) === null || _k === void 0 ? void 0 : _k.fileId,
                    issueDate: issueDate,
                    expiryDate: expiryDate,
                    cardNumber: idNumber,
                    fileSource: 'NextGen Mobile App',
                    fileExtension: (_m = (_l = this.fileName) === null || _l === void 0 ? void 0 : _l.split('.').slice(-1)[0]) !== null && _m !== void 0 ? _m : (_o = this.passportValue) === null || _o === void 0 ? void 0 : _o.fileExtension,
                    // description: this.passportValue?.seqId,
                    originalFilename: (_p = this.fileName) !== null && _p !== void 0 ? _p : (_q = this.passportValue) === null || _q === void 0 ? void 0 : _q.originalFilename,
                    // fileTypeDescription: this.passportValue?.fileTypeDescription,
                    recto: `${base64[1]}`,
                    // verso: this.passportValue?.verso,
                    // dob: this.passportValue?.dob,
                    // nationality: this.passportValue?.nationality,
                    // beneficiaryWallet:this.passportValue?.beneficiaryWallet,
                    // enrolmentDTO: this.passportValue?.enrolmentDTO
                };
                this.editMyDocument(passport);
            }
            else {
                this.addMyDocument(this.passport);
            }
        }
    }
    onClickFont(evt) {
        if (evt.type === 'front' && evt.value) {
            this.idFont = evt.value;
            this.fileName = evt.name;
            this.fileFormat = evt.format;
            if (this.currentPolicy == undefined || !this.beneficiaryId) {
                this.idFont = null;
            }
        }
    }
    onChange(value) {
        this.issueDate = value;
        const expiryDate = this.passportForm.controls['expiryDate'].value;
        if (value > expiryDate) {
            this.passportForm.controls['expiryDate'].reset();
            this.passportForm.controls['expiryDate'].updateValueAndValidity();
        }
    }
    getPassport() {
        const request = {
            beneficiaryId: this.beneficiaryId,
            userPolicyId: this.currentPolicy.userPolicyId,
            filetype: parseInt(this.route.snapshot.paramMap.get('id'))
        };
        this.myDocumentService.getMydocuments(request).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_8__.takeUntil)(this.unsubscribe$)).subscribe((res) => {
            var _a, _b, _c, _d, _e;
            if (res) {
                this.passportValue = res[0];
                const dataDocument = {
                    passportNumber: (_a = res[0]) === null || _a === void 0 ? void 0 : _a.cardNumber,
                    issueDate: (_b = res[0]) === null || _b === void 0 ? void 0 : _b.issueDate,
                    expiryDate: (_c = res[0]) === null || _c === void 0 ? void 0 : _c.expiryDate,
                };
                this.passportForm.patchValue(dataDocument);
                if (((_d = res[0]) === null || _d === void 0 ? void 0 : _d.recto) != null && this.idFont == null) {
                    this.idFont = `data:image/jpeg;base64,${(_e = res[0]) === null || _e === void 0 ? void 0 : _e.recto}`;
                }
            }
        });
    }
    addMyDocument(body) {
        this.myDocumentService.addMyDocument(this.currentPolicy.userPolicyId, body).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_8__.takeUntil)(this.unsubscribe$)).subscribe(() => {
            this.onBack();
        });
    }
    editMyDocument(body) {
        this.myDocumentService.editMyDocument(this.currentPolicy.userPolicyId, body).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_8__.takeUntil)(this.unsubscribe$)).subscribe(() => {
            this.onBack();
        });
    }
};
PassportComponent.ctorParameters = () => [
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormBuilder },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.NavController },
    { type: src_app_service_my_documents_my_documents_service__WEBPACK_IMPORTED_MODULE_4__.MyDocumentsService },
    { type: src_app_service_insurance_insurance_service__WEBPACK_IMPORTED_MODULE_3__.InsuranceService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_10__.ActivatedRoute },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_10__.Router },
    { type: _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_11__.Storage },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.Platform }
];
PassportComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_12__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_13__.Component)({
        selector: 'app-passport',
        template: _passport_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_passport_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], PassportComponent);



/***/ }),

/***/ 5052:
/*!***********************************************************!*\
  !*** ./src/app/pages/my-documents/visa/visa.component.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "VisaComponent": () => (/* binding */ VisaComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _visa_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./visa.component.html?ngResource */ 12304);
/* harmony import */ var _visa_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./visa.component.scss?ngResource */ 47838);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ionic/storage-angular */ 80190);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs */ 92218);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs/operators */ 85921);
/* harmony import */ var src_app_model_control_control_model__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/model/control/control.model */ 45482);
/* harmony import */ var src_app_service_insurance_insurance_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/service/insurance/insurance.service */ 57072);
/* harmony import */ var src_app_service_my_documents_my_documents_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/service/my-documents/my-documents.service */ 70929);
/* harmony import */ var src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/shared/data/enum/screen */ 68302);














let VisaComponent = class VisaComponent {
    constructor(fb, navControl, myDocumentService, insuranceService, route, router, storage, platform) {
        var _a, _b, _c;
        this.fb = fb;
        this.navControl = navControl;
        this.myDocumentService = myDocumentService;
        this.insuranceService = insuranceService;
        this.route = route;
        this.router = router;
        this.storage = storage;
        this.platform = platform;
        this.TYPE = src_app_model_control_control_model__WEBPACK_IMPORTED_MODULE_2__.ControlType;
        this.errorMessage = '';
        this.issueDate = new Date().toISOString();
        this.expiryDate = new Date(new Date().setDate(new Date().getDate() + 7300)).toISOString();
        this.unsubscribe$ = new rxjs__WEBPACK_IMPORTED_MODULE_6__.Subject();
        this.params = this.route.snapshot.queryParams;
        this.nameMember = ((_a = this.params) === null || _a === void 0 ? void 0 : _a.nameMember) + "'s";
        this.beneficiaryId = (_b = this.params) === null || _b === void 0 ? void 0 : _b.beneficiaryId;
        if (!((_c = this.params) === null || _c === void 0 ? void 0 : _c.beneficiaryId)) {
            this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_5__.Screens.MyDocument]);
        }
    }
    ngOnInit() {
        this.visaForm = this.fb.group({
            visaNumber: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.required]],
            issueDate: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.required]],
            expiryDate: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.required]],
        });
    }
    ionViewWillEnter() {
        this.unsubscribe$ = new rxjs__WEBPACK_IMPORTED_MODULE_6__.Subject();
        this.getInformation();
    }
    ionViewDidEnter() {
        this.subscription = this.platform.backButton.subscribeWithPriority(9999, () => {
            this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_5__.Screens.MyDocument], { queryParams: { beneficiaryId: this.beneficiaryId } });
        });
    }
    ionViewWillLeave() {
        this.unsubscribe$.next();
        this.unsubscribe$.complete();
        this.subscription.unsubscribe();
    }
    getInformation() {
        this.insuranceService.getPolicyInformation().pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_8__.takeUntil)(this.unsubscribe$)).subscribe((res) => {
            if (!res)
                return;
            this.currentPolicy = res;
            this.getVisa();
            console.log(this.expiryDate);
        });
    }
    onBack() {
        // this.navControl.back();
        this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_5__.Screens.MyDocument], { queryParams: { beneficiaryId: this.beneficiaryId } });
    }
    onUpdate() {
        var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q;
        if (!this.idFont) {
            this.errorMessage = 'myDocument.uploadVisa';
            return;
        }
        this.visaForm.markAllAsTouched();
        this.visaForm.markAsDirty();
        if (this.visaForm.valid) {
            const idNumber = this.visaForm.controls['visaNumber'].value;
            const issueDate = this.visaForm.controls['issueDate'].value;
            const expiryDate = this.visaForm.controls['expiryDate'].value;
            const base64_1 = this.idFont.split(',');
            const base64 = this.myDocumentService.resizeImage(base64_1).split(',');
            this.visa = {
                beneficiaryId: this.beneficiaryId,
                fileType: 3,
                issueDate: issueDate,
                expiryDate: expiryDate,
                cardNumber: idNumber,
                fileSource: 'NextGen Mobile App',
                fileExtension: (_b = (_a = this.fileName) === null || _a === void 0 ? void 0 : _a.split('.').slice(-1)[0]) !== null && _b !== void 0 ? _b : (_c = this.visa) === null || _c === void 0 ? void 0 : _c.fileExtension,
                originalFilename: (_d = this.fileName) !== null && _d !== void 0 ? _d : (_e = this.visa) === null || _e === void 0 ? void 0 : _e.originalFilename,
                recto: `${base64[1]}`
            };
            // console.log(this.passport);
            //check data
            if (this.visaValue) {
                // const data = {
                //   beneficiaryId: this.currentPolicy.beneficiaryId,
                //   userPolicyId: this.currentPolicy.userPolicyId,
                //   fileId: this.visaValue.fileId,
                //   filetype: this.visaValue.fileType
                // }
                // this.deleteMyDocument(data,this.visa);
                const visa = {
                    seqId: (_f = this.visaValue) === null || _f === void 0 ? void 0 : _f.seqId,
                    beneficiaryId: (_g = this.visaValue) === null || _g === void 0 ? void 0 : _g.beneficiaryId,
                    fileType: (_h = this.visaValue) === null || _h === void 0 ? void 0 : _h.fileType,
                    userId: (_j = this.visaValue) === null || _j === void 0 ? void 0 : _j.userId,
                    fileId: (_k = this.visaValue) === null || _k === void 0 ? void 0 : _k.fileId,
                    issueDate: issueDate,
                    expiryDate: expiryDate,
                    cardNumber: idNumber,
                    fileSource: 'NextGen Mobile App',
                    fileExtension: (_m = (_l = this.fileName) === null || _l === void 0 ? void 0 : _l.split('.').slice(-1)[0]) !== null && _m !== void 0 ? _m : (_o = this.visaValue) === null || _o === void 0 ? void 0 : _o.fileExtension,
                    // description: this.passportValue?.seqId,
                    originalFilename: (_p = this.fileName) !== null && _p !== void 0 ? _p : (_q = this.visaValue) === null || _q === void 0 ? void 0 : _q.originalFilename,
                    // fileTypeDescription: this.passportValue?.fileTypeDescription,
                    recto: `${base64[1]}`,
                    // verso: this.passportValue?.verso,
                    // dob: this.passportValue?.dob,
                    // nationality: this.passportValue?.nationality,
                    // beneficiaryWallet:this.passportValue?.beneficiaryWallet,
                    // enrolmentDTO: this.passportValue?.enrolmentDTO
                };
                this.editMyDocument(visa);
            }
            else {
                this.addMyDocument(this.visa);
            }
        }
    }
    onClickFont(evt) {
        if (evt.type === 'front' && evt.value) {
            this.idFont = evt.value;
            this.fileName = evt.name;
            this.fileFormat = evt.format;
            if (this.currentPolicy == undefined || !this.beneficiaryId) {
                this.idFont = null;
            }
        }
    }
    onChange(value) {
        this.issueDate = value;
        const expiryDate = this.visaForm.controls['expiryDate'].value;
        if (value > expiryDate) {
            this.visaForm.controls['expiryDate'].reset();
            this.visaForm.controls['expiryDate'].updateValueAndValidity();
        }
    }
    getVisa() {
        const request = {
            beneficiaryId: this.beneficiaryId,
            userPolicyId: this.currentPolicy.userPolicyId,
            filetype: parseInt(this.route.snapshot.paramMap.get('id'))
        };
        this.myDocumentService.getMydocuments(request).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_8__.takeUntil)(this.unsubscribe$)).subscribe((res) => {
            var _a, _b, _c, _d, _e;
            if (res) {
                this.visaValue = res[0];
                const dataDocument = {
                    visaNumber: (_a = res[0]) === null || _a === void 0 ? void 0 : _a.cardNumber,
                    issueDate: (_b = res[0]) === null || _b === void 0 ? void 0 : _b.issueDate,
                    expiryDate: (_c = res[0]) === null || _c === void 0 ? void 0 : _c.expiryDate,
                };
                this.visaForm.patchValue(dataDocument);
                if (((_d = res[0]) === null || _d === void 0 ? void 0 : _d.recto) != null && this.idFont == null) {
                    this.idFont = `data:image/jpeg;base64,${(_e = res[0]) === null || _e === void 0 ? void 0 : _e.recto}`;
                }
            }
        });
    }
    addMyDocument(body) {
        this.myDocumentService.addMyDocument(this.currentPolicy.userPolicyId, body).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_8__.takeUntil)(this.unsubscribe$)).subscribe(() => {
            this.onBack();
        });
    }
    // deleteMyDocument(request:RequestDeleteMyDocument,body){
    //   this.myDocumentService.deleteMyDocument(request).pipe(takeUntil(this.unsubscribe$)).subscribe(()=>{      
    //     this.addMyDocument(body);
    //   });
    // }
    editMyDocument(body) {
        this.myDocumentService.editMyDocument(this.currentPolicy.userPolicyId, body).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_8__.takeUntil)(this.unsubscribe$)).subscribe(() => {
            this.onBack();
        });
    }
};
VisaComponent.ctorParameters = () => [
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormBuilder },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.NavController },
    { type: src_app_service_my_documents_my_documents_service__WEBPACK_IMPORTED_MODULE_4__.MyDocumentsService },
    { type: src_app_service_insurance_insurance_service__WEBPACK_IMPORTED_MODULE_3__.InsuranceService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_10__.ActivatedRoute },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_10__.Router },
    { type: _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_11__.Storage },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.Platform }
];
VisaComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_12__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_13__.Component)({
        selector: 'app-visa',
        template: _visa_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_visa_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], VisaComponent);



/***/ }),

/***/ 70929:
/*!**************************************************************!*\
  !*** ./src/app/service/my-documents/my-documents.service.ts ***!
  \**************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MyDocumentsService": () => (/* binding */ MyDocumentsService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ 28784);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @environments/environment */ 92340);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ 64139);





let MyDocumentsService = class MyDocumentsService {
    constructor(httpClient) {
        this.httpClient = httpClient;
        this.url = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.ApiURL;
    }
    detectNationalID(request, body) {
        const data = {
            userPolicyId: request.userPolicyId,
            beneficiaryId: request.beneficiaryId,
            requestSource: request.requestSource
        };
        const headers = { 'content-type': 'application/json' };
        return this.httpClient.post(`${this.url}/mds/api/beneficiary/v1.0/nationaliddata`, body, { params: data, headers: headers });
    }
    getMembers() {
        return (0,rxjs__WEBPACK_IMPORTED_MODULE_1__.of)([
            { id: 1, name: 'Ann Larson', age: '79', sex: 'Male', image: '' },
            {
                id: 2,
                name: 'Jenny Larson',
                age: '37',
                sex: 'Female',
                image: '../../../assets/images/member.svg',
            },
            { id: 3, name: 'John Larson', age: '79', sex: 'Male', image: '' },
        ]);
    }
    getMydocuments(request) {
        const data = {
            beneficiaryId: request.beneficiaryId,
            userPolicyId: request.userPolicyId,
            filetype: request.filetype
        };
        return this.httpClient.get(`${this.url}/mds/api/beneficiary/v1.0/wallet`, { params: data });
    }
    deleteMyDocument(request) {
        const data = {
            beneficiaryId: request.beneficiaryId,
            userPolicyId: request.userPolicyId,
            fileId: request.fileId,
            filetype: request.filetype,
            seqId: request.seqId
        };
        return this.httpClient.delete(`${this.url}/mds/api/beneficiary/v1.0/wallet`, { params: data });
    }
    addMyDocument(userPolicyId, body) {
        const data = {
            userPolicyId: userPolicyId
        };
        return this.httpClient.post(`${this.url}/mds/api/beneficiary/v1.0/wallet`, body, { params: data });
    }
    editMyDocument(userPolicyId, body) {
        const data = {
            userPolicyId: userPolicyId
        };
        return this.httpClient.put(`${this.url}/mds/api/beneficiary/v1.0/wallet`, body, { params: data });
    }
    resizeImage(base64Str) {
        const img = new Image();
        img.src = base64Str;
        const canvas = document.createElement('canvas');
        const MAX_WIDTH = 70;
        const MAX_HEIGHT = 70;
        let width = img.width;
        let height = img.height;
        if (width > height) {
            if (width > MAX_WIDTH) {
                height *= MAX_WIDTH / width;
                width = MAX_WIDTH;
            }
        }
        else {
            if (height > MAX_HEIGHT) {
                width *= MAX_HEIGHT / height;
                height = MAX_HEIGHT;
            }
        }
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        ctx.drawImage(img, 0, 0, width, height);
        return canvas.toDataURL();
    }
};
MyDocumentsService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__.HttpClient }
];
MyDocumentsService = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Injectable)({
        providedIn: 'root',
    })
], MyDocumentsService);



/***/ }),

/***/ 52719:
/*!******************************************************************************************!*\
  !*** ./src/app/pages/my-documents/change-member/change-member.component.scss?ngResource ***!
  \******************************************************************************************/
/***/ ((module) => {

module.exports = ":root {\n  --nc-color-nextgen-neutral-grey-50: #f1efef;\n  --nc-color-nextgen-white: #ffffff;\n  --nc-color-nextgen-blue: #0d152e;\n  --nc-color-nextgen-green: #00908d;\n  --nc-color-nextgen-black: #000000;\n  --nc-color-nextgen-grey-background: #c8d3da;\n  --nc-color-nextgen-grey: #92a2ac;\n  --nc-color-nextgen-stone-grey: #fafafa;\n  --nc-color-nextgen-error: #fc1055;\n  --nc-color-nextgen-neutral-grey: #414141;\n  --nc-color-nextgen-fibrant-green: #00bab6;\n  --nc-color-nextgen-warning: #ffd048;\n  --nc-color-nextgen-green-background: #e6f2f2;\n  --nc-color-nextgen-neutral-grey-400: #7a7a7a;\n  --nc-color-nextgen-neutral-grey-100: #eff3f5;\n  --nc-color-nextgen-status-error: #ba0c3f;\n  --nc-color-nextgen-status-error-background: #ffeff4;\n  --nc-color-nextgen-status-warning: #cba127;\n  --nc-color-nextgen-status-warning-background: #fff8e6;\n  --nc-color-nextgen-blue-100: #dfeff2;\n  --nc-color-nextgen-error-red-700: #f62459;\n  --nc-color-nextgen-blue-500: #006192;\n  --nc-color-nextgen-blue-400: #79cdec;\n  --nc-color-nextgen-red-500: #ff6592;\n  --nc-color-nextgen-secondary-blue-300: #13a0d3;\n  --lumi-white-color: #ffffff;\n  --lumi-primary-yellow-color: #fab600;\n}\n\n.ion-color-green {\n  --ion-color-base: var(--nc-color-nextgen-green);\n  --ion-color-base-rgb: var(--nc-color-nextgen-green);\n  --ion-color-contrast: var(--nc-color-nextgen-white);\n  --ion-color-contrast-rgb: var(--nc-color-nextgen-green);\n  --ion-color-shade: var(--nc-color-nextgen-green);\n  --ion-color-tint: var(--nc-color-nextgen-green);\n}\n\n.select-member-title {\n  padding: 1rem;\n  color: var(--nc-color-nextgen-blue);\n}\n\n.member {\n  padding: 1rem;\n}\n\n.text-member {\n  color: var(--nc-color-nextgen-blue);\n}\n\n.img-member {\n  height: 40px;\n  width: 40px;\n  background-color: var(--nc-color-nextgen-grey-background);\n  border-radius: 50%;\n  justify-content: center;\n  display: flex;\n  align-items: center;\n}\n\n.img-member span {\n  color: var(--nc-color-nextgen-white);\n}\n\n.member-active {\n  background-color: rgba(var(--nc-color-nextgen-green), 0.1);\n  border-radius: 6px;\n}\n\n.content {\n  height: 100%;\n  padding: 1.5rem;\n  padding-bottom: 6rem;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFxjb2xvci5zY3NzIiwiY2hhbmdlLW1lbWJlci5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNDLDJDQUFBO0VBQ0EsaUNBQUE7RUFDQSxnQ0FBQTtFQUNBLGlDQUFBO0VBQ0EsaUNBQUE7RUFDQSwyQ0FBQTtFQUNBLGdDQUFBO0VBQ0Esc0NBQUE7RUFDQSxpQ0FBQTtFQUNBLHdDQUFBO0VBQ0EseUNBQUE7RUFDQSxtQ0FBQTtFQUNBLDRDQUFBO0VBQ0EsNENBQUE7RUFDQSw0Q0FBQTtFQUNBLHdDQUFBO0VBQ0EsbURBQUE7RUFDQSwwQ0FBQTtFQUNBLHFEQUFBO0VBQ0Esb0NBQUE7RUFDQSx5Q0FBQTtFQUNBLG9DQUFBO0VBQ0Esb0NBQUE7RUFDQSxtQ0FBQTtFQUNBLDhDQUFBO0VBRUEsMkJBQUE7RUFDQSxvQ0FBQTtBQ0FEOztBRGdDQTtFQUNDLCtDQUFBO0VBQ0EsbURBQUE7RUFDQSxtREFBQTtFQUNBLHVEQUFBO0VBQ0EsZ0RBQUE7RUFDQSwrQ0FBQTtBQzdCRDs7QUFuQ0E7RUFDSSxhQUFBO0VBQ0EsbUNEMEJpQjtBQ1lyQjs7QUFuQ0E7RUFDSSxhQUFBO0FBc0NKOztBQW5DQTtFQUNJLG1DRGtCaUI7QUNvQnJCOztBQW5DQTtFQUNJLFlBQUE7RUFDQSxXQUFBO0VBQ0EseUREZ0I0QjtFQ2Y1QixrQkFBQTtFQUNBLHVCQUFBO0VBQ0EsYUFBQTtFQUNBLG1CQUFBO0FBc0NKOztBQXJDSTtFQUNJLG9DRFFjO0FDK0J0Qjs7QUFuQ0E7RUFDSSwwREFBQTtFQUNBLGtCQUFBO0FBc0NKOztBQXBDQTtFQUNJLFlBQUE7RUFDQSxlQUFBO0VBQ0Esb0JBQUE7QUF1Q0oiLCJmaWxlIjoiY2hhbmdlLW1lbWJlci5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIjpyb290IHtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTUwOiAjZjFlZmVmO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi13aGl0ZTogI2ZmZmZmZjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZTogIzBkMTUyZTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW46ICMwMDkwOGQ7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWJsYWNrOiAjMDAwMDAwO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ncmV5LWJhY2tncm91bmQ6ICNjOGQzZGE7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWdyZXk6ICM5MmEyYWM7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0b25lLWdyZXk6ICNmYWZhZmE7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWVycm9yOiAjZmMxMDU1O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXk6ICM0MTQxNDE7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWZpYnJhbnQtZ3JlZW46ICMwMGJhYjY7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXdhcm5pbmc6ICNmZmQwNDg7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuLWJhY2tncm91bmQ6ICNlNmYyZjI7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS00MDA6ICM3YTdhN2E7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS0xMDA6ICNlZmYzZjU7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy1lcnJvcjogI2JhMGMzZjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yLWJhY2tncm91bmQ6ICNmZmVmZjQ7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy13YXJuaW5nOiAjY2JhMTI3O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtd2FybmluZy1iYWNrZ3JvdW5kOiAjZmZmOGU2O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlLTEwMDogI2RmZWZmMjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tZXJyb3ItcmVkLTcwMDogI2Y2MjQ1OTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZS01MDA6ICMwMDYxOTI7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWJsdWUtNDAwOiAjNzljZGVjO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1yZWQtNTAwOiAjZmY2NTkyO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zZWNvbmRhcnktYmx1ZS0zMDA6ICMxM2EwZDM7XHJcblxyXG5cdC0tbHVtaS13aGl0ZS1jb2xvcjogI2ZmZmZmZjtcclxuXHQtLWx1bWktcHJpbWFyeS15ZWxsb3ctY29sb3I6ICNmYWI2MDA7XHJcbn1cclxuJGNvbG9yLW5leHRnZW4tYmx1ZTogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlKTtcclxuJGNvbG9yLW5leHRnZW4tZ3JlZW46IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4pO1xyXG4kY29sb3ItbmV4dGdlbi13aGl0ZTogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi13aGl0ZSk7XHJcbiRjb2xvci1uZXh0Z2VuLWJsYWNrOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWJsYWNrKTtcclxuJGNvbG9yLW5leHRnZW4tZ3JleS1iYWNrZ3JvdW5kOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZXktYmFja2dyb3VuZCk7XHJcbiRjb2xvci1uZXh0Z2VuLWdyZXk6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JleSk7XHJcbiRjb2xvci1uZXh0Z2VuLXN0b25lLWdyZXk6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tc3RvbmUtZ3JleSk7XHJcbiRjb2xvci1uZXh0Z2VuLWVycm9yOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWVycm9yKTtcclxuJGNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5OiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleSk7XHJcbiRjb2xvci1uZXh0Z2VuLWZpYnJhbnQtZ3JlZW46IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZmlicmFudC1ncmVlbik7XHJcbiRjb2xvci1uZXh0Z2VuLXdhcm5pbmc6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4td2FybmluZyk7XHJcbiRjb2xvci1uZXh0Z2VuLWdyZWVuLWJhY2tncm91bmQ6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4tYmFja2dyb3VuZCk7XHJcbiRjb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS01MDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNTApO1xyXG4kY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNDAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS00MDApO1xyXG4kY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktMTAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS0xMDApO1xyXG4kY29sb3ItbmV4dGdlbi1zdGF0dXMtZXJyb3I6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yKTtcclxuJGNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yLWJhY2tncm91bmQ6IHZhcihcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yLWJhY2tncm91bmRcclxuKTtcclxuJGNvbG9yLW5leHRnZW4tc3RhdHVzLXdhcm5pbmc6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLXdhcm5pbmcpO1xyXG4kY29sb3ItbmV4dGdlbi1zdGF0dXMtd2FybmluZy1iYWNrZ3JvdW5kOiB2YXIoXHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy13YXJuaW5nLWJhY2tncm91bmRcclxuKTtcclxuJGNvbG9yLW5leHRnZW4tYmx1ZS0xMDA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZS0xMDApO1xyXG4kY29sb3ItbmV4dGdlbi1lcnJvci1yZWQtNzAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWVycm9yLXJlZC03MDApO1xyXG4kY29sb3ItbmV4dGdlbi1ibHVlLTUwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlLTUwMCk7XHJcbiRjb2xvci1uZXh0Z2VuLWJsdWUtNDAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWJsdWUtNDAwKTtcclxuJGNvbG9yLW5leHRnZW4tcmVkLTUwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1yZWQtNTAwKTtcclxuJGNvbG9yLW5leHRnZW4tc2Vjb25kYXJ5LWJsdWUtMzAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXNlY29uZGFyeS1ibHVlLTMwMCk7XHJcblxyXG4uaW9uLWNvbG9yLWdyZWVuIHtcclxuXHQtLWlvbi1jb2xvci1iYXNlOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuKTtcclxuXHQtLWlvbi1jb2xvci1iYXNlLXJnYjogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbik7XHJcblx0LS1pb24tY29sb3ItY29udHJhc3Q6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4td2hpdGUpO1xyXG5cdC0taW9uLWNvbG9yLWNvbnRyYXN0LXJnYjogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbik7XHJcblx0LS1pb24tY29sb3Itc2hhZGU6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4pO1xyXG5cdC0taW9uLWNvbG9yLXRpbnQ6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4pO1xyXG59XHJcbiIsIkBpbXBvcnQgXCIuLi8uLi8uLi8uLi9jb2xvci5zY3NzXCI7XHJcblxyXG4uc2VsZWN0LW1lbWJlci10aXRsZSB7XHJcbiAgICBwYWRkaW5nOiAxcmVtO1xyXG4gICAgY29sb3I6ICRjb2xvci1uZXh0Z2VuLWJsdWU7XHJcbn1cclxuXHJcbi5tZW1iZXIge1xyXG4gICAgcGFkZGluZzogMXJlbTtcclxufVxyXG5cclxuLnRleHQtbWVtYmVyIHtcclxuICAgIGNvbG9yOiAkY29sb3ItbmV4dGdlbi1ibHVlO1xyXG59XHJcblxyXG4uaW1nLW1lbWJlciB7XHJcbiAgICBoZWlnaHQ6IDQwcHg7XHJcbiAgICB3aWR0aDogNDBweDtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICRjb2xvci1uZXh0Z2VuLWdyZXktYmFja2dyb3VuZDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDUwJTtcclxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICBzcGFuIHtcclxuICAgICAgICBjb2xvcjogJGNvbG9yLW5leHRnZW4td2hpdGUgO1xyXG4gICAgfVxyXG59XHJcblxyXG4ubWVtYmVyLWFjdGl2ZSB7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiByZ2JhKCRjb2xvcjogJGNvbG9yLW5leHRnZW4tZ3JlZW4sICRhbHBoYTogMC4xKTtcclxuICAgIGJvcmRlci1yYWRpdXM6IDZweDtcclxufVxyXG4uY29udGVudCB7XHJcbiAgICBoZWlnaHQ6IDEwMCU7XHJcbiAgICBwYWRkaW5nOiAxLjVyZW07XHJcbiAgICBwYWRkaW5nLWJvdHRvbTogNnJlbTtcclxufSJdfQ== */";

/***/ }),

/***/ 86817:
/*!************************************************************************************************!*\
  !*** ./src/app/pages/my-documents/edit-national-id/edit-national-id.component.scss?ngResource ***!
  \************************************************************************************************/
/***/ ((module) => {

module.exports = ":root {\n  --nc-color-nextgen-neutral-grey-50: #f1efef;\n  --nc-color-nextgen-white: #ffffff;\n  --nc-color-nextgen-blue: #0d152e;\n  --nc-color-nextgen-green: #00908d;\n  --nc-color-nextgen-black: #000000;\n  --nc-color-nextgen-grey-background: #c8d3da;\n  --nc-color-nextgen-grey: #92a2ac;\n  --nc-color-nextgen-stone-grey: #fafafa;\n  --nc-color-nextgen-error: #fc1055;\n  --nc-color-nextgen-neutral-grey: #414141;\n  --nc-color-nextgen-fibrant-green: #00bab6;\n  --nc-color-nextgen-warning: #ffd048;\n  --nc-color-nextgen-green-background: #e6f2f2;\n  --nc-color-nextgen-neutral-grey-400: #7a7a7a;\n  --nc-color-nextgen-neutral-grey-100: #eff3f5;\n  --nc-color-nextgen-status-error: #ba0c3f;\n  --nc-color-nextgen-status-error-background: #ffeff4;\n  --nc-color-nextgen-status-warning: #cba127;\n  --nc-color-nextgen-status-warning-background: #fff8e6;\n  --nc-color-nextgen-blue-100: #dfeff2;\n  --nc-color-nextgen-error-red-700: #f62459;\n  --nc-color-nextgen-blue-500: #006192;\n  --nc-color-nextgen-blue-400: #79cdec;\n  --nc-color-nextgen-red-500: #ff6592;\n  --nc-color-nextgen-secondary-blue-300: #13a0d3;\n  --lumi-white-color: #ffffff;\n  --lumi-primary-yellow-color: #fab600;\n}\n\n.ion-color-green {\n  --ion-color-base: var(--nc-color-nextgen-green);\n  --ion-color-base-rgb: var(--nc-color-nextgen-green);\n  --ion-color-contrast: var(--nc-color-nextgen-white);\n  --ion-color-contrast-rgb: var(--nc-color-nextgen-green);\n  --ion-color-shade: var(--nc-color-nextgen-green);\n  --ion-color-tint: var(--nc-color-nextgen-green);\n}\n\n.add-bank-container {\n  background: var(--nc-color-nextgen-neutral-grey-50);\n}\n\n.title-text {\n  color: var(--nc-color-nextgen-blue);\n  max-width: 230px;\n  white-space: nowrap;\n  overflow: hidden;\n  text-overflow: ellipsis;\n}\n\n.document-type {\n  padding-top: 1rem;\n  padding-bottom: 1rem;\n}\n\n.document-type .text-document-type {\n  color: var(--nc-color-nextgen-blue);\n}\n\n.details {\n  padding-top: 2rem;\n  padding-bottom: 1rem;\n}\n\n.content-upload {\n  padding: 0.5rem;\n  background: var(--nc-color-nextgen-blue-100);\n  border: 1px solid var(--nc-color-nextgen-blue-400);\n  border-radius: 8px;\n  margin-top: 1rem;\n}\n\n.content-upload .content {\n  color: var(--nc-color-nextgen-neutral-grey);\n  text-align: justify;\n}\n\n.content-upload .icon-info {\n  color: var(--nc-color-nextgen-blue-500);\n}\n\n.errorMessage {\n  background: var(--nc-color-nextgen-status-error-background);\n  border: 1px solid var(--nc-color-nextgen-red-500);\n  border-radius: 8px;\n  padding: 0.5rem;\n  margin-bottom: 1rem;\n}\n\n.errorMessage .info-error {\n  color: var(--nc-color-nextgen-status-error);\n}\n\n.field {\n  padding-bottom: 1rem;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFxjb2xvci5zY3NzIiwiZWRpdC1uYXRpb25hbC1pZC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNDLDJDQUFBO0VBQ0EsaUNBQUE7RUFDQSxnQ0FBQTtFQUNBLGlDQUFBO0VBQ0EsaUNBQUE7RUFDQSwyQ0FBQTtFQUNBLGdDQUFBO0VBQ0Esc0NBQUE7RUFDQSxpQ0FBQTtFQUNBLHdDQUFBO0VBQ0EseUNBQUE7RUFDQSxtQ0FBQTtFQUNBLDRDQUFBO0VBQ0EsNENBQUE7RUFDQSw0Q0FBQTtFQUNBLHdDQUFBO0VBQ0EsbURBQUE7RUFDQSwwQ0FBQTtFQUNBLHFEQUFBO0VBQ0Esb0NBQUE7RUFDQSx5Q0FBQTtFQUNBLG9DQUFBO0VBQ0Esb0NBQUE7RUFDQSxtQ0FBQTtFQUNBLDhDQUFBO0VBRUEsMkJBQUE7RUFDQSxvQ0FBQTtBQ0FEOztBRGdDQTtFQUNDLCtDQUFBO0VBQ0EsbURBQUE7RUFDQSxtREFBQTtFQUNBLHVEQUFBO0VBQ0EsZ0RBQUE7RUFDQSwrQ0FBQTtBQzdCRDs7QUFuQ0E7RUFDSSxtRER1QzRCO0FDRGhDOztBQW5DQTtFQUNJLG1DRHVCaUI7RUN0QmpCLGdCQUFBO0VBQ0EsbUJBQUE7RUFDQSxnQkFBQTtFQUNBLHVCQUFBO0FBc0NKOztBQWxDQTtFQUNJLGlCQUFBO0VBQ0Esb0JBQUE7QUFxQ0o7O0FBbkNJO0VBQ0ksbUNEVWE7QUMyQnJCOztBQWpDQTtFQUNJLGlCQUFBO0VBQ0Esb0JBQUE7QUFvQ0o7O0FBN0JBO0VBQ0ksZUFBQTtFQUNBLDRDRGtCcUI7RUNqQnJCLGtEQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtBQWdDSjs7QUE5Qkk7RUFDSSwyQ0RIcUI7RUNJckIsbUJBQUE7QUFnQ1I7O0FBN0JJO0VBQ0ksdUNEU2lCO0FDc0J6Qjs7QUF6QkE7RUFDSSwyRERQb0M7RUNRcEMsaURBQUE7RUFDQSxrQkFBQTtFQUNBLGVBQUE7RUFDQSxtQkFBQTtBQTRCSjs7QUExQkk7RUFDSSwyQ0RmcUI7QUMyQzdCOztBQXpCQTtFQUNJLG9CQUFBO0FBNEJKIiwiZmlsZSI6ImVkaXQtbmF0aW9uYWwtaWQuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyI6cm9vdCB7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS01MDogI2YxZWZlZjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4td2hpdGU6ICNmZmZmZmY7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWJsdWU6ICMwZDE1MmU7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuOiAjMDA5MDhkO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ibGFjazogIzAwMDAwMDtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tZ3JleS1iYWNrZ3JvdW5kOiAjYzhkM2RhO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ncmV5OiAjOTJhMmFjO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zdG9uZS1ncmV5OiAjZmFmYWZhO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1lcnJvcjogI2ZjMTA1NTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5OiAjNDE0MTQxO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1maWJyYW50LWdyZWVuOiAjMDBiYWI2O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi13YXJuaW5nOiAjZmZkMDQ4O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbi1iYWNrZ3JvdW5kOiAjZTZmMmYyO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNDAwOiAjN2E3YTdhO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktMTAwOiAjZWZmM2Y1O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtZXJyb3I6ICNiYTBjM2Y7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy1lcnJvci1iYWNrZ3JvdW5kOiAjZmZlZmY0O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtd2FybmluZzogI2NiYTEyNztcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLXdhcm5pbmctYmFja2dyb3VuZDogI2ZmZjhlNjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZS0xMDA6ICNkZmVmZjI7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWVycm9yLXJlZC03MDA6ICNmNjI0NTk7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWJsdWUtNTAwOiAjMDA2MTkyO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlLTQwMDogIzc5Y2RlYztcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tcmVkLTUwMDogI2ZmNjU5MjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc2Vjb25kYXJ5LWJsdWUtMzAwOiAjMTNhMGQzO1xyXG5cclxuXHQtLWx1bWktd2hpdGUtY29sb3I6ICNmZmZmZmY7XHJcblx0LS1sdW1pLXByaW1hcnkteWVsbG93LWNvbG9yOiAjZmFiNjAwO1xyXG59XHJcbiRjb2xvci1uZXh0Z2VuLWJsdWU6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZSk7XHJcbiRjb2xvci1uZXh0Z2VuLWdyZWVuOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuKTtcclxuJGNvbG9yLW5leHRnZW4td2hpdGU6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4td2hpdGUpO1xyXG4kY29sb3ItbmV4dGdlbi1ibGFjazogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ibGFjayk7XHJcbiRjb2xvci1uZXh0Z2VuLWdyZXktYmFja2dyb3VuZDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmV5LWJhY2tncm91bmQpO1xyXG4kY29sb3ItbmV4dGdlbi1ncmV5OiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZXkpO1xyXG4kY29sb3ItbmV4dGdlbi1zdG9uZS1ncmV5OiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXN0b25lLWdyZXkpO1xyXG4kY29sb3ItbmV4dGdlbi1lcnJvcjogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1lcnJvcik7XHJcbiRjb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleTogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXkpO1xyXG4kY29sb3ItbmV4dGdlbi1maWJyYW50LWdyZWVuOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWZpYnJhbnQtZ3JlZW4pO1xyXG4kY29sb3ItbmV4dGdlbi13YXJuaW5nOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXdhcm5pbmcpO1xyXG4kY29sb3ItbmV4dGdlbi1ncmVlbi1iYWNrZ3JvdW5kOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuLWJhY2tncm91bmQpO1xyXG4kY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNTA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTUwKTtcclxuJGNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTQwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNDAwKTtcclxuJGNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTEwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktMTAwKTtcclxuJGNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy1lcnJvcik7XHJcbiRjb2xvci1uZXh0Z2VuLXN0YXR1cy1lcnJvci1iYWNrZ3JvdW5kOiB2YXIoXHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy1lcnJvci1iYWNrZ3JvdW5kXHJcbik7XHJcbiRjb2xvci1uZXh0Z2VuLXN0YXR1cy13YXJuaW5nOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy13YXJuaW5nKTtcclxuJGNvbG9yLW5leHRnZW4tc3RhdHVzLXdhcm5pbmctYmFja2dyb3VuZDogdmFyKFxyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtd2FybmluZy1iYWNrZ3JvdW5kXHJcbik7XHJcbiRjb2xvci1uZXh0Z2VuLWJsdWUtMTAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWJsdWUtMTAwKTtcclxuJGNvbG9yLW5leHRnZW4tZXJyb3ItcmVkLTcwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1lcnJvci1yZWQtNzAwKTtcclxuJGNvbG9yLW5leHRnZW4tYmx1ZS01MDA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZS01MDApO1xyXG4kY29sb3ItbmV4dGdlbi1ibHVlLTQwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlLTQwMCk7XHJcbiRjb2xvci1uZXh0Z2VuLXJlZC01MDA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tcmVkLTUwMCk7XHJcbiRjb2xvci1uZXh0Z2VuLXNlY29uZGFyeS1ibHVlLTMwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1zZWNvbmRhcnktYmx1ZS0zMDApO1xyXG5cclxuLmlvbi1jb2xvci1ncmVlbiB7XHJcblx0LS1pb24tY29sb3ItYmFzZTogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbik7XHJcblx0LS1pb24tY29sb3ItYmFzZS1yZ2I6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4pO1xyXG5cdC0taW9uLWNvbG9yLWNvbnRyYXN0OiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXdoaXRlKTtcclxuXHQtLWlvbi1jb2xvci1jb250cmFzdC1yZ2I6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4pO1xyXG5cdC0taW9uLWNvbG9yLXNoYWRlOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuKTtcclxuXHQtLWlvbi1jb2xvci10aW50OiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuKTtcclxufVxyXG4iLCJAaW1wb3J0IFwiLi4vLi4vLi4vLi4vY29sb3Iuc2Nzc1wiO1xyXG5cclxuLmFkZC1iYW5rLWNvbnRhaW5lciB7XHJcbiAgICBiYWNrZ3JvdW5kOiAkY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNTA7XHJcbn1cclxuXHJcbi50aXRsZS10ZXh0IHtcclxuICAgIGNvbG9yOiAkY29sb3ItbmV4dGdlbi1ibHVlO1xyXG4gICAgbWF4LXdpZHRoOiAyMzBweDtcclxuICAgIHdoaXRlLXNwYWNlOiBub3dyYXA7XHJcbiAgICBvdmVyZmxvdzogaGlkZGVuO1xyXG4gICAgdGV4dC1vdmVyZmxvdzogZWxsaXBzaXM7XHJcbn1cclxuXHJcblxyXG4uZG9jdW1lbnQtdHlwZSB7XHJcbiAgICBwYWRkaW5nLXRvcDogMXJlbTtcclxuICAgIHBhZGRpbmctYm90dG9tOiAxcmVtO1xyXG5cclxuICAgIC50ZXh0LWRvY3VtZW50LXR5cGUge1xyXG4gICAgICAgIGNvbG9yOiAkY29sb3ItbmV4dGdlbi1ibHVlO1xyXG4gICAgfVxyXG59XHJcblxyXG4uZGV0YWlscyB7XHJcbiAgICBwYWRkaW5nLXRvcDogMnJlbTtcclxuICAgIHBhZGRpbmctYm90dG9tOiAxcmVtO1xyXG59XHJcblxyXG5cclxuXHJcblxyXG5cclxuLmNvbnRlbnQtdXBsb2FkIHtcclxuICAgIHBhZGRpbmc6IDAuNXJlbTtcclxuICAgIGJhY2tncm91bmQ6ICRjb2xvci1uZXh0Z2VuLWJsdWUtMTAwO1xyXG4gICAgYm9yZGVyOiAxcHggc29saWQgJGNvbG9yLW5leHRnZW4tYmx1ZS00MDA7XHJcbiAgICBib3JkZXItcmFkaXVzOiA4cHg7XHJcbiAgICBtYXJnaW4tdG9wOiAxcmVtO1xyXG5cclxuICAgIC5jb250ZW50IHtcclxuICAgICAgICBjb2xvcjogJGNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5O1xyXG4gICAgICAgIHRleHQtYWxpZ246IGp1c3RpZnk7XHJcbiAgICB9XHJcblxyXG4gICAgLmljb24taW5mbyB7XHJcbiAgICAgICAgY29sb3I6ICRjb2xvci1uZXh0Z2VuLWJsdWUtNTAwO1xyXG4gICAgfVxyXG59XHJcblxyXG5cclxuXHJcbi5lcnJvck1lc3NhZ2Uge1xyXG4gICAgYmFja2dyb3VuZDogJGNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yLWJhY2tncm91bmQ7XHJcbiAgICBib3JkZXI6IDFweCBzb2xpZCAkY29sb3ItbmV4dGdlbi1yZWQtNTAwO1xyXG4gICAgYm9yZGVyLXJhZGl1czogOHB4O1xyXG4gICAgcGFkZGluZzogMC41cmVtO1xyXG4gICAgbWFyZ2luLWJvdHRvbTogMXJlbTtcclxuXHJcbiAgICAuaW5mby1lcnJvciB7XHJcbiAgICAgICAgY29sb3I6ICRjb2xvci1uZXh0Z2VuLXN0YXR1cy1lcnJvcjtcclxuICAgIH1cclxufVxyXG4uZmllbGR7XHJcbiAgICBwYWRkaW5nLWJvdHRvbTogMXJlbTtcclxufSJdfQ== */";

/***/ }),

/***/ 52984:
/*!**********************************************************************!*\
  !*** ./src/app/pages/my-documents/my-documents.page.scss?ngResource ***!
  \**********************************************************************/
/***/ ((module) => {

module.exports = ":root {\n  --nc-color-nextgen-neutral-grey-50: #f1efef;\n  --nc-color-nextgen-white: #ffffff;\n  --nc-color-nextgen-blue: #0d152e;\n  --nc-color-nextgen-green: #00908d;\n  --nc-color-nextgen-black: #000000;\n  --nc-color-nextgen-grey-background: #c8d3da;\n  --nc-color-nextgen-grey: #92a2ac;\n  --nc-color-nextgen-stone-grey: #fafafa;\n  --nc-color-nextgen-error: #fc1055;\n  --nc-color-nextgen-neutral-grey: #414141;\n  --nc-color-nextgen-fibrant-green: #00bab6;\n  --nc-color-nextgen-warning: #ffd048;\n  --nc-color-nextgen-green-background: #e6f2f2;\n  --nc-color-nextgen-neutral-grey-400: #7a7a7a;\n  --nc-color-nextgen-neutral-grey-100: #eff3f5;\n  --nc-color-nextgen-status-error: #ba0c3f;\n  --nc-color-nextgen-status-error-background: #ffeff4;\n  --nc-color-nextgen-status-warning: #cba127;\n  --nc-color-nextgen-status-warning-background: #fff8e6;\n  --nc-color-nextgen-blue-100: #dfeff2;\n  --nc-color-nextgen-error-red-700: #f62459;\n  --nc-color-nextgen-blue-500: #006192;\n  --nc-color-nextgen-blue-400: #79cdec;\n  --nc-color-nextgen-red-500: #ff6592;\n  --nc-color-nextgen-secondary-blue-300: #13a0d3;\n  --lumi-white-color: #ffffff;\n  --lumi-primary-yellow-color: #fab600;\n}\n\n.ion-color-green {\n  --ion-color-base: var(--nc-color-nextgen-green);\n  --ion-color-base-rgb: var(--nc-color-nextgen-green);\n  --ion-color-contrast: var(--nc-color-nextgen-white);\n  --ion-color-contrast-rgb: var(--nc-color-nextgen-green);\n  --ion-color-shade: var(--nc-color-nextgen-green);\n  --ion-color-tint: var(--nc-color-nextgen-green);\n}\n\n.add-bank-container {\n  background: var(--nc-color-nextgen-neutral-grey-50);\n}\n\n.title-text {\n  color: var(--nc-color-nextgen-blue);\n}\n\n.card-member {\n  background: var(--nc-color-nextgen-white);\n  box-shadow: 0px 1px 2px rgba(0, 0, 0, 0.1);\n  border-radius: 8px;\n  padding: 1rem;\n}\n\n.card-member .name-member {\n  color: var(--nc-color-nextgen-blue);\n}\n\n.card-member .age-sex {\n  color: var(--nc-color-nextgen-grey);\n  padding-top: 0.25rem;\n}\n\n.card-member .change {\n  color: var(--nc-color-nextgen-green);\n  float: right;\n}\n\n.card-member .img-member {\n  width: 3rem;\n  height: 3rem;\n  background-color: var(--nc-color-nextgen-grey-background);\n  border-radius: 50%;\n  justify-content: center;\n  display: flex;\n  align-items: center;\n}\n\n.card-member .img-member span {\n  color: var(--nc-color-nextgen-white);\n}\n\n.document-type {\n  padding-top: 1rem;\n  padding-bottom: 1rem;\n}\n\n.document-type .text-document-type {\n  color: var(--nc-color-nextgen-blue);\n}\n\n.card-document {\n  background: var(--nc-color-nextgen-white);\n  box-shadow: 0px 1px 2px rgba(0, 0, 0, 0.1);\n  border-radius: 8px;\n  padding: 1rem;\n  margin-bottom: 0.5rem;\n}\n\n.card-document .title-document {\n  color: var(--nc-color-nextgen-blue);\n  padding-bottom: 0.25rem;\n}\n\n.card-document .document {\n  color: var(--nc-color-nextgen-green);\n  padding-right: 0.25rem;\n}\n\n.card-document .document .icon-check {\n  width: 1rem;\n  height: 1rem;\n  margin-left: 0.5rem;\n  margin-right: 0.5rem;\n}\n\n.icon-right {\n  text-align: end;\n}\n\n.icon-right .icon {\n  height: 19px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXGNvbG9yLnNjc3MiLCJteS1kb2N1bWVudHMucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0MsMkNBQUE7RUFDQSxpQ0FBQTtFQUNBLGdDQUFBO0VBQ0EsaUNBQUE7RUFDQSxpQ0FBQTtFQUNBLDJDQUFBO0VBQ0EsZ0NBQUE7RUFDQSxzQ0FBQTtFQUNBLGlDQUFBO0VBQ0Esd0NBQUE7RUFDQSx5Q0FBQTtFQUNBLG1DQUFBO0VBQ0EsNENBQUE7RUFDQSw0Q0FBQTtFQUNBLDRDQUFBO0VBQ0Esd0NBQUE7RUFDQSxtREFBQTtFQUNBLDBDQUFBO0VBQ0EscURBQUE7RUFDQSxvQ0FBQTtFQUNBLHlDQUFBO0VBQ0Esb0NBQUE7RUFDQSxvQ0FBQTtFQUNBLG1DQUFBO0VBQ0EsOENBQUE7RUFFQSwyQkFBQTtFQUNBLG9DQUFBO0FDQUQ7O0FEZ0NBO0VBQ0MsK0NBQUE7RUFDQSxtREFBQTtFQUNBLG1EQUFBO0VBQ0EsdURBQUE7RUFDQSxnREFBQTtFQUNBLCtDQUFBO0FDN0JEOztBQW5DQTtFQUNJLG1ERHVDNEI7QUNEaEM7O0FBbkNBO0VBQ0ksbUNEdUJpQjtBQ2VyQjs7QUFuQ0E7RUFDSSx5Q0RxQmtCO0VDcEJsQiwwQ0FBQTtFQUNBLGtCQUFBO0VBQ0EsYUFBQTtBQXNDSjs7QUFwQ0k7RUFDSSxtQ0RhYTtBQ3lCckI7O0FBbkNJO0VBQ0ksbUNEY2E7RUNiYixvQkFBQTtBQXFDUjs7QUFsQ0k7RUFDSSxvQ0RLYztFQ0pkLFlBQUE7QUFvQ1I7O0FBakNJO0VBQ0ksV0FBQTtFQUNBLFlBQUE7RUFDQSx5RERDd0I7RUNBeEIsa0JBQUE7RUFDQSx1QkFBQTtFQUNBLGFBQUE7RUFDQSxtQkFBQTtBQW1DUjs7QUFsQ1E7RUFDSSxvQ0RQVTtBQzJDdEI7O0FBL0JBO0VBQ0ksaUJBQUE7RUFDQSxvQkFBQTtBQWtDSjs7QUFoQ0k7RUFDSSxtQ0RuQmE7QUNxRHJCOztBQTlCQTtFQUNJLHlDRHRCa0I7RUN1QmxCLDBDQUFBO0VBQ0Esa0JBQUE7RUFDQSxhQUFBO0VBQ0EscUJBQUE7QUFpQ0o7O0FBL0JJO0VBQ0ksbUNEL0JhO0VDZ0NiLHVCQUFBO0FBaUNSOztBQTlCSTtFQUNJLG9DRG5DYztFQ29DZCxzQkFBQTtBQWdDUjs7QUE5QlE7RUFDSSxXQUFBO0VBQ0EsWUFBQTtFQUNBLG1CQUFBO0VBQ0Esb0JBQUE7QUFnQ1o7O0FBM0JBO0VBQ0ksZUFBQTtBQThCSjs7QUE1Qkk7RUFFSSxZQUFBO0FBNkJSIiwiZmlsZSI6Im15LWRvY3VtZW50cy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyI6cm9vdCB7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS01MDogI2YxZWZlZjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4td2hpdGU6ICNmZmZmZmY7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWJsdWU6ICMwZDE1MmU7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuOiAjMDA5MDhkO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ibGFjazogIzAwMDAwMDtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tZ3JleS1iYWNrZ3JvdW5kOiAjYzhkM2RhO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ncmV5OiAjOTJhMmFjO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zdG9uZS1ncmV5OiAjZmFmYWZhO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1lcnJvcjogI2ZjMTA1NTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5OiAjNDE0MTQxO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1maWJyYW50LWdyZWVuOiAjMDBiYWI2O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi13YXJuaW5nOiAjZmZkMDQ4O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbi1iYWNrZ3JvdW5kOiAjZTZmMmYyO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNDAwOiAjN2E3YTdhO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktMTAwOiAjZWZmM2Y1O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtZXJyb3I6ICNiYTBjM2Y7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy1lcnJvci1iYWNrZ3JvdW5kOiAjZmZlZmY0O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtd2FybmluZzogI2NiYTEyNztcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLXdhcm5pbmctYmFja2dyb3VuZDogI2ZmZjhlNjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZS0xMDA6ICNkZmVmZjI7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWVycm9yLXJlZC03MDA6ICNmNjI0NTk7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWJsdWUtNTAwOiAjMDA2MTkyO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlLTQwMDogIzc5Y2RlYztcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tcmVkLTUwMDogI2ZmNjU5MjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc2Vjb25kYXJ5LWJsdWUtMzAwOiAjMTNhMGQzO1xyXG5cclxuXHQtLWx1bWktd2hpdGUtY29sb3I6ICNmZmZmZmY7XHJcblx0LS1sdW1pLXByaW1hcnkteWVsbG93LWNvbG9yOiAjZmFiNjAwO1xyXG59XHJcbiRjb2xvci1uZXh0Z2VuLWJsdWU6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZSk7XHJcbiRjb2xvci1uZXh0Z2VuLWdyZWVuOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuKTtcclxuJGNvbG9yLW5leHRnZW4td2hpdGU6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4td2hpdGUpO1xyXG4kY29sb3ItbmV4dGdlbi1ibGFjazogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ibGFjayk7XHJcbiRjb2xvci1uZXh0Z2VuLWdyZXktYmFja2dyb3VuZDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmV5LWJhY2tncm91bmQpO1xyXG4kY29sb3ItbmV4dGdlbi1ncmV5OiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZXkpO1xyXG4kY29sb3ItbmV4dGdlbi1zdG9uZS1ncmV5OiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXN0b25lLWdyZXkpO1xyXG4kY29sb3ItbmV4dGdlbi1lcnJvcjogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1lcnJvcik7XHJcbiRjb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleTogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXkpO1xyXG4kY29sb3ItbmV4dGdlbi1maWJyYW50LWdyZWVuOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWZpYnJhbnQtZ3JlZW4pO1xyXG4kY29sb3ItbmV4dGdlbi13YXJuaW5nOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXdhcm5pbmcpO1xyXG4kY29sb3ItbmV4dGdlbi1ncmVlbi1iYWNrZ3JvdW5kOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuLWJhY2tncm91bmQpO1xyXG4kY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNTA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTUwKTtcclxuJGNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTQwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNDAwKTtcclxuJGNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTEwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktMTAwKTtcclxuJGNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy1lcnJvcik7XHJcbiRjb2xvci1uZXh0Z2VuLXN0YXR1cy1lcnJvci1iYWNrZ3JvdW5kOiB2YXIoXHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy1lcnJvci1iYWNrZ3JvdW5kXHJcbik7XHJcbiRjb2xvci1uZXh0Z2VuLXN0YXR1cy13YXJuaW5nOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy13YXJuaW5nKTtcclxuJGNvbG9yLW5leHRnZW4tc3RhdHVzLXdhcm5pbmctYmFja2dyb3VuZDogdmFyKFxyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtd2FybmluZy1iYWNrZ3JvdW5kXHJcbik7XHJcbiRjb2xvci1uZXh0Z2VuLWJsdWUtMTAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWJsdWUtMTAwKTtcclxuJGNvbG9yLW5leHRnZW4tZXJyb3ItcmVkLTcwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1lcnJvci1yZWQtNzAwKTtcclxuJGNvbG9yLW5leHRnZW4tYmx1ZS01MDA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZS01MDApO1xyXG4kY29sb3ItbmV4dGdlbi1ibHVlLTQwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlLTQwMCk7XHJcbiRjb2xvci1uZXh0Z2VuLXJlZC01MDA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tcmVkLTUwMCk7XHJcbiRjb2xvci1uZXh0Z2VuLXNlY29uZGFyeS1ibHVlLTMwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1zZWNvbmRhcnktYmx1ZS0zMDApO1xyXG5cclxuLmlvbi1jb2xvci1ncmVlbiB7XHJcblx0LS1pb24tY29sb3ItYmFzZTogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbik7XHJcblx0LS1pb24tY29sb3ItYmFzZS1yZ2I6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4pO1xyXG5cdC0taW9uLWNvbG9yLWNvbnRyYXN0OiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXdoaXRlKTtcclxuXHQtLWlvbi1jb2xvci1jb250cmFzdC1yZ2I6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4pO1xyXG5cdC0taW9uLWNvbG9yLXNoYWRlOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuKTtcclxuXHQtLWlvbi1jb2xvci10aW50OiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuKTtcclxufVxyXG4iLCJAaW1wb3J0IFwiLi4vLi4vLi4vY29sb3Iuc2Nzc1wiO1xyXG5cclxuLmFkZC1iYW5rLWNvbnRhaW5lciB7XHJcbiAgICBiYWNrZ3JvdW5kOiAkY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNTA7XHJcbn1cclxuXHJcbi50aXRsZS10ZXh0IHtcclxuICAgIGNvbG9yOiAkY29sb3ItbmV4dGdlbi1ibHVlO1xyXG59XHJcblxyXG4uY2FyZC1tZW1iZXIge1xyXG4gICAgYmFja2dyb3VuZDogJGNvbG9yLW5leHRnZW4td2hpdGU7XHJcbiAgICBib3gtc2hhZG93OiAwcHggMXB4IDJweCByZ2JhKDAsIDAsIDAsIDAuMSk7XHJcbiAgICBib3JkZXItcmFkaXVzOiA4cHg7XHJcbiAgICBwYWRkaW5nOiAxcmVtO1xyXG5cclxuICAgIC5uYW1lLW1lbWJlciB7XHJcbiAgICAgICAgY29sb3I6ICRjb2xvci1uZXh0Z2VuLWJsdWU7XHJcbiAgICB9XHJcblxyXG4gICAgLmFnZS1zZXgge1xyXG4gICAgICAgIGNvbG9yOiAkY29sb3ItbmV4dGdlbi1ncmV5O1xyXG4gICAgICAgIHBhZGRpbmctdG9wOiAwLjI1cmVtO1xyXG4gICAgfVxyXG5cclxuICAgIC5jaGFuZ2Uge1xyXG4gICAgICAgIGNvbG9yOiAkY29sb3ItbmV4dGdlbi1ncmVlbjtcclxuICAgICAgICBmbG9hdDogcmlnaHQ7XHJcbiAgICB9XHJcblxyXG4gICAgLmltZy1tZW1iZXIge1xyXG4gICAgICAgIHdpZHRoOiAzcmVtO1xyXG4gICAgICAgIGhlaWdodDogM3JlbTtcclxuICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiAkY29sb3ItbmV4dGdlbi1ncmV5LWJhY2tncm91bmQ7XHJcbiAgICAgICAgYm9yZGVyLXJhZGl1czogNTAlO1xyXG4gICAgICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgICAgICBzcGFuIHtcclxuICAgICAgICAgICAgY29sb3I6ICRjb2xvci1uZXh0Z2VuLXdoaXRlIDtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbn1cclxuXHJcbi5kb2N1bWVudC10eXBlIHtcclxuICAgIHBhZGRpbmctdG9wOiAxcmVtO1xyXG4gICAgcGFkZGluZy1ib3R0b206IDFyZW07XHJcblxyXG4gICAgLnRleHQtZG9jdW1lbnQtdHlwZSB7XHJcbiAgICAgICAgY29sb3I6ICRjb2xvci1uZXh0Z2VuLWJsdWU7XHJcbiAgICB9XHJcbn1cclxuXHJcbi5jYXJkLWRvY3VtZW50IHtcclxuICAgIGJhY2tncm91bmQ6ICRjb2xvci1uZXh0Z2VuLXdoaXRlO1xyXG4gICAgYm94LXNoYWRvdzogMHB4IDFweCAycHggcmdiYSgwLCAwLCAwLCAwLjEpO1xyXG4gICAgYm9yZGVyLXJhZGl1czogOHB4O1xyXG4gICAgcGFkZGluZzogMXJlbTtcclxuICAgIG1hcmdpbi1ib3R0b206IDAuNXJlbTtcclxuXHJcbiAgICAudGl0bGUtZG9jdW1lbnQge1xyXG4gICAgICAgIGNvbG9yOiAkY29sb3ItbmV4dGdlbi1ibHVlO1xyXG4gICAgICAgIHBhZGRpbmctYm90dG9tOiAwLjI1cmVtO1xyXG4gICAgfVxyXG5cclxuICAgIC5kb2N1bWVudCB7XHJcbiAgICAgICAgY29sb3I6ICRjb2xvci1uZXh0Z2VuLWdyZWVuO1xyXG4gICAgICAgIHBhZGRpbmctcmlnaHQ6IDAuMjVyZW07XHJcblxyXG4gICAgICAgIC5pY29uLWNoZWNrIHtcclxuICAgICAgICAgICAgd2lkdGg6IDFyZW07XHJcbiAgICAgICAgICAgIGhlaWdodDogMXJlbTtcclxuICAgICAgICAgICAgbWFyZ2luLWxlZnQ6IDAuNXJlbTtcclxuICAgICAgICAgICAgbWFyZ2luLXJpZ2h0OiAwLjVyZW07XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59XHJcblxyXG4uaWNvbi1yaWdodCB7XHJcbiAgICB0ZXh0LWFsaWduOiBlbmQ7XHJcblxyXG4gICAgLmljb24ge1xyXG4gICAgICAgIC8vIGZvbnQtc2l6ZTogMS41cmVtICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgaGVpZ2h0OiAxOXB4O1xyXG4gICAgfVxyXG59Il19 */";

/***/ }),

/***/ 15764:
/*!**************************************************************************!*\
  !*** ./src/app/pages/my-documents/other/other.component.scss?ngResource ***!
  \**************************************************************************/
/***/ ((module) => {

module.exports = ":root {\n  --nc-color-nextgen-neutral-grey-50: #f1efef;\n  --nc-color-nextgen-white: #ffffff;\n  --nc-color-nextgen-blue: #0d152e;\n  --nc-color-nextgen-green: #00908d;\n  --nc-color-nextgen-black: #000000;\n  --nc-color-nextgen-grey-background: #c8d3da;\n  --nc-color-nextgen-grey: #92a2ac;\n  --nc-color-nextgen-stone-grey: #fafafa;\n  --nc-color-nextgen-error: #fc1055;\n  --nc-color-nextgen-neutral-grey: #414141;\n  --nc-color-nextgen-fibrant-green: #00bab6;\n  --nc-color-nextgen-warning: #ffd048;\n  --nc-color-nextgen-green-background: #e6f2f2;\n  --nc-color-nextgen-neutral-grey-400: #7a7a7a;\n  --nc-color-nextgen-neutral-grey-100: #eff3f5;\n  --nc-color-nextgen-status-error: #ba0c3f;\n  --nc-color-nextgen-status-error-background: #ffeff4;\n  --nc-color-nextgen-status-warning: #cba127;\n  --nc-color-nextgen-status-warning-background: #fff8e6;\n  --nc-color-nextgen-blue-100: #dfeff2;\n  --nc-color-nextgen-error-red-700: #f62459;\n  --nc-color-nextgen-blue-500: #006192;\n  --nc-color-nextgen-blue-400: #79cdec;\n  --nc-color-nextgen-red-500: #ff6592;\n  --nc-color-nextgen-secondary-blue-300: #13a0d3;\n  --lumi-white-color: #ffffff;\n  --lumi-primary-yellow-color: #fab600;\n}\n\n.ion-color-green {\n  --ion-color-base: var(--nc-color-nextgen-green);\n  --ion-color-base-rgb: var(--nc-color-nextgen-green);\n  --ion-color-contrast: var(--nc-color-nextgen-white);\n  --ion-color-contrast-rgb: var(--nc-color-nextgen-green);\n  --ion-color-shade: var(--nc-color-nextgen-green);\n  --ion-color-tint: var(--nc-color-nextgen-green);\n}\n\n.add-bank-container {\n  background: var(--nc-color-nextgen-neutral-grey-50);\n}\n\n.title-text {\n  color: var(--nc-color-nextgen-blue);\n  max-width: 230px;\n  white-space: nowrap;\n  overflow: hidden;\n  text-overflow: ellipsis;\n}\n\n.document-type {\n  padding-top: 1rem;\n  padding-bottom: 1rem;\n}\n\n.document-type .text-document-type {\n  color: var(--nc-color-nextgen-blue);\n}\n\n.details {\n  padding-top: 2rem;\n  padding-bottom: 1rem;\n}\n\n.content-upload {\n  padding: 0.5rem;\n  background: var(--nc-color-nextgen-blue-100);\n  border: 1px solid var(--nc-color-nextgen-blue-400);\n  border-radius: 8px;\n  margin-top: 1rem;\n}\n\n.content-upload .content {\n  color: var(--nc-color-nextgen-neutral-grey);\n  text-align: justify;\n}\n\n.content-upload .icon-info {\n  color: var(--nc-color-nextgen-blue-500);\n}\n\n.errorMessage {\n  background: var(--nc-color-nextgen-status-error-background);\n  border: 1px solid var(--nc-color-nextgen-red-500);\n  border-radius: 8px;\n  padding: 0.5rem;\n  margin-bottom: 1rem;\n}\n\n.errorMessage .info-error {\n  color: var(--nc-color-nextgen-status-error);\n}\n\n.field {\n  padding-bottom: 1rem;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFxjb2xvci5zY3NzIiwib3RoZXIuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDQywyQ0FBQTtFQUNBLGlDQUFBO0VBQ0EsZ0NBQUE7RUFDQSxpQ0FBQTtFQUNBLGlDQUFBO0VBQ0EsMkNBQUE7RUFDQSxnQ0FBQTtFQUNBLHNDQUFBO0VBQ0EsaUNBQUE7RUFDQSx3Q0FBQTtFQUNBLHlDQUFBO0VBQ0EsbUNBQUE7RUFDQSw0Q0FBQTtFQUNBLDRDQUFBO0VBQ0EsNENBQUE7RUFDQSx3Q0FBQTtFQUNBLG1EQUFBO0VBQ0EsMENBQUE7RUFDQSxxREFBQTtFQUNBLG9DQUFBO0VBQ0EseUNBQUE7RUFDQSxvQ0FBQTtFQUNBLG9DQUFBO0VBQ0EsbUNBQUE7RUFDQSw4Q0FBQTtFQUVBLDJCQUFBO0VBQ0Esb0NBQUE7QUNBRDs7QURnQ0E7RUFDQywrQ0FBQTtFQUNBLG1EQUFBO0VBQ0EsbURBQUE7RUFDQSx1REFBQTtFQUNBLGdEQUFBO0VBQ0EsK0NBQUE7QUM3QkQ7O0FBbkNBO0VBQ0ksbUREdUM0QjtBQ0RoQzs7QUFuQ0E7RUFDSSxtQ0R1QmlCO0VDdEJqQixnQkFBQTtFQUNBLG1CQUFBO0VBQ0EsZ0JBQUE7RUFDQSx1QkFBQTtBQXNDSjs7QUFuQ0E7RUFDSSxpQkFBQTtFQUNBLG9CQUFBO0FBc0NKOztBQXBDSTtFQUNJLG1DRFdhO0FDMkJyQjs7QUFsQ0E7RUFDSSxpQkFBQTtFQUNBLG9CQUFBO0FBcUNKOztBQTlCQTtFQUNJLGVBQUE7RUFDQSw0Q0RtQnFCO0VDbEJyQixrREFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7QUFpQ0o7O0FBL0JJO0VBQ0ksMkNERnFCO0VDR3JCLG1CQUFBO0FBaUNSOztBQTlCSTtFQUNJLHVDRFVpQjtBQ3NCekI7O0FBMUJBO0VBQ0ksMkRETm9DO0VDT3BDLGlEQUFBO0VBQ0Esa0JBQUE7RUFDQSxlQUFBO0VBQ0EsbUJBQUE7QUE2Qko7O0FBM0JJO0VBQ0ksMkNEZHFCO0FDMkM3Qjs7QUExQkE7RUFDSSxvQkFBQTtBQTZCSiIsImZpbGUiOiJvdGhlci5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIjpyb290IHtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTUwOiAjZjFlZmVmO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi13aGl0ZTogI2ZmZmZmZjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZTogIzBkMTUyZTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW46ICMwMDkwOGQ7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWJsYWNrOiAjMDAwMDAwO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ncmV5LWJhY2tncm91bmQ6ICNjOGQzZGE7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWdyZXk6ICM5MmEyYWM7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0b25lLWdyZXk6ICNmYWZhZmE7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWVycm9yOiAjZmMxMDU1O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXk6ICM0MTQxNDE7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWZpYnJhbnQtZ3JlZW46ICMwMGJhYjY7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXdhcm5pbmc6ICNmZmQwNDg7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuLWJhY2tncm91bmQ6ICNlNmYyZjI7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS00MDA6ICM3YTdhN2E7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS0xMDA6ICNlZmYzZjU7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy1lcnJvcjogI2JhMGMzZjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yLWJhY2tncm91bmQ6ICNmZmVmZjQ7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy13YXJuaW5nOiAjY2JhMTI3O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtd2FybmluZy1iYWNrZ3JvdW5kOiAjZmZmOGU2O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlLTEwMDogI2RmZWZmMjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tZXJyb3ItcmVkLTcwMDogI2Y2MjQ1OTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZS01MDA6ICMwMDYxOTI7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWJsdWUtNDAwOiAjNzljZGVjO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1yZWQtNTAwOiAjZmY2NTkyO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zZWNvbmRhcnktYmx1ZS0zMDA6ICMxM2EwZDM7XHJcblxyXG5cdC0tbHVtaS13aGl0ZS1jb2xvcjogI2ZmZmZmZjtcclxuXHQtLWx1bWktcHJpbWFyeS15ZWxsb3ctY29sb3I6ICNmYWI2MDA7XHJcbn1cclxuJGNvbG9yLW5leHRnZW4tYmx1ZTogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlKTtcclxuJGNvbG9yLW5leHRnZW4tZ3JlZW46IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4pO1xyXG4kY29sb3ItbmV4dGdlbi13aGl0ZTogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi13aGl0ZSk7XHJcbiRjb2xvci1uZXh0Z2VuLWJsYWNrOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWJsYWNrKTtcclxuJGNvbG9yLW5leHRnZW4tZ3JleS1iYWNrZ3JvdW5kOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZXktYmFja2dyb3VuZCk7XHJcbiRjb2xvci1uZXh0Z2VuLWdyZXk6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JleSk7XHJcbiRjb2xvci1uZXh0Z2VuLXN0b25lLWdyZXk6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tc3RvbmUtZ3JleSk7XHJcbiRjb2xvci1uZXh0Z2VuLWVycm9yOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWVycm9yKTtcclxuJGNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5OiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleSk7XHJcbiRjb2xvci1uZXh0Z2VuLWZpYnJhbnQtZ3JlZW46IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZmlicmFudC1ncmVlbik7XHJcbiRjb2xvci1uZXh0Z2VuLXdhcm5pbmc6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4td2FybmluZyk7XHJcbiRjb2xvci1uZXh0Z2VuLWdyZWVuLWJhY2tncm91bmQ6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4tYmFja2dyb3VuZCk7XHJcbiRjb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS01MDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNTApO1xyXG4kY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNDAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS00MDApO1xyXG4kY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktMTAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS0xMDApO1xyXG4kY29sb3ItbmV4dGdlbi1zdGF0dXMtZXJyb3I6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yKTtcclxuJGNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yLWJhY2tncm91bmQ6IHZhcihcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yLWJhY2tncm91bmRcclxuKTtcclxuJGNvbG9yLW5leHRnZW4tc3RhdHVzLXdhcm5pbmc6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLXdhcm5pbmcpO1xyXG4kY29sb3ItbmV4dGdlbi1zdGF0dXMtd2FybmluZy1iYWNrZ3JvdW5kOiB2YXIoXHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy13YXJuaW5nLWJhY2tncm91bmRcclxuKTtcclxuJGNvbG9yLW5leHRnZW4tYmx1ZS0xMDA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZS0xMDApO1xyXG4kY29sb3ItbmV4dGdlbi1lcnJvci1yZWQtNzAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWVycm9yLXJlZC03MDApO1xyXG4kY29sb3ItbmV4dGdlbi1ibHVlLTUwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlLTUwMCk7XHJcbiRjb2xvci1uZXh0Z2VuLWJsdWUtNDAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWJsdWUtNDAwKTtcclxuJGNvbG9yLW5leHRnZW4tcmVkLTUwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1yZWQtNTAwKTtcclxuJGNvbG9yLW5leHRnZW4tc2Vjb25kYXJ5LWJsdWUtMzAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXNlY29uZGFyeS1ibHVlLTMwMCk7XHJcblxyXG4uaW9uLWNvbG9yLWdyZWVuIHtcclxuXHQtLWlvbi1jb2xvci1iYXNlOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuKTtcclxuXHQtLWlvbi1jb2xvci1iYXNlLXJnYjogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbik7XHJcblx0LS1pb24tY29sb3ItY29udHJhc3Q6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4td2hpdGUpO1xyXG5cdC0taW9uLWNvbG9yLWNvbnRyYXN0LXJnYjogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbik7XHJcblx0LS1pb24tY29sb3Itc2hhZGU6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4pO1xyXG5cdC0taW9uLWNvbG9yLXRpbnQ6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4pO1xyXG59XHJcbiIsIkBpbXBvcnQgXCIuLi8uLi8uLi8uLi9jb2xvci5zY3NzXCI7XHJcblxyXG4uYWRkLWJhbmstY29udGFpbmVyIHtcclxuICAgIGJhY2tncm91bmQ6ICRjb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS01MDtcclxufVxyXG5cclxuLnRpdGxlLXRleHQge1xyXG4gICAgY29sb3I6ICRjb2xvci1uZXh0Z2VuLWJsdWU7XHJcbiAgICBtYXgtd2lkdGg6IDIzMHB4O1xyXG4gICAgd2hpdGUtc3BhY2U6IG5vd3JhcDtcclxuICAgIG92ZXJmbG93OiBoaWRkZW47XHJcbiAgICB0ZXh0LW92ZXJmbG93OiBlbGxpcHNpcztcclxufVxyXG5cclxuLmRvY3VtZW50LXR5cGUge1xyXG4gICAgcGFkZGluZy10b3A6IDFyZW07XHJcbiAgICBwYWRkaW5nLWJvdHRvbTogMXJlbTtcclxuXHJcbiAgICAudGV4dC1kb2N1bWVudC10eXBlIHtcclxuICAgICAgICBjb2xvcjogJGNvbG9yLW5leHRnZW4tYmx1ZTtcclxuICAgIH1cclxufVxyXG5cclxuLmRldGFpbHMge1xyXG4gICAgcGFkZGluZy10b3A6IDJyZW07XHJcbiAgICBwYWRkaW5nLWJvdHRvbTogMXJlbTtcclxufVxyXG5cclxuXHJcblxyXG5cclxuXHJcbi5jb250ZW50LXVwbG9hZCB7XHJcbiAgICBwYWRkaW5nOiAwLjVyZW07XHJcbiAgICBiYWNrZ3JvdW5kOiAkY29sb3ItbmV4dGdlbi1ibHVlLTEwMDtcclxuICAgIGJvcmRlcjogMXB4IHNvbGlkICRjb2xvci1uZXh0Z2VuLWJsdWUtNDAwO1xyXG4gICAgYm9yZGVyLXJhZGl1czogOHB4O1xyXG4gICAgbWFyZ2luLXRvcDogMXJlbTtcclxuXHJcbiAgICAuY29udGVudCB7XHJcbiAgICAgICAgY29sb3I6ICRjb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleTtcclxuICAgICAgICB0ZXh0LWFsaWduOiBqdXN0aWZ5O1xyXG4gICAgfVxyXG5cclxuICAgIC5pY29uLWluZm8ge1xyXG4gICAgICAgIGNvbG9yOiAkY29sb3ItbmV4dGdlbi1ibHVlLTUwMDtcclxuICAgIH1cclxufVxyXG5cclxuXHJcblxyXG4uZXJyb3JNZXNzYWdlIHtcclxuICAgIGJhY2tncm91bmQ6ICRjb2xvci1uZXh0Z2VuLXN0YXR1cy1lcnJvci1iYWNrZ3JvdW5kO1xyXG4gICAgYm9yZGVyOiAxcHggc29saWQgJGNvbG9yLW5leHRnZW4tcmVkLTUwMDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDhweDtcclxuICAgIHBhZGRpbmc6IDAuNXJlbTtcclxuICAgIG1hcmdpbi1ib3R0b206IDFyZW07XHJcblxyXG4gICAgLmluZm8tZXJyb3Ige1xyXG4gICAgICAgIGNvbG9yOiAkY29sb3ItbmV4dGdlbi1zdGF0dXMtZXJyb3I7XHJcbiAgICB9XHJcbn1cclxuLmZpZWxke1xyXG4gICAgcGFkZGluZy1ib3R0b206IDFyZW07XHJcbn0iXX0= */";

/***/ }),

/***/ 50179:
/*!********************************************************************************!*\
  !*** ./src/app/pages/my-documents/passport/passport.component.scss?ngResource ***!
  \********************************************************************************/
/***/ ((module) => {

module.exports = ":root {\n  --nc-color-nextgen-neutral-grey-50: #f1efef;\n  --nc-color-nextgen-white: #ffffff;\n  --nc-color-nextgen-blue: #0d152e;\n  --nc-color-nextgen-green: #00908d;\n  --nc-color-nextgen-black: #000000;\n  --nc-color-nextgen-grey-background: #c8d3da;\n  --nc-color-nextgen-grey: #92a2ac;\n  --nc-color-nextgen-stone-grey: #fafafa;\n  --nc-color-nextgen-error: #fc1055;\n  --nc-color-nextgen-neutral-grey: #414141;\n  --nc-color-nextgen-fibrant-green: #00bab6;\n  --nc-color-nextgen-warning: #ffd048;\n  --nc-color-nextgen-green-background: #e6f2f2;\n  --nc-color-nextgen-neutral-grey-400: #7a7a7a;\n  --nc-color-nextgen-neutral-grey-100: #eff3f5;\n  --nc-color-nextgen-status-error: #ba0c3f;\n  --nc-color-nextgen-status-error-background: #ffeff4;\n  --nc-color-nextgen-status-warning: #cba127;\n  --nc-color-nextgen-status-warning-background: #fff8e6;\n  --nc-color-nextgen-blue-100: #dfeff2;\n  --nc-color-nextgen-error-red-700: #f62459;\n  --nc-color-nextgen-blue-500: #006192;\n  --nc-color-nextgen-blue-400: #79cdec;\n  --nc-color-nextgen-red-500: #ff6592;\n  --nc-color-nextgen-secondary-blue-300: #13a0d3;\n  --lumi-white-color: #ffffff;\n  --lumi-primary-yellow-color: #fab600;\n}\n\n.ion-color-green {\n  --ion-color-base: var(--nc-color-nextgen-green);\n  --ion-color-base-rgb: var(--nc-color-nextgen-green);\n  --ion-color-contrast: var(--nc-color-nextgen-white);\n  --ion-color-contrast-rgb: var(--nc-color-nextgen-green);\n  --ion-color-shade: var(--nc-color-nextgen-green);\n  --ion-color-tint: var(--nc-color-nextgen-green);\n}\n\n.add-bank-container {\n  background: var(--nc-color-nextgen-neutral-grey-50);\n}\n\n.title-text {\n  color: var(--nc-color-nextgen-blue);\n  max-width: 230px;\n  white-space: nowrap;\n  overflow: hidden;\n  text-overflow: ellipsis;\n}\n\n.document-type {\n  padding-top: 1rem;\n  padding-bottom: 1rem;\n}\n\n.document-type .text-document-type {\n  color: var(--nc-color-nextgen-blue);\n}\n\n.details {\n  padding-top: 2rem;\n  padding-bottom: 1rem;\n}\n\n.content-upload {\n  padding: 0.5rem;\n  background: var(--nc-color-nextgen-blue-100);\n  border: 1px solid var(--nc-color-nextgen-blue-400);\n  border-radius: 8px;\n  margin-top: 1rem;\n}\n\n.content-upload .content {\n  color: var(--nc-color-nextgen-neutral-grey);\n  text-align: justify;\n}\n\n.content-upload .icon-info {\n  color: var(--nc-color-nextgen-blue-500);\n}\n\n.errorMessage {\n  background: var(--nc-color-nextgen-status-error-background);\n  border: 1px solid var(--nc-color-nextgen-red-500);\n  border-radius: 8px;\n  padding: 0.5rem;\n  margin-bottom: 1rem;\n}\n\n.errorMessage .info-error {\n  color: var(--nc-color-nextgen-status-error);\n}\n\n.field {\n  padding-bottom: 1rem;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFxjb2xvci5zY3NzIiwicGFzc3BvcnQuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDQywyQ0FBQTtFQUNBLGlDQUFBO0VBQ0EsZ0NBQUE7RUFDQSxpQ0FBQTtFQUNBLGlDQUFBO0VBQ0EsMkNBQUE7RUFDQSxnQ0FBQTtFQUNBLHNDQUFBO0VBQ0EsaUNBQUE7RUFDQSx3Q0FBQTtFQUNBLHlDQUFBO0VBQ0EsbUNBQUE7RUFDQSw0Q0FBQTtFQUNBLDRDQUFBO0VBQ0EsNENBQUE7RUFDQSx3Q0FBQTtFQUNBLG1EQUFBO0VBQ0EsMENBQUE7RUFDQSxxREFBQTtFQUNBLG9DQUFBO0VBQ0EseUNBQUE7RUFDQSxvQ0FBQTtFQUNBLG9DQUFBO0VBQ0EsbUNBQUE7RUFDQSw4Q0FBQTtFQUVBLDJCQUFBO0VBQ0Esb0NBQUE7QUNBRDs7QURnQ0E7RUFDQywrQ0FBQTtFQUNBLG1EQUFBO0VBQ0EsbURBQUE7RUFDQSx1REFBQTtFQUNBLGdEQUFBO0VBQ0EsK0NBQUE7QUM3QkQ7O0FBbkNBO0VBQ0ksbUREdUM0QjtBQ0RoQzs7QUFuQ0E7RUFDSSxtQ0R1QmlCO0VDdEJqQixnQkFBQTtFQUNBLG1CQUFBO0VBQ0EsZ0JBQUE7RUFDQSx1QkFBQTtBQXNDSjs7QUFuQ0E7RUFDSSxpQkFBQTtFQUNBLG9CQUFBO0FBc0NKOztBQXBDSTtFQUNJLG1DRFdhO0FDMkJyQjs7QUFsQ0E7RUFDSSxpQkFBQTtFQUNBLG9CQUFBO0FBcUNKOztBQTlCQTtFQUNJLGVBQUE7RUFDQSw0Q0RtQnFCO0VDbEJyQixrREFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7QUFpQ0o7O0FBL0JJO0VBQ0ksMkNERnFCO0VDR3JCLG1CQUFBO0FBaUNSOztBQTlCSTtFQUNJLHVDRFVpQjtBQ3NCekI7O0FBMUJBO0VBQ0ksMkRETm9DO0VDT3BDLGlEQUFBO0VBQ0Esa0JBQUE7RUFDQSxlQUFBO0VBQ0EsbUJBQUE7QUE2Qko7O0FBM0JJO0VBQ0ksMkNEZHFCO0FDMkM3Qjs7QUExQkE7RUFDSSxvQkFBQTtBQTZCSiIsImZpbGUiOiJwYXNzcG9ydC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIjpyb290IHtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTUwOiAjZjFlZmVmO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi13aGl0ZTogI2ZmZmZmZjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZTogIzBkMTUyZTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW46ICMwMDkwOGQ7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWJsYWNrOiAjMDAwMDAwO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ncmV5LWJhY2tncm91bmQ6ICNjOGQzZGE7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWdyZXk6ICM5MmEyYWM7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0b25lLWdyZXk6ICNmYWZhZmE7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWVycm9yOiAjZmMxMDU1O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXk6ICM0MTQxNDE7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWZpYnJhbnQtZ3JlZW46ICMwMGJhYjY7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXdhcm5pbmc6ICNmZmQwNDg7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuLWJhY2tncm91bmQ6ICNlNmYyZjI7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS00MDA6ICM3YTdhN2E7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS0xMDA6ICNlZmYzZjU7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy1lcnJvcjogI2JhMGMzZjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yLWJhY2tncm91bmQ6ICNmZmVmZjQ7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy13YXJuaW5nOiAjY2JhMTI3O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtd2FybmluZy1iYWNrZ3JvdW5kOiAjZmZmOGU2O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlLTEwMDogI2RmZWZmMjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tZXJyb3ItcmVkLTcwMDogI2Y2MjQ1OTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZS01MDA6ICMwMDYxOTI7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWJsdWUtNDAwOiAjNzljZGVjO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1yZWQtNTAwOiAjZmY2NTkyO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zZWNvbmRhcnktYmx1ZS0zMDA6ICMxM2EwZDM7XHJcblxyXG5cdC0tbHVtaS13aGl0ZS1jb2xvcjogI2ZmZmZmZjtcclxuXHQtLWx1bWktcHJpbWFyeS15ZWxsb3ctY29sb3I6ICNmYWI2MDA7XHJcbn1cclxuJGNvbG9yLW5leHRnZW4tYmx1ZTogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlKTtcclxuJGNvbG9yLW5leHRnZW4tZ3JlZW46IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4pO1xyXG4kY29sb3ItbmV4dGdlbi13aGl0ZTogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi13aGl0ZSk7XHJcbiRjb2xvci1uZXh0Z2VuLWJsYWNrOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWJsYWNrKTtcclxuJGNvbG9yLW5leHRnZW4tZ3JleS1iYWNrZ3JvdW5kOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZXktYmFja2dyb3VuZCk7XHJcbiRjb2xvci1uZXh0Z2VuLWdyZXk6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JleSk7XHJcbiRjb2xvci1uZXh0Z2VuLXN0b25lLWdyZXk6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tc3RvbmUtZ3JleSk7XHJcbiRjb2xvci1uZXh0Z2VuLWVycm9yOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWVycm9yKTtcclxuJGNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5OiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleSk7XHJcbiRjb2xvci1uZXh0Z2VuLWZpYnJhbnQtZ3JlZW46IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZmlicmFudC1ncmVlbik7XHJcbiRjb2xvci1uZXh0Z2VuLXdhcm5pbmc6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4td2FybmluZyk7XHJcbiRjb2xvci1uZXh0Z2VuLWdyZWVuLWJhY2tncm91bmQ6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4tYmFja2dyb3VuZCk7XHJcbiRjb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS01MDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNTApO1xyXG4kY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNDAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS00MDApO1xyXG4kY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktMTAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS0xMDApO1xyXG4kY29sb3ItbmV4dGdlbi1zdGF0dXMtZXJyb3I6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yKTtcclxuJGNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yLWJhY2tncm91bmQ6IHZhcihcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yLWJhY2tncm91bmRcclxuKTtcclxuJGNvbG9yLW5leHRnZW4tc3RhdHVzLXdhcm5pbmc6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLXdhcm5pbmcpO1xyXG4kY29sb3ItbmV4dGdlbi1zdGF0dXMtd2FybmluZy1iYWNrZ3JvdW5kOiB2YXIoXHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy13YXJuaW5nLWJhY2tncm91bmRcclxuKTtcclxuJGNvbG9yLW5leHRnZW4tYmx1ZS0xMDA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZS0xMDApO1xyXG4kY29sb3ItbmV4dGdlbi1lcnJvci1yZWQtNzAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWVycm9yLXJlZC03MDApO1xyXG4kY29sb3ItbmV4dGdlbi1ibHVlLTUwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlLTUwMCk7XHJcbiRjb2xvci1uZXh0Z2VuLWJsdWUtNDAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWJsdWUtNDAwKTtcclxuJGNvbG9yLW5leHRnZW4tcmVkLTUwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1yZWQtNTAwKTtcclxuJGNvbG9yLW5leHRnZW4tc2Vjb25kYXJ5LWJsdWUtMzAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXNlY29uZGFyeS1ibHVlLTMwMCk7XHJcblxyXG4uaW9uLWNvbG9yLWdyZWVuIHtcclxuXHQtLWlvbi1jb2xvci1iYXNlOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuKTtcclxuXHQtLWlvbi1jb2xvci1iYXNlLXJnYjogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbik7XHJcblx0LS1pb24tY29sb3ItY29udHJhc3Q6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4td2hpdGUpO1xyXG5cdC0taW9uLWNvbG9yLWNvbnRyYXN0LXJnYjogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbik7XHJcblx0LS1pb24tY29sb3Itc2hhZGU6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4pO1xyXG5cdC0taW9uLWNvbG9yLXRpbnQ6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4pO1xyXG59XHJcbiIsIkBpbXBvcnQgXCIuLi8uLi8uLi8uLi9jb2xvci5zY3NzXCI7XHJcblxyXG4uYWRkLWJhbmstY29udGFpbmVyIHtcclxuICAgIGJhY2tncm91bmQ6ICRjb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS01MDtcclxufVxyXG5cclxuLnRpdGxlLXRleHQge1xyXG4gICAgY29sb3I6ICRjb2xvci1uZXh0Z2VuLWJsdWU7XHJcbiAgICBtYXgtd2lkdGg6IDIzMHB4O1xyXG4gICAgd2hpdGUtc3BhY2U6IG5vd3JhcDtcclxuICAgIG92ZXJmbG93OiBoaWRkZW47XHJcbiAgICB0ZXh0LW92ZXJmbG93OiBlbGxpcHNpcztcclxufVxyXG5cclxuLmRvY3VtZW50LXR5cGUge1xyXG4gICAgcGFkZGluZy10b3A6IDFyZW07XHJcbiAgICBwYWRkaW5nLWJvdHRvbTogMXJlbTtcclxuXHJcbiAgICAudGV4dC1kb2N1bWVudC10eXBlIHtcclxuICAgICAgICBjb2xvcjogJGNvbG9yLW5leHRnZW4tYmx1ZTtcclxuICAgIH1cclxufVxyXG5cclxuLmRldGFpbHMge1xyXG4gICAgcGFkZGluZy10b3A6IDJyZW07XHJcbiAgICBwYWRkaW5nLWJvdHRvbTogMXJlbTtcclxufVxyXG5cclxuXHJcblxyXG5cclxuXHJcbi5jb250ZW50LXVwbG9hZCB7XHJcbiAgICBwYWRkaW5nOiAwLjVyZW07XHJcbiAgICBiYWNrZ3JvdW5kOiAkY29sb3ItbmV4dGdlbi1ibHVlLTEwMDtcclxuICAgIGJvcmRlcjogMXB4IHNvbGlkICRjb2xvci1uZXh0Z2VuLWJsdWUtNDAwO1xyXG4gICAgYm9yZGVyLXJhZGl1czogOHB4O1xyXG4gICAgbWFyZ2luLXRvcDogMXJlbTtcclxuXHJcbiAgICAuY29udGVudCB7XHJcbiAgICAgICAgY29sb3I6ICRjb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleTtcclxuICAgICAgICB0ZXh0LWFsaWduOiBqdXN0aWZ5O1xyXG4gICAgfVxyXG5cclxuICAgIC5pY29uLWluZm8ge1xyXG4gICAgICAgIGNvbG9yOiAkY29sb3ItbmV4dGdlbi1ibHVlLTUwMDtcclxuICAgIH1cclxufVxyXG5cclxuXHJcblxyXG4uZXJyb3JNZXNzYWdlIHtcclxuICAgIGJhY2tncm91bmQ6ICRjb2xvci1uZXh0Z2VuLXN0YXR1cy1lcnJvci1iYWNrZ3JvdW5kO1xyXG4gICAgYm9yZGVyOiAxcHggc29saWQgJGNvbG9yLW5leHRnZW4tcmVkLTUwMDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDhweDtcclxuICAgIHBhZGRpbmc6IDAuNXJlbTtcclxuICAgIG1hcmdpbi1ib3R0b206IDFyZW07XHJcblxyXG4gICAgLmluZm8tZXJyb3Ige1xyXG4gICAgICAgIGNvbG9yOiAkY29sb3ItbmV4dGdlbi1zdGF0dXMtZXJyb3I7XHJcbiAgICB9XHJcbn1cclxuLmZpZWxke1xyXG4gICAgcGFkZGluZy1ib3R0b206IDFyZW07XHJcbn0iXX0= */";

/***/ }),

/***/ 47838:
/*!************************************************************************!*\
  !*** ./src/app/pages/my-documents/visa/visa.component.scss?ngResource ***!
  \************************************************************************/
/***/ ((module) => {

module.exports = ":root {\n  --nc-color-nextgen-neutral-grey-50: #f1efef;\n  --nc-color-nextgen-white: #ffffff;\n  --nc-color-nextgen-blue: #0d152e;\n  --nc-color-nextgen-green: #00908d;\n  --nc-color-nextgen-black: #000000;\n  --nc-color-nextgen-grey-background: #c8d3da;\n  --nc-color-nextgen-grey: #92a2ac;\n  --nc-color-nextgen-stone-grey: #fafafa;\n  --nc-color-nextgen-error: #fc1055;\n  --nc-color-nextgen-neutral-grey: #414141;\n  --nc-color-nextgen-fibrant-green: #00bab6;\n  --nc-color-nextgen-warning: #ffd048;\n  --nc-color-nextgen-green-background: #e6f2f2;\n  --nc-color-nextgen-neutral-grey-400: #7a7a7a;\n  --nc-color-nextgen-neutral-grey-100: #eff3f5;\n  --nc-color-nextgen-status-error: #ba0c3f;\n  --nc-color-nextgen-status-error-background: #ffeff4;\n  --nc-color-nextgen-status-warning: #cba127;\n  --nc-color-nextgen-status-warning-background: #fff8e6;\n  --nc-color-nextgen-blue-100: #dfeff2;\n  --nc-color-nextgen-error-red-700: #f62459;\n  --nc-color-nextgen-blue-500: #006192;\n  --nc-color-nextgen-blue-400: #79cdec;\n  --nc-color-nextgen-red-500: #ff6592;\n  --nc-color-nextgen-secondary-blue-300: #13a0d3;\n  --lumi-white-color: #ffffff;\n  --lumi-primary-yellow-color: #fab600;\n}\n\n.ion-color-green {\n  --ion-color-base: var(--nc-color-nextgen-green);\n  --ion-color-base-rgb: var(--nc-color-nextgen-green);\n  --ion-color-contrast: var(--nc-color-nextgen-white);\n  --ion-color-contrast-rgb: var(--nc-color-nextgen-green);\n  --ion-color-shade: var(--nc-color-nextgen-green);\n  --ion-color-tint: var(--nc-color-nextgen-green);\n}\n\n.add-bank-container {\n  background: var(--nc-color-nextgen-neutral-grey-50);\n}\n\n.title-text {\n  color: var(--nc-color-nextgen-blue);\n  max-width: 230px;\n  white-space: nowrap;\n  overflow: hidden;\n  text-overflow: ellipsis;\n}\n\n.document-type {\n  padding-top: 1rem;\n  padding-bottom: 1rem;\n}\n\n.document-type .text-document-type {\n  color: var(--nc-color-nextgen-blue);\n}\n\n.details {\n  padding-top: 2rem;\n  padding-bottom: 1rem;\n}\n\n.content-upload {\n  padding: 0.5rem;\n  background: var(--nc-color-nextgen-blue-100);\n  border: 1px solid var(--nc-color-nextgen-blue-400);\n  border-radius: 8px;\n  margin-top: 1rem;\n}\n\n.content-upload .content {\n  color: var(--nc-color-nextgen-neutral-grey);\n  text-align: justify;\n}\n\n.content-upload .icon-info {\n  color: var(--nc-color-nextgen-blue-500);\n}\n\n.errorMessage {\n  background: var(--nc-color-nextgen-status-error-background);\n  border: 1px solid var(--nc-color-nextgen-red-500);\n  border-radius: 8px;\n  padding: 0.5rem;\n  margin-bottom: 1rem;\n}\n\n.errorMessage .info-error {\n  color: var(--nc-color-nextgen-status-error);\n}\n\n.field {\n  padding-bottom: 1rem;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFxjb2xvci5zY3NzIiwidmlzYS5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNDLDJDQUFBO0VBQ0EsaUNBQUE7RUFDQSxnQ0FBQTtFQUNBLGlDQUFBO0VBQ0EsaUNBQUE7RUFDQSwyQ0FBQTtFQUNBLGdDQUFBO0VBQ0Esc0NBQUE7RUFDQSxpQ0FBQTtFQUNBLHdDQUFBO0VBQ0EseUNBQUE7RUFDQSxtQ0FBQTtFQUNBLDRDQUFBO0VBQ0EsNENBQUE7RUFDQSw0Q0FBQTtFQUNBLHdDQUFBO0VBQ0EsbURBQUE7RUFDQSwwQ0FBQTtFQUNBLHFEQUFBO0VBQ0Esb0NBQUE7RUFDQSx5Q0FBQTtFQUNBLG9DQUFBO0VBQ0Esb0NBQUE7RUFDQSxtQ0FBQTtFQUNBLDhDQUFBO0VBRUEsMkJBQUE7RUFDQSxvQ0FBQTtBQ0FEOztBRGdDQTtFQUNDLCtDQUFBO0VBQ0EsbURBQUE7RUFDQSxtREFBQTtFQUNBLHVEQUFBO0VBQ0EsZ0RBQUE7RUFDQSwrQ0FBQTtBQzdCRDs7QUFuQ0E7RUFDSSxtRER1QzRCO0FDRGhDOztBQW5DQTtFQUNJLG1DRHVCaUI7RUN0QmpCLGdCQUFBO0VBQ0EsbUJBQUE7RUFDQSxnQkFBQTtFQUNBLHVCQUFBO0FBc0NKOztBQW5DQTtFQUNJLGlCQUFBO0VBQ0Esb0JBQUE7QUFzQ0o7O0FBcENJO0VBQ0ksbUNEV2E7QUMyQnJCOztBQWxDQTtFQUNJLGlCQUFBO0VBQ0Esb0JBQUE7QUFxQ0o7O0FBOUJBO0VBQ0ksZUFBQTtFQUNBLDRDRG1CcUI7RUNsQnJCLGtEQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtBQWlDSjs7QUEvQkk7RUFDSSwyQ0RGcUI7RUNHckIsbUJBQUE7QUFpQ1I7O0FBOUJJO0VBQ0ksdUNEVWlCO0FDc0J6Qjs7QUExQkE7RUFDSSwyREROb0M7RUNPcEMsaURBQUE7RUFDQSxrQkFBQTtFQUNBLGVBQUE7RUFDQSxtQkFBQTtBQTZCSjs7QUEzQkk7RUFDSSwyQ0RkcUI7QUMyQzdCOztBQTFCQTtFQUNJLG9CQUFBO0FBNkJKIiwiZmlsZSI6InZpc2EuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyI6cm9vdCB7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS01MDogI2YxZWZlZjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4td2hpdGU6ICNmZmZmZmY7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWJsdWU6ICMwZDE1MmU7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuOiAjMDA5MDhkO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ibGFjazogIzAwMDAwMDtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tZ3JleS1iYWNrZ3JvdW5kOiAjYzhkM2RhO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ncmV5OiAjOTJhMmFjO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zdG9uZS1ncmV5OiAjZmFmYWZhO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1lcnJvcjogI2ZjMTA1NTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5OiAjNDE0MTQxO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1maWJyYW50LWdyZWVuOiAjMDBiYWI2O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi13YXJuaW5nOiAjZmZkMDQ4O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbi1iYWNrZ3JvdW5kOiAjZTZmMmYyO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNDAwOiAjN2E3YTdhO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktMTAwOiAjZWZmM2Y1O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtZXJyb3I6ICNiYTBjM2Y7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy1lcnJvci1iYWNrZ3JvdW5kOiAjZmZlZmY0O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtd2FybmluZzogI2NiYTEyNztcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLXdhcm5pbmctYmFja2dyb3VuZDogI2ZmZjhlNjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZS0xMDA6ICNkZmVmZjI7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWVycm9yLXJlZC03MDA6ICNmNjI0NTk7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWJsdWUtNTAwOiAjMDA2MTkyO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlLTQwMDogIzc5Y2RlYztcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tcmVkLTUwMDogI2ZmNjU5MjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc2Vjb25kYXJ5LWJsdWUtMzAwOiAjMTNhMGQzO1xyXG5cclxuXHQtLWx1bWktd2hpdGUtY29sb3I6ICNmZmZmZmY7XHJcblx0LS1sdW1pLXByaW1hcnkteWVsbG93LWNvbG9yOiAjZmFiNjAwO1xyXG59XHJcbiRjb2xvci1uZXh0Z2VuLWJsdWU6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZSk7XHJcbiRjb2xvci1uZXh0Z2VuLWdyZWVuOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuKTtcclxuJGNvbG9yLW5leHRnZW4td2hpdGU6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4td2hpdGUpO1xyXG4kY29sb3ItbmV4dGdlbi1ibGFjazogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ibGFjayk7XHJcbiRjb2xvci1uZXh0Z2VuLWdyZXktYmFja2dyb3VuZDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmV5LWJhY2tncm91bmQpO1xyXG4kY29sb3ItbmV4dGdlbi1ncmV5OiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZXkpO1xyXG4kY29sb3ItbmV4dGdlbi1zdG9uZS1ncmV5OiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXN0b25lLWdyZXkpO1xyXG4kY29sb3ItbmV4dGdlbi1lcnJvcjogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1lcnJvcik7XHJcbiRjb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleTogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXkpO1xyXG4kY29sb3ItbmV4dGdlbi1maWJyYW50LWdyZWVuOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWZpYnJhbnQtZ3JlZW4pO1xyXG4kY29sb3ItbmV4dGdlbi13YXJuaW5nOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXdhcm5pbmcpO1xyXG4kY29sb3ItbmV4dGdlbi1ncmVlbi1iYWNrZ3JvdW5kOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuLWJhY2tncm91bmQpO1xyXG4kY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNTA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTUwKTtcclxuJGNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTQwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNDAwKTtcclxuJGNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTEwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktMTAwKTtcclxuJGNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy1lcnJvcik7XHJcbiRjb2xvci1uZXh0Z2VuLXN0YXR1cy1lcnJvci1iYWNrZ3JvdW5kOiB2YXIoXHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy1lcnJvci1iYWNrZ3JvdW5kXHJcbik7XHJcbiRjb2xvci1uZXh0Z2VuLXN0YXR1cy13YXJuaW5nOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy13YXJuaW5nKTtcclxuJGNvbG9yLW5leHRnZW4tc3RhdHVzLXdhcm5pbmctYmFja2dyb3VuZDogdmFyKFxyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtd2FybmluZy1iYWNrZ3JvdW5kXHJcbik7XHJcbiRjb2xvci1uZXh0Z2VuLWJsdWUtMTAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWJsdWUtMTAwKTtcclxuJGNvbG9yLW5leHRnZW4tZXJyb3ItcmVkLTcwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1lcnJvci1yZWQtNzAwKTtcclxuJGNvbG9yLW5leHRnZW4tYmx1ZS01MDA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZS01MDApO1xyXG4kY29sb3ItbmV4dGdlbi1ibHVlLTQwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlLTQwMCk7XHJcbiRjb2xvci1uZXh0Z2VuLXJlZC01MDA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tcmVkLTUwMCk7XHJcbiRjb2xvci1uZXh0Z2VuLXNlY29uZGFyeS1ibHVlLTMwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1zZWNvbmRhcnktYmx1ZS0zMDApO1xyXG5cclxuLmlvbi1jb2xvci1ncmVlbiB7XHJcblx0LS1pb24tY29sb3ItYmFzZTogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbik7XHJcblx0LS1pb24tY29sb3ItYmFzZS1yZ2I6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4pO1xyXG5cdC0taW9uLWNvbG9yLWNvbnRyYXN0OiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXdoaXRlKTtcclxuXHQtLWlvbi1jb2xvci1jb250cmFzdC1yZ2I6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4pO1xyXG5cdC0taW9uLWNvbG9yLXNoYWRlOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuKTtcclxuXHQtLWlvbi1jb2xvci10aW50OiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuKTtcclxufVxyXG4iLCJAaW1wb3J0IFwiLi4vLi4vLi4vLi4vY29sb3Iuc2Nzc1wiO1xyXG5cclxuLmFkZC1iYW5rLWNvbnRhaW5lciB7XHJcbiAgICBiYWNrZ3JvdW5kOiAkY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNTA7XHJcbn1cclxuXHJcbi50aXRsZS10ZXh0IHtcclxuICAgIGNvbG9yOiAkY29sb3ItbmV4dGdlbi1ibHVlO1xyXG4gICAgbWF4LXdpZHRoOiAyMzBweDtcclxuICAgIHdoaXRlLXNwYWNlOiBub3dyYXA7XHJcbiAgICBvdmVyZmxvdzogaGlkZGVuO1xyXG4gICAgdGV4dC1vdmVyZmxvdzogZWxsaXBzaXM7XHJcbn1cclxuXHJcbi5kb2N1bWVudC10eXBlIHtcclxuICAgIHBhZGRpbmctdG9wOiAxcmVtO1xyXG4gICAgcGFkZGluZy1ib3R0b206IDFyZW07XHJcblxyXG4gICAgLnRleHQtZG9jdW1lbnQtdHlwZSB7XHJcbiAgICAgICAgY29sb3I6ICRjb2xvci1uZXh0Z2VuLWJsdWU7XHJcbiAgICB9XHJcbn1cclxuXHJcbi5kZXRhaWxzIHtcclxuICAgIHBhZGRpbmctdG9wOiAycmVtO1xyXG4gICAgcGFkZGluZy1ib3R0b206IDFyZW07XHJcbn1cclxuXHJcblxyXG5cclxuXHJcblxyXG4uY29udGVudC11cGxvYWQge1xyXG4gICAgcGFkZGluZzogMC41cmVtO1xyXG4gICAgYmFja2dyb3VuZDogJGNvbG9yLW5leHRnZW4tYmx1ZS0xMDA7XHJcbiAgICBib3JkZXI6IDFweCBzb2xpZCAkY29sb3ItbmV4dGdlbi1ibHVlLTQwMDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDhweDtcclxuICAgIG1hcmdpbi10b3A6IDFyZW07XHJcblxyXG4gICAgLmNvbnRlbnQge1xyXG4gICAgICAgIGNvbG9yOiAkY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXk7XHJcbiAgICAgICAgdGV4dC1hbGlnbjoganVzdGlmeTtcclxuICAgIH1cclxuXHJcbiAgICAuaWNvbi1pbmZvIHtcclxuICAgICAgICBjb2xvcjogJGNvbG9yLW5leHRnZW4tYmx1ZS01MDA7XHJcbiAgICB9XHJcbn1cclxuXHJcblxyXG5cclxuLmVycm9yTWVzc2FnZSB7XHJcbiAgICBiYWNrZ3JvdW5kOiAkY29sb3ItbmV4dGdlbi1zdGF0dXMtZXJyb3ItYmFja2dyb3VuZDtcclxuICAgIGJvcmRlcjogMXB4IHNvbGlkICRjb2xvci1uZXh0Z2VuLXJlZC01MDA7XHJcbiAgICBib3JkZXItcmFkaXVzOiA4cHg7XHJcbiAgICBwYWRkaW5nOiAwLjVyZW07XHJcbiAgICBtYXJnaW4tYm90dG9tOiAxcmVtO1xyXG5cclxuICAgIC5pbmZvLWVycm9yIHtcclxuICAgICAgICBjb2xvcjogJGNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yO1xyXG4gICAgfVxyXG59XHJcbi5maWVsZHtcclxuICAgIHBhZGRpbmctYm90dG9tOiAxcmVtO1xyXG59Il19 */";

/***/ }),

/***/ 55753:
/*!******************************************************************************************!*\
  !*** ./src/app/pages/my-documents/change-member/change-member.component.html?ngResource ***!
  \******************************************************************************************/
/***/ ((module) => {

module.exports = "  <div class=\"select-member-title h3 bold\"> {{\"myDocument.selectMember\" | translate}}</div>\r\n\r\n  <ion-content>\r\n    <ion-row *ngFor=\"let item of listMemberCard\" class=\"member\" (click)=\"onSelectMember(item)\"\r\n      [ngClass]=\"item.id===memberActive.id?'member-active':''\">\r\n      <ion-col size=\"2\" class=\"ion-align-self-center\">\r\n        <!-- <img [src]=\"item.image==''?'../../../../assets/images/no-image-member.svg':item.image\" class=\"img-member\" /> -->\r\n        <div class=\"img-member\"><span *ngIf=\"item?.name!='MySelf'\" class=\"body-n\">{{item?.image }}</span>\r\n          <span *ngIf=\"item?.name=='MySelf'\" class=\"body-n\">{{'schedule.mySelfDocument' |translate | changeName}}</span>\r\n        </div>\r\n      </ion-col>\r\n      <ion-col size=\"10\" *ngIf=\"item?.name!='MySelf'\" class=\"ion-align-self-center body-n text-member\"\r\n        [ngClass]=\"item.id===memberActive.id?'bold':''\">\r\n        {{item.name}}\r\n      </ion-col>\r\n      <ion-col size=\"10\" *ngIf=\"item?.name=='MySelf'\" class=\"ion-align-self-center body-n text-member\"\r\n        [ngClass]=\"item.id===memberActive.id?'bold':''\">\r\n        {{'schedule.mySelfDocument' |translate}}\r\n      </ion-col>\r\n    </ion-row>\r\n  </ion-content>";

/***/ }),

/***/ 28050:
/*!************************************************************************************************!*\
  !*** ./src/app/pages/my-documents/edit-national-id/edit-national-id.component.html?ngResource ***!
  \************************************************************************************************/
/***/ ((module) => {

module.exports = "<div class=\"add-bank-container\">\r\n  <nextcare-layout>\r\n    <ng-template header>\r\n      <ion-row>\r\n        <ion-col size=\"2\" class=\"d-flex\">\r\n          <button class=\"btn btn-circle\" (click)=\"onBack()\">\r\n            <ion-icon  class=\"icon-back body-l\" name=\"arrow-back-outline\"></ion-icon>\r\n          </button>\r\n        </ion-col>\r\n        <ion-col size=\"8\" class=\"row\">\r\n          <span class=\"title-text h6 bold\">{{nameMember}} {{\"myDocument.nationalID\" | translate}}</span>\r\n        </ion-col>\r\n        <ion-col size=\"2\">\r\n        </ion-col>\r\n      </ion-row>\r\n    </ng-template>\r\n    <ng-template body>\r\n      <ion-grid>\r\n        <ion-row class=\"document-type\">\r\n          <div class=\"h6 bold text-document-type\">{{\"myDocument.nationalID\" | translate}}</div>\r\n        </ion-row>\r\n        <ion-row>\r\n          <ion-col size=\"6\">\r\n            <app-upload-image [textUpload]=\"'myDocument.uploadFront' | translate\" type=\"front\"\r\n              (completeProcess)=\"onClickFont($event)\" [height]=\"'18vh'\" [title]=\"'myDocument.idFront' | translate\"\r\n              [base64]=\"idFont\" titleCamera=\"Front of ID\">\r\n            </app-upload-image>\r\n          </ion-col>\r\n          <ion-col size=\"6\">\r\n            <app-upload-image [textUpload]=\"'myDocument.uploadBack' | translate\" type=\"back\" [height]=\"'18vh'\"\r\n              (completeProcess)=\"onClickBack($event)\" [title]=\"'myDocument.idBack' | translate\" [base64]=\"idBack\"\r\n              titleCamera=\"Back of ID\">\r\n            </app-upload-image>\r\n          </ion-col>\r\n        </ion-row>\r\n        <ion-row class=\"content-upload\">\r\n          <ion-col size=\"1\">\r\n            <div><i class=\"uil uil-info-circle icon-info body-l\"></i></div>\r\n          </ion-col>\r\n          <ion-col size=\"10\">\r\n            <div class=\"body-sm content\">{{\"myDocument.content\" | translate}}</div>\r\n          </ion-col>\r\n          <ion-col size=\"1\">\r\n          </ion-col>\r\n        </ion-row>\r\n        <ion-row class=\"details\">\r\n          <div class=\"h6 bold text-document-type\">{{\"myDocument.idDetails\" | translate}}</div>\r\n        </ion-row>\r\n        <form [formGroup]=\"nationalIDForm\">\r\n          <div class=\"field\">\r\n          <nextgen-control [type]=\"TYPE.INPUT\" [label-property]=\"'myDocument.fullName' | translate\" [disabled]=\"true\"\r\n            formControlName=\"fullName\" [placeholder]=\"'myDocument.nameAsPerID' | translate\">\r\n          </nextgen-control>\r\n        </div>\r\n        <div class=\"field\">\r\n          <nextgen-control [type]=\"TYPE.INPUT\" [label-property]=\"'myDocument.idNumber' | translate\" [disabled]=\"true\"\r\n            formControlName=\"idNumber\" [placeholder]=\"'--- ---- ---- ---- ----- ---- ---- ---- ---- ----'\">\r\n          </nextgen-control></div>\r\n          <div class=\"field\">\r\n          <nextgen-control [type]=\"TYPE.INPUT\" [label-property]=\"'myDocument.nationality'|translate\"\r\n            [placeholder]=\"'myDocument.chooseNationality'|translate\" [disabled]=\"true\" formControlName=\"nationality\"\r\n            [items]=\"countryList\"></nextgen-control>\r\n            </div>\r\n        </form>\r\n        <ion-row class=\"errorMessage\" *ngIf=\"errorMessage!=''\">\r\n          <ion-col size=\"1\">\r\n            <div><i class=\"uil uil-info-circle info-error body-l\"></i></div>\r\n          </ion-col>\r\n          <ion-col size=\"11\" class=\"ion-align-self-center\">\r\n            <div class=\"body-sm info-error\">{{errorMessage | translate}}</div>\r\n          </ion-col>\r\n        </ion-row>\r\n      </ion-grid>\r\n    </ng-template>\r\n    <ng-template bottom>\r\n      <button class=\"btn btn-large primary bold\" [disabled]=\"isDisableUpdate\" (click)=\"onUpdate()\">{{\"myDocument.update\"\r\n        |\r\n        translate}}</button>\r\n    </ng-template>\r\n  </nextcare-layout>\r\n</div>";

/***/ }),

/***/ 94137:
/*!**********************************************************************!*\
  !*** ./src/app/pages/my-documents/my-documents.page.html?ngResource ***!
  \**********************************************************************/
/***/ ((module) => {

module.exports = "<div class=\"add-bank-container\">\r\n  <nextcare-layout>\r\n    <ng-template header>\r\n      <ion-row>\r\n        <ion-col size=\"2\" class=\"d-flex\">\r\n          <button class=\"btn btn-circle\" (click)=\"onBack()\">\r\n            <ion-icon  class=\"icon-back body-l\" name=\"arrow-back-outline\"></ion-icon>\r\n          </button>\r\n        </ion-col>\r\n        <ion-col size=\"8\" class=\"row\">\r\n          <span class=\"title-text h6 bold\">{{\"myDocument.uploadDocuments\" | translate}}</span>\r\n        </ion-col>\r\n        <ion-col size=\"2\">\r\n        </ion-col>\r\n      </ion-row>\r\n    </ng-template>\r\n    <ng-template body>\r\n      <ion-grid>\r\n        <ion-row class=\"card-member\">\r\n          <ion-col class=\"ion-align-self-center\" size=\"3\">\r\n            <!-- <img [src]=\"memberActive?.image==''?'../../../../assets/images/no-image-member.svg':memberActive?.image\"\r\n              class=\"img-member\" /> -->\r\n              <div class=\"img-member\"><span *ngIf=\"memberActive?.name!='MySelf'\" class=\"body-n\">{{memberActive?.image }}</span>\r\n                <span *ngIf=\"memberActive?.name=='MySelf'\" class=\"body-n\">{{'schedule.mySelfDocument' |translate | changeName}}</span>\r\n              </div>\r\n          </ion-col>\r\n          <ion-col class=\"ion-align-self-center\" size=\"6\">\r\n            <div class=\"body-l bold name-member\" *ngIf=\"memberActive?.name!='MySelf'\">{{memberActive?.name}}</div>\r\n            <div class=\"body-l bold name-member\" *ngIf=\"memberActive?.name=='MySelf'\">{{'schedule.mySelfDocument' |translate}}</div>\r\n            <div class=\"body-sm age-sex\">{{memberActive?.age}}, {{memberActive?.sex}}</div>\r\n          </ion-col>\r\n          <ion-col class=\"ion-align-self-center\" size=\"3\">\r\n            <div class=\"body-sm bold change\" (click)=\"onChangeMember()\">{{\"myDocument.change\" | translate}}</div>\r\n          </ion-col>\r\n        </ion-row>\r\n        <ion-row class=\"document-type\">\r\n          <div class=\"h6 bold text-document-type\">{{\"myDocument.documentType\" | translate}}</div>\r\n        </ion-row>\r\n        <div *ngIf=\"!isLoading\">\r\n          <div *ngFor=\"let item of listDefault\">\r\n            <ion-row class=\"card-document\"   *ngIf=\"item?.enable\" >         \r\n              <ion-col class=\"ion-align-self-center\" size=\"10\">\r\n                <div class=\"body-n bold title-document\">{{item?.nameDocument | translate}}</div>\r\n                <div class=\"document\" *ngIf=\"item?.idNumber==null\">\r\n                  <span><i class=\"body-l bold uil uil-plus-circle document\"></i></span>\r\n                  <span class=\"body-sm bold document\">{{\"myDocument.upload\" | translate}}</span>\r\n                </div>\r\n                <div class=\"document\"  *ngIf=\"item?.idNumber!=null\">\r\n                  <span>{{item?.idNumber}}</span>\r\n                  <span>\r\n                    <img class=\"icon-check\" src=\"../../../assets/icon/icon-check.svg\">\r\n                  </span>\r\n                </div>\r\n              </ion-col>\r\n              <ion-col class=\"ion-align-self-center icon-right\" *ngIf=\"item?.idNumber!=null\" size=\"2\">\r\n                <!-- <i class=\"uil uil-arrow-right icon\"></i> -->\r\n                <ion-icon  class=\"uil icon\" name=\"arrow-forward-outline\"></ion-icon>\r\n              </ion-col>\r\n           \r\n            </ion-row>\r\n          </div>\r\n      \r\n      </div>\r\n      <div *ngIf=\"isLoading\">\r\n        <div *ngFor=\"let item of listDocument\">\r\n          <ion-row class=\"card-document\"  *ngIf=\"item?.enable\" (click)=\"onUploadNationalID(item)\">\r\n                 \r\n            <ion-col class=\"ion-align-self-center\" size=\"10\">\r\n              <div class=\"body-n bold title-document\">{{item?.nameDocument | translate}}</div>\r\n              <div class=\"document\" *ngIf=\"item?.idNumber==null\">\r\n                <span><i class=\"body-l bold uil uil-plus-circle document\"></i></span>\r\n                <span class=\"body-sm bold document\">{{\"myDocument.upload\" | translate}}</span>\r\n              </div>\r\n              <div class=\"document\"  *ngIf=\"item?.idNumber!=null\">\r\n                <span>{{item?.idNumber}}</span>\r\n                <span>\r\n                  <img class=\"icon-check\" src=\"../../../assets/icon/icon-check.svg\">\r\n                </span>\r\n              </div>\r\n            </ion-col>\r\n            <ion-col class=\"ion-align-self-center icon-right\" *ngIf=\"item?.idNumber!=null\" size=\"2\">\r\n              <!-- <i class=\"uil uil-arrow-right icon\"></i> -->\r\n              <ion-icon  class=\"uil icon\" name=\"arrow-forward-outline\"></ion-icon>\r\n            </ion-col>\r\n          \r\n          </ion-row>\r\n        </div>\r\n   \r\n      </div>\r\n      </ion-grid>\r\n    </ng-template>\r\n  </nextcare-layout>\r\n</div>";

/***/ }),

/***/ 5350:
/*!**************************************************************************!*\
  !*** ./src/app/pages/my-documents/other/other.component.html?ngResource ***!
  \**************************************************************************/
/***/ ((module) => {

module.exports = "<div class=\"add-bank-container\">\r\n  <nextcare-layout>\r\n    <ng-template header>\r\n      <ion-row>\r\n        <ion-col size=\"2\" class=\"d-flex\">\r\n          <button class=\"btn btn-circle\" (click)=\"onBack()\">\r\n            <ion-icon  class=\"icon-back body-l\" name=\"arrow-back-outline\"></ion-icon>\r\n          </button>\r\n        </ion-col>\r\n        <ion-col size=\"8\" class=\"row\">\r\n          <span class=\"title-text h6 bold\">{{nameMember}} {{'myDocument.other' | translate}}</span>\r\n        </ion-col>\r\n        <ion-col size=\"2\">\r\n        </ion-col>\r\n      </ion-row>\r\n    </ng-template>\r\n    <ng-template body>\r\n      <ion-grid>\r\n        <ion-row class=\"document-type\">\r\n          <div class=\"h6 bold text-document-type\">{{'myDocument.other' | translate}}</div>\r\n        </ion-row>\r\n        <ion-row>\r\n          <ion-col size=\"12\">\r\n            <app-upload-image [textUpload]=\"'myDocument.uploadFront' | translate\" [height]=\"'20vh'\" type=\"front\"\r\n              (completeProcess)=\"onClickFont($event)\" [title]=\"'myDocument.otherImage' | translate\" [base64]=\"idFont\"\r\n              titleCamera=\"Front of ID\">\r\n            </app-upload-image>\r\n          </ion-col>\r\n        </ion-row>\r\n        <ion-row class=\"content-upload\">\r\n          <ion-col size=\"1\">\r\n            <div><i class=\"uil uil-info-circle icon-info body-l\"></i></div>\r\n          </ion-col>\r\n          <ion-col size=\"10\">\r\n            <div class=\"body-sm content\">{{\"myDocument.content\" | translate}}</div>\r\n          </ion-col>\r\n          <ion-col size=\"1\">\r\n          </ion-col>\r\n        </ion-row>\r\n        <ion-row class=\"details\">\r\n          <div class=\"h6 bold text-document-type\">{{'myDocument.otherDetail' | translate}}</div>\r\n        </ion-row>\r\n        <form [formGroup]=\"otherForm\">\r\n          <div class=\"field\">\r\n          <nextgen-control [type]=\"TYPE.INPUT\" [label-property]=\"'myDocument.otherNumber' | translate\"\r\n            formControlName=\"otherNumber\" [placeholder]=\"'--- ---- ---- ---- ----- ---- ---- ---- ---- ----'\">\r\n          </nextgen-control>\r\n        </div>          \r\n        <div class=\"field\">\r\n          <nextgen-control [type]=\"TYPE.DATETIMEDIALOG\" [label-property]=\"'myDocument.issueDate' | translate\"\r\n            (ngModelChange)=\"onChange($event)\" formControlName=\"issueDate\"\r\n            [placeholder]=\"'myDocument.chooseIssueDate'| translate\">\r\n          </nextgen-control>\r\n        </div>\r\n          <div class=\"field\">\r\n          <nextgen-control [type]=\"TYPE.DATETIMEDIALOG\" [label-property]=\"'myDocument.expiryDate'|translate\"\r\n            [minDate]=\"issueDate\" [maxDate]=\"expiryDate\" [second-icon]=\"'uil uil-angle-down'\"\r\n            [placeholder]=\"'myDocument.chooseExpiryDate'|translate\" formControlName=\"expiryDate\"></nextgen-control>\r\n          </div>\r\n        </form>\r\n        <ion-row class=\"errorMessage\" *ngIf=\"errorMessage!=''\">\r\n          <ion-col size=\"1\">\r\n            <div><i class=\"uil uil-info-circle info-error body-l\"></i></div>\r\n          </ion-col>\r\n          <ion-col size=\"11\" class=\"ion-align-self-center\">\r\n            <div class=\"body-sm info-error\">{{errorMessage | translate}}</div>\r\n          </ion-col>\r\n        </ion-row>\r\n      </ion-grid>\r\n    </ng-template>\r\n    <ng-template bottom>\r\n      <button class=\"btn btn-large primary bold\" (click)=\"onUpdate()\">{{\"myDocument.update\" | translate}}</button>\r\n    </ng-template>\r\n  </nextcare-layout>\r\n</div>";

/***/ }),

/***/ 35171:
/*!********************************************************************************!*\
  !*** ./src/app/pages/my-documents/passport/passport.component.html?ngResource ***!
  \********************************************************************************/
/***/ ((module) => {

module.exports = "<div class=\"add-bank-container\">\r\n  <nextcare-layout>\r\n    <ng-template header>\r\n      <ion-row>\r\n        <ion-col size=\"2\" class=\"d-flex\">\r\n          <button class=\"btn btn-circle\" (click)=\"onBack()\">\r\n            <ion-icon  class=\"icon-back body-l\" name=\"arrow-back-outline\"></ion-icon>\r\n          </button>\r\n        </ion-col>\r\n        <ion-col size=\"8\" class=\"row\">\r\n          <span class=\"title-text h6 bold\">{{nameMember}} {{'myDocument.passport' | translate}}</span>\r\n        </ion-col>\r\n        <ion-col size=\"2\">\r\n        </ion-col>\r\n      </ion-row>\r\n    </ng-template>\r\n    <ng-template body>\r\n      <ion-grid>\r\n        <ion-row class=\"document-type\">\r\n          <div class=\"h6 bold text-document-type\">{{'myDocument.passport' | translate}}</div>\r\n        </ion-row>\r\n        <ion-row>\r\n          <ion-col size=\"12\">\r\n            <app-upload-image [textUpload]=\"'myDocument.uploadFront' | translate\" [height]=\"'20vh'\" type=\"front\"\r\n              (completeProcess)=\"onClickFont($event)\" [title]=\"'myDocument.passportImage' | translate\" [base64]=\"idFont\"\r\n              titleCamera=\"Front of ID\">\r\n            </app-upload-image>\r\n          </ion-col>\r\n        </ion-row>\r\n        <ion-row class=\"content-upload\">\r\n          <ion-col size=\"1\">\r\n            <div><i class=\"uil uil-info-circle icon-info body-l\"></i></div>\r\n          </ion-col>\r\n          <ion-col size=\"10\">\r\n            <div class=\"body-sm content\">{{\"myDocument.content\" | translate}}</div>\r\n          </ion-col>\r\n          <ion-col size=\"1\">\r\n          </ion-col>\r\n        </ion-row>\r\n        <ion-row class=\"details\">\r\n          <div class=\"h6 bold text-document-type\">{{'myDocument.passportDetail' | translate}}</div>\r\n        </ion-row>\r\n        <form [formGroup]=\"passportForm\">\r\n          <div class=\"field\">\r\n          <nextgen-control [type]=\"TYPE.INPUT\" [label-property]=\"'myDocument.passportNumber' | translate\"\r\n            formControlName=\"passportNumber\" [placeholder]=\"'--- ---- ---- ---- ----- ---- ---- ---- ---- ----'\">\r\n          </nextgen-control>\r\n        </div>\r\n          <div class=\"field\">\r\n          <nextgen-control [type]=\"TYPE.DATETIMEDIALOG\" [label-property]=\"'myDocument.issueDate' | translate\"\r\n            (ngModelChange)=\"onChange($event)\" formControlName=\"issueDate\"\r\n            [placeholder]=\"'myDocument.chooseIssueDate'| translate\">\r\n          </nextgen-control>\r\n        </div>\r\n          <div class=\"field\">\r\n          <nextgen-control [type]=\"TYPE.DATETIMEDIALOG\" [label-property]=\"'myDocument.expiryDate'|translate\"\r\n            [minDate]=\"issueDate\" [maxDate]=\"expiryDate\" [second-icon]=\"'uil uil-angle-down'\"\r\n            [placeholder]=\"'myDocument.chooseExpiryDate'|translate\" formControlName=\"expiryDate\"></nextgen-control>\r\n          </div>\r\n        </form>\r\n        <ion-row class=\"errorMessage\" *ngIf=\"errorMessage!=''\">\r\n          <ion-col size=\"1\">\r\n            <div><i class=\"uil uil-info-circle info-error body-l\"></i></div>\r\n          </ion-col>\r\n          <ion-col size=\"11\" class=\"ion-align-self-center\">\r\n            <div class=\"body-sm info-error\">{{errorMessage | translate}}</div>\r\n          </ion-col>\r\n        </ion-row>\r\n      </ion-grid>\r\n    </ng-template>\r\n    <ng-template bottom>\r\n      <button class=\"btn btn-large primary bold\" (click)=\"onUpdate()\">{{\"myDocument.update\" | translate}}</button>\r\n    </ng-template>\r\n  </nextcare-layout>\r\n</div>";

/***/ }),

/***/ 12304:
/*!************************************************************************!*\
  !*** ./src/app/pages/my-documents/visa/visa.component.html?ngResource ***!
  \************************************************************************/
/***/ ((module) => {

module.exports = "<div class=\"add-bank-container\">\r\n  <nextcare-layout>\r\n    <ng-template header>\r\n      <ion-row>\r\n        <ion-col size=\"2\" class=\"d-flex\">\r\n          <button class=\"btn btn-circle\" (click)=\"onBack()\">\r\n            <ion-icon  class=\"icon-back body-l\" name=\"arrow-back-outline\"></ion-icon>\r\n          </button>\r\n        </ion-col>\r\n        <ion-col size=\"8\" class=\"row\">\r\n          <span class=\"title-text h6 bold\">{{nameMember}} {{'myDocument.visa' | translate}}</span>\r\n        </ion-col>\r\n        <ion-col size=\"2\">\r\n        </ion-col>\r\n      </ion-row>\r\n    </ng-template>\r\n    <ng-template body>\r\n      <ion-grid>\r\n        <ion-row class=\"document-type\">\r\n          <div class=\"h6 bold text-document-type\">{{'myDocument.visa' | translate}}</div>\r\n        </ion-row>\r\n        <ion-row>\r\n          <ion-col size=\"12\">\r\n            <app-upload-image [textUpload]=\"'myDocument.uploadFront' | translate\" [height]=\"'20vh'\" type=\"front\"\r\n              (completeProcess)=\"onClickFont($event)\" [title]=\"'myDocument.visaImage' | translate\" [base64]=\"idFont\"\r\n              titleCamera=\"Front of ID\">\r\n            </app-upload-image>\r\n          </ion-col>\r\n        </ion-row>\r\n        <ion-row class=\"content-upload\">\r\n          <ion-col size=\"1\">\r\n            <div><i class=\"uil uil-info-circle icon-info body-l\"></i></div>\r\n          </ion-col>\r\n          <ion-col size=\"10\">\r\n            <div class=\"body-sm content\">{{\"myDocument.content\" | translate}}</div>\r\n          </ion-col>\r\n          <ion-col size=\"1\">\r\n          </ion-col>\r\n        </ion-row>\r\n        <ion-row class=\"details\">\r\n          <div class=\"h6 bold text-document-type\">{{'myDocument.visaDetail' | translate}}</div>\r\n        </ion-row>\r\n        <form [formGroup]=\"visaForm\">\r\n          <div class=\"field\">\r\n          <nextgen-control [type]=\"TYPE.INPUT\" [label-property]=\"'myDocument.visaNumber' | translate\"\r\n            formControlName=\"visaNumber\" [placeholder]=\"'--- ---- ---- ---- ----- ---- ---- ---- ---- ----'\">\r\n          </nextgen-control>\r\n        </div>\r\n          <div class=\"field\">\r\n          <nextgen-control [type]=\"TYPE.DATETIMEDIALOG\" [label-property]=\"'myDocument.issueDate' | translate\"\r\n            (ngModelChange)=\"onChange($event)\" formControlName=\"issueDate\"\r\n            [placeholder]=\"'myDocument.chooseIssueDate'| translate\">\r\n          </nextgen-control>\r\n        </div>\r\n          <div class=\"field\">\r\n          <nextgen-control [type]=\"TYPE.DATETIMEDIALOG\" [label-property]=\"'myDocument.expiryDate'|translate\"\r\n            [minDate]=\"issueDate\" [maxDate]=\"expiryDate\" [second-icon]=\"'uil uil-angle-down'\"\r\n            [placeholder]=\"'myDocument.chooseExpiryDate'|translate\" formControlName=\"expiryDate\"></nextgen-control>\r\n          </div>\r\n        </form>\r\n        <ion-row class=\"errorMessage\" *ngIf=\"errorMessage!=''\">\r\n          <ion-col size=\"1\">\r\n            <div><i class=\"uil uil-info-circle info-error body-l\"></i></div>\r\n          </ion-col>\r\n          <ion-col size=\"11\" class=\"ion-align-self-center\">\r\n            <div class=\"body-sm info-error\">{{errorMessage | translate}}</div>\r\n          </ion-col>\r\n        </ion-row>\r\n      </ion-grid>\r\n    </ng-template>\r\n    <ng-template bottom>\r\n      <button class=\"btn btn-large primary bold\" (click)=\"onUpdate()\">{{\"myDocument.update\" | translate}}</button>\r\n    </ng-template>\r\n  </nextcare-layout>\r\n</div>";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_my-documents_my-documents_module_ts.js.map