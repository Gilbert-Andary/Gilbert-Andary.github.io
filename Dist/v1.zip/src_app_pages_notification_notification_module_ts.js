"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_notification_notification_module_ts"],{

/***/ 69154:
/*!*******************************************************************************************!*\
  !*** ./src/app/pages/notification/notification-content/notification-content.component.ts ***!
  \*******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NotificationContentComponent": () => (/* binding */ NotificationContentComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _notification_content_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./notification-content.component.html?ngResource */ 73971);
/* harmony import */ var _notification_content_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./notification-content.component.scss?ngResource */ 64530);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var src_app_service_notification_notification_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/service/notification/notification.service */ 66258);





let NotificationContentComponent = class NotificationContentComponent {
    constructor(notificationService) {
        this.notificationService = notificationService;
    }
    ngOnInit() {
    }
    checkNewNotification(item) {
        item.isNew = false;
        this.notificationService.checkCountNotification(this.notifications);
    }
};
NotificationContentComponent.ctorParameters = () => [
    { type: src_app_service_notification_notification_service__WEBPACK_IMPORTED_MODULE_2__.NotificationService }
];
NotificationContentComponent.propDecorators = {
    notifications: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.Input }]
};
NotificationContentComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-notification-content',
        template: _notification_content_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_notification_content_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], NotificationContentComponent);



/***/ }),

/***/ 54863:
/*!*******************************************************************!*\
  !*** ./src/app/pages/notification/notification-routing.module.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NotificationPageRoutingModule": () => (/* binding */ NotificationPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _notification_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./notification.page */ 95259);




const routes = [
    {
        path: '',
        component: _notification_page__WEBPACK_IMPORTED_MODULE_0__.NotificationPage
    },
];
let NotificationPageRoutingModule = class NotificationPageRoutingModule {
};
NotificationPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
    })
], NotificationPageRoutingModule);



/***/ }),

/***/ 89770:
/*!***********************************************************!*\
  !*** ./src/app/pages/notification/notification.module.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NotificationPageModule": () => (/* binding */ NotificationPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _notification_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./notification.page */ 95259);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/shared/shared.module */ 44466);
/* harmony import */ var _notification_routing_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./notification-routing.module */ 54863);
/* harmony import */ var _notification_content_notification_content_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./notification-content/notification-content.component */ 69154);
/* harmony import */ var src_app_service_notification_notification_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/service/notification/notification.service */ 66258);
/* harmony import */ var src_app_pipe_notification_nice_date_format_pipe__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/pipe/notification/nice-date-format.pipe */ 89347);











let NotificationPageModule = class NotificationPageModule {
};
NotificationPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.NgModule)({
        declarations: [_notification_page__WEBPACK_IMPORTED_MODULE_0__.NotificationPage,
            _notification_content_notification_content_component__WEBPACK_IMPORTED_MODULE_3__.NotificationContentComponent,
            src_app_pipe_notification_nice_date_format_pipe__WEBPACK_IMPORTED_MODULE_5__.NiceDateFormatPipe
        ],
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_8__.CommonModule,
            _notification_routing_module__WEBPACK_IMPORTED_MODULE_2__.NotificationPageRoutingModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_9__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_10__.IonicModule,
            src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_1__.SharedModule,
        ],
        providers: [
            src_app_service_notification_notification_service__WEBPACK_IMPORTED_MODULE_4__.NotificationService
        ]
    })
], NotificationPageModule);



/***/ }),

/***/ 95259:
/*!*********************************************************!*\
  !*** ./src/app/pages/notification/notification.page.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NotificationPage": () => (/* binding */ NotificationPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _notification_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./notification.page.html?ngResource */ 45816);
/* harmony import */ var _notification_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./notification.page.scss?ngResource */ 15116);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var src_app_service_notification_notification_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/service/notification/notification.service */ 66258);
/* harmony import */ var src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/shared/data/enum/event */ 38570);
/* harmony import */ var _awesome_cordova_plugins_firebase_analytics_ngx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @awesome-cordova-plugins/firebase-analytics/ngx */ 48852);
/* harmony import */ var _awesome_cordova_plugins_clevertap_ngx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @awesome-cordova-plugins/clevertap/ngx */ 45363);
/* harmony import */ var src_app_service_insurance_insurance_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/service/insurance/insurance.service */ 57072);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! rxjs/operators */ 85921);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! rxjs */ 92218);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/shared/data/constants */ 74676);
/* harmony import */ var _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @ionic/storage-angular */ 80190);
/* harmony import */ var src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/shared/data/enum/screen */ 68302);

















let NotificationPage = class NotificationPage {
    constructor(notificationService, navCtrl, menu, firebaseAnalytics, clevertap, insuranceService, route, platform, location, router, storage) {
        this.notificationService = notificationService;
        this.navCtrl = navCtrl;
        this.menu = menu;
        this.firebaseAnalytics = firebaseAnalytics;
        this.clevertap = clevertap;
        this.insuranceService = insuranceService;
        this.route = route;
        this.platform = platform;
        this.location = location;
        this.router = router;
        this.storage = storage;
        this.checkList = [];
        this.unsubscribe$ = new rxjs__WEBPACK_IMPORTED_MODULE_9__.Subject();
        this.params = this.route.snapshot.queryParams;
    }
    ngOnInit() {
        this.firebaseAnalytics.logEvent(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_3__.GA4Event.NotificationsViewed, {});
        this.clevertap.recordEventWithName(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_3__.GA4Event.NotificationsViewed);
        this.notificationService.countNotification().subscribe(res => {
            this.countNotifications = res;
        });
        // this.getNotifications();
        this.command = {
            actionName: 'Back',
            action: 'onBack',
            class: '',
        };
        // this.checkList = [
        //   {
        //     name: 'notifications.all',
        //     id: 'All',
        //   },
        //   {
        //     name: 'notifications.claims',
        //     id: 'Claims',
        //   },
        //   {
        //     name: 'notifications.appointments',
        //     id: 'Appointments',
        //   },
        //   {
        //     name: 'notifications.inquiries',
        //     id: 'Inquiries',
        //   },
        //   {
        //     name: 'notifications.medicines',
        //     id: 'Medicines',
        //   },
        //   {
        //     name: 'notifications.reports',
        //     id: 'Reports',
        //   },
        //   {
        //     name: 'notifications.seeADoctorNotifications',
        //     id: 'SeeADoctorNotifications'
        //   },
        // ]
    }
    ionViewWillEnter() {
        this.unsubscribe$ = new rxjs__WEBPACK_IMPORTED_MODULE_9__.Subject();
        this.getInformation();
    }
    ionViewDidEnter() {
        this.subscription = this.platform.backButton.subscribeWithPriority(9999, () => {
            if (this.location.path().includes('homePage')) {
                this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_8__.Screens.Home]);
            }
            else if (this.location.path().includes('side-menu')) {
                this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_8__.Screens.Home]);
                this.menu.open('profile-menu');
            }
        });
    }
    ionViewWillLeave() {
        this.unsubscribe$.next();
        this.unsubscribe$.complete();
        this.subscription.unsubscribe();
    }
    onBack() {
        if (this.params.redirectTo == 'homePage') {
            this.router.navigate([
                '/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_8__.Screens.Home
            ]).then((_) => {
                this.menu.close('profile-menu');
            });
        }
        else if (this.params.redirectTo == 'side-menu') {
            this.router.navigate([
                '/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_8__.Screens.Home
            ]).then((_) => {
                this.menu.open('profile-menu');
            });
        }
    }
    getInformation() {
        this.insuranceService.getPolicyInformation().pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_10__.takeUntil)(this.unsubscribe$)).subscribe((res) => {
            var _a;
            if (!res || ((_a = this.currentPolicy) === null || _a === void 0 ? void 0 : _a.beneficiaryId) === res.beneficiaryId)
                return;
            this.currentPolicy = res;
            this.getNotifications();
        });
    }
    getNotifications() {
        var _a;
        return (0,tslib__WEBPACK_IMPORTED_MODULE_11__.__awaiter)(this, void 0, void 0, function* () {
            const fcmToken = yield this.storage.get(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_7__.Constants.FCM_TOKEN);
            const requestNotifications = [{
                    notificationType: 3,
                    typeValue: fcmToken
                }];
            this.notifications = [];
            this.notificationService.getNotifications((_a = this.currentPolicy) === null || _a === void 0 ? void 0 : _a.userPolicyId, requestNotifications)
                .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_10__.takeUntil)(this.unsubscribe$))
                .subscribe((data) => {
                this.notifications.push({
                    rangeName: 'notifications.OLDER',
                    detailNotification: data.map((item) => ({
                        title: item.title,
                        subtitle: item.body,
                        time: '',
                        icon: 'uil uil-calender',
                        isNew: false,
                        key: 'Appointments'
                    }))
                });
                // data.sort(
                //   (objA, objB) => new Date(objB.statusDate).getTime() - new Date(objA.statusDate).getTime(),
                // )
                // const listToday: DetailNotification[] = [];
                // const listYesterday: DetailNotification[] = [];
                // const listLastWeek: DetailNotification[] = [];
                // const listOlder: DetailNotification[] = [];
                // data.forEach((value) => {
                //   const today = new Date();
                //   const yesterday = new Date(today);
                //   const lastWeek = new Date(today.getFullYear(), today.getMonth(), today.getDate() - 7);
                //   const notification: NotificationParams = JSON.parse(value.notificationParams);
                //   yesterday.setDate(yesterday.getDate() - 1);
                //   if (new Date(value.requestDate).getFullYear() == today.getFullYear() && new Date(value.requestDate).getMonth() == today.getMonth() && new Date(value.requestDate).getDate() == today.getDate())
                //     listToday.push({
                //       title: notification.Title,
                //       subtitle: notification.Body,
                //       time: value.requestDate,
                //       icon: 'uil uil-calender',
                //       isNew: true,
                //       key: 'Appointments',
                //     });
                //   else if (new Date(value.requestDate).getFullYear() == yesterday.getFullYear() && new Date(value.requestDate).getMonth() == yesterday.getMonth() && new Date(value.requestDate).getDate() == yesterday.getDate())
                //     listYesterday.push({
                //       title: notification.Title,
                //       subtitle: notification.Body,
                //       time: value.requestDate,
                //       icon: 'uil uil-calender',
                //       isNew: true,
                //       key: 'Appointments',
                //     });
                //   else if (new Date(value.requestDate) < yesterday && new Date(value.requestDate) > lastWeek)
                //     listLastWeek.push({
                //       title: notification.Title,
                //       subtitle: notification.Body,
                //       time: value.requestDate,
                //       icon: 'uil uil-calender',
                //       isNew: true,
                //       key: 'Appointments',
                //     });
                //   else {
                //     listOlder.push({
                //       title: notification.Title,
                //       subtitle: notification.Body,
                //       time: value.requestDate,
                //       icon: 'uil uil-calender',
                //       isNew: true,
                //       key: 'Appointments',
                //     });
                //   }
                // });
                // if (listToday?.length > 0) {
                //   this.notifications.push({
                //     rangeName: 'notifications.TODAY',
                //     detailNotification: listToday
                //   })
                // }
                // if (listYesterday?.length > 0) {
                //   this.notifications.push({
                //     rangeName: 'notifications.YESTERDAY',
                //     detailNotification: listYesterday
                //   })
                // }
                // if (listLastWeek?.length > 0) {
                //   this.notifications.push({
                //     rangeName: 'notifications.YESTERDAY',
                //     detailNotification: listLastWeek
                //   })
                // }
                // if (listOlder?.length > 0) {
                //   this.notifications.push({
                //     rangeName: 'notifications.OLDER',
                //     detailNotification: listOlder
                //   })
                // }
                this.notificationService.checkCountNotification(this.notifications);
                // console.log(this.notifications);
            });
        });
    }
    markAllRead() {
        this.notifications.every(e => {
            e.detailNotification.forEach(z => z.isNew = false);
        });
        this.notificationService.checkCountNotification(this.notifications);
        console.log(this.notifications);
    }
    chooseFilter(item) {
        item.active = !item.active;
        // const filtered = this.checkList.filter(e => e.active).map(e => e.id);
        // this.notificationService.getListNotification(filtered).subscribe(res => {
        //   this.notifications = res;
        // });
        this.getNotifications();
    }
};
NotificationPage.ctorParameters = () => [
    { type: src_app_service_notification_notification_service__WEBPACK_IMPORTED_MODULE_2__.NotificationService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_12__.NavController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_12__.MenuController },
    { type: _awesome_cordova_plugins_firebase_analytics_ngx__WEBPACK_IMPORTED_MODULE_4__.FirebaseAnalytics },
    { type: _awesome_cordova_plugins_clevertap_ngx__WEBPACK_IMPORTED_MODULE_5__.CleverTap },
    { type: src_app_service_insurance_insurance_service__WEBPACK_IMPORTED_MODULE_6__.InsuranceService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_13__.ActivatedRoute },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_12__.Platform },
    { type: _angular_common__WEBPACK_IMPORTED_MODULE_14__.Location },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_13__.Router },
    { type: _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_15__.Storage }
];
NotificationPage = (0,tslib__WEBPACK_IMPORTED_MODULE_11__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_16__.Component)({
        selector: 'app-notification',
        template: _notification_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_notification_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], NotificationPage);



/***/ }),

/***/ 89347:
/*!************************************************************!*\
  !*** ./src/app/pipe/notification/nice-date-format.pipe.ts ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NiceDateFormatPipe": () => (/* binding */ NiceDateFormatPipe)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 3184);


let NiceDateFormatPipe = class NiceDateFormatPipe {
    constructor(changeDetectorRef, ngZone) {
        this.changeDetectorRef = changeDetectorRef;
        this.ngZone = ngZone;
    }
    transform(value) {
        this.removeTimer();
        const d = new Date(value);
        const now = new Date();
        const seconds = Math.round(Math.abs((now.getTime() - d.getTime()) / 1000));
        const timeToUpdate = (Number.isNaN(seconds)) ? 1000 : this.getSecondsUntilUpdate(seconds) * 1000;
        this.timer = this.ngZone.runOutsideAngular(() => {
            if (typeof window !== 'undefined') {
                return window.setTimeout(() => {
                    this.ngZone.run(() => this.changeDetectorRef.markForCheck());
                }, timeToUpdate);
            }
            return null;
        });
        const minutes = Math.round(Math.abs(seconds / 60));
        const hours = Math.round(Math.abs(minutes / 60));
        // const days = Math.round(Math.abs(hours / 24));
        // let months = Math.round(Math.abs(days/30.416));
        // let years = Math.round(Math.abs(days/365));
        if (Number.isNaN(seconds)) {
            return '';
        }
        else if (seconds <= 45) {
            return seconds + 's ago';
        }
        else if (seconds <= 90) {
            return '1m ago';
        }
        else if (minutes <= 45) {
            return minutes + 'm ago';
        }
        else if (minutes <= 90) {
            return '1h ago';
        }
        else if (hours <= 22) {
            return hours + 'h ago';
        }
        else if (hours <= 36) {
            return d.toLocaleString('en-US', { hour: 'numeric', minute: '2-digit', hour12: true });
        }
        else {
            return d.toLocaleDateString('en-GB', {
                day: '2-digit', month: 'short'
            });
        }
    }
    ngOnDestroy() {
        this.removeTimer();
    }
    removeTimer() {
        if (this.timer) {
            window.clearTimeout(this.timer);
            this.timer = null;
        }
    }
    getSecondsUntilUpdate(seconds) {
        const min = 60;
        const hr = min * 60;
        const day = hr * 24;
        if (seconds < min) { // less than 1 min, update every 2 secs
            return 2;
        }
        else if (seconds < hr) { // less than an hour, update every 30 secs
            return 30;
        }
        else if (seconds < day) { // less then a day, update every 5 mins
            return 300;
        }
        else { // update every hour
            return 3600;
        }
    }
};
NiceDateFormatPipe.ctorParameters = () => [
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ChangeDetectorRef },
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.NgZone }
];
NiceDateFormatPipe = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_0__.Pipe)({
        name: 'niceDateFormat',
        pure: false
    })
], NiceDateFormatPipe);



/***/ }),

/***/ 64530:
/*!********************************************************************************************************!*\
  !*** ./src/app/pages/notification/notification-content/notification-content.component.scss?ngResource ***!
  \********************************************************************************************************/
/***/ ((module) => {

module.exports = ":root {\n  --nc-color-nextgen-neutral-grey-50: #f1efef;\n  --nc-color-nextgen-white: #ffffff;\n  --nc-color-nextgen-blue: #0d152e;\n  --nc-color-nextgen-green: #00908d;\n  --nc-color-nextgen-black: #000000;\n  --nc-color-nextgen-grey-background: #c8d3da;\n  --nc-color-nextgen-grey: #92a2ac;\n  --nc-color-nextgen-stone-grey: #fafafa;\n  --nc-color-nextgen-error: #fc1055;\n  --nc-color-nextgen-neutral-grey: #414141;\n  --nc-color-nextgen-fibrant-green: #00bab6;\n  --nc-color-nextgen-warning: #ffd048;\n  --nc-color-nextgen-green-background: #e6f2f2;\n  --nc-color-nextgen-neutral-grey-400: #7a7a7a;\n  --nc-color-nextgen-neutral-grey-100: #eff3f5;\n  --nc-color-nextgen-status-error: #ba0c3f;\n  --nc-color-nextgen-status-error-background: #ffeff4;\n  --nc-color-nextgen-status-warning: #cba127;\n  --nc-color-nextgen-status-warning-background: #fff8e6;\n  --nc-color-nextgen-blue-100: #dfeff2;\n  --nc-color-nextgen-error-red-700: #f62459;\n  --nc-color-nextgen-blue-500: #006192;\n  --nc-color-nextgen-blue-400: #79cdec;\n  --nc-color-nextgen-red-500: #ff6592;\n  --nc-color-nextgen-secondary-blue-300: #13a0d3;\n  --lumi-white-color: #ffffff;\n  --lumi-primary-yellow-color: #fab600;\n}\n\n.ion-color-green {\n  --ion-color-base: var(--nc-color-nextgen-green);\n  --ion-color-base-rgb: var(--nc-color-nextgen-green);\n  --ion-color-contrast: var(--nc-color-nextgen-white);\n  --ion-color-contrast-rgb: var(--nc-color-nextgen-green);\n  --ion-color-shade: var(--nc-color-nextgen-green);\n  --ion-color-tint: var(--nc-color-nextgen-green);\n}\n\n.main-notification .title {\n  background-color: var(--nc-color-nextgen-neutral-grey-100);\n  color: var(--nc-color-nextgen-grey);\n  padding-top: 0.6rem;\n  padding-bottom: 0.6rem;\n  padding-left: 1.5rem;\n}\n\n.padding-content {\n  padding-left: 0rem;\n  padding-right: 1rem;\n}\n\n.main-content .one-notification {\n  padding-top: 1.2rem;\n  padding-bottom: 1.2rem;\n  border-bottom: 1px solid var(--nc-color-nextgen-neutral-grey-100);\n}\n\n.main-content .one-notification .type-notification i {\n  padding: 0.5rem 0.6rem;\n  background-color: var(--nc-color-nextgen-green-background);\n  border-radius: 50%;\n  color: #122B54;\n}\n\n.main-content .one-notification .information {\n  margin-bottom: 1rem;\n  margin-left: 10px;\n}\n\n.main-content .one-notification .information .main-title {\n  color: var(--nc-color-nextgen-blue);\n}\n\n.main-content .one-notification .information .subscription {\n  color: var(--nc-color-nextgen-neutral-grey-400);\n}\n\n.main-content .one-notification .information .image-notification {\n  margin: 1rem 0;\n}\n\n.main-content .one-notification .information .image-notification img {\n  width: 100%;\n}\n\n.main-content .one-notification .new-notification {\n  position: absolute;\n  right: 0;\n  display: flex;\n}\n\n.main-content .one-notification .new-notification .dot {\n  width: 10px;\n  height: 10px;\n  background-color: var(--nc-color-nextgen-fibrant-green);\n  border-radius: 50%;\n  margin-right: 5px;\n  margin-top: 2px;\n}\n\n.main-content .one-notification .new-notification .time {\n  color: var(--nc-color-nextgen-grey);\n}\n\n.main-content .one-notification .subscription {\n  color: var(--nc-color-nextgen-neutral-grey-400);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFxjb2xvci5zY3NzIiwibm90aWZpY2F0aW9uLWNvbnRlbnQuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDQywyQ0FBQTtFQUNBLGlDQUFBO0VBQ0EsZ0NBQUE7RUFDQSxpQ0FBQTtFQUNBLGlDQUFBO0VBQ0EsMkNBQUE7RUFDQSxnQ0FBQTtFQUNBLHNDQUFBO0VBQ0EsaUNBQUE7RUFDQSx3Q0FBQTtFQUNBLHlDQUFBO0VBQ0EsbUNBQUE7RUFDQSw0Q0FBQTtFQUNBLDRDQUFBO0VBQ0EsNENBQUE7RUFDQSx3Q0FBQTtFQUNBLG1EQUFBO0VBQ0EsMENBQUE7RUFDQSxxREFBQTtFQUNBLG9DQUFBO0VBQ0EseUNBQUE7RUFDQSxvQ0FBQTtFQUNBLG9DQUFBO0VBQ0EsbUNBQUE7RUFDQSw4Q0FBQTtFQUVBLDJCQUFBO0VBQ0Esb0NBQUE7QUNBRDs7QURnQ0E7RUFDQywrQ0FBQTtFQUNBLG1EQUFBO0VBQ0EsbURBQUE7RUFDQSx1REFBQTtFQUNBLGdEQUFBO0VBQ0EsK0NBQUE7QUM3QkQ7O0FBakNJO0VBQ0ksMEREdUN5QjtFQ3RDekIsbUNENkJhO0VDNUJiLG1CQUFBO0VBQ0Esc0JBQUE7RUFDQSxvQkFBQTtBQW9DUjs7QUFqQ0E7RUFDSSxrQkFBQTtFQUNBLG1CQUFBO0FBb0NKOztBQWpDSTtFQUVJLG1CQUFBO0VBQ0Esc0JBQUE7RUFFQSxpRUFBQTtBQWtDUjs7QUFoQ1k7RUFDSSxzQkFBQTtFQUNBLDBERGVpQjtFQ2RqQixrQkFBQTtFQUNBLGNBQUE7QUFrQ2hCOztBQS9CUTtFQUNJLG1CQUFBO0VBQ0EsaUJBQUE7QUFpQ1o7O0FBaENZO0VBQ0ksbUNETEs7QUN1Q3JCOztBQWZZO0VBQ0ksK0NEWmlCO0FDNkJqQzs7QUFmWTtFQUNJLGNBQUE7QUFpQmhCOztBQWhCZ0I7RUFDSSxXQUFBO0FBa0JwQjs7QUFkUTtFQUNJLGtCQUFBO0VBQ0EsUUFBQTtFQUNBLGFBQUE7QUFnQlo7O0FBZlk7RUFDSSxXQUFBO0VBQ0EsWUFBQTtFQUNBLHVERGhDYztFQ2lDZCxrQkFBQTtFQUNBLGlCQUFBO0VBQ0EsZUFBQTtBQWlCaEI7O0FBZlk7RUFDSSxtQ0QxQ0s7QUMyRHJCOztBQWRRO0VBQ0ksK0NEdENxQjtBQ3NEakMiLCJmaWxlIjoibm90aWZpY2F0aW9uLWNvbnRlbnQuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyI6cm9vdCB7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS01MDogI2YxZWZlZjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4td2hpdGU6ICNmZmZmZmY7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWJsdWU6ICMwZDE1MmU7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuOiAjMDA5MDhkO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ibGFjazogIzAwMDAwMDtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tZ3JleS1iYWNrZ3JvdW5kOiAjYzhkM2RhO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ncmV5OiAjOTJhMmFjO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zdG9uZS1ncmV5OiAjZmFmYWZhO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1lcnJvcjogI2ZjMTA1NTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5OiAjNDE0MTQxO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1maWJyYW50LWdyZWVuOiAjMDBiYWI2O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi13YXJuaW5nOiAjZmZkMDQ4O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbi1iYWNrZ3JvdW5kOiAjZTZmMmYyO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNDAwOiAjN2E3YTdhO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktMTAwOiAjZWZmM2Y1O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtZXJyb3I6ICNiYTBjM2Y7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy1lcnJvci1iYWNrZ3JvdW5kOiAjZmZlZmY0O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtd2FybmluZzogI2NiYTEyNztcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLXdhcm5pbmctYmFja2dyb3VuZDogI2ZmZjhlNjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZS0xMDA6ICNkZmVmZjI7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWVycm9yLXJlZC03MDA6ICNmNjI0NTk7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWJsdWUtNTAwOiAjMDA2MTkyO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlLTQwMDogIzc5Y2RlYztcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tcmVkLTUwMDogI2ZmNjU5MjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc2Vjb25kYXJ5LWJsdWUtMzAwOiAjMTNhMGQzO1xyXG5cclxuXHQtLWx1bWktd2hpdGUtY29sb3I6ICNmZmZmZmY7XHJcblx0LS1sdW1pLXByaW1hcnkteWVsbG93LWNvbG9yOiAjZmFiNjAwO1xyXG59XHJcbiRjb2xvci1uZXh0Z2VuLWJsdWU6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZSk7XHJcbiRjb2xvci1uZXh0Z2VuLWdyZWVuOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuKTtcclxuJGNvbG9yLW5leHRnZW4td2hpdGU6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4td2hpdGUpO1xyXG4kY29sb3ItbmV4dGdlbi1ibGFjazogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ibGFjayk7XHJcbiRjb2xvci1uZXh0Z2VuLWdyZXktYmFja2dyb3VuZDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmV5LWJhY2tncm91bmQpO1xyXG4kY29sb3ItbmV4dGdlbi1ncmV5OiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZXkpO1xyXG4kY29sb3ItbmV4dGdlbi1zdG9uZS1ncmV5OiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXN0b25lLWdyZXkpO1xyXG4kY29sb3ItbmV4dGdlbi1lcnJvcjogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1lcnJvcik7XHJcbiRjb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleTogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXkpO1xyXG4kY29sb3ItbmV4dGdlbi1maWJyYW50LWdyZWVuOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWZpYnJhbnQtZ3JlZW4pO1xyXG4kY29sb3ItbmV4dGdlbi13YXJuaW5nOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXdhcm5pbmcpO1xyXG4kY29sb3ItbmV4dGdlbi1ncmVlbi1iYWNrZ3JvdW5kOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuLWJhY2tncm91bmQpO1xyXG4kY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNTA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTUwKTtcclxuJGNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTQwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNDAwKTtcclxuJGNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTEwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktMTAwKTtcclxuJGNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy1lcnJvcik7XHJcbiRjb2xvci1uZXh0Z2VuLXN0YXR1cy1lcnJvci1iYWNrZ3JvdW5kOiB2YXIoXHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy1lcnJvci1iYWNrZ3JvdW5kXHJcbik7XHJcbiRjb2xvci1uZXh0Z2VuLXN0YXR1cy13YXJuaW5nOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy13YXJuaW5nKTtcclxuJGNvbG9yLW5leHRnZW4tc3RhdHVzLXdhcm5pbmctYmFja2dyb3VuZDogdmFyKFxyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtd2FybmluZy1iYWNrZ3JvdW5kXHJcbik7XHJcbiRjb2xvci1uZXh0Z2VuLWJsdWUtMTAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWJsdWUtMTAwKTtcclxuJGNvbG9yLW5leHRnZW4tZXJyb3ItcmVkLTcwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1lcnJvci1yZWQtNzAwKTtcclxuJGNvbG9yLW5leHRnZW4tYmx1ZS01MDA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZS01MDApO1xyXG4kY29sb3ItbmV4dGdlbi1ibHVlLTQwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlLTQwMCk7XHJcbiRjb2xvci1uZXh0Z2VuLXJlZC01MDA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tcmVkLTUwMCk7XHJcbiRjb2xvci1uZXh0Z2VuLXNlY29uZGFyeS1ibHVlLTMwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1zZWNvbmRhcnktYmx1ZS0zMDApO1xyXG5cclxuLmlvbi1jb2xvci1ncmVlbiB7XHJcblx0LS1pb24tY29sb3ItYmFzZTogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbik7XHJcblx0LS1pb24tY29sb3ItYmFzZS1yZ2I6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4pO1xyXG5cdC0taW9uLWNvbG9yLWNvbnRyYXN0OiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXdoaXRlKTtcclxuXHQtLWlvbi1jb2xvci1jb250cmFzdC1yZ2I6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4pO1xyXG5cdC0taW9uLWNvbG9yLXNoYWRlOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuKTtcclxuXHQtLWlvbi1jb2xvci10aW50OiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuKTtcclxufVxyXG4iLCJAaW1wb3J0IFwiLi4vLi4vLi4vLi4vY29sb3Iuc2Nzc1wiO1xyXG5cclxuXHJcbi5tYWluLW5vdGlmaWNhdGlvbntcclxuICAgIC50aXRsZXtcclxuICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiAkY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktMTAwO1xyXG4gICAgICAgIGNvbG9yOiAkY29sb3ItbmV4dGdlbi1ncmV5O1xyXG4gICAgICAgIHBhZGRpbmctdG9wOiAwLjZyZW07XHJcbiAgICAgICAgcGFkZGluZy1ib3R0b206IDAuNnJlbTtcclxuICAgICAgICBwYWRkaW5nLWxlZnQ6IDEuNXJlbTtcclxuICAgIH1cclxufVxyXG4ucGFkZGluZy1jb250ZW50e1xyXG4gICAgcGFkZGluZy1sZWZ0OiAwcmVtO1xyXG4gICAgcGFkZGluZy1yaWdodDogMXJlbTtcclxufVxyXG4ubWFpbi1jb250ZW50e1xyXG4gICAgLm9uZS1ub3RpZmljYXRpb257XHJcbiAgICAgICAgLy8gcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgICAgIHBhZGRpbmctdG9wOiAxLjJyZW07XHJcbiAgICAgICAgcGFkZGluZy1ib3R0b206IDEuMnJlbTtcclxuICAgICAgICAvLyBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICAgIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAkY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktMTAwO1xyXG4gICAgICAgIC50eXBlLW5vdGlmaWNhdGlvbntcclxuICAgICAgICAgICAgaXtcclxuICAgICAgICAgICAgICAgIHBhZGRpbmc6IDAuNXJlbSAwLjZyZW07XHJcbiAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiAkY29sb3ItbmV4dGdlbi1ncmVlbi1iYWNrZ3JvdW5kO1xyXG4gICAgICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogNTAlO1xyXG4gICAgICAgICAgICAgICAgY29sb3I6ICMxMjJCNTQ7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgLmluZm9ybWF0aW9ueyAgXHJcbiAgICAgICAgICAgIG1hcmdpbi1ib3R0b206IDFyZW07IFxyXG4gICAgICAgICAgICBtYXJnaW4tbGVmdDogMTBweDtcclxuICAgICAgICAgICAgLm1haW4tdGl0bGV7XHJcbiAgICAgICAgICAgICAgICBjb2xvcjokY29sb3ItbmV4dGdlbi1ibHVlO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIC8vIC5uZXctbm90aWZpY2F0aW9ue1xyXG4gICAgICAgICAgICAvLyAgICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgICAgICAgICAvLyAgICAgcmlnaHQ6IDA7XHJcbiAgICAgICAgICAgIC8vICAgICB0b3A6IDE5cHg7XHJcbiAgICAgICAgICAgIC8vICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICAgICAgICAvLyAgICAgLmRvdHtcclxuICAgICAgICAgICAgLy8gICAgICAgICB3aWR0aDogMTBweDtcclxuICAgICAgICAgICAgLy8gICAgICAgICBoZWlnaHQ6IDEwcHg7XHJcbiAgICAgICAgICAgIC8vICAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogJGNvbG9yLW5leHRnZW4tZmlicmFudC1ncmVlbjtcclxuICAgICAgICAgICAgLy8gICAgICAgICBib3JkZXItcmFkaXVzOiA1MCU7XHJcbiAgICAgICAgICAgIC8vICAgICAgICAgbWFyZ2luLXJpZ2h0OiA1cHg7XHJcbiAgICAgICAgICAgIC8vICAgICAgICAgbWFyZ2luLXRvcDogMnB4IFxyXG4gICAgICAgICAgICAvLyAgICAgfVxyXG4gICAgICAgICAgICAvLyAgICAgLnRpbWV7XHJcbiAgICAgICAgICAgIC8vICAgICAgICAgY29sb3I6ICRjb2xvci1uZXh0Z2VuLWdyZXk7XHJcbiAgICAgICAgICAgIC8vICAgICB9XHJcbiAgICAgICAgICAgIC8vIH1cclxuICAgICAgICAgICAgLnN1YnNjcmlwdGlvbntcclxuICAgICAgICAgICAgICAgIGNvbG9yOiAkY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNDAwO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIC5pbWFnZS1ub3RpZmljYXRpb257XHJcbiAgICAgICAgICAgICAgICBtYXJnaW46IDFyZW0gMDtcclxuICAgICAgICAgICAgICAgIGltZ3tcclxuICAgICAgICAgICAgICAgICAgICB3aWR0aDogMTAwJTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICAubmV3LW5vdGlmaWNhdGlvbntcclxuICAgICAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgICAgICAgICByaWdodDogMDtcclxuICAgICAgICAgICAgZGlzcGxheTogZmxleDtcclxuICAgICAgICAgICAgLmRvdHtcclxuICAgICAgICAgICAgICAgIHdpZHRoOiAxMHB4O1xyXG4gICAgICAgICAgICAgICAgaGVpZ2h0OiAxMHB4O1xyXG4gICAgICAgICAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogJGNvbG9yLW5leHRnZW4tZmlicmFudC1ncmVlbjtcclxuICAgICAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDUwJTtcclxuICAgICAgICAgICAgICAgIG1hcmdpbi1yaWdodDogNXB4O1xyXG4gICAgICAgICAgICAgICAgbWFyZ2luLXRvcDogMnB4IFxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIC50aW1le1xyXG4gICAgICAgICAgICAgICAgY29sb3I6ICRjb2xvci1uZXh0Z2VuLWdyZXk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgLnN1YnNjcmlwdGlvbntcclxuICAgICAgICAgICAgY29sb3I6ICRjb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS00MDA7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59Il19 */";

/***/ }),

/***/ 15116:
/*!**********************************************************************!*\
  !*** ./src/app/pages/notification/notification.page.scss?ngResource ***!
  \**********************************************************************/
/***/ ((module) => {

module.exports = ":root {\n  --nc-color-nextgen-neutral-grey-50: #f1efef;\n  --nc-color-nextgen-white: #ffffff;\n  --nc-color-nextgen-blue: #0d152e;\n  --nc-color-nextgen-green: #00908d;\n  --nc-color-nextgen-black: #000000;\n  --nc-color-nextgen-grey-background: #c8d3da;\n  --nc-color-nextgen-grey: #92a2ac;\n  --nc-color-nextgen-stone-grey: #fafafa;\n  --nc-color-nextgen-error: #fc1055;\n  --nc-color-nextgen-neutral-grey: #414141;\n  --nc-color-nextgen-fibrant-green: #00bab6;\n  --nc-color-nextgen-warning: #ffd048;\n  --nc-color-nextgen-green-background: #e6f2f2;\n  --nc-color-nextgen-neutral-grey-400: #7a7a7a;\n  --nc-color-nextgen-neutral-grey-100: #eff3f5;\n  --nc-color-nextgen-status-error: #ba0c3f;\n  --nc-color-nextgen-status-error-background: #ffeff4;\n  --nc-color-nextgen-status-warning: #cba127;\n  --nc-color-nextgen-status-warning-background: #fff8e6;\n  --nc-color-nextgen-blue-100: #dfeff2;\n  --nc-color-nextgen-error-red-700: #f62459;\n  --nc-color-nextgen-blue-500: #006192;\n  --nc-color-nextgen-blue-400: #79cdec;\n  --nc-color-nextgen-red-500: #ff6592;\n  --nc-color-nextgen-secondary-blue-300: #13a0d3;\n  --lumi-white-color: #ffffff;\n  --lumi-primary-yellow-color: #fab600;\n}\n\n.ion-color-green {\n  --ion-color-base: var(--nc-color-nextgen-green);\n  --ion-color-base-rgb: var(--nc-color-nextgen-green);\n  --ion-color-contrast: var(--nc-color-nextgen-white);\n  --ion-color-contrast-rgb: var(--nc-color-nextgen-green);\n  --ion-color-shade: var(--nc-color-nextgen-green);\n  --ion-color-tint: var(--nc-color-nextgen-green);\n}\n\n.notification-container {\n  background: var(--nc-color-nextgen-white);\n}\n\n.padding-content {\n  padding-left: 2rem;\n  padding-right: 2rem;\n}\n\n.title-text {\n  color: var(--nc-color-nextgen-blue);\n}\n\n.unread-notification {\n  display: flex;\n  justify-content: space-between;\n  padding-bottom: 1rem;\n}\n\n.unread-notification .all-check-btn {\n  color: var(--nc-color-nextgen-green);\n  float: right !important;\n}\n\n.filter-list {\n  margin: 1rem 0;\n  display: flex;\n  width: 100%;\n  flex-direction: row;\n  align-items: center;\n  gap: 0.25rem;\n  overflow: auto;\n  overflow: -moz-scrollbars-none;\n  -ms-overflow-style: none;\n  padding-left: 1rem;\n}\n\n.filter-list::-webkit-scrollbar {\n  width: 0 !important;\n  display: none;\n}\n\n.filter-btn {\n  border: 1px solid var(--nc-color-nextgen-grey-background);\n  width: auto;\n  height: 4vh;\n  padding: 0 0.25rem;\n  border-radius: 2vh;\n  background: var(--nc-color-nextgen-white);\n  --background: $color-nextgen-white;\n  --background-activated: $color-nextgen-white;\n}\n\n.filter-btn .uil-multiply {\n  padding-left: 12px;\n  display: none;\n}\n\n.filter-btn.active {\n  border: 1px solid var(--nc-color-nextgen-green);\n  width: auto;\n  height: 4vh;\n  padding: 0 0.25rem;\n  border-radius: 2vh;\n  background: var(--nc-color-nextgen-green-background);\n  color: var(--nc-color-nextgen-green);\n}\n\n.filter-btn.active .uil-multiply {\n  color: var(--nc-color-nextgen-green);\n  display: block;\n}\n\nion-button {\n  --background-hover: \"\";\n  --background-focused: \"\";\n  --box-shadow: none;\n  text-transform: none !important;\n}\n\n:host ::ng-deep .layout-container {\n  margin-left: unset !important;\n  margin-right: unset !important;\n}\n\n.padding {\n  margin-left: 24px;\n  margin-right: 24px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXGNvbG9yLnNjc3MiLCJub3RpZmljYXRpb24ucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0MsMkNBQUE7RUFDQSxpQ0FBQTtFQUNBLGdDQUFBO0VBQ0EsaUNBQUE7RUFDQSxpQ0FBQTtFQUNBLDJDQUFBO0VBQ0EsZ0NBQUE7RUFDQSxzQ0FBQTtFQUNBLGlDQUFBO0VBQ0Esd0NBQUE7RUFDQSx5Q0FBQTtFQUNBLG1DQUFBO0VBQ0EsNENBQUE7RUFDQSw0Q0FBQTtFQUNBLDRDQUFBO0VBQ0Esd0NBQUE7RUFDQSxtREFBQTtFQUNBLDBDQUFBO0VBQ0EscURBQUE7RUFDQSxvQ0FBQTtFQUNBLHlDQUFBO0VBQ0Esb0NBQUE7RUFDQSxvQ0FBQTtFQUNBLG1DQUFBO0VBQ0EsOENBQUE7RUFFQSwyQkFBQTtFQUNBLG9DQUFBO0FDQUQ7O0FEZ0NBO0VBQ0MsK0NBQUE7RUFDQSxtREFBQTtFQUNBLG1EQUFBO0VBQ0EsdURBQUE7RUFDQSxnREFBQTtFQUNBLCtDQUFBO0FDN0JEOztBQW5DQTtFQUNJLHlDRDZCa0I7QUNTdEI7O0FBbkNBO0VBQ0ksa0JBQUE7RUFDQSxtQkFBQTtBQXNDSjs7QUFuQ0E7RUFDSSxtQ0RrQmlCO0FDb0JyQjs7QUFwQ0E7RUFDSSxhQUFBO0VBQ0EsOEJBQUE7RUFDQSxvQkFBQTtBQXVDSjs7QUF0Q0k7RUFDSSxvQ0RZYztFQ1hkLHVCQUFBO0FBd0NSOztBQXJDQTtFQUNJLGNBQUE7RUFDQSxhQUFBO0VBQ0EsV0FBQTtFQUNBLG1CQUFBO0VBQ0EsbUJBQUE7RUFDQSxZQUFBO0VBQ0EsY0FBQTtFQUNBLDhCQUFBO0VBQ0Esd0JBQUE7RUFDQSxrQkFBQTtBQXdDSjs7QUF0Q0E7RUFDSSxtQkFBQTtFQUNBLGFBQUE7QUF5Q0o7O0FBdkNBO0VBQ0kseURBQUE7RUFDQSxXQUFBO0VBQ0EsV0FBQTtFQUNBLGtCQUFBO0VBQ0Esa0JBQUE7RUFDQSx5Q0Ria0I7RUNjbEIsa0NBQUE7RUFDQSw0Q0FBQTtBQTBDSjs7QUF6Q0k7RUFDSSxrQkFBQTtFQUNBLGFBQUE7QUEyQ1I7O0FBeENBO0VBQ0ksK0NBQUE7RUFDQSxXQUFBO0VBQ0EsV0FBQTtFQUNBLGtCQUFBO0VBQ0Esa0JBQUE7RUFDQSxvRERsQjZCO0VDbUI3QixvQ0Q3QmtCO0FDd0V0Qjs7QUExQ0k7RUFDSSxvQ0QvQmM7RUNnQ2QsY0FBQTtBQTRDUjs7QUF6Q0E7RUFDSSxzQkFBQTtFQUNBLHdCQUFBO0VBQ0Esa0JBQUE7RUFDQSwrQkFBQTtBQTRDSjs7QUF4Q0k7RUFDSSw2QkFBQTtFQUNBLDhCQUFBO0FBMkNSOztBQXZDRTtFQUNFLGlCQUFBO0VBQ0ksa0JBQUE7QUEwQ1IiLCJmaWxlIjoibm90aWZpY2F0aW9uLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIjpyb290IHtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTUwOiAjZjFlZmVmO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi13aGl0ZTogI2ZmZmZmZjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZTogIzBkMTUyZTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW46ICMwMDkwOGQ7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWJsYWNrOiAjMDAwMDAwO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ncmV5LWJhY2tncm91bmQ6ICNjOGQzZGE7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWdyZXk6ICM5MmEyYWM7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0b25lLWdyZXk6ICNmYWZhZmE7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWVycm9yOiAjZmMxMDU1O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXk6ICM0MTQxNDE7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWZpYnJhbnQtZ3JlZW46ICMwMGJhYjY7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXdhcm5pbmc6ICNmZmQwNDg7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuLWJhY2tncm91bmQ6ICNlNmYyZjI7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS00MDA6ICM3YTdhN2E7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS0xMDA6ICNlZmYzZjU7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy1lcnJvcjogI2JhMGMzZjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yLWJhY2tncm91bmQ6ICNmZmVmZjQ7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy13YXJuaW5nOiAjY2JhMTI3O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtd2FybmluZy1iYWNrZ3JvdW5kOiAjZmZmOGU2O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlLTEwMDogI2RmZWZmMjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tZXJyb3ItcmVkLTcwMDogI2Y2MjQ1OTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZS01MDA6ICMwMDYxOTI7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWJsdWUtNDAwOiAjNzljZGVjO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1yZWQtNTAwOiAjZmY2NTkyO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zZWNvbmRhcnktYmx1ZS0zMDA6ICMxM2EwZDM7XHJcblxyXG5cdC0tbHVtaS13aGl0ZS1jb2xvcjogI2ZmZmZmZjtcclxuXHQtLWx1bWktcHJpbWFyeS15ZWxsb3ctY29sb3I6ICNmYWI2MDA7XHJcbn1cclxuJGNvbG9yLW5leHRnZW4tYmx1ZTogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlKTtcclxuJGNvbG9yLW5leHRnZW4tZ3JlZW46IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4pO1xyXG4kY29sb3ItbmV4dGdlbi13aGl0ZTogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi13aGl0ZSk7XHJcbiRjb2xvci1uZXh0Z2VuLWJsYWNrOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWJsYWNrKTtcclxuJGNvbG9yLW5leHRnZW4tZ3JleS1iYWNrZ3JvdW5kOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZXktYmFja2dyb3VuZCk7XHJcbiRjb2xvci1uZXh0Z2VuLWdyZXk6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JleSk7XHJcbiRjb2xvci1uZXh0Z2VuLXN0b25lLWdyZXk6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tc3RvbmUtZ3JleSk7XHJcbiRjb2xvci1uZXh0Z2VuLWVycm9yOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWVycm9yKTtcclxuJGNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5OiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleSk7XHJcbiRjb2xvci1uZXh0Z2VuLWZpYnJhbnQtZ3JlZW46IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZmlicmFudC1ncmVlbik7XHJcbiRjb2xvci1uZXh0Z2VuLXdhcm5pbmc6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4td2FybmluZyk7XHJcbiRjb2xvci1uZXh0Z2VuLWdyZWVuLWJhY2tncm91bmQ6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4tYmFja2dyb3VuZCk7XHJcbiRjb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS01MDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNTApO1xyXG4kY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNDAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS00MDApO1xyXG4kY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktMTAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS0xMDApO1xyXG4kY29sb3ItbmV4dGdlbi1zdGF0dXMtZXJyb3I6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yKTtcclxuJGNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yLWJhY2tncm91bmQ6IHZhcihcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yLWJhY2tncm91bmRcclxuKTtcclxuJGNvbG9yLW5leHRnZW4tc3RhdHVzLXdhcm5pbmc6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLXdhcm5pbmcpO1xyXG4kY29sb3ItbmV4dGdlbi1zdGF0dXMtd2FybmluZy1iYWNrZ3JvdW5kOiB2YXIoXHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy13YXJuaW5nLWJhY2tncm91bmRcclxuKTtcclxuJGNvbG9yLW5leHRnZW4tYmx1ZS0xMDA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZS0xMDApO1xyXG4kY29sb3ItbmV4dGdlbi1lcnJvci1yZWQtNzAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWVycm9yLXJlZC03MDApO1xyXG4kY29sb3ItbmV4dGdlbi1ibHVlLTUwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlLTUwMCk7XHJcbiRjb2xvci1uZXh0Z2VuLWJsdWUtNDAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWJsdWUtNDAwKTtcclxuJGNvbG9yLW5leHRnZW4tcmVkLTUwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1yZWQtNTAwKTtcclxuJGNvbG9yLW5leHRnZW4tc2Vjb25kYXJ5LWJsdWUtMzAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXNlY29uZGFyeS1ibHVlLTMwMCk7XHJcblxyXG4uaW9uLWNvbG9yLWdyZWVuIHtcclxuXHQtLWlvbi1jb2xvci1iYXNlOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuKTtcclxuXHQtLWlvbi1jb2xvci1iYXNlLXJnYjogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbik7XHJcblx0LS1pb24tY29sb3ItY29udHJhc3Q6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4td2hpdGUpO1xyXG5cdC0taW9uLWNvbG9yLWNvbnRyYXN0LXJnYjogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbik7XHJcblx0LS1pb24tY29sb3Itc2hhZGU6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4pO1xyXG5cdC0taW9uLWNvbG9yLXRpbnQ6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4pO1xyXG59XHJcbiIsIkBpbXBvcnQgXCIuLi8uLi8uLi9jb2xvci5zY3NzXCI7XHJcblxyXG4ubm90aWZpY2F0aW9uLWNvbnRhaW5lciB7XHJcbiAgICBiYWNrZ3JvdW5kOiAkY29sb3ItbmV4dGdlbi13aGl0ZTtcclxufVxyXG5cclxuLnBhZGRpbmctY29udGVudHtcclxuICAgIHBhZGRpbmctbGVmdDogMnJlbTtcclxuICAgIHBhZGRpbmctcmlnaHQ6IDJyZW07XHJcbn1cclxuXHJcbi50aXRsZS10ZXh0IHtcclxuICAgIGNvbG9yOiAkY29sb3ItbmV4dGdlbi1ibHVlO1xyXG59XHJcbi51bnJlYWQtbm90aWZpY2F0aW9uIHtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XHJcbiAgICBwYWRkaW5nLWJvdHRvbTogMXJlbTtcclxuICAgIC5hbGwtY2hlY2stYnRue1xyXG4gICAgICAgIGNvbG9yOiAkY29sb3ItbmV4dGdlbi1ncmVlbjtcclxuICAgICAgICBmbG9hdDogcmlnaHQgIWltcG9ydGFudDtcclxuICAgIH1cclxufVxyXG4uZmlsdGVyLWxpc3Qge1xyXG4gICAgbWFyZ2luOiAxcmVtIDA7IFxyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgZmxleC1kaXJlY3Rpb246IHJvdztcclxuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICBnYXA6IDAuMjVyZW07XHJcbiAgICBvdmVyZmxvdzogYXV0bztcclxuICAgIG92ZXJmbG93OiAtbW96LXNjcm9sbGJhcnMtbm9uZTtcclxuICAgIC1tcy1vdmVyZmxvdy1zdHlsZTogbm9uZTtcclxuICAgIHBhZGRpbmctbGVmdDogMXJlbTtcclxufVxyXG4uZmlsdGVyLWxpc3Q6Oi13ZWJraXQtc2Nyb2xsYmFyIHtcclxuICAgIHdpZHRoOiAwICFpbXBvcnRhbnQ7XHJcbiAgICBkaXNwbGF5OiBub25lO1xyXG4gIH1cclxuLmZpbHRlci1idG4ge1xyXG4gICAgYm9yZGVyOiAxcHggc29saWQgJGNvbG9yLW5leHRnZW4tZ3JleS1iYWNrZ3JvdW5kO1xyXG4gICAgd2lkdGg6IGF1dG87XHJcbiAgICBoZWlnaHQ6IDR2aDtcclxuICAgIHBhZGRpbmc6IDAgMC4yNXJlbTtcclxuICAgIGJvcmRlci1yYWRpdXM6IDJ2aDtcclxuICAgIGJhY2tncm91bmQ6ICRjb2xvci1uZXh0Z2VuLXdoaXRlO1xyXG4gICAgLS1iYWNrZ3JvdW5kOiAkY29sb3ItbmV4dGdlbi13aGl0ZTtcclxuICAgIC0tYmFja2dyb3VuZC1hY3RpdmF0ZWQ6ICRjb2xvci1uZXh0Z2VuLXdoaXRlO1xyXG4gICAgLnVpbC1tdWx0aXBseSB7XHJcbiAgICAgICAgcGFkZGluZy1sZWZ0OiAxMnB4O1xyXG4gICAgICAgIGRpc3BsYXk6IG5vbmU7XHJcbiAgICAgIH1cclxufVxyXG4uZmlsdGVyLWJ0bi5hY3RpdmV7XHJcbiAgICBib3JkZXI6IDFweCBzb2xpZCAkY29sb3ItbmV4dGdlbi1ncmVlbjtcclxuICAgIHdpZHRoOiBhdXRvO1xyXG4gICAgaGVpZ2h0OiA0dmg7XHJcbiAgICBwYWRkaW5nOiAwIDAuMjVyZW07XHJcbiAgICBib3JkZXItcmFkaXVzOiAydmg7XHJcbiAgICBiYWNrZ3JvdW5kOiAkY29sb3ItbmV4dGdlbi1ncmVlbi1iYWNrZ3JvdW5kO1xyXG4gICAgY29sb3I6ICRjb2xvci1uZXh0Z2VuLWdyZWVuO1xyXG4gICAgLnVpbC1tdWx0aXBseSB7XHJcbiAgICAgICAgY29sb3I6ICRjb2xvci1uZXh0Z2VuLWdyZWVuO1xyXG4gICAgICAgIGRpc3BsYXk6IGJsb2NrO1xyXG4gICAgICB9XHJcbn1cclxuaW9uLWJ1dHRvbiB7XHJcbiAgICAtLWJhY2tncm91bmQtaG92ZXI6ICcnO1xyXG4gICAgLS1iYWNrZ3JvdW5kLWZvY3VzZWQ6ICcnO1xyXG4gICAgLS1ib3gtc2hhZG93OiBub25lO1xyXG4gICAgdGV4dC10cmFuc2Zvcm06IG5vbmUhaW1wb3J0YW50O1xyXG4gIH1cclxuXHJcbiAgOmhvc3QgOjpuZy1kZWVwIHtcclxuICAgIC5sYXlvdXQtY29udGFpbmVyIHtcclxuICAgICAgICBtYXJnaW4tbGVmdDogdW5zZXQgIWltcG9ydGFudDtcclxuICAgICAgICBtYXJnaW4tcmlnaHQ6IHVuc2V0ICFpbXBvcnRhbnQ7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICAucGFkZGluZyB7XHJcbiAgICBtYXJnaW4tbGVmdDogMjRweDtcclxuICAgICAgICBtYXJnaW4tcmlnaHQ6IDI0cHg7XHJcbiAgfVxyXG5cclxuICAiXX0= */";

/***/ }),

/***/ 73971:
/*!********************************************************************************************************!*\
  !*** ./src/app/pages/notification/notification-content/notification-content.component.html?ngResource ***!
  \********************************************************************************************************/
/***/ ((module) => {

module.exports = "<div class=\"main-notification\" *ngFor=\"let notification of notifications\">\r\n  <!-- <div class=\"title\">\r\n    <span class=\"body-sm bold\">{{notification.rangeName | translate}}</span>\r\n  </div> -->\r\n  <div class=\"main-content padding-content\">\r\n    <ion-grid mode=\"ios\" (click)=\"checkNewNotification(item)\" class=\"one-notification\"\r\n      *ngFor=\"let item of notification.detailNotification\">\r\n      <ion-row>\r\n        <ion-col size=\"2\">\r\n          <div class=\"type-notification\">\r\n            <i [class]=\"item.icon\"></i>\r\n          </div>\r\n        </ion-col>\r\n        <ion-col size=\"7\">\r\n          <p class=\"body-sm bold main-title\">{{item.title}}</p>\r\n        </ion-col>\r\n        <ion-col size=\"3\">\r\n          <div class=\"new-notification\">\r\n            <div *ngIf=\"item.isNew === true\" class=\"dot\"></div>\r\n            <span class=\"body-sm time\">{{item.time | niceDateFormat | translate}}</span>\r\n          </div>\r\n        </ion-col>\r\n      </ion-row>\r\n      <ion-row>\r\n        <ion-col size=\"2\"></ion-col>\r\n        <ion-col size=\"10\"> <span class=\"subscription body-sm\">{{item.subtitle}}</span>\r\n          <div class=\"image-notification\" *ngIf=\"item.image\">\r\n            <img src=\"{{item.image}}\" alt=\"\">\r\n          </div>\r\n        </ion-col>\r\n      </ion-row>\r\n    </ion-grid>\r\n  </div>\r\n</div>\r\n<div class=\"data-default\" *ngIf=\"!notifications || notifications.length === 0\">\r\n  <ion-text class=\"body-l\">{{ 'notifications.dataDefault' | translate}}</ion-text>\r\n</div>";

/***/ }),

/***/ 45816:
/*!**********************************************************************!*\
  !*** ./src/app/pages/notification/notification.page.html?ngResource ***!
  \**********************************************************************/
/***/ ((module) => {

module.exports = "<div class=\"notification-container\">\r\n  <nextcare-layout>\r\n    <ng-template header>\r\n      <ion-row>\r\n        <ion-col size=\"2\" class=\"d-flex\">\r\n          <button class=\"btn btn-circle\" (click)=\"onBack()\">\r\n            <ion-icon  class=\"icon-back body-l\" name=\"arrow-back-outline\"></ion-icon>\r\n          </button>\r\n        </ion-col>\r\n        <ion-col size=\"8\" class=\"row\">\r\n          <span class=\"title-text h6 bold\">{{'home.notifications'|translate}}</span>\r\n        </ion-col>\r\n        <ion-col size=\"2\">\r\n        </ion-col>\r\n      </ion-row>\r\n    </ng-template>\r\n    <ng-template body>\r\n      <div class=\"filter-list\">\r\n        <ion-button (click)=\"chooseFilter(item)\" *ngFor=\"let item of checkList, index as i\" class=\"filter-btn body-xs\"\r\n          [ngClass]=\"item.active ? 'active': ''\">{{item.name | translate}} <i class=\"uil uil-multiply\"></i></ion-button>\r\n      </div>\r\n      <!-- <div class=\"unread-notification\">\r\n        <span class=\"body-sm bold\">{{countNotifications}} {{'notifications.unreadMessages' | translate}}</span>\r\n        <span (click)=\"markAllRead()\" class=\"all-check-btn body-xs bold\">{{'notifications.markAllRead' |\r\n          translate}}</span>\r\n      </div> -->\r\n      <app-notification-content [notifications]=\"notifications\"></app-notification-content>\r\n    </ng-template>\r\n  </nextcare-layout>\r\n</div>";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_notification_notification_module_ts.js.map