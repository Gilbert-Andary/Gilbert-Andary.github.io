"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_get-started_get-started_module_ts"],{

/***/ 37187:
/*!*****************************************************************!*\
  !*** ./src/app/pages/get-started/get-started-routing.module.ts ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "GetStartedRoutingModule": () => (/* binding */ GetStartedRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _get_started_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./get-started.page */ 30446);




const routes = [
    {
        path: '',
        component: _get_started_page__WEBPACK_IMPORTED_MODULE_0__.GetStartedPage,
    },
];
let GetStartedRoutingModule = class GetStartedRoutingModule {
};
GetStartedRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], GetStartedRoutingModule);



/***/ }),

/***/ 61675:
/*!*********************************************************!*\
  !*** ./src/app/pages/get-started/get-started.module.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "GetStartedModule": () => (/* binding */ GetStartedModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _get_started_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./get-started.page */ 30446);
/* harmony import */ var _get_started_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./get-started-routing.module */ 37187);
/* harmony import */ var src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/shared/shared.module */ 44466);








let GetStartedModule = class GetStartedModule {
};
GetStartedModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonicModule,
            _get_started_routing_module__WEBPACK_IMPORTED_MODULE_1__.GetStartedRoutingModule,
            src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_2__.SharedModule,
        ],
        declarations: [_get_started_page__WEBPACK_IMPORTED_MODULE_0__.GetStartedPage]
    })
], GetStartedModule);



/***/ }),

/***/ 30446:
/*!*******************************************************!*\
  !*** ./src/app/pages/get-started/get-started.page.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "GetStartedPage": () => (/* binding */ GetStartedPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _get_started_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./get-started.page.html?ngResource */ 79996);
/* harmony import */ var _get_started_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./get-started.page.scss?ngResource */ 89640);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _awesome_cordova_plugins_app_version_ngx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @awesome-cordova-plugins/app-version/ngx */ 74582);
/* harmony import */ var _awesome_cordova_plugins_clevertap_ngx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @awesome-cordova-plugins/clevertap/ngx */ 45363);
/* harmony import */ var _awesome_cordova_plugins_firebase_analytics_ngx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @awesome-cordova-plugins/firebase-analytics/ngx */ 48852);
/* harmony import */ var _capgo_capacitor_navigation_bar__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @capgo/capacitor-navigation-bar */ 48012);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @environments/environment */ 92340);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @ionic/storage-angular */ 80190);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var src_app_service_language_language_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/service/language/language.service */ 11281);
/* harmony import */ var src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/shared/data/constants */ 74676);
/* harmony import */ var src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/shared/data/enum/event */ 38570);
/* harmony import */ var src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/app/shared/data/enum/screen */ 68302);

















let GetStartedPage = class GetStartedPage {
    constructor(router, storage, firebaseAnalytics, clevertap, appVersion, platform, languageService, translate) {
        this.router = router;
        this.storage = storage;
        this.firebaseAnalytics = firebaseAnalytics;
        this.clevertap = clevertap;
        this.appVersion = appVersion;
        this.platform = platform;
        this.languageService = languageService;
        this.translate = translate;
        this.versionApp = _environments_environment__WEBPACK_IMPORTED_MODULE_6__.environment.appVersion;
        this.language = null;
        this.labels = [];
        this.currentIndex = 0;
        this.currentLabel = undefined;
    }
    ngOnInit() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_11__.__awaiter)(this, void 0, void 0, function* () {
            this.languageService.getLanguages().subscribe((data) => (0,tslib__WEBPACK_IMPORTED_MODULE_11__.__awaiter)(this, void 0, void 0, function* () {
                data.forEach((obj, idx, array) => (0,tslib__WEBPACK_IMPORTED_MODULE_11__.__awaiter)(this, void 0, void 0, function* () {
                    let translatedvalue = yield this.languageService.getJsonKeyValue('getStarted', 'getStarted', obj.culture);
                    this.labels.push(translatedvalue);
                    if (array.length - 1 == idx) {
                        this.triggerInterval();
                    }
                }));
            }));
            try {
                this.versionApp = yield this.appVersion.getVersionNumber();
            }
            catch (error) {
                console.log(error);
            }
        });
    }
    triggerInterval() {
        this.currentLabel = this.labels[this.currentIndex];
        setInterval(() => {
            this.currentIndex = (this.currentIndex + 1) % this.labels.length;
            this.currentLabel = undefined;
            setTimeout(() => {
                this.currentLabel = this.labels[this.currentIndex];
            }, 10);
        }, 2000);
    }
    ionViewWillEnter() {
        this.platform.ready().then(() => {
            _capgo_capacitor_navigation_bar__WEBPACK_IMPORTED_MODULE_5__.NavigationBar.setNavigationBarColor({
                color: '#0D152E',
            });
        });
    }
    ionViewDidEnter() {
        this.subscription = this.platform.backButton.subscribeWithPriority(9999, () => {
            navigator['app'].exitApp();
        });
    }
    ionViewWillLeave() {
        this.platform.ready().then(() => {
            _capgo_capacitor_navigation_bar__WEBPACK_IMPORTED_MODULE_5__.NavigationBar.setNavigationBarColor({
                color: '#FFFFFF',
            });
        });
        this.subscription.unsubscribe();
    }
    redirectToSelectLanguage() {
        this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_10__.Screens.LanguageSelection]).then(() => { });
        this.firebaseAnalytics.logEvent(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_9__.GA4Event.OnboardingProceeded, {});
        this.clevertap.recordEventWithName(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_9__.GA4Event.OnboardingProceeded);
    }
    redirectToSignIn() {
        this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_10__.Screens.SignIn]).then(() => { });
        this.firebaseAnalytics.logEvent(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_9__.GA4Event.OnboardingProceeded, {});
        this.clevertap.recordEventWithName('registration_home_screen');
        window.localStorage.setItem(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_8__.Constants.PREFERED_LANGUAGE, src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_8__.Constants.DEFAULT_LANGUAGE);
    }
};
GetStartedPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_12__.Router },
    { type: _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_13__.Storage },
    { type: _awesome_cordova_plugins_firebase_analytics_ngx__WEBPACK_IMPORTED_MODULE_4__.FirebaseAnalytics },
    { type: _awesome_cordova_plugins_clevertap_ngx__WEBPACK_IMPORTED_MODULE_3__.CleverTap },
    { type: _awesome_cordova_plugins_app_version_ngx__WEBPACK_IMPORTED_MODULE_2__.AppVersion },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_14__.Platform },
    { type: src_app_service_language_language_service__WEBPACK_IMPORTED_MODULE_7__.LanguageService },
    { type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_15__.TranslateService }
];
GetStartedPage = (0,tslib__WEBPACK_IMPORTED_MODULE_11__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_16__.Component)({
        selector: 'app-get-started',
        template: _get_started_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_get_started_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], GetStartedPage);



/***/ }),

/***/ 74675:
/*!******************************************************************************!*\
  !*** ./node_modules/@capgo/capacitor-navigation-bar/dist/esm/definitions.js ***!
  \******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);



/***/ }),

/***/ 48012:
/*!************************************************************************!*\
  !*** ./node_modules/@capgo/capacitor-navigation-bar/dist/esm/index.js ***!
  \************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NavigationBar": () => (/* binding */ NavigationBar)
/* harmony export */ });
/* harmony import */ var _capacitor_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @capacitor/core */ 26549);
/* harmony import */ var _definitions__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./definitions */ 74675);

const NavigationBar = (0,_capacitor_core__WEBPACK_IMPORTED_MODULE_0__.registerPlugin)('NavigationBar', {
    web: () => __webpack_require__.e(/*! import() */ "node_modules_capgo_capacitor-navigation-bar_dist_esm_web_js").then(__webpack_require__.bind(__webpack_require__, /*! ./web */ 15610)).then(m => new m.NavigationBarWeb()),
});




/***/ }),

/***/ 89640:
/*!********************************************************************!*\
  !*** ./src/app/pages/get-started/get-started.page.scss?ngResource ***!
  \********************************************************************/
/***/ ((module) => {

module.exports = ":root {\n  --nc-color-nextgen-neutral-grey-50: #f1efef;\n  --nc-color-nextgen-white: #ffffff;\n  --nc-color-nextgen-blue: #0d152e;\n  --nc-color-nextgen-green: #00908d;\n  --nc-color-nextgen-black: #000000;\n  --nc-color-nextgen-grey-background: #c8d3da;\n  --nc-color-nextgen-grey: #92a2ac;\n  --nc-color-nextgen-stone-grey: #fafafa;\n  --nc-color-nextgen-error: #fc1055;\n  --nc-color-nextgen-neutral-grey: #414141;\n  --nc-color-nextgen-fibrant-green: #00bab6;\n  --nc-color-nextgen-warning: #ffd048;\n  --nc-color-nextgen-green-background: #e6f2f2;\n  --nc-color-nextgen-neutral-grey-400: #7a7a7a;\n  --nc-color-nextgen-neutral-grey-100: #eff3f5;\n  --nc-color-nextgen-status-error: #ba0c3f;\n  --nc-color-nextgen-status-error-background: #ffeff4;\n  --nc-color-nextgen-status-warning: #cba127;\n  --nc-color-nextgen-status-warning-background: #fff8e6;\n  --nc-color-nextgen-blue-100: #dfeff2;\n  --nc-color-nextgen-error-red-700: #f62459;\n  --nc-color-nextgen-blue-500: #006192;\n  --nc-color-nextgen-blue-400: #79cdec;\n  --nc-color-nextgen-red-500: #ff6592;\n  --nc-color-nextgen-secondary-blue-300: #13a0d3;\n  --lumi-white-color: #ffffff;\n  --lumi-primary-yellow-color: #fab600;\n}\n\n.ion-color-green {\n  --ion-color-base: var(--nc-color-nextgen-green);\n  --ion-color-base-rgb: var(--nc-color-nextgen-green);\n  --ion-color-contrast: var(--nc-color-nextgen-white);\n  --ion-color-contrast-rgb: var(--nc-color-nextgen-green);\n  --ion-color-shade: var(--nc-color-nextgen-green);\n  --ion-color-tint: var(--nc-color-nextgen-green);\n}\n\n.get-started-container nextcare-layout {\n  background: var(--lumi-primary-yellow-color);\n}\n\n.get-started-container .login {\n  text-align: right;\n}\n\n.get-started-container .login .login-text {\n  color: var(--lumi-white-color);\n}\n\n.get-started-container .next-care-logo {\n  display: flex;\n  align-items: center;\n  height: 80%;\n  justify-content: center;\n}\n\n.get-started-container .get-started {\n  text-align: center;\n  height: 57px;\n}\n\n:host ::ng-deep ion-title {\n  background-color: var(--lumi-primary-yellow-color) !important;\n}\n\n.version-app {\n  text-align: center;\n  color: var(--lumi-white-color);\n  padding-top: 1.8rem;\n}\n\n.lumi-primary {\n  background: var(--lumi-white-color);\n  color: var(--lumi-primary-yellow-color);\n  font-weight: bold;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXGNvbG9yLnNjc3MiLCJnZXQtc3RhcnRlZC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDQywyQ0FBQTtFQUNBLGlDQUFBO0VBQ0EsZ0NBQUE7RUFDQSxpQ0FBQTtFQUNBLGlDQUFBO0VBQ0EsMkNBQUE7RUFDQSxnQ0FBQTtFQUNBLHNDQUFBO0VBQ0EsaUNBQUE7RUFDQSx3Q0FBQTtFQUNBLHlDQUFBO0VBQ0EsbUNBQUE7RUFDQSw0Q0FBQTtFQUNBLDRDQUFBO0VBQ0EsNENBQUE7RUFDQSx3Q0FBQTtFQUNBLG1EQUFBO0VBQ0EsMENBQUE7RUFDQSxxREFBQTtFQUNBLG9DQUFBO0VBQ0EseUNBQUE7RUFDQSxvQ0FBQTtFQUNBLG9DQUFBO0VBQ0EsbUNBQUE7RUFDQSw4Q0FBQTtFQUVBLDJCQUFBO0VBQ0Esb0NBQUE7QUNBRDs7QURnQ0E7RUFDQywrQ0FBQTtFQUNBLG1EQUFBO0VBQ0EsbURBQUE7RUFDQSx1REFBQTtFQUNBLGdEQUFBO0VBQ0EsK0NBQUE7QUM3QkQ7O0FBbkNDO0VBQ0MsNENBQUE7QUFzQ0Y7O0FBcENDO0VBQ0MsaUJBQUE7QUFzQ0Y7O0FBckNFO0VBQ0MsOEJBQUE7QUF1Q0g7O0FBcENDO0VBQ0MsYUFBQTtFQUNBLG1CQUFBO0VBQ0EsV0FBQTtFQUNBLHVCQUFBO0FBc0NGOztBQWhDQztFQUNDLGtCQUFBO0VBQ0EsWUFBQTtBQWtDRjs7QUE5QkE7RUFDQyw2REFBQTtBQWlDRDs7QUEvQkE7RUFDQyxrQkFBQTtFQUNBLDhCQUFBO0VBQ0EsbUJBQUE7QUFrQ0Q7O0FBL0JBO0VBQ0MsbUNBQUE7RUFDQSx1Q0FBQTtFQUNBLGlCQUFBO0FBa0NEIiwiZmlsZSI6ImdldC1zdGFydGVkLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIjpyb290IHtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTUwOiAjZjFlZmVmO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi13aGl0ZTogI2ZmZmZmZjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZTogIzBkMTUyZTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW46ICMwMDkwOGQ7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWJsYWNrOiAjMDAwMDAwO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ncmV5LWJhY2tncm91bmQ6ICNjOGQzZGE7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWdyZXk6ICM5MmEyYWM7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0b25lLWdyZXk6ICNmYWZhZmE7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWVycm9yOiAjZmMxMDU1O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXk6ICM0MTQxNDE7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWZpYnJhbnQtZ3JlZW46ICMwMGJhYjY7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXdhcm5pbmc6ICNmZmQwNDg7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuLWJhY2tncm91bmQ6ICNlNmYyZjI7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS00MDA6ICM3YTdhN2E7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS0xMDA6ICNlZmYzZjU7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy1lcnJvcjogI2JhMGMzZjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yLWJhY2tncm91bmQ6ICNmZmVmZjQ7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy13YXJuaW5nOiAjY2JhMTI3O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtd2FybmluZy1iYWNrZ3JvdW5kOiAjZmZmOGU2O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlLTEwMDogI2RmZWZmMjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tZXJyb3ItcmVkLTcwMDogI2Y2MjQ1OTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZS01MDA6ICMwMDYxOTI7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWJsdWUtNDAwOiAjNzljZGVjO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1yZWQtNTAwOiAjZmY2NTkyO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zZWNvbmRhcnktYmx1ZS0zMDA6ICMxM2EwZDM7XHJcblxyXG5cdC0tbHVtaS13aGl0ZS1jb2xvcjogI2ZmZmZmZjtcclxuXHQtLWx1bWktcHJpbWFyeS15ZWxsb3ctY29sb3I6ICNmYWI2MDA7XHJcbn1cclxuJGNvbG9yLW5leHRnZW4tYmx1ZTogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlKTtcclxuJGNvbG9yLW5leHRnZW4tZ3JlZW46IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4pO1xyXG4kY29sb3ItbmV4dGdlbi13aGl0ZTogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi13aGl0ZSk7XHJcbiRjb2xvci1uZXh0Z2VuLWJsYWNrOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWJsYWNrKTtcclxuJGNvbG9yLW5leHRnZW4tZ3JleS1iYWNrZ3JvdW5kOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZXktYmFja2dyb3VuZCk7XHJcbiRjb2xvci1uZXh0Z2VuLWdyZXk6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JleSk7XHJcbiRjb2xvci1uZXh0Z2VuLXN0b25lLWdyZXk6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tc3RvbmUtZ3JleSk7XHJcbiRjb2xvci1uZXh0Z2VuLWVycm9yOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWVycm9yKTtcclxuJGNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5OiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleSk7XHJcbiRjb2xvci1uZXh0Z2VuLWZpYnJhbnQtZ3JlZW46IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZmlicmFudC1ncmVlbik7XHJcbiRjb2xvci1uZXh0Z2VuLXdhcm5pbmc6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4td2FybmluZyk7XHJcbiRjb2xvci1uZXh0Z2VuLWdyZWVuLWJhY2tncm91bmQ6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4tYmFja2dyb3VuZCk7XHJcbiRjb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS01MDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNTApO1xyXG4kY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNDAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS00MDApO1xyXG4kY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktMTAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS0xMDApO1xyXG4kY29sb3ItbmV4dGdlbi1zdGF0dXMtZXJyb3I6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yKTtcclxuJGNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yLWJhY2tncm91bmQ6IHZhcihcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yLWJhY2tncm91bmRcclxuKTtcclxuJGNvbG9yLW5leHRnZW4tc3RhdHVzLXdhcm5pbmc6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLXdhcm5pbmcpO1xyXG4kY29sb3ItbmV4dGdlbi1zdGF0dXMtd2FybmluZy1iYWNrZ3JvdW5kOiB2YXIoXHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy13YXJuaW5nLWJhY2tncm91bmRcclxuKTtcclxuJGNvbG9yLW5leHRnZW4tYmx1ZS0xMDA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZS0xMDApO1xyXG4kY29sb3ItbmV4dGdlbi1lcnJvci1yZWQtNzAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWVycm9yLXJlZC03MDApO1xyXG4kY29sb3ItbmV4dGdlbi1ibHVlLTUwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlLTUwMCk7XHJcbiRjb2xvci1uZXh0Z2VuLWJsdWUtNDAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWJsdWUtNDAwKTtcclxuJGNvbG9yLW5leHRnZW4tcmVkLTUwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1yZWQtNTAwKTtcclxuJGNvbG9yLW5leHRnZW4tc2Vjb25kYXJ5LWJsdWUtMzAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXNlY29uZGFyeS1ibHVlLTMwMCk7XHJcblxyXG4uaW9uLWNvbG9yLWdyZWVuIHtcclxuXHQtLWlvbi1jb2xvci1iYXNlOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuKTtcclxuXHQtLWlvbi1jb2xvci1iYXNlLXJnYjogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbik7XHJcblx0LS1pb24tY29sb3ItY29udHJhc3Q6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4td2hpdGUpO1xyXG5cdC0taW9uLWNvbG9yLWNvbnRyYXN0LXJnYjogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbik7XHJcblx0LS1pb24tY29sb3Itc2hhZGU6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4pO1xyXG5cdC0taW9uLWNvbG9yLXRpbnQ6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4pO1xyXG59XHJcbiIsIkBpbXBvcnQgXCIuLi8uLi8uLi9jb2xvci5zY3NzXCI7XHJcbi5nZXQtc3RhcnRlZC1jb250YWluZXIge1xyXG5cdG5leHRjYXJlLWxheW91dCB7XHJcblx0XHRiYWNrZ3JvdW5kOiB2YXIoLS1sdW1pLXByaW1hcnkteWVsbG93LWNvbG9yKTtcclxuXHR9XHJcblx0LmxvZ2luIHtcclxuXHRcdHRleHQtYWxpZ246IHJpZ2h0O1xyXG5cdFx0LmxvZ2luLXRleHQge1xyXG5cdFx0XHRjb2xvcjogdmFyKC0tbHVtaS13aGl0ZS1jb2xvcik7XHJcblx0XHR9XHJcblx0fVxyXG5cdC5uZXh0LWNhcmUtbG9nbyB7XHJcblx0XHRkaXNwbGF5OiBmbGV4O1xyXG5cdFx0YWxpZ24taXRlbXM6IGNlbnRlcjtcclxuXHRcdGhlaWdodDogODAlO1xyXG5cdFx0anVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcblx0XHRpbWcge1xyXG5cdFx0XHQvLyBoZWlnaHQ6IDM0cHg7XHJcblx0XHRcdC8vIHdpZHRoOiAxOTBweDtcclxuXHRcdH1cclxuXHR9XHJcblx0LmdldC1zdGFydGVkIHtcclxuXHRcdHRleHQtYWxpZ246IGNlbnRlcjtcclxuXHRcdGhlaWdodDogNTdweDtcclxuXHR9XHJcbn1cclxuXHJcbjpob3N0IDo6bmctZGVlcCBpb24tdGl0bGUge1xyXG5cdGJhY2tncm91bmQtY29sb3I6IHZhcigtLWx1bWktcHJpbWFyeS15ZWxsb3ctY29sb3IpICFpbXBvcnRhbnQ7XHJcbn1cclxuLnZlcnNpb24tYXBwIHtcclxuXHR0ZXh0LWFsaWduOiBjZW50ZXI7XHJcblx0Y29sb3I6IHZhcigtLWx1bWktd2hpdGUtY29sb3IpO1xyXG5cdHBhZGRpbmctdG9wOiAxLjhyZW07XHJcbn1cclxuXHJcbi5sdW1pLXByaW1hcnkge1xyXG5cdGJhY2tncm91bmQ6IHZhcigtLWx1bWktd2hpdGUtY29sb3IpO1xyXG5cdGNvbG9yOiB2YXIoLS1sdW1pLXByaW1hcnkteWVsbG93LWNvbG9yKTtcclxuXHRmb250LXdlaWdodDogYm9sZDtcclxufVxyXG4iXX0= */";

/***/ }),

/***/ 79996:
/*!********************************************************************!*\
  !*** ./src/app/pages/get-started/get-started.page.html?ngResource ***!
  \********************************************************************/
/***/ ((module) => {

module.exports = "<div class=\"get-started-container\">\r\n\t<nextcare-layout>\r\n\t\t<ng-template header>\r\n\t\t\t<div class=\"login\">\r\n\t\t\t\t<div class=\"login-text h5 bold\" (click)=\"redirectToSignIn()\">{{ 'getStarted.login' | translate }}</div>\r\n\t\t\t</div>\r\n\t\t</ng-template>\r\n\t\t<ng-template body>\r\n\t\t\t<div class=\"next-care-logo\">\r\n\t\t\t\t<img src=\"../../../assets/icon/logo-white.svg\" />\r\n\t\t\t</div>\r\n\t\t\t<div class=\"bottom-section\">\r\n\t\t\t\t<!-- <div class=\"get-started\">\r\n          <button class=\"btn btn-large primary bold\" (click)=\"redirectToSelectLanguage()\">{{ 'getStarted.getStarted' |\r\n            translate }}</button>\r\n        </div> -->\r\n\t\t\t\t<div class=\"iphone get-started\">\r\n\t\t\t\t\t<button class=\"btn btn-large primary bold lumi-primary\" (click)=\"redirectToSelectLanguage()\">\r\n\t\t\t\t\t\t<div class=\"lumi-primary animate__animated animate__slideInRight\" *ngIf=\"currentLabel\">{{ labels[currentIndex] }}</div>\r\n\t\t\t\t\t</button>\r\n\t\t\t\t</div>\r\n\t\t\t\t<p class=\"version-app body-xs\">{{'home.appversion' | translate}} {{versionApp}}</p>\r\n\t\t\t</div>\r\n\t\t</ng-template>\r\n\t</nextcare-layout>\r\n</div>\r\n";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_get-started_get-started_module_ts.js.map