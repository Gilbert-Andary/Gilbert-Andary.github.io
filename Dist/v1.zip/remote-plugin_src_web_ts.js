"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["remote-plugin_src_web_ts"],{

/***/ 65555:
/*!**********************************!*\
  !*** ./remote-plugin/src/web.ts ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RemotePluginWeb": () => (/* binding */ RemotePluginWeb)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _capacitor_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @capacitor/core */ 39479);


class RemotePluginWeb extends _capacitor_core__WEBPACK_IMPORTED_MODULE_0__.WebPlugin {
    echo(options) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__awaiter)(this, void 0, void 0, function* () {
            console.log('ECHO', options);
            return options;
        });
    }
    logCrashEvent(_options) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__awaiter)(this, void 0, void 0, function* () {
            console.log('log event ');
        });
    }
    setCustomKeysValuesCrashlytics(_options) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__awaiter)(this, void 0, void 0, function* () {
            console.log('set custom key and value ');
        });
    }
    setUserIdCrashlytics(_options) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__awaiter)(this, void 0, void 0, function* () {
            console.log('set user id ');
        });
    }
}


/***/ })

}]);
//# sourceMappingURL=remote-plugin_src_web_ts.js.map