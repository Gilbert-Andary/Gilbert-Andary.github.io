"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_forgot-password_forgot-password_module_ts"],{

/***/ 85490:
/*!*****************************************************************************************************************!*\
  !*** ./src/app/pages/forgot-password/forgot-password-check-email/forgot-password-check-email-routing.module.ts ***!
  \*****************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ForgotPasswordCheckEmailPageRoutingModule": () => (/* binding */ ForgotPasswordCheckEmailPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _forgot_password_check_email_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./forgot-password-check-email.page */ 44864);




const routes = [
    {
        path: '',
        component: _forgot_password_check_email_page__WEBPACK_IMPORTED_MODULE_0__.ForgotPasswordCheckEmailPage
    },
];
let ForgotPasswordCheckEmailPageRoutingModule = class ForgotPasswordCheckEmailPageRoutingModule {
};
ForgotPasswordCheckEmailPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
    })
], ForgotPasswordCheckEmailPageRoutingModule);



/***/ }),

/***/ 57025:
/*!*********************************************************************************************************!*\
  !*** ./src/app/pages/forgot-password/forgot-password-check-email/forgot-password-check-email.module.ts ***!
  \*********************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ForgotPasswordCheckEmailModule": () => (/* binding */ ForgotPasswordCheckEmailModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _forgot_password_check_email_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./forgot-password-check-email.page */ 44864);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/shared/shared.module */ 44466);
/* harmony import */ var _forgot_password_check_email_routing_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./forgot-password-check-email-routing.module */ 85490);








let ForgotPasswordCheckEmailModule = class ForgotPasswordCheckEmailModule {
};
ForgotPasswordCheckEmailModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        declarations: [_forgot_password_check_email_page__WEBPACK_IMPORTED_MODULE_0__.ForgotPasswordCheckEmailPage],
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule,
            _forgot_password_check_email_routing_module__WEBPACK_IMPORTED_MODULE_2__.ForgotPasswordCheckEmailPageRoutingModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonicModule,
            src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_1__.SharedModule,
        ],
    })
], ForgotPasswordCheckEmailModule);



/***/ }),

/***/ 44864:
/*!*******************************************************************************************************!*\
  !*** ./src/app/pages/forgot-password/forgot-password-check-email/forgot-password-check-email.page.ts ***!
  \*******************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ForgotPasswordCheckEmailPage": () => (/* binding */ ForgotPasswordCheckEmailPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _forgot_password_check_email_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./forgot-password-check-email.page.html?ngResource */ 83425);
/* harmony import */ var _forgot_password_check_email_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./forgot-password-check-email.page.scss?ngResource */ 60293);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/shared/data/enum/screen */ 68302);
/* harmony import */ var _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ionic/storage-angular */ 80190);
/* harmony import */ var src_app_shared_data_enum_platform__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/shared/data/enum/platform */ 8760);
/* harmony import */ var src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/shared/data/constants */ 74676);
/* harmony import */ var src_app_shared_data_enum_login_type__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/shared/data/enum/login-type */ 3674);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @environments/environment */ 92340);
/* harmony import */ var src_app_service_signup_signup_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/service/signup/signup.service */ 71234);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ionic/angular */ 93819);













let ForgotPasswordCheckEmailPage = class ForgotPasswordCheckEmailPage {
    constructor(router, storage, route, signupService, platform) {
        this.router = router;
        this.storage = storage;
        this.route = route;
        this.signupService = signupService;
        this.platform = platform;
        this.isMobileApp = false;
        this.time = 30;
        this.textTimeInterval = '';
        this.textResendLink = 'forgotPassword.resendLink';
        this.params = this.route.snapshot.queryParams;
    }
    loadPlatformInformation() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__awaiter)(this, void 0, void 0, function* () {
            const platform = yield this.storage.get(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_4__.Constants.PLATFORM);
            if (platform == src_app_shared_data_enum_platform__WEBPACK_IMPORTED_MODULE_3__.PlatformEnum.Mobile) {
                this.isMobileApp = true;
            }
        });
    }
    ngOnInit() { }
    ionViewDidEnter() {
        this.subscription = this.platform.backButton.subscribeWithPriority(9999, () => {
            this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__.Screens.ForgotPassword]);
        });
    }
    ionViewWillLeave() {
        this.subscription.unsubscribe();
    }
    resendLink() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__awaiter)(this, void 0, void 0, function* () {
            if (this.time - 30 >= 0) {
                this.textResendLink = '';
                const myInterval = setInterval(() => {
                    this.time--;
                    this.textTimeInterval = this.time + 's';
                    if (this.time == 0) {
                        this.time = 30;
                        clearInterval(myInterval);
                        this.textTimeInterval = '';
                        this.textResendLink = 'forgotPassword.resendLink';
                    }
                }, 1000);
                // this.getResetKeyPassword();
                const userId = yield this.storage.get(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_4__.Constants.USERID);
                this.signupService.sendOTP({
                    login: this.params.email,
                    appID: _environments_environment__WEBPACK_IMPORTED_MODULE_6__.environment.AppID,
                    type: src_app_shared_data_enum_login_type__WEBPACK_IMPORTED_MODULE_5__.LoginType.Email,
                    userId,
                }).subscribe();
            }
        });
    }
    onClose() {
        this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__.Screens.SignIn]);
    }
    redirectToNeedHelp() {
        this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__.Screens.InquiryBeforeLogin], { queryParams: { redirectTo: 'check-mail' } });
    }
    openMyMail() {
        // InsuranceCard.handleOpenMail();
        this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__.Screens.SetNewPassword], {
            queryParams: {
                type: src_app_shared_data_enum_login_type__WEBPACK_IMPORTED_MODULE_5__.LoginType.Email,
                login: this.params.email,
                redirectTo: src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__.Screens.SignIn,
                message: 'otpPhoneNumber.verify-email-desc',
                cancelRequest: true,
            }
        });
    }
};
ForgotPasswordCheckEmailPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_9__.Router },
    { type: _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_10__.Storage },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_9__.ActivatedRoute },
    { type: src_app_service_signup_signup_service__WEBPACK_IMPORTED_MODULE_7__.SignupService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_11__.Platform }
];
ForgotPasswordCheckEmailPage = (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_12__.Component)({
        selector: 'app-forgot-password-check-email',
        template: _forgot_password_check_email_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_forgot_password_check_email_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], ForgotPasswordCheckEmailPage);



/***/ }),

/***/ 6177:
/*!*************************************************************************!*\
  !*** ./src/app/pages/forgot-password/forgot-password-routing.module.ts ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ForgotPasswordPageRoutingModule": () => (/* binding */ ForgotPasswordPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _forgot_password_check_email_forgot_password_check_email_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./forgot-password-check-email/forgot-password-check-email.page */ 44864);
/* harmony import */ var _forgot_password_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./forgot-password.page */ 8670);





const routes = [
    {
        path: '',
        component: _forgot_password_page__WEBPACK_IMPORTED_MODULE_1__.ForgotPasswordPage
    },
    {
        path: 'check-your-email',
        component: _forgot_password_check_email_forgot_password_check_email_page__WEBPACK_IMPORTED_MODULE_0__.ForgotPasswordCheckEmailPage
    },
];
let ForgotPasswordPageRoutingModule = class ForgotPasswordPageRoutingModule {
};
ForgotPasswordPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule]
    })
], ForgotPasswordPageRoutingModule);



/***/ }),

/***/ 65638:
/*!*****************************************************************!*\
  !*** ./src/app/pages/forgot-password/forgot-password.module.ts ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ForgotPasswordPageModule": () => (/* binding */ ForgotPasswordPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _forgot_password_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./forgot-password.page */ 8670);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/shared/shared.module */ 44466);
/* harmony import */ var _forgot_password_routing_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./forgot-password-routing.module */ 6177);
/* harmony import */ var _forgot_password_check_email_forgot_password_check_email_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./forgot-password-check-email/forgot-password-check-email.module */ 57025);









let ForgotPasswordPageModule = class ForgotPasswordPageModule {
};
ForgotPasswordPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.NgModule)({
        declarations: [_forgot_password_page__WEBPACK_IMPORTED_MODULE_0__.ForgotPasswordPage],
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_6__.CommonModule,
            _forgot_password_routing_module__WEBPACK_IMPORTED_MODULE_2__.ForgotPasswordPageRoutingModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.IonicModule,
            src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_1__.SharedModule,
            _forgot_password_check_email_forgot_password_check_email_module__WEBPACK_IMPORTED_MODULE_3__.ForgotPasswordCheckEmailModule
        ],
    })
], ForgotPasswordPageModule);



/***/ }),

/***/ 8670:
/*!***************************************************************!*\
  !*** ./src/app/pages/forgot-password/forgot-password.page.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ForgotPasswordPage": () => (/* binding */ ForgotPasswordPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _forgot_password_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./forgot-password.page.html?ngResource */ 36688);
/* harmony import */ var _forgot_password_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./forgot-password.page.scss?ngResource */ 72653);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @ionic/storage-angular */ 80190);
/* harmony import */ var src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/shared/data/enum/screen */ 68302);
/* harmony import */ var src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/shared/data/constants */ 74676);
/* harmony import */ var src_app_shared_data_enum_platform__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/shared/data/enum/platform */ 8760);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var src_app_model_control_control_model__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/model/control/control.model */ 45482);
/* harmony import */ var _awesome_cordova_plugins_firebase_analytics_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @awesome-cordova-plugins/firebase-analytics/ngx */ 48852);
/* harmony import */ var src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/shared/data/enum/event */ 38570);
/* harmony import */ var _awesome_cordova_plugins_clevertap_ngx__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @awesome-cordova-plugins/clevertap/ngx */ 45363);
/* harmony import */ var src_app_service_signup_signup_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/service/signup/signup.service */ 71234);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @environments/environment */ 92340);
/* harmony import */ var src_app_shared_data_enum_login_type__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/app/shared/data/enum/login-type */ 3674);
/* harmony import */ var src_app_shared_components_nextgen_dialog_nextgen_dialog_service__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! src/app/shared/components/nextgen-dialog/nextgen-dialog.service */ 96485);
/* harmony import */ var src_app_shared_components_popup_message_popup_message_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! src/app/shared/components/popup-message/popup-message.component */ 18290);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/common/http */ 28784);





















let ForgotPasswordPage = class ForgotPasswordPage {
    constructor(router, storage, navCtrl, fb, firebaseAnalytics, clevertap, route, signupService, dialogService, platform) {
        this.router = router;
        this.storage = storage;
        this.navCtrl = navCtrl;
        this.fb = fb;
        this.firebaseAnalytics = firebaseAnalytics;
        this.clevertap = clevertap;
        this.route = route;
        this.signupService = signupService;
        this.dialogService = dialogService;
        this.platform = platform;
        this.TYPE = src_app_model_control_control_model__WEBPACK_IMPORTED_MODULE_5__.ControlType; //type input control
        this.showPassword = false; //status password(hide=false/show)
        this.isMobileApp = false;
        this.secondIcon = 'uil uil-eye-slash';
        // Build formGroup
        this.forgotPasswordForm = this.fb.group({
            email: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_14__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_14__.Validators.pattern(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/)]],
        });
        this.loadPlatformInformation();
        this.params = this.route.snapshot.queryParams;
    }
    ngOnInit() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__awaiter)(this, void 0, void 0, function* () {
        });
    }
    ionViewDidEnter() {
        this.subscription = this.platform.backButton.subscribeWithPriority(9999, () => {
            this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__.Screens.SignIn]);
        });
    }
    ionViewWillLeave() {
        this.subscription.unsubscribe();
    }
    loadPlatformInformation() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__awaiter)(this, void 0, void 0, function* () {
            const platform = yield this.storage.get(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_3__.Constants.PLATFORM);
            if (platform == src_app_shared_data_enum_platform__WEBPACK_IMPORTED_MODULE_4__.PlatformEnum.Mobile) {
                this.isMobileApp = true;
            }
        });
    }
    sendResetLink() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__awaiter)(this, void 0, void 0, function* () {
            const headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_16__.HttpHeaders({
                customErrorAlert: 'true',
            });
            const userId = yield this.storage.get(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_3__.Constants.USERID);
            this.signupService.sendOTP({
                login: this.forgotPasswordForm.controls['email'].value,
                appID: _environments_environment__WEBPACK_IMPORTED_MODULE_10__.environment.AppID,
                type: src_app_shared_data_enum_login_type__WEBPACK_IMPORTED_MODULE_11__.LoginType.Email,
                userId,
            }, headers).subscribe((res) => {
                if (res) {
                    this.firebaseAnalytics.logEvent(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_7__.GA4Event.PasswordChangeCompleted, {});
                    this.clevertap.recordEventWithName(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_7__.GA4Event.PasswordChangeCompleted);
                    // Save Signup Information
                    this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__.Screens.ForgotPassword + '/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__.Screens.ForgotPasswordCheckMail], {
                        queryParams: Object.assign({}, this.forgotPasswordForm.value)
                    });
                }
            }, (_error) => {
                // console log here.
                if (_error.status == 401) {
                    this.dialogService.open(src_app_shared_components_popup_message_popup_message_component__WEBPACK_IMPORTED_MODULE_13__.PopupMessageComponent, {
                        data: {
                            content: 'forgotPassword.error401',
                            textYes: 'button.ok',
                        },
                        // title: 'Message ',
                        title: 'title.wrongTitleMessage',
                        position: 'middle',
                        width: '90%',
                    });
                }
                else {
                    this.dialogService.open(src_app_shared_components_popup_message_popup_message_component__WEBPACK_IMPORTED_MODULE_13__.PopupMessageComponent, {
                        data: {
                            content: _error.error.message,
                            textYes: 'button.ok',
                        },
                        // title: 'Message ',
                        title: 'title.wrongTitleMessage',
                        position: 'middle',
                        width: '90%',
                    });
                }
            });
        });
    }
    onBack() {
        this.navCtrl.back();
    }
    redirectToNeedHelp() {
        this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__.Screens.InquiryBeforeLogin], { queryParams: { redirectTo: 'forgot-passwords' } });
    }
    onPaste(event) {
        const clipboardData = event.clipboardData;
        let content = clipboardData.getData('text');
        if (content.indexOf(' ') >= 0)
            content = content.replace(/\s/g, '');
        this.forgotPasswordForm.controls['email'].setValue(content);
        this.forgotPasswordForm.controls['email'].updateValueAndValidity();
        event.preventDefault();
    }
    onInput() {
        if (this.email.indexOf(' ') >= 0) {
            this.email = this.email.replace(/\s/g, '');
        }
    }
};
ForgotPasswordPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_17__.Router },
    { type: _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_18__.Storage },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_19__.NavController },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_14__.FormBuilder },
    { type: _awesome_cordova_plugins_firebase_analytics_ngx__WEBPACK_IMPORTED_MODULE_6__.FirebaseAnalytics },
    { type: _awesome_cordova_plugins_clevertap_ngx__WEBPACK_IMPORTED_MODULE_8__.CleverTap },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_17__.ActivatedRoute },
    { type: src_app_service_signup_signup_service__WEBPACK_IMPORTED_MODULE_9__.SignupService },
    { type: src_app_shared_components_nextgen_dialog_nextgen_dialog_service__WEBPACK_IMPORTED_MODULE_12__.DialogService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_19__.Platform }
];
ForgotPasswordPage = (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_20__.Component)({
        selector: 'app-forgot-password',
        template: _forgot_password_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_forgot_password_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], ForgotPasswordPage);



/***/ }),

/***/ 60293:
/*!********************************************************************************************************************!*\
  !*** ./src/app/pages/forgot-password/forgot-password-check-email/forgot-password-check-email.page.scss?ngResource ***!
  \********************************************************************************************************************/
/***/ ((module) => {

module.exports = ":root {\n  --nc-color-nextgen-neutral-grey-50: #f1efef;\n  --nc-color-nextgen-white: #ffffff;\n  --nc-color-nextgen-blue: #0d152e;\n  --nc-color-nextgen-green: #00908d;\n  --nc-color-nextgen-black: #000000;\n  --nc-color-nextgen-grey-background: #c8d3da;\n  --nc-color-nextgen-grey: #92a2ac;\n  --nc-color-nextgen-stone-grey: #fafafa;\n  --nc-color-nextgen-error: #fc1055;\n  --nc-color-nextgen-neutral-grey: #414141;\n  --nc-color-nextgen-fibrant-green: #00bab6;\n  --nc-color-nextgen-warning: #ffd048;\n  --nc-color-nextgen-green-background: #e6f2f2;\n  --nc-color-nextgen-neutral-grey-400: #7a7a7a;\n  --nc-color-nextgen-neutral-grey-100: #eff3f5;\n  --nc-color-nextgen-status-error: #ba0c3f;\n  --nc-color-nextgen-status-error-background: #ffeff4;\n  --nc-color-nextgen-status-warning: #cba127;\n  --nc-color-nextgen-status-warning-background: #fff8e6;\n  --nc-color-nextgen-blue-100: #dfeff2;\n  --nc-color-nextgen-error-red-700: #f62459;\n  --nc-color-nextgen-blue-500: #006192;\n  --nc-color-nextgen-blue-400: #79cdec;\n  --nc-color-nextgen-red-500: #ff6592;\n  --nc-color-nextgen-secondary-blue-300: #13a0d3;\n  --lumi-white-color: #ffffff;\n  --lumi-primary-yellow-color: #fab600;\n}\n\n.ion-color-green {\n  --ion-color-base: var(--nc-color-nextgen-green);\n  --ion-color-base-rgb: var(--nc-color-nextgen-green);\n  --ion-color-contrast: var(--nc-color-nextgen-white);\n  --ion-color-contrast-rgb: var(--nc-color-nextgen-green);\n  --ion-color-shade: var(--nc-color-nextgen-green);\n  --ion-color-tint: var(--nc-color-nextgen-green);\n}\n\n.forgot-password-container {\n  background: var(--nc-color-nextgen-neutral-grey-50);\n}\n\n.need-help-text {\n  color: var(--nc-color-nextgen-green);\n  float: right !important;\n}\n\n.body-content {\n  padding-top: 6rem;\n  min-height: 85%;\n  text-align: center;\n}\n\n.check-your-mail {\n  color: var(--nc-color-nextgen-blue);\n  padding-top: 1.5rem;\n}\n\n.data-email {\n  padding-top: 2rem;\n  padding-bottom: 2rem;\n  color: var(--nc-color-nextgen-neutral-grey);\n}\n\n.text-receive {\n  color: var(--nc-color-nextgen-neutral-grey);\n}\n\n.receive-the-link {\n  text-align: center;\n}\n\n.text-link {\n  color: var(--nc-color-nextgen-green) !important;\n}\n\n.toolbar-title {\n  display: flex;\n  justify-content: space-between;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFxjb2xvci5zY3NzIiwiZm9yZ290LXBhc3N3b3JkLWNoZWNrLWVtYWlsLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNDLDJDQUFBO0VBQ0EsaUNBQUE7RUFDQSxnQ0FBQTtFQUNBLGlDQUFBO0VBQ0EsaUNBQUE7RUFDQSwyQ0FBQTtFQUNBLGdDQUFBO0VBQ0Esc0NBQUE7RUFDQSxpQ0FBQTtFQUNBLHdDQUFBO0VBQ0EseUNBQUE7RUFDQSxtQ0FBQTtFQUNBLDRDQUFBO0VBQ0EsNENBQUE7RUFDQSw0Q0FBQTtFQUNBLHdDQUFBO0VBQ0EsbURBQUE7RUFDQSwwQ0FBQTtFQUNBLHFEQUFBO0VBQ0Esb0NBQUE7RUFDQSx5Q0FBQTtFQUNBLG9DQUFBO0VBQ0Esb0NBQUE7RUFDQSxtQ0FBQTtFQUNBLDhDQUFBO0VBRUEsMkJBQUE7RUFDQSxvQ0FBQTtBQ0FEOztBRGdDQTtFQUNDLCtDQUFBO0VBQ0EsbURBQUE7RUFDQSxtREFBQTtFQUNBLHVEQUFBO0VBQ0EsZ0RBQUE7RUFDQSwrQ0FBQTtBQzdCRDs7QUFuQ0E7RUFDSSxtRER1QzRCO0FDRGhDOztBQW5DQTtFQUNJLG9DRHdCa0I7RUN2QmxCLHVCQUFBO0FBc0NKOztBQW5DQTtFQUNJLGlCQUFBO0VBQ0EsZUFBQTtFQUNBLGtCQUFBO0FBc0NKOztBQW5DQTtFQUNJLG1DRFlpQjtFQ1hqQixtQkFBQTtBQXNDSjs7QUFuQ0E7RUFDSSxpQkFBQTtFQUNBLG9CQUFBO0VBQ0EsMkNEYXlCO0FDeUI3Qjs7QUFuQ0E7RUFDSSwyQ0RTeUI7QUM2QjdCOztBQW5DQTtFQUNJLGtCQUFBO0FBc0NKOztBQW5DQTtFQUNJLCtDQUFBO0FBc0NKOztBQXBDQTtFQUNJLGFBQUE7RUFDQSw4QkFBQTtBQXVDSiIsImZpbGUiOiJmb3Jnb3QtcGFzc3dvcmQtY2hlY2stZW1haWwucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiOnJvb3Qge1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNTA6ICNmMWVmZWY7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXdoaXRlOiAjZmZmZmZmO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlOiAjMGQxNTJlO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbjogIzAwOTA4ZDtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tYmxhY2s6ICMwMDAwMDA7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWdyZXktYmFja2dyb3VuZDogI2M4ZDNkYTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tZ3JleTogIzkyYTJhYztcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc3RvbmUtZ3JleTogI2ZhZmFmYTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tZXJyb3I6ICNmYzEwNTU7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleTogIzQxNDE0MTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tZmlicmFudC1ncmVlbjogIzAwYmFiNjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4td2FybmluZzogI2ZmZDA0ODtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4tYmFja2dyb3VuZDogI2U2ZjJmMjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTQwMDogIzdhN2E3YTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTEwMDogI2VmZjNmNTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yOiAjYmEwYzNmO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtZXJyb3ItYmFja2dyb3VuZDogI2ZmZWZmNDtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLXdhcm5pbmc6ICNjYmExMjc7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy13YXJuaW5nLWJhY2tncm91bmQ6ICNmZmY4ZTY7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWJsdWUtMTAwOiAjZGZlZmYyO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1lcnJvci1yZWQtNzAwOiAjZjYyNDU5O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlLTUwMDogIzAwNjE5MjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZS00MDA6ICM3OWNkZWM7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXJlZC01MDA6ICNmZjY1OTI7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXNlY29uZGFyeS1ibHVlLTMwMDogIzEzYTBkMztcclxuXHJcblx0LS1sdW1pLXdoaXRlLWNvbG9yOiAjZmZmZmZmO1xyXG5cdC0tbHVtaS1wcmltYXJ5LXllbGxvdy1jb2xvcjogI2ZhYjYwMDtcclxufVxyXG4kY29sb3ItbmV4dGdlbi1ibHVlOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWJsdWUpO1xyXG4kY29sb3ItbmV4dGdlbi1ncmVlbjogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbik7XHJcbiRjb2xvci1uZXh0Z2VuLXdoaXRlOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXdoaXRlKTtcclxuJGNvbG9yLW5leHRnZW4tYmxhY2s6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tYmxhY2spO1xyXG4kY29sb3ItbmV4dGdlbi1ncmV5LWJhY2tncm91bmQ6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JleS1iYWNrZ3JvdW5kKTtcclxuJGNvbG9yLW5leHRnZW4tZ3JleTogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmV5KTtcclxuJGNvbG9yLW5leHRnZW4tc3RvbmUtZ3JleTogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1zdG9uZS1ncmV5KTtcclxuJGNvbG9yLW5leHRnZW4tZXJyb3I6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZXJyb3IpO1xyXG4kY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXk6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5KTtcclxuJGNvbG9yLW5leHRnZW4tZmlicmFudC1ncmVlbjogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1maWJyYW50LWdyZWVuKTtcclxuJGNvbG9yLW5leHRnZW4td2FybmluZzogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi13YXJuaW5nKTtcclxuJGNvbG9yLW5leHRnZW4tZ3JlZW4tYmFja2dyb3VuZDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbi1iYWNrZ3JvdW5kKTtcclxuJGNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTUwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS01MCk7XHJcbiRjb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS00MDA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTQwMCk7XHJcbiRjb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS0xMDA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTEwMCk7XHJcbiRjb2xvci1uZXh0Z2VuLXN0YXR1cy1lcnJvcjogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtZXJyb3IpO1xyXG4kY29sb3ItbmV4dGdlbi1zdGF0dXMtZXJyb3ItYmFja2dyb3VuZDogdmFyKFxyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtZXJyb3ItYmFja2dyb3VuZFxyXG4pO1xyXG4kY29sb3ItbmV4dGdlbi1zdGF0dXMtd2FybmluZzogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtd2FybmluZyk7XHJcbiRjb2xvci1uZXh0Z2VuLXN0YXR1cy13YXJuaW5nLWJhY2tncm91bmQ6IHZhcihcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLXdhcm5pbmctYmFja2dyb3VuZFxyXG4pO1xyXG4kY29sb3ItbmV4dGdlbi1ibHVlLTEwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlLTEwMCk7XHJcbiRjb2xvci1uZXh0Z2VuLWVycm9yLXJlZC03MDA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZXJyb3ItcmVkLTcwMCk7XHJcbiRjb2xvci1uZXh0Z2VuLWJsdWUtNTAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWJsdWUtNTAwKTtcclxuJGNvbG9yLW5leHRnZW4tYmx1ZS00MDA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZS00MDApO1xyXG4kY29sb3ItbmV4dGdlbi1yZWQtNTAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXJlZC01MDApO1xyXG4kY29sb3ItbmV4dGdlbi1zZWNvbmRhcnktYmx1ZS0zMDA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tc2Vjb25kYXJ5LWJsdWUtMzAwKTtcclxuXHJcbi5pb24tY29sb3ItZ3JlZW4ge1xyXG5cdC0taW9uLWNvbG9yLWJhc2U6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4pO1xyXG5cdC0taW9uLWNvbG9yLWJhc2UtcmdiOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuKTtcclxuXHQtLWlvbi1jb2xvci1jb250cmFzdDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi13aGl0ZSk7XHJcblx0LS1pb24tY29sb3ItY29udHJhc3QtcmdiOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuKTtcclxuXHQtLWlvbi1jb2xvci1zaGFkZTogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbik7XHJcblx0LS1pb24tY29sb3ItdGludDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbik7XHJcbn1cclxuIiwiQGltcG9ydCBcIi4uLy4uLy4uLy4uL2NvbG9yLnNjc3NcIjtcclxuXHJcbi5mb3Jnb3QtcGFzc3dvcmQtY29udGFpbmVyIHtcclxuICAgIGJhY2tncm91bmQ6ICRjb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS01MDtcclxufVxyXG5cclxuLm5lZWQtaGVscC10ZXh0IHtcclxuICAgIGNvbG9yOiAkY29sb3ItbmV4dGdlbi1ncmVlbjtcclxuICAgIGZsb2F0OiByaWdodCAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4uYm9keS1jb250ZW50IHtcclxuICAgIHBhZGRpbmctdG9wOiA2cmVtO1xyXG4gICAgbWluLWhlaWdodDogODUlO1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyOyBcclxuICBcclxufVxyXG4uY2hlY2steW91ci1tYWlsIHtcclxuICAgIGNvbG9yOiAkY29sb3ItbmV4dGdlbi1ibHVlO1xyXG4gICAgcGFkZGluZy10b3A6IDEuNXJlbTtcclxufVxyXG5cclxuLmRhdGEtZW1haWwge1xyXG4gICAgcGFkZGluZy10b3A6IDJyZW07XHJcbiAgICBwYWRkaW5nLWJvdHRvbTogMnJlbTtcclxuICAgIGNvbG9yOiAkY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXk7XHJcbn1cclxuXHJcbi50ZXh0LXJlY2VpdmUge1xyXG4gICAgY29sb3I6ICRjb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleTtcclxufVxyXG5cclxuLnJlY2VpdmUtdGhlLWxpbmsge1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG59XHJcblxyXG4udGV4dC1saW5rIHtcclxuICAgIGNvbG9yOiAkY29sb3ItbmV4dGdlbi1ncmVlbiAgIWltcG9ydGFudDtcclxufVxyXG4udG9vbGJhci10aXRsZXtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6c3BhY2UtYmV0d2VlbjtcclxufSJdfQ== */";

/***/ }),

/***/ 72653:
/*!****************************************************************************!*\
  !*** ./src/app/pages/forgot-password/forgot-password.page.scss?ngResource ***!
  \****************************************************************************/
/***/ ((module) => {

module.exports = ":root {\n  --nc-color-nextgen-neutral-grey-50: #f1efef;\n  --nc-color-nextgen-white: #ffffff;\n  --nc-color-nextgen-blue: #0d152e;\n  --nc-color-nextgen-green: #00908d;\n  --nc-color-nextgen-black: #000000;\n  --nc-color-nextgen-grey-background: #c8d3da;\n  --nc-color-nextgen-grey: #92a2ac;\n  --nc-color-nextgen-stone-grey: #fafafa;\n  --nc-color-nextgen-error: #fc1055;\n  --nc-color-nextgen-neutral-grey: #414141;\n  --nc-color-nextgen-fibrant-green: #00bab6;\n  --nc-color-nextgen-warning: #ffd048;\n  --nc-color-nextgen-green-background: #e6f2f2;\n  --nc-color-nextgen-neutral-grey-400: #7a7a7a;\n  --nc-color-nextgen-neutral-grey-100: #eff3f5;\n  --nc-color-nextgen-status-error: #ba0c3f;\n  --nc-color-nextgen-status-error-background: #ffeff4;\n  --nc-color-nextgen-status-warning: #cba127;\n  --nc-color-nextgen-status-warning-background: #fff8e6;\n  --nc-color-nextgen-blue-100: #dfeff2;\n  --nc-color-nextgen-error-red-700: #f62459;\n  --nc-color-nextgen-blue-500: #006192;\n  --nc-color-nextgen-blue-400: #79cdec;\n  --nc-color-nextgen-red-500: #ff6592;\n  --nc-color-nextgen-secondary-blue-300: #13a0d3;\n  --lumi-white-color: #ffffff;\n  --lumi-primary-yellow-color: #fab600;\n}\n\n.ion-color-green {\n  --ion-color-base: var(--nc-color-nextgen-green);\n  --ion-color-base-rgb: var(--nc-color-nextgen-green);\n  --ion-color-contrast: var(--nc-color-nextgen-white);\n  --ion-color-contrast-rgb: var(--nc-color-nextgen-green);\n  --ion-color-shade: var(--nc-color-nextgen-green);\n  --ion-color-tint: var(--nc-color-nextgen-green);\n}\n\n.forgot-password-container {\n  background: var(--nc-color-nextgen-neutral-grey-50);\n}\n\n.body-content {\n  padding-top: 2rem;\n  min-height: 85%;\n  padding-bottom: 3rem;\n}\n\n.need-help-text {\n  color: var(--nc-color-nextgen-green);\n  float: right !important;\n}\n\n.text-detail {\n  color: var(--nc-color-nextgen-neutral-grey);\n  padding-top: 2rem;\n}\n\n.form-forgot-pass {\n  width: 100%;\n  padding-top: 2rem;\n}\n\n.send-reset-link {\n  text-align: center;\n  padding-top: 7rem;\n}\n\n.toolbar-title {\n  display: flex;\n  justify-content: space-between;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXGNvbG9yLnNjc3MiLCJmb3Jnb3QtcGFzc3dvcmQucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0MsMkNBQUE7RUFDQSxpQ0FBQTtFQUNBLGdDQUFBO0VBQ0EsaUNBQUE7RUFDQSxpQ0FBQTtFQUNBLDJDQUFBO0VBQ0EsZ0NBQUE7RUFDQSxzQ0FBQTtFQUNBLGlDQUFBO0VBQ0Esd0NBQUE7RUFDQSx5Q0FBQTtFQUNBLG1DQUFBO0VBQ0EsNENBQUE7RUFDQSw0Q0FBQTtFQUNBLDRDQUFBO0VBQ0Esd0NBQUE7RUFDQSxtREFBQTtFQUNBLDBDQUFBO0VBQ0EscURBQUE7RUFDQSxvQ0FBQTtFQUNBLHlDQUFBO0VBQ0Esb0NBQUE7RUFDQSxvQ0FBQTtFQUNBLG1DQUFBO0VBQ0EsOENBQUE7RUFFQSwyQkFBQTtFQUNBLG9DQUFBO0FDQUQ7O0FEZ0NBO0VBQ0MsK0NBQUE7RUFDQSxtREFBQTtFQUNBLG1EQUFBO0VBQ0EsdURBQUE7RUFDQSxnREFBQTtFQUNBLCtDQUFBO0FDN0JEOztBQW5DQTtFQUNJLG1ERHVDNEI7QUNEaEM7O0FBbkNBO0VBQ0ksaUJBQUE7RUFDQSxlQUFBO0VBQ0Ysb0JBQUE7QUFzQ0Y7O0FBbkNBO0VBQ0ksb0NEa0JrQjtFQ2pCbEIsdUJBQUE7QUFzQ0o7O0FBbkNBO0VBQ0ksMkNEb0J5QjtFQ25CekIsaUJBQUE7QUFzQ0o7O0FBbkNBO0VBQ0ksV0FBQTtFQUNBLGlCQUFBO0FBc0NKOztBQW5DQTtFQUNJLGtCQUFBO0VBQ0EsaUJBQUE7QUFzQ0o7O0FBcENBO0VBQ0ksYUFBQTtFQUNBLDhCQUFBO0FBdUNKIiwiZmlsZSI6ImZvcmdvdC1wYXNzd29yZC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyI6cm9vdCB7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS01MDogI2YxZWZlZjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4td2hpdGU6ICNmZmZmZmY7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWJsdWU6ICMwZDE1MmU7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuOiAjMDA5MDhkO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ibGFjazogIzAwMDAwMDtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tZ3JleS1iYWNrZ3JvdW5kOiAjYzhkM2RhO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ncmV5OiAjOTJhMmFjO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zdG9uZS1ncmV5OiAjZmFmYWZhO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1lcnJvcjogI2ZjMTA1NTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5OiAjNDE0MTQxO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1maWJyYW50LWdyZWVuOiAjMDBiYWI2O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi13YXJuaW5nOiAjZmZkMDQ4O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbi1iYWNrZ3JvdW5kOiAjZTZmMmYyO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNDAwOiAjN2E3YTdhO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktMTAwOiAjZWZmM2Y1O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtZXJyb3I6ICNiYTBjM2Y7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy1lcnJvci1iYWNrZ3JvdW5kOiAjZmZlZmY0O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtd2FybmluZzogI2NiYTEyNztcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLXdhcm5pbmctYmFja2dyb3VuZDogI2ZmZjhlNjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZS0xMDA6ICNkZmVmZjI7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWVycm9yLXJlZC03MDA6ICNmNjI0NTk7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWJsdWUtNTAwOiAjMDA2MTkyO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlLTQwMDogIzc5Y2RlYztcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tcmVkLTUwMDogI2ZmNjU5MjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc2Vjb25kYXJ5LWJsdWUtMzAwOiAjMTNhMGQzO1xyXG5cclxuXHQtLWx1bWktd2hpdGUtY29sb3I6ICNmZmZmZmY7XHJcblx0LS1sdW1pLXByaW1hcnkteWVsbG93LWNvbG9yOiAjZmFiNjAwO1xyXG59XHJcbiRjb2xvci1uZXh0Z2VuLWJsdWU6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZSk7XHJcbiRjb2xvci1uZXh0Z2VuLWdyZWVuOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuKTtcclxuJGNvbG9yLW5leHRnZW4td2hpdGU6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4td2hpdGUpO1xyXG4kY29sb3ItbmV4dGdlbi1ibGFjazogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ibGFjayk7XHJcbiRjb2xvci1uZXh0Z2VuLWdyZXktYmFja2dyb3VuZDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmV5LWJhY2tncm91bmQpO1xyXG4kY29sb3ItbmV4dGdlbi1ncmV5OiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZXkpO1xyXG4kY29sb3ItbmV4dGdlbi1zdG9uZS1ncmV5OiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXN0b25lLWdyZXkpO1xyXG4kY29sb3ItbmV4dGdlbi1lcnJvcjogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1lcnJvcik7XHJcbiRjb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleTogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXkpO1xyXG4kY29sb3ItbmV4dGdlbi1maWJyYW50LWdyZWVuOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWZpYnJhbnQtZ3JlZW4pO1xyXG4kY29sb3ItbmV4dGdlbi13YXJuaW5nOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXdhcm5pbmcpO1xyXG4kY29sb3ItbmV4dGdlbi1ncmVlbi1iYWNrZ3JvdW5kOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuLWJhY2tncm91bmQpO1xyXG4kY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNTA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTUwKTtcclxuJGNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTQwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNDAwKTtcclxuJGNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTEwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktMTAwKTtcclxuJGNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy1lcnJvcik7XHJcbiRjb2xvci1uZXh0Z2VuLXN0YXR1cy1lcnJvci1iYWNrZ3JvdW5kOiB2YXIoXHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy1lcnJvci1iYWNrZ3JvdW5kXHJcbik7XHJcbiRjb2xvci1uZXh0Z2VuLXN0YXR1cy13YXJuaW5nOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy13YXJuaW5nKTtcclxuJGNvbG9yLW5leHRnZW4tc3RhdHVzLXdhcm5pbmctYmFja2dyb3VuZDogdmFyKFxyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtd2FybmluZy1iYWNrZ3JvdW5kXHJcbik7XHJcbiRjb2xvci1uZXh0Z2VuLWJsdWUtMTAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWJsdWUtMTAwKTtcclxuJGNvbG9yLW5leHRnZW4tZXJyb3ItcmVkLTcwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1lcnJvci1yZWQtNzAwKTtcclxuJGNvbG9yLW5leHRnZW4tYmx1ZS01MDA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZS01MDApO1xyXG4kY29sb3ItbmV4dGdlbi1ibHVlLTQwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlLTQwMCk7XHJcbiRjb2xvci1uZXh0Z2VuLXJlZC01MDA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tcmVkLTUwMCk7XHJcbiRjb2xvci1uZXh0Z2VuLXNlY29uZGFyeS1ibHVlLTMwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1zZWNvbmRhcnktYmx1ZS0zMDApO1xyXG5cclxuLmlvbi1jb2xvci1ncmVlbiB7XHJcblx0LS1pb24tY29sb3ItYmFzZTogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbik7XHJcblx0LS1pb24tY29sb3ItYmFzZS1yZ2I6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4pO1xyXG5cdC0taW9uLWNvbG9yLWNvbnRyYXN0OiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXdoaXRlKTtcclxuXHQtLWlvbi1jb2xvci1jb250cmFzdC1yZ2I6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4pO1xyXG5cdC0taW9uLWNvbG9yLXNoYWRlOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuKTtcclxuXHQtLWlvbi1jb2xvci10aW50OiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuKTtcclxufVxyXG4iLCJAaW1wb3J0IFwiLi4vLi4vLi4vY29sb3Iuc2Nzc1wiO1xyXG5cclxuLmZvcmdvdC1wYXNzd29yZC1jb250YWluZXIge1xyXG4gICAgYmFja2dyb3VuZDogJGNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTUwO1xyXG59XHJcblxyXG4uYm9keS1jb250ZW50e1xyXG4gICAgcGFkZGluZy10b3A6IDJyZW07XHJcbiAgICBtaW4taGVpZ2h0OiA4NSU7XHJcbiAgcGFkZGluZy1ib3R0b206IDNyZW07XHJcbn1cclxuXHJcbi5uZWVkLWhlbHAtdGV4dCB7XHJcbiAgICBjb2xvcjogJGNvbG9yLW5leHRnZW4tZ3JlZW47XHJcbiAgICBmbG9hdDogcmlnaHQgIWltcG9ydGFudDtcclxufVxyXG5cclxuLnRleHQtZGV0YWlsIHtcclxuICAgIGNvbG9yOiAkY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXk7XHJcbiAgICBwYWRkaW5nLXRvcDogMnJlbTtcclxufVxyXG5cclxuLmZvcm0tZm9yZ290LXBhc3Mge1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBwYWRkaW5nLXRvcDogMnJlbTtcclxufVxyXG5cclxuLnNlbmQtcmVzZXQtbGluayB7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBwYWRkaW5nLXRvcDogN3JlbTtcclxufVxyXG4udG9vbGJhci10aXRsZXtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6c3BhY2UtYmV0d2VlbjtcclxufSJdfQ== */";

/***/ }),

/***/ 83425:
/*!********************************************************************************************************************!*\
  !*** ./src/app/pages/forgot-password/forgot-password-check-email/forgot-password-check-email.page.html?ngResource ***!
  \********************************************************************************************************************/
/***/ ((module) => {

module.exports = "<div class=\"forgot-password-container\">\r\n\t<nextcare-layout>\r\n\t\t<ng-template header>\r\n\t\t\t<div class=\"toolbar-title\">\r\n\t\t\t\t<button class=\"btn btn-circle\" (click)=\"onClose()\"><i class=\"uil uil-multiply body-l\"></i></button>\r\n\t\t\t\t<span class=\"need-help-text body-l bold\" (click)=\"redirectToNeedHelp()\">{{'signin.needHelp' | translate }}</span>\r\n\t\t\t</div>\r\n\t\t</ng-template>\r\n\t\t<ng-template body>\r\n\t\t\t<div class=\"body-content\">\r\n\t\t\t\t<img src=\"../../../../assets/images/email.svg\" />\r\n\t\t\t\t<div class=\"check-your-mail h3 bold\">{{'forgotPassword.checkYourEmail'|translate}}</div>\r\n\t\t\t\t<div class=\"data-email\">\r\n\t\t\t\t\t<span class=\"body-n\">{{'forgotPassword.weHaveSendYouAVerificationLinkToYourEmail'|translate}}&nbsp;</span>\r\n\t\t\t\t\t<span class=\"body-n bold\">{{params?.email}}</span>\r\n\t\t\t\t</div>\r\n\t\t\t\t<div class=\"send-reset-link\">\r\n\t\t\t\t\t<button class=\"btn btn-large primary bold\" (click)=\"openMyMail()\">{{'forgotPassword.enterOTP'|translate}}</button>\r\n\t\t\t\t</div>\r\n\t\t\t</div>\r\n\t\t</ng-template>\r\n\t\t<ng-template bottom>\r\n\t\t\t<div class=\"receive-the-link\">\r\n\t\t\t\t<span class=\"body-n text-receive\">{{'forgotPassword.DidntReceiveTheLink'| translate}}&nbsp;</span>\r\n\t\t\t\t<span class=\"body-n bold text-link\">\r\n\t\t\t\t\t<span class=\"body-n bold text-link\" (click)=\"resendLink()\">{{textResendLink| translate}}</span>\r\n\t\t\t\t\t{{textTimeInterval}}\r\n\t\t\t\t</span>\r\n\t\t\t</div>\r\n\t\t</ng-template>\r\n\t</nextcare-layout>\r\n</div>\r\n";

/***/ }),

/***/ 36688:
/*!****************************************************************************!*\
  !*** ./src/app/pages/forgot-password/forgot-password.page.html?ngResource ***!
  \****************************************************************************/
/***/ ((module) => {

module.exports = "<div class=\"forgot-password-container\">\r\n    <nextcare-layout>\r\n        <ng-template header>\r\n            <div class=\"toolbar-title\">\r\n                <button class=\"btn btn-circle\" (click)=\"onBack()\">\r\n                    <ion-icon  class=\"icon-back body-l\" name=\"arrow-back-outline\"></ion-icon>\r\n                </button>\r\n                <span class=\"need-help-text body-l bold\" (click)=\"redirectToNeedHelp()\">{{\r\n                    'signin.needHelp' |\r\n                    translate }}</span>\r\n            </div>\r\n        </ng-template>\r\n        <ng-template body>\r\n            <div class=\"body-content\">\r\n            <div class=\"h3 bold\">\r\n                {{'forgotPassword.title' | translate}}\r\n            </div>\r\n            <div class=\"text-detail body-sm\">\r\n                {{'forgotPassword.textDetail' | translate}}\r\n            </div>\r\n            <div>\r\n                <form class=\"form-forgot-pass\" [formGroup]=\"forgotPasswordForm\">\r\n                    <div>\r\n                        <nextgen-control [type]=\"TYPE.INPUT\" [label-property]=\"'signup.email' | translate\"\r\n                            [placeholder]=\"'signup.emailPlaceholder' | translate\" first-icon=\"uil uil-envelope\"\r\n                            [(ngModel)]=\"email\"\r\n                            (keyup)=\"onInput()\"\r\n                            (paste)=\"onPaste($event)\"\r\n                            formControlName=\"email\">\r\n                        </nextgen-control>\r\n                    </div>\r\n                    <div class=\"send-reset-link\">\r\n                        <button class=\"btn btn-large primary bold\" [disabled]=\"forgotPasswordForm.invalid\"\r\n                            (click)=\"sendResetLink()\">{{\r\n                            'forgotPassword.buttonSendResetLink' | translate }}</button>\r\n                    </div>\r\n                </form>\r\n            </div>\r\n        </div>\r\n        </ng-template>\r\n    </nextcare-layout>\r\n</div>";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_forgot-password_forgot-password_module_ts.js.map