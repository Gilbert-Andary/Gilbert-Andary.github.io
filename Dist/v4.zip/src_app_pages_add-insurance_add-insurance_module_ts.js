"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_add-insurance_add-insurance_module_ts"],{

/***/ 89170:
/*!*********************************************************************!*\
  !*** ./src/app/pages/add-insurance/add-insurance-routing.module.ts ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AddInsurancePageRoutingModule": () => (/* binding */ AddInsurancePageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _add_insurance_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./add-insurance.page */ 76173);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var src_app_resolves_regionCountry__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/resolves/regionCountry */ 26129);
/* harmony import */ var src_app_resolves_serviceType_resolve__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/resolves/serviceType.resolve */ 58502);






const routes = [
    {
        path: '',
        component: _add_insurance_page__WEBPACK_IMPORTED_MODULE_0__.AddInsurancePage,
        resolve: {
            regionsCountryType: src_app_resolves_regionCountry__WEBPACK_IMPORTED_MODULE_1__.RegionCountryResolve,
            servicesType: src_app_resolves_serviceType_resolve__WEBPACK_IMPORTED_MODULE_2__.ServiceTypeResolve
        }
    },
];
let AddInsurancePageRoutingModule = class AddInsurancePageRoutingModule {
};
AddInsurancePageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_5__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_5__.RouterModule]
    })
], AddInsurancePageRoutingModule);



/***/ }),

/***/ 93686:
/*!*************************************************************!*\
  !*** ./src/app/pages/add-insurance/add-insurance.module.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AddInsurancePageModule": () => (/* binding */ AddInsurancePageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _add_insurance_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./add-insurance-routing.module */ 89170);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _angular_material_expansion__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/material/expansion */ 12928);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var src_app_resolves_regionCountry__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/resolves/regionCountry */ 26129);
/* harmony import */ var src_app_resolves_serviceType_resolve__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/resolves/serviceType.resolve */ 58502);
/* harmony import */ var src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/shared/shared.module */ 44466);
/* harmony import */ var _show_tearms_cookies_show_find_emirates_ID_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./show-tearms-cookies/show-find-emirates-ID.component */ 73921);











let AddInsurancePageModule = class AddInsurancePageModule {
};
AddInsurancePageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.NgModule)({
        declarations: [
            // AddInsurancePage,
            _show_tearms_cookies_show_find_emirates_ID_component__WEBPACK_IMPORTED_MODULE_4__.ShowFindEmiratesIDComponent
        ],
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_7__.CommonModule,
            _add_insurance_routing_module__WEBPACK_IMPORTED_MODULE_0__.AddInsurancePageRoutingModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_8__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.IonicModule,
            src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_3__.SharedModule,
            _angular_material_expansion__WEBPACK_IMPORTED_MODULE_10__.MatExpansionModule
        ],
        providers: [
            src_app_resolves_serviceType_resolve__WEBPACK_IMPORTED_MODULE_2__.ServiceTypeResolve,
            src_app_resolves_regionCountry__WEBPACK_IMPORTED_MODULE_1__.RegionCountryResolve,
        ],
    })
], AddInsurancePageModule);



/***/ }),

/***/ 26129:
/*!*******************************************!*\
  !*** ./src/app/resolves/regionCountry.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RegionCountryResolve": () => (/* binding */ RegionCountryResolve)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs/operators */ 86942);
/* harmony import */ var _service_language_language_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../service/language/language.service */ 11281);





let RegionCountryResolve = class RegionCountryResolve {
    /** CONSTRUCTORS */
    constructor(router, regionsCountryService) {
        this.router = router;
        this.regionsCountryService = regionsCountryService;
    }
    resolve(_) {
        return this.regionsCountryService.getRegionCountry().pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_1__.map)((res) => {
            console.log(res);
            res = res.map((e) => {
                let icon;
                switch (e.id) {
                    case 82:
                        icon = 'bh';
                        break;
                    case 97:
                        icon = 'cn';
                        break;
                    case 15:
                        icon = 'eg';
                        break;
                    case 19:
                        icon = 'gr';
                        break;
                    case 212:
                        icon = 'ksa';
                        break;
                    case 26:
                        icon = 'lb';
                        break;
                    case 32:
                        icon = 'ma';
                        break;
                    case 68:
                        icon = 'om';
                        break;
                    case 35:
                        icon = 'qa';
                        break;
                    case 42:
                        icon = 'tn';
                        break;
                    case 45:
                        icon = 'ae';
                        break;
                    case 25:
                        icon = 'kw';
                        break;
                    case 24:
                        icon = 'sa';
                        break;
                    case 56:
                        icon = 'de';
                        break;
                    default:
                        icon = 'empty';
                }
                return Object.assign({ icon: icon }, e);
            });
            return res;
        }));
    }
};
RegionCountryResolve.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__.Router },
    { type: _service_language_language_service__WEBPACK_IMPORTED_MODULE_0__.LanguageService }
];
RegionCountryResolve = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Injectable)()
], RegionCountryResolve);



/***/ }),

/***/ 58502:
/*!*************************************************!*\
  !*** ./src/app/resolves/serviceType.resolve.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ServiceTypeResolve": () => (/* binding */ ServiceTypeResolve)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _service_connect_insurance_connect_insurance_details_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../service/connect-insurance/connect-insurance-details.service */ 16809);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs/operators */ 86942);





let ServiceTypeResolve = class ServiceTypeResolve {
    /** CONSTRUCTORS */
    constructor(router, connectInsurance) {
        this.router = router;
        this.connectInsurance = connectInsurance;
    }
    resolve(_) {
        return this.connectInsurance.getServiceType().pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_1__.map)(res => {
            res = res.map(e => (Object.assign({ name: e.text }, e)));
            return res;
        }));
    }
};
ServiceTypeResolve.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__.Router },
    { type: _service_connect_insurance_connect_insurance_details_service__WEBPACK_IMPORTED_MODULE_0__.ConnectInsuranceDetailsService }
];
ServiceTypeResolve = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Injectable)()
], ServiceTypeResolve);



/***/ })

}]);
//# sourceMappingURL=src_app_pages_add-insurance_add-insurance_module_ts.js.map