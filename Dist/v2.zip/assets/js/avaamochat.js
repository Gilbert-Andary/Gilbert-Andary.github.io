(function (w) {
  w.AvaamoChatBot = function (t) {
    async function o(t, o) {
      if (window.Avaamo) {
        await window?.Avaamo?.logout();
        const elements = document.querySelectorAll('#avm-web-channel');
        elements.forEach(element => {
          element.remove();
        });
      }
      var n = document.createElement('script');
      n.setAttribute('src', t),
        n.setAttribute('id', 'avm-web-channel'),
        n.onload = o,
        document.body.appendChild(n)
    }
    return this.options = t || {},
      this.load = function (t) {
        o(this.options,
          function () {
            window.Avaamo.addFrame(),
              t && "function" == typeof (t) && t(window.Avaamo), window.Avaamo.openChatBox()
          })
      }, this
  }
}
)(window)
