"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["insurance-card_src_web_ts"],{

/***/ 47189:
/*!***********************************!*\
  !*** ./insurance-card/src/web.ts ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "InsuranceCardWeb": () => (/* binding */ InsuranceCardWeb)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _capacitor_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @capacitor/core */ 59179);


class InsuranceCardWeb extends _capacitor_core__WEBPACK_IMPORTED_MODULE_0__.WebPlugin {
    echo(options) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__awaiter)(this, void 0, void 0, function* () {
            console.log('ECHO', options);
            return options;
        });
    }
    saveCardImageToGallery(_options) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__awaiter)(this, void 0, void 0, function* () {
            // logic here
        });
    }
    handleDeepLinking() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__awaiter)(this, void 0, void 0, function* () {
            // Logic here
            let options = { isDeepLink: true };
            return options;
        });
    }
    handleOpenMail() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__awaiter)(this, void 0, void 0, function* () {
        });
    }
}


/***/ })

}]);
//# sourceMappingURL=insurance-card_src_web_ts.js.map