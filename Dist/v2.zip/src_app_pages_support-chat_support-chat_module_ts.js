"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_support-chat_support-chat_module_ts"],{

/***/ 69290:
/*!*******************************************************************!*\
  !*** ./src/app/pages/support-chat/support-chat-routing.module.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SupportChatPageRoutingModule": () => (/* binding */ SupportChatPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _support_chat_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./support-chat.page */ 95997);




const routes = [
    {
        path: '',
        component: _support_chat_page__WEBPACK_IMPORTED_MODULE_0__.SupportChatPage
    },
];
let SupportChatPageRoutingModule = class SupportChatPageRoutingModule {
};
SupportChatPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
    })
], SupportChatPageRoutingModule);



/***/ }),

/***/ 80831:
/*!***********************************************************!*\
  !*** ./src/app/pages/support-chat/support-chat.module.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SupportChatPageModule": () => (/* binding */ SupportChatPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _support_chat_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./support-chat.page */ 95997);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/shared/shared.module */ 44466);
/* harmony import */ var _support_chat_routing_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./support-chat-routing.module */ 69290);








let SupportChatPageModule = class SupportChatPageModule {
};
SupportChatPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        declarations: [_support_chat_page__WEBPACK_IMPORTED_MODULE_0__.SupportChatPage],
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule,
            _support_chat_routing_module__WEBPACK_IMPORTED_MODULE_2__.SupportChatPageRoutingModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonicModule,
            src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_1__.SharedModule,
        ],
    })
], SupportChatPageModule);



/***/ }),

/***/ 95997:
/*!*********************************************************!*\
  !*** ./src/app/pages/support-chat/support-chat.page.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SupportChatPage": () => (/* binding */ SupportChatPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _support_chat_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./support-chat.page.html?ngResource */ 56182);
/* harmony import */ var _support_chat_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./support-chat.page.scss?ngResource */ 87481);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);




let SupportChatPage = class SupportChatPage {
    constructor() {
    }
    ngOnInit() {
    }
};
SupportChatPage.ctorParameters = () => [];
SupportChatPage = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-support-chat',
        template: _support_chat_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_support_chat_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], SupportChatPage);



/***/ }),

/***/ 87481:
/*!**********************************************************************!*\
  !*** ./src/app/pages/support-chat/support-chat.page.scss?ngResource ***!
  \**********************************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzdXBwb3J0LWNoYXQucGFnZS5zY3NzIn0= */";

/***/ }),

/***/ 56182:
/*!**********************************************************************!*\
  !*** ./src/app/pages/support-chat/support-chat.page.html?ngResource ***!
  \**********************************************************************/
/***/ ((module) => {

module.exports = "<p>Support/Chat</p>";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_support-chat_support-chat_module_ts.js.map