"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_edit-profile_edit-profile_module_ts"],{

/***/ 8324:
/*!***************************************************************************************!*\
  !*** ./projects/iris-ionic-library/src/lib/_utils/components/base-component/index.ts ***!
  \***************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NcBaseComponent": () => (/* reexport safe */ _public_api__WEBPACK_IMPORTED_MODULE_0__.NcBaseComponent),
/* harmony export */   "NcBaseComponentModule": () => (/* reexport safe */ _public_api__WEBPACK_IMPORTED_MODULE_0__.NcBaseComponentModule)
/* harmony export */ });
/* harmony import */ var _public_api__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./public-api */ 67685);



/***/ }),

/***/ 67685:
/*!********************************************************************************************!*\
  !*** ./projects/iris-ionic-library/src/lib/_utils/components/base-component/public-api.ts ***!
  \********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NcBaseComponent": () => (/* reexport safe */ _src_base_component_component__WEBPACK_IMPORTED_MODULE_0__.NcBaseComponent),
/* harmony export */   "NcBaseComponentModule": () => (/* reexport safe */ _src_base_component_module__WEBPACK_IMPORTED_MODULE_2__.NcBaseComponentModule)
/* harmony export */ });
/* harmony import */ var _src_base_component_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./src/base-component.component */ 96132);
/* harmony import */ var _src_base_component_interface__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./src/base-component.interface */ 81136);
/* harmony import */ var _src_base_component_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./src/base-component.module */ 24294);
/*
 * Public API Surface sub-entry of iris-ionic-library
 * Make sure you don't have internal imports in the library, that point to the main iris-ionic-library/index.ts file of the lib.
 */





/***/ }),

/***/ 96132:
/*!**************************************************************************************************************!*\
  !*** ./projects/iris-ionic-library/src/lib/_utils/components/base-component/src/base-component.component.ts ***!
  \**************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NcBaseComponent": () => (/* binding */ NcBaseComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _base_component_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./base-component.component.html?ngResource */ 61543);
/* harmony import */ var _base_component_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./base-component.component.scss?ngResource */ 17405);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var iris_ionic_library_src_lib_shared__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! iris-ionic-library/src/lib/shared */ 6936);





let NcBaseComponent = class NcBaseComponent {
    constructor() {
        this.config = {
            id: null,
            formGroup: null,
        };
        this.fieldValueChange = new _angular_core__WEBPACK_IMPORTED_MODULE_3__.EventEmitter();
        this.translationService = iris_ionic_library_src_lib_shared__WEBPACK_IMPORTED_MODULE_2__.NcCommonUtils.getClass(iris_ionic_library_src_lib_shared__WEBPACK_IMPORTED_MODULE_2__.NcTranslationService);
    }
    ngOnInit() { }
    initComponent(fromObject) {
        // NcCommonUtils.initComponent(this.config, fromObject);
        this.config = fromObject;
        this.config.backupConfig = {};
        iris_ionic_library_src_lib_shared__WEBPACK_IMPORTED_MODULE_2__.NcCommonUtils.initComponent(this.config.backupConfig, fromObject);
    }
    onChange($event) {
        this.fieldValueChange.emit($event);
    }
    resetConfigToInitialState() {
        this.initComponent(this.config.backupConfig);
    }
    getControl() {
        const config = this.config;
        if (config.formGroup && config.id) {
            return config.formGroup.controls[config.id];
        }
    }
};
NcBaseComponent.ctorParameters = () => [];
NcBaseComponent.propDecorators = {
    fieldValueChange: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.Output }]
};
NcBaseComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'nc-base-component',
        template: _base_component_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_base_component_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], NcBaseComponent);



/***/ }),

/***/ 81136:
/*!**************************************************************************************************************!*\
  !*** ./projects/iris-ionic-library/src/lib/_utils/components/base-component/src/base-component.interface.ts ***!
  \**************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);



/***/ }),

/***/ 24294:
/*!***********************************************************************************************************!*\
  !*** ./projects/iris-ionic-library/src/lib/_utils/components/base-component/src/base-component.module.ts ***!
  \***********************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NcBaseComponentModule": () => (/* binding */ NcBaseComponentModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var iris_ionic_library_src_lib_shared__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! iris-ionic-library/src/lib/shared */ 6936);



let NcBaseComponentModule = class NcBaseComponentModule {
};
NcBaseComponentModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        declarations: [],
        imports: [
            iris_ionic_library_src_lib_shared__WEBPACK_IMPORTED_MODULE_0__.NcSharedModule,
        ],
    })
], NcBaseComponentModule);



/***/ }),

/***/ 71033:
/*!*************************************************************!*\
  !*** ./projects/iris-ionic-library/src/lib/_utils/index.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NcBaseComponent": () => (/* reexport safe */ _public_api__WEBPACK_IMPORTED_MODULE_0__.NcBaseComponent),
/* harmony export */   "NcBaseComponentModule": () => (/* reexport safe */ _public_api__WEBPACK_IMPORTED_MODULE_0__.NcBaseComponentModule)
/* harmony export */ });
/* harmony import */ var _public_api__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./public-api */ 21337);



/***/ }),

/***/ 21337:
/*!******************************************************************!*\
  !*** ./projects/iris-ionic-library/src/lib/_utils/public-api.ts ***!
  \******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NcBaseComponent": () => (/* reexport safe */ _components_base_component__WEBPACK_IMPORTED_MODULE_0__.NcBaseComponent),
/* harmony export */   "NcBaseComponentModule": () => (/* reexport safe */ _components_base_component__WEBPACK_IMPORTED_MODULE_0__.NcBaseComponentModule)
/* harmony export */ });
/* harmony import */ var _components_base_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./components/base-component */ 8324);
/*
 * Public API Surface sub-entry of iris-ionic-library
 * Make sure you don't have internal imports in the library, that point to the main iris-ionic-library/index.ts file of the lib.
 */



/***/ }),

/***/ 9578:
/*!*****************************************************************************!*\
  !*** ./projects/iris-ionic-library/src/lib/components/back-button/index.ts ***!
  \*****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NcBackButtonComponent": () => (/* reexport safe */ _public_api__WEBPACK_IMPORTED_MODULE_0__.NcBackButtonComponent),
/* harmony export */   "NcBackButtonComponentModule": () => (/* reexport safe */ _public_api__WEBPACK_IMPORTED_MODULE_0__.NcBackButtonComponentModule)
/* harmony export */ });
/* harmony import */ var _public_api__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./public-api */ 83971);



/***/ }),

/***/ 83971:
/*!**********************************************************************************!*\
  !*** ./projects/iris-ionic-library/src/lib/components/back-button/public-api.ts ***!
  \**********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NcBackButtonComponent": () => (/* reexport safe */ _src_back_button_component__WEBPACK_IMPORTED_MODULE_0__.NcBackButtonComponent),
/* harmony export */   "NcBackButtonComponentModule": () => (/* reexport safe */ _src_back_button_module__WEBPACK_IMPORTED_MODULE_2__.NcBackButtonComponentModule)
/* harmony export */ });
/* harmony import */ var _src_back_button_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./src/back-button.component */ 39978);
/* harmony import */ var _src_back_button_interface__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./src/back-button.interface */ 55961);
/* harmony import */ var _src_back_button_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./src/back-button.module */ 36210);
/*
 * Public API Surface sub-entry of iris-ionic-library
 * Make sure you don't have internal imports in the library, that point to the main iris-ionic-library/index.ts file of the lib.
 */





/***/ }),

/***/ 39978:
/*!*************************************************************************************************!*\
  !*** ./projects/iris-ionic-library/src/lib/components/back-button/src/back-button.component.ts ***!
  \*************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NcBackButtonComponent": () => (/* binding */ NcBackButtonComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _back_button_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./back-button.component.html?ngResource */ 86016);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var iris_ionic_library_src_lib_utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! iris-ionic-library/src/lib/_utils */ 71033);
/* harmony import */ var iris_ionic_library_src_lib_elements__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! iris-ionic-library/src/lib/elements */ 43591);
/* harmony import */ var iris_ionic_library_src_lib_shared__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! iris-ionic-library/src/lib/shared */ 6936);






let NcBackButtonComponent = class NcBackButtonComponent extends iris_ionic_library_src_lib_utils__WEBPACK_IMPORTED_MODULE_1__.NcBaseComponent {
    constructor(navService) {
        super();
        this.navService = navService;
    }
    ngOnInit() {
        this.initComponent(this.compConfig);
        this.config.elementClicked = () => {
            this.navService.goBack();
        };
        this.config.icon = {
            formGroup: this.config.formGroup,
            id: this.config.id + '-back-icon',
            iconName: iris_ionic_library_src_lib_elements__WEBPACK_IMPORTED_MODULE_2__.IconsList.back,
        };
    }
};
NcBackButtonComponent.ctorParameters = () => [
    { type: iris_ionic_library_src_lib_shared__WEBPACK_IMPORTED_MODULE_3__.NcNavigatorService }
];
NcBackButtonComponent.propDecorators = {
    compConfig: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_4__.Input }]
};
NcBackButtonComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'nc-back-button',
        template: _back_button_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
    })
], NcBackButtonComponent);



/***/ }),

/***/ 55961:
/*!*************************************************************************************************!*\
  !*** ./projects/iris-ionic-library/src/lib/components/back-button/src/back-button.interface.ts ***!
  \*************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);



/***/ }),

/***/ 36210:
/*!**********************************************************************************************!*\
  !*** ./projects/iris-ionic-library/src/lib/components/back-button/src/back-button.module.ts ***!
  \**********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NcBackButtonComponentModule": () => (/* binding */ NcBackButtonComponentModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var iris_ionic_library_src_lib_elements__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! iris-ionic-library/src/lib/elements */ 43591);
/* harmony import */ var iris_ionic_library_src_lib_shared__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! iris-ionic-library/src/lib/shared */ 6936);
/* harmony import */ var _back_button_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./back-button.component */ 39978);





let NcBackButtonComponentModule = class NcBackButtonComponentModule {
};
NcBackButtonComponentModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        declarations: [
            _back_button_component__WEBPACK_IMPORTED_MODULE_2__.NcBackButtonComponent,
        ],
        imports: [
            iris_ionic_library_src_lib_shared__WEBPACK_IMPORTED_MODULE_1__.NcSharedModule,
            iris_ionic_library_src_lib_elements__WEBPACK_IMPORTED_MODULE_0__.NcComponentModule,
            // NcButtonSubmitModule,
        ],
        exports: [
            _back_button_component__WEBPACK_IMPORTED_MODULE_2__.NcBackButtonComponent,
        ],
    })
], NcBackButtonComponentModule);



/***/ }),

/***/ 30679:
/*!******************************************************************************!*\
  !*** ./projects/iris-ionic-library/src/lib/components/header-label/index.ts ***!
  \******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NcHeaderLabelComponent": () => (/* reexport safe */ _public_api__WEBPACK_IMPORTED_MODULE_0__.NcHeaderLabelComponent),
/* harmony export */   "NcHeaderLabelModule": () => (/* reexport safe */ _public_api__WEBPACK_IMPORTED_MODULE_0__.NcHeaderLabelModule)
/* harmony export */ });
/* harmony import */ var _public_api__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./public-api */ 77430);



/***/ }),

/***/ 77430:
/*!***********************************************************************************!*\
  !*** ./projects/iris-ionic-library/src/lib/components/header-label/public-api.ts ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NcHeaderLabelComponent": () => (/* reexport safe */ _src_header_label_component__WEBPACK_IMPORTED_MODULE_0__.NcHeaderLabelComponent),
/* harmony export */   "NcHeaderLabelModule": () => (/* reexport safe */ _src_header_label_module__WEBPACK_IMPORTED_MODULE_2__.NcHeaderLabelModule)
/* harmony export */ });
/* harmony import */ var _src_header_label_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./src/header-label.component */ 56515);
/* harmony import */ var _src_header_label_interface__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./src/header-label.interface */ 33107);
/* harmony import */ var _src_header_label_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./src/header-label.module */ 56495);
/*
 * Public API Surface sub-entry of iris-ionic-library
 * Make sure you don't have internal imports in the library, that point to the main iris-ionic-library/index.ts file of the lib.
 */





/***/ }),

/***/ 56515:
/*!***************************************************************************************************!*\
  !*** ./projects/iris-ionic-library/src/lib/components/header-label/src/header-label.component.ts ***!
  \***************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NcHeaderLabelComponent": () => (/* binding */ NcHeaderLabelComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _header_label_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./header-label.component.html?ngResource */ 39768);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var iris_ionic_library_src_lib_utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! iris-ionic-library/src/lib/_utils */ 71033);




let NcHeaderLabelComponent = class NcHeaderLabelComponent extends iris_ionic_library_src_lib_utils__WEBPACK_IMPORTED_MODULE_1__.NcBaseComponent {
    constructor() {
        super();
    }
    ngOnInit() {
        this.initComponent(this.compConfig);
    }
};
NcHeaderLabelComponent.ctorParameters = () => [];
NcHeaderLabelComponent.propDecorators = {
    compConfig: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.Input }]
};
NcHeaderLabelComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.Component)({
        selector: 'nc-header-label',
        template: _header_label_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
    })
], NcHeaderLabelComponent);



/***/ }),

/***/ 33107:
/*!***************************************************************************************************!*\
  !*** ./projects/iris-ionic-library/src/lib/components/header-label/src/header-label.interface.ts ***!
  \***************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);



/***/ }),

/***/ 56495:
/*!************************************************************************************************!*\
  !*** ./projects/iris-ionic-library/src/lib/components/header-label/src/header-label.module.ts ***!
  \************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NcHeaderLabelModule": () => (/* binding */ NcHeaderLabelModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var iris_ionic_library_src_lib_elements__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! iris-ionic-library/src/lib/elements */ 43591);
/* harmony import */ var iris_ionic_library_src_lib_shared__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! iris-ionic-library/src/lib/shared */ 6936);
/* harmony import */ var _header_label_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./header-label.component */ 56515);





let NcHeaderLabelModule = class NcHeaderLabelModule {
};
NcHeaderLabelModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        declarations: [
            _header_label_component__WEBPACK_IMPORTED_MODULE_2__.NcHeaderLabelComponent,
        ],
        imports: [
            iris_ionic_library_src_lib_shared__WEBPACK_IMPORTED_MODULE_1__.NcSharedModule,
            iris_ionic_library_src_lib_elements__WEBPACK_IMPORTED_MODULE_0__.NcComponentModule,
        ],
        exports: [
            _header_label_component__WEBPACK_IMPORTED_MODULE_2__.NcHeaderLabelComponent,
        ],
    })
], NcHeaderLabelModule);



/***/ }),

/***/ 69164:
/*!**************************************************************************************!*\
  !*** ./projects/iris-ionic-library/src/lib/components/navigation-hyperlink/index.ts ***!
  \**************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NcNavigationHyperlinkComponent": () => (/* reexport safe */ _public_api__WEBPACK_IMPORTED_MODULE_0__.NcNavigationHyperlinkComponent),
/* harmony export */   "NcNavigationHyperlinkModule": () => (/* reexport safe */ _public_api__WEBPACK_IMPORTED_MODULE_0__.NcNavigationHyperlinkModule)
/* harmony export */ });
/* harmony import */ var _public_api__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./public-api */ 75343);



/***/ }),

/***/ 75343:
/*!*******************************************************************************************!*\
  !*** ./projects/iris-ionic-library/src/lib/components/navigation-hyperlink/public-api.ts ***!
  \*******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NcNavigationHyperlinkComponent": () => (/* reexport safe */ _src_navigation_hyperlink_component__WEBPACK_IMPORTED_MODULE_0__.NcNavigationHyperlinkComponent),
/* harmony export */   "NcNavigationHyperlinkModule": () => (/* reexport safe */ _src_navigation_hyperlink_module__WEBPACK_IMPORTED_MODULE_2__.NcNavigationHyperlinkModule)
/* harmony export */ });
/* harmony import */ var _src_navigation_hyperlink_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./src/navigation-hyperlink.component */ 90325);
/* harmony import */ var _src_navigation_hyperlink_interface__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./src/navigation-hyperlink.interface */ 22904);
/* harmony import */ var _src_navigation_hyperlink_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./src/navigation-hyperlink.module */ 60231);
/*
 * Public API Surface sub-entry of iris-ionic-library
 * Make sure you don't have internal imports in the library, that point to the main iris-ionic-library/index.ts file of the lib.
 */





/***/ }),

/***/ 90325:
/*!*******************************************************************************************************************!*\
  !*** ./projects/iris-ionic-library/src/lib/components/navigation-hyperlink/src/navigation-hyperlink.component.ts ***!
  \*******************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NcNavigationHyperlinkComponent": () => (/* binding */ NcNavigationHyperlinkComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _navigation_hyperlink_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./navigation-hyperlink.component.html?ngResource */ 43618);
/* harmony import */ var _navigation_hyperlink_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./navigation-hyperlink.component.scss?ngResource */ 99409);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var iris_ionic_library_src_lib_utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! iris-ionic-library/src/lib/_utils */ 71033);
/* harmony import */ var iris_ionic_library_src_lib_shared__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! iris-ionic-library/src/lib/shared */ 6936);






let NcNavigationHyperlinkComponent = class NcNavigationHyperlinkComponent extends iris_ionic_library_src_lib_utils__WEBPACK_IMPORTED_MODULE_2__.NcBaseComponent {
    constructor(navigator) {
        super();
        this.navigator = navigator;
    }
    ngOnInit() {
        this.initComponent(this.compConfig);
        this.config.elementClicked = () => {
            if (this.config.pageHref) {
                this.navigator.openPage(this.config.pageHref);
            }
        };
    }
};
NcNavigationHyperlinkComponent.ctorParameters = () => [
    { type: iris_ionic_library_src_lib_shared__WEBPACK_IMPORTED_MODULE_3__.NcNavigatorService }
];
NcNavigationHyperlinkComponent.propDecorators = {
    compConfig: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_4__.Input }]
};
NcNavigationHyperlinkComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'nc-navigation-hyperlink',
        template: _navigation_hyperlink_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_navigation_hyperlink_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], NcNavigationHyperlinkComponent);



/***/ }),

/***/ 22904:
/*!*******************************************************************************************************************!*\
  !*** ./projects/iris-ionic-library/src/lib/components/navigation-hyperlink/src/navigation-hyperlink.interface.ts ***!
  \*******************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);



/***/ }),

/***/ 60231:
/*!****************************************************************************************************************!*\
  !*** ./projects/iris-ionic-library/src/lib/components/navigation-hyperlink/src/navigation-hyperlink.module.ts ***!
  \****************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NcNavigationHyperlinkModule": () => (/* binding */ NcNavigationHyperlinkModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var iris_ionic_library_src_lib_elements__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! iris-ionic-library/src/lib/elements */ 43591);
/* harmony import */ var iris_ionic_library_src_lib_shared__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! iris-ionic-library/src/lib/shared */ 6936);
/* harmony import */ var _navigation_hyperlink_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./navigation-hyperlink.component */ 90325);





let NcNavigationHyperlinkModule = class NcNavigationHyperlinkModule {
};
NcNavigationHyperlinkModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        declarations: [
            _navigation_hyperlink_component__WEBPACK_IMPORTED_MODULE_2__.NcNavigationHyperlinkComponent,
        ],
        imports: [
            iris_ionic_library_src_lib_shared__WEBPACK_IMPORTED_MODULE_1__.NcSharedModule,
            iris_ionic_library_src_lib_elements__WEBPACK_IMPORTED_MODULE_0__.NcComponentModule,
        ],
        exports: [
            _navigation_hyperlink_component__WEBPACK_IMPORTED_MODULE_2__.NcNavigationHyperlinkComponent,
        ],
    })
], NcNavigationHyperlinkModule);



/***/ }),

/***/ 52748:
/*!********************************************************************************!*\
  !*** ./projects/iris-ionic-library/src/lib/components/password-input/index.ts ***!
  \********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NcPasswordInputComponent": () => (/* reexport safe */ _public_api__WEBPACK_IMPORTED_MODULE_0__.NcPasswordInputComponent),
/* harmony export */   "NcPasswordInputComponentModule": () => (/* reexport safe */ _public_api__WEBPACK_IMPORTED_MODULE_0__.NcPasswordInputComponentModule)
/* harmony export */ });
/* harmony import */ var _public_api__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./public-api */ 30942);



/***/ }),

/***/ 30942:
/*!*************************************************************************************!*\
  !*** ./projects/iris-ionic-library/src/lib/components/password-input/public-api.ts ***!
  \*************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NcPasswordInputComponent": () => (/* reexport safe */ _src_password_input_component__WEBPACK_IMPORTED_MODULE_0__.NcPasswordInputComponent),
/* harmony export */   "NcPasswordInputComponentModule": () => (/* reexport safe */ _src_password_input_module__WEBPACK_IMPORTED_MODULE_2__.NcPasswordInputComponentModule)
/* harmony export */ });
/* harmony import */ var _src_password_input_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./src/password-input.component */ 50046);
/* harmony import */ var _src_password_input_interface__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./src/password-input.interface */ 73260);
/* harmony import */ var _src_password_input_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./src/password-input.module */ 96216);
/*
 * Public API Surface sub-entry of iris-ionic-library
 * Make sure you don't have internal imports in the library, that point to the main iris-ionic-library/index.ts file of the lib.
 */





/***/ }),

/***/ 50046:
/*!*******************************************************************************************************!*\
  !*** ./projects/iris-ionic-library/src/lib/components/password-input/src/password-input.component.ts ***!
  \*******************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NcPasswordInputComponent": () => (/* binding */ NcPasswordInputComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _password_input_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./password-input.component.html?ngResource */ 77709);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var iris_ionic_library_src_lib_utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! iris-ionic-library/src/lib/_utils */ 71033);
/* harmony import */ var iris_ionic_library_src_lib_elements__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! iris-ionic-library/src/lib/elements */ 43591);





let NcPasswordInputComponent = class NcPasswordInputComponent extends iris_ionic_library_src_lib_utils__WEBPACK_IMPORTED_MODULE_1__.NcBaseComponent {
    constructor() {
        super();
    }
    ngOnInit() {
        this.initComponent(this.compConfig);
        this.config.type = 'password';
        this.config.icon = {
            iconName: iris_ionic_library_src_lib_elements__WEBPACK_IMPORTED_MODULE_2__.IconsList.password,
            formGroup: this.compConfig.formGroup,
            id: 'password-icon',
        };
        this.config.secondaryIcon = {
            iconName: iris_ionic_library_src_lib_elements__WEBPACK_IMPORTED_MODULE_2__.IconsList.showPassword,
            formGroup: this.compConfig.formGroup,
            id: 'show-password-icon',
            elementClicked: () => {
                const showPass = this.config.secondaryIcon.iconName == iris_ionic_library_src_lib_elements__WEBPACK_IMPORTED_MODULE_2__.IconsList.showPassword;
                this.config.secondaryIcon.iconName = showPass ? iris_ionic_library_src_lib_elements__WEBPACK_IMPORTED_MODULE_2__.IconsList.hidePassword : iris_ionic_library_src_lib_elements__WEBPACK_IMPORTED_MODULE_2__.IconsList.showPassword;
                this.config.type = showPass ? 'text' : 'password';
            },
        };
    }
};
NcPasswordInputComponent.ctorParameters = () => [];
NcPasswordInputComponent.propDecorators = {
    compConfig: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.Input }]
};
NcPasswordInputComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'nc-password-input',
        template: _password_input_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
    })
], NcPasswordInputComponent);



/***/ }),

/***/ 73260:
/*!*******************************************************************************************************!*\
  !*** ./projects/iris-ionic-library/src/lib/components/password-input/src/password-input.interface.ts ***!
  \*******************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);



/***/ }),

/***/ 96216:
/*!****************************************************************************************************!*\
  !*** ./projects/iris-ionic-library/src/lib/components/password-input/src/password-input.module.ts ***!
  \****************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NcPasswordInputComponentModule": () => (/* binding */ NcPasswordInputComponentModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var iris_ionic_library_src_lib_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! iris-ionic-library/src/lib/_utils */ 71033);
/* harmony import */ var iris_ionic_library_src_lib_elements__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! iris-ionic-library/src/lib/elements */ 43591);
/* harmony import */ var iris_ionic_library_src_lib_shared__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! iris-ionic-library/src/lib/shared */ 6936);
/* harmony import */ var _password_input_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./password-input.component */ 50046);






let NcPasswordInputComponentModule = class NcPasswordInputComponentModule {
};
NcPasswordInputComponentModule = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.NgModule)({
        declarations: [
            _password_input_component__WEBPACK_IMPORTED_MODULE_3__.NcPasswordInputComponent,
        ],
        imports: [
            iris_ionic_library_src_lib_shared__WEBPACK_IMPORTED_MODULE_2__.NcSharedModule,
            iris_ionic_library_src_lib_utils__WEBPACK_IMPORTED_MODULE_0__.NcBaseComponentModule,
            iris_ionic_library_src_lib_elements__WEBPACK_IMPORTED_MODULE_1__.NcComponentModule,
        ],
        exports: [
            _password_input_component__WEBPACK_IMPORTED_MODULE_3__.NcPasswordInputComponent,
        ],
    })
], NcPasswordInputComponentModule);



/***/ }),

/***/ 25456:
/*!*******************************************************************************!*\
  !*** ./projects/iris-ionic-library/src/lib/components/submit-button/index.ts ***!
  \*******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NcButtonSubmitModule": () => (/* reexport safe */ _public_api__WEBPACK_IMPORTED_MODULE_0__.NcButtonSubmitModule),
/* harmony export */   "NcSubmitButtonComponent": () => (/* reexport safe */ _public_api__WEBPACK_IMPORTED_MODULE_0__.NcSubmitButtonComponent)
/* harmony export */ });
/* harmony import */ var _public_api__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./public-api */ 43807);



/***/ }),

/***/ 43807:
/*!************************************************************************************!*\
  !*** ./projects/iris-ionic-library/src/lib/components/submit-button/public-api.ts ***!
  \************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NcButtonSubmitModule": () => (/* reexport safe */ _src_submit_button_module__WEBPACK_IMPORTED_MODULE_2__.NcButtonSubmitModule),
/* harmony export */   "NcSubmitButtonComponent": () => (/* reexport safe */ _src_submit_button_component__WEBPACK_IMPORTED_MODULE_0__.NcSubmitButtonComponent)
/* harmony export */ });
/* harmony import */ var _src_submit_button_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./src/submit-button.component */ 91203);
/* harmony import */ var _src_submit_button_interface__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./src/submit-button.interface */ 44097);
/* harmony import */ var _src_submit_button_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./src/submit-button.module */ 61966);
/*
 * Public API Surface sub-entry of iris-ionic-library
 * Make sure you don't have internal imports in the library, that point to the main iris-ionic-library/index.ts file of the lib.
 */





/***/ }),

/***/ 91203:
/*!*****************************************************************************************************!*\
  !*** ./projects/iris-ionic-library/src/lib/components/submit-button/src/submit-button.component.ts ***!
  \*****************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NcSubmitButtonComponent": () => (/* binding */ NcSubmitButtonComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _submit_button_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./submit-button.component.html?ngResource */ 95517);
/* harmony import */ var _submit_button_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./submit-button.component.scss?ngResource */ 79394);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var iris_ionic_library_src_lib_utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! iris-ionic-library/src/lib/_utils */ 71033);
/* harmony import */ var iris_ionic_library_src_lib_shared__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! iris-ionic-library/src/lib/shared */ 6936);






let NcSubmitButtonComponent = class NcSubmitButtonComponent extends iris_ionic_library_src_lib_utils__WEBPACK_IMPORTED_MODULE_2__.NcBaseComponent {
    constructor(ncHttpService) {
        super();
        this.ncHttpService = ncHttpService;
    }
    ngOnInit() {
        this.initComponent(this.compConfig);
        this.config.formGroup.fieldValueChange = this.config.formGroup.formGroupInit = () => {
            this.config.isDisabled = this.config.formGroup.invalid;
        };
        // this.config.isDisabled = this.config.formGroup.invalid;
        this.config.elementClicked = () => {
            if (this.config.formGroup.valid) {
                if (iris_ionic_library_src_lib_shared__WEBPACK_IMPORTED_MODULE_3__.NcCommonUtils.isNotNull(this.config.urlToCall)) {
                    this.ncHttpService.sendPostRequest(this.config.urlToCall, this.config.formGroup.value);
                }
            }
            else {
                this.config.formGroup.validateForm();
                document.querySelectorAll('[ng-reflect-name].ng-invalid')[0].scrollIntoView({ behavior: 'smooth' });
            }
        };
    }
};
NcSubmitButtonComponent.ctorParameters = () => [
    { type: iris_ionic_library_src_lib_shared__WEBPACK_IMPORTED_MODULE_3__.NcHttpService }
];
NcSubmitButtonComponent.propDecorators = {
    compConfig: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_4__.Input }]
};
NcSubmitButtonComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'nc-submit-button',
        template: _submit_button_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_submit_button_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], NcSubmitButtonComponent);



/***/ }),

/***/ 44097:
/*!*****************************************************************************************************!*\
  !*** ./projects/iris-ionic-library/src/lib/components/submit-button/src/submit-button.interface.ts ***!
  \*****************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);



/***/ }),

/***/ 61966:
/*!**************************************************************************************************!*\
  !*** ./projects/iris-ionic-library/src/lib/components/submit-button/src/submit-button.module.ts ***!
  \**************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NcButtonSubmitModule": () => (/* binding */ NcButtonSubmitModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var iris_ionic_library_src_lib_elements__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! iris-ionic-library/src/lib/elements */ 43591);
/* harmony import */ var iris_ionic_library_src_lib_shared__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! iris-ionic-library/src/lib/shared */ 6936);
/* harmony import */ var _submit_button_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./submit-button.component */ 91203);





let NcButtonSubmitModule = class NcButtonSubmitModule {
};
NcButtonSubmitModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        declarations: [
            _submit_button_component__WEBPACK_IMPORTED_MODULE_2__.NcSubmitButtonComponent,
        ],
        imports: [
            iris_ionic_library_src_lib_shared__WEBPACK_IMPORTED_MODULE_1__.NcSharedModule,
            iris_ionic_library_src_lib_elements__WEBPACK_IMPORTED_MODULE_0__.NcComponentModule,
        ],
        exports: [
            _submit_button_component__WEBPACK_IMPORTED_MODULE_2__.NcSubmitButtonComponent,
        ],
    })
], NcButtonSubmitModule);



/***/ }),

/***/ 43591:
/*!***************************************************************!*\
  !*** ./projects/iris-ionic-library/src/lib/elements/index.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ClevertapEvent": () => (/* reexport safe */ _public_api__WEBPACK_IMPORTED_MODULE_0__.ClevertapEvent),
/* harmony export */   "GA4Event": () => (/* reexport safe */ _public_api__WEBPACK_IMPORTED_MODULE_0__.GA4Event),
/* harmony export */   "IconsList": () => (/* reexport safe */ _public_api__WEBPACK_IMPORTED_MODULE_0__.IconsList),
/* harmony export */   "NCRegexp": () => (/* reexport safe */ _public_api__WEBPACK_IMPORTED_MODULE_0__.NCRegexp),
/* harmony export */   "NCRegexpEnum": () => (/* reexport safe */ _public_api__WEBPACK_IMPORTED_MODULE_0__.NCRegexpEnum),
/* harmony export */   "NcActionBaseComponent": () => (/* reexport safe */ _public_api__WEBPACK_IMPORTED_MODULE_0__.NcActionBaseComponent),
/* harmony export */   "NcBaseElementComponent": () => (/* reexport safe */ _public_api__WEBPACK_IMPORTED_MODULE_0__.NcBaseElementComponent),
/* harmony export */   "NcBaseLabelComponent": () => (/* reexport safe */ _public_api__WEBPACK_IMPORTED_MODULE_0__.NcBaseLabelComponent),
/* harmony export */   "NcButtonActionComponent": () => (/* reexport safe */ _public_api__WEBPACK_IMPORTED_MODULE_0__.NcButtonActionComponent),
/* harmony export */   "NcComponentModule": () => (/* reexport safe */ _public_api__WEBPACK_IMPORTED_MODULE_0__.NcComponentModule),
/* harmony export */   "NcDropdownSelectComponent": () => (/* reexport safe */ _public_api__WEBPACK_IMPORTED_MODULE_0__.NcDropdownSelectComponent),
/* harmony export */   "NcFormControl": () => (/* reexport safe */ _public_api__WEBPACK_IMPORTED_MODULE_0__.NcFormControl),
/* harmony export */   "NcFormGroup": () => (/* reexport safe */ _public_api__WEBPACK_IMPORTED_MODULE_0__.NcFormGroup),
/* harmony export */   "NcFormfieldBaseComponent": () => (/* reexport safe */ _public_api__WEBPACK_IMPORTED_MODULE_0__.NcFormfieldBaseComponent),
/* harmony export */   "NcHyperlinkActionComponent": () => (/* reexport safe */ _public_api__WEBPACK_IMPORTED_MODULE_0__.NcHyperlinkActionComponent),
/* harmony export */   "NcIconActionComponent": () => (/* reexport safe */ _public_api__WEBPACK_IMPORTED_MODULE_0__.NcIconActionComponent),
/* harmony export */   "NcImgActionComponent": () => (/* reexport safe */ _public_api__WEBPACK_IMPORTED_MODULE_0__.NcImgActionComponent),
/* harmony export */   "NcInputKeyInComponent": () => (/* reexport safe */ _public_api__WEBPACK_IMPORTED_MODULE_0__.NcInputKeyInComponent),
/* harmony export */   "NcKeyinFormfieldComponent": () => (/* reexport safe */ _public_api__WEBPACK_IMPORTED_MODULE_0__.NcKeyinFormfieldComponent),
/* harmony export */   "NcMaterialModule": () => (/* reexport safe */ _public_api__WEBPACK_IMPORTED_MODULE_0__.NcMaterialModule),
/* harmony export */   "NcSelectFormfieldComponent": () => (/* reexport safe */ _public_api__WEBPACK_IMPORTED_MODULE_0__.NcSelectFormfieldComponent)
/* harmony export */ });
/* harmony import */ var _public_api__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./public-api */ 89201);



/***/ }),

/***/ 89201:
/*!********************************************************************!*\
  !*** ./projects/iris-ionic-library/src/lib/elements/public-api.ts ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ClevertapEvent": () => (/* reexport safe */ _src_interfaces_common_exposed_interface__WEBPACK_IMPORTED_MODULE_15__.ClevertapEvent),
/* harmony export */   "GA4Event": () => (/* reexport safe */ _src_interfaces_common_exposed_interface__WEBPACK_IMPORTED_MODULE_15__.GA4Event),
/* harmony export */   "IconsList": () => (/* reexport safe */ _src_interfaces_common_exposed_interface__WEBPACK_IMPORTED_MODULE_15__.IconsList),
/* harmony export */   "NCRegexp": () => (/* reexport safe */ _src_interfaces_common_exposed_interface__WEBPACK_IMPORTED_MODULE_15__.NCRegexp),
/* harmony export */   "NCRegexpEnum": () => (/* reexport safe */ _src_interfaces_common_exposed_interface__WEBPACK_IMPORTED_MODULE_15__.NCRegexpEnum),
/* harmony export */   "NcActionBaseComponent": () => (/* reexport safe */ _src_base_element_action_base_action_base_component__WEBPACK_IMPORTED_MODULE_1__.NcActionBaseComponent),
/* harmony export */   "NcBaseElementComponent": () => (/* reexport safe */ _src_base_element_base_element_component__WEBPACK_IMPORTED_MODULE_6__.NcBaseElementComponent),
/* harmony export */   "NcBaseLabelComponent": () => (/* reexport safe */ _src_base_label_base_label_component__WEBPACK_IMPORTED_MODULE_12__.NcBaseLabelComponent),
/* harmony export */   "NcButtonActionComponent": () => (/* reexport safe */ _src_base_element_action_base_button_action_button_action_component__WEBPACK_IMPORTED_MODULE_2__.NcButtonActionComponent),
/* harmony export */   "NcComponentModule": () => (/* reexport safe */ _src_components_module__WEBPACK_IMPORTED_MODULE_13__.NcComponentModule),
/* harmony export */   "NcDropdownSelectComponent": () => (/* reexport safe */ _src_base_element_formfield_base_select_formfield_dropdown_select_dropdown_select_component__WEBPACK_IMPORTED_MODULE_10__.NcDropdownSelectComponent),
/* harmony export */   "NcFormControl": () => (/* reexport safe */ _src_interfaces_common_classes__WEBPACK_IMPORTED_MODULE_14__.NcFormControl),
/* harmony export */   "NcFormGroup": () => (/* reexport safe */ _src_interfaces_common_classes__WEBPACK_IMPORTED_MODULE_14__.NcFormGroup),
/* harmony export */   "NcFormfieldBaseComponent": () => (/* reexport safe */ _src_base_element_formfield_base_formfield_base_component__WEBPACK_IMPORTED_MODULE_7__.NcFormfieldBaseComponent),
/* harmony export */   "NcHyperlinkActionComponent": () => (/* reexport safe */ _src_base_element_action_base_hyperlink_action_hyperlink_action_component__WEBPACK_IMPORTED_MODULE_3__.NcHyperlinkActionComponent),
/* harmony export */   "NcIconActionComponent": () => (/* reexport safe */ _src_base_element_action_base_icon_action_icon_action_component__WEBPACK_IMPORTED_MODULE_4__.NcIconActionComponent),
/* harmony export */   "NcImgActionComponent": () => (/* reexport safe */ _src_base_element_action_base_img_action_img_action_component__WEBPACK_IMPORTED_MODULE_5__.NcImgActionComponent),
/* harmony export */   "NcInputKeyInComponent": () => (/* reexport safe */ _src_base_element_formfield_base_keyin_formfield_input_keyin_input_keyin_component__WEBPACK_IMPORTED_MODULE_9__.NcInputKeyInComponent),
/* harmony export */   "NcKeyinFormfieldComponent": () => (/* reexport safe */ _src_base_element_formfield_base_keyin_formfield_formfield_keyin_component__WEBPACK_IMPORTED_MODULE_8__.NcKeyinFormfieldComponent),
/* harmony export */   "NcMaterialModule": () => (/* reexport safe */ _src_angular_material_module__WEBPACK_IMPORTED_MODULE_0__.NcMaterialModule),
/* harmony export */   "NcSelectFormfieldComponent": () => (/* reexport safe */ _src_base_element_formfield_base_select_formfield_select_formfield_component__WEBPACK_IMPORTED_MODULE_11__.NcSelectFormfieldComponent)
/* harmony export */ });
/* harmony import */ var _src_angular_material_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./src/angular-material.module */ 49952);
/* harmony import */ var _src_base_element_action_base_action_base_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./src/base-element/action-base/action-base.component */ 79444);
/* harmony import */ var _src_base_element_action_base_button_action_button_action_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./src/base-element/action-base/button-action/button-action.component */ 61464);
/* harmony import */ var _src_base_element_action_base_hyperlink_action_hyperlink_action_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./src/base-element/action-base/hyperlink-action/hyperlink-action.component */ 17087);
/* harmony import */ var _src_base_element_action_base_icon_action_icon_action_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./src/base-element/action-base/icon-action/icon-action.component */ 98288);
/* harmony import */ var _src_base_element_action_base_img_action_img_action_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./src/base-element/action-base/img-action/img-action.component */ 19410);
/* harmony import */ var _src_base_element_base_element_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./src/base-element/base-element.component */ 62807);
/* harmony import */ var _src_base_element_formfield_base_formfield_base_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./src/base-element/formfield-base/formfield-base.component */ 80918);
/* harmony import */ var _src_base_element_formfield_base_keyin_formfield_formfield_keyin_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./src/base-element/formfield-base/keyin-formfield/formfield-keyin.component */ 18638);
/* harmony import */ var _src_base_element_formfield_base_keyin_formfield_input_keyin_input_keyin_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./src/base-element/formfield-base/keyin-formfield/input-keyin/input-keyin.component */ 54214);
/* harmony import */ var _src_base_element_formfield_base_select_formfield_dropdown_select_dropdown_select_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./src/base-element/formfield-base/select-formfield/dropdown-select/dropdown-select.component */ 79006);
/* harmony import */ var _src_base_element_formfield_base_select_formfield_select_formfield_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./src/base-element/formfield-base/select-formfield/select-formfield.component */ 68519);
/* harmony import */ var _src_base_label_base_label_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./src/base-label/base-label.component */ 68041);
/* harmony import */ var _src_components_module__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./src/components.module */ 68200);
/* harmony import */ var _src_interfaces_common_classes__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./src/interfaces/common-classes */ 64893);
/* harmony import */ var _src_interfaces_common_exposed_interface__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./src/interfaces/common-exposed-interface */ 2748);
/* harmony import */ var _src_interfaces_common_interface__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./src/interfaces/common-interface */ 73895);
/*
 * Public API Surface sub-entry of iris-ionic-library
 * Make sure you don't have internal imports in the library, that point to the main iris-ionic-library/index.ts file of the lib.
 */



















/***/ }),

/***/ 49952:
/*!*************************************************************************************!*\
  !*** ./projects/iris-ionic-library/src/lib/elements/src/angular-material.module.ts ***!
  \*************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NcMaterialModule": () => (/* binding */ NcMaterialModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_material_datepicker__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/material/datepicker */ 5818);
/* harmony import */ var _angular_material_select__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/material/select */ 91434);
/* harmony import */ var _angular_material_stepper__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/material/stepper */ 7650);





let NcMaterialModule = class NcMaterialModule {
};
NcMaterialModule = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_1__.NgModule)({
        imports: [
            _angular_material_stepper__WEBPACK_IMPORTED_MODULE_2__.MatStepperModule,
            _angular_material_datepicker__WEBPACK_IMPORTED_MODULE_3__.MatDatepickerModule,
            _angular_material_select__WEBPACK_IMPORTED_MODULE_4__.MatSelectModule,
        ],
        exports: [
            _angular_material_stepper__WEBPACK_IMPORTED_MODULE_2__.MatStepperModule,
            _angular_material_datepicker__WEBPACK_IMPORTED_MODULE_3__.MatDatepickerModule,
            _angular_material_select__WEBPACK_IMPORTED_MODULE_4__.MatSelectModule,
        ],
    })
], NcMaterialModule);



/***/ }),

/***/ 79444:
/*!************************************************************************************************************!*\
  !*** ./projects/iris-ionic-library/src/lib/elements/src/base-element/action-base/action-base.component.ts ***!
  \************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NcActionBaseComponent": () => (/* binding */ NcActionBaseComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _action_base_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./action-base.component.html?ngResource */ 71944);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _awesome_cordova_plugins_clevertap_ngx__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @awesome-cordova-plugins/clevertap/ngx */ 45363);
/* harmony import */ var _awesome_cordova_plugins_firebase_analytics_ngx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @awesome-cordova-plugins/firebase-analytics/ngx */ 48852);
/* harmony import */ var iris_ionic_library_src_lib_shared__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! iris-ionic-library/src/lib/shared */ 6936);
/* harmony import */ var _base_element_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../base-element.component */ 62807);







let NcActionBaseComponent = class NcActionBaseComponent extends _base_element_component__WEBPACK_IMPORTED_MODULE_4__.NcBaseElementComponent {
    constructor() {
        super();
        this.elementClicked = new _angular_core__WEBPACK_IMPORTED_MODULE_5__.EventEmitter();
        this.firebaseAnalytics = iris_ionic_library_src_lib_shared__WEBPACK_IMPORTED_MODULE_3__.NcCommonUtils.getClass(_awesome_cordova_plugins_firebase_analytics_ngx__WEBPACK_IMPORTED_MODULE_2__.FirebaseAnalytics);
        this.clevertap = iris_ionic_library_src_lib_shared__WEBPACK_IMPORTED_MODULE_3__.NcCommonUtils.getClass(_awesome_cordova_plugins_clevertap_ngx__WEBPACK_IMPORTED_MODULE_1__.CleverTap);
    }
    ngOnInit() {
        // this.initBase();
    }
    onElementClicked(event) {
        if (this.config.preClickFunction) {
            this.config.preClickFunction();
        }
        if (this.config.elementClicked) {
            this.config.elementClicked(event);
        }
        if (this.config.postClickFunction) {
            this.config.postClickFunction();
        }
        this.elementClicked.emit(event);
    }
};
NcActionBaseComponent.ctorParameters = () => [];
NcActionBaseComponent.propDecorators = {
    config: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.Input }],
    elementClicked: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.Output }]
};
NcActionBaseComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: 'nc-action-base',
        template: _action_base_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
    })
], NcActionBaseComponent);



/***/ }),

/***/ 61464:
/*!****************************************************************************************************************************!*\
  !*** ./projects/iris-ionic-library/src/lib/elements/src/base-element/action-base/button-action/button-action.component.ts ***!
  \****************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NcButtonActionComponent": () => (/* binding */ NcButtonActionComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _button_action_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./button-action.component.html?ngResource */ 91770);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _action_base_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../action-base.component */ 79444);




let NcButtonActionComponent = class NcButtonActionComponent extends _action_base_component__WEBPACK_IMPORTED_MODULE_1__.NcActionBaseComponent {
    constructor() {
        super();
    }
    ngOnInit() {
        this.initBase(true);
    }
};
NcButtonActionComponent.ctorParameters = () => [];
NcButtonActionComponent.propDecorators = {
    config: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.Input }]
};
NcButtonActionComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.Component)({
        selector: 'nc-button-action',
        template: _button_action_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
    })
], NcButtonActionComponent);



/***/ }),

/***/ 17087:
/*!**********************************************************************************************************************************!*\
  !*** ./projects/iris-ionic-library/src/lib/elements/src/base-element/action-base/hyperlink-action/hyperlink-action.component.ts ***!
  \**********************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NcHyperlinkActionComponent": () => (/* binding */ NcHyperlinkActionComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _hyperlink_action_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./hyperlink-action.component.html?ngResource */ 87624);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _action_base_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../action-base.component */ 79444);




let NcHyperlinkActionComponent = class NcHyperlinkActionComponent extends _action_base_component__WEBPACK_IMPORTED_MODULE_1__.NcActionBaseComponent {
    constructor() {
        super();
    }
    ngOnInit() {
        this.initBase();
    }
};
NcHyperlinkActionComponent.ctorParameters = () => [];
NcHyperlinkActionComponent.propDecorators = {
    config: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.Input }]
};
NcHyperlinkActionComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.Component)({
        selector: 'nc-hyperlink-action',
        template: _hyperlink_action_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
    })
], NcHyperlinkActionComponent);



/***/ }),

/***/ 98288:
/*!************************************************************************************************************************!*\
  !*** ./projects/iris-ionic-library/src/lib/elements/src/base-element/action-base/icon-action/icon-action.component.ts ***!
  \************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NcIconActionComponent": () => (/* binding */ NcIconActionComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _icon_action_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./icon-action.component.html?ngResource */ 32680);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _action_base_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../action-base.component */ 79444);




let NcIconActionComponent = class NcIconActionComponent extends _action_base_component__WEBPACK_IMPORTED_MODULE_1__.NcActionBaseComponent {
    constructor() {
        super();
    }
    ngOnInit() {
        this.initBase();
    }
};
NcIconActionComponent.ctorParameters = () => [];
NcIconActionComponent.propDecorators = {
    config: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.Input }]
};
NcIconActionComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.Component)({
        selector: 'nc-icon-action',
        template: _icon_action_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
    })
], NcIconActionComponent);



/***/ }),

/***/ 19410:
/*!**********************************************************************************************************************!*\
  !*** ./projects/iris-ionic-library/src/lib/elements/src/base-element/action-base/img-action/img-action.component.ts ***!
  \**********************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NcImgActionComponent": () => (/* binding */ NcImgActionComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _img_action_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./img-action.component.html?ngResource */ 75068);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _action_base_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../action-base.component */ 79444);




let NcImgActionComponent = class NcImgActionComponent extends _action_base_component__WEBPACK_IMPORTED_MODULE_1__.NcActionBaseComponent {
    constructor() {
        super();
    }
    ngOnInit() {
        this.initBase();
    }
};
NcImgActionComponent.ctorParameters = () => [];
NcImgActionComponent.propDecorators = {
    config: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.Input }]
};
NcImgActionComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.Component)({
        selector: 'nc-img-action',
        template: _img_action_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
    })
], NcImgActionComponent);



/***/ }),

/***/ 62807:
/*!*************************************************************************************************!*\
  !*** ./projects/iris-ionic-library/src/lib/elements/src/base-element/base-element.component.ts ***!
  \*************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NcBaseElementComponent": () => (/* binding */ NcBaseElementComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _base_element_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./base-element.component.html?ngResource */ 36501);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var iris_ionic_library_src_lib_shared__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! iris-ionic-library/src/lib/shared */ 6936);
/* harmony import */ var _interfaces_common_classes__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../interfaces/common-classes */ 64893);





let NcBaseElementComponent = class NcBaseElementComponent {
    constructor() {
        this.config = {
            id: null,
            formGroup: null,
        };
        this.translationService = iris_ionic_library_src_lib_shared__WEBPACK_IMPORTED_MODULE_1__.NcCommonUtils.getClass(iris_ionic_library_src_lib_shared__WEBPACK_IMPORTED_MODULE_1__.NcTranslationService);
    }
    ngOnInit() {
        // this.initBase();
    }
    initBase(addToForm = false) {
        var _a, _b;
        if (addToForm) {
            if (iris_ionic_library_src_lib_shared__WEBPACK_IMPORTED_MODULE_1__.NcCommonUtils.isNotNull(this.config) && iris_ionic_library_src_lib_shared__WEBPACK_IMPORTED_MODULE_1__.NcCommonUtils.isNotNull((_a = this.config) === null || _a === void 0 ? void 0 : _a.id) && iris_ionic_library_src_lib_shared__WEBPACK_IMPORTED_MODULE_1__.NcCommonUtils.isNotNull((_b = this.config) === null || _b === void 0 ? void 0 : _b.formGroup)) {
                if (iris_ionic_library_src_lib_shared__WEBPACK_IMPORTED_MODULE_1__.NcCommonUtils.isNull(this.config.formGroup.get(this.config.id))) {
                    // any checking can be made
                    const formControl = new _interfaces_common_classes__WEBPACK_IMPORTED_MODULE_2__.NcFormControl(this.config.id, '', { updateOn: 'change' });
                    this.config.formGroup.addControl(this.config.id, formControl);
                }
                else {
                    //es lint can be implemented
                    console.error('You should add an id and formgroup to all of your components');
                }
            }
        }
    }
    getControl() {
        return this.config.formGroup.controls[this.config.id];
    }
};
NcBaseElementComponent.ctorParameters = () => [];
NcBaseElementComponent.propDecorators = {
    config: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.Input }]
};
NcBaseElementComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'nc-base-component',
        template: _base_element_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
    })
], NcBaseElementComponent);



/***/ }),

/***/ 80918:
/*!******************************************************************************************************************!*\
  !*** ./projects/iris-ionic-library/src/lib/elements/src/base-element/formfield-base/formfield-base.component.ts ***!
  \******************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NcFormfieldBaseComponent": () => (/* binding */ NcFormfieldBaseComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _formfield_base_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./formfield-base.component.html?ngResource */ 67552);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var iris_ionic_library_src_lib_shared__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! iris-ionic-library/src/lib/shared */ 6936);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs/operators */ 80823);
/* harmony import */ var _interfaces_common_exposed_interface__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../interfaces/common-exposed-interface */ 2748);
/* harmony import */ var _base_element_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../base-element.component */ 62807);








let NcFormfieldBaseComponent = class NcFormfieldBaseComponent extends _base_element_component__WEBPACK_IMPORTED_MODULE_3__.NcBaseElementComponent {
    constructor() {
        super();
        this.fieldValueChange = new _angular_core__WEBPACK_IMPORTED_MODULE_4__.EventEmitter();
    }
    ngOnInit() {
        // this.initBase();
    }
    initBase() {
        super.initBase(true);
        if (iris_ionic_library_src_lib_shared__WEBPACK_IMPORTED_MODULE_1__.NcCommonUtils.isNotNull(this.config.isRequired)) {
            this.addValidators([_angular_forms__WEBPACK_IMPORTED_MODULE_5__.Validators.required]);
        }
        this.getControl()
            .valueChanges.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_6__.debounceTime)(100))
            .subscribe((newValue) => {
            if (iris_ionic_library_src_lib_shared__WEBPACK_IMPORTED_MODULE_1__.NcCommonUtils.isNull(newValue)) {
                this.getControl().reset(null, { emitEvent: false });
            }
            if (!this.getControl().checkIfValidAndPopulate()) {
                if (iris_ionic_library_src_lib_shared__WEBPACK_IMPORTED_MODULE_1__.NcCommonUtils.isNotNull(this.config.listOfValues)) {
                    const tempValue = this.config.listOfValues.find((element) => {
                        return element.key == newValue;
                    });
                    newValue = tempValue;
                }
                this.onChange(newValue);
            }
            this.config.formGroup.fieldValueChange();
        });
        this.getControl().updateValueAndValidity({ emitEvent: false });
        if (this.config.formGroup.formGroupInit) {
            this.config.formGroup.formGroupInit();
        }
    }
    onChange($event) {
        if (this.config.fieldValueChange) {
            this.config.fieldValueChange($event);
        }
        this.fieldValueChange.emit({ value: $event });
        // this.config.formGroup.updateValueAndValidity();
    }
    addValidators(validator) {
        this.getControl().addValidators(validator);
    }
    getHintIcon(hint) {
        return {
            iconName: hint.error ? _interfaces_common_exposed_interface__WEBPACK_IMPORTED_MODULE_2__.IconsList.hintInValid : _interfaces_common_exposed_interface__WEBPACK_IMPORTED_MODULE_2__.IconsList.hintValid,
            id: hint.message,
            formGroup: this.config.formGroup,
        };
    }
};
NcFormfieldBaseComponent.ctorParameters = () => [];
NcFormfieldBaseComponent.propDecorators = {
    config: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_4__.Input }],
    fieldValueChange: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_4__.Output }]
};
NcFormfieldBaseComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'nc-formfield-base',
        template: _formfield_base_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
    })
], NcFormfieldBaseComponent);



/***/ }),

/***/ 18638:
/*!***********************************************************************************************************************************!*\
  !*** ./projects/iris-ionic-library/src/lib/elements/src/base-element/formfield-base/keyin-formfield/formfield-keyin.component.ts ***!
  \***********************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NcKeyinFormfieldComponent": () => (/* binding */ NcKeyinFormfieldComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _keyin_formfield_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./keyin-formfield.component.html?ngResource */ 81351);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _formfield_base_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../formfield-base.component */ 80918);




let NcKeyinFormfieldComponent = class NcKeyinFormfieldComponent extends _formfield_base_component__WEBPACK_IMPORTED_MODULE_1__.NcFormfieldBaseComponent {
    constructor() {
        super();
    }
    ngOnInit() {
        // this.initBase();
        this.addPatternValidator();
    }
    addPatternValidator() {
        this.getControl().createPatternValidatorFn(this.config.pattern);
    }
};
NcKeyinFormfieldComponent.ctorParameters = () => [];
NcKeyinFormfieldComponent.propDecorators = {
    config: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.Input }]
};
NcKeyinFormfieldComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.Component)({
        selector: 'nc-keyin-formfield',
        template: _keyin_formfield_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
    })
], NcKeyinFormfieldComponent);



/***/ }),

/***/ 54214:
/*!*******************************************************************************************************************************************!*\
  !*** ./projects/iris-ionic-library/src/lib/elements/src/base-element/formfield-base/keyin-formfield/input-keyin/input-keyin.component.ts ***!
  \*******************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NcInputKeyInComponent": () => (/* binding */ NcInputKeyInComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _input_keyin_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./input-keyin.component.html?ngResource */ 38947);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _formfield_base_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../formfield-base.component */ 80918);




let NcInputKeyInComponent = class NcInputKeyInComponent extends _formfield_base_component__WEBPACK_IMPORTED_MODULE_1__.NcFormfieldBaseComponent {
    constructor() {
        super();
    }
    ngOnInit() {
        this.initBase();
    }
};
NcInputKeyInComponent.ctorParameters = () => [];
NcInputKeyInComponent.propDecorators = {
    config: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.Input }]
};
NcInputKeyInComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.Component)({
        selector: 'nc-input-keyin',
        template: _input_keyin_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
    })
], NcInputKeyInComponent);



/***/ }),

/***/ 79006:
/*!****************************************************************************************************************************************************!*\
  !*** ./projects/iris-ionic-library/src/lib/elements/src/base-element/formfield-base/select-formfield/dropdown-select/dropdown-select.component.ts ***!
  \****************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NcDropdownSelectComponent": () => (/* binding */ NcDropdownSelectComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _dropdown_select_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./dropdown-select.component.html?ngResource */ 74534);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var iris_ionic_library_src_lib_shared__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! iris-ionic-library/src/lib/shared */ 6936);
/* harmony import */ var _select_formfield_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../select-formfield.component */ 68519);





let NcDropdownSelectComponent = class NcDropdownSelectComponent extends _select_formfield_component__WEBPACK_IMPORTED_MODULE_2__.NcSelectFormfieldComponent {
    constructor() {
        super();
    }
    ngOnInit() {
        this.initBase();
        this.initDDL();
    }
    initDDL() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            if (iris_ionic_library_src_lib_shared__WEBPACK_IMPORTED_MODULE_1__.NcCommonUtils.isNotNull(this.config.title)) {
                this.config.title = yield this.translationService.get(this.config.title).toPromise();
            }
            this.interfaceOptions = {
                buttons: [],
                cssClass: this.config.cssClass + ' action-sheet-ddl',
                header: this.config.title,
            };
        });
    }
};
NcDropdownSelectComponent.ctorParameters = () => [];
NcDropdownSelectComponent.propDecorators = {
    config: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_4__.Input }]
};
NcDropdownSelectComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'nc-dropdown-select',
        template: _dropdown_select_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
    })
], NcDropdownSelectComponent);



/***/ }),

/***/ 68519:
/*!*************************************************************************************************************************************!*\
  !*** ./projects/iris-ionic-library/src/lib/elements/src/base-element/formfield-base/select-formfield/select-formfield.component.ts ***!
  \*************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NcSelectFormfieldComponent": () => (/* binding */ NcSelectFormfieldComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _select_formfield_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./select-formfield.component.html?ngResource */ 40561);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _formfield_base_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../formfield-base.component */ 80918);




let NcSelectFormfieldComponent = class NcSelectFormfieldComponent extends _formfield_base_component__WEBPACK_IMPORTED_MODULE_1__.NcFormfieldBaseComponent {
    constructor() {
        super();
    }
    ngOnInit() {
        // this.initBase();
    }
};
NcSelectFormfieldComponent.ctorParameters = () => [];
NcSelectFormfieldComponent.propDecorators = {
    config: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.Input }]
};
NcSelectFormfieldComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.Component)({
        selector: 'nc-select-formfield',
        template: _select_formfield_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
    })
], NcSelectFormfieldComponent);



/***/ }),

/***/ 68041:
/*!*********************************************************************************************!*\
  !*** ./projects/iris-ionic-library/src/lib/elements/src/base-label/base-label.component.ts ***!
  \*********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NcBaseLabelComponent": () => (/* binding */ NcBaseLabelComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _base_label_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./base-label.component.html?ngResource */ 60993);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 3184);



let NcBaseLabelComponent = class NcBaseLabelComponent {
    constructor() {
        this.config = {};
    }
    ngOnInit() {
        this.config.resetLabel = (text) => {
            this.config.label = text;
        };
        this.config.resetAppendLabel = (text) => {
            this.config.appendLabel = text;
        };
    }
};
NcBaseLabelComponent.ctorParameters = () => [];
NcBaseLabelComponent.propDecorators = {
    config: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_1__.Input }]
};
NcBaseLabelComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_1__.Component)({
        selector: 'nc-base-label',
        template: _base_label_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
    })
], NcBaseLabelComponent);



/***/ }),

/***/ 68200:
/*!*******************************************************************************!*\
  !*** ./projects/iris-ionic-library/src/lib/elements/src/components.module.ts ***!
  \*******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NcComponentModule": () => (/* binding */ NcComponentModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var _angular_material_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./angular-material.module */ 49952);
/* harmony import */ var _base_element_action_base_action_base_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./base-element/action-base/action-base.component */ 79444);
/* harmony import */ var _base_element_action_base_button_action_button_action_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./base-element/action-base/button-action/button-action.component */ 61464);
/* harmony import */ var _base_element_action_base_hyperlink_action_hyperlink_action_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./base-element/action-base/hyperlink-action/hyperlink-action.component */ 17087);
/* harmony import */ var _base_element_action_base_icon_action_icon_action_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./base-element/action-base/icon-action/icon-action.component */ 98288);
/* harmony import */ var _base_element_action_base_img_action_img_action_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./base-element/action-base/img-action/img-action.component */ 19410);
/* harmony import */ var _base_element_base_element_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./base-element/base-element.component */ 62807);
/* harmony import */ var _base_element_formfield_base_formfield_base_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./base-element/formfield-base/formfield-base.component */ 80918);
/* harmony import */ var _base_element_formfield_base_keyin_formfield_formfield_keyin_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./base-element/formfield-base/keyin-formfield/formfield-keyin.component */ 18638);
/* harmony import */ var _base_element_formfield_base_keyin_formfield_input_keyin_input_keyin_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./base-element/formfield-base/keyin-formfield/input-keyin/input-keyin.component */ 54214);
/* harmony import */ var _base_element_formfield_base_select_formfield_dropdown_select_dropdown_select_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./base-element/formfield-base/select-formfield/dropdown-select/dropdown-select.component */ 79006);
/* harmony import */ var _base_element_formfield_base_select_formfield_select_formfield_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./base-element/formfield-base/select-formfield/select-formfield.component */ 68519);
/* harmony import */ var _base_label_base_label_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./base-label/base-label.component */ 68041);



















const myComponents = [
    //Base
    _base_element_base_element_component__WEBPACK_IMPORTED_MODULE_6__.NcBaseElementComponent,
    _base_label_base_label_component__WEBPACK_IMPORTED_MODULE_12__.NcBaseLabelComponent,
    //FormField
    _base_element_formfield_base_formfield_base_component__WEBPACK_IMPORTED_MODULE_7__.NcFormfieldBaseComponent,
    _base_element_formfield_base_keyin_formfield_formfield_keyin_component__WEBPACK_IMPORTED_MODULE_8__.NcKeyinFormfieldComponent,
    _base_element_formfield_base_select_formfield_select_formfield_component__WEBPACK_IMPORTED_MODULE_11__.NcSelectFormfieldComponent,
    _base_element_formfield_base_keyin_formfield_input_keyin_input_keyin_component__WEBPACK_IMPORTED_MODULE_9__.NcInputKeyInComponent,
    _base_element_formfield_base_select_formfield_dropdown_select_dropdown_select_component__WEBPACK_IMPORTED_MODULE_10__.NcDropdownSelectComponent,
    //Actions
    _base_element_action_base_action_base_component__WEBPACK_IMPORTED_MODULE_1__.NcActionBaseComponent,
    _base_element_action_base_button_action_button_action_component__WEBPACK_IMPORTED_MODULE_2__.NcButtonActionComponent,
    _base_element_action_base_img_action_img_action_component__WEBPACK_IMPORTED_MODULE_5__.NcImgActionComponent,
    _base_element_action_base_icon_action_icon_action_component__WEBPACK_IMPORTED_MODULE_4__.NcIconActionComponent,
    _base_element_action_base_hyperlink_action_hyperlink_action_component__WEBPACK_IMPORTED_MODULE_3__.NcHyperlinkActionComponent,
];
let NcComponentModule = class NcComponentModule {
};
NcComponentModule = (0,tslib__WEBPACK_IMPORTED_MODULE_13__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_14__.NgModule)({
        declarations: [
            ...myComponents,
        ],
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_15__.CommonModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_16__.IonicModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_17__.FormsModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_17__.ReactiveFormsModule,
            _ngx_translate_core__WEBPACK_IMPORTED_MODULE_18__.TranslateModule,
            // NcSharedModule,
            _angular_material_module__WEBPACK_IMPORTED_MODULE_0__.NcMaterialModule,
        ],
        exports: [
            ...myComponents,
        ],
        providers: [],
    })
], NcComponentModule);



/***/ }),

/***/ 64893:
/*!***************************************************************************************!*\
  !*** ./projects/iris-ionic-library/src/lib/elements/src/interfaces/common-classes.ts ***!
  \***************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NcFormControl": () => (/* binding */ NcFormControl),
/* harmony export */   "NcFormGroup": () => (/* binding */ NcFormGroup)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var iris_ionic_library_src_lib_shared__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! iris-ionic-library/src/lib/shared */ 6936);
/* harmony import */ var _common_exposed_interface__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./common-exposed-interface */ 2748);



class NcFormGroup extends _angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormGroup {
    validateForm() {
        Object.keys(this.controls).forEach((element) => {
            this.controls[element].markAsTouched({ onlySelf: true });
            this.controls[element].checkIfValidAndPopulate();
        });
    }
}
class NcFormControl extends _angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormControl {
    constructor(name, formState, validatorOrOpts, asyncValidator) {
        super(formState, validatorOrOpts);
        this.customValidators = {
            required: {
                message: 'validationSummary.required',
            },
        };
        this.hints = {};
        this.formControlName = name;
    }
    getNcValidationObject(object) {
        return Object.keys(object).map((elem) => {
            if (typeof object[elem] === 'object') {
                return object[elem];
            }
            else {
                return {
                    isHint: false,
                    message: this.customValidators[elem].message,
                    error: true,
                };
            }
        });
    }
    checkIfValidAndPopulate() {
        this.updateValueAndValidity({ emitEvent: false });
        return this.invalid;
    }
    getControlErrors() {
        if (this.isInvalid()) {
            return this.getNcValidationObject(this.errors);
        }
    }
    getControlHints() {
        // if (this.isInvalid()) {
        let totalNumber = Object.keys(this.hints).length;
        let hints = this.getNcValidationObject(this.hints);
        let invalidHints = Object.values(this.hints).filter((hint) => {
            return hint.error;
        }).length;
        let validHints = totalNumber - invalidHints;
        let validRatio = validHints / totalNumber;
        let invalidRatio = invalidHints / totalNumber;
        let currentProgress = 'progress33';
        if (validRatio <= 0.33) {
            currentProgress = 'progress33';
        }
        else if (validRatio > 0.33 && validRatio < 1) {
            currentProgress = 'progress66';
        }
        else {
            currentProgress = 'progress100';
        }
        return {
            totalNumber,
            hints,
            invalidHints,
            validHints,
            validRatio,
            invalidRatio,
            currentProgress,
        };
        // }
        // return { totalNumber: 0, hints: [], validHints: 0, invalidHints: 0, validRatio: 0, invalidRatio: 0 };
    }
    createPatternValidatorFn(patterns) {
        if (iris_ionic_library_src_lib_shared__WEBPACK_IMPORTED_MODULE_0__.NcCommonUtils.isNotNull(patterns)) {
            const validatorFN = () => {
                let err = {};
                if (this.dirty || this.touched) {
                    patterns.forEach((pattern) => {
                        const regex = _common_exposed_interface__WEBPACK_IMPORTED_MODULE_1__.NCRegexp[pattern.pattern].pattern;
                        const isHint = pattern.isHint;
                        const isValid = String(this.value).match(regex);
                        const errorObj = {
                            isHint,
                            message: _common_exposed_interface__WEBPACK_IMPORTED_MODULE_1__.NCRegexp[pattern.pattern].message,
                            error: !isValid,
                        };
                        delete this.hints[pattern.pattern];
                        if (isHint) {
                            this.hints[pattern.pattern] = errorObj;
                        }
                        if (errorObj.error) {
                            err[pattern.pattern] = errorObj;
                        }
                    });
                }
                return err;
            };
            this.addValidators(validatorFN);
        }
    }
    isInvalid() {
        return (this.dirty || this.touched) && this.invalid;
    }
}


/***/ }),

/***/ 2748:
/*!*************************************************************************************************!*\
  !*** ./projects/iris-ionic-library/src/lib/elements/src/interfaces/common-exposed-interface.ts ***!
  \*************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ClevertapEvent": () => (/* binding */ ClevertapEvent),
/* harmony export */   "GA4Event": () => (/* binding */ GA4Event),
/* harmony export */   "IconsList": () => (/* binding */ IconsList),
/* harmony export */   "NCRegexp": () => (/* binding */ NCRegexp),
/* harmony export */   "NCRegexpEnum": () => (/* binding */ NCRegexpEnum)
/* harmony export */ });
var IconsList;
(function (IconsList) {
    IconsList["password"] = "./assets/lib-svgs/password.svg";
    IconsList["showPassword"] = "./assets/lib-svgs/show-password.svg";
    IconsList["hidePassword"] = "./assets/lib-svgs/hide-password.svg";
    IconsList["email"] = "./assets/lib-svgs/email.svg";
    IconsList["language"] = "./assets/lib-svgs/language.svg";
    IconsList["back"] = "./assets/lib-svgs/back.svg";
    IconsList["hintValid"] = "./assets/lib-svgs/valid-hint.svg";
    IconsList["hintInValid"] = "./assets/lib-svgs/invalid-hint.svg";
})(IconsList || (IconsList = {}));
var GA4Event;
(function (GA4Event) {
    GA4Event["NA"] = "NA";
    // Onboarding
    GA4Event["OnboardingProceeded"] = "Onboarding_Proceeded";
    GA4Event["LanguageSelected"] = "Language_Selected";
    GA4Event["SignUpCompleted"] = "Sign_Up_Completed";
    GA4Event["SignUpFailed"] = "Sign_Up_Failed";
    GA4Event["EmailVerificationSkipped"] = "Email_Verification_Skipped";
    GA4Event["EmailVerificationStarted"] = "Email_Verification_Started";
    GA4Event["Email_erificationCompleted"] = "Email_Verification_Completed";
    GA4Event["LoginInitiated"] = "Login_Initiated";
    GA4Event["LoginCompleted"] = "Login_Completed";
    GA4Event["FaceIDLoginEnabled"] = "Face_ID_Login_Enabled";
    GA4Event["FaceIDLoginSkipped"] = "Face_ID_Login_Skipped";
    GA4Event["TouchIDLoginEnabled"] = "Touch_ID_Login_Enabled";
    GA4Event["TouchIDLoginSkipped"] = "Touch_ID_Login_Skipped";
    GA4Event["InsuranceConnectionInitiated"] = "Insurance_Connection_Initiated";
    GA4Event["InsuranceConnectionCompleted"] = "Insurance_Connection_Completed";
    GA4Event["PhoneNumberAdded"] = "Phone_Number_Added";
    // Account
    GA4Event["PasswordResetInitiated"] = "Password_Reset_Initiated";
    GA4Event["PasswordResetCompleted"] = "Password_Reset_Completed";
    GA4Event["AccountDeleted"] = "Account_Deleted";
    GA4Event["PasswordChangeInitiated"] = "Password_Change_Initiated";
    GA4Event["PasswordChangeCompleted"] = "Password_Change_Completed";
    GA4Event["AddressAdded"] = "Address_Added";
    GA4Event["AddressDeleted"] = "Address_Deleted";
    GA4Event["BankAccountAdded"] = "Bank_Account_Added";
    GA4Event["BankAccountDeleted"] = "Bank_Account_Deleted";
    GA4Event["MobileNumberVerified"] = "Mobile_Number_Verified";
    GA4Event["PolicySwitched"] = "Policy_Switched";
    GA4Event["NotificationsViewed"] = "Notifications_Viewed";
    // Navigation
    GA4Event["HomeNavigationChanged"] = "Home_Navigation_Changed";
    GA4Event["NeedHelpStarted"] = "Need_Help_Started";
    GA4Event["FacilityBookingSelected"] = "Facility_Booking_Selected";
    // Claims
    GA4Event["PreApprovalClaimInitiated"] = "Pre_Approval_Claim_Initiated";
    GA4Event["PreApprovalClaimDetailsConfirmed"] = "Pre_Approval_Claim_Details_Confirmed";
    GA4Event["PreApprovalClaimDocumentAdded"] = "Pre_Approval_Claim_Document_Added";
    GA4Event["PreApprovalClaimSubmitted"] = "Pre_Approval_Claim_Submitted";
    GA4Event["PreApprovalClaimReviewsubmitted"] = "Pre_Approval_Claim_Review_submitted";
    GA4Event["PreApprovalClaimDocumentAddedMissing"] = "Pre_Approval_Claim_Document_Added_missing";
    GA4Event["PreApprovalClaimSubmittedMissing"] = "Pre_Approval_Claim_Submitted_missing";
    GA4Event["ReimbursmentClaimInitiated"] = "Reimbursment_Claim_Initiated";
    GA4Event["ReimbursmentClaimDetailsConfirmed"] = "Reimbursment_Claim_Details_Confirmed";
    GA4Event["ReimbursmentClaimASOAPDocumentUploaded"] = "Reimbursment_Claim_ASOAP_Document_Uploaded";
    GA4Event["ReimbursmentClaimDSUploaded"] = "Reimbursment_Claim_DS_Uploaded";
    GA4Event["ReimbursmentClaimLRTUploaded"] = "Reimbursment_Claim_LRT_Uploaded";
    GA4Event["ReimbursmentClaimInvoiceUploaded"] = "Reimbursment_Claim_Invoice_Uploaded";
    GA4Event["ReimbursmentClaimAdditionalUploaded"] = "Reimbursment_Claim_Additional_Uploaded";
    GA4Event["ReimbursmentClaimDocumentAdded"] = "Reimbursment_Claim_Document_Added";
    GA4Event["ReimbursmentClaimPaymentMethodChosen"] = "Reimbursment_Claim_Payment_Method_Chosen";
    GA4Event["ReimbursmentClaimSubmitted"] = "Reimbursment_Claim_Submitted";
    GA4Event["ReimbursmentClaimMissingUploaded"] = "Reimbursment_Claim_Missing_Uploaded";
    GA4Event["ReimbursmentClaimDSUploadedMissing"] = "Reimbursment_Claim_DS_Uploaded_missing";
    GA4Event["ReimbursmentClaimASOAPDocumentUploadedMissing"] = "Reimbursment_Claim_ASOAP_Document_Uploaded_missing";
    // Sysmptom checker
    GA4Event["SymptomCheckerSelected"] = "Symptom_Checker_Selected";
    GA4Event["SymptomCheckerStarted"] = "Symptom_Checker_Started";
    GA4Event["SymptomCheckerBodyPartSelected"] = "Symptom_Checker_Body_Part_Selected";
    GA4Event["SymptomCheckerCompleted"] = "Symptom_Checker_Completed";
    GA4Event["SymptomCheckerResultsOpened"] = "Symptom_Checker_Results_Opened";
    GA4Event["InpersonAppointmentStarted"] = "Inperson_Appointment_Started";
    GA4Event["VideoCallDoctorStarted"] = "Video_Call_Doctor_Started";
    // Insurance Coverage
    GA4Event["ICCategorySelected"] = "IC_Category_Selected";
    GA4Event["ICInPatientBenefitSubcategorySelected"] = "IC_In_Patient_Benefit_Subcategory_Selected";
    GA4Event["ICOutPatientBenefitSubcategorySelected"] = "IC_Out_Patient_Benefit_Subcategory_Selected_Checker_Body_Part_Selected";
    GA4Event["ICDentalBenefitSubcategorySelected"] = "IC_Dental_Benefit_Subcategory_Selected";
    GA4Event["ICOpticalBenefitSubcategorySelected"] = "IC_Optical_Benefit_Subcategory_Selected";
    GA4Event["ICPolicyDetailsViewed"] = "IC_Policy_Details_Viewed";
    GA4Event["ICDocumentViewed"] = "IC_Document_Viewed";
    GA4Event["ICBenefitSearched"] = "IC_Benefit_Searched";
    GA4Event["ICSearchResultSelected"] = "IC_Search_Result_Selected";
    GA4Event["ICBookAnAppointmentStarted"] = "IC_Book_An_Appointment_Started";
    GA4Event["ICDentalBenefitSelected"] = "IC_Dental_Benefit_Selected";
    GA4Event["ICInPatientBenefitSelected"] = "IC_In_Patient_Benefit_Selected";
    GA4Event["ICOutPatientBenefitSelected"] = "IC_Out_Patient_Benefit_Selected";
    GA4Event["ICOpticalBenefitSelected"] = "IC_Optical_Benefit_Selected";
    GA4Event["ICOpticalPlanPurchased"] = "IC_Optical_Plan_Purchased";
    // Referral & Prescription
    GA4Event["ReferralandPrescriptionStarted"] = "Referral_Prescription_Started";
    GA4Event["ReferralDetailsViewed"] = "Referral_Details_Viewed";
    GA4Event["ReferralAppointmentBookingStarted"] = "Referral_Appointment_Booking_Started";
    GA4Event["PrescriptionDetailsViewed"] = "Prescription_Details_Viewed";
    GA4Event["PrescriptionOrderStarted"] = "Prescription_Order_Started";
})(GA4Event || (GA4Event = {}));
var ClevertapEvent;
(function (ClevertapEvent) {
    ClevertapEvent["NA"] = "NA";
    ClevertapEvent["registration_get_started"] = "registration_get_started";
    ClevertapEvent["registration_login"] = "registration_login";
    ClevertapEvent["registration_create_account"] = "registration_create_account";
    ClevertapEvent["registration_language_selection"] = "Registration_language_selection";
    ClevertapEvent["registration_need_help"] = "registration_need_help";
    ClevertapEvent["registration_verify_account"] = "registration_verify_account";
    ClevertapEvent["registration_resend_verify_link"] = "registration_resend_verify_link";
    ClevertapEvent["registration_verify_skip"] = "registration_verify_skip";
    ClevertapEvent["registration_verify_email"] = "registration_verify_email";
    ClevertapEvent["registration_connect_insurance"] = "registration_connect_insurance";
    ClevertapEvent["registration_connect_insurance_skip"] = "registration_connect_insurance_skip";
    ClevertapEvent["registration_verify_insurance"] = "registration_verify_insurance";
    ClevertapEvent["registration_verify_insurance_help"] = "registration_verify_insurance_help";
    ClevertapEvent["registration_insurance_country"] = "registration_insurance_country";
    ClevertapEvent["registration_insurance_added_add_another_card"] = "registration_insurance_added_add_another_card";
    ClevertapEvent["registration_insurance_added_show_benefits"] = "registration_insurance_added_show_benefits";
    ClevertapEvent["login_home_screen"] = "login_home_screen";
    ClevertapEvent["login_login_account"] = "login_login_account";
    ClevertapEvent["login_forgot_password"] = "login_forgot_password";
    ClevertapEvent["login_register"] = "login_register";
    ClevertapEvent["login_continue_as_guest"] = "login_continue_as_guest";
    ClevertapEvent["login_language_selection"] = "login_language_selection";
    ClevertapEvent["login_enable_face_id"] = "login_enable_face_id";
    ClevertapEvent["login_enable_face_id_skip"] = "login_enable_face_id_skip";
    ClevertapEvent["login_login_face_id_email"] = "login_login_face_id_email";
    ClevertapEvent["login_forgot_password_email_submit"] = "login_forgot_password_email_submit";
    ClevertapEvent["login_forgot_password_email_submit_help"] = "login_forgot_password_email_submit_help";
    ClevertapEvent["login_forgot_password_check_your_email"] = "login_forgot_password_check_your_email";
    ClevertapEvent["login_forgot_password_resend_link"] = "login_forgot_password_resend_link";
    ClevertapEvent["login_forgot_password_reset_password"] = "login_forgot_password_reset_password";
    ClevertapEvent["login_forgot_password_need_help"] = "login_forgot_password_need_help";
    ClevertapEvent["policy_coverage_search_benefits"] = "policy_coverage_search_benefits";
    ClevertapEvent["policy_coverage_home_screen_view_card"] = "policy_coverage_home_screen_view_card";
    ClevertapEvent["policy_coverage_home_screen_need_help"] = "policy_coverage_home_screen_need_help";
    ClevertapEvent["policy_coverage_home_screen_highlights"] = "policy_coverage_home_screen_highlights";
    ClevertapEvent["policy_coverage_home_screen_table_of_benefits"] = "policy_coverage_home_screen_table_of_benefits";
    ClevertapEvent["policy_coverage_home_screen_travel_certificate"] = "policy_coverage_home_screen_travel_certificate";
    ClevertapEvent["policy_coverage_home_screen_coi"] = "policy_coverage_home_screen_coi";
    ClevertapEvent["policy_coverage_home_screen_in_patient"] = "policy_coverage_home_screen_in_patient";
    ClevertapEvent["policy_coverage_home_screen_out_patient"] = "policy_coverage_home_screen_out_patient";
    ClevertapEvent["policy_coverage_home_screen_optical"] = "policy_coverage_home_screen_optical";
    ClevertapEvent["policy_coverage_home_screen_dental"] = "policy_coverage_home_screen_dental";
    ClevertapEvent["policy_coverage_home_screen_search_benefits"] = "policy_coverage_home_screen_search_benefits";
    ClevertapEvent["policy_coverage_home_screen_search_benefits_book_appointment"] = "policy_coverage_home_screen_search_benefits_book_appointment";
    ClevertapEvent["policy_coverage_home_screen_dental_benefits_benefits_list_selection"] = "policy_coverage_home_screen_dental_benefits_benefits_list_selection";
    ClevertapEvent["policy_coverage_dental_benefits_search_benefits_book_appointment"] = "policy_coverage_dental_benefits_search_benefits_book_appointment";
    ClevertapEvent["policy_coverage_dental_benefits_need_help"] = "policy_coverage_dental_benefits_need_help";
})(ClevertapEvent || (ClevertapEvent = {}));
// prettier-ignore
const NCRegexp = {
    REQUIRED: { pattern: /.{1,}/, message: 'validationSummary.required' },
    EMAIL: { pattern: /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/, message: 'validationSummary.email' },
    AT_LEAST_ONE_NUMBER: { pattern: /[0-9]/g, message: 'signup.atLeast1Number' },
    AT_LEAST_ONE_SYMBOL: { pattern: /[^A-Za-z 0-9]/g, message: 'signup.atLeast1Symbol' },
    AT_LEAST_8_CHARACTERS: { pattern: /.{8,}/, message: 'signup.atLeast8Charecters' },
    AT_LEAST_ONE_CAPITAL_CHARACTER: { pattern: /[A-Z]/g, message: 'signup.atLeast1CapitalLetter' },
};
var NCRegexpEnum;
(function (NCRegexpEnum) {
    NCRegexpEnum["REQUIRED"] = "REQUIRED";
    NCRegexpEnum["EMAIL"] = "EMAIL";
    NCRegexpEnum["AT_LEAST_ONE_NUMBER"] = "AT_LEAST_ONE_NUMBER";
    NCRegexpEnum["AT_LEAST_ONE_SYMBOL"] = "AT_LEAST_ONE_SYMBOL";
    NCRegexpEnum["AT_LEAST_8_CHARACTERS"] = "AT_LEAST_8_CHARACTERS";
    NCRegexpEnum["AT_LEAST_ONE_CAPITAL_CHARACTER"] = "AT_LEAST_ONE_CAPITAL_CHARACTER";
})(NCRegexpEnum || (NCRegexpEnum = {}));


/***/ }),

/***/ 73895:
/*!*****************************************************************************************!*\
  !*** ./projects/iris-ionic-library/src/lib/elements/src/interfaces/common-interface.ts ***!
  \*****************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);



/***/ }),

/***/ 43574:
/*!**************************************************************************!*\
  !*** ./projects/iris-ionic-library/src/lib/layouts/base-layout/index.ts ***!
  \**************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NcBaseLayoutComponent": () => (/* reexport safe */ _public_api__WEBPACK_IMPORTED_MODULE_0__.NcBaseLayoutComponent),
/* harmony export */   "NcBaseLayoutComponentModule": () => (/* reexport safe */ _public_api__WEBPACK_IMPORTED_MODULE_0__.NcBaseLayoutComponentModule)
/* harmony export */ });
/* harmony import */ var _public_api__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./public-api */ 79009);



/***/ }),

/***/ 79009:
/*!*******************************************************************************!*\
  !*** ./projects/iris-ionic-library/src/lib/layouts/base-layout/public-api.ts ***!
  \*******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NcBaseLayoutComponent": () => (/* reexport safe */ _src_base_layout_component__WEBPACK_IMPORTED_MODULE_0__.NcBaseLayoutComponent),
/* harmony export */   "NcBaseLayoutComponentModule": () => (/* reexport safe */ _src_base_layout_module__WEBPACK_IMPORTED_MODULE_2__.NcBaseLayoutComponentModule)
/* harmony export */ });
/* harmony import */ var _src_base_layout_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./src/base-layout.component */ 55602);
/* harmony import */ var _src_base_layout_interface__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./src/base-layout.interface */ 36953);
/* harmony import */ var _src_base_layout_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./src/base-layout.module */ 55469);
/*
 * Public API Surface sub-entry of iris-ionic-library
 * Make sure you don't have internal imports in the library, that point to the main iris-ionic-library/index.ts file of the lib.
 */





/***/ }),

/***/ 55602:
/*!**********************************************************************************************!*\
  !*** ./projects/iris-ionic-library/src/lib/layouts/base-layout/src/base-layout.component.ts ***!
  \**********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NcBaseLayoutComponent": () => (/* binding */ NcBaseLayoutComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _base_layout_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./base-layout.component.html?ngResource */ 96069);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var iris_ionic_library_src_lib_shared__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! iris-ionic-library/src/lib/shared */ 6936);




let NcBaseLayoutComponent = class NcBaseLayoutComponent {
    constructor() {
        this.config = {
            id: null,
            formGroup: null,
        };
        this.loadHeaderConfigs = false;
    }
    ngOnInit() {
        this.initComponent(this.compConfig);
    }
    initComponent(fromObject) {
        iris_ionic_library_src_lib_shared__WEBPACK_IMPORTED_MODULE_1__.NcCommonUtils.initComponent(this.config, fromObject);
        this.backButtonConfig = {
            id: 'back-button',
            label: 'forgotPassword.back',
            formGroup: this.config.formGroup,
        };
        this.navigateToNeedHelp = {
            id: 'signin.needHelp',
            label: 'signin.needHelp',
            formGroup: this.config.formGroup,
            pageHref: iris_ionic_library_src_lib_shared__WEBPACK_IMPORTED_MODULE_1__.Screens.InquiryBeforeLogin,
        };
        this.loadHeaderConfigs = true;
        // (this.config as IBaseLayoutElement).backupConfig = {};
        // NcCommonUtils.initComponent((this.config as IBaseLayoutElement).backupConfig, fromObject);
    }
};
NcBaseLayoutComponent.ctorParameters = () => [];
NcBaseLayoutComponent.propDecorators = {
    compConfig: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.Input }]
};
NcBaseLayoutComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.Component)({
        selector: 'nc-base-layout',
        template: _base_layout_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
    })
], NcBaseLayoutComponent);



/***/ }),

/***/ 36953:
/*!**********************************************************************************************!*\
  !*** ./projects/iris-ionic-library/src/lib/layouts/base-layout/src/base-layout.interface.ts ***!
  \**********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);



/***/ }),

/***/ 55469:
/*!*******************************************************************************************!*\
  !*** ./projects/iris-ionic-library/src/lib/layouts/base-layout/src/base-layout.module.ts ***!
  \*******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NcBaseLayoutComponentModule": () => (/* binding */ NcBaseLayoutComponentModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var iris_ionic_library_src_lib_elements__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! iris-ionic-library/src/lib/elements */ 43591);
/* harmony import */ var iris_ionic_library_src_lib_components_back_button__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! iris-ionic-library/src/lib/components/back-button */ 9578);
/* harmony import */ var iris_ionic_library_src_lib_components_navigation_hyperlink__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! iris-ionic-library/src/lib/components/navigation-hyperlink */ 69164);
/* harmony import */ var iris_ionic_library_src_lib_shared__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! iris-ionic-library/src/lib/shared */ 6936);
/* harmony import */ var _base_layout_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./base-layout.component */ 55602);







let NcBaseLayoutComponentModule = class NcBaseLayoutComponentModule {
};
NcBaseLayoutComponentModule = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.NgModule)({
        declarations: [
            _base_layout_component__WEBPACK_IMPORTED_MODULE_4__.NcBaseLayoutComponent,
        ],
        imports: [
            iris_ionic_library_src_lib_shared__WEBPACK_IMPORTED_MODULE_3__.NcSharedModule,
            iris_ionic_library_src_lib_elements__WEBPACK_IMPORTED_MODULE_0__.NcComponentModule,
            iris_ionic_library_src_lib_components_back_button__WEBPACK_IMPORTED_MODULE_1__.NcBackButtonComponentModule,
            iris_ionic_library_src_lib_components_navigation_hyperlink__WEBPACK_IMPORTED_MODULE_2__.NcNavigationHyperlinkModule,
        ],
        exports: [
            _base_layout_component__WEBPACK_IMPORTED_MODULE_4__.NcBaseLayoutComponent,
        ],
    })
], NcBaseLayoutComponentModule);



/***/ }),

/***/ 54261:
/*!**************************************************************************!*\
  !*** ./projects/iris-ionic-library/src/lib/layouts/form-layout/index.ts ***!
  \**************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NcFormLayoutComponent": () => (/* reexport safe */ _public_api__WEBPACK_IMPORTED_MODULE_0__.NcFormLayoutComponent),
/* harmony export */   "NcFormLayoutComponentModule": () => (/* reexport safe */ _public_api__WEBPACK_IMPORTED_MODULE_0__.NcFormLayoutComponentModule)
/* harmony export */ });
/* harmony import */ var _public_api__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./public-api */ 98656);



/***/ }),

/***/ 98656:
/*!*******************************************************************************!*\
  !*** ./projects/iris-ionic-library/src/lib/layouts/form-layout/public-api.ts ***!
  \*******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NcFormLayoutComponent": () => (/* reexport safe */ _src_form_layout_component__WEBPACK_IMPORTED_MODULE_0__.NcFormLayoutComponent),
/* harmony export */   "NcFormLayoutComponentModule": () => (/* reexport safe */ _src_form_layout_module__WEBPACK_IMPORTED_MODULE_2__.NcFormLayoutComponentModule)
/* harmony export */ });
/* harmony import */ var _src_form_layout_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./src/form-layout.component */ 38454);
/* harmony import */ var _src_form_layout_interface__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./src/form-layout.interface */ 48931);
/* harmony import */ var _src_form_layout_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./src/form-layout.module */ 75687);
/*
 * Public API Surface sub-entry of iris-ionic-library
 * Make sure you don't have internal imports in the library, that point to the main iris-ionic-library/index.ts file of the lib.
 */





/***/ }),

/***/ 38454:
/*!**********************************************************************************************!*\
  !*** ./projects/iris-ionic-library/src/lib/layouts/form-layout/src/form-layout.component.ts ***!
  \**********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NcFormLayoutComponent": () => (/* binding */ NcFormLayoutComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _form_layout_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./form-layout.component.html?ngResource */ 96814);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var iris_ionic_library_src_lib_layouts_base_layout__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! iris-ionic-library/src/lib/layouts/base-layout */ 43574);




let NcFormLayoutComponent = class NcFormLayoutComponent extends iris_ionic_library_src_lib_layouts_base_layout__WEBPACK_IMPORTED_MODULE_1__.NcBaseLayoutComponent {
    constructor() {
        super();
    }
    ngOnInit() {
        this.initComponent(this.compConfig);
    }
};
NcFormLayoutComponent.ctorParameters = () => [];
NcFormLayoutComponent.propDecorators = {
    compConfig: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.Input }]
};
NcFormLayoutComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.Component)({
        selector: 'nc-form-layout',
        template: _form_layout_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
    })
], NcFormLayoutComponent);



/***/ }),

/***/ 48931:
/*!**********************************************************************************************!*\
  !*** ./projects/iris-ionic-library/src/lib/layouts/form-layout/src/form-layout.interface.ts ***!
  \**********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);



/***/ }),

/***/ 75687:
/*!*******************************************************************************************!*\
  !*** ./projects/iris-ionic-library/src/lib/layouts/form-layout/src/form-layout.module.ts ***!
  \*******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NcFormLayoutComponentModule": () => (/* binding */ NcFormLayoutComponentModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var iris_ionic_library_src_lib_components_submit_button__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! iris-ionic-library/src/lib/components/submit-button */ 25456);
/* harmony import */ var iris_ionic_library_src_lib_elements__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! iris-ionic-library/src/lib/elements */ 43591);
/* harmony import */ var iris_ionic_library_src_lib_shared__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! iris-ionic-library/src/lib/shared */ 6936);
/* harmony import */ var iris_ionic_library_src_lib_layouts_base_layout__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! iris-ionic-library/src/lib/layouts/base-layout */ 43574);
/* harmony import */ var _form_layout_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./form-layout.component */ 38454);







let NcFormLayoutComponentModule = class NcFormLayoutComponentModule {
};
NcFormLayoutComponentModule = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.NgModule)({
        declarations: [
            _form_layout_component__WEBPACK_IMPORTED_MODULE_4__.NcFormLayoutComponent,
        ],
        imports: [
            iris_ionic_library_src_lib_shared__WEBPACK_IMPORTED_MODULE_2__.NcSharedModule,
            iris_ionic_library_src_lib_elements__WEBPACK_IMPORTED_MODULE_1__.NcComponentModule,
            iris_ionic_library_src_lib_layouts_base_layout__WEBPACK_IMPORTED_MODULE_3__.NcBaseLayoutComponentModule,
            iris_ionic_library_src_lib_components_submit_button__WEBPACK_IMPORTED_MODULE_0__.NcButtonSubmitModule,
        ],
        exports: [
            _form_layout_component__WEBPACK_IMPORTED_MODULE_4__.NcFormLayoutComponent,
        ],
    })
], NcFormLayoutComponentModule);



/***/ }),

/***/ 13234:
/*!***********************************************************************************!*\
  !*** ./src/app/pages/edit-profile/change-passwords/change-passwords.component.ts ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ChangePasswordComponent": () => (/* binding */ ChangePasswordComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _change_passwords_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./change-passwords.component.html?ngResource */ 81239);
/* harmony import */ var _change_passwords_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./change-passwords.component.scss?ngResource */ 76570);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @ionic/storage-angular */ 80190);
/* harmony import */ var src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/shared/data/enum/screen */ 68302);
/* harmony import */ var src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/shared/data/constants */ 74676);
/* harmony import */ var src_app_shared_data_enum_platform__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/shared/data/enum/platform */ 8760);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var src_app_model_control_control_model__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/model/control/control.model */ 45482);
/* harmony import */ var src_app_shared_components_nextgen_dialog_nextgen_dialog_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/shared/components/nextgen-dialog/nextgen-dialog.service */ 96485);
/* harmony import */ var _confirm_changed_confirm_changed_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./confirm-changed/confirm-changed.component */ 96672);
/* harmony import */ var _awesome_cordova_plugins_firebase_analytics_ngx__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @awesome-cordova-plugins/firebase-analytics/ngx */ 48852);
/* harmony import */ var src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/shared/data/enum/event */ 38570);
/* harmony import */ var _awesome_cordova_plugins_clevertap_ngx__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @awesome-cordova-plugins/clevertap/ngx */ 45363);
/* harmony import */ var src_app_service_profile_edit_profile_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/app/service/profile/edit-profile.service */ 85307);
/* harmony import */ var src_app_service_utilities_third_party_service__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! src/app/service/utilities/third-party.service */ 47617);
/* harmony import */ var _service_signin_signin_service__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../../service/signin/signin.service */ 91265);
/* harmony import */ var src_app_service_insurance_insurance_service__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! src/app/service/insurance/insurance.service */ 57072);





















let ChangePasswordComponent = class ChangePasswordComponent {
    constructor(router, storage, navCtrl, dialogService, fb, firebaseAnalytics, clevertap, editProfileService, thirPartyService, signInService, insuranceService, platform) {
        this.router = router;
        this.storage = storage;
        this.navCtrl = navCtrl;
        this.dialogService = dialogService;
        this.fb = fb;
        this.firebaseAnalytics = firebaseAnalytics;
        this.clevertap = clevertap;
        this.editProfileService = editProfileService;
        this.thirPartyService = thirPartyService;
        this.signInService = signInService;
        this.insuranceService = insuranceService;
        this.platform = platform;
        this.TYPE = src_app_model_control_control_model__WEBPACK_IMPORTED_MODULE_5__.ControlType; //type input control
        this.showPassword = false; //status password(hide=false/show)
        this.showCurrentPassword = false;
        this.isMobileApp = false;
        this.needHelp = false;
        this.progressPassword = {
            key: 'error',
            progress: '0%'
        };
        this.isProgressBarPassword = false; // status progressbar control password (hide=false/show)
        this.isProgressBarChanegePassword = true;
        this.secondIconPassword = 'uil uil-eye-slash';
        this.secondIconCurrentPassword = 'uil uil-eye-slash';
        this.typeInputPassword = this.TYPE.PASSWORD;
        this.typeInputCurrentPassword = this.TYPE.PASSWORD;
        this.messageValidations = [
            {
                key: 'leastOneNumber',
                text: 'signup.atLeast1Number'
            },
            {
                key: 'specialCharacters',
                text: 'signup.atLeast1Symbol'
            },
            {
                key: 'leastCharecters',
                text: 'changePassword.atLeast8Characters'
            },
            {
                key: 'leastOneCap',
                text: 'signup.atLeast1CapitalLetter'
            }
        ];
        // Build formGroup
        this.changePasswordForm = this.fb.group({
            password: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_15__.Validators.required, this.passwordValidation()]],
            currentPassword: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_15__.Validators.required]],
        });
        this.loadPlatformInformation();
        this.firebaseAnalytics.logEvent(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_9__.GA4Event.PasswordChangeInitiated, {});
        this.clevertap.recordEventWithName(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_9__.GA4Event.PasswordChangeInitiated);
    }
    ngOnInit() {
        this.needHelp = this.insuranceService.checkPayerSetting(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_3__.Constants.ENABLE_Member_Inquiry, true);
    }
    ionViewDidEnter() {
        this.subscription = this.platform.backButton.subscribeWithPriority(9999, () => (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__awaiter)(this, void 0, void 0, function* () {
            this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__.Screens.EditProfile]);
        }));
    }
    ionViewWillLeave() {
        this.subscription.unsubscribe();
    }
    loadPlatformInformation() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__awaiter)(this, void 0, void 0, function* () {
            const platform = yield this.storage.get(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_3__.Constants.PLATFORM);
            if (platform == src_app_shared_data_enum_platform__WEBPACK_IMPORTED_MODULE_4__.PlatformEnum.Mobile) {
                this.isMobileApp = true;
            }
        });
    }
    passwordValidation() {
        return (control) => {
            const val = control.value;
            const err = {};
            if (!String(val).match(/[0-9]/g)) {
                err.leastOneNumber = true;
            }
            // eslint-disable-next-line no-useless-escape
            if (!String(val).match(/[\!\@\#\_\$\+\%\-]/g)) {
                err.specialCharacters = true;
            }
            if (String(val).length < 8) {
                err.leastCharecters = true;
            }
            if (!String(val).match(/[A-Z]/g)) {
                err.leastOneCap = true;
            }
            const errorCount = Object.keys(err).length;
            if (errorCount > 2) {
                this.progressPassword = {
                    key: 'error',
                    progress: '10%'
                };
            }
            else if (errorCount == 0) {
                this.progressPassword = {
                    key: 'success',
                    progress: '100%'
                };
            }
            else {
                this.progressPassword = {
                    key: 'warning',
                    progress: '50%'
                };
            }
            return err;
        };
    }
    verifyPass(key) {
        const errors = this.changePasswordForm.controls['password'].errors;
        if (Object.keys(errors).findIndex(e => e === key) === -1) {
            return true;
        }
        else {
            return false;
        }
    }
    togglePassword() {
        this.showPassword = !this.showPassword;
        if (this.showPassword) {
            this.typeInputPassword = this.TYPE.INPUT;
            this.secondIconPassword = 'uil uil-eye';
        }
        else {
            this.typeInputPassword = this.TYPE.PASSWORD;
            this.secondIconPassword = 'uil uil-eye-slash';
        }
    }
    toggleCurrentPassword() {
        this.showCurrentPassword = !this.showCurrentPassword;
        if (this.showCurrentPassword) {
            this.typeInputCurrentPassword = this.TYPE.INPUT;
            this.secondIconCurrentPassword = 'uil uil-eye';
        }
        else {
            this.typeInputCurrentPassword = this.TYPE.PASSWORD;
            this.secondIconCurrentPassword = 'uil uil-eye-slash';
        }
    }
    onBack() {
        this.navCtrl.back();
    }
    redirectToNeedHelp() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__awaiter)(this, void 0, void 0, function* () {
            this.thirPartyService.openLiveChat('ChangePassword');
        });
    }
    onFocusPasswordControl() {
        this.isProgressBarPassword = true;
    }
    confirmChangePassword() {
        const model = {
            oldPassword: this.changePasswordForm.controls['currentPassword'].value,
            newPassword: this.changePasswordForm.controls['password'].value
        };
        this.editProfileService.updateNewPassword(model).subscribe((_) => {
            this.dialogService.open(_confirm_changed_confirm_changed_component__WEBPACK_IMPORTED_MODULE_7__.ConfirmChangedComponent, {
                position: 'middle',
                height: '352px',
                width: '90%',
                canClose: true
            })
                .afterClosed()
                .subscribe((isYes) => {
                if (isYes) {
                    window.localStorage.setItem(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_3__.Constants.PASSWORD, model.newPassword);
                    // const user = this.signInService.getBiomatricInfo();
                    // NativeBiometric.setCredentials({
                    //   username: user.email,
                    //   password: model.newPassword,
                    //   server: window.location.hostname,
                    // }).then();
                    // Add this to subcribe when integrate password change
                    this.firebaseAnalytics.logEvent(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_9__.GA4Event.PasswordChangeCompleted, {});
                    this.clevertap.recordEventWithName(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_9__.GA4Event.PasswordChangeCompleted);
                }
                this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__.Screens.EditProfile]);
            });
        });
    }
};
ChangePasswordComponent.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_17__.Router },
    { type: _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_18__.Storage },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_19__.NavController },
    { type: src_app_shared_components_nextgen_dialog_nextgen_dialog_service__WEBPACK_IMPORTED_MODULE_6__.DialogService },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_15__.FormBuilder },
    { type: _awesome_cordova_plugins_firebase_analytics_ngx__WEBPACK_IMPORTED_MODULE_8__.FirebaseAnalytics },
    { type: _awesome_cordova_plugins_clevertap_ngx__WEBPACK_IMPORTED_MODULE_10__.CleverTap },
    { type: src_app_service_profile_edit_profile_service__WEBPACK_IMPORTED_MODULE_11__.EditProfileService },
    { type: src_app_service_utilities_third_party_service__WEBPACK_IMPORTED_MODULE_12__.ThirdPartyService },
    { type: _service_signin_signin_service__WEBPACK_IMPORTED_MODULE_13__.SigninService },
    { type: src_app_service_insurance_insurance_service__WEBPACK_IMPORTED_MODULE_14__.InsuranceService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_19__.Platform }
];
ChangePasswordComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_20__.Component)({
        selector: 'app-change-passwords',
        template: _change_passwords_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_change_passwords_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], ChangePasswordComponent);



/***/ }),

/***/ 96672:
/*!**************************************************************************************************!*\
  !*** ./src/app/pages/edit-profile/change-passwords/confirm-changed/confirm-changed.component.ts ***!
  \**************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ConfirmChangedComponent": () => (/* binding */ ConfirmChangedComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _confirm_changed_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./confirm-changed.component.html?ngResource */ 27048);
/* harmony import */ var _confirm_changed_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./confirm-changed.component.scss?ngResource */ 11076);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var src_app_shared_components_nextgen_dialog_nextgen_dialog_ref__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/shared/components/nextgen-dialog/nextgen-dialog-ref */ 99922);





let ConfirmChangedComponent = class ConfirmChangedComponent {
    constructor(dialogRef) {
        this.dialogRef = dialogRef;
    }
    ngOnInit() {
    }
    onClose(isYes) {
        this.dialogRef.close(isYes);
    }
};
ConfirmChangedComponent.ctorParameters = () => [
    { type: src_app_shared_components_nextgen_dialog_nextgen_dialog_ref__WEBPACK_IMPORTED_MODULE_2__.NextgenDialogRef }
];
ConfirmChangedComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-confirm-changed',
        template: _confirm_changed_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_confirm_changed_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], ConfirmChangedComponent);



/***/ }),

/***/ 59094:
/*!*******************************************************************!*\
  !*** ./src/app/pages/edit-profile/edit-profile-routing.module.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EditProfilePageRoutingModule": () => (/* binding */ EditProfilePageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _saved_address_saved_address_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./saved-address/saved-address.page */ 73208);
/* harmony import */ var _edit_profile_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./edit-profile.page */ 11847);
/* harmony import */ var _update_phone_number_update_phone_number_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./update-phone-number/update-phone-number.component */ 26772);
/* harmony import */ var _change_passwords_change_passwords_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./change-passwords/change-passwords.component */ 13234);







const routes = [
    {
        path: '',
        component: _edit_profile_page__WEBPACK_IMPORTED_MODULE_1__.EditProfilePage
    },
    {
        path: 'saved-address',
        component: _saved_address_saved_address_page__WEBPACK_IMPORTED_MODULE_0__.SavedAddressPage,
    },
    {
        path: 'update-phone-number',
        component: _update_phone_number_update_phone_number_component__WEBPACK_IMPORTED_MODULE_2__.UpdatePhoneNumberComponent,
    },
    {
        path: 'change-passwords',
        component: _change_passwords_change_passwords_component__WEBPACK_IMPORTED_MODULE_3__.ChangePasswordComponent,
    },
];
let EditProfilePageRoutingModule = class EditProfilePageRoutingModule {
};
EditProfilePageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_6__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_6__.RouterModule]
    })
], EditProfilePageRoutingModule);



/***/ }),

/***/ 60483:
/*!***********************************************************!*\
  !*** ./src/app/pages/edit-profile/edit-profile.module.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EditProfilePageModule": () => (/* binding */ EditProfilePageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _edit_profile_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./edit-profile.page */ 11847);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/shared/shared.module */ 44466);
/* harmony import */ var _angular_material_expansion__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/material/expansion */ 12928);
/* harmony import */ var _edit_profile_routing_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./edit-profile-routing.module */ 59094);
/* harmony import */ var _update_phone_number_update_phone_number_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./update-phone-number/update-phone-number.component */ 26772);
/* harmony import */ var _saved_address_saved_address_page__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./saved-address/saved-address.page */ 73208);
/* harmony import */ var _change_passwords_confirm_changed_confirm_changed_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./change-passwords/confirm-changed/confirm-changed.component */ 96672);
/* harmony import */ var iris_ionic_library_components_header_label__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! iris-ionic-library/components/header-label */ 30679);
/* harmony import */ var iris_ionic_library_components_password_input__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! iris-ionic-library/components/password-input */ 52748);
/* harmony import */ var iris_ionic_library_layouts_form_layout__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! iris-ionic-library/layouts/form-layout */ 54261);
/* harmony import */ var iris_ionic_library_shared__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! iris-ionic-library/shared */ 6936);
/* harmony import */ var _change_passwords_change_passwords_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./change-passwords/change-passwords.component */ 13234);

















let EditProfilePageModule = class EditProfilePageModule {
};
EditProfilePageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_11__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_12__.NgModule)({
        declarations: [
            _edit_profile_page__WEBPACK_IMPORTED_MODULE_0__.EditProfilePage,
            _update_phone_number_update_phone_number_component__WEBPACK_IMPORTED_MODULE_3__.UpdatePhoneNumberComponent,
            _saved_address_saved_address_page__WEBPACK_IMPORTED_MODULE_4__.SavedAddressPage,
            _change_passwords_change_passwords_component__WEBPACK_IMPORTED_MODULE_10__.ChangePasswordComponent,
            _change_passwords_confirm_changed_confirm_changed_component__WEBPACK_IMPORTED_MODULE_5__.ConfirmChangedComponent,
        ],
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_13__.CommonModule,
            _edit_profile_routing_module__WEBPACK_IMPORTED_MODULE_2__.EditProfilePageRoutingModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_14__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_15__.IonicModule,
            src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_1__.SharedModule,
            _angular_material_expansion__WEBPACK_IMPORTED_MODULE_16__.MatExpansionModule,
            iris_ionic_library_shared__WEBPACK_IMPORTED_MODULE_9__.NcSharedModule,
            iris_ionic_library_layouts_form_layout__WEBPACK_IMPORTED_MODULE_8__.NcFormLayoutComponentModule,
            iris_ionic_library_components_password_input__WEBPACK_IMPORTED_MODULE_7__.NcPasswordInputComponentModule,
            iris_ionic_library_components_header_label__WEBPACK_IMPORTED_MODULE_6__.NcHeaderLabelModule,
        ],
    })
], EditProfilePageModule);



/***/ }),

/***/ 11847:
/*!*********************************************************!*\
  !*** ./src/app/pages/edit-profile/edit-profile.page.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EditProfilePage": () => (/* binding */ EditProfilePage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _edit_profile_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./edit-profile.page.html?ngResource */ 68598);
/* harmony import */ var _edit_profile_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./edit-profile.page.scss?ngResource */ 72545);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var src_app_model_control_control_model__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/model/control/control.model */ 45482);
/* harmony import */ var src_app_shared_components_nextgen_dialog_nextgen_dialog_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/shared/components/nextgen-dialog/nextgen-dialog.service */ 96485);
/* harmony import */ var src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/shared/data/enum/screen */ 68302);
/* harmony import */ var src_app_service_profile_edit_profile_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/service/profile/edit-profile.service */ 85307);
/* harmony import */ var src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/shared/data/constants */ 74676);
/* harmony import */ var src_app_service_signin_signin_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/service/signin/signin.service */ 91265);
/* harmony import */ var capacitor_native_biometric__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! capacitor-native-biometric */ 31506);
/* harmony import */ var _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! @ionic/storage-angular */ 80190);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _awesome_cordova_plugins_firebase_analytics_ngx__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @awesome-cordova-plugins/firebase-analytics/ngx */ 48852);
/* harmony import */ var src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/app/shared/data/enum/event */ 38570);
/* harmony import */ var _awesome_cordova_plugins_clevertap_ngx__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @awesome-cordova-plugins/clevertap/ngx */ 45363);
/* harmony import */ var src_app_service_new_claim_upload_document_upload_document_service__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! src/app/service/new-claim/upload-document/upload-document.service */ 66848);
/* harmony import */ var src_app_service_user_user_service__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! src/app/service/user/user.service */ 87746);
/* harmony import */ var src_app_shared_components_alert_delete_alert_delete_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! src/app/shared/components/alert-delete/alert-delete.component */ 98887);
/* harmony import */ var src_app_shared_components_alert_enter_password_alert_enter_password_component__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! src/app/shared/components/alert-enter-password/alert-enter-password.component */ 57866);
/* harmony import */ var src_app_shared_data_enum_login_type__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! src/app/shared/data/enum/login-type */ 3674);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var src_app_shared_components_popup_message_popup_message_component__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! src/app/shared/components/popup-message/popup-message.component */ 18290);
/* harmony import */ var _update_phone_number_update_phone_number_component__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ./update-phone-number/update-phone-number.component */ 26772);
/* harmony import */ var _new_claim_upload_detail_upload_documents_upload_documents_component__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ../new-claim/upload-detail/upload-documents/upload-documents.component */ 89883);
/* harmony import */ var src_app_service_insurance_insurance_service__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! src/app/service/insurance/insurance.service */ 57072);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! rxjs/operators */ 85921);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! rxjs/operators */ 59095);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! rxjs */ 92218);
/* harmony import */ var src_app_shared_components_camera_review_confirm_image_dialog_confirm_image_dialog_component__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! src/app/shared/components/camera-review/confirm-image-dialog/confirm-image-dialog.component */ 1998);
/* harmony import */ var src_app_service_utilities_camera_service__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! src/app/service/utilities/camera.service */ 18855);
/* harmony import */ var src_app_providers_api_api_service__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! src/app/providers/api/api.service */ 57985);

































let EditProfilePage = class EditProfilePage {
    constructor(location, navCtrl, menu, dialogSevice, editProfileService, platform, signinService, storage, router, modalCtrl, firebaseAnalytics, clevertap, uploadDocumentService, userService, cdr, fb, insuranceService, cameraService, apiService) {
        this.location = location;
        this.navCtrl = navCtrl;
        this.menu = menu;
        this.dialogSevice = dialogSevice;
        this.editProfileService = editProfileService;
        this.platform = platform;
        this.signinService = signinService;
        this.storage = storage;
        this.router = router;
        this.modalCtrl = modalCtrl;
        this.firebaseAnalytics = firebaseAnalytics;
        this.clevertap = clevertap;
        this.uploadDocumentService = uploadDocumentService;
        this.userService = userService;
        this.cdr = cdr;
        this.fb = fb;
        this.insuranceService = insuranceService;
        this.cameraService = cameraService;
        this.apiService = apiService;
        this.TYPE = src_app_model_control_control_model__WEBPACK_IMPORTED_MODULE_2__.ControlType;
        this.phoneNumber = '+9751 55 2252 204';
        this.displayBank = false;
        this.displayCheque = false;
        this.unsubscribe$ = new rxjs__WEBPACK_IMPORTED_MODULE_24__.Subject();
        this.profileForm = this.fb.group({
            firstName: [''],
            lastName: ['']
        });
    }
    ionViewWillEnter() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_25__.__awaiter)(this, void 0, void 0, function* () {
            this.initEditProfilePage();
        });
    }
    ionViewDidEnter() {
        this.subscription = this.platform.backButton.subscribeWithPriority(9999, () => (0,tslib__WEBPACK_IMPORTED_MODULE_25__.__awaiter)(this, void 0, void 0, function* () {
            if (this.showEditName == true) {
                this.showEditName = false;
            }
            else {
                this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_4__.Screens.Home]);
                this.menu.open('profile-menu');
            }
        }));
    }
    ionViewWillLeave() {
        this.unsubscribe$.next();
        this.unsubscribe$.complete();
        this.subscription.unsubscribe();
    }
    ngOnInit() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_25__.__awaiter)(this, void 0, void 0, function* () {
            this.userService.getUserProfileValue().subscribe(res => {
                this.userImage = res;
                this.cdr.detectChanges();
            });
            if (!this.userImage) {
                this.userImage = yield this.storage.get(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_6__.Constants.USER_IMAGE);
            }
        });
    }
    initEditProfilePage() {
        this.insuranceService.getPolicyInformation().pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_26__.takeUntil)(this.unsubscribe$)).subscribe((res) => (0,tslib__WEBPACK_IMPORTED_MODULE_25__.__awaiter)(this, void 0, void 0, function* () {
            try {
                yield capacitor_native_biometric__WEBPACK_IMPORTED_MODULE_8__.NativeBiometric.isAvailable().then((result) => {
                    this.isSupportBiometric = result.isAvailable;
                    const columnnameBank = this.insuranceService.checkPayerSetting(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_6__.Constants.ENABLE_BENEF_BANK_TRANSFER, true);
                    if (columnnameBank == false) {
                        this.displayBank = false;
                    }
                    else {
                        this.displayBank = true;
                    }
                    const columnnameCheque = this.insuranceService.checkPayerSetting(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_6__.Constants.ENABLE_BENEF_CHEQUE_PAYMENT, true);
                    if (columnnameCheque == false) {
                        this.displayCheque = false;
                    }
                    else {
                        this.displayCheque = true;
                    }
                    console.log(this.displayCheque);
                    this.actionList = [
                        {
                            title: 'editProfile.changePassword',
                            startClassIcon: 'lock',
                            endClassIcon: 'angle-right-b',
                            key: 'changePassword',
                            isShow: true
                        },
                        {
                            title: 'editProfile.savedAddress',
                            startClassIcon: 'map-marker',
                            endClassIcon: 'angle-right-b',
                            key: 'savedAddress',
                            isShow: this.displayCheque,
                        },
                        {
                            title: 'editProfile.bankDetails',
                            startClassIcon: 'credit-card',
                            endClassIcon: 'angle-right-b',
                            key: 'bankDetail',
                            isShow: this.displayBank
                        },
                        {
                            title: 'editProfile.biometricsLogin',
                            startClassIcon: 'finger-print',
                            endClassIcon: 'toggle-off',
                            key: 'biometricLogin',
                            isShow: this.isSupportBiometric,
                        },
                        {
                            title: 'editProfile.deleteAccount',
                            startClassIcon: 'trash-alt',
                            endClassIcon: 'angle-right-b',
                            key: 'deleteAccount',
                            isShow: true
                        }
                    ];
                });
            }
            catch (error) {
                const columnnameBank = this.insuranceService.checkPayerSetting(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_6__.Constants.ENABLE_BENEF_BANK_TRANSFER, true);
                if (columnnameBank == false) {
                    this.displayBank = false;
                }
                else {
                    this.displayBank = true;
                }
                const columnnameCheque = this.insuranceService.checkPayerSetting(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_6__.Constants.ENABLE_BENEF_CHEQUE_PAYMENT, true);
                if (columnnameCheque == false) {
                    this.displayCheque = false;
                }
                else {
                    this.displayCheque = true;
                }
                console.log(this.displayCheque);
                this.actionList = [
                    {
                        title: 'editProfile.changePassword',
                        startClassIcon: 'lock',
                        endClassIcon: 'angle-right-b',
                        key: 'changePassword',
                        isShow: true
                    },
                    {
                        title: 'editProfile.savedAddress',
                        startClassIcon: 'map-marker',
                        endClassIcon: 'angle-right-b',
                        key: 'savedAddress',
                        isShow: this.displayCheque,
                    },
                    {
                        title: 'editProfile.bankDetails',
                        startClassIcon: 'credit-card',
                        endClassIcon: 'angle-right-b',
                        key: 'bankDetail',
                        isShow: this.displayBank,
                    },
                    {
                        title: 'editProfile.biometricsLogin',
                        startClassIcon: 'finger-print',
                        endClassIcon: 'toggle-off',
                        key: 'biometricLogin',
                        isShow: false,
                    },
                    {
                        title: 'editProfile.deleteAccount',
                        startClassIcon: 'trash-alt',
                        endClassIcon: 'angle-right-b',
                        key: 'deleteAccount',
                        isShow: true
                    }
                ];
            }
            this.isToggle = yield this.signinService.getBiomatricStatus();
            this.getUserContact();
            this.getUserProfile();
            // this.handleEditprofileScreen();
            this.showEditName = false;
        }));
    }
    // handleEditprofileScreen(){
    //   this.platform.backButton.subscribeWithPriority(15, (processNextHandler) => {
    //     if(this.location.isCurrentPathEqualTo('/'+ Screens.EditProfile)){
    //       if(this.showEditName == false){
    //         this.router.navigate(['/home/' + Screens.Home]);
    //         this.menu.open('profile-menu');
    //         this.showEditName = true
    //       } else {
    //         this.showEditName = false
    //       }
    //     }
    //     processNextHandler();
    //   });
    // }
    onUpdateEmail(email) {
        this.firebaseAnalytics.logEvent(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_10__.GA4Event.EmailVerificationStarted, {});
        // this.clevertap.recordEventWithNameAndProps(GA4Event.EmailVerificationStarted, { user_email: this.userContact?.contactInfo});
        this.clevertap.recordEventWithName(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_10__.GA4Event.EmailVerificationStarted);
        this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_4__.Screens.UpdateEmail], {
            state: {
                contact: email,
            }
        });
    }
    onUpdatePhoneNumber() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_25__.__awaiter)(this, void 0, void 0, function* () {
            const ref = yield this.modalCtrl.create({
                component: _update_phone_number_update_phone_number_component__WEBPACK_IMPORTED_MODULE_18__.UpdatePhoneNumberComponent,
            });
            ref.present();
        });
    }
    openDialog() {
        this.dialogSevice.open(src_app_shared_components_popup_message_popup_message_component__WEBPACK_IMPORTED_MODULE_17__.PopupMessageComponent, {
            data: {
                content: 'editProfile.popupText',
                textNo: 'editProfile.popupLink',
            },
            title: 'editProfile.popupTitle',
            position: 'bottom',
            width: '100%',
        });
    }
    onNavigate(item) {
        console.log('test');
        switch (item.key) {
            case 'changePassword':
                this.navCtrl.navigateForward(src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_4__.Screens.ChangePassword);
                break;
            case 'savedAddress':
                this.navCtrl.navigateForward(src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_4__.Screens.SavedAddress);
                break;
            case 'bankDetail':
                // this.navCtrl.navigateForward(Screens.BankDetails);
                this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_4__.Screens.BankDetails], {
                    queryParams: { isShow: true }
                });
                break;
            case 'biometricLogin':
                this.isToggle = !this.isToggle;
                if (this.isToggle) {
                    this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_4__.Screens.EnableFaceId], { queryParams: { fromEditprofile: 'editProfile' } }).then(() => {
                    });
                }
                else {
                    this.signinService.setBiomatricStatus(false);
                }
                break;
            case 'deleteAccount':
                {
                    this.deleteAccount();
                }
                break;
        }
    }
    deleteAccount() {
        this.dialogSevice.open(src_app_shared_components_alert_delete_alert_delete_component__WEBPACK_IMPORTED_MODULE_14__.AlertDeleteComponent, {
            data: {
                textContentDelete: 'editProfile.deleteAccountTitleContent',
                textDeleteAddress: 'editProfile.deleteAccountTitle',
            },
            position: 'bottom',
            height: '250px',
            width: '100%',
        }).afterClosed().subscribe((res) => {
            if (res) {
                this.dialogSevice.open(src_app_shared_components_alert_enter_password_alert_enter_password_component__WEBPACK_IMPORTED_MODULE_15__.AlertEnterPasswordComponent, {
                    data: {
                        textDeleteAddress: 'editProfile.enterPassword',
                    },
                    position: 'middle',
                    height: '340px',
                    width: '90%',
                }).afterClosed().subscribe((res) => {
                    if (res) {
                        const userId = window.localStorage.getItem(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_6__.Constants.USERID);
                        this.editProfileService.deleteAccount(userId).subscribe(_res => {
                            this.dialogSevice.open(src_app_shared_components_popup_message_popup_message_component__WEBPACK_IMPORTED_MODULE_17__.PopupMessageComponent, {
                                data: {
                                    content: 'editProfile.deleteAccountSuccess',
                                    textYes: 'editProfile.btnDeleteAccountSuccess',
                                },
                                title: 'title.wrongTitleMessage',
                                height: '350px',
                                width: '90%',
                                position: 'middle',
                            }).afterClosed()
                                .subscribe(() => {
                                this.firebaseAnalytics.logEvent(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_10__.GA4Event.AccountDeleted, {});
                                this.clevertap.recordEventWithName(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_10__.GA4Event.AccountDeleted);
                                this.signinService.logout();
                                this.signinService.eraseUserData();
                                this.signinService.dataUser.next(null);
                                window.location.reload();
                                this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_4__.Screens.SignIn]);
                            });
                        });
                    }
                });
            }
        });
    }
    onBack() {
        this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_4__.Screens.Home]).then(() => {
            this.menu.open('profile-menu');
        });
    }
    handleFileInput(evt) {
        const files = evt.target.files;
        const file = files[0];
        this.uploadDocumentService
            .convertFile(file)
            .subscribe((base64) => {
            console.log(base64);
            if (!base64)
                return;
            this.userService.updateUserProfileImage(base64).subscribe(() => {
                this.userService.getUserProfileImage().subscribe();
            }, _ => this.onBack());
        });
    }
    getUserContact() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_25__.__awaiter)(this, void 0, void 0, function* () {
            // const contacts = await this.storage.get(Constants.USER_CONTACT);
            this.userService.getUserContact().subscribe((contacts) => {
                this.userContact = {
                    emails: contacts.filter(e => e.type === 'email'),
                    phones: contacts.filter(e => e.type === 'phone' && e.typeDescription === 'mobilenumber')
                };
                if (this.userContact.emails.some(e => e.isVerified === 1)) {
                    this.canVerifyEmail = false;
                }
                else {
                    this.canVerifyEmail = true;
                }
                ;
                if (this.userContact.phones.some(e => e.isVerified === 1)) {
                    this.canVerifyPhone = false;
                }
                else {
                    this.canVerifyPhone = true;
                }
                ;
                if (this.userContact.phones.length === 0) {
                    this.userContact.phones = [
                        {
                            contactInfo: null,
                            isVerified: null,
                            contactID: null,
                            isPrefered: null,
                            type: src_app_shared_data_enum_login_type__WEBPACK_IMPORTED_MODULE_16__.LoginType.Mobile,
                            userID: null,
                        }
                    ];
                }
                if (this.userContact.emails.length === 0) {
                    this.userContact.emails = [
                        {
                            contactInfo: null,
                            isVerified: null,
                            contactID: null,
                            isPrefered: null,
                            type: src_app_shared_data_enum_login_type__WEBPACK_IMPORTED_MODULE_16__.LoginType.Email,
                            userID: null,
                        }
                    ];
                }
            });
        });
    }
    getUserProfile() {
        var _a, _b;
        return (0,tslib__WEBPACK_IMPORTED_MODULE_25__.__awaiter)(this, void 0, void 0, function* () {
            this.userProfile = yield this.storage.get(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_6__.Constants.USER_PROFILE);
            this.profile = {
                firstName: (_a = this.userProfile) === null || _a === void 0 ? void 0 : _a.firstName,
                lastName: (_b = this.userProfile) === null || _b === void 0 ? void 0 : _b.lastName
            };
        });
    }
    onVerifyEmail(email) {
        this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_4__.Screens.OTPVerification], {
            queryParams: {
                type: src_app_shared_data_enum_login_type__WEBPACK_IMPORTED_MODULE_16__.LoginType.Email,
                login: email.contactInfo,
                redirectTo: src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_4__.Screens.Home,
                message: 'otpPhoneNumber.verify-email-desc',
                redirectBack: src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_4__.Screens.Home,
                isShow: true
            }
        });
    }
    onUpdatePhone(phone) {
        this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_4__.Screens.UpdatePhoneNumber], {
            state: {
                contact: phone,
            }
        });
    }
    onVerifyPhone(phone) {
        this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_4__.Screens.OTPVerification], {
            queryParams: {
                type: src_app_shared_data_enum_login_type__WEBPACK_IMPORTED_MODULE_16__.LoginType.Mobile,
                login: phone.contactInfo,
                redirectTo: src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_4__.Screens.Home,
                message: 'otpPhoneNumber.verify-phone-desc',
                redirectBack: src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_4__.Screens.EditProfile,
                reload: true,
                isShow: true
            }
        });
    }
    getName() {
        var _a, _b;
        this.showEditName = true;
        this.profileForm = this.fb.group({
            firstName: [(_a = this.profile) === null || _a === void 0 ? void 0 : _a.firstName, _angular_forms__WEBPACK_IMPORTED_MODULE_27__.Validators.required],
            lastName: [(_b = this.profile) === null || _b === void 0 ? void 0 : _b.lastName, _angular_forms__WEBPACK_IMPORTED_MODULE_27__.Validators.required]
        });
        this.cdr.detectChanges();
    }
    updateName() {
        this.profileForm.markAllAsTouched();
        this.profileForm.markAsDirty();
        if (this.profileForm.valid) {
            const data = this.profileForm.value;
            const profile = {
                firstName: data.firstName,
                lastName: data.lastName,
            };
            this.editProfileService.updateProfile(profile).subscribe((data) => {
                if (data) {
                    this.showEditName = false;
                    this.userService.getProfileUser().subscribe(res => {
                        this.storage.set(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_6__.Constants.USER_PROFILE, res);
                    });
                    this.profile = {
                        firstName: data.firstName,
                        lastName: data.lastName
                    };
                }
            });
        }
    }
    openSelection() {
        this.dialogSevice
            .open(_new_claim_upload_detail_upload_documents_upload_documents_component__WEBPACK_IMPORTED_MODULE_19__.UploadDocumentsComponent, {
            position: 'bottom',
            title: 'uploadDocuments.uploadPicture',
            data: {
                noPDF: true,
            }
        })
            .afterClosed()
            .subscribe((res) => (0,tslib__WEBPACK_IMPORTED_MODULE_25__.__awaiter)(this, void 0, void 0, function* () {
            if (typeof res.file == 'string') {
                yield this.cropImage(res.file);
            }
            else {
                this.uploadDocumentService
                    .convertFile(res.file)
                    .subscribe((base64) => (0,tslib__WEBPACK_IMPORTED_MODULE_25__.__awaiter)(this, void 0, void 0, function* () {
                    if (!base64)
                        return;
                    yield this.cropImage(base64);
                }));
            }
        }));
    }
    calc_image_size(image) {
        let y = 1;
        if (image.endsWith('==')) {
            y = 2;
        }
        const x_size = (image.length * (3 / 4)) - y;
        return Math.round(x_size / 1024);
    }
    reduce_image_file_size(base64Str, MAX_WIDTH = 700, MAX_HEIGHT = 700) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_25__.__awaiter)(this, void 0, void 0, function* () {
            const resized_base64 = yield new Promise((resolve) => {
                const img = new Image();
                img.src = `data:image/png;base64,${base64Str}`;
                img.onload = () => {
                    const canvas = document.createElement('canvas');
                    let width = img.width;
                    let height = img.height;
                    if (width > height) {
                        if (width > MAX_WIDTH) {
                            height *= MAX_WIDTH / width;
                            width = MAX_WIDTH;
                        }
                    }
                    else {
                        if (height > MAX_HEIGHT) {
                            width *= MAX_HEIGHT / height;
                            height = MAX_HEIGHT;
                        }
                    }
                    canvas.width = width;
                    canvas.height = height;
                    const ctx = canvas.getContext('2d');
                    ctx.drawImage(img, 0, 0, width, height);
                    resolve(canvas.toDataURL()); // this will return base64 image results after resize
                };
            });
            return resized_base64;
        });
    }
    cropImage(base64) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_25__.__awaiter)(this, void 0, void 0, function* () {
            const ref = yield this.modalCtrl.create({
                component: src_app_shared_components_camera_review_confirm_image_dialog_confirm_image_dialog_component__WEBPACK_IMPORTED_MODULE_21__.ConfirmImageDialogComponent,
                componentProps: {
                    imageSrc: `data:image/png;base64,${base64}`,
                    title: '',
                    type: '',
                    name: new Date().getTime() + '.jpeg',
                    format: 'jpeg',
                    typeProfile: true
                },
            });
            ref.present();
            const { data } = yield ref.onWillDismiss();
            if (data === null || data === void 0 ? void 0 : data.complete) {
                this.cameraService.getCroppedBase64().subscribe((res) => (0,tslib__WEBPACK_IMPORTED_MODULE_25__.__awaiter)(this, void 0, void 0, function* () {
                    if (res) {
                        let base64Resize;
                        if (this.calc_image_size(res.url.toString().split(',')[1]) > 1500) {
                            const resized = yield this.reduce_image_file_size(res.url.toString().split(',')[1]);
                            base64Resize = resized.toString().split(',')[1];
                        }
                        else {
                            base64Resize = res.url.toString().split(',')[1];
                        }
                        this.userService.updateUserProfileImage(base64Resize)
                            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_28__.switchMap)(_ => this.userService.getUserProfileImage())).subscribe(() => {
                        }, _ => this.onBack());
                    }
                }));
            }
        });
    }
};
EditProfilePage.ctorParameters = () => [
    { type: _angular_common__WEBPACK_IMPORTED_MODULE_29__.Location },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_30__.NavController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_30__.MenuController },
    { type: src_app_shared_components_nextgen_dialog_nextgen_dialog_service__WEBPACK_IMPORTED_MODULE_3__.DialogService },
    { type: src_app_service_profile_edit_profile_service__WEBPACK_IMPORTED_MODULE_5__.EditProfileService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_30__.Platform },
    { type: src_app_service_signin_signin_service__WEBPACK_IMPORTED_MODULE_7__.SigninService },
    { type: _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_31__.Storage },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_32__.Router },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_30__.ModalController },
    { type: _awesome_cordova_plugins_firebase_analytics_ngx__WEBPACK_IMPORTED_MODULE_9__.FirebaseAnalytics },
    { type: _awesome_cordova_plugins_clevertap_ngx__WEBPACK_IMPORTED_MODULE_11__.CleverTap },
    { type: src_app_service_new_claim_upload_document_upload_document_service__WEBPACK_IMPORTED_MODULE_12__.UploadDocumentService },
    { type: src_app_service_user_user_service__WEBPACK_IMPORTED_MODULE_13__.UserService },
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_33__.ChangeDetectorRef },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_27__.FormBuilder },
    { type: src_app_service_insurance_insurance_service__WEBPACK_IMPORTED_MODULE_20__.InsuranceService },
    { type: src_app_service_utilities_camera_service__WEBPACK_IMPORTED_MODULE_22__.CameraService },
    { type: src_app_providers_api_api_service__WEBPACK_IMPORTED_MODULE_23__.ApiService }
];
EditProfilePage = (0,tslib__WEBPACK_IMPORTED_MODULE_25__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_33__.Component)({
        selector: 'app-edit-profile',
        template: _edit_profile_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_edit_profile_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], EditProfilePage);



/***/ }),

/***/ 73208:
/*!************************************************************************!*\
  !*** ./src/app/pages/edit-profile/saved-address/saved-address.page.ts ***!
  \************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SavedAddressPage": () => (/* binding */ SavedAddressPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _saved_address_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./saved-address.page.html?ngResource */ 24215);
/* harmony import */ var _saved_address_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./saved-address.page.scss?ngResource */ 91721);
/* harmony import */ var _service_new_claim_payment_method_payment_method_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../service/new-claim/payment-method/payment-method.service */ 18620);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _awesome_cordova_plugins_firebase_analytics_ngx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @awesome-cordova-plugins/firebase-analytics/ngx */ 48852);
/* harmony import */ var _awesome_cordova_plugins_clevertap_ngx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @awesome-cordova-plugins/clevertap/ngx */ 45363);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var src_app_model_workflow_workflow_model__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/model/workflow/workflow.model */ 42791);
/* harmony import */ var src_app_shared_components_add_address_add_address_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/shared/components/add-address/add-address.component */ 93697);
/* harmony import */ var src_app_shared_components_alert_delete_alert_delete_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/shared/components/alert-delete/alert-delete.component */ 98887);
/* harmony import */ var src_app_shared_components_nextgen_dialog_nextgen_dialog_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/shared/components/nextgen-dialog/nextgen-dialog.service */ 96485);
/* harmony import */ var src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/shared/data/enum/event */ 38570);
/* harmony import */ var src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/app/shared/data/enum/screen */ 68302);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/router */ 52816);















let SavedAddressPage = class SavedAddressPage {
    constructor(navCtrl, dialogService, modalCtrl, firebaseAnalytics, clevertap, paymentMethodService, platform, router) {
        this.navCtrl = navCtrl;
        this.dialogService = dialogService;
        this.modalCtrl = modalCtrl;
        this.firebaseAnalytics = firebaseAnalytics;
        this.clevertap = clevertap;
        this.paymentMethodService = paymentMethodService;
        this.platform = platform;
        this.router = router;
        this.isShowButtonAddNewAddress = true;
    }
    ngOnInit() {
        this.getListAddress();
    }
    ionViewDidEnter() {
        this.subscription = this.platform.backButton.subscribeWithPriority(9999, () => {
            this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_10__.Screens.EditProfile]);
        });
    }
    ionViewWillLeave() {
        this.subscription.unsubscribe();
    }
    getListAddress() {
        this.paymentMethodService.getAddress().subscribe((data) => {
            this.listAddress = data;
            this.checkIsNewAddress();
        });
    }
    checkIsNewAddress() {
        var _a;
        // eslint-disable-next-line prefer-const
        let listAddressType = [];
        (_a = this.listAddress) === null || _a === void 0 ? void 0 : _a.map((value) => {
            listAddressType.push(value.title);
        });
        if (listAddressType.some((_) => _ == 'Home') &&
            listAddressType.some((_) => _ == 'Office') &&
            listAddressType.some((_) => _ == 'Other')) {
            this.isShowButtonAddNewAddress = false;
        }
        else {
            this.isShowButtonAddNewAddress = true;
        }
    }
    addAddress() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_11__.__awaiter)(this, void 0, void 0, function* () {
            const ref = yield this.modalCtrl.create({
                component: src_app_shared_components_add_address_add_address_component__WEBPACK_IMPORTED_MODULE_6__.AddAddressComponent,
                componentProps: {
                    dataSource: this.listAddress,
                    addNew: true
                }
            });
            ref.present();
            const { data } = yield ref.onWillDismiss();
            if (data) {
                this.getListAddress();
            }
        });
    }
    onDelete(value) {
        this.dialogService
            .open(src_app_shared_components_alert_delete_alert_delete_component__WEBPACK_IMPORTED_MODULE_7__.AlertDeleteComponent, {
            data: {
                textContentDelete: 'savedAddress.contentDelete',
                textDeleteAddress: 'savedAddress.deleteAddress',
            },
            height: '32%',
            width: '100%',
        })
            .afterClosed()
            .subscribe((res) => {
            if (res) {
                this.firebaseAnalytics.logEvent(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_9__.GA4Event.AddressDeleted, {});
                this.clevertap.recordEventWithName(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_9__.GA4Event.AddressDeleted);
                // this.listAddress.forEach((item, index) => {
                //   if (item === value) this.listAddress.splice(index, 1);
                // });
                const requestSaveAddress = {
                    addressId: value.userAddressID
                };
                this.paymentMethodService.deleteSaveAddress(requestSaveAddress).subscribe(_ => {
                    this.getListAddress();
                });
            }
        });
    }
    onBack() {
        this.navCtrl.back();
    }
    onEdit(value) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_11__.__awaiter)(this, void 0, void 0, function* () {
            const ref = yield this.modalCtrl.create({
                component: src_app_shared_components_add_address_add_address_component__WEBPACK_IMPORTED_MODULE_6__.AddAddressComponent,
                componentProps: {
                    mode: src_app_model_workflow_workflow_model__WEBPACK_IMPORTED_MODULE_5__.MODE.EDIT,
                    dataSource: this.listAddress,
                    addNew: false,
                    onEdit: true,
                    initValue: Object.assign(Object.assign({}, value), { house: value.floor, buildingName: value.building, addressType: value.title }),
                },
            });
            ref.present();
            const { data } = yield ref.onWillDismiss();
            if (data) {
                this.getListAddress();
            }
        });
    }
};
SavedAddressPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_12__.NavController },
    { type: src_app_shared_components_nextgen_dialog_nextgen_dialog_service__WEBPACK_IMPORTED_MODULE_8__.DialogService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_12__.ModalController },
    { type: _awesome_cordova_plugins_firebase_analytics_ngx__WEBPACK_IMPORTED_MODULE_3__.FirebaseAnalytics },
    { type: _awesome_cordova_plugins_clevertap_ngx__WEBPACK_IMPORTED_MODULE_4__.CleverTap },
    { type: _service_new_claim_payment_method_payment_method_service__WEBPACK_IMPORTED_MODULE_2__.PaymentMethodService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_12__.Platform },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_13__.Router }
];
SavedAddressPage = (0,tslib__WEBPACK_IMPORTED_MODULE_11__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_14__.Component)({
        selector: 'app-saved-address',
        template: _saved_address_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_saved_address_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], SavedAddressPage);



/***/ }),

/***/ 26772:
/*!*****************************************************************************************!*\
  !*** ./src/app/pages/edit-profile/update-phone-number/update-phone-number.component.ts ***!
  \*****************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UpdatePhoneNumberComponent": () => (/* binding */ UpdatePhoneNumberComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _update_phone_number_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./update-phone-number.component.html?ngResource */ 87139);
/* harmony import */ var _update_phone_number_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./update-phone-number.component.scss?ngResource */ 26505);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var src_app_model_control_control_model__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/model/control/control.model */ 45482);
/* harmony import */ var src_app_service_country_countries_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/service/country/countries.service */ 51249);
/* harmony import */ var src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/shared/data/enum/screen */ 68302);
/* harmony import */ var country_iso_3_to_2__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! country-iso-3-to-2 */ 97754);
/* harmony import */ var country_iso_3_to_2__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(country_iso_3_to_2__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var src_app_service_profile_edit_profile_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/service/profile/edit-profile.service */ 85307);
/* harmony import */ var src_app_shared_data_enum_login_type__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/shared/data/enum/login-type */ 3674);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var src_app_service_insurance_insurance_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/service/insurance/insurance.service */ 57072);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @ionic/angular */ 93819);















let UpdatePhoneNumberComponent = class UpdatePhoneNumberComponent {
    constructor(fb, router, countryService, profileService, location, insuranceService, platform) {
        var _a;
        this.fb = fb;
        this.router = router;
        this.countryService = countryService;
        this.profileService = profileService;
        this.location = location;
        this.insuranceService = insuranceService;
        this.platform = platform;
        this.TYPE = src_app_model_control_control_model__WEBPACK_IMPORTED_MODULE_2__.ControlType;
        this.isDisable = true;
        this.params = (_a = this.router.getCurrentNavigation().extras.state) === null || _a === void 0 ? void 0 : _a.contact;
        this.numberPhoneForm = this.fb.group({
            phone: [null, [_angular_forms__WEBPACK_IMPORTED_MODULE_9__.Validators.required]],
        });
    }
    ngOnInit() {
        this.getCountryList();
    }
    ionViewDidEnter() {
        this.subscription = this.platform.backButton.subscribeWithPriority(9999, () => {
            this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_4__.Screens.EditProfile]);
        });
    }
    ionViewWillLeave() {
        this.subscription.unsubscribe();
    }
    onBack() {
        this.location.back();
    }
    getCountryList() {
        this.countryService.getCountries().subscribe((res) => {
            var _a, _b, _c;
            this.countryList = res.map((res) => {
                var _a;
                return ({
                    id: res.countryId,
                    name: res.countryDescription,
                    icon: res.countryCodeISO2.toLocaleLowerCase() || ((_a = country_iso_3_to_2__WEBPACK_IMPORTED_MODULE_5__(res.countryCodeISO)) === null || _a === void 0 ? void 0 : _a.toLocaleLowerCase()) || 'empty',
                    currencyId: res.currencyId,
                    countryAreaCode: res.countryAreaCode,
                });
            });
            const countryId = (_c = (_b = (_a = this.insuranceService.getPolicyDetailResponse()) === null || _a === void 0 ? void 0 : _a[0]) === null || _b === void 0 ? void 0 : _b.Payer) === null || _c === void 0 ? void 0 : _c.Address.countryId;
            res.forEach((item) => {
                var _a;
                if (item.countryId == countryId) {
                    this.country = {
                        id: item.countryId,
                        name: item.countryDescription,
                        icon: item.countryCodeISO2.toLocaleLowerCase() || ((_a = country_iso_3_to_2__WEBPACK_IMPORTED_MODULE_5__(item.countryCodeISO)) === null || _a === void 0 ? void 0 : _a.toLocaleLowerCase()) || 'empty',
                        currencyId: item.currencyId,
                        countryAreaCode: item === null || item === void 0 ? void 0 : item.countryAreaCode,
                    };
                }
            });
            // this.country = {
            //   id: res[0].countryId,
            //   name: res[0].countryDescription,
            //   icon: res[0].countryCodeISO2.toLocaleLowerCase() || convertCountry(res[0].countryCodeISO)?.toLocaleLowerCase() || 'empty',
            //   currencyId: res[0].currencyId,
            //   countryAreaCode: res[0]?.countryAreaCode,
            // }
            const phone = {
                phoneDescription: this.country,
                //phoneDescription: null,
                phoneNumber: null
            };
            this.numberPhoneForm.controls['phone'].setValue(phone);
            this.numberPhoneForm.controls['phone'].updateValueAndValidity();
        });
    }
    verifyHandler() {
        var _a, _b, _c, _d, _e, _f, _g;
        return (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__awaiter)(this, void 0, void 0, function* () {
            this.numberPhoneForm.markAllAsTouched();
            this.numberPhoneForm.markAsDirty();
            const value = this.numberPhoneForm.value;
            if (value.phone.phoneNumber) {
                if ((_a = this.params) === null || _a === void 0 ? void 0 : _a.contactID) {
                    this.profileService.updateContact(Object.assign(Object.assign({}, this.params), { isVerified: 0, contactInfo: ((_c = (_b = value.phone) === null || _b === void 0 ? void 0 : _b.phoneDescription) === null || _c === void 0 ? void 0 : _c.countryAreaCode) + '-' + ((_d = value.phone) === null || _d === void 0 ? void 0 : _d.phoneNumber) })).subscribe(_ => {
                        var _a, _b, _c;
                        this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_4__.Screens.OTPVerification], {
                            queryParams: {
                                type: this.params.type || src_app_shared_data_enum_login_type__WEBPACK_IMPORTED_MODULE_7__.LoginType.Mobile,
                                login: ((_b = (_a = value.phone) === null || _a === void 0 ? void 0 : _a.phoneDescription) === null || _b === void 0 ? void 0 : _b.countryAreaCode) + '-' + ((_c = value.phone) === null || _c === void 0 ? void 0 : _c.phoneNumber),
                                redirectTo: src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_4__.Screens.Home,
                                message: 'otpPhoneNumber.verify-phone-desc',
                                redirectBack: src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_4__.Screens.EditProfile,
                                reload: true,
                                isShow: true
                            }
                        });
                    });
                }
                else {
                    this.profileService.addNewContact(Object.assign(Object.assign({}, this.params), { isVerified: 0, contactInfo: ((_f = (_e = value.phone) === null || _e === void 0 ? void 0 : _e.phoneDescription) === null || _f === void 0 ? void 0 : _f.countryAreaCode) + '-' + ((_g = value.phone) === null || _g === void 0 ? void 0 : _g.phoneNumber) })).subscribe(_ => {
                        var _a, _b, _c;
                        this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_4__.Screens.OTPVerification], {
                            queryParams: {
                                type: this.params.type || src_app_shared_data_enum_login_type__WEBPACK_IMPORTED_MODULE_7__.LoginType.Mobile,
                                login: ((_b = (_a = value.phone) === null || _a === void 0 ? void 0 : _a.phoneDescription) === null || _b === void 0 ? void 0 : _b.countryAreaCode) + '-' + ((_c = value.phone) === null || _c === void 0 ? void 0 : _c.phoneNumber),
                                redirectTo: src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_4__.Screens.Home,
                                message: 'otpPhoneNumber.verify-phone-desc',
                                redirectBack: src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_4__.Screens.EditProfile,
                                reload: true,
                                isShow: true
                            }
                        });
                    });
                }
            }
        });
    }
    changeNumber(e) {
        if ((e === null || e === void 0 ? void 0 : e.phoneDescription) == null || ((e === null || e === void 0 ? void 0 : e.phoneNumber.toString().length) < 6 || (e === null || e === void 0 ? void 0 : e.phoneNumber.toString().length) > 10)) {
            this.isDisable = true;
        }
        else {
            this.isDisable = false;
        }
    }
};
UpdatePhoneNumberComponent.ctorParameters = () => [
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_9__.FormBuilder },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_11__.Router },
    { type: src_app_service_country_countries_service__WEBPACK_IMPORTED_MODULE_3__.CountriesService },
    { type: src_app_service_profile_edit_profile_service__WEBPACK_IMPORTED_MODULE_6__.EditProfileService },
    { type: _angular_common__WEBPACK_IMPORTED_MODULE_12__.Location },
    { type: src_app_service_insurance_insurance_service__WEBPACK_IMPORTED_MODULE_8__.InsuranceService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_13__.Platform }
];
UpdatePhoneNumberComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_14__.Component)({
        selector: 'app-update-phone-number',
        template: _update_phone_number_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_update_phone_number_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], UpdatePhoneNumberComponent);



/***/ }),

/***/ 17405:
/*!***************************************************************************************************************************!*\
  !*** ./projects/iris-ionic-library/src/lib/_utils/components/base-component/src/base-component.component.scss?ngResource ***!
  \***************************************************************************************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJiYXNlLWNvbXBvbmVudC5jb21wb25lbnQuc2NzcyJ9 */";

/***/ }),

/***/ 99409:
/*!********************************************************************************************************************************!*\
  !*** ./projects/iris-ionic-library/src/lib/components/navigation-hyperlink/src/navigation-hyperlink.component.scss?ngResource ***!
  \********************************************************************************************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJuYXZpZ2F0aW9uLWh5cGVybGluay5jb21wb25lbnQuc2NzcyJ9 */";

/***/ }),

/***/ 79394:
/*!******************************************************************************************************************!*\
  !*** ./projects/iris-ionic-library/src/lib/components/submit-button/src/submit-button.component.scss?ngResource ***!
  \******************************************************************************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzdWJtaXQtYnV0dG9uLmNvbXBvbmVudC5zY3NzIn0= */";

/***/ }),

/***/ 76570:
/*!************************************************************************************************!*\
  !*** ./src/app/pages/edit-profile/change-passwords/change-passwords.component.scss?ngResource ***!
  \************************************************************************************************/
/***/ ((module) => {

module.exports = ":root {\n  --nc-color-nextgen-neutral-grey-50: red;\n  --nc-color-nextgen-white: yellow;\n  --nc-color-nextgen-blue: #0d152e;\n  --nc-color-nextgen-green: #00908d;\n  --nc-color-nextgen-black: #000000;\n  --nc-color-nextgen-grey-background: #c8d3da;\n  --nc-color-nextgen-grey: #92a2ac;\n  --nc-color-nextgen-stone-grey: #fafafa;\n  --nc-color-nextgen-error: #fc1055;\n  --nc-color-nextgen-neutral-grey: #414141;\n  --nc-color-nextgen-fibrant-green: #00bab6;\n  --nc-color-nextgen-warning: #ffd048;\n  --nc-color-nextgen-green-background: #e6f2f2;\n  --nc-color-nextgen-neutral-grey-400: #7a7a7a;\n  --nc-color-nextgen-neutral-grey-100: #eff3f5;\n  --nc-color-nextgen-status-error: #ba0c3f;\n  --nc-color-nextgen-status-error-background: #ffeff4;\n  --nc-color-nextgen-status-warning: #cba127;\n  --nc-color-nextgen-status-warning-background: #fff8e6;\n  --nc-color-nextgen-blue-100: #dfeff2;\n  --nc-color-nextgen-error-red-700: #f62459;\n  --nc-color-nextgen-blue-500: #006192;\n  --nc-color-nextgen-blue-400: #79cdec;\n  --nc-color-nextgen-red-500: #ff6592;\n  --nc-color-nextgen-secondary-blue-300: #13a0d3;\n  --lumi-white-color: #ffffff;\n  --lumi-primary-yellow-color: #fab600;\n}\n\n.ion-color-green {\n  --ion-color-base: var(--nc-color-nextgen-green);\n  --ion-color-base-rgb: var(--nc-color-nextgen-green);\n  --ion-color-contrast: var(--nc-color-nextgen-white);\n  --ion-color-contrast-rgb: var(--nc-color-nextgen-green);\n  --ion-color-shade: var(--nc-color-nextgen-green);\n  --ion-color-tint: var(--nc-color-nextgen-green);\n}\n\n.change-password-container {\n  background: var(--nc-color-nextgen-neutral-grey-50);\n}\n\n.change-password-header {\n  justify-content: space-between;\n}\n\n.need-help-text {\n  color: var(--nc-color-nextgen-green);\n  float: right !important;\n}\n\n.change-password-title {\n  width: 100%;\n  color: var(--nc-color-nextgen-black);\n  padding-top: 2rem;\n}\n\n.form-change-password {\n  width: 100%;\n  padding-top: 2rem;\n}\n\n.button-change-password {\n  text-align: center;\n  padding-top: 2rem;\n}\n\n.validation-summary-password {\n  list-style: none;\n}\n\n.validation-summary-password li {\n  display: flex;\n}\n\n.validation-summary-password li .check-place {\n  color: var(--nc-color-nextgen-green) !important;\n}\n\n.text-validation {\n  color: var(--nc-color-nextgen-grey) !important;\n}\n\n.check-place {\n  width: 22px;\n  height: auto;\n}\n\n.change-password-content {\n  min-height: 85%;\n  padding-bottom: 3rem;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFxjb2xvci5zY3NzIiwiY2hhbmdlLXBhc3N3b3Jkcy5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNDLHVDQUFBO0VBQ0EsZ0NBQUE7RUFDQSxnQ0FBQTtFQUNBLGlDQUFBO0VBQ0EsaUNBQUE7RUFDQSwyQ0FBQTtFQUNBLGdDQUFBO0VBQ0Esc0NBQUE7RUFDQSxpQ0FBQTtFQUNBLHdDQUFBO0VBQ0EseUNBQUE7RUFDQSxtQ0FBQTtFQUNBLDRDQUFBO0VBQ0EsNENBQUE7RUFDQSw0Q0FBQTtFQUNBLHdDQUFBO0VBQ0EsbURBQUE7RUFDQSwwQ0FBQTtFQUNBLHFEQUFBO0VBQ0Esb0NBQUE7RUFDQSx5Q0FBQTtFQUNBLG9DQUFBO0VBQ0Esb0NBQUE7RUFDQSxtQ0FBQTtFQUNBLDhDQUFBO0VBRUEsMkJBQUE7RUFDQSxvQ0FBQTtBQ0FEOztBRGdDQTtFQUNDLCtDQUFBO0VBQ0EsbURBQUE7RUFDQSxtREFBQTtFQUNBLHVEQUFBO0VBQ0EsZ0RBQUE7RUFDQSwrQ0FBQTtBQzdCRDs7QUFuQ0E7RUFDSSxtRER1QzRCO0FDRGhDOztBQW5DQTtFQUNJLDhCQUFBO0FBc0NKOztBQW5DQTtFQUNJLG9DRG9Ca0I7RUNuQmxCLHVCQUFBO0FBc0NKOztBQW5DQTtFQUNJLFdBQUE7RUFDQSxvQ0RnQmtCO0VDZmxCLGlCQUFBO0FBc0NKOztBQW5DQTtFQUNJLFdBQUE7RUFDQSxpQkFBQTtBQXNDSjs7QUFuQ0E7RUFDSSxrQkFBQTtFQUNBLGlCQUFBO0FBc0NKOztBQW5DQTtFQUNJLGdCQUFBO0FBc0NKOztBQXBDSTtFQUNJLGFBQUE7QUFzQ1I7O0FBcENRO0VBQ0ksK0NBQUE7QUFzQ1o7O0FBakNBO0VBQ0ksOENBQUE7QUFvQ0o7O0FBakNBO0VBQ0ksV0FBQTtFQUNBLFlBQUE7QUFvQ0o7O0FBakNBO0VBQ0ksZUFBQTtFQUNBLG9CQUFBO0FBb0NKIiwiZmlsZSI6ImNoYW5nZS1wYXNzd29yZHMuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyI6cm9vdCB7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS01MDogcmVkO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi13aGl0ZTogeWVsbG93O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlOiAjMGQxNTJlO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbjogIzAwOTA4ZDtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tYmxhY2s6ICMwMDAwMDA7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWdyZXktYmFja2dyb3VuZDogI2M4ZDNkYTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tZ3JleTogIzkyYTJhYztcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc3RvbmUtZ3JleTogI2ZhZmFmYTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tZXJyb3I6ICNmYzEwNTU7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleTogIzQxNDE0MTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tZmlicmFudC1ncmVlbjogIzAwYmFiNjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4td2FybmluZzogI2ZmZDA0ODtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4tYmFja2dyb3VuZDogI2U2ZjJmMjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTQwMDogIzdhN2E3YTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTEwMDogI2VmZjNmNTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yOiAjYmEwYzNmO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtZXJyb3ItYmFja2dyb3VuZDogI2ZmZWZmNDtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLXdhcm5pbmc6ICNjYmExMjc7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy13YXJuaW5nLWJhY2tncm91bmQ6ICNmZmY4ZTY7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWJsdWUtMTAwOiAjZGZlZmYyO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1lcnJvci1yZWQtNzAwOiAjZjYyNDU5O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlLTUwMDogIzAwNjE5MjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZS00MDA6ICM3OWNkZWM7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXJlZC01MDA6ICNmZjY1OTI7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXNlY29uZGFyeS1ibHVlLTMwMDogIzEzYTBkMztcclxuXHJcblx0LS1sdW1pLXdoaXRlLWNvbG9yOiAjZmZmZmZmO1xyXG5cdC0tbHVtaS1wcmltYXJ5LXllbGxvdy1jb2xvcjogI2ZhYjYwMDtcclxufVxyXG4kY29sb3ItbmV4dGdlbi1ibHVlOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWJsdWUpO1xyXG4kY29sb3ItbmV4dGdlbi1ncmVlbjogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbik7XHJcbiRjb2xvci1uZXh0Z2VuLXdoaXRlOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXdoaXRlKTtcclxuJGNvbG9yLW5leHRnZW4tYmxhY2s6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tYmxhY2spO1xyXG4kY29sb3ItbmV4dGdlbi1ncmV5LWJhY2tncm91bmQ6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JleS1iYWNrZ3JvdW5kKTtcclxuJGNvbG9yLW5leHRnZW4tZ3JleTogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmV5KTtcclxuJGNvbG9yLW5leHRnZW4tc3RvbmUtZ3JleTogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1zdG9uZS1ncmV5KTtcclxuJGNvbG9yLW5leHRnZW4tZXJyb3I6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZXJyb3IpO1xyXG4kY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXk6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5KTtcclxuJGNvbG9yLW5leHRnZW4tZmlicmFudC1ncmVlbjogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1maWJyYW50LWdyZWVuKTtcclxuJGNvbG9yLW5leHRnZW4td2FybmluZzogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi13YXJuaW5nKTtcclxuJGNvbG9yLW5leHRnZW4tZ3JlZW4tYmFja2dyb3VuZDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbi1iYWNrZ3JvdW5kKTtcclxuJGNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTUwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS01MCk7XHJcbiRjb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS00MDA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTQwMCk7XHJcbiRjb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS0xMDA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTEwMCk7XHJcbiRjb2xvci1uZXh0Z2VuLXN0YXR1cy1lcnJvcjogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtZXJyb3IpO1xyXG4kY29sb3ItbmV4dGdlbi1zdGF0dXMtZXJyb3ItYmFja2dyb3VuZDogdmFyKFxyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtZXJyb3ItYmFja2dyb3VuZFxyXG4pO1xyXG4kY29sb3ItbmV4dGdlbi1zdGF0dXMtd2FybmluZzogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtd2FybmluZyk7XHJcbiRjb2xvci1uZXh0Z2VuLXN0YXR1cy13YXJuaW5nLWJhY2tncm91bmQ6IHZhcihcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLXdhcm5pbmctYmFja2dyb3VuZFxyXG4pO1xyXG4kY29sb3ItbmV4dGdlbi1ibHVlLTEwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlLTEwMCk7XHJcbiRjb2xvci1uZXh0Z2VuLWVycm9yLXJlZC03MDA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZXJyb3ItcmVkLTcwMCk7XHJcbiRjb2xvci1uZXh0Z2VuLWJsdWUtNTAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWJsdWUtNTAwKTtcclxuJGNvbG9yLW5leHRnZW4tYmx1ZS00MDA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZS00MDApO1xyXG4kY29sb3ItbmV4dGdlbi1yZWQtNTAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXJlZC01MDApO1xyXG4kY29sb3ItbmV4dGdlbi1zZWNvbmRhcnktYmx1ZS0zMDA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tc2Vjb25kYXJ5LWJsdWUtMzAwKTtcclxuXHJcbi5pb24tY29sb3ItZ3JlZW4ge1xyXG5cdC0taW9uLWNvbG9yLWJhc2U6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4pO1xyXG5cdC0taW9uLWNvbG9yLWJhc2UtcmdiOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuKTtcclxuXHQtLWlvbi1jb2xvci1jb250cmFzdDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi13aGl0ZSk7XHJcblx0LS1pb24tY29sb3ItY29udHJhc3QtcmdiOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuKTtcclxuXHQtLWlvbi1jb2xvci1zaGFkZTogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbik7XHJcblx0LS1pb24tY29sb3ItdGludDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbik7XHJcbn1cclxuIiwiQGltcG9ydCBcIi4uLy4uLy4uLy4uL2NvbG9yLnNjc3NcIjtcclxuXHJcbi5jaGFuZ2UtcGFzc3dvcmQtY29udGFpbmVyIHtcclxuICAgIGJhY2tncm91bmQ6ICRjb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS01MDtcclxufVxyXG5cclxuLmNoYW5nZS1wYXNzd29yZC1oZWFkZXJ7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XHJcbn1cclxuXHJcbi5uZWVkLWhlbHAtdGV4dCB7XHJcbiAgICBjb2xvcjogJGNvbG9yLW5leHRnZW4tZ3JlZW47XHJcbiAgICBmbG9hdDogcmlnaHQgIWltcG9ydGFudDtcclxufVxyXG5cclxuLmNoYW5nZS1wYXNzd29yZC10aXRsZSB7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIGNvbG9yOiAkY29sb3ItbmV4dGdlbi1ibGFjaztcclxuICAgIHBhZGRpbmctdG9wOiAycmVtO1xyXG59XHJcblxyXG4uZm9ybS1jaGFuZ2UtcGFzc3dvcmQge1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBwYWRkaW5nLXRvcDogMnJlbTtcclxufVxyXG5cclxuLmJ1dHRvbi1jaGFuZ2UtcGFzc3dvcmQge1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgcGFkZGluZy10b3A6IDJyZW07XHJcbn1cclxuXHJcbi52YWxpZGF0aW9uLXN1bW1hcnktcGFzc3dvcmQge1xyXG4gICAgbGlzdC1zdHlsZTogbm9uZTtcclxuXHJcbiAgICBsaSB7XHJcbiAgICAgICAgZGlzcGxheTogZmxleDtcclxuXHJcbiAgICAgICAgLmNoZWNrLXBsYWNlIHtcclxuICAgICAgICAgICAgY29sb3I6ICRjb2xvci1uZXh0Z2VuLWdyZWVuICAhaW1wb3J0YW50O1xyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG5cclxuLnRleHQtdmFsaWRhdGlvbiB7XHJcbiAgICBjb2xvcjogJGNvbG9yLW5leHRnZW4tZ3JleSAgIWltcG9ydGFudDtcclxufVxyXG5cclxuLmNoZWNrLXBsYWNlIHtcclxuICAgIHdpZHRoOiAyMnB4O1xyXG4gICAgaGVpZ2h0OiBhdXRvO1xyXG59XHJcblxyXG4uY2hhbmdlLXBhc3N3b3JkLWNvbnRlbnQge1xyXG4gICAgbWluLWhlaWdodDogODUlO1xyXG4gICAgcGFkZGluZy1ib3R0b206IDNyZW07XHJcbn1cclxuIl19 */";

/***/ }),

/***/ 11076:
/*!***************************************************************************************************************!*\
  !*** ./src/app/pages/edit-profile/change-passwords/confirm-changed/confirm-changed.component.scss?ngResource ***!
  \***************************************************************************************************************/
/***/ ((module) => {

module.exports = ":root {\n  --nc-color-nextgen-neutral-grey-50: red;\n  --nc-color-nextgen-white: yellow;\n  --nc-color-nextgen-blue: #0d152e;\n  --nc-color-nextgen-green: #00908d;\n  --nc-color-nextgen-black: #000000;\n  --nc-color-nextgen-grey-background: #c8d3da;\n  --nc-color-nextgen-grey: #92a2ac;\n  --nc-color-nextgen-stone-grey: #fafafa;\n  --nc-color-nextgen-error: #fc1055;\n  --nc-color-nextgen-neutral-grey: #414141;\n  --nc-color-nextgen-fibrant-green: #00bab6;\n  --nc-color-nextgen-warning: #ffd048;\n  --nc-color-nextgen-green-background: #e6f2f2;\n  --nc-color-nextgen-neutral-grey-400: #7a7a7a;\n  --nc-color-nextgen-neutral-grey-100: #eff3f5;\n  --nc-color-nextgen-status-error: #ba0c3f;\n  --nc-color-nextgen-status-error-background: #ffeff4;\n  --nc-color-nextgen-status-warning: #cba127;\n  --nc-color-nextgen-status-warning-background: #fff8e6;\n  --nc-color-nextgen-blue-100: #dfeff2;\n  --nc-color-nextgen-error-red-700: #f62459;\n  --nc-color-nextgen-blue-500: #006192;\n  --nc-color-nextgen-blue-400: #79cdec;\n  --nc-color-nextgen-red-500: #ff6592;\n  --nc-color-nextgen-secondary-blue-300: #13a0d3;\n  --lumi-white-color: #ffffff;\n  --lumi-primary-yellow-color: #fab600;\n}\n\n.ion-color-green {\n  --ion-color-base: var(--nc-color-nextgen-green);\n  --ion-color-base-rgb: var(--nc-color-nextgen-green);\n  --ion-color-contrast: var(--nc-color-nextgen-white);\n  --ion-color-contrast-rgb: var(--nc-color-nextgen-green);\n  --ion-color-shade: var(--nc-color-nextgen-green);\n  --ion-color-tint: var(--nc-color-nextgen-green);\n}\n\n.confirm-change-page {\n  text-align: center;\n}\n\n.confirm-change-page .confirm-change-title h1 {\n  color: var(--nc-color-nextgen-blue);\n}\n\n.confirm-change-page .lock-icon {\n  margin-bottom: 25px;\n}\n\n.confirm-change-page .lock-icon i {\n  background-color: #C8D3DA;\n  padding: 6% 7%;\n  border-radius: 50%;\n  color: white;\n  font-size: 40px !important;\n}\n\n.confirm-change-page .confirm-change-content .confirm-change-text {\n  padding-top: 8px;\n  padding-bottom: 24px;\n}\n\n.confirm-change-page .confirm-change-content .confirm-change-btn .confirm-btn {\n  margin-bottom: 20px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFwuLlxcY29sb3Iuc2NzcyIsImNvbmZpcm0tY2hhbmdlZC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNDLHVDQUFBO0VBQ0EsZ0NBQUE7RUFDQSxnQ0FBQTtFQUNBLGlDQUFBO0VBQ0EsaUNBQUE7RUFDQSwyQ0FBQTtFQUNBLGdDQUFBO0VBQ0Esc0NBQUE7RUFDQSxpQ0FBQTtFQUNBLHdDQUFBO0VBQ0EseUNBQUE7RUFDQSxtQ0FBQTtFQUNBLDRDQUFBO0VBQ0EsNENBQUE7RUFDQSw0Q0FBQTtFQUNBLHdDQUFBO0VBQ0EsbURBQUE7RUFDQSwwQ0FBQTtFQUNBLHFEQUFBO0VBQ0Esb0NBQUE7RUFDQSx5Q0FBQTtFQUNBLG9DQUFBO0VBQ0Esb0NBQUE7RUFDQSxtQ0FBQTtFQUNBLDhDQUFBO0VBRUEsMkJBQUE7RUFDQSxvQ0FBQTtBQ0FEOztBRGdDQTtFQUNDLCtDQUFBO0VBQ0EsbURBQUE7RUFDQSxtREFBQTtFQUNBLHVEQUFBO0VBQ0EsZ0RBQUE7RUFDQSwrQ0FBQTtBQzdCRDs7QUFuQ0E7RUFDSSxrQkFBQTtBQXNDSjs7QUFuQ1E7RUFDSSxtQ0R1QlM7QUNjckI7O0FBakNJO0VBQ0ksbUJBQUE7QUFtQ1I7O0FBakNRO0VBQ0kseUJBQUE7RUFDQSxjQUFBO0VBQ0Esa0JBQUE7RUFDQSxZQUFBO0VBQ0EsMEJBQUE7QUFtQ1o7O0FBOUJRO0VBQ0ksZ0JBQUE7RUFDQSxvQkFBQTtBQWdDWjs7QUE3Qlk7RUFDSSxtQkFBQTtBQStCaEIiLCJmaWxlIjoiY29uZmlybS1jaGFuZ2VkLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiOnJvb3Qge1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNTA6IHJlZDtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4td2hpdGU6IHllbGxvdztcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZTogIzBkMTUyZTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW46ICMwMDkwOGQ7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWJsYWNrOiAjMDAwMDAwO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ncmV5LWJhY2tncm91bmQ6ICNjOGQzZGE7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWdyZXk6ICM5MmEyYWM7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0b25lLWdyZXk6ICNmYWZhZmE7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWVycm9yOiAjZmMxMDU1O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXk6ICM0MTQxNDE7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWZpYnJhbnQtZ3JlZW46ICMwMGJhYjY7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXdhcm5pbmc6ICNmZmQwNDg7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuLWJhY2tncm91bmQ6ICNlNmYyZjI7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS00MDA6ICM3YTdhN2E7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS0xMDA6ICNlZmYzZjU7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy1lcnJvcjogI2JhMGMzZjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yLWJhY2tncm91bmQ6ICNmZmVmZjQ7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy13YXJuaW5nOiAjY2JhMTI3O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtd2FybmluZy1iYWNrZ3JvdW5kOiAjZmZmOGU2O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlLTEwMDogI2RmZWZmMjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tZXJyb3ItcmVkLTcwMDogI2Y2MjQ1OTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZS01MDA6ICMwMDYxOTI7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWJsdWUtNDAwOiAjNzljZGVjO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1yZWQtNTAwOiAjZmY2NTkyO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zZWNvbmRhcnktYmx1ZS0zMDA6ICMxM2EwZDM7XHJcblxyXG5cdC0tbHVtaS13aGl0ZS1jb2xvcjogI2ZmZmZmZjtcclxuXHQtLWx1bWktcHJpbWFyeS15ZWxsb3ctY29sb3I6ICNmYWI2MDA7XHJcbn1cclxuJGNvbG9yLW5leHRnZW4tYmx1ZTogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlKTtcclxuJGNvbG9yLW5leHRnZW4tZ3JlZW46IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4pO1xyXG4kY29sb3ItbmV4dGdlbi13aGl0ZTogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi13aGl0ZSk7XHJcbiRjb2xvci1uZXh0Z2VuLWJsYWNrOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWJsYWNrKTtcclxuJGNvbG9yLW5leHRnZW4tZ3JleS1iYWNrZ3JvdW5kOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZXktYmFja2dyb3VuZCk7XHJcbiRjb2xvci1uZXh0Z2VuLWdyZXk6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JleSk7XHJcbiRjb2xvci1uZXh0Z2VuLXN0b25lLWdyZXk6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tc3RvbmUtZ3JleSk7XHJcbiRjb2xvci1uZXh0Z2VuLWVycm9yOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWVycm9yKTtcclxuJGNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5OiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleSk7XHJcbiRjb2xvci1uZXh0Z2VuLWZpYnJhbnQtZ3JlZW46IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZmlicmFudC1ncmVlbik7XHJcbiRjb2xvci1uZXh0Z2VuLXdhcm5pbmc6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4td2FybmluZyk7XHJcbiRjb2xvci1uZXh0Z2VuLWdyZWVuLWJhY2tncm91bmQ6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4tYmFja2dyb3VuZCk7XHJcbiRjb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS01MDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNTApO1xyXG4kY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNDAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS00MDApO1xyXG4kY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktMTAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS0xMDApO1xyXG4kY29sb3ItbmV4dGdlbi1zdGF0dXMtZXJyb3I6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yKTtcclxuJGNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yLWJhY2tncm91bmQ6IHZhcihcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yLWJhY2tncm91bmRcclxuKTtcclxuJGNvbG9yLW5leHRnZW4tc3RhdHVzLXdhcm5pbmc6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLXdhcm5pbmcpO1xyXG4kY29sb3ItbmV4dGdlbi1zdGF0dXMtd2FybmluZy1iYWNrZ3JvdW5kOiB2YXIoXHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy13YXJuaW5nLWJhY2tncm91bmRcclxuKTtcclxuJGNvbG9yLW5leHRnZW4tYmx1ZS0xMDA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZS0xMDApO1xyXG4kY29sb3ItbmV4dGdlbi1lcnJvci1yZWQtNzAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWVycm9yLXJlZC03MDApO1xyXG4kY29sb3ItbmV4dGdlbi1ibHVlLTUwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlLTUwMCk7XHJcbiRjb2xvci1uZXh0Z2VuLWJsdWUtNDAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWJsdWUtNDAwKTtcclxuJGNvbG9yLW5leHRnZW4tcmVkLTUwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1yZWQtNTAwKTtcclxuJGNvbG9yLW5leHRnZW4tc2Vjb25kYXJ5LWJsdWUtMzAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXNlY29uZGFyeS1ibHVlLTMwMCk7XHJcblxyXG4uaW9uLWNvbG9yLWdyZWVuIHtcclxuXHQtLWlvbi1jb2xvci1iYXNlOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuKTtcclxuXHQtLWlvbi1jb2xvci1iYXNlLXJnYjogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbik7XHJcblx0LS1pb24tY29sb3ItY29udHJhc3Q6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4td2hpdGUpO1xyXG5cdC0taW9uLWNvbG9yLWNvbnRyYXN0LXJnYjogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbik7XHJcblx0LS1pb24tY29sb3Itc2hhZGU6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4pO1xyXG5cdC0taW9uLWNvbG9yLXRpbnQ6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4pO1xyXG59XHJcbiIsIkBpbXBvcnQgXCIuLi8uLi8uLi8uLi8uLi9jb2xvci5zY3NzXCI7XHJcblxyXG4uY29uZmlybS1jaGFuZ2UtcGFnZSB7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcblxyXG4gICAgLmNvbmZpcm0tY2hhbmdlLXRpdGxlIHtcclxuICAgICAgICBoMSB7XHJcbiAgICAgICAgICAgIGNvbG9yOiAkY29sb3ItbmV4dGdlbi1ibHVlO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAubG9jay1pY29uIHtcclxuICAgICAgICBtYXJnaW4tYm90dG9tOiAyNXB4O1xyXG5cclxuICAgICAgICBpIHtcclxuICAgICAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogI0M4RDNEQTtcclxuICAgICAgICAgICAgcGFkZGluZzogNiUgNyU7XHJcbiAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDUwJTtcclxuICAgICAgICAgICAgY29sb3I6IHdoaXRlO1xyXG4gICAgICAgICAgICBmb250LXNpemU6IDQwcHggIWltcG9ydGFudDtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLmNvbmZpcm0tY2hhbmdlLWNvbnRlbnQge1xyXG4gICAgICAgIC5jb25maXJtLWNoYW5nZS10ZXh0e1xyXG4gICAgICAgICAgICBwYWRkaW5nLXRvcDogOHB4O1xyXG4gICAgICAgICAgICBwYWRkaW5nLWJvdHRvbToyNHB4XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC5jb25maXJtLWNoYW5nZS1idG4ge1xyXG4gICAgICAgICAgICAuY29uZmlybS1idG4ge1xyXG4gICAgICAgICAgICAgICAgbWFyZ2luLWJvdHRvbTogMjBweDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxufSJdfQ== */";

/***/ }),

/***/ 72545:
/*!**********************************************************************!*\
  !*** ./src/app/pages/edit-profile/edit-profile.page.scss?ngResource ***!
  \**********************************************************************/
/***/ ((module) => {

module.exports = ":root {\n  --nc-color-nextgen-neutral-grey-50: red;\n  --nc-color-nextgen-white: yellow;\n  --nc-color-nextgen-blue: #0d152e;\n  --nc-color-nextgen-green: #00908d;\n  --nc-color-nextgen-black: #000000;\n  --nc-color-nextgen-grey-background: #c8d3da;\n  --nc-color-nextgen-grey: #92a2ac;\n  --nc-color-nextgen-stone-grey: #fafafa;\n  --nc-color-nextgen-error: #fc1055;\n  --nc-color-nextgen-neutral-grey: #414141;\n  --nc-color-nextgen-fibrant-green: #00bab6;\n  --nc-color-nextgen-warning: #ffd048;\n  --nc-color-nextgen-green-background: #e6f2f2;\n  --nc-color-nextgen-neutral-grey-400: #7a7a7a;\n  --nc-color-nextgen-neutral-grey-100: #eff3f5;\n  --nc-color-nextgen-status-error: #ba0c3f;\n  --nc-color-nextgen-status-error-background: #ffeff4;\n  --nc-color-nextgen-status-warning: #cba127;\n  --nc-color-nextgen-status-warning-background: #fff8e6;\n  --nc-color-nextgen-blue-100: #dfeff2;\n  --nc-color-nextgen-error-red-700: #f62459;\n  --nc-color-nextgen-blue-500: #006192;\n  --nc-color-nextgen-blue-400: #79cdec;\n  --nc-color-nextgen-red-500: #ff6592;\n  --nc-color-nextgen-secondary-blue-300: #13a0d3;\n  --lumi-white-color: #ffffff;\n  --lumi-primary-yellow-color: #fab600;\n}\n\n.ion-color-green {\n  --ion-color-base: var(--nc-color-nextgen-green);\n  --ion-color-base-rgb: var(--nc-color-nextgen-green);\n  --ion-color-contrast: var(--nc-color-nextgen-white);\n  --ion-color-contrast-rgb: var(--nc-color-nextgen-green);\n  --ion-color-shade: var(--nc-color-nextgen-green);\n  --ion-color-tint: var(--nc-color-nextgen-green);\n}\n\n/*\n * 1. Custom CSS \n * ----------------------------------------------------------------------------\n */\n\n:root {\n  --nc-color-nextgen-neutral-grey-50: red;\n  --nc-color-nextgen-white: yellow;\n  --nc-color-nextgen-blue: #0d152e;\n  --nc-color-nextgen-green: #00908d;\n  --nc-color-nextgen-black: #000000;\n  --nc-color-nextgen-grey-background: #c8d3da;\n  --nc-color-nextgen-grey: #92a2ac;\n  --nc-color-nextgen-stone-grey: #fafafa;\n  --nc-color-nextgen-error: #fc1055;\n  --nc-color-nextgen-neutral-grey: #414141;\n  --nc-color-nextgen-fibrant-green: #00bab6;\n  --nc-color-nextgen-warning: #ffd048;\n  --nc-color-nextgen-green-background: #e6f2f2;\n  --nc-color-nextgen-neutral-grey-400: #7a7a7a;\n  --nc-color-nextgen-neutral-grey-100: #eff3f5;\n  --nc-color-nextgen-status-error: #ba0c3f;\n  --nc-color-nextgen-status-error-background: #ffeff4;\n  --nc-color-nextgen-status-warning: #cba127;\n  --nc-color-nextgen-status-warning-background: #fff8e6;\n  --nc-color-nextgen-blue-100: #dfeff2;\n  --nc-color-nextgen-error-red-700: #f62459;\n  --nc-color-nextgen-blue-500: #006192;\n  --nc-color-nextgen-blue-400: #79cdec;\n  --nc-color-nextgen-red-500: #ff6592;\n  --nc-color-nextgen-secondary-blue-300: #13a0d3;\n  --lumi-white-color: #ffffff;\n  --lumi-primary-yellow-color: #fab600;\n}\n\n.ion-color-green {\n  --ion-color-base: var(--nc-color-nextgen-green);\n  --ion-color-base-rgb: var(--nc-color-nextgen-green);\n  --ion-color-contrast: var(--nc-color-nextgen-white);\n  --ion-color-contrast-rgb: var(--nc-color-nextgen-green);\n  --ion-color-shade: var(--nc-color-nextgen-green);\n  --ion-color-tint: var(--nc-color-nextgen-green);\n}\n\n.display-xl {\n  font-size: 41px !important;\n  font-weight: 400 !important;\n  line-height: 120% !important;\n}\n\n.display-md {\n  font-size: 36px !important;\n  font-weight: 400 !important;\n  line-height: 120% !important;\n}\n\n.h1 {\n  font-size: 31px !important;\n  font-weight: 400 !important;\n  line-height: 120% !important;\n}\n\n.h2 {\n  font-size: 28px !important;\n  font-weight: 400 !important;\n  line-height: 120% !important;\n}\n\n.h3 {\n  font-size: 25px !important;\n  font-weight: 400 !important;\n  line-height: 120% !important;\n}\n\n.h4 {\n  font-size: 22px !important;\n  font-weight: 400 !important;\n  line-height: 120% !important;\n}\n\n.h5 {\n  font-size: 19px !important;\n  font-weight: 400 !important;\n  line-height: 120% !important;\n}\n\n.h6 {\n  font-size: 17px !important;\n  font-weight: 400 !important;\n  line-height: 120% !important;\n}\n\n.body-l {\n  font-size: 17px !important;\n  font-weight: 400 !important;\n  line-height: 120% !important;\n}\n\n.body-n {\n  font-size: 15px !important;\n  font-weight: 400 !important;\n  line-height: 120% !important;\n}\n\n.body-sm {\n  font-size: 13px !important;\n  font-weight: 400 !important;\n  line-height: 120% !important;\n}\n\n.body-xs {\n  font-size: 12px !important;\n  font-weight: 400 !important;\n  line-height: 120% !important;\n}\n\n.semibold.display-xl {\n  font-weight: 600 !important;\n}\n\n.semibold.display-md {\n  font-weight: 600 !important;\n}\n\n.semibold.h1 {\n  font-weight: 600 !important;\n}\n\n.semibold.h2 {\n  font-weight: 600 !important;\n}\n\n.semibold.h3 {\n  font-weight: 600 !important;\n}\n\n.semibold.h4 {\n  font-weight: 600 !important;\n}\n\n.semibold.h5 {\n  font-weight: 600 !important;\n}\n\n.semibold.h6 {\n  font-weight: 600 !important;\n}\n\n.semibold.body-l {\n  font-weight: 600 !important;\n}\n\n.semibold.body-n {\n  font-weight: 600 !important;\n}\n\n.semibold.body-sm {\n  font-weight: 600 !important;\n}\n\n.semibold.body-xs {\n  font-weight: 600 !important;\n}\n\n.bold.display-xl {\n  font-weight: 700 !important;\n}\n\n.bold.display-md {\n  font-weight: 700 !important;\n}\n\n.bold.h1 {\n  font-weight: 700 !important;\n}\n\n.bold.h2 {\n  font-weight: 700 !important;\n}\n\n.bold.h3 {\n  font-weight: 700 !important;\n}\n\n.bold.h4 {\n  font-weight: 700 !important;\n}\n\n.bold.h5 {\n  font-weight: 700 !important;\n}\n\n.bold.h6 {\n  font-weight: 700 !important;\n}\n\n.bold.body-l {\n  font-weight: 700 !important;\n}\n\n.bold.body-n {\n  font-weight: 700 !important;\n}\n\n.bold.body-sm {\n  font-weight: 700 !important;\n}\n\n.bold.body-xs {\n  font-weight: 700 !important;\n}\n\n@font-face {\n  font-family: \"Allianz Neo\";\n  font-style: normal;\n  font-weight: 300;\n  font-display: swap;\n  src: url('AllianzNeoW04-Light.woff2') format(\"woff2\"), url('AllianzNeoW04-Light.woff') format(\"woff\");\n}\n\n@font-face {\n  font-family: \"Allianz Neo\";\n  font-style: italic;\n  font-weight: 300;\n  font-display: swap;\n  src: url('AllianzNeoW04-LightItalic.woff2') format(\"woff2\"), url('AllianzNeoW04-LightItalic.woff') format(\"woff\");\n}\n\n@font-face {\n  font-family: \"Allianz Neo\";\n  font-style: normal;\n  font-weight: 400;\n  font-display: swap;\n  src: url('AllianzNeoW04-Regular.woff2') format(\"woff2\"), url('AllianzNeoW04-Regular.woff') format(\"woff\");\n}\n\n@font-face {\n  font-family: \"Allianz Neo\";\n  font-style: italic;\n  font-weight: 400;\n  font-display: swap;\n  src: url('AllianzNeoW04-Italic.woff2') format(\"woff2\"), url('AllianzNeoW04-Italic.woff') format(\"woff\");\n}\n\n@font-face {\n  font-family: \"Allianz Neo\";\n  font-style: normal;\n  font-weight: 600;\n  font-display: swap;\n  src: url('AllianzNeoW04-SemiBold.woff2') format(\"woff2\"), url('AllianzNeoW04-SemiBold.woff') format(\"woff\");\n}\n\n@font-face {\n  font-family: \"Allianz Neo\";\n  font-style: italic;\n  font-weight: 600;\n  font-display: swap;\n  src: url('AllianzNeoW04-SemiBoldIt.woff2') format(\"woff2\"), url('AllianzNeoW04-SemiBoldIt.woff') format(\"woff\");\n}\n\n@font-face {\n  font-family: \"Allianz Neo\";\n  font-style: normal;\n  font-weight: 700;\n  font-display: swap;\n  src: url('AllianzNeoW04-Bold.woff2') format(\"woff2\"), url('AllianzNeoW04-Bold.woff') format(\"woff\");\n}\n\n@font-face {\n  font-family: \"Allianz Neo\";\n  font-style: italic;\n  font-weight: 700;\n  font-display: swap;\n  src: url('AllianzNeoW04-BoldItalic.woff2') format(\"woff2\"), url('AllianzNeoW04-BoldItalic.woff') format(\"woff\");\n}\n\n* {\n  color: var(--nc-color-nextgen-neutral-grey);\n  font-family: \"Allianz Neo\", sans-serif;\n  font-weight: 400;\n  font-size: 16px;\n}\n\nhtml {\n  --ion-safe-area-top: 0px;\n}\n\n.col-1 {\n  width: 8.33%;\n}\n\n.col-2 {\n  width: 16.66%;\n}\n\n.col-3 {\n  width: 25%;\n}\n\n.col-4 {\n  width: 33.33%;\n}\n\n.col-5 {\n  width: 41.66%;\n}\n\n.col-6 {\n  width: 50%;\n}\n\n.col-7 {\n  width: 58.33%;\n}\n\n.col-8 {\n  width: 66.66%;\n}\n\n.col-9 {\n  width: 75%;\n}\n\n.col-10 {\n  width: 83.33%;\n}\n\n.col-11 {\n  width: 91.66%;\n}\n\n.col-12 {\n  width: 100%;\n}\n\n@media only screen and (max-width: 576px) {\n  /* For tablets: */\n  .col-sm-1 {\n    width: 8.33%;\n  }\n\n  .col-sm-2 {\n    width: 16.66%;\n  }\n\n  .col-sm-3 {\n    width: 25%;\n  }\n\n  .col-sm-4 {\n    width: 33.33%;\n  }\n\n  .col-sm-5 {\n    width: 41.66%;\n  }\n\n  .col-sm-6 {\n    width: 50%;\n  }\n\n  .col-sm-7 {\n    width: 58.33%;\n  }\n\n  .col-sm-8 {\n    width: 66.66%;\n  }\n\n  .col-sm-9 {\n    width: 75%;\n  }\n\n  .col-sm-10 {\n    width: 83.33%;\n  }\n\n  .col-sm-11 {\n    width: 91.66%;\n  }\n\n  .col-sm-12 {\n    width: 100%;\n  }\n}\n\n@media only screen and (max-width: 768px) and (min-width: 577px) {\n  /* For tablets: */\n  .col-md-1 {\n    width: 8.33%;\n  }\n\n  .col-md-2 {\n    width: 16.66%;\n  }\n\n  .col-md-3 {\n    width: 25%;\n  }\n\n  .col-md-4 {\n    width: 33.33%;\n  }\n\n  .col-md-5 {\n    width: 41.66%;\n  }\n\n  .col-md-6 {\n    width: 50%;\n  }\n\n  .col-md-7 {\n    width: 58.33%;\n  }\n\n  .col-md-8 {\n    width: 66.66%;\n  }\n\n  .col-md-9 {\n    width: 75%;\n  }\n\n  .col-md-10 {\n    width: 83.33%;\n  }\n\n  .col-md-11 {\n    width: 91.66%;\n  }\n\n  .col-md-12 {\n    width: 100%;\n  }\n}\n\n@media only screen and (min-width: 769px) {\n  /* For tablets: */\n  .col-lg-1 {\n    width: 8.33%;\n  }\n\n  .col-lg-2 {\n    width: 16.66%;\n  }\n\n  .col-lg-3 {\n    width: 25%;\n  }\n\n  .col-lg-4 {\n    width: 33.33%;\n  }\n\n  .col-lg-5 {\n    width: 41.66%;\n  }\n\n  .col-lg-6 {\n    width: 50%;\n  }\n\n  .col-lg-7 {\n    width: 58.33%;\n  }\n\n  .col-lg-8 {\n    width: 66.66%;\n  }\n\n  .col-lg-9 {\n    width: 75%;\n  }\n\n  .col-lg-10 {\n    width: 83.33%;\n  }\n\n  .col-lg-11 {\n    width: 91.66%;\n  }\n\n  .col-lg-12 {\n    width: 100%;\n  }\n}\n\n.row {\n  display: flex;\n  justify-content: center;\n  align-items: center;\n}\n\n.custom-toast {\n  --max-width: fit-content;\n}\n\n/*\n * 2. Custom CSS for compatibility with Edge\n * ----------------------------------------------------------------------------\n */\n\ninput::-ms-reveal,\ninput::-ms-clear {\n  display: none;\n}\n\n.swal2-popup {\n  margin-top: 20px;\n}\n\n/*\n * 3. Custom CSS for loading controller\n * ----------------------------------------------------------------------------\n */\n\n.transparent-loading-class {\n  --background: transparent;\n  --spinner-color: #47e6b1;\n}\n\n.loading-wrapper.sc-ion-loading-md {\n  box-shadow: unset;\n  -webkit-box-shadow: unset;\n}\n\n.uil {\n  color: var(--nc-color-nextgen-grey);\n}\n\n.btn {\n  height: 48px;\n  border-radius: 28px;\n  padding: 0px 41px 0px 41px;\n  box-shadow: none;\n}\n\n.btn.btn-circle {\n  background-color: var(--nc-color-nextgen-stone-grey) !important;\n  color: var(--nc-color-nextgen-black);\n  padding: unset !important;\n  height: 36px !important;\n  width: 36px !important;\n  border-radius: 50% !important;\n}\n\n.btn.btn-circle i {\n  color: var(--nc-color-nextgen-black);\n}\n\n.btn.primary {\n  background: var(--nc-color-nextgen-green);\n  color: var(--nc-color-nextgen-white);\n}\n\n.btn.primary .uil {\n  color: var(--nc-color-nextgen-white);\n}\n\n.btn.primary:disabled {\n  background-color: var(--nc-color-nextgen-grey-background) !important;\n  color: var(--nc-color-nextgen-grey) !important;\n}\n\n.btn.secondary {\n  background: var(--nc-color-nextgen-white) !important;\n  border-color: var(--nc-color-nextgen-green);\n  border: solid 1px;\n  color: var(--nc-color-nextgen-green);\n}\n\n.btn.secondary .uil {\n  color: var(--nc-color-nextgen-green);\n}\n\n.btn.secondary:disabled {\n  background-color: var(--nc-color-nextgen-white) !important;\n  color: var(--nc-color-nextgen-grey) !important;\n  border-color: var(--nc-color-nextgen-grey-background) !important;\n}\n\n.btn.transparent {\n  background: transparent !important;\n  border-color: var(--nc-color-nextgen-green);\n  border: solid 1px;\n  color: var(--nc-color-nextgen-green);\n}\n\n.btn.transparent .uil {\n  color: var(--nc-color-nextgen-green);\n}\n\n.btn.transparent:disabled {\n  background-color: transparent !important;\n  color: var(--nc-color-nextgen-grey) !important;\n  border-color: var(--nc-color-nextgen-grey-background) !important;\n}\n\n.btn.btn-large {\n  height: 56px !important;\n  width: 100%;\n}\n\n.btn.bold {\n  font-weight: 700 !important;\n}\n\n.btn.semibold {\n  font-weight: 600 !important;\n}\n\n.btn-no-space {\n  padding: 5px !important;\n  height: -moz-fit-content;\n  height: fit-content;\n}\n\n.btn-back {\n  width: 31px;\n  height: 28px;\n  background-color: transparent;\n  padding: 0;\n  color: var(--nc-color-nextgen-green);\n}\n\n.container {\n  padding: 2rem;\n  height: 100%;\n}\n\n.body-section {\n  width: 100%;\n  height: 95%;\n  overflow-y: auto;\n  position: relative;\n}\n\n.top-section {\n  width: 100%;\n  height: 10%;\n  justify-content: space-between;\n  display: flex;\n  align-items: center;\n}\n\n.form-control {\n  position: relative;\n  height: 85px;\n  margin-bottom: 8px;\n}\n\n.control {\n  border-radius: 8px;\n  height: 56px;\n  border: 1px solid var(--nc-color-nextgen-grey-background);\n  width: 100%;\n  position: absolute;\n  top: 32px;\n  background-color: var(--nc-color-nextgen-white);\n}\n\n.control table {\n  table-layout: fixed;\n  border-collapse: unset;\n}\n\n.control input {\n  height: 54px;\n  border: unset;\n  border-radius: 8px;\n  width: max-content;\n  width: 100%;\n  pointer-events: auto;\n  background-color: var(--nc-color-nextgen-white);\n}\n\n.control.textarea {\n  height: 108px;\n}\n\n.control textarea {\n  height: 106px;\n  border: unset;\n  border-radius: 8px;\n  width: max-content;\n  width: 100%;\n  pointer-events: auto;\n  resize: none;\n  background-color: var(--nc-color-nextgen-white);\n}\n\n.control input:focus {\n  outline: none;\n}\n\n.control:focus-within {\n  border-color: var(--nc-color-nextgen-green);\n}\n\n.control:focus-within .first-icon {\n  display: none;\n}\n\n.control:focus-within .first-icon.non-hidden {\n  display: table-cell;\n}\n\n.control .first-icon {\n  width: 32px;\n  text-align: center;\n  padding-left: 8px;\n}\n\n.control .first-icon i {\n  font-size: 24px !important;\n}\n\n.control .second-icon {\n  width: 32px;\n  text-align: center;\n}\n\n.control .second-icon i {\n  font-size: 24px !important;\n}\n\n.control:focus-within ~ div .control-label {\n  color: var(--nc-color-nextgen-green);\n}\n\n.control-error .control {\n  border-color: var(--nc-color-nextgen-error);\n}\n\n.control-error .control-label {\n  color: var(--nc-color-nextgen-error) !important;\n}\n\n.validation-summary li {\n  color: var(--nc-color-nextgen-error) !important;\n  list-style: none;\n}\n\n.validation-summary li i {\n  color: var(--nc-color-nextgen-error) !important;\n}\n\n.mr-1 {\n  margin-right: 0.5rem;\n}\n\n.mb-1 {\n  margin-bottom: 0.5rem;\n}\n\n.dialog-pane {\n  position: absolute;\n  pointer-events: auto;\n  box-sizing: border-box;\n  z-index: 1000;\n  display: block;\n  max-width: 100%;\n  max-height: 100%;\n}\n\n.overlay-backdrop {\n  background-color: var(--nc-color-nextgen-neutral-grey);\n  opacity: 0.2 !important;\n}\n\n.dialog-container {\n  animation: fadeIn 0.5s linear;\n  background-color: var(--nc-color-nextgen-white);\n}\n\n@keyframes fadeIn {\n  from {\n    transform: translateY(100%);\n  }\n  to {\n    transform: translateY(0%);\n  }\n}\n\n.error {\n  color: var(--nc-color-nextgen-error);\n}\n\n.error.background {\n  background-color: var(--nc-color-nextgen-error);\n}\n\n.success {\n  color: var(--nc-color-nextgen-fibrant-green);\n}\n\n.success.background {\n  background-color: var(--nc-color-nextgen-fibrant-green);\n}\n\n.warning {\n  color: var(--nc-color-nextgen-warning);\n}\n\n.warning.background {\n  background-color: var(--nc-color-nextgen-warning);\n}\n\n.select {\n  width: 100%;\n  height: 54px;\n  border: unset;\n  border-radius: 8px;\n  display: grid;\n  -webkit-appearance: none;\n          appearance: none;\n  grid-template-areas: \"select\";\n}\n\n.select:focus {\n  outline: unset;\n}\n\n.color-black {\n  color: var(--nc-color-nextgen-black);\n}\n\n.modal-default {\n  --width: 100%;\n  --height: 100%;\n}\n\n.integration-panel {\n  width: 100%;\n  height: 100%;\n  max-width: 100% !important;\n}\n\n.verloop-button {\n  visibility: hidden;\n}\n\n.back-area {\n  position: fixed;\n  top: 0;\n  right: 0;\n  height: 50px;\n  width: 100%;\n  background-color: var(--nc-color-nextgen-neutral-grey-50);\n  z-index: 9999999;\n}\n\n.back-area.ios {\n  height: 80px;\n}\n\n.title-widget {\n  text-align: center;\n  position: sticky;\n  top: 48px;\n}\n\n.button-back {\n  background-color: #fafafa;\n  height: 36px;\n  width: 36px;\n  border-radius: 50%;\n  position: absolute;\n  left: 18px;\n  bottom: 4px;\n}\n\n.icon-close-widget {\n  position: absolute;\n  z-index: 250;\n  left: 11px;\n  bottom: 13px;\n}\n\n.data-default {\n  position: absolute;\n  top: 50%;\n  left: 50%;\n  transform: translate(-50%, -50%);\n  text-align: center;\n  color: var(--nc-color-nextgen-neutral-grey-400);\n  z-index: 1000;\n}\n\n.avaamo__icon {\n  visibility: hidden !important;\n}\n\n.avaamo__chat__widget.ios #avaamo__popup {\n  padding-top: 40px;\n}\n\n.d-flex {\n  display: flex;\n}\n\nnextcare-layout {\n  left: 0;\n  right: 0;\n  top: 0;\n  bottom: 0;\n  display: flex;\n  position: absolute;\n  flex-direction: column;\n  justify-content: space-between;\n  contain: layout size style;\n  overflow: hidden;\n  background-color: var(--nc-color-nextgen-neutral-grey-50);\n  padding-right: 24px;\n  padding-left: 24px;\n}\n\nion-header.ios.header-ios {\n  margin-top: 40px;\n}\n\n.header-ios ion-toolbar:last-of-type {\n  --border-width: 0px !important;\n}\n\n.header-md.md::after {\n  display: none;\n}\n\nion-toolbar {\n  padding-right: unset !important;\n  padding-left: unset !important;\n}\n\ni.icon-back {\n  content: url('long-arrow-left-icon.svg');\n}\n\n.verloop-widget.ios .verloop-container.visible {\n  height: calc(100% - 40px);\n  top: 40px;\n}\n\n#nextcare-ads {\n  display: none;\n  overflow: scroll;\n  height: 180px;\n}\n\n.d-block {\n  display: block;\n}\n\n.title-text {\n  color: var(--nc-color-nextgen-blue);\n}\n\n:host ion-datetime #shadow-root .datetime-calendar .calendar-header .calendar-action-buttons .calendar-month-year {\n  align-items: center;\n  justify-content: center;\n  display: flex;\n  width: 100%;\n}\n\n:host ion-datetime #shadow-root .datetime-calendar .calendar-header .calendar-action-buttons .calendar-month-year ion-icon {\n  display: none;\n}\n\n:host ion-datetime #shadow-root .datetime-calendar .calendar-header .calendar-action-buttons .calendar-next-prev {\n  position: absolute;\n  width: 100%;\n  right: 0;\n}\n\n:host ion-datetime #shadow-root .datetime-calendar .calendar-header .calendar-action-buttons .calendar-next-prev ion-buttons {\n  display: flex;\n  justify-content: space-between;\n  width: 100%;\n}\n\n.mat-dialog-container {\n  padding: unset !important;\n}\n\n/* Change autocomplete styles in WebKit */\n\ninput:-webkit-autofill,\ninput:-webkit-autofill:hover,\ninput:-webkit-autofill:focus,\ntextarea:-webkit-autofill,\ntextarea:-webkit-autofill:hover,\ntextarea:-webkit-autofill:focus,\nselect:-webkit-autofill,\nselect:-webkit-autofill:hover,\nselect:-webkit-autofill:focus {\n  -webkit-text-fill-color: black;\n  -webkit-box-shadow: 0 0 0px 1000px white inset;\n  -webkit-transition: background-color 5000s ease-in-out 0s;\n  transition: background-color 5000s ease-in-out 0s;\n}\n\n.force-update-popup + .cdk-global-overlay-wrapper .save-btn {\n  background: var(--lumi-primary-yellow-color) !important;\n  color: var(--lumi-white-color) !important;\n  font-weight: bold !important;\n}\n\n.force-update-popup + .cdk-global-overlay-wrapper .cancel-btn {\n  color: var(--lumi-primary-yellow-color) !important;\n}\n\n@keyframes slideInRight {\n  0% {\n    transform: translate3d(100%, 0, 0);\n    visibility: visible;\n  }\n  to {\n    transform: translateZ(0);\n  }\n}\n\n.animate__slideInRight {\n  animation-name: slideInRight;\n}\n\n.animate__animated {\n  animation-duration: 0.5s;\n  animation-duration: 0.5s;\n  animation-fill-mode: both;\n}\n\n.body {\n  background-color: #ffff !important;\n}\n\n.back-button {\n  position: absolute;\n  width: 31px;\n  height: 28px;\n  left: 23px;\n  top: 40px;\n  background-color: transparent;\n  padding: 0;\n}\n\n.edit-profile-container {\n  background-color: #ffff;\n}\n\n.edit-profile-container .profile-image-box {\n  margin-bottom: 15px;\n  text-align: center;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n}\n\n.edit-profile-container .profile-image-box .avatar-container {\n  position: relative;\n  height: 100px;\n  width: 100px;\n}\n\n.edit-profile-container .profile-image-box .profile-image {\n  width: 96px;\n  height: 96px;\n  border-radius: 50%;\n  object-fit: cover;\n}\n\n.edit-profile-container .profile-image-box .camera-icon {\n  right: 0;\n  bottom: 0;\n  align-items: center;\n  justify-content: center;\n  background: var(--nc-color-nextgen-neutral-grey-100);\n  padding: 10px 12px;\n  border-radius: 50%;\n  text-align: center;\n  position: absolute;\n}\n\n.edit-profile-container .edit-profile-page-header {\n  width: 100%;\n  justify-content: space-between;\n  display: flex;\n  align-items: center;\n}\n\n.edit-profile-container .edit-profile-page-header span {\n  width: 100%;\n  text-align: center;\n}\n\n.edit-profile-container .details-box .details-text {\n  padding-top: 1rem;\n  padding-bottom: 1rem;\n  color: var(--nc-color-nextgen-grey);\n  flex: none;\n  order: 3;\n  flex-grow: 0;\n}\n\n.edit-profile-container .details-box .details-subtitle {\n  padding-top: 0.5rem;\n  padding-bottom: 0.5rem;\n  padding-left: 0.5rem;\n}\n\n.edit-profile-container .details-box .details-subtitle .details-text {\n  color: var(--nc-color-nextgen-neutral-grey-400);\n}\n\n.edit-profile-container .details-box .details-subtitle .email-profile {\n  display: flex;\n  justify-content: space-between;\n}\n\n.edit-profile-container .details-box .details-subtitle .email-profile .email-account {\n  align-items: center;\n  display: flex;\n}\n\n.edit-profile-container .details-box .details-subtitle .email-profile .email-account .details-content {\n  width: 215px;\n  white-space: nowrap;\n  overflow: hidden;\n  text-overflow: ellipsis;\n  color: var(--nc-color-nextgen-blue);\n}\n\n.edit-profile-container .details-box .details-subtitle .email-profile .right-icon {\n  justify-items: right;\n}\n\n.edit-profile-container .menu-item-container .menu-item {\n  display: flex;\n  height: 60px;\n  align-items: center;\n  justify-content: space-between;\n}\n\n.edit-profile-container .menu-item-container .menu-item .title {\n  display: flex;\n  align-items: center;\n  font-size: 18px;\n  font-weight: 400;\n  width: 90%;\n}\n\n.edit-profile-container .menu-item-container .menu-item:hover {\n  background: #e6e6e6;\n}\n\n.edit-profile-container .menu-item-container .menu-item .menu-icon {\n  display: flex;\n  align-items: center;\n  color: #c4c4c4;\n}\n\n.edit-profile-container .border-box {\n  border-bottom: 2px solid #EFF3F5;\n  width: 100%;\n  margin-bottom: 0.5rem;\n  padding-top: 2rem;\n}\n\n.edit-profile-container .right-icon {\n  float: right;\n  font-size: 20px !important;\n}\n\n.uil-finger-print {\n  background: url('finger.svg');\n  background-repeat: no-repeat;\n  background-size: cover;\n  /* stretch the background to cover the whole element */\n  color: var(--nc-color-nextgen-grey);\n  /* \n     still inline, but has block features\n     meaning height and width can be set\n  */\n  display: inline-block;\n  height: 23px;\n  width: 23px;\n}\n\nion-toggle {\n  --background: #C8D3DA;\n  --background-checked: #00908D;\n  --handle-background: #fff;\n  --handle-background-checked: #fff;\n  height: 24px;\n  width: 48px;\n}\n\n.verified {\n  width: 60px;\n  margin-left: 5px;\n  margin-right: 5px;\n  color: var(--nc-color-nextgen-grey);\n  white-space: nowrap;\n  overflow: hidden;\n  text-overflow: ellipsis;\n}\n\n.update-phone-box {\n  display: inherit;\n}\n\n.verify-now {\n  width: 80px;\n  white-space: nowrap;\n  overflow: hidden;\n  text-overflow: ellipsis;\n  color: var(--nc-color-nextgen-error-red-700);\n}\n\n.file {\n  display: none;\n}\n\n.check-icon {\n  padding-left: 5px;\n  padding-right: 5px;\n  display: flex;\n  align-items: center;\n}\n\n.input-name {\n  width: 90%;\n  white-space: nowrap;\n  overflow: hidden;\n  text-overflow: ellipsis;\n  color: var(--nc-color-nextgen-blue);\n  border: none;\n}\n\n.update-icon {\n  color: #00908D;\n}\n\n@media only screen and (min-width: 250px) and (max-width: 320px) {\n  .edit-profile-container .details-box .details-subtitle .details-text {\n    color: var(--nc-color-nextgen-neutral-grey-400);\n  }\n  .edit-profile-container .details-box .details-subtitle .email-profile .email-account .details-content {\n    width: 100px;\n    white-space: nowrap;\n    overflow: hidden;\n    text-overflow: ellipsis;\n    color: var(--nc-color-nextgen-blue);\n  }\n}\n\n@media only screen and (max-width: 360px) {\n  .verified {\n    display: none;\n  }\n}\n\n:host ::ng-deep .edit-profile-container ion-title {\n  background-color: #ffff !important;\n}\n\n.icon-ion {\n  width: 24px !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXGNvbG9yLnNjc3MiLCJlZGl0LXByb2ZpbGUucGFnZS5zY3NzIiwiLi5cXC4uXFwuLlxcc3R5bGUuc2NzcyIsIi4uXFwuLlxcLi5cXGZvbnQtc2l6ZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0MsdUNBQUE7RUFDQSxnQ0FBQTtFQUNBLGdDQUFBO0VBQ0EsaUNBQUE7RUFDQSxpQ0FBQTtFQUNBLDJDQUFBO0VBQ0EsZ0NBQUE7RUFDQSxzQ0FBQTtFQUNBLGlDQUFBO0VBQ0Esd0NBQUE7RUFDQSx5Q0FBQTtFQUNBLG1DQUFBO0VBQ0EsNENBQUE7RUFDQSw0Q0FBQTtFQUNBLDRDQUFBO0VBQ0Esd0NBQUE7RUFDQSxtREFBQTtFQUNBLDBDQUFBO0VBQ0EscURBQUE7RUFDQSxvQ0FBQTtFQUNBLHlDQUFBO0VBQ0Esb0NBQUE7RUFDQSxvQ0FBQTtFQUNBLG1DQUFBO0VBQ0EsOENBQUE7RUFFQSwyQkFBQTtFQUNBLG9DQUFBO0FDQUQ7O0FEZ0NBO0VBQ0MsK0NBQUE7RUFDQSxtREFBQTtFQUNBLG1EQUFBO0VBQ0EsdURBQUE7RUFDQSxnREFBQTtFQUNBLCtDQUFBO0FDN0JEOztBQ3JDQTs7O0VBQUE7O0FGQUE7RUFDQyx1Q0FBQTtFQUNBLGdDQUFBO0VBQ0EsZ0NBQUE7RUFDQSxpQ0FBQTtFQUNBLGlDQUFBO0VBQ0EsMkNBQUE7RUFDQSxnQ0FBQTtFQUNBLHNDQUFBO0VBQ0EsaUNBQUE7RUFDQSx3Q0FBQTtFQUNBLHlDQUFBO0VBQ0EsbUNBQUE7RUFDQSw0Q0FBQTtFQUNBLDRDQUFBO0VBQ0EsNENBQUE7RUFDQSx3Q0FBQTtFQUNBLG1EQUFBO0VBQ0EsMENBQUE7RUFDQSxxREFBQTtFQUNBLG9DQUFBO0VBQ0EseUNBQUE7RUFDQSxvQ0FBQTtFQUNBLG9DQUFBO0VBQ0EsbUNBQUE7RUFDQSw4Q0FBQTtFQUVBLDJCQUFBO0VBQ0Esb0NBQUE7QUMyQ0Q7O0FEWEE7RUFDQywrQ0FBQTtFQUNBLG1EQUFBO0VBQ0EsbURBQUE7RUFDQSx1REFBQTtFQUNBLGdEQUFBO0VBQ0EsK0NBQUE7QUNjRDs7QUVoRkE7RUFDSSwwQkFBQTtFQUNBLDJCQUFBO0VBQ0EsNEJBQUE7QUZtRko7O0FFaEZBO0VBQ0ksMEJBQUE7RUFDQSwyQkFBQTtFQUNBLDRCQUFBO0FGbUZKOztBRWhGQTtFQUNJLDBCQUFBO0VBQ0EsMkJBQUE7RUFDQSw0QkFBQTtBRm1GSjs7QUVoRkE7RUFDSSwwQkFBQTtFQUNBLDJCQUFBO0VBQ0EsNEJBQUE7QUZtRko7O0FFaEZBO0VBQ0ksMEJBQUE7RUFDQSwyQkFBQTtFQUNBLDRCQUFBO0FGbUZKOztBRWhGQTtFQUNJLDBCQUFBO0VBQ0EsMkJBQUE7RUFDQSw0QkFBQTtBRm1GSjs7QUVoRkE7RUFDSSwwQkFBQTtFQUNBLDJCQUFBO0VBQ0EsNEJBQUE7QUZtRko7O0FFaEZBO0VBQ0ksMEJBQUE7RUFDQSwyQkFBQTtFQUNBLDRCQUFBO0FGbUZKOztBRWhGQTtFQUNJLDBCQUFBO0VBQ0EsMkJBQUE7RUFDQSw0QkFBQTtBRm1GSjs7QUVoRkE7RUFDSSwwQkFBQTtFQUNBLDJCQUFBO0VBQ0EsNEJBQUE7QUZtRko7O0FFaEZBO0VBQ0ksMEJBQUE7RUFDQSwyQkFBQTtFQUNBLDRCQUFBO0FGbUZKOztBRWhGQTtFQUNJLDBCQUFBO0VBQ0EsMkJBQUE7RUFDQSw0QkFBQTtBRm1GSjs7QUUvRUk7RUFDSSwyQkFBQTtBRmtGUjs7QUVoRkk7RUFDSSwyQkFBQTtBRmtGUjs7QUVoRkk7RUFDSSwyQkFBQTtBRmtGUjs7QUVoRkk7RUFDSSwyQkFBQTtBRmtGUjs7QUVoRkk7RUFDSSwyQkFBQTtBRmtGUjs7QUVoRkk7RUFDSSwyQkFBQTtBRmtGUjs7QUVoRkk7RUFDSSwyQkFBQTtBRmtGUjs7QUVoRkk7RUFDSSwyQkFBQTtBRmtGUjs7QUVoRkk7RUFDSSwyQkFBQTtBRmtGUjs7QUVoRkk7RUFDSSwyQkFBQTtBRmtGUjs7QUVoRkk7RUFDSSwyQkFBQTtBRmtGUjs7QUVoRkk7RUFDSSwyQkFBQTtBRmtGUjs7QUU3RUk7RUFDSSwyQkFBQTtBRmdGUjs7QUU5RUk7RUFDSSwyQkFBQTtBRmdGUjs7QUU5RUk7RUFDSSwyQkFBQTtBRmdGUjs7QUU5RUk7RUFDSSwyQkFBQTtBRmdGUjs7QUU5RUk7RUFDSSwyQkFBQTtBRmdGUjs7QUU5RUk7RUFDSSwyQkFBQTtBRmdGUjs7QUU5RUk7RUFDSSwyQkFBQTtBRmdGUjs7QUU5RUk7RUFDSSwyQkFBQTtBRmdGUjs7QUU5RUk7RUFDSSwyQkFBQTtBRmdGUjs7QUU5RUk7RUFDSSwyQkFBQTtBRmdGUjs7QUU5RUk7RUFDSSwyQkFBQTtBRmdGUjs7QUU5RUk7RUFDSSwyQkFBQTtBRmdGUjs7QUN2TkE7RUFDQywwQkFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrQkFBQTtFQUNBLHFHQUFBO0FEME5EOztBQ3BOQTtFQUNDLDBCQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtFQUNBLGtCQUFBO0VBQ0EsaUhBQUE7QURzTkQ7O0FDaE5BO0VBQ0MsMEJBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0Esa0JBQUE7RUFDQSx5R0FBQTtBRGtORDs7QUM1TUE7RUFDQywwQkFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrQkFBQTtFQUNBLHVHQUFBO0FEOE1EOztBQ3hNQTtFQUNDLDBCQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtFQUNBLGtCQUFBO0VBQ0EsMkdBQUE7QUQwTUQ7O0FDcE1BO0VBQ0MsMEJBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0Esa0JBQUE7RUFDQSwrR0FBQTtBRHNNRDs7QUNoTUE7RUFDQywwQkFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrQkFBQTtFQUNBLG1HQUFBO0FEa01EOztBQzVMQTtFQUNDLDBCQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtFQUNBLGtCQUFBO0VBQ0EsK0dBQUE7QUQ4TEQ7O0FDeExBO0VBQ0MsMkNGOUQ0QjtFRStENUIsc0NBQUE7RUFDQSxnQkFBQTtFQUNBLGVBQUE7QUQwTEQ7O0FDdkxBO0VBQ0Msd0JBQUE7QUQwTEQ7O0FDdkxBO0VBQ0MsWUFBQTtBRDBMRDs7QUN2TEE7RUFDQyxhQUFBO0FEMExEOztBQ3ZMQTtFQUNDLFVBQUE7QUQwTEQ7O0FDdkxBO0VBQ0MsYUFBQTtBRDBMRDs7QUN2TEE7RUFDQyxhQUFBO0FEMExEOztBQ3ZMQTtFQUNDLFVBQUE7QUQwTEQ7O0FDdkxBO0VBQ0MsYUFBQTtBRDBMRDs7QUN2TEE7RUFDQyxhQUFBO0FEMExEOztBQ3ZMQTtFQUNDLFVBQUE7QUQwTEQ7O0FDdkxBO0VBQ0MsYUFBQTtBRDBMRDs7QUN2TEE7RUFDQyxhQUFBO0FEMExEOztBQ3ZMQTtFQUNDLFdBQUE7QUQwTEQ7O0FDdkxBO0VBQ0MsaUJBQUE7RUFDQTtJQUNDLFlBQUE7RUQwTEE7O0VDdkxEO0lBQ0MsYUFBQTtFRDBMQTs7RUN2TEQ7SUFDQyxVQUFBO0VEMExBOztFQ3ZMRDtJQUNDLGFBQUE7RUQwTEE7O0VDdkxEO0lBQ0MsYUFBQTtFRDBMQTs7RUN2TEQ7SUFDQyxVQUFBO0VEMExBOztFQ3ZMRDtJQUNDLGFBQUE7RUQwTEE7O0VDdkxEO0lBQ0MsYUFBQTtFRDBMQTs7RUN2TEQ7SUFDQyxVQUFBO0VEMExBOztFQ3ZMRDtJQUNDLGFBQUE7RUQwTEE7O0VDdkxEO0lBQ0MsYUFBQTtFRDBMQTs7RUN2TEQ7SUFDQyxXQUFBO0VEMExBO0FBQ0Y7O0FDdkxBO0VBQ0MsaUJBQUE7RUFDQTtJQUNDLFlBQUE7RUR5TEE7O0VDdExEO0lBQ0MsYUFBQTtFRHlMQTs7RUN0TEQ7SUFDQyxVQUFBO0VEeUxBOztFQ3RMRDtJQUNDLGFBQUE7RUR5TEE7O0VDdExEO0lBQ0MsYUFBQTtFRHlMQTs7RUN0TEQ7SUFDQyxVQUFBO0VEeUxBOztFQ3RMRDtJQUNDLGFBQUE7RUR5TEE7O0VDdExEO0lBQ0MsYUFBQTtFRHlMQTs7RUN0TEQ7SUFDQyxVQUFBO0VEeUxBOztFQ3RMRDtJQUNDLGFBQUE7RUR5TEE7O0VDdExEO0lBQ0MsYUFBQTtFRHlMQTs7RUN0TEQ7SUFDQyxXQUFBO0VEeUxBO0FBQ0Y7O0FDdExBO0VBQ0MsaUJBQUE7RUFDQTtJQUNDLFlBQUE7RUR3TEE7O0VDckxEO0lBQ0MsYUFBQTtFRHdMQTs7RUNyTEQ7SUFDQyxVQUFBO0VEd0xBOztFQ3JMRDtJQUNDLGFBQUE7RUR3TEE7O0VDckxEO0lBQ0MsYUFBQTtFRHdMQTs7RUNyTEQ7SUFDQyxVQUFBO0VEd0xBOztFQ3JMRDtJQUNDLGFBQUE7RUR3TEE7O0VDckxEO0lBQ0MsYUFBQTtFRHdMQTs7RUNyTEQ7SUFDQyxVQUFBO0VEd0xBOztFQ3JMRDtJQUNDLGFBQUE7RUR3TEE7O0VDckxEO0lBQ0MsYUFBQTtFRHdMQTs7RUNyTEQ7SUFDQyxXQUFBO0VEd0xBO0FBQ0Y7O0FDckxBO0VBQ0MsYUFBQTtFQUNBLHVCQUFBO0VBQ0EsbUJBQUE7QUR1TEQ7O0FDbkxBO0VBQ0Msd0JBQUE7QURzTEQ7O0FDbkxBOzs7RUFBQTs7QUFJQTs7RUFFQyxhQUFBO0FEc0xEOztBQ25MQTtFQUNDLGdCQUFBO0FEc0xEOztBQ25MQTs7O0VBQUE7O0FBSUE7RUFDQyx5QkFBQTtFQUNBLHdCQUFBO0FEc0xEOztBQ25MQTtFQUNDLGlCQUFBO0VBQ0EseUJBQUE7QURzTEQ7O0FDbkxBO0VBQ0MsbUNGM1RvQjtBQ2lmckI7O0FDbkxBO0VBQ0MsWUFBQTtFQUNBLG1CQUFBO0VBQ0EsMEJBQUE7RUFDQSxnQkFBQTtBRHNMRDs7QUNwTEM7RUFDQywrREFBQTtFQUNBLG9DRnhVb0I7RUV5VXBCLHlCQUFBO0VBQ0EsdUJBQUE7RUFDQSxzQkFBQTtFQUNBLDZCQUFBO0FEc0xGOztBQ3BMRTtFQUNDLG9DRi9VbUI7QUNxZ0J0Qjs7QUNsTEM7RUFDQyx5Q0Z0Vm9CO0VFdVZwQixvQ0Z0Vm9CO0FDMGdCdEI7O0FDbExFO0VBQ0Msb0NGelZtQjtBQzZnQnRCOztBQ2pMRTtFQUNDLG9FQUFBO0VBQ0EsOENBQUE7QURtTEg7O0FDL0tDO0VBQ0Msb0RBQUE7RUFDQSwyQ0ZyV29CO0VFc1dwQixpQkFBQTtFQUNBLG9DRnZXb0I7QUN3aEJ0Qjs7QUMvS0U7RUFDQyxvQ0YxV21CO0FDMmhCdEI7O0FDOUtFO0VBQ0MsMERBQUE7RUFDQSw4Q0FBQTtFQUNBLGdFQUFBO0FEZ0xIOztBQzVLQztFQUNDLGtDQUFBO0VBQ0EsMkNGdFhvQjtFRXVYcEIsaUJBQUE7RUFDQSxvQ0Z4WG9CO0FDc2lCdEI7O0FDNUtFO0VBQ0Msb0NGM1htQjtBQ3lpQnRCOztBQzNLRTtFQUNDLHdDQUFBO0VBQ0EsOENBQUE7RUFDQSxnRUFBQTtBRDZLSDs7QUN6S0M7RUFDQyx1QkFBQTtFQUNBLFdBQUE7QUQyS0Y7O0FDeEtDO0VBQ0MsMkJBQUE7QUQwS0Y7O0FDdktDO0VBQ0MsMkJBQUE7QUR5S0Y7O0FDcktBO0VBQ0MsdUJBQUE7RUFDQSx3QkFBQTtFQUFBLG1CQUFBO0FEd0tEOztBQ3JLQTtFQUNDLFdBQUE7RUFDQSxZQUFBO0VBQ0EsNkJBQUE7RUFDQSxVQUFBO0VBQ0Esb0NGN1pxQjtBQ3FrQnRCOztBQ3JLQTtFQUNDLGFBQUE7RUFDQSxZQUFBO0FEd0tEOztBQ3JLQTtFQUNDLFdBQUE7RUFDQSxXQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrQkFBQTtBRHdLRDs7QUNyS0E7RUFDQyxXQUFBO0VBQ0EsV0FBQTtFQUNBLDhCQUFBO0VBQ0EsYUFBQTtFQUNBLG1CQUFBO0FEd0tEOztBQ3JLQTtFQUNDLGtCQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0FEd0tEOztBQ3JLQTtFQUNDLGtCQUFBO0VBQ0EsWUFBQTtFQUNBLHlEQUFBO0VBQ0EsV0FBQTtFQUNBLGtCQUFBO0VBQ0EsU0FBQTtFQUNBLCtDRmhjcUI7QUN3bUJ0Qjs7QUN0S0M7RUFDQyxtQkFBQTtFQUNBLHNCQUFBO0FEd0tGOztBQ3JLQztFQUNDLFlBQUE7RUFDQSxhQUFBO0VBQ0Esa0JBQUE7RUFDQSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxvQkFBQTtFQUNBLCtDRjljb0I7QUNxbkJ0Qjs7QUNwS0M7RUFDQyxhQUFBO0FEc0tGOztBQ25LQztFQUNDLGFBQUE7RUFDQSxhQUFBO0VBQ0Esa0JBQUE7RUFDQSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxvQkFBQTtFQUNBLFlBQUE7RUFDQSwrQ0Y3ZG9CO0FDa29CdEI7O0FDbEtDO0VBQ0MsYUFBQTtBRG9LRjs7QUNqS0M7RUFDQywyQ0Z0ZW9CO0FDeW9CdEI7O0FDaktFO0VBQ0MsYUFBQTtBRG1LSDs7QUNoS0U7RUFDQyxtQkFBQTtBRGtLSDs7QUM5SkM7RUFDQyxXQUFBO0VBQ0Esa0JBQUE7RUFDQSxpQkFBQTtBRGdLRjs7QUM5SkU7RUFDQywwQkFBQTtBRGdLSDs7QUM1SkM7RUFDQyxXQUFBO0VBQ0Esa0JBQUE7QUQ4SkY7O0FDM0pFO0VBQ0MsMEJBQUE7QUQ2Skg7O0FDeEpBO0VBQ0Msb0NGdmdCcUI7QUNrcUJ0Qjs7QUN2SkM7RUFDQywyQ0Z0Z0JvQjtBQ2dxQnRCOztBQ3ZKQztFQUNDLCtDQUFBO0FEeUpGOztBQ3BKQztFQUNDLCtDQUFBO0VBQ0EsZ0JBQUE7QUR1SkY7O0FDckpFO0VBQ0MsK0NBQUE7QUR1Skg7O0FDbEpBO0VBQ0Msb0JBQUE7QURxSkQ7O0FDbEpBO0VBQ0MscUJBQUE7QURxSkQ7O0FDbEpBO0VBQ0Msa0JBQUE7RUFDQSxvQkFBQTtFQUNBLHNCQUFBO0VBQ0EsYUFBQTtFQUNBLGNBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7QURxSkQ7O0FDbEpBO0VBQ0Msc0RGM2lCNEI7RUU0aUI1Qix1QkFBQTtBRHFKRDs7QUNsSkE7RUFDQyw2QkFBQTtFQUNBLCtDRnZqQnFCO0FDNHNCdEI7O0FDbEpBO0VBQ0M7SUFDQywyQkFBQTtFRHFKQTtFQ2xKRDtJQUNDLHlCQUFBO0VEb0pBO0FBQ0Y7O0FDakpBO0VBQ0Msb0NGaGtCcUI7QUNtdEJ0Qjs7QUNqSkM7RUFDQywrQ0Zua0JvQjtBQ3N0QnRCOztBQy9JQTtFQUNDLDRDRnRrQjZCO0FDd3RCOUI7O0FDaEpDO0VBQ0MsdURGemtCNEI7QUMydEI5Qjs7QUM5SUE7RUFDQyxzQ0Y3a0J1QjtBQzh0QnhCOztBQy9JQztFQUNDLGlERmhsQnNCO0FDaXVCeEI7O0FDN0lBO0VBQ0MsV0FBQTtFQUNBLFlBQUE7RUFDQSxhQUFBO0VBQ0Esa0JBQUE7RUFDQSxhQUFBO0VBQ0Esd0JBQUE7VUFBQSxnQkFBQTtFQUNBLDZCQUFBO0FEZ0pEOztBQzlJQztFQUNDLGNBQUE7QURnSkY7O0FDNUlBO0VBQ0Msb0NGMW1CcUI7QUN5dkJ0Qjs7QUM1SUE7RUFDQyxhQUFBO0VBQ0EsY0FBQTtBRCtJRDs7QUM1SUE7RUFDQyxXQUFBO0VBQ0EsWUFBQTtFQUNBLDBCQUFBO0FEK0lEOztBQzVJQTtFQUNDLGtCQUFBO0FEK0lEOztBQzVJQTtFQUNDLGVBQUE7RUFDQSxNQUFBO0VBQ0EsUUFBQTtFQUNBLFlBQUE7RUFDQSxXQUFBO0VBQ0EseURGem5CK0I7RUUwbkIvQixnQkFBQTtBRCtJRDs7QUM3SUM7RUFDQyxZQUFBO0FEK0lGOztBQzNJQTtFQUNDLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxTQUFBO0FEOElEOztBQzNJQTtFQUNDLHlCQUFBO0VBQ0EsWUFBQTtFQUNBLFdBQUE7RUFDQSxrQkFBQTtFQUNBLGtCQUFBO0VBQ0EsVUFBQTtFQUNBLFdBQUE7QUQ4SUQ7O0FDM0lBO0VBQ0Msa0JBQUE7RUFDQSxZQUFBO0VBQ0EsVUFBQTtFQUNBLFlBQUE7QUQ4SUQ7O0FDM0lBO0VBQ0Msa0JBQUE7RUFDQSxRQUFBO0VBQ0EsU0FBQTtFQUNBLGdDQUFBO0VBQ0Esa0JBQUE7RUFDQSwrQ0Y3cEJnQztFRThwQmhDLGFBQUE7QUQ4SUQ7O0FDM0lBO0VBQ0MsNkJBQUE7QUQ4SUQ7O0FDMUlDO0VBQ0MsaUJBQUE7QUQ2SUY7O0FDeklBO0VBQ0MsYUFBQTtBRDRJRDs7QUN6SUE7RUFDQyxPQUFBO0VBQ0EsUUFBQTtFQUNBLE1BQUE7RUFDQSxTQUFBO0VBQ0EsYUFBQTtFQUNBLGtCQUFBO0VBQ0Esc0JBQUE7RUFDQSw4QkFBQTtFQUNBLDBCQUFBO0VBQ0EsZ0JBQUE7RUFDQSx5REYzckIrQjtFRTRyQi9CLG1CQUFBO0VBQ0Esa0JBQUE7QUQ0SUQ7O0FDeklBO0VBQ0MsZ0JBQUE7QUQ0SUQ7O0FDeklBO0VBQ0MsOEJBQUE7QUQ0SUQ7O0FDeklBO0VBQ0MsYUFBQTtBRDRJRDs7QUN6SUE7RUFDQywrQkFBQTtFQUNBLDhCQUFBO0FENElEOztBQ3pJQTtFQUNDLHdDQUFBO0FENElEOztBQ3hJQztFQUNDLHlCQUFBO0VBQ0EsU0FBQTtBRDJJRjs7QUN2SUE7RUFDQyxhQUFBO0VBQ0EsZ0JBQUE7RUFDQSxhQUFBO0FEMElEOztBQ3ZJQTtFQUNDLGNBQUE7QUQwSUQ7O0FDdklBO0VBQ0MsbUNGbnZCb0I7QUM2M0JyQjs7QUNuSUk7RUFDQyxtQkFBQTtFQUNBLHVCQUFBO0VBQ0EsYUFBQTtFQUNBLFdBQUE7QURzSUw7O0FDcElLO0VBQ0MsYUFBQTtBRHNJTjs7QUNsSUk7RUFDQyxrQkFBQTtFQUNBLFdBQUE7RUFDQSxRQUFBO0FEb0lMOztBQ2xJSztFQUNDLGFBQUE7RUFDQSw4QkFBQTtFQUNBLFdBQUE7QURvSU47O0FDNUhBO0VBQ0MseUJBQUE7QUQrSEQ7O0FDNUhBLHlDQUFBOztBQUNBOzs7Ozs7Ozs7RUFTQyw4QkFBQTtFQUNBLDhDQUFBO0VBQ0EseURBQUE7RUFBQSxpREFBQTtBRCtIRDs7QUMzSEM7RUFDQyx1REFBQTtFQUNBLHlDQUFBO0VBQ0EsNEJBQUE7QUQ4SEY7O0FDM0hDO0VBQ0Msa0RBQUE7QUQ2SEY7O0FDNUdBO0VBQ0M7SUFFQyxrQ0FBQTtJQUNBLG1CQUFBO0VEMEhBO0VDdkhEO0lBRUMsd0JBQUE7RUR5SEE7QUFDRjs7QUN0SEE7RUFFQyw0QkFBQTtBRHdIRDs7QUNySEE7RUFFQyx3QkFBQTtFQUVBLHdCQUFBO0VBRUEseUJBQUE7QUR3SEQ7O0FBNStCQTtFQUNFLGtDQUFBO0FBKytCRjs7QUE1K0JBO0VBQ0Usa0JBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtFQUNBLFVBQUE7RUFDQSxTQUFBO0VBQ0EsNkJBQUE7RUFDQSxVQUFBO0FBKytCRjs7QUE1K0JBO0VBQ0UsdUJBQUE7QUErK0JGOztBQTcrQkU7RUFDRSxtQkFBQTtFQUNBLGtCQUFBO0VBQ0EsYUFBQTtFQUNBLG1CQUFBO0VBQ0EsdUJBQUE7QUErK0JKOztBQTcrQkk7RUFDRSxrQkFBQTtFQUNBLGFBQUE7RUFDQSxZQUFBO0FBKytCTjs7QUE1K0JJO0VBQ0UsV0FBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtFQUNBLGlCQUFBO0FBOCtCTjs7QUEzK0JJO0VBQ0UsUUFBQTtFQUNBLFNBQUE7RUFDQSxtQkFBQTtFQUNBLHVCQUFBO0VBQ0Esb0RERDJCO0VDRTNCLGtCQUFBO0VBQ0Esa0JBQUE7RUFDQSxrQkFBQTtFQUNBLGtCQUFBO0FBNitCTjs7QUF6K0JFO0VBQ0UsV0FBQTtFQUNBLDhCQUFBO0VBQ0EsYUFBQTtFQUNBLG1CQUFBO0FBMitCSjs7QUF6K0JJO0VBQ0UsV0FBQTtFQUNBLGtCQUFBO0FBMitCTjs7QUF0K0JJO0VBQ0UsaUJBQUE7RUFDQSxvQkFBQTtFQUNBLG1DRGxDZTtFQ21DZixVQUFBO0VBQ0EsUUFBQTtFQUNBLFlBQUE7QUF3K0JOOztBQXIrQkk7RUFDRSxtQkFBQTtFQUNBLHNCQUFBO0VBQ0Esb0JBQUE7QUF1K0JOOztBQXIrQk07RUFDRSwrQ0R0Q3lCO0FDNmdDakM7O0FBcCtCTTtFQUNFLGFBQUE7RUFDQSw4QkFBQTtBQXMrQlI7O0FBcCtCUTtFQUNFLG1CQUFBO0VBQ0EsYUFBQTtBQXMrQlY7O0FBcCtCVTtFQUNFLFlBQUE7RUFDQSxtQkFBQTtFQUNBLGdCQUFBO0VBQ0EsdUJBQUE7RUFDQSxtQ0RuRVM7QUN5aUNyQjs7QUFsK0JRO0VBQ0Usb0JBQUE7QUFvK0JWOztBQTc5Qkk7RUFDRSxhQUFBO0VBQ0EsWUFBQTtFQUNBLG1CQUFBO0VBQ0EsOEJBQUE7QUErOUJOOztBQTc5Qk07RUFDRSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSxVQUFBO0FBKzlCUjs7QUF4OUJNO0VBQ0UsbUJBQUE7QUEwOUJSOztBQXY5Qk07RUFDRSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSxjQUFBO0FBeTlCUjs7QUFwOUJFO0VBQ0UsZ0NBQUE7RUFDQSxXQUFBO0VBQ0EscUJBQUE7RUFDQSxpQkFBQTtBQXM5Qko7O0FBbjlCRTtFQUNFLFlBQUE7RUFDQSwwQkFBQTtBQXE5Qko7O0FBajlCQTtFQUNFLDZCQUFBO0VBQ0EsNEJBQUE7RUFDQSxzQkFBQTtFQUNBLHNEQUFBO0VBQ0EsbUNEMUhtQjtFQzRIbkI7OztHQUFBO0VBSUEscUJBQUE7RUFDQSxZQUFBO0VBQ0EsV0FBQTtBQW05QkY7O0FBaDlCQTtFQUNFLHFCQUFBO0VBQ0EsNkJBQUE7RUFFQSx5QkFBQTtFQUNBLGlDQUFBO0VBQ0EsWUFBQTtFQUNBLFdBQUE7QUFrOUJGOztBQTc4QkE7RUFDRSxXQUFBO0VBQ0EsZ0JBQUE7RUFDQSxpQkFBQTtFQUNBLG1DRHJKbUI7RUNzSm5CLG1CQUFBO0VBQ0EsZ0JBQUE7RUFDQSx1QkFBQTtBQWc5QkY7O0FBOThCQTtFQUNFLGdCQUFBO0FBaTlCRjs7QUE5OEJBO0VBQ0UsV0FBQTtFQUNBLG1CQUFBO0VBQ0EsZ0JBQUE7RUFDQSx1QkFBQTtFQUNBLDRDRGhKNEI7QUNpbUM5Qjs7QUE5OEJBO0VBQ0UsYUFBQTtBQWk5QkY7O0FBOThCQTtFQUNFLGlCQUFBO0VBQ0Esa0JBQUE7RUFDQSxhQUFBO0VBQ0EsbUJBQUE7QUFpOUJGOztBQS84QkE7RUFDRSxVQUFBO0VBQ0EsbUJBQUE7RUFDQSxnQkFBQTtFQUNBLHVCQUFBO0VBQ0EsbUNEMUxtQjtFQzJMbkIsWUFBQTtBQWs5QkY7O0FBaDlCQTtFQUNFLGNBQUE7QUFtOUJGOztBQWo5QkE7RUFJUTtJQUNFLCtDRHhMdUI7RUN5b0MvQjtFQTU4QlU7SUFDRSxZQUFBO0lBQ0EsbUJBQUE7SUFDQSxnQkFBQTtJQUNBLHVCQUFBO0lBQ0EsbUNEL01PO0VDNnBDbkI7QUFDRjs7QUF0OEJBO0VBQ0U7SUFDRSxhQUFBO0VBdzhCRjtBQUNGOztBQXI4QkE7RUFDRSxrQ0FBQTtBQXU4QkY7O0FBcjhCQTtFQUNFLHNCQUFBO0FBdzhCRiIsImZpbGUiOiJlZGl0LXByb2ZpbGUucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiOnJvb3Qge1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNTA6IHJlZDtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4td2hpdGU6IHllbGxvdztcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZTogIzBkMTUyZTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW46ICMwMDkwOGQ7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWJsYWNrOiAjMDAwMDAwO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ncmV5LWJhY2tncm91bmQ6ICNjOGQzZGE7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWdyZXk6ICM5MmEyYWM7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0b25lLWdyZXk6ICNmYWZhZmE7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWVycm9yOiAjZmMxMDU1O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXk6ICM0MTQxNDE7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWZpYnJhbnQtZ3JlZW46ICMwMGJhYjY7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXdhcm5pbmc6ICNmZmQwNDg7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuLWJhY2tncm91bmQ6ICNlNmYyZjI7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS00MDA6ICM3YTdhN2E7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS0xMDA6ICNlZmYzZjU7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy1lcnJvcjogI2JhMGMzZjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yLWJhY2tncm91bmQ6ICNmZmVmZjQ7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy13YXJuaW5nOiAjY2JhMTI3O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtd2FybmluZy1iYWNrZ3JvdW5kOiAjZmZmOGU2O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlLTEwMDogI2RmZWZmMjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tZXJyb3ItcmVkLTcwMDogI2Y2MjQ1OTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZS01MDA6ICMwMDYxOTI7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWJsdWUtNDAwOiAjNzljZGVjO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1yZWQtNTAwOiAjZmY2NTkyO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zZWNvbmRhcnktYmx1ZS0zMDA6ICMxM2EwZDM7XHJcblxyXG5cdC0tbHVtaS13aGl0ZS1jb2xvcjogI2ZmZmZmZjtcclxuXHQtLWx1bWktcHJpbWFyeS15ZWxsb3ctY29sb3I6ICNmYWI2MDA7XHJcbn1cclxuJGNvbG9yLW5leHRnZW4tYmx1ZTogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlKTtcclxuJGNvbG9yLW5leHRnZW4tZ3JlZW46IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4pO1xyXG4kY29sb3ItbmV4dGdlbi13aGl0ZTogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi13aGl0ZSk7XHJcbiRjb2xvci1uZXh0Z2VuLWJsYWNrOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWJsYWNrKTtcclxuJGNvbG9yLW5leHRnZW4tZ3JleS1iYWNrZ3JvdW5kOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZXktYmFja2dyb3VuZCk7XHJcbiRjb2xvci1uZXh0Z2VuLWdyZXk6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JleSk7XHJcbiRjb2xvci1uZXh0Z2VuLXN0b25lLWdyZXk6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tc3RvbmUtZ3JleSk7XHJcbiRjb2xvci1uZXh0Z2VuLWVycm9yOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWVycm9yKTtcclxuJGNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5OiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleSk7XHJcbiRjb2xvci1uZXh0Z2VuLWZpYnJhbnQtZ3JlZW46IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZmlicmFudC1ncmVlbik7XHJcbiRjb2xvci1uZXh0Z2VuLXdhcm5pbmc6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4td2FybmluZyk7XHJcbiRjb2xvci1uZXh0Z2VuLWdyZWVuLWJhY2tncm91bmQ6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4tYmFja2dyb3VuZCk7XHJcbiRjb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS01MDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNTApO1xyXG4kY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNDAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS00MDApO1xyXG4kY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktMTAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS0xMDApO1xyXG4kY29sb3ItbmV4dGdlbi1zdGF0dXMtZXJyb3I6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yKTtcclxuJGNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yLWJhY2tncm91bmQ6IHZhcihcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yLWJhY2tncm91bmRcclxuKTtcclxuJGNvbG9yLW5leHRnZW4tc3RhdHVzLXdhcm5pbmc6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLXdhcm5pbmcpO1xyXG4kY29sb3ItbmV4dGdlbi1zdGF0dXMtd2FybmluZy1iYWNrZ3JvdW5kOiB2YXIoXHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy13YXJuaW5nLWJhY2tncm91bmRcclxuKTtcclxuJGNvbG9yLW5leHRnZW4tYmx1ZS0xMDA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZS0xMDApO1xyXG4kY29sb3ItbmV4dGdlbi1lcnJvci1yZWQtNzAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWVycm9yLXJlZC03MDApO1xyXG4kY29sb3ItbmV4dGdlbi1ibHVlLTUwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlLTUwMCk7XHJcbiRjb2xvci1uZXh0Z2VuLWJsdWUtNDAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWJsdWUtNDAwKTtcclxuJGNvbG9yLW5leHRnZW4tcmVkLTUwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1yZWQtNTAwKTtcclxuJGNvbG9yLW5leHRnZW4tc2Vjb25kYXJ5LWJsdWUtMzAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXNlY29uZGFyeS1ibHVlLTMwMCk7XHJcblxyXG4uaW9uLWNvbG9yLWdyZWVuIHtcclxuXHQtLWlvbi1jb2xvci1iYXNlOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuKTtcclxuXHQtLWlvbi1jb2xvci1iYXNlLXJnYjogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbik7XHJcblx0LS1pb24tY29sb3ItY29udHJhc3Q6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4td2hpdGUpO1xyXG5cdC0taW9uLWNvbG9yLWNvbnRyYXN0LXJnYjogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbik7XHJcblx0LS1pb24tY29sb3Itc2hhZGU6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4pO1xyXG5cdC0taW9uLWNvbG9yLXRpbnQ6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4pO1xyXG59XHJcbiIsIkBpbXBvcnQgXCIuLi8uLi8uLi9jb2xvci5zY3NzXCI7XHJcbkBpbXBvcnQgXCIuLi8uLi8uLi9zdHlsZS5zY3NzXCI7XHJcblxyXG4uYm9keSB7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZmYgIWltcG9ydGFudDtcclxufVxyXG5cclxuLmJhY2stYnV0dG9uIHtcclxuICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgd2lkdGg6IDMxcHg7XHJcbiAgaGVpZ2h0OiAyOHB4O1xyXG4gIGxlZnQ6IDIzcHg7XHJcbiAgdG9wOiA0MHB4O1xyXG4gIGJhY2tncm91bmQtY29sb3I6IHRyYW5zcGFyZW50O1xyXG4gIHBhZGRpbmc6IDA7XHJcbn1cclxuXHJcbi5lZGl0LXByb2ZpbGUtY29udGFpbmVyIHtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmZjtcclxuXHJcbiAgLnByb2ZpbGUtaW1hZ2UtYm94IHtcclxuICAgIG1hcmdpbi1ib3R0b206IDE1cHg7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG5cclxuICAgIC5hdmF0YXItY29udGFpbmVyIHtcclxuICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgICBoZWlnaHQ6IDEwMHB4O1xyXG4gICAgICB3aWR0aDogMTAwcHg7XHJcbiAgICB9XHJcblxyXG4gICAgLnByb2ZpbGUtaW1hZ2Uge1xyXG4gICAgICB3aWR0aDogOTZweDtcclxuICAgICAgaGVpZ2h0OiA5NnB4O1xyXG4gICAgICBib3JkZXItcmFkaXVzOiA1MCU7XHJcbiAgICAgIG9iamVjdC1maXQ6IGNvdmVyO1xyXG4gICAgfVxyXG5cclxuICAgIC5jYW1lcmEtaWNvbiB7XHJcbiAgICAgIHJpZ2h0OiAwO1xyXG4gICAgICBib3R0b206IDA7XHJcbiAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgICBiYWNrZ3JvdW5kOiAkY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktMTAwO1xyXG4gICAgICBwYWRkaW5nOiAxMHB4IDEycHg7XHJcbiAgICAgIGJvcmRlci1yYWRpdXM6IDUwJTtcclxuICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICAuZWRpdC1wcm9maWxlLXBhZ2UtaGVhZGVyIHtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcblxyXG4gICAgc3BhbiB7XHJcbiAgICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICAuZGV0YWlscy1ib3gge1xyXG4gICAgLmRldGFpbHMtdGV4dCB7XHJcbiAgICAgIHBhZGRpbmctdG9wOiAxcmVtO1xyXG4gICAgICBwYWRkaW5nLWJvdHRvbTogMXJlbTtcclxuICAgICAgY29sb3I6ICRjb2xvci1uZXh0Z2VuLWdyZXk7XHJcbiAgICAgIGZsZXg6IG5vbmU7XHJcbiAgICAgIG9yZGVyOiAzO1xyXG4gICAgICBmbGV4LWdyb3c6IDA7XHJcbiAgICB9XHJcblxyXG4gICAgLmRldGFpbHMtc3VidGl0bGUge1xyXG4gICAgICBwYWRkaW5nLXRvcDogMC41cmVtO1xyXG4gICAgICBwYWRkaW5nLWJvdHRvbTogMC41cmVtO1xyXG4gICAgICBwYWRkaW5nLWxlZnQ6IDAuNXJlbTtcclxuXHJcbiAgICAgIC5kZXRhaWxzLXRleHQge1xyXG4gICAgICAgIGNvbG9yOiAkY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNDAwO1xyXG4gICAgICB9XHJcblxyXG4gICAgICAuZW1haWwtcHJvZmlsZSB7XHJcbiAgICAgICAgZGlzcGxheTogZmxleDtcclxuICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XHJcblxyXG4gICAgICAgIC5lbWFpbC1hY2NvdW50IHtcclxuICAgICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xyXG5cclxuICAgICAgICAgIC5kZXRhaWxzLWNvbnRlbnQge1xyXG4gICAgICAgICAgICB3aWR0aDogMjE1cHg7XHJcbiAgICAgICAgICAgIHdoaXRlLXNwYWNlOiBub3dyYXA7XHJcbiAgICAgICAgICAgIG92ZXJmbG93OiBoaWRkZW47XHJcbiAgICAgICAgICAgIHRleHQtb3ZlcmZsb3c6IGVsbGlwc2lzO1xyXG4gICAgICAgICAgICBjb2xvcjogJGNvbG9yLW5leHRnZW4tYmx1ZTtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC5yaWdodC1pY29uIHtcclxuICAgICAgICAgIGp1c3RpZnktaXRlbXM6IHJpZ2h0O1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgLm1lbnUtaXRlbS1jb250YWluZXIge1xyXG4gICAgLm1lbnUtaXRlbSB7XHJcbiAgICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICAgIGhlaWdodDogNjBweDtcclxuICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xyXG5cclxuICAgICAgLnRpdGxlIHtcclxuICAgICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICAgICAgZm9udC1zaXplOiAxOHB4O1xyXG4gICAgICAgIGZvbnQtd2VpZ2h0OiA0MDA7XHJcbiAgICAgICAgd2lkdGg6IDkwJTtcclxuICAgICAgfVxyXG5cclxuICAgICAgJi5tZW51LWl0ZW06Zmlyc3QtY2hpbGQge1xyXG4gICAgICAgIC8vIGJvcmRlci10b3A6IDFweCBzb2xpZCAjZTllOWU5O1xyXG4gICAgICB9XHJcblxyXG4gICAgICAmOmhvdmVyIHtcclxuICAgICAgICBiYWNrZ3JvdW5kOiBkYXJrZW4od2hpdGUsIDEwKTtcclxuICAgICAgfVxyXG5cclxuICAgICAgLm1lbnUtaWNvbiB7XHJcbiAgICAgICAgZGlzcGxheTogZmxleDtcclxuICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgICAgIGNvbG9yOiAjYzRjNGM0O1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICAuYm9yZGVyLWJveCB7XHJcbiAgICBib3JkZXItYm90dG9tOiAycHggc29saWQgI0VGRjNGNTtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgbWFyZ2luLWJvdHRvbTogMC41cmVtO1xyXG4gICAgcGFkZGluZy10b3A6IDJyZW07XHJcbiAgfVxyXG5cclxuICAucmlnaHQtaWNvbiB7XHJcbiAgICBmbG9hdDogcmlnaHQ7XHJcbiAgICBmb250LXNpemU6IDIwcHggIWltcG9ydGFudDtcclxuICB9XHJcbn1cclxuXHJcbi51aWwtZmluZ2VyLXByaW50IHtcclxuICBiYWNrZ3JvdW5kOiB1cmwoJy4uLy4uLy4uL2Fzc2V0cy9pY29uL2Zpbmdlci5zdmcnKTtcclxuICBiYWNrZ3JvdW5kLXJlcGVhdDogbm8tcmVwZWF0O1xyXG4gIGJhY2tncm91bmQtc2l6ZTogY292ZXI7XHJcbiAgLyogc3RyZXRjaCB0aGUgYmFja2dyb3VuZCB0byBjb3ZlciB0aGUgd2hvbGUgZWxlbWVudCAqL1xyXG4gIGNvbG9yOiAkY29sb3ItbmV4dGdlbi1ncmV5O1xyXG5cclxuICAvKiBcclxuICAgICBzdGlsbCBpbmxpbmUsIGJ1dCBoYXMgYmxvY2sgZmVhdHVyZXNcclxuICAgICBtZWFuaW5nIGhlaWdodCBhbmQgd2lkdGggY2FuIGJlIHNldFxyXG4gICovXHJcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xyXG4gIGhlaWdodDogMjNweDtcclxuICB3aWR0aDogMjNweDtcclxufVxyXG5cclxuaW9uLXRvZ2dsZSB7XHJcbiAgLS1iYWNrZ3JvdW5kOiAjQzhEM0RBO1xyXG4gIC0tYmFja2dyb3VuZC1jaGVja2VkOiAjMDA5MDhEO1xyXG5cclxuICAtLWhhbmRsZS1iYWNrZ3JvdW5kOiAjZmZmO1xyXG4gIC0taGFuZGxlLWJhY2tncm91bmQtY2hlY2tlZDogI2ZmZjtcclxuICBoZWlnaHQ6IDI0cHg7XHJcbiAgd2lkdGg6IDQ4cHg7XHJcbn1cclxuXHJcblxyXG5cclxuLnZlcmlmaWVkIHtcclxuICB3aWR0aDogNjBweDtcclxuICBtYXJnaW4tbGVmdDogNXB4O1xyXG4gIG1hcmdpbi1yaWdodDogNXB4O1xyXG4gIGNvbG9yOiAkY29sb3ItbmV4dGdlbi1ncmV5O1xyXG4gIHdoaXRlLXNwYWNlOiBub3dyYXA7XHJcbiAgb3ZlcmZsb3c6IGhpZGRlbjtcclxuICB0ZXh0LW92ZXJmbG93OiBlbGxpcHNpcztcclxufVxyXG4udXBkYXRlLXBob25lLWJveHtcclxuICBkaXNwbGF5OiBpbmhlcml0O1xyXG59XHJcblxyXG4udmVyaWZ5LW5vdyB7XHJcbiAgd2lkdGg6IDgwcHg7XHJcbiAgd2hpdGUtc3BhY2U6IG5vd3JhcDtcclxuICBvdmVyZmxvdzogaGlkZGVuO1xyXG4gIHRleHQtb3ZlcmZsb3c6IGVsbGlwc2lzO1xyXG4gIGNvbG9yOiAkY29sb3ItbmV4dGdlbi1lcnJvci1yZWQtNzAwO1xyXG59XHJcblxyXG4uZmlsZSB7XHJcbiAgZGlzcGxheTogbm9uZTtcclxufVxyXG5cclxuLmNoZWNrLWljb24ge1xyXG4gIHBhZGRpbmctbGVmdDogNXB4O1xyXG4gIHBhZGRpbmctcmlnaHQ6IDVweDtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbn1cclxuLmlucHV0LW5hbWV7XHJcbiAgd2lkdGg6IDkwJTtcclxuICB3aGl0ZS1zcGFjZTogbm93cmFwO1xyXG4gIG92ZXJmbG93OiBoaWRkZW47XHJcbiAgdGV4dC1vdmVyZmxvdzogZWxsaXBzaXM7XHJcbiAgY29sb3I6ICRjb2xvci1uZXh0Z2VuLWJsdWU7XHJcbiAgYm9yZGVyOiBub25lO1xyXG59XHJcbi51cGRhdGUtaWNvbntcclxuICBjb2xvcjogIzAwOTA4RDtcclxufVxyXG5AbWVkaWEgb25seSBzY3JlZW4gYW5kIChtaW4td2lkdGg6IDI1MHB4KSBhbmQgKG1heC13aWR0aDogMzIwcHgpIHtcclxuICAuZWRpdC1wcm9maWxlLWNvbnRhaW5lciB7XHJcbiAgICAuZGV0YWlscy1ib3gge1xyXG4gICAgICAuZGV0YWlscy1zdWJ0aXRsZSB7XHJcbiAgICAgICAgLmRldGFpbHMtdGV4dCB7XHJcbiAgICAgICAgICBjb2xvcjogJGNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTQwMDtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC5lbWFpbC1wcm9maWxlIHtcclxuICAgICAgICAgIC5lbWFpbC1hY2NvdW50IHtcclxuICAgICAgICAgICAgLmRldGFpbHMtY29udGVudCB7XHJcbiAgICAgICAgICAgICAgd2lkdGg6IDEwMHB4O1xyXG4gICAgICAgICAgICAgIHdoaXRlLXNwYWNlOiBub3dyYXA7XHJcbiAgICAgICAgICAgICAgb3ZlcmZsb3c6IGhpZGRlbjtcclxuICAgICAgICAgICAgICB0ZXh0LW92ZXJmbG93OiBlbGxpcHNpcztcclxuICAgICAgICAgICAgICBjb2xvcjogJGNvbG9yLW5leHRnZW4tYmx1ZTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH1cclxufVxyXG5cclxuQG1lZGlhIG9ubHkgc2NyZWVuIGFuZCAobWF4LXdpZHRoOiAzNjBweCkge1xyXG4gIC52ZXJpZmllZCB7XHJcbiAgICBkaXNwbGF5OiBub25lO1xyXG4gIH1cclxufVxyXG5cclxuOmhvc3QgOjpuZy1kZWVwIC5lZGl0LXByb2ZpbGUtY29udGFpbmVyIGlvbi10aXRsZSB7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZmYgIWltcG9ydGFudDtcclxufVxyXG4uaWNvbi1pb257XHJcbiAgd2lkdGg6IDI0cHggIWltcG9ydGFudDtcclxufSIsIi8qXHJcbiAqIDEuIEN1c3RvbSBDU1MgXHJcbiAqIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuICovXHJcblxyXG4vLyBjb2xvciB2YXJpYWJsZVxyXG5AaW1wb3J0IFwiLi9jb2xvci5zY3NzXCI7XHJcbi8vIHR5cG9ncmFwaHlcclxuQGltcG9ydCBcIi4vZm9udC1zaXplLnNjc3NcIjtcclxuXHJcbi8vIEZvbnRzXHJcbkBmb250LWZhY2Uge1xyXG5cdGZvbnQtZmFtaWx5OiBcIkFsbGlhbnogTmVvXCI7XHJcblx0Zm9udC1zdHlsZTogbm9ybWFsO1xyXG5cdGZvbnQtd2VpZ2h0OiAzMDA7XHJcblx0Zm9udC1kaXNwbGF5OiBzd2FwO1xyXG5cdHNyYzogdXJsKFwiLi9hc3NldHMvZm9udHMvQWxsaWFuek5lby9BbGxpYW56X05lb193ZWJmb250cy93b2ZmMi9BbGxpYW56TmVvVzA0LUxpZ2h0LndvZmYyXCIpXHJcblx0XHRcdGZvcm1hdChcIndvZmYyXCIpLFxyXG5cdFx0dXJsKFwiLi9hc3NldHMvZm9udHMvQWxsaWFuek5lby9BbGxpYW56X05lb193ZWJmb250cy93b2ZmL0FsbGlhbnpOZW9XMDQtTGlnaHQud29mZlwiKVxyXG5cdFx0XHRmb3JtYXQoXCJ3b2ZmXCIpO1xyXG59XHJcblxyXG5AZm9udC1mYWNlIHtcclxuXHRmb250LWZhbWlseTogXCJBbGxpYW56IE5lb1wiO1xyXG5cdGZvbnQtc3R5bGU6IGl0YWxpYztcclxuXHRmb250LXdlaWdodDogMzAwO1xyXG5cdGZvbnQtZGlzcGxheTogc3dhcDtcclxuXHRzcmM6IHVybChcIi4vYXNzZXRzL2ZvbnRzL0FsbGlhbnpOZW8vQWxsaWFuel9OZW9fd2ViZm9udHMvd29mZjIvQWxsaWFuek5lb1cwNC1MaWdodEl0YWxpYy53b2ZmMlwiKVxyXG5cdFx0XHRmb3JtYXQoXCJ3b2ZmMlwiKSxcclxuXHRcdHVybChcIi4vYXNzZXRzL2ZvbnRzL0FsbGlhbnpOZW8vQWxsaWFuel9OZW9fd2ViZm9udHMvd29mZi9BbGxpYW56TmVvVzA0LUxpZ2h0SXRhbGljLndvZmZcIilcclxuXHRcdFx0Zm9ybWF0KFwid29mZlwiKTtcclxufVxyXG5cclxuQGZvbnQtZmFjZSB7XHJcblx0Zm9udC1mYW1pbHk6IFwiQWxsaWFueiBOZW9cIjtcclxuXHRmb250LXN0eWxlOiBub3JtYWw7XHJcblx0Zm9udC13ZWlnaHQ6IDQwMDtcclxuXHRmb250LWRpc3BsYXk6IHN3YXA7XHJcblx0c3JjOiB1cmwoXCIuL2Fzc2V0cy9mb250cy9BbGxpYW56TmVvL0FsbGlhbnpfTmVvX3dlYmZvbnRzL3dvZmYyL0FsbGlhbnpOZW9XMDQtUmVndWxhci53b2ZmMlwiKVxyXG5cdFx0XHRmb3JtYXQoXCJ3b2ZmMlwiKSxcclxuXHRcdHVybChcIi4vYXNzZXRzL2ZvbnRzL0FsbGlhbnpOZW8vQWxsaWFuel9OZW9fd2ViZm9udHMvd29mZi9BbGxpYW56TmVvVzA0LVJlZ3VsYXIud29mZlwiKVxyXG5cdFx0XHRmb3JtYXQoXCJ3b2ZmXCIpO1xyXG59XHJcblxyXG5AZm9udC1mYWNlIHtcclxuXHRmb250LWZhbWlseTogXCJBbGxpYW56IE5lb1wiO1xyXG5cdGZvbnQtc3R5bGU6IGl0YWxpYztcclxuXHRmb250LXdlaWdodDogNDAwO1xyXG5cdGZvbnQtZGlzcGxheTogc3dhcDtcclxuXHRzcmM6IHVybChcIi4vYXNzZXRzL2ZvbnRzL0FsbGlhbnpOZW8vQWxsaWFuel9OZW9fd2ViZm9udHMvd29mZjIvQWxsaWFuek5lb1cwNC1JdGFsaWMud29mZjJcIilcclxuXHRcdFx0Zm9ybWF0KFwid29mZjJcIiksXHJcblx0XHR1cmwoXCIuL2Fzc2V0cy9mb250cy9BbGxpYW56TmVvL0FsbGlhbnpfTmVvX3dlYmZvbnRzL3dvZmYvQWxsaWFuek5lb1cwNC1JdGFsaWMud29mZlwiKVxyXG5cdFx0XHRmb3JtYXQoXCJ3b2ZmXCIpO1xyXG59XHJcblxyXG5AZm9udC1mYWNlIHtcclxuXHRmb250LWZhbWlseTogXCJBbGxpYW56IE5lb1wiO1xyXG5cdGZvbnQtc3R5bGU6IG5vcm1hbDtcclxuXHRmb250LXdlaWdodDogNjAwO1xyXG5cdGZvbnQtZGlzcGxheTogc3dhcDtcclxuXHRzcmM6IHVybChcIi4vYXNzZXRzL2ZvbnRzL0FsbGlhbnpOZW8vQWxsaWFuel9OZW9fd2ViZm9udHMvd29mZjIvQWxsaWFuek5lb1cwNC1TZW1pQm9sZC53b2ZmMlwiKVxyXG5cdFx0XHRmb3JtYXQoXCJ3b2ZmMlwiKSxcclxuXHRcdHVybChcIi4vYXNzZXRzL2ZvbnRzL0FsbGlhbnpOZW8vQWxsaWFuel9OZW9fd2ViZm9udHMvd29mZi9BbGxpYW56TmVvVzA0LVNlbWlCb2xkLndvZmZcIilcclxuXHRcdFx0Zm9ybWF0KFwid29mZlwiKTtcclxufVxyXG5cclxuQGZvbnQtZmFjZSB7XHJcblx0Zm9udC1mYW1pbHk6IFwiQWxsaWFueiBOZW9cIjtcclxuXHRmb250LXN0eWxlOiBpdGFsaWM7XHJcblx0Zm9udC13ZWlnaHQ6IDYwMDtcclxuXHRmb250LWRpc3BsYXk6IHN3YXA7XHJcblx0c3JjOiB1cmwoXCIuL2Fzc2V0cy9mb250cy9BbGxpYW56TmVvL0FsbGlhbnpfTmVvX3dlYmZvbnRzL3dvZmYyL0FsbGlhbnpOZW9XMDQtU2VtaUJvbGRJdC53b2ZmMlwiKVxyXG5cdFx0XHRmb3JtYXQoXCJ3b2ZmMlwiKSxcclxuXHRcdHVybChcIi4vYXNzZXRzL2ZvbnRzL0FsbGlhbnpOZW8vQWxsaWFuel9OZW9fd2ViZm9udHMvd29mZi9BbGxpYW56TmVvVzA0LVNlbWlCb2xkSXQud29mZlwiKVxyXG5cdFx0XHRmb3JtYXQoXCJ3b2ZmXCIpO1xyXG59XHJcblxyXG5AZm9udC1mYWNlIHtcclxuXHRmb250LWZhbWlseTogXCJBbGxpYW56IE5lb1wiO1xyXG5cdGZvbnQtc3R5bGU6IG5vcm1hbDtcclxuXHRmb250LXdlaWdodDogNzAwO1xyXG5cdGZvbnQtZGlzcGxheTogc3dhcDtcclxuXHRzcmM6IHVybChcIi4vYXNzZXRzL2ZvbnRzL0FsbGlhbnpOZW8vQWxsaWFuel9OZW9fd2ViZm9udHMvd29mZjIvQWxsaWFuek5lb1cwNC1Cb2xkLndvZmYyXCIpXHJcblx0XHRcdGZvcm1hdChcIndvZmYyXCIpLFxyXG5cdFx0dXJsKFwiLi9hc3NldHMvZm9udHMvQWxsaWFuek5lby9BbGxpYW56X05lb193ZWJmb250cy93b2ZmL0FsbGlhbnpOZW9XMDQtQm9sZC53b2ZmXCIpXHJcblx0XHRcdGZvcm1hdChcIndvZmZcIik7XHJcbn1cclxuXHJcbkBmb250LWZhY2Uge1xyXG5cdGZvbnQtZmFtaWx5OiBcIkFsbGlhbnogTmVvXCI7XHJcblx0Zm9udC1zdHlsZTogaXRhbGljO1xyXG5cdGZvbnQtd2VpZ2h0OiA3MDA7XHJcblx0Zm9udC1kaXNwbGF5OiBzd2FwO1xyXG5cdHNyYzogdXJsKFwiLi9hc3NldHMvZm9udHMvQWxsaWFuek5lby9BbGxpYW56X05lb193ZWJmb250cy93b2ZmMi9BbGxpYW56TmVvVzA0LUJvbGRJdGFsaWMud29mZjJcIilcclxuXHRcdFx0Zm9ybWF0KFwid29mZjJcIiksXHJcblx0XHR1cmwoXCIuL2Fzc2V0cy9mb250cy9BbGxpYW56TmVvL0FsbGlhbnpfTmVvX3dlYmZvbnRzL3dvZmYvQWxsaWFuek5lb1cwNC1Cb2xkSXRhbGljLndvZmZcIilcclxuXHRcdFx0Zm9ybWF0KFwid29mZlwiKTtcclxufVxyXG5cclxuKiB7XHJcblx0Y29sb3I6ICRjb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleTtcclxuXHRmb250LWZhbWlseTogXCJBbGxpYW56IE5lb1wiLCBzYW5zLXNlcmlmO1xyXG5cdGZvbnQtd2VpZ2h0OiA0MDA7XHJcblx0Zm9udC1zaXplOiAxNnB4O1xyXG59XHJcblxyXG5odG1sIHtcclxuXHQtLWlvbi1zYWZlLWFyZWEtdG9wOiAwcHg7XHJcbn1cclxuXHJcbi5jb2wtMSB7XHJcblx0d2lkdGg6IDguMzMlO1xyXG59XHJcblxyXG4uY29sLTIge1xyXG5cdHdpZHRoOiAxNi42NiU7XHJcbn1cclxuXHJcbi5jb2wtMyB7XHJcblx0d2lkdGg6IDI1JTtcclxufVxyXG5cclxuLmNvbC00IHtcclxuXHR3aWR0aDogMzMuMzMlO1xyXG59XHJcblxyXG4uY29sLTUge1xyXG5cdHdpZHRoOiA0MS42NiU7XHJcbn1cclxuXHJcbi5jb2wtNiB7XHJcblx0d2lkdGg6IDUwJTtcclxufVxyXG5cclxuLmNvbC03IHtcclxuXHR3aWR0aDogNTguMzMlO1xyXG59XHJcblxyXG4uY29sLTgge1xyXG5cdHdpZHRoOiA2Ni42NiU7XHJcbn1cclxuXHJcbi5jb2wtOSB7XHJcblx0d2lkdGg6IDc1JTtcclxufVxyXG5cclxuLmNvbC0xMCB7XHJcblx0d2lkdGg6IDgzLjMzJTtcclxufVxyXG5cclxuLmNvbC0xMSB7XHJcblx0d2lkdGg6IDkxLjY2JTtcclxufVxyXG5cclxuLmNvbC0xMiB7XHJcblx0d2lkdGg6IDEwMCU7XHJcbn1cclxuXHJcbkBtZWRpYSBvbmx5IHNjcmVlbiBhbmQgKG1heC13aWR0aDogNTc2cHgpIHtcclxuXHQvKiBGb3IgdGFibGV0czogKi9cclxuXHQuY29sLXNtLTEge1xyXG5cdFx0d2lkdGg6IDguMzMlO1xyXG5cdH1cclxuXHJcblx0LmNvbC1zbS0yIHtcclxuXHRcdHdpZHRoOiAxNi42NiU7XHJcblx0fVxyXG5cclxuXHQuY29sLXNtLTMge1xyXG5cdFx0d2lkdGg6IDI1JTtcclxuXHR9XHJcblxyXG5cdC5jb2wtc20tNCB7XHJcblx0XHR3aWR0aDogMzMuMzMlO1xyXG5cdH1cclxuXHJcblx0LmNvbC1zbS01IHtcclxuXHRcdHdpZHRoOiA0MS42NiU7XHJcblx0fVxyXG5cclxuXHQuY29sLXNtLTYge1xyXG5cdFx0d2lkdGg6IDUwJTtcclxuXHR9XHJcblxyXG5cdC5jb2wtc20tNyB7XHJcblx0XHR3aWR0aDogNTguMzMlO1xyXG5cdH1cclxuXHJcblx0LmNvbC1zbS04IHtcclxuXHRcdHdpZHRoOiA2Ni42NiU7XHJcblx0fVxyXG5cclxuXHQuY29sLXNtLTkge1xyXG5cdFx0d2lkdGg6IDc1JTtcclxuXHR9XHJcblxyXG5cdC5jb2wtc20tMTAge1xyXG5cdFx0d2lkdGg6IDgzLjMzJTtcclxuXHR9XHJcblxyXG5cdC5jb2wtc20tMTEge1xyXG5cdFx0d2lkdGg6IDkxLjY2JTtcclxuXHR9XHJcblxyXG5cdC5jb2wtc20tMTIge1xyXG5cdFx0d2lkdGg6IDEwMCU7XHJcblx0fVxyXG59XHJcblxyXG5AbWVkaWEgb25seSBzY3JlZW4gYW5kIChtYXgtd2lkdGg6IDc2OHB4KSBhbmQgKG1pbi13aWR0aDogNTc3cHgpIHtcclxuXHQvKiBGb3IgdGFibGV0czogKi9cclxuXHQuY29sLW1kLTEge1xyXG5cdFx0d2lkdGg6IDguMzMlO1xyXG5cdH1cclxuXHJcblx0LmNvbC1tZC0yIHtcclxuXHRcdHdpZHRoOiAxNi42NiU7XHJcblx0fVxyXG5cclxuXHQuY29sLW1kLTMge1xyXG5cdFx0d2lkdGg6IDI1JTtcclxuXHR9XHJcblxyXG5cdC5jb2wtbWQtNCB7XHJcblx0XHR3aWR0aDogMzMuMzMlO1xyXG5cdH1cclxuXHJcblx0LmNvbC1tZC01IHtcclxuXHRcdHdpZHRoOiA0MS42NiU7XHJcblx0fVxyXG5cclxuXHQuY29sLW1kLTYge1xyXG5cdFx0d2lkdGg6IDUwJTtcclxuXHR9XHJcblxyXG5cdC5jb2wtbWQtNyB7XHJcblx0XHR3aWR0aDogNTguMzMlO1xyXG5cdH1cclxuXHJcblx0LmNvbC1tZC04IHtcclxuXHRcdHdpZHRoOiA2Ni42NiU7XHJcblx0fVxyXG5cclxuXHQuY29sLW1kLTkge1xyXG5cdFx0d2lkdGg6IDc1JTtcclxuXHR9XHJcblxyXG5cdC5jb2wtbWQtMTAge1xyXG5cdFx0d2lkdGg6IDgzLjMzJTtcclxuXHR9XHJcblxyXG5cdC5jb2wtbWQtMTEge1xyXG5cdFx0d2lkdGg6IDkxLjY2JTtcclxuXHR9XHJcblxyXG5cdC5jb2wtbWQtMTIge1xyXG5cdFx0d2lkdGg6IDEwMCU7XHJcblx0fVxyXG59XHJcblxyXG5AbWVkaWEgb25seSBzY3JlZW4gYW5kIChtaW4td2lkdGg6IDc2OXB4KSB7XHJcblx0LyogRm9yIHRhYmxldHM6ICovXHJcblx0LmNvbC1sZy0xIHtcclxuXHRcdHdpZHRoOiA4LjMzJTtcclxuXHR9XHJcblxyXG5cdC5jb2wtbGctMiB7XHJcblx0XHR3aWR0aDogMTYuNjYlO1xyXG5cdH1cclxuXHJcblx0LmNvbC1sZy0zIHtcclxuXHRcdHdpZHRoOiAyNSU7XHJcblx0fVxyXG5cclxuXHQuY29sLWxnLTQge1xyXG5cdFx0d2lkdGg6IDMzLjMzJTtcclxuXHR9XHJcblxyXG5cdC5jb2wtbGctNSB7XHJcblx0XHR3aWR0aDogNDEuNjYlO1xyXG5cdH1cclxuXHJcblx0LmNvbC1sZy02IHtcclxuXHRcdHdpZHRoOiA1MCU7XHJcblx0fVxyXG5cclxuXHQuY29sLWxnLTcge1xyXG5cdFx0d2lkdGg6IDU4LjMzJTtcclxuXHR9XHJcblxyXG5cdC5jb2wtbGctOCB7XHJcblx0XHR3aWR0aDogNjYuNjYlO1xyXG5cdH1cclxuXHJcblx0LmNvbC1sZy05IHtcclxuXHRcdHdpZHRoOiA3NSU7XHJcblx0fVxyXG5cclxuXHQuY29sLWxnLTEwIHtcclxuXHRcdHdpZHRoOiA4My4zMyU7XHJcblx0fVxyXG5cclxuXHQuY29sLWxnLTExIHtcclxuXHRcdHdpZHRoOiA5MS42NiU7XHJcblx0fVxyXG5cclxuXHQuY29sLWxnLTEyIHtcclxuXHRcdHdpZHRoOiAxMDAlO1xyXG5cdH1cclxufVxyXG5cclxuLnJvdyB7XHJcblx0ZGlzcGxheTogZmxleDtcclxuXHRqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuXHRhbGlnbi1pdGVtczogY2VudGVyO1xyXG59XHJcblxyXG4vLyBDU1NcclxuLmN1c3RvbS10b2FzdCB7XHJcblx0LS1tYXgtd2lkdGg6IGZpdC1jb250ZW50O1xyXG59XHJcblxyXG4vKlxyXG4gKiAyLiBDdXN0b20gQ1NTIGZvciBjb21wYXRpYmlsaXR5IHdpdGggRWRnZVxyXG4gKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcbiAqL1xyXG5pbnB1dDo6LW1zLXJldmVhbCxcclxuaW5wdXQ6Oi1tcy1jbGVhciB7XHJcblx0ZGlzcGxheTogbm9uZTtcclxufVxyXG5cclxuLnN3YWwyLXBvcHVwIHtcclxuXHRtYXJnaW4tdG9wOiAyMHB4O1xyXG59XHJcblxyXG4vKlxyXG4gKiAzLiBDdXN0b20gQ1NTIGZvciBsb2FkaW5nIGNvbnRyb2xsZXJcclxuICogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG4gKi9cclxuLnRyYW5zcGFyZW50LWxvYWRpbmctY2xhc3Mge1xyXG5cdC0tYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XHJcblx0LS1zcGlubmVyLWNvbG9yOiAjNDdlNmIxO1xyXG59XHJcblxyXG4ubG9hZGluZy13cmFwcGVyLnNjLWlvbi1sb2FkaW5nLW1kIHtcclxuXHRib3gtc2hhZG93OiB1bnNldDtcclxuXHQtd2Via2l0LWJveC1zaGFkb3c6IHVuc2V0O1xyXG59XHJcblxyXG4udWlsIHtcclxuXHRjb2xvcjogJGNvbG9yLW5leHRnZW4tZ3JleTtcclxufVxyXG5cclxuLmJ0biB7XHJcblx0aGVpZ2h0OiA0OHB4O1xyXG5cdGJvcmRlci1yYWRpdXM6IDI4cHg7XHJcblx0cGFkZGluZzogMHB4IDQxcHggMHB4IDQxcHg7XHJcblx0Ym94LXNoYWRvdzogbm9uZTtcclxuXHJcblx0Ji5idG4tY2lyY2xlIHtcclxuXHRcdGJhY2tncm91bmQtY29sb3I6ICRjb2xvci1uZXh0Z2VuLXN0b25lLWdyZXkgIWltcG9ydGFudDtcclxuXHRcdGNvbG9yOiAkY29sb3ItbmV4dGdlbi1ibGFjaztcclxuXHRcdHBhZGRpbmc6IHVuc2V0ICFpbXBvcnRhbnQ7XHJcblx0XHRoZWlnaHQ6IDM2cHggIWltcG9ydGFudDtcclxuXHRcdHdpZHRoOiAzNnB4ICFpbXBvcnRhbnQ7XHJcblx0XHRib3JkZXItcmFkaXVzOiA1MCUgIWltcG9ydGFudDtcclxuXHJcblx0XHRpIHtcclxuXHRcdFx0Y29sb3I6ICRjb2xvci1uZXh0Z2VuLWJsYWNrO1xyXG5cdFx0fVxyXG5cdH1cclxuXHJcblx0Ji5wcmltYXJ5IHtcclxuXHRcdGJhY2tncm91bmQ6ICRjb2xvci1uZXh0Z2VuLWdyZWVuO1xyXG5cdFx0Y29sb3I6ICRjb2xvci1uZXh0Z2VuLXdoaXRlO1xyXG5cclxuXHRcdC51aWwge1xyXG5cdFx0XHRjb2xvcjogJGNvbG9yLW5leHRnZW4td2hpdGU7XHJcblx0XHR9XHJcblxyXG5cdFx0JjpkaXNhYmxlZCB7XHJcblx0XHRcdGJhY2tncm91bmQtY29sb3I6ICRjb2xvci1uZXh0Z2VuLWdyZXktYmFja2dyb3VuZCAhaW1wb3J0YW50O1xyXG5cdFx0XHRjb2xvcjogJGNvbG9yLW5leHRnZW4tZ3JleSAhaW1wb3J0YW50O1xyXG5cdFx0fVxyXG5cdH1cclxuXHJcblx0Ji5zZWNvbmRhcnkge1xyXG5cdFx0YmFja2dyb3VuZDogJGNvbG9yLW5leHRnZW4td2hpdGUgIWltcG9ydGFudDtcclxuXHRcdGJvcmRlci1jb2xvcjogJGNvbG9yLW5leHRnZW4tZ3JlZW47XHJcblx0XHRib3JkZXI6IHNvbGlkIDFweDtcclxuXHRcdGNvbG9yOiAkY29sb3ItbmV4dGdlbi1ncmVlbjtcclxuXHJcblx0XHQudWlsIHtcclxuXHRcdFx0Y29sb3I6ICRjb2xvci1uZXh0Z2VuLWdyZWVuO1xyXG5cdFx0fVxyXG5cclxuXHRcdCY6ZGlzYWJsZWQge1xyXG5cdFx0XHRiYWNrZ3JvdW5kLWNvbG9yOiAkY29sb3ItbmV4dGdlbi13aGl0ZSAhaW1wb3J0YW50O1xyXG5cdFx0XHRjb2xvcjogJGNvbG9yLW5leHRnZW4tZ3JleSAhaW1wb3J0YW50O1xyXG5cdFx0XHRib3JkZXItY29sb3I6ICRjb2xvci1uZXh0Z2VuLWdyZXktYmFja2dyb3VuZCAhaW1wb3J0YW50O1xyXG5cdFx0fVxyXG5cdH1cclxuXHJcblx0Ji50cmFuc3BhcmVudCB7XHJcblx0XHRiYWNrZ3JvdW5kOiB0cmFuc3BhcmVudCAhaW1wb3J0YW50O1xyXG5cdFx0Ym9yZGVyLWNvbG9yOiAkY29sb3ItbmV4dGdlbi1ncmVlbjtcclxuXHRcdGJvcmRlcjogc29saWQgMXB4O1xyXG5cdFx0Y29sb3I6ICRjb2xvci1uZXh0Z2VuLWdyZWVuO1xyXG5cclxuXHRcdC51aWwge1xyXG5cdFx0XHRjb2xvcjogJGNvbG9yLW5leHRnZW4tZ3JlZW47XHJcblx0XHR9XHJcblxyXG5cdFx0JjpkaXNhYmxlZCB7XHJcblx0XHRcdGJhY2tncm91bmQtY29sb3I6IHRyYW5zcGFyZW50ICFpbXBvcnRhbnQ7XHJcblx0XHRcdGNvbG9yOiAkY29sb3ItbmV4dGdlbi1ncmV5ICFpbXBvcnRhbnQ7XHJcblx0XHRcdGJvcmRlci1jb2xvcjogJGNvbG9yLW5leHRnZW4tZ3JleS1iYWNrZ3JvdW5kICFpbXBvcnRhbnQ7XHJcblx0XHR9XHJcblx0fVxyXG5cclxuXHQmLmJ0bi1sYXJnZSB7XHJcblx0XHRoZWlnaHQ6IDU2cHggIWltcG9ydGFudDtcclxuXHRcdHdpZHRoOiAxMDAlO1xyXG5cdH1cclxuXHJcblx0Ji5ib2xkIHtcclxuXHRcdGZvbnQtd2VpZ2h0OiA3MDAgIWltcG9ydGFudDtcclxuXHR9XHJcblxyXG5cdCYuc2VtaWJvbGQge1xyXG5cdFx0Zm9udC13ZWlnaHQ6IDYwMCAhaW1wb3J0YW50O1xyXG5cdH1cclxufVxyXG5cclxuLmJ0bi1uby1zcGFjZSB7XHJcblx0cGFkZGluZzogNXB4ICFpbXBvcnRhbnQ7XHJcblx0aGVpZ2h0OiBmaXQtY29udGVudDtcclxufVxyXG5cclxuLmJ0bi1iYWNrIHtcclxuXHR3aWR0aDogMzFweDtcclxuXHRoZWlnaHQ6IDI4cHg7XHJcblx0YmFja2dyb3VuZC1jb2xvcjogdHJhbnNwYXJlbnQ7XHJcblx0cGFkZGluZzogMDtcclxuXHRjb2xvcjogJGNvbG9yLW5leHRnZW4tZ3JlZW47XHJcbn1cclxuXHJcbi5jb250YWluZXIge1xyXG5cdHBhZGRpbmc6IDJyZW07XHJcblx0aGVpZ2h0OiAxMDAlO1xyXG59XHJcblxyXG4uYm9keS1zZWN0aW9uIHtcclxuXHR3aWR0aDogMTAwJTtcclxuXHRoZWlnaHQ6IDk1JTtcclxuXHRvdmVyZmxvdy15OiBhdXRvO1xyXG5cdHBvc2l0aW9uOiByZWxhdGl2ZTtcclxufVxyXG5cclxuLnRvcC1zZWN0aW9uIHtcclxuXHR3aWR0aDogMTAwJTtcclxuXHRoZWlnaHQ6IDEwJTtcclxuXHRqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XHJcblx0ZGlzcGxheTogZmxleDtcclxuXHRhbGlnbi1pdGVtczogY2VudGVyO1xyXG59XHJcblxyXG4uZm9ybS1jb250cm9sIHtcclxuXHRwb3NpdGlvbjogcmVsYXRpdmU7XHJcblx0aGVpZ2h0OiA4NXB4O1xyXG5cdG1hcmdpbi1ib3R0b206IDhweDtcclxufVxyXG5cclxuLmNvbnRyb2wge1xyXG5cdGJvcmRlci1yYWRpdXM6IDhweDtcclxuXHRoZWlnaHQ6IDU2cHg7XHJcblx0Ym9yZGVyOiAxcHggc29saWQgJGNvbG9yLW5leHRnZW4tZ3JleS1iYWNrZ3JvdW5kO1xyXG5cdHdpZHRoOiAxMDAlO1xyXG5cdHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuXHR0b3A6IDMycHg7XHJcblx0YmFja2dyb3VuZC1jb2xvcjogJGNvbG9yLW5leHRnZW4td2hpdGU7XHJcblxyXG5cdCYgdGFibGUge1xyXG5cdFx0dGFibGUtbGF5b3V0OiBmaXhlZDtcclxuXHRcdGJvcmRlci1jb2xsYXBzZTogdW5zZXQ7XHJcblx0fVxyXG5cclxuXHQmIGlucHV0IHtcclxuXHRcdGhlaWdodDogNTRweDtcclxuXHRcdGJvcmRlcjogdW5zZXQ7XHJcblx0XHRib3JkZXItcmFkaXVzOiA4cHg7XHJcblx0XHR3aWR0aDogbWF4LWNvbnRlbnQ7XHJcblx0XHR3aWR0aDogMTAwJTtcclxuXHRcdHBvaW50ZXItZXZlbnRzOiBhdXRvO1xyXG5cdFx0YmFja2dyb3VuZC1jb2xvcjogJGNvbG9yLW5leHRnZW4td2hpdGU7XHJcblx0fVxyXG5cclxuXHQmLnRleHRhcmVhIHtcclxuXHRcdGhlaWdodDogMTA4cHg7XHJcblx0fVxyXG5cclxuXHQmIHRleHRhcmVhIHtcclxuXHRcdGhlaWdodDogMTA2cHg7XHJcblx0XHRib3JkZXI6IHVuc2V0O1xyXG5cdFx0Ym9yZGVyLXJhZGl1czogOHB4O1xyXG5cdFx0d2lkdGg6IG1heC1jb250ZW50O1xyXG5cdFx0d2lkdGg6IDEwMCU7XHJcblx0XHRwb2ludGVyLWV2ZW50czogYXV0bztcclxuXHRcdHJlc2l6ZTogbm9uZTtcclxuXHRcdGJhY2tncm91bmQtY29sb3I6ICRjb2xvci1uZXh0Z2VuLXdoaXRlO1xyXG5cdH1cclxuXHJcblx0JiBpbnB1dDpmb2N1cyB7XHJcblx0XHRvdXRsaW5lOiBub25lO1xyXG5cdH1cclxuXHJcblx0Jjpmb2N1cy13aXRoaW4ge1xyXG5cdFx0Ym9yZGVyLWNvbG9yOiAkY29sb3ItbmV4dGdlbi1ncmVlbjtcclxuXHJcblx0XHQuZmlyc3QtaWNvbiB7XHJcblx0XHRcdGRpc3BsYXk6IG5vbmU7XHJcblx0XHR9XHJcblxyXG5cdFx0LmZpcnN0LWljb24ubm9uLWhpZGRlbiB7XHJcblx0XHRcdGRpc3BsYXk6IHRhYmxlLWNlbGw7XHJcblx0XHR9XHJcblx0fVxyXG5cclxuXHQuZmlyc3QtaWNvbiB7XHJcblx0XHR3aWR0aDogMzJweDtcclxuXHRcdHRleHQtYWxpZ246IGNlbnRlcjtcclxuXHRcdHBhZGRpbmctbGVmdDogOHB4O1xyXG5cclxuXHRcdGkge1xyXG5cdFx0XHRmb250LXNpemU6IDI0cHggIWltcG9ydGFudDtcclxuXHRcdH1cclxuXHR9XHJcblxyXG5cdC5zZWNvbmQtaWNvbiB7XHJcblx0XHR3aWR0aDogMzJweDtcclxuXHRcdHRleHQtYWxpZ246IGNlbnRlcjtcclxuXHRcdC8vIHBhZGRpbmctcmlnaHQ6IDhweDtcclxuXHJcblx0XHRpIHtcclxuXHRcdFx0Zm9udC1zaXplOiAyNHB4ICFpbXBvcnRhbnQ7XHJcblx0XHR9XHJcblx0fVxyXG59XHJcblxyXG4uY29udHJvbDpmb2N1cy13aXRoaW4gfiBkaXYgLmNvbnRyb2wtbGFiZWwge1xyXG5cdGNvbG9yOiAkY29sb3ItbmV4dGdlbi1ncmVlbjtcclxufVxyXG5cclxuLmNvbnRyb2wtZXJyb3Ige1xyXG5cdC5jb250cm9sIHtcclxuXHRcdGJvcmRlci1jb2xvcjogJGNvbG9yLW5leHRnZW4tZXJyb3I7XHJcblx0fVxyXG5cclxuXHQuY29udHJvbC1sYWJlbCB7XHJcblx0XHRjb2xvcjogJGNvbG9yLW5leHRnZW4tZXJyb3IgIWltcG9ydGFudDtcclxuXHR9XHJcbn1cclxuXHJcbi52YWxpZGF0aW9uLXN1bW1hcnkge1xyXG5cdGxpIHtcclxuXHRcdGNvbG9yOiAkY29sb3ItbmV4dGdlbi1lcnJvciAhaW1wb3J0YW50O1xyXG5cdFx0bGlzdC1zdHlsZTogbm9uZTtcclxuXHJcblx0XHRpIHtcclxuXHRcdFx0Y29sb3I6ICRjb2xvci1uZXh0Z2VuLWVycm9yICFpbXBvcnRhbnQ7XHJcblx0XHR9XHJcblx0fVxyXG59XHJcblxyXG4ubXItMSB7XHJcblx0bWFyZ2luLXJpZ2h0OiAwLjVyZW07XHJcbn1cclxuXHJcbi5tYi0xIHtcclxuXHRtYXJnaW4tYm90dG9tOiAwLjVyZW07XHJcbn1cclxuXHJcbi5kaWFsb2ctcGFuZSB7XHJcblx0cG9zaXRpb246IGFic29sdXRlO1xyXG5cdHBvaW50ZXItZXZlbnRzOiBhdXRvO1xyXG5cdGJveC1zaXppbmc6IGJvcmRlci1ib3g7XHJcblx0ei1pbmRleDogMTAwMDtcclxuXHRkaXNwbGF5OiBibG9jaztcclxuXHRtYXgtd2lkdGg6IDEwMCU7XHJcblx0bWF4LWhlaWdodDogMTAwJTtcclxufVxyXG5cclxuLm92ZXJsYXktYmFja2Ryb3Age1xyXG5cdGJhY2tncm91bmQtY29sb3I6ICRjb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleTtcclxuXHRvcGFjaXR5OiAwLjIgIWltcG9ydGFudDtcclxufVxyXG5cclxuLmRpYWxvZy1jb250YWluZXIge1xyXG5cdGFuaW1hdGlvbjogZmFkZUluIDAuNXMgbGluZWFyO1xyXG5cdGJhY2tncm91bmQtY29sb3I6ICRjb2xvci1uZXh0Z2VuLXdoaXRlO1xyXG59XHJcblxyXG5Aa2V5ZnJhbWVzIGZhZGVJbiB7XHJcblx0ZnJvbSB7XHJcblx0XHR0cmFuc2Zvcm06IHRyYW5zbGF0ZVkoMTAwJSk7XHJcblx0fVxyXG5cclxuXHR0byB7XHJcblx0XHR0cmFuc2Zvcm06IHRyYW5zbGF0ZVkoMCUpO1xyXG5cdH1cclxufVxyXG5cclxuLmVycm9yIHtcclxuXHRjb2xvcjogJGNvbG9yLW5leHRnZW4tZXJyb3I7XHJcblxyXG5cdCYuYmFja2dyb3VuZCB7XHJcblx0XHRiYWNrZ3JvdW5kLWNvbG9yOiAkY29sb3ItbmV4dGdlbi1lcnJvcjtcclxuXHR9XHJcbn1cclxuXHJcbi5zdWNjZXNzIHtcclxuXHRjb2xvcjogJGNvbG9yLW5leHRnZW4tZmlicmFudC1ncmVlbjtcclxuXHJcblx0Ji5iYWNrZ3JvdW5kIHtcclxuXHRcdGJhY2tncm91bmQtY29sb3I6ICRjb2xvci1uZXh0Z2VuLWZpYnJhbnQtZ3JlZW47XHJcblx0fVxyXG59XHJcblxyXG4ud2FybmluZyB7XHJcblx0Y29sb3I6ICRjb2xvci1uZXh0Z2VuLXdhcm5pbmc7XHJcblxyXG5cdCYuYmFja2dyb3VuZCB7XHJcblx0XHRiYWNrZ3JvdW5kLWNvbG9yOiAkY29sb3ItbmV4dGdlbi13YXJuaW5nO1xyXG5cdH1cclxufVxyXG5cclxuLnNlbGVjdCB7XHJcblx0d2lkdGg6IDEwMCU7XHJcblx0aGVpZ2h0OiA1NHB4O1xyXG5cdGJvcmRlcjogdW5zZXQ7XHJcblx0Ym9yZGVyLXJhZGl1czogOHB4O1xyXG5cdGRpc3BsYXk6IGdyaWQ7XHJcblx0YXBwZWFyYW5jZTogbm9uZTtcclxuXHRncmlkLXRlbXBsYXRlLWFyZWFzOiBcInNlbGVjdFwiO1xyXG5cclxuXHQmOmZvY3VzIHtcclxuXHRcdG91dGxpbmU6IHVuc2V0O1xyXG5cdH1cclxufVxyXG5cclxuLmNvbG9yLWJsYWNrIHtcclxuXHRjb2xvcjogJGNvbG9yLW5leHRnZW4tYmxhY2s7XHJcbn1cclxuXHJcbi5tb2RhbC1kZWZhdWx0IHtcclxuXHQtLXdpZHRoOiAxMDAlO1xyXG5cdC0taGVpZ2h0OiAxMDAlO1xyXG59XHJcblxyXG4uaW50ZWdyYXRpb24tcGFuZWwge1xyXG5cdHdpZHRoOiAxMDAlO1xyXG5cdGhlaWdodDogMTAwJTtcclxuXHRtYXgtd2lkdGg6IDEwMCUgIWltcG9ydGFudDtcclxufVxyXG5cclxuLnZlcmxvb3AtYnV0dG9uIHtcclxuXHR2aXNpYmlsaXR5OiBoaWRkZW47XHJcbn1cclxuXHJcbi5iYWNrLWFyZWEge1xyXG5cdHBvc2l0aW9uOiBmaXhlZDtcclxuXHR0b3A6IDA7XHJcblx0cmlnaHQ6IDA7XHJcblx0aGVpZ2h0OiA1MHB4O1xyXG5cdHdpZHRoOiAxMDAlO1xyXG5cdGJhY2tncm91bmQtY29sb3I6ICRjb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS01MDtcclxuXHR6LWluZGV4OiA5OTk5OTk5O1xyXG5cclxuXHQmLmlvcyB7XHJcblx0XHRoZWlnaHQ6IDgwcHg7XHJcblx0fVxyXG59XHJcblxyXG4udGl0bGUtd2lkZ2V0IHtcclxuXHR0ZXh0LWFsaWduOiBjZW50ZXI7XHJcblx0cG9zaXRpb246IHN0aWNreTtcclxuXHR0b3A6IDQ4cHg7XHJcbn1cclxuXHJcbi5idXR0b24tYmFjayB7XHJcblx0YmFja2dyb3VuZC1jb2xvcjogI2ZhZmFmYTtcclxuXHRoZWlnaHQ6IDM2cHg7XHJcblx0d2lkdGg6IDM2cHg7XHJcblx0Ym9yZGVyLXJhZGl1czogNTAlO1xyXG5cdHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuXHRsZWZ0OiAxOHB4O1xyXG5cdGJvdHRvbTogNHB4O1xyXG59XHJcblxyXG4uaWNvbi1jbG9zZS13aWRnZXQge1xyXG5cdHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuXHR6LWluZGV4OiAyNTA7XHJcblx0bGVmdDogMTFweDtcclxuXHRib3R0b206IDEzcHg7XHJcbn1cclxuXHJcbi5kYXRhLWRlZmF1bHQge1xyXG5cdHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuXHR0b3A6IDUwJTtcclxuXHRsZWZ0OiA1MCU7XHJcblx0dHJhbnNmb3JtOiB0cmFuc2xhdGUoLTUwJSwgLTUwJSk7XHJcblx0dGV4dC1hbGlnbjogY2VudGVyO1xyXG5cdGNvbG9yOiAkY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNDAwO1xyXG5cdHotaW5kZXg6IDEwMDA7XHJcbn1cclxuXHJcbi5hdmFhbW9fX2ljb24ge1xyXG5cdHZpc2liaWxpdHk6IGhpZGRlbiAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4uYXZhYW1vX19jaGF0X193aWRnZXQuaW9zIHtcclxuXHQjYXZhYW1vX19wb3B1cCB7XHJcblx0XHRwYWRkaW5nLXRvcDogNDBweDtcclxuXHR9XHJcbn1cclxuXHJcbi5kLWZsZXgge1xyXG5cdGRpc3BsYXk6IGZsZXg7XHJcbn1cclxuXHJcbm5leHRjYXJlLWxheW91dCB7XHJcblx0bGVmdDogMDtcclxuXHRyaWdodDogMDtcclxuXHR0b3A6IDA7XHJcblx0Ym90dG9tOiAwO1xyXG5cdGRpc3BsYXk6IGZsZXg7XHJcblx0cG9zaXRpb246IGFic29sdXRlO1xyXG5cdGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcblx0anVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xyXG5cdGNvbnRhaW46IGxheW91dCBzaXplIHN0eWxlO1xyXG5cdG92ZXJmbG93OiBoaWRkZW47XHJcblx0YmFja2dyb3VuZC1jb2xvcjogJGNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTUwO1xyXG5cdHBhZGRpbmctcmlnaHQ6IDI0cHg7XHJcblx0cGFkZGluZy1sZWZ0OiAyNHB4O1xyXG59XHJcblxyXG5pb24taGVhZGVyLmlvcy5oZWFkZXItaW9zIHtcclxuXHRtYXJnaW4tdG9wOiA0MHB4O1xyXG59XHJcblxyXG4uaGVhZGVyLWlvcyBpb24tdG9vbGJhcjpsYXN0LW9mLXR5cGUge1xyXG5cdC0tYm9yZGVyLXdpZHRoOiAwcHggIWltcG9ydGFudDtcclxufVxyXG5cclxuLmhlYWRlci1tZC5tZDo6YWZ0ZXIge1xyXG5cdGRpc3BsYXk6IG5vbmU7XHJcbn1cclxuXHJcbmlvbi10b29sYmFyIHtcclxuXHRwYWRkaW5nLXJpZ2h0OiB1bnNldCAhaW1wb3J0YW50O1xyXG5cdHBhZGRpbmctbGVmdDogdW5zZXQgIWltcG9ydGFudDtcclxufVxyXG5cclxuaS5pY29uLWJhY2sge1xyXG5cdGNvbnRlbnQ6IHVybChhc3NldHMvaWNvbi9sb25nLWFycm93LWxlZnQtaWNvbi5zdmcpO1xyXG59XHJcblxyXG4udmVybG9vcC13aWRnZXQuaW9zIHtcclxuXHQudmVybG9vcC1jb250YWluZXIudmlzaWJsZSB7XHJcblx0XHRoZWlnaHQ6IGNhbGMoMTAwJSAtIDQwcHgpO1xyXG5cdFx0dG9wOiA0MHB4O1xyXG5cdH1cclxufVxyXG5cclxuI25leHRjYXJlLWFkcyB7XHJcblx0ZGlzcGxheTogbm9uZTtcclxuXHRvdmVyZmxvdzogc2Nyb2xsO1xyXG5cdGhlaWdodDogMTgwcHg7XHJcbn1cclxuXHJcbi5kLWJsb2NrIHtcclxuXHRkaXNwbGF5OiBibG9jaztcclxufVxyXG5cclxuLnRpdGxlLXRleHQge1xyXG5cdGNvbG9yOiAkY29sb3ItbmV4dGdlbi1ibHVlO1xyXG59XHJcblxyXG46aG9zdCBpb24tZGF0ZXRpbWUgI3NoYWRvdy1yb290IHtcclxuXHQuZGF0ZXRpbWUtY2FsZW5kYXIge1xyXG5cdFx0LmNhbGVuZGFyLWhlYWRlciB7XHJcblx0XHRcdC5jYWxlbmRhci1hY3Rpb24tYnV0dG9ucyB7XHJcblx0XHRcdFx0LmNhbGVuZGFyLW1vbnRoLXllYXIge1xyXG5cdFx0XHRcdFx0YWxpZ24taXRlbXM6IGNlbnRlcjtcclxuXHRcdFx0XHRcdGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG5cdFx0XHRcdFx0ZGlzcGxheTogZmxleDtcclxuXHRcdFx0XHRcdHdpZHRoOiAxMDAlO1xyXG5cclxuXHRcdFx0XHRcdGlvbi1pY29uIHtcclxuXHRcdFx0XHRcdFx0ZGlzcGxheTogbm9uZTtcclxuXHRcdFx0XHRcdH1cclxuXHRcdFx0XHR9XHJcblxyXG5cdFx0XHRcdC5jYWxlbmRhci1uZXh0LXByZXYge1xyXG5cdFx0XHRcdFx0cG9zaXRpb246IGFic29sdXRlO1xyXG5cdFx0XHRcdFx0d2lkdGg6IDEwMCU7XHJcblx0XHRcdFx0XHRyaWdodDogMDtcclxuXHJcblx0XHRcdFx0XHRpb24tYnV0dG9ucyB7XHJcblx0XHRcdFx0XHRcdGRpc3BsYXk6IGZsZXg7XHJcblx0XHRcdFx0XHRcdGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcclxuXHRcdFx0XHRcdFx0d2lkdGg6IDEwMCU7XHJcblx0XHRcdFx0XHR9XHJcblx0XHRcdFx0fVxyXG5cdFx0XHR9XHJcblx0XHR9XHJcblx0fVxyXG59XHJcblxyXG4ubWF0LWRpYWxvZy1jb250YWluZXIge1xyXG5cdHBhZGRpbmc6IHVuc2V0ICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi8qIENoYW5nZSBhdXRvY29tcGxldGUgc3R5bGVzIGluIFdlYktpdCAqL1xyXG5pbnB1dDotd2Via2l0LWF1dG9maWxsLFxyXG5pbnB1dDotd2Via2l0LWF1dG9maWxsOmhvdmVyLFxyXG5pbnB1dDotd2Via2l0LWF1dG9maWxsOmZvY3VzLFxyXG50ZXh0YXJlYTotd2Via2l0LWF1dG9maWxsLFxyXG50ZXh0YXJlYTotd2Via2l0LWF1dG9maWxsOmhvdmVyLFxyXG50ZXh0YXJlYTotd2Via2l0LWF1dG9maWxsOmZvY3VzLFxyXG5zZWxlY3Q6LXdlYmtpdC1hdXRvZmlsbCxcclxuc2VsZWN0Oi13ZWJraXQtYXV0b2ZpbGw6aG92ZXIsXHJcbnNlbGVjdDotd2Via2l0LWF1dG9maWxsOmZvY3VzIHtcclxuXHQtd2Via2l0LXRleHQtZmlsbC1jb2xvcjogYmxhY2s7XHJcblx0LXdlYmtpdC1ib3gtc2hhZG93OiAwIDAgMHB4IDEwMDBweCB3aGl0ZSBpbnNldDtcclxuXHR0cmFuc2l0aW9uOiBiYWNrZ3JvdW5kLWNvbG9yIDUwMDBzIGVhc2UtaW4tb3V0IDBzO1xyXG59XHJcblxyXG4uZm9yY2UtdXBkYXRlLXBvcHVwICsgLmNkay1nbG9iYWwtb3ZlcmxheS13cmFwcGVyIHtcclxuXHQuc2F2ZS1idG4ge1xyXG5cdFx0YmFja2dyb3VuZDogdmFyKC0tbHVtaS1wcmltYXJ5LXllbGxvdy1jb2xvcikgIWltcG9ydGFudDtcclxuXHRcdGNvbG9yOiB2YXIoLS1sdW1pLXdoaXRlLWNvbG9yKSAhaW1wb3J0YW50O1xyXG5cdFx0Zm9udC13ZWlnaHQ6IGJvbGQgIWltcG9ydGFudDtcclxuXHR9XHJcblxyXG5cdC5jYW5jZWwtYnRuIHtcclxuXHRcdGNvbG9yOiB2YXIoLS1sdW1pLXByaW1hcnkteWVsbG93LWNvbG9yKSAhaW1wb3J0YW50O1xyXG5cdH1cclxufVxyXG5cclxuQC13ZWJraXQta2V5ZnJhbWVzIHNsaWRlSW5SaWdodCB7XHJcblx0MCUge1xyXG5cdFx0LXdlYmtpdC10cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKDEwMCUsIDAsIDApO1xyXG5cdFx0dHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgxMDAlLCAwLCAwKTtcclxuXHRcdHZpc2liaWxpdHk6IHZpc2libGU7XHJcblx0fVxyXG5cclxuXHR0byB7XHJcblx0XHQtd2Via2l0LXRyYW5zZm9ybTogdHJhbnNsYXRlWigwKTtcclxuXHRcdHRyYW5zZm9ybTogdHJhbnNsYXRlWigwKTtcclxuXHR9XHJcbn1cclxuXHJcbkBrZXlmcmFtZXMgc2xpZGVJblJpZ2h0IHtcclxuXHQwJSB7XHJcblx0XHQtd2Via2l0LXRyYW5zZm9ybTogdHJhbnNsYXRlM2QoMTAwJSwgMCwgMCk7XHJcblx0XHR0cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKDEwMCUsIDAsIDApO1xyXG5cdFx0dmlzaWJpbGl0eTogdmlzaWJsZTtcclxuXHR9XHJcblxyXG5cdHRvIHtcclxuXHRcdC13ZWJraXQtdHJhbnNmb3JtOiB0cmFuc2xhdGVaKDApO1xyXG5cdFx0dHJhbnNmb3JtOiB0cmFuc2xhdGVaKDApO1xyXG5cdH1cclxufVxyXG5cclxuLmFuaW1hdGVfX3NsaWRlSW5SaWdodCB7XHJcblx0LXdlYmtpdC1hbmltYXRpb24tbmFtZTogc2xpZGVJblJpZ2h0O1xyXG5cdGFuaW1hdGlvbi1uYW1lOiBzbGlkZUluUmlnaHQ7XHJcbn1cclxuXHJcbi5hbmltYXRlX19hbmltYXRlZCB7XHJcblx0LXdlYmtpdC1hbmltYXRpb24tZHVyYXRpb246IDAuNXM7XHJcblx0YW5pbWF0aW9uLWR1cmF0aW9uOiAwLjVzO1xyXG5cdC13ZWJraXQtYW5pbWF0aW9uLWR1cmF0aW9uOiAwLjVzO1xyXG5cdGFuaW1hdGlvbi1kdXJhdGlvbjogMC41cztcclxuXHQtd2Via2l0LWFuaW1hdGlvbi1maWxsLW1vZGU6IGJvdGg7XHJcblx0YW5pbWF0aW9uLWZpbGwtbW9kZTogYm90aDtcclxufVxyXG4iLCIuZGlzcGxheS14bCB7XHJcbiAgICBmb250LXNpemU6IDQxcHggIWltcG9ydGFudDtcclxuICAgIGZvbnQtd2VpZ2h0OiA0MDAgIWltcG9ydGFudDtcclxuICAgIGxpbmUtaGVpZ2h0OiAxMjAlICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5kaXNwbGF5LW1kIHtcclxuICAgIGZvbnQtc2l6ZTogMzZweCAhaW1wb3J0YW50O1xyXG4gICAgZm9udC13ZWlnaHQ6IDQwMCAhaW1wb3J0YW50O1xyXG4gICAgbGluZS1oZWlnaHQ6IDEyMCUgIWltcG9ydGFudDtcclxufVxyXG5cclxuLmgxIHtcclxuICAgIGZvbnQtc2l6ZTogMzFweCAhaW1wb3J0YW50O1xyXG4gICAgZm9udC13ZWlnaHQ6IDQwMCAhaW1wb3J0YW50O1xyXG4gICAgbGluZS1oZWlnaHQ6IDEyMCUgIWltcG9ydGFudDtcclxufVxyXG5cclxuLmgyIHtcclxuICAgIGZvbnQtc2l6ZTogMjhweCAhaW1wb3J0YW50O1xyXG4gICAgZm9udC13ZWlnaHQ6IDQwMCAhaW1wb3J0YW50O1xyXG4gICAgbGluZS1oZWlnaHQ6IDEyMCUgIWltcG9ydGFudDtcclxufVxyXG5cclxuLmgzIHtcclxuICAgIGZvbnQtc2l6ZTogMjVweCAhaW1wb3J0YW50O1xyXG4gICAgZm9udC13ZWlnaHQ6IDQwMCAhaW1wb3J0YW50O1xyXG4gICAgbGluZS1oZWlnaHQ6IDEyMCUgIWltcG9ydGFudDtcclxufVxyXG5cclxuLmg0IHtcclxuICAgIGZvbnQtc2l6ZTogMjJweCAhaW1wb3J0YW50O1xyXG4gICAgZm9udC13ZWlnaHQ6IDQwMCAhaW1wb3J0YW50O1xyXG4gICAgbGluZS1oZWlnaHQ6IDEyMCUgIWltcG9ydGFudDtcclxufVxyXG5cclxuLmg1IHtcclxuICAgIGZvbnQtc2l6ZTogMTlweCAhaW1wb3J0YW50O1xyXG4gICAgZm9udC13ZWlnaHQ6IDQwMCAhaW1wb3J0YW50O1xyXG4gICAgbGluZS1oZWlnaHQ6IDEyMCUgIWltcG9ydGFudDtcclxufVxyXG5cclxuLmg2IHtcclxuICAgIGZvbnQtc2l6ZTogMTdweCAhaW1wb3J0YW50O1xyXG4gICAgZm9udC13ZWlnaHQ6IDQwMCAhaW1wb3J0YW50O1xyXG4gICAgbGluZS1oZWlnaHQ6IDEyMCUgIWltcG9ydGFudDtcclxufVxyXG5cclxuLmJvZHktbCB7XHJcbiAgICBmb250LXNpemU6IDE3cHggIWltcG9ydGFudDtcclxuICAgIGZvbnQtd2VpZ2h0OiA0MDAgIWltcG9ydGFudDtcclxuICAgIGxpbmUtaGVpZ2h0OiAxMjAlICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5ib2R5LW4ge1xyXG4gICAgZm9udC1zaXplOiAxNXB4ICFpbXBvcnRhbnQ7XHJcbiAgICBmb250LXdlaWdodDogNDAwICFpbXBvcnRhbnQ7XHJcbiAgICBsaW5lLWhlaWdodDogMTIwJSAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4uYm9keS1zbSB7XHJcbiAgICBmb250LXNpemU6IDEzcHggIWltcG9ydGFudDtcclxuICAgIGZvbnQtd2VpZ2h0OiA0MDAgIWltcG9ydGFudDtcclxuICAgIGxpbmUtaGVpZ2h0OiAxMjAlICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5ib2R5LXhzIHtcclxuICAgIGZvbnQtc2l6ZTogMTJweCAhaW1wb3J0YW50O1xyXG4gICAgZm9udC13ZWlnaHQ6IDQwMCAhaW1wb3J0YW50O1xyXG4gICAgbGluZS1oZWlnaHQ6IDEyMCUgIWltcG9ydGFudDtcclxufVxyXG5cclxuLnNlbWlib2xkIHtcclxuICAgICYuZGlzcGxheS14bCB7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IDYwMCAhaW1wb3J0YW50O1xyXG4gICAgfVxyXG4gICAgJi5kaXNwbGF5LW1kIHtcclxuICAgICAgICBmb250LXdlaWdodDogNjAwICFpbXBvcnRhbnQ7XHJcbiAgICB9XHJcbiAgICAmLmgxIHtcclxuICAgICAgICBmb250LXdlaWdodDogNjAwICFpbXBvcnRhbnQ7XHJcbiAgICB9XHJcbiAgICAmLmgyIHtcclxuICAgICAgICBmb250LXdlaWdodDogNjAwICFpbXBvcnRhbnQ7XHJcbiAgICB9XHJcbiAgICAmLmgzIHtcclxuICAgICAgICBmb250LXdlaWdodDogNjAwICFpbXBvcnRhbnQ7XHJcbiAgICB9XHJcbiAgICAmLmg0IHtcclxuICAgICAgICBmb250LXdlaWdodDogNjAwICFpbXBvcnRhbnQ7XHJcbiAgICB9XHJcbiAgICAmLmg1IHtcclxuICAgICAgICBmb250LXdlaWdodDogNjAwICFpbXBvcnRhbnQ7XHJcbiAgICB9XHJcbiAgICAmLmg2IHtcclxuICAgICAgICBmb250LXdlaWdodDogNjAwICFpbXBvcnRhbnQ7XHJcbiAgICB9XHJcbiAgICAmLmJvZHktbCB7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IDYwMCAhaW1wb3J0YW50O1xyXG4gICAgfVxyXG4gICAgJi5ib2R5LW4ge1xyXG4gICAgICAgIGZvbnQtd2VpZ2h0OiA2MDAgIWltcG9ydGFudDtcclxuICAgIH1cclxuICAgICYuYm9keS1zbSB7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IDYwMCAhaW1wb3J0YW50O1xyXG4gICAgfVxyXG4gICAgJi5ib2R5LXhzIHtcclxuICAgICAgICBmb250LXdlaWdodDogNjAwICFpbXBvcnRhbnQ7XHJcbiAgICB9XHJcbn1cclxuXHJcbi5ib2xkIHtcclxuICAgICYuZGlzcGxheS14bCB7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IDcwMCAhaW1wb3J0YW50O1xyXG4gICAgfVxyXG4gICAgJi5kaXNwbGF5LW1kIHtcclxuICAgICAgICBmb250LXdlaWdodDogNzAwICFpbXBvcnRhbnQ7XHJcbiAgICB9XHJcbiAgICAmLmgxIHtcclxuICAgICAgICBmb250LXdlaWdodDogNzAwICFpbXBvcnRhbnQ7XHJcbiAgICB9XHJcbiAgICAmLmgyIHtcclxuICAgICAgICBmb250LXdlaWdodDogNzAwICFpbXBvcnRhbnQ7XHJcbiAgICB9XHJcbiAgICAmLmgzIHtcclxuICAgICAgICBmb250LXdlaWdodDogNzAwICFpbXBvcnRhbnQ7XHJcbiAgICB9XHJcbiAgICAmLmg0IHtcclxuICAgICAgICBmb250LXdlaWdodDogNzAwICFpbXBvcnRhbnQ7XHJcbiAgICB9XHJcbiAgICAmLmg1IHtcclxuICAgICAgICBmb250LXdlaWdodDogNzAwICFpbXBvcnRhbnQ7XHJcbiAgICB9XHJcbiAgICAmLmg2IHtcclxuICAgICAgICBmb250LXdlaWdodDogNzAwICFpbXBvcnRhbnQ7XHJcbiAgICB9XHJcbiAgICAmLmJvZHktbCB7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IDcwMCAhaW1wb3J0YW50O1xyXG4gICAgfVxyXG4gICAgJi5ib2R5LW4ge1xyXG4gICAgICAgIGZvbnQtd2VpZ2h0OiA3MDAgIWltcG9ydGFudDtcclxuICAgIH1cclxuICAgICYuYm9keS1zbSB7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IDcwMCAhaW1wb3J0YW50O1xyXG4gICAgfVxyXG4gICAgJi5ib2R5LXhzIHtcclxuICAgICAgICBmb250LXdlaWdodDogNzAwICFpbXBvcnRhbnQ7XHJcbiAgICB9XHJcbn0iXX0= */";

/***/ }),

/***/ 91721:
/*!*************************************************************************************!*\
  !*** ./src/app/pages/edit-profile/saved-address/saved-address.page.scss?ngResource ***!
  \*************************************************************************************/
/***/ ((module) => {

module.exports = ":root {\n  --nc-color-nextgen-neutral-grey-50: red;\n  --nc-color-nextgen-white: yellow;\n  --nc-color-nextgen-blue: #0d152e;\n  --nc-color-nextgen-green: #00908d;\n  --nc-color-nextgen-black: #000000;\n  --nc-color-nextgen-grey-background: #c8d3da;\n  --nc-color-nextgen-grey: #92a2ac;\n  --nc-color-nextgen-stone-grey: #fafafa;\n  --nc-color-nextgen-error: #fc1055;\n  --nc-color-nextgen-neutral-grey: #414141;\n  --nc-color-nextgen-fibrant-green: #00bab6;\n  --nc-color-nextgen-warning: #ffd048;\n  --nc-color-nextgen-green-background: #e6f2f2;\n  --nc-color-nextgen-neutral-grey-400: #7a7a7a;\n  --nc-color-nextgen-neutral-grey-100: #eff3f5;\n  --nc-color-nextgen-status-error: #ba0c3f;\n  --nc-color-nextgen-status-error-background: #ffeff4;\n  --nc-color-nextgen-status-warning: #cba127;\n  --nc-color-nextgen-status-warning-background: #fff8e6;\n  --nc-color-nextgen-blue-100: #dfeff2;\n  --nc-color-nextgen-error-red-700: #f62459;\n  --nc-color-nextgen-blue-500: #006192;\n  --nc-color-nextgen-blue-400: #79cdec;\n  --nc-color-nextgen-red-500: #ff6592;\n  --nc-color-nextgen-secondary-blue-300: #13a0d3;\n  --lumi-white-color: #ffffff;\n  --lumi-primary-yellow-color: #fab600;\n}\n\n.ion-color-green {\n  --ion-color-base: var(--nc-color-nextgen-green);\n  --ion-color-base-rgb: var(--nc-color-nextgen-green);\n  --ion-color-contrast: var(--nc-color-nextgen-white);\n  --ion-color-contrast-rgb: var(--nc-color-nextgen-green);\n  --ion-color-shade: var(--nc-color-nextgen-green);\n  --ion-color-tint: var(--nc-color-nextgen-green);\n}\n\n.add-bank-container {\n  background: var(--nc-color-nextgen-neutral-grey-50);\n}\n\n.no-address-container {\n  background: var(--nc-color-nextgen-white);\n}\n\n.no-address-container .body-no-address {\n  text-align: center;\n  min-height: 100%;\n  display: grid;\n  align-content: center;\n  margin-top: -2rem;\n}\n\n.no-address-container .body-no-address .img-house {\n  padding-bottom: 3rem;\n}\n\n.no-address-container .body-no-address .header-no-address {\n  color: var(--nc-color-nextgen-neutral-grey);\n}\n\n.no-address-container .body-no-address .content-no-address {\n  padding-bottom: 3rem;\n  color: var(--nc-color-nextgen-neutral-grey-400);\n}\n\n.page-header {\n  width: 100%;\n  justify-content: space-between;\n  display: flex;\n  align-items: center;\n}\n\n.page-header .title-text {\n  width: 100%;\n  text-align: center;\n  color: var(--nc-color-nextgen-blue);\n}\n\n.bottom-saved-address {\n  text-align: center;\n}\n\n.bottom-saved-address .icon-btn-saved-address {\n  padding-right: 0.5rem;\n}\n\n.content {\n  background: var(--nc-color-nextgen-white);\n  box-shadow: 0px 1px 2px rgba(0, 0, 0, 0.1);\n  border-radius: 8px;\n  padding: 1rem;\n  margin-top: 0.5rem;\n  align-items: center;\n}\n\n.content .headerCard {\n  color: var(--nc-color-nextgen-black);\n}\n\n.content .bodyCard {\n  color: var(--nc-color-nextgen-neutral-grey-400);\n  padding-top: 0.25rem;\n}\n\n.content .action {\n  padding-top: 1rem;\n  text-align: right;\n}\n\n.content .action .btn-action {\n  background-color: transparent;\n  padding-left: 0.5rem;\n  color: var(--nc-color-nextgen-grey);\n}\n\n.content .action .icon-btn-action {\n  color: var(--nc-color-nextgen-grey);\n}\n\n.card-payment {\n  padding-top: 1rem;\n  padding-top: 1rem;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFxjb2xvci5zY3NzIiwic2F2ZWQtYWRkcmVzcy5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDQyx1Q0FBQTtFQUNBLGdDQUFBO0VBQ0EsZ0NBQUE7RUFDQSxpQ0FBQTtFQUNBLGlDQUFBO0VBQ0EsMkNBQUE7RUFDQSxnQ0FBQTtFQUNBLHNDQUFBO0VBQ0EsaUNBQUE7RUFDQSx3Q0FBQTtFQUNBLHlDQUFBO0VBQ0EsbUNBQUE7RUFDQSw0Q0FBQTtFQUNBLDRDQUFBO0VBQ0EsNENBQUE7RUFDQSx3Q0FBQTtFQUNBLG1EQUFBO0VBQ0EsMENBQUE7RUFDQSxxREFBQTtFQUNBLG9DQUFBO0VBQ0EseUNBQUE7RUFDQSxvQ0FBQTtFQUNBLG9DQUFBO0VBQ0EsbUNBQUE7RUFDQSw4Q0FBQTtFQUVBLDJCQUFBO0VBQ0Esb0NBQUE7QUNBRDs7QURnQ0E7RUFDQywrQ0FBQTtFQUNBLG1EQUFBO0VBQ0EsbURBQUE7RUFDQSx1REFBQTtFQUNBLGdEQUFBO0VBQ0EsK0NBQUE7QUM3QkQ7O0FBbkNBO0VBQ0ksbUREdUM0QjtBQ0RoQzs7QUFuQ0E7RUFDSSx5Q0R5QmtCO0FDYXRCOztBQXBDSTtFQUNJLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxhQUFBO0VBQ0EscUJBQUE7RUFDQSxpQkFBQTtBQXNDUjs7QUFwQ1E7RUFDSSxvQkFBQTtBQXNDWjs7QUFuQ1E7RUFDSSwyQ0RpQmlCO0FDb0I3Qjs7QUFsQ1E7RUFDSSxvQkFBQTtFQUNBLCtDRGlCcUI7QUNtQmpDOztBQS9CQTtFQUNJLFdBQUE7RUFDQSw4QkFBQTtFQUNBLGFBQUE7RUFDQSxtQkFBQTtBQWtDSjs7QUFoQ0k7RUFDSSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSxtQ0RWYTtBQzRDckI7O0FBOUJBO0VBQ0ksa0JBQUE7QUFpQ0o7O0FBL0JJO0VBQ0kscUJBQUE7QUFpQ1I7O0FBN0JBO0VBQ0kseUNEckJrQjtFQ3NCbEIsMENBQUE7RUFDQSxrQkFBQTtFQUNBLGFBQUE7RUFDQSxrQkFBQTtFQUNBLG1CQUFBO0FBZ0NKOztBQTlCSTtFQUNJLG9DRDVCYztBQzREdEI7O0FBN0JJO0VBQ0ksK0NEdEJ5QjtFQ3VCekIsb0JBQUE7QUErQlI7O0FBNUJJO0VBQ0ksaUJBQUE7RUFDQSxpQkFBQTtBQThCUjs7QUE1QlE7RUFDSSw2QkFBQTtFQUNBLG9CQUFBO0VBQ0EsbUNEekNTO0FDdUVyQjs7QUEzQlE7RUFDSSxtQ0Q3Q1M7QUMwRXJCOztBQXhCQTtFQUNJLGlCQUFBO0VBQ0EsaUJBQUE7QUEyQkoiLCJmaWxlIjoic2F2ZWQtYWRkcmVzcy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyI6cm9vdCB7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS01MDogcmVkO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi13aGl0ZTogeWVsbG93O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlOiAjMGQxNTJlO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbjogIzAwOTA4ZDtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tYmxhY2s6ICMwMDAwMDA7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWdyZXktYmFja2dyb3VuZDogI2M4ZDNkYTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tZ3JleTogIzkyYTJhYztcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc3RvbmUtZ3JleTogI2ZhZmFmYTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tZXJyb3I6ICNmYzEwNTU7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleTogIzQxNDE0MTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tZmlicmFudC1ncmVlbjogIzAwYmFiNjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4td2FybmluZzogI2ZmZDA0ODtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4tYmFja2dyb3VuZDogI2U2ZjJmMjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTQwMDogIzdhN2E3YTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTEwMDogI2VmZjNmNTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yOiAjYmEwYzNmO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtZXJyb3ItYmFja2dyb3VuZDogI2ZmZWZmNDtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLXdhcm5pbmc6ICNjYmExMjc7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy13YXJuaW5nLWJhY2tncm91bmQ6ICNmZmY4ZTY7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWJsdWUtMTAwOiAjZGZlZmYyO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1lcnJvci1yZWQtNzAwOiAjZjYyNDU5O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlLTUwMDogIzAwNjE5MjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZS00MDA6ICM3OWNkZWM7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXJlZC01MDA6ICNmZjY1OTI7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXNlY29uZGFyeS1ibHVlLTMwMDogIzEzYTBkMztcclxuXHJcblx0LS1sdW1pLXdoaXRlLWNvbG9yOiAjZmZmZmZmO1xyXG5cdC0tbHVtaS1wcmltYXJ5LXllbGxvdy1jb2xvcjogI2ZhYjYwMDtcclxufVxyXG4kY29sb3ItbmV4dGdlbi1ibHVlOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWJsdWUpO1xyXG4kY29sb3ItbmV4dGdlbi1ncmVlbjogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbik7XHJcbiRjb2xvci1uZXh0Z2VuLXdoaXRlOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXdoaXRlKTtcclxuJGNvbG9yLW5leHRnZW4tYmxhY2s6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tYmxhY2spO1xyXG4kY29sb3ItbmV4dGdlbi1ncmV5LWJhY2tncm91bmQ6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JleS1iYWNrZ3JvdW5kKTtcclxuJGNvbG9yLW5leHRnZW4tZ3JleTogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmV5KTtcclxuJGNvbG9yLW5leHRnZW4tc3RvbmUtZ3JleTogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1zdG9uZS1ncmV5KTtcclxuJGNvbG9yLW5leHRnZW4tZXJyb3I6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZXJyb3IpO1xyXG4kY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXk6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5KTtcclxuJGNvbG9yLW5leHRnZW4tZmlicmFudC1ncmVlbjogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1maWJyYW50LWdyZWVuKTtcclxuJGNvbG9yLW5leHRnZW4td2FybmluZzogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi13YXJuaW5nKTtcclxuJGNvbG9yLW5leHRnZW4tZ3JlZW4tYmFja2dyb3VuZDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbi1iYWNrZ3JvdW5kKTtcclxuJGNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTUwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS01MCk7XHJcbiRjb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS00MDA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTQwMCk7XHJcbiRjb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS0xMDA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTEwMCk7XHJcbiRjb2xvci1uZXh0Z2VuLXN0YXR1cy1lcnJvcjogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtZXJyb3IpO1xyXG4kY29sb3ItbmV4dGdlbi1zdGF0dXMtZXJyb3ItYmFja2dyb3VuZDogdmFyKFxyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtZXJyb3ItYmFja2dyb3VuZFxyXG4pO1xyXG4kY29sb3ItbmV4dGdlbi1zdGF0dXMtd2FybmluZzogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtd2FybmluZyk7XHJcbiRjb2xvci1uZXh0Z2VuLXN0YXR1cy13YXJuaW5nLWJhY2tncm91bmQ6IHZhcihcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLXdhcm5pbmctYmFja2dyb3VuZFxyXG4pO1xyXG4kY29sb3ItbmV4dGdlbi1ibHVlLTEwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlLTEwMCk7XHJcbiRjb2xvci1uZXh0Z2VuLWVycm9yLXJlZC03MDA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZXJyb3ItcmVkLTcwMCk7XHJcbiRjb2xvci1uZXh0Z2VuLWJsdWUtNTAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWJsdWUtNTAwKTtcclxuJGNvbG9yLW5leHRnZW4tYmx1ZS00MDA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZS00MDApO1xyXG4kY29sb3ItbmV4dGdlbi1yZWQtNTAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXJlZC01MDApO1xyXG4kY29sb3ItbmV4dGdlbi1zZWNvbmRhcnktYmx1ZS0zMDA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tc2Vjb25kYXJ5LWJsdWUtMzAwKTtcclxuXHJcbi5pb24tY29sb3ItZ3JlZW4ge1xyXG5cdC0taW9uLWNvbG9yLWJhc2U6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4pO1xyXG5cdC0taW9uLWNvbG9yLWJhc2UtcmdiOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuKTtcclxuXHQtLWlvbi1jb2xvci1jb250cmFzdDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi13aGl0ZSk7XHJcblx0LS1pb24tY29sb3ItY29udHJhc3QtcmdiOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuKTtcclxuXHQtLWlvbi1jb2xvci1zaGFkZTogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbik7XHJcblx0LS1pb24tY29sb3ItdGludDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbik7XHJcbn1cclxuIiwiQGltcG9ydCBcIi4uLy4uLy4uLy4uL2NvbG9yLnNjc3NcIjtcclxuXHJcbi5hZGQtYmFuay1jb250YWluZXIge1xyXG4gICAgYmFja2dyb3VuZDogJGNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTUwO1xyXG59XHJcblxyXG4ubm8tYWRkcmVzcy1jb250YWluZXIge1xyXG4gICAgYmFja2dyb3VuZDogJGNvbG9yLW5leHRnZW4td2hpdGU7XHJcblxyXG4gICAgLmJvZHktbm8tYWRkcmVzcyB7XHJcbiAgICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgICAgIG1pbi1oZWlnaHQ6IDEwMCU7XHJcbiAgICAgICAgZGlzcGxheTogZ3JpZDtcclxuICAgICAgICBhbGlnbi1jb250ZW50OiBjZW50ZXI7XHJcbiAgICAgICAgbWFyZ2luLXRvcDogLTJyZW07XHJcblxyXG4gICAgICAgIC5pbWctaG91c2Uge1xyXG4gICAgICAgICAgICBwYWRkaW5nLWJvdHRvbTogM3JlbTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC5oZWFkZXItbm8tYWRkcmVzcyB7XHJcbiAgICAgICAgICAgIGNvbG9yOiAkY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAuY29udGVudC1uby1hZGRyZXNzIHtcclxuICAgICAgICAgICAgcGFkZGluZy1ib3R0b206IDNyZW07XHJcbiAgICAgICAgICAgIGNvbG9yOiAkY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNDAwO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG5cclxuLnBhZ2UtaGVhZGVyIHtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcblxyXG4gICAgLnRpdGxlLXRleHQge1xyXG4gICAgICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgICAgICBjb2xvcjogJGNvbG9yLW5leHRnZW4tYmx1ZTtcclxuICAgIH1cclxufVxyXG5cclxuLmJvdHRvbS1zYXZlZC1hZGRyZXNzIHtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuXHJcbiAgICAuaWNvbi1idG4tc2F2ZWQtYWRkcmVzcyB7XHJcbiAgICAgICAgcGFkZGluZy1yaWdodDogMC41cmVtO1xyXG4gICAgfVxyXG59XHJcblxyXG4uY29udGVudCB7XHJcbiAgICBiYWNrZ3JvdW5kOiAkY29sb3ItbmV4dGdlbi13aGl0ZTtcclxuICAgIGJveC1zaGFkb3c6IDBweCAxcHggMnB4IHJnYmEoMCwgMCwgMCwgMC4xKTtcclxuICAgIGJvcmRlci1yYWRpdXM6IDhweDtcclxuICAgIHBhZGRpbmc6IDFyZW07XHJcbiAgICBtYXJnaW4tdG9wOiAwLjVyZW07XHJcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG5cclxuICAgIC5oZWFkZXJDYXJkIHtcclxuICAgICAgICBjb2xvcjogJGNvbG9yLW5leHRnZW4tYmxhY2s7XHJcbiAgICB9XHJcblxyXG4gICAgLmJvZHlDYXJkIHtcclxuICAgICAgICBjb2xvcjogJGNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTQwMDtcclxuICAgICAgICBwYWRkaW5nLXRvcDogMC4yNXJlbTtcclxuICAgIH1cclxuXHJcbiAgICAuYWN0aW9uIHtcclxuICAgICAgICBwYWRkaW5nLXRvcDogMXJlbTtcclxuICAgICAgICB0ZXh0LWFsaWduOiByaWdodDtcclxuXHJcbiAgICAgICAgLmJ0bi1hY3Rpb24ge1xyXG4gICAgICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiB0cmFuc3BhcmVudDtcclxuICAgICAgICAgICAgcGFkZGluZy1sZWZ0OiAwLjVyZW07XHJcbiAgICAgICAgICAgIGNvbG9yOiAkY29sb3ItbmV4dGdlbi1ncmV5O1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLmljb24tYnRuLWFjdGlvbiB7XHJcbiAgICAgICAgICAgIGNvbG9yOiAkY29sb3ItbmV4dGdlbi1ncmV5O1xyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG5cclxuLmNhcmQtcGF5bWVudCB7XHJcbiAgICBwYWRkaW5nLXRvcDogMXJlbTtcclxuICAgIHBhZGRpbmctdG9wOiAxcmVtO1xyXG59Il19 */";

/***/ }),

/***/ 26505:
/*!******************************************************************************************************!*\
  !*** ./src/app/pages/edit-profile/update-phone-number/update-phone-number.component.scss?ngResource ***!
  \******************************************************************************************************/
/***/ ((module) => {

module.exports = ":root {\n  --nc-color-nextgen-neutral-grey-50: red;\n  --nc-color-nextgen-white: yellow;\n  --nc-color-nextgen-blue: #0d152e;\n  --nc-color-nextgen-green: #00908d;\n  --nc-color-nextgen-black: #000000;\n  --nc-color-nextgen-grey-background: #c8d3da;\n  --nc-color-nextgen-grey: #92a2ac;\n  --nc-color-nextgen-stone-grey: #fafafa;\n  --nc-color-nextgen-error: #fc1055;\n  --nc-color-nextgen-neutral-grey: #414141;\n  --nc-color-nextgen-fibrant-green: #00bab6;\n  --nc-color-nextgen-warning: #ffd048;\n  --nc-color-nextgen-green-background: #e6f2f2;\n  --nc-color-nextgen-neutral-grey-400: #7a7a7a;\n  --nc-color-nextgen-neutral-grey-100: #eff3f5;\n  --nc-color-nextgen-status-error: #ba0c3f;\n  --nc-color-nextgen-status-error-background: #ffeff4;\n  --nc-color-nextgen-status-warning: #cba127;\n  --nc-color-nextgen-status-warning-background: #fff8e6;\n  --nc-color-nextgen-blue-100: #dfeff2;\n  --nc-color-nextgen-error-red-700: #f62459;\n  --nc-color-nextgen-blue-500: #006192;\n  --nc-color-nextgen-blue-400: #79cdec;\n  --nc-color-nextgen-red-500: #ff6592;\n  --nc-color-nextgen-secondary-blue-300: #13a0d3;\n  --lumi-white-color: #ffffff;\n  --lumi-primary-yellow-color: #fab600;\n}\n\n.ion-color-green {\n  --ion-color-base: var(--nc-color-nextgen-green);\n  --ion-color-base-rgb: var(--nc-color-nextgen-green);\n  --ion-color-contrast: var(--nc-color-nextgen-white);\n  --ion-color-contrast-rgb: var(--nc-color-nextgen-green);\n  --ion-color-shade: var(--nc-color-nextgen-green);\n  --ion-color-tint: var(--nc-color-nextgen-green);\n}\n\n.update-phone-number-container {\n  background-color: var(--nc-color-nextgen-neutral-grey-50);\n}\n\n.update-phone-number-content .update-phone-number-title {\n  color: var(--nc-color-nextgen-blue);\n  padding-top: 1rem;\n}\n\n.update-phone-number-content .update-phone-number-OTP {\n  color: var(--nc-color-nextgen-neutral-grey);\n  padding-top: 2rem;\n}\n\n.update-phone-number-content .add-phone-number {\n  padding-top: 2rem;\n}\n\n.update-phone-number-content .button-update {\n  padding-top: 3rem;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFxjb2xvci5zY3NzIiwidXBkYXRlLXBob25lLW51bWJlci5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNDLHVDQUFBO0VBQ0EsZ0NBQUE7RUFDQSxnQ0FBQTtFQUNBLGlDQUFBO0VBQ0EsaUNBQUE7RUFDQSwyQ0FBQTtFQUNBLGdDQUFBO0VBQ0Esc0NBQUE7RUFDQSxpQ0FBQTtFQUNBLHdDQUFBO0VBQ0EseUNBQUE7RUFDQSxtQ0FBQTtFQUNBLDRDQUFBO0VBQ0EsNENBQUE7RUFDQSw0Q0FBQTtFQUNBLHdDQUFBO0VBQ0EsbURBQUE7RUFDQSwwQ0FBQTtFQUNBLHFEQUFBO0VBQ0Esb0NBQUE7RUFDQSx5Q0FBQTtFQUNBLG9DQUFBO0VBQ0Esb0NBQUE7RUFDQSxtQ0FBQTtFQUNBLDhDQUFBO0VBRUEsMkJBQUE7RUFDQSxvQ0FBQTtBQ0FEOztBRGdDQTtFQUNDLCtDQUFBO0VBQ0EsbURBQUE7RUFDQSxtREFBQTtFQUNBLHVEQUFBO0VBQ0EsZ0RBQUE7RUFDQSwrQ0FBQTtBQzdCRDs7QUFwQ0E7RUFDSSx5RER3QzRCO0FDRGhDOztBQW5DSTtFQUNJLG1DRHVCYTtFQ3RCYixpQkFBQTtBQXNDUjs7QUFwQ0k7RUFDSSwyQ0QyQnFCO0VDMUJyQixpQkFBQTtBQXNDUjs7QUFwQ0k7RUFDSSxpQkFBQTtBQXNDUjs7QUFwQ0k7RUFDSSxpQkFBQTtBQXNDUiIsImZpbGUiOiJ1cGRhdGUtcGhvbmUtbnVtYmVyLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiOnJvb3Qge1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNTA6IHJlZDtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4td2hpdGU6IHllbGxvdztcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZTogIzBkMTUyZTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW46ICMwMDkwOGQ7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWJsYWNrOiAjMDAwMDAwO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ncmV5LWJhY2tncm91bmQ6ICNjOGQzZGE7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWdyZXk6ICM5MmEyYWM7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0b25lLWdyZXk6ICNmYWZhZmE7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWVycm9yOiAjZmMxMDU1O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXk6ICM0MTQxNDE7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWZpYnJhbnQtZ3JlZW46ICMwMGJhYjY7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXdhcm5pbmc6ICNmZmQwNDg7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuLWJhY2tncm91bmQ6ICNlNmYyZjI7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS00MDA6ICM3YTdhN2E7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS0xMDA6ICNlZmYzZjU7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy1lcnJvcjogI2JhMGMzZjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yLWJhY2tncm91bmQ6ICNmZmVmZjQ7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy13YXJuaW5nOiAjY2JhMTI3O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtd2FybmluZy1iYWNrZ3JvdW5kOiAjZmZmOGU2O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlLTEwMDogI2RmZWZmMjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tZXJyb3ItcmVkLTcwMDogI2Y2MjQ1OTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZS01MDA6ICMwMDYxOTI7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWJsdWUtNDAwOiAjNzljZGVjO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1yZWQtNTAwOiAjZmY2NTkyO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zZWNvbmRhcnktYmx1ZS0zMDA6ICMxM2EwZDM7XHJcblxyXG5cdC0tbHVtaS13aGl0ZS1jb2xvcjogI2ZmZmZmZjtcclxuXHQtLWx1bWktcHJpbWFyeS15ZWxsb3ctY29sb3I6ICNmYWI2MDA7XHJcbn1cclxuJGNvbG9yLW5leHRnZW4tYmx1ZTogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlKTtcclxuJGNvbG9yLW5leHRnZW4tZ3JlZW46IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4pO1xyXG4kY29sb3ItbmV4dGdlbi13aGl0ZTogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi13aGl0ZSk7XHJcbiRjb2xvci1uZXh0Z2VuLWJsYWNrOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWJsYWNrKTtcclxuJGNvbG9yLW5leHRnZW4tZ3JleS1iYWNrZ3JvdW5kOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZXktYmFja2dyb3VuZCk7XHJcbiRjb2xvci1uZXh0Z2VuLWdyZXk6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JleSk7XHJcbiRjb2xvci1uZXh0Z2VuLXN0b25lLWdyZXk6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tc3RvbmUtZ3JleSk7XHJcbiRjb2xvci1uZXh0Z2VuLWVycm9yOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWVycm9yKTtcclxuJGNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5OiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleSk7XHJcbiRjb2xvci1uZXh0Z2VuLWZpYnJhbnQtZ3JlZW46IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZmlicmFudC1ncmVlbik7XHJcbiRjb2xvci1uZXh0Z2VuLXdhcm5pbmc6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4td2FybmluZyk7XHJcbiRjb2xvci1uZXh0Z2VuLWdyZWVuLWJhY2tncm91bmQ6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4tYmFja2dyb3VuZCk7XHJcbiRjb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS01MDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNTApO1xyXG4kY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNDAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS00MDApO1xyXG4kY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktMTAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS0xMDApO1xyXG4kY29sb3ItbmV4dGdlbi1zdGF0dXMtZXJyb3I6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yKTtcclxuJGNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yLWJhY2tncm91bmQ6IHZhcihcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yLWJhY2tncm91bmRcclxuKTtcclxuJGNvbG9yLW5leHRnZW4tc3RhdHVzLXdhcm5pbmc6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLXdhcm5pbmcpO1xyXG4kY29sb3ItbmV4dGdlbi1zdGF0dXMtd2FybmluZy1iYWNrZ3JvdW5kOiB2YXIoXHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy13YXJuaW5nLWJhY2tncm91bmRcclxuKTtcclxuJGNvbG9yLW5leHRnZW4tYmx1ZS0xMDA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZS0xMDApO1xyXG4kY29sb3ItbmV4dGdlbi1lcnJvci1yZWQtNzAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWVycm9yLXJlZC03MDApO1xyXG4kY29sb3ItbmV4dGdlbi1ibHVlLTUwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlLTUwMCk7XHJcbiRjb2xvci1uZXh0Z2VuLWJsdWUtNDAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWJsdWUtNDAwKTtcclxuJGNvbG9yLW5leHRnZW4tcmVkLTUwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1yZWQtNTAwKTtcclxuJGNvbG9yLW5leHRnZW4tc2Vjb25kYXJ5LWJsdWUtMzAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXNlY29uZGFyeS1ibHVlLTMwMCk7XHJcblxyXG4uaW9uLWNvbG9yLWdyZWVuIHtcclxuXHQtLWlvbi1jb2xvci1iYXNlOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuKTtcclxuXHQtLWlvbi1jb2xvci1iYXNlLXJnYjogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbik7XHJcblx0LS1pb24tY29sb3ItY29udHJhc3Q6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4td2hpdGUpO1xyXG5cdC0taW9uLWNvbG9yLWNvbnRyYXN0LXJnYjogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbik7XHJcblx0LS1pb24tY29sb3Itc2hhZGU6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4pO1xyXG5cdC0taW9uLWNvbG9yLXRpbnQ6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4pO1xyXG59XHJcbiIsIkBpbXBvcnQgXCIuLi8uLi8uLi8uLi9jb2xvci5zY3NzXCI7XHJcbi51cGRhdGUtcGhvbmUtbnVtYmVyLWNvbnRhaW5lciB7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAkY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNTA7XHJcbn1cclxuXHJcbi51cGRhdGUtcGhvbmUtbnVtYmVyLWNvbnRlbnQge1xyXG4gICAgLnVwZGF0ZS1waG9uZS1udW1iZXItdGl0bGUge1xyXG4gICAgICAgIGNvbG9yOiAkY29sb3ItbmV4dGdlbi1ibHVlO1xyXG4gICAgICAgIHBhZGRpbmctdG9wOiAxcmVtO1xyXG4gICAgfVxyXG4gICAgLnVwZGF0ZS1waG9uZS1udW1iZXItT1RQIHtcclxuICAgICAgICBjb2xvcjogJGNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5O1xyXG4gICAgICAgIHBhZGRpbmctdG9wOiAycmVtO1xyXG4gICAgfVxyXG4gICAgLmFkZC1waG9uZS1udW1iZXIge1xyXG4gICAgICAgIHBhZGRpbmctdG9wOiAycmVtO1xyXG4gICAgfVxyXG4gICAgLmJ1dHRvbi11cGRhdGUge1xyXG4gICAgICAgIHBhZGRpbmctdG9wOiAzcmVtO1xyXG4gICAgfVxyXG59Il19 */";

/***/ }),

/***/ 61543:
/*!***************************************************************************************************************************!*\
  !*** ./projects/iris-ionic-library/src/lib/_utils/components/base-component/src/base-component.component.html?ngResource ***!
  \***************************************************************************************************************************/
/***/ ((module) => {

module.exports = "";

/***/ }),

/***/ 86016:
/*!**************************************************************************************************************!*\
  !*** ./projects/iris-ionic-library/src/lib/components/back-button/src/back-button.component.html?ngResource ***!
  \**************************************************************************************************************/
/***/ ((module) => {

module.exports = "<!-- Custom Html goes here -->\r\n<nc-button-action [config]=\"config\"></nc-button-action>\r\n";

/***/ }),

/***/ 39768:
/*!****************************************************************************************************************!*\
  !*** ./projects/iris-ionic-library/src/lib/components/header-label/src/header-label.component.html?ngResource ***!
  \****************************************************************************************************************/
/***/ ((module) => {

module.exports = "<nc-base-label [config]=\"config\"></nc-base-label>\r\n";

/***/ }),

/***/ 43618:
/*!********************************************************************************************************************************!*\
  !*** ./projects/iris-ionic-library/src/lib/components/navigation-hyperlink/src/navigation-hyperlink.component.html?ngResource ***!
  \********************************************************************************************************************************/
/***/ ((module) => {

module.exports = "<nc-hyperlink-action [config]=\"config\"></nc-hyperlink-action>\r\n";

/***/ }),

/***/ 77709:
/*!********************************************************************************************************************!*\
  !*** ./projects/iris-ionic-library/src/lib/components/password-input/src/password-input.component.html?ngResource ***!
  \********************************************************************************************************************/
/***/ ((module) => {

module.exports = "<nc-input-keyin\r\n\t[config]=\"config\"\r\n\t(fieldValueChange)=\"onChange($event)\"></nc-input-keyin>\r\n";

/***/ }),

/***/ 95517:
/*!******************************************************************************************************************!*\
  !*** ./projects/iris-ionic-library/src/lib/components/submit-button/src/submit-button.component.html?ngResource ***!
  \******************************************************************************************************************/
/***/ ((module) => {

module.exports = "<nc-button-action [config]=\"config\"></nc-button-action>\r\n";

/***/ }),

/***/ 71944:
/*!*************************************************************************************************************************!*\
  !*** ./projects/iris-ionic-library/src/lib/elements/src/base-element/action-base/action-base.component.html?ngResource ***!
  \*************************************************************************************************************************/
/***/ ((module) => {

module.exports = "<ng-content></ng-content>\r\n";

/***/ }),

/***/ 91770:
/*!*****************************************************************************************************************************************!*\
  !*** ./projects/iris-ionic-library/src/lib/elements/src/base-element/action-base/button-action/button-action.component.html?ngResource ***!
  \*****************************************************************************************************************************************/
/***/ ((module) => {

module.exports = "<nc-action-base [config]=\"config\">\r\n\t<ion-button [ngClass]=\"{'isDisabled':config.isDisabled}\" (click)=\"onElementClicked($event)\">\r\n\t\t<nc-icon-action *ngIf=\"config.icon\" [config]=\"config.icon\"></nc-icon-action>\r\n\t\t<nc-base-label [config]=\"{label:config.label}\"></nc-base-label>\r\n\t</ion-button>\r\n</nc-action-base>\r\n\r\n<!-- [ngClass]=\"{'isDisabled':config.isDisabled}\"\r\n[disabled]=\"config.isDisabled\" -->\r\n";

/***/ }),

/***/ 87624:
/*!***********************************************************************************************************************************************!*\
  !*** ./projects/iris-ionic-library/src/lib/elements/src/base-element/action-base/hyperlink-action/hyperlink-action.component.html?ngResource ***!
  \***********************************************************************************************************************************************/
/***/ ((module) => {

module.exports = "<nc-action-base [config]=\"config\">\r\n\t<nc-base-label\r\n\t\t(click)=\"onElementClicked($event)\"\r\n\t\t[config]=\"config\"></nc-base-label>\r\n</nc-action-base>\r\n";

/***/ }),

/***/ 32680:
/*!*************************************************************************************************************************************!*\
  !*** ./projects/iris-ionic-library/src/lib/elements/src/base-element/action-base/icon-action/icon-action.component.html?ngResource ***!
  \*************************************************************************************************************************************/
/***/ ((module) => {

module.exports = "<nc-action-base [config]=\"config\">\r\n\t<ion-icon\r\n\t\t[src]=\"config.iconName\"\r\n\t\t(click)=\"onElementClicked($event)\"></ion-icon>\r\n</nc-action-base>\r\n";

/***/ }),

/***/ 75068:
/*!***********************************************************************************************************************************!*\
  !*** ./projects/iris-ionic-library/src/lib/elements/src/base-element/action-base/img-action/img-action.component.html?ngResource ***!
  \***********************************************************************************************************************************/
/***/ ((module) => {

module.exports = "<nc-action-base [config]=\"config\">\r\n\t<ion-img [src]=\"config.src\"></ion-img>\r\n</nc-action-base>\r\n";

/***/ }),

/***/ 36501:
/*!**************************************************************************************************************!*\
  !*** ./projects/iris-ionic-library/src/lib/elements/src/base-element/base-element.component.html?ngResource ***!
  \**************************************************************************************************************/
/***/ ((module) => {

module.exports = "<div\r\n\tclass=\"base-element\"\r\n\t[attr.isDisabled]=\"config.isDisabled\">\r\n\t<ng-content></ng-content>\r\n</div>\r\n";

/***/ }),

/***/ 67552:
/*!*******************************************************************************************************************************!*\
  !*** ./projects/iris-ionic-library/src/lib/elements/src/base-element/formfield-base/formfield-base.component.html?ngResource ***!
  \*******************************************************************************************************************************/
/***/ ((module) => {

module.exports = "<!-- <nc-base-component [config]=\"config\"> -->\r\n<ion-item>\r\n\t<div class=\"field-main-wrapper\" [ngClass]=\"{'invalid':this.getControl().isInvalid()}\">\r\n\t\t<div class=\"field-label-wrapper .body-sm\">\r\n\t\t\t<nc-base-label class=\"field-label\" [config]=\"config\"></nc-base-label>\r\n\t\t\t<nc-base-label class=\"required-asterisk\" *ngIf=\"config.isRequired\" [config]=\"{label:'*'}\"></nc-base-label>\r\n\t\t\t<div class=\"progress-bar-wrapper\" [ngClass]=\"this.getControl().getControlHints().currentProgress\" *ngIf=\"this.getControl().getControlHints().totalNumber >0\">\r\n\t\t\t\t<nc-base-label *ngIf=\"config.hintProgressValue\" class=\"progress-title\" [config]=\"{label:config.hintProgressValue[this.getControl().getControlHints().currentProgress]}\"></nc-base-label>\r\n\t\t\t\t<ion-progress-bar [value]=\"this.getControl().getControlHints().validRatio==0?0.02:this.getControl().getControlHints().validRatio\"></ion-progress-bar>\r\n\t\t\t</div>\r\n\t\t</div>\r\n\t\t<div class=\"main-field\">\r\n\t\t\t<nc-icon-action *ngIf=\"config.icon\" class=\"field-icon\" [config]=\"config.icon\"></nc-icon-action>\r\n\t\t\t<ng-content></ng-content>\r\n\t\t\t<nc-icon-action *ngIf=\"config.secondaryIcon\" class=\"secondary-field-icon\" [config]=\"config.secondaryIcon\"></nc-icon-action>\r\n\t\t</div>\r\n\t\t<ng-container *ngIf=\"this.getControl().isInvalid()\">\r\n\t\t\t<div class=\"error-wrapper\">\r\n\t\t\t\t<ng-container *ngFor=\"let error of this.getControl().getControlErrors()\">\r\n\t\t\t\t\t<nc-base-label *ngIf=\"!error.isHint\" class=\"error-messages\" [config]=\"{label: error.message}\"></nc-base-label>\r\n\t\t\t\t</ng-container>\r\n\t\t\t</div>\r\n\t\t</ng-container>\r\n\r\n\t\t<ng-container *ngIf=\"this.getControl().getControlHints().totalNumber >0\">\r\n\t\t\t<div class=\"hint-wrapper\">\r\n\t\t\t\t<ng-container *ngFor=\"let hint of this.getControl().getControlHints().hints\">\r\n\t\t\t\t\t<div class=\"hint-set\">\r\n\t\t\t\t\t\t<nc-icon-action class=\"hint-icon\" [ngClass]=\"{'invalid':hint.error,'valid':!hint.error}\" [config]=\"getHintIcon(hint)\"></nc-icon-action>\r\n\t\t\t\t\t\t<nc-base-label class=\"hint-messages\" [config]=\"{label: hint.message}\"></nc-base-label>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t</ng-container>\r\n\t\t\t</div>\r\n\t\t</ng-container>\r\n\t</div>\r\n</ion-item>\r\n<!-- </nc-base-component> -->\r\n";

/***/ }),

/***/ 38947:
/*!********************************************************************************************************************************************************!*\
  !*** ./projects/iris-ionic-library/src/lib/elements/src/base-element/formfield-base/keyin-formfield/input-keyin/input-keyin.component.html?ngResource ***!
  \********************************************************************************************************************************************************/
/***/ ((module) => {

module.exports = "<nc-keyin-formfield [config]=\"config\" [formGroup]=\"config.formGroup\">\r\n\t<ion-input [placeholder]=\"config.placeholder | translate\" [type]=\"config.type\" [disabled]=\"config.isDisabled\" [formControlName]=\"config.id\"></ion-input>\r\n</nc-keyin-formfield>\r\n";

/***/ }),

/***/ 81351:
/*!************************************************************************************************************************************************!*\
  !*** ./projects/iris-ionic-library/src/lib/elements/src/base-element/formfield-base/keyin-formfield/keyin-formfield.component.html?ngResource ***!
  \************************************************************************************************************************************************/
/***/ ((module) => {

module.exports = "<nc-formfield-base [config]=\"config\">\r\n\t<ng-content></ng-content>\r\n</nc-formfield-base>\r\n";

/***/ }),

/***/ 74534:
/*!*****************************************************************************************************************************************************************!*\
  !*** ./projects/iris-ionic-library/src/lib/elements/src/base-element/formfield-base/select-formfield/dropdown-select/dropdown-select.component.html?ngResource ***!
  \*****************************************************************************************************************************************************************/
/***/ ((module) => {

module.exports = "<nc-select-formfield *ngIf=\"config\" [config]=\"config\" [formGroup]=\"config.formGroup\">\r\n\t<ion-select mode=\"ios\" [interfaceOptions]=\"interfaceOptions\" interface=\"action-sheet\" [placeholder]=\"config.placeholder\" [formControlName]=\"config.id\" [(ngModel)]=\"config.currentValue\">\r\n\t\t<ng-container *ngFor=\"let values of config.listOfValues\">\r\n\t\t\t<ion-select-option [value]=\"values.key\">{{ values.description | translate }}</ion-select-option>\r\n\t\t</ng-container>\r\n\t</ion-select>\r\n\t<!-- <mat-select *ngIf=\"config.listOfValues.length > 0\" [placeholder]=\"config.placeholder\" [formControlName]=\"config.id\" [(ngModel)]=\"config.currentValue\">\r\n\t\t<ng-container *ngFor=\"let values of config.listOfValues\">\r\n\t\t\t<mat-option [value]=\"values.key\">{{ values.description | translate }}</mat-option>\r\n\t\t</ng-container>\r\n\t</mat-select> -->\r\n\t<!-- <ion-skeleton-text [animated]=\"true\" *ngIf=\"!config.listOfValues || config.listOfValues.length === 0\"></ion-skeleton-text> -->\r\n</nc-select-formfield>\r\n";

/***/ }),

/***/ 40561:
/*!**************************************************************************************************************************************************!*\
  !*** ./projects/iris-ionic-library/src/lib/elements/src/base-element/formfield-base/select-formfield/select-formfield.component.html?ngResource ***!
  \**************************************************************************************************************************************************/
/***/ ((module) => {

module.exports = "<nc-formfield-base [config]=\"config\">\r\n\t<ng-content></ng-content>\r\n</nc-formfield-base>\r\n";

/***/ }),

/***/ 60993:
/*!**********************************************************************************************************!*\
  !*** ./projects/iris-ionic-library/src/lib/elements/src/base-label/base-label.component.html?ngResource ***!
  \**********************************************************************************************************/
/***/ ((module) => {

module.exports = "<ion-label [ngClass]=\"{'has-appended-label':config.appendLabel}\">\r\n\t{{ config.label | translate }}\r\n\t<ion-label class=\"appended-label\" *ngIf=\"config.appendLabel\">{{config.appendLabel | translate}}</ion-label>\r\n</ion-label>\r\n";

/***/ }),

/***/ 96069:
/*!***********************************************************************************************************!*\
  !*** ./projects/iris-ionic-library/src/lib/layouts/base-layout/src/base-layout.component.html?ngResource ***!
  \***********************************************************************************************************/
/***/ ((module) => {

module.exports = "<!-- Custom Html goes here -->\r\n<ion-header class=\"main-header\">\r\n\t<!-- <ion-toolbar>\r\n\t\t<ion-title> -->\r\n\t<div *ngIf=\"loadHeaderConfigs\" class=\"header-config\">\r\n\t\t<nc-back-button *ngIf=\"config.showBackButton\" class=\"nav-hyper-need-help\" [compConfig]=\"backButtonConfig\"></nc-back-button>\r\n\t\t<nc-navigation-hyperlink *ngIf=\"config.showHelpButton\" class=\"nav-hyper-need-help\" [compConfig]=\"navigateToNeedHelp\"></nc-navigation-hyperlink>\r\n\t</div>\r\n\t<ng-content select=\"[header]\"></ng-content>\r\n\t<!-- </ion-title>\r\n\t</ion-toolbar> -->\r\n</ion-header>\r\n<ion-content class=\"main-content\">\r\n\t<div class=\"main-content-wrapper\" [ngClass]=\"[compConfig.contentCSSClass?compConfig.contentCSSClass:'',compConfig.fitContentHeight?'fit-content':'']\">\r\n\t\t<ng-content select=\"[content]\"></ng-content>\r\n\t</div>\r\n</ion-content>\r\n<ion-footer class=\"main-footer\">\r\n\t<ng-content select=\"[footer]\"></ng-content>\r\n</ion-footer>\r\n";

/***/ }),

/***/ 96814:
/*!***********************************************************************************************************!*\
  !*** ./projects/iris-ionic-library/src/lib/layouts/form-layout/src/form-layout.component.html?ngResource ***!
  \***********************************************************************************************************/
/***/ ((module) => {

module.exports = "<!-- Custom Html goes here -->\r\n<nc-base-layout [compConfig]=\"config\">\r\n\t<ng-content header select=\"[header]\"></ng-content>\r\n\t<ng-container content>\r\n\t\t<ng-content></ng-content>\r\n\t\t<nc-submit-button *ngIf=\"config.displaySubmitInContent\" [compConfig]=\"config.submitOptions\"></nc-submit-button>\r\n\t</ng-container>\r\n\t<ng-container footer>\r\n\t\t<ng-content select=\"[footer]\"></ng-content>\r\n\t\t<nc-submit-button *ngIf=\"!config.displaySubmitInContent\" footer [compConfig]=\"config.submitOptions\"></nc-submit-button>\r\n\t</ng-container>\r\n</nc-base-layout>\r\n";

/***/ }),

/***/ 81239:
/*!************************************************************************************************!*\
  !*** ./src/app/pages/edit-profile/change-passwords/change-passwords.component.html?ngResource ***!
  \************************************************************************************************/
/***/ ((module) => {

module.exports = "<div class=\"change-password-container\">\r\n  <nextcare-layout>\r\n    <ng-template header>\r\n      <ion-row  class=\"change-password-header d-flex\">\r\n        <div>\r\n          <button class=\"btn btn-circle\" (click)=\"onBack()\">\r\n            <!-- <i class=\"icon-back body-l\"></i> -->\r\n            <ion-icon  class=\"icon-back body-l\" name=\"arrow-back-outline\"></ion-icon>\r\n          </button>\r\n        </div>\r\n        <div *ngIf=\"needHelp\">\r\n          <span class=\"need-help-text body-l bold\" (click)=\"redirectToNeedHelp()\">{{\r\n            'signup.needHelp' |\r\n            translate }}</span>\r\n        </div>\r\n      </ion-row>\r\n    </ng-template>\r\n    <ng-template body>\r\n      <div class=\"change-password-content\">\r\n        <div class=\"change-password-title h1 bold\">\r\n          {{'changePassword.title' | translate}}\r\n        </div>\r\n        <div>\r\n          <form class=\"form-change-password\" [formGroup]=\"changePasswordForm\">\r\n            <!-- start current password -->\r\n            <div>\r\n              <nextgen-control [type]=\"typeInputCurrentPassword\"\r\n                [label-property]=\"'changePassword.currentPassword' | translate\"\r\n                [placeholder]=\"'changePassword.currentPassword' | translate\" first-icon=\"uil uil-lock-alt\"\r\n                [second-icon]=\"secondIconCurrentPassword\" (secondIconHandler)=\"toggleCurrentPassword()\"\r\n                formControlName=\"currentPassword\">\r\n              </nextgen-control>\r\n            </div>\r\n            <!-- end current password -->\r\n            <div>\r\n              <nextgen-control [type]=\"typeInputPassword\" [label-property]=\"'changePassword.newPassword' | translate\"\r\n                [placeholder]=\"'signup.passwordPlaceholder' | translate\" first-icon=\"uil uil-lock-alt\"\r\n                [progress-status]=\"progressPassword\" [has-progress-bar]=\"isProgressBarPassword\"\r\n                [second-icon]=\"secondIconPassword\" [has-progress-change-pass]=\"isProgressBarChanegePassword\"\r\n                 (secondIconHandler)=\"togglePassword()\" formControlName=\"password\"\r\n                [native-template]=\"nativeTemplateValidation\" (click)=\"onFocusPasswordControl()\">\r\n              </nextgen-control>\r\n              <ng-template #nativeTemplateValidation>\r\n                <ul class=\"validation-summary-password\">\r\n                  <li *ngFor=\"let val of messageValidations\">\r\n                    <div class=\"check-place\">\r\n                      <i [ngClass]=\"verifyPass(val.key)?'uis uis-check-circle':''\" class=\"check-place mr-1\"></i>\r\n                    </div>\r\n                    <span class=\"text-validation\">{{val.text| translate}}</span>\r\n                  </li>\r\n                </ul>\r\n              </ng-template>\r\n            </div>\r\n            <div class=\"button-change-password\">\r\n              <button class=\"btn btn-large primary bold\" [disabled]=\"changePasswordForm.invalid\" appIonCLick\r\n                (debounceClick)=\"confirmChangePassword()\" [debounceTime]=\"700\">{{\r\n                'setNewPassWord.confirm' | translate }}</button>\r\n            </div>\r\n          </form>\r\n        </div>\r\n      </div>\r\n    </ng-template>\r\n  </nextcare-layout>\r\n</div>";

/***/ }),

/***/ 27048:
/*!***************************************************************************************************************!*\
  !*** ./src/app/pages/edit-profile/change-passwords/confirm-changed/confirm-changed.component.html?ngResource ***!
  \***************************************************************************************************************/
/***/ ((module) => {

module.exports = "<div class=\"confirm-change-page container\" >\r\n  <div class=\"lock-icon\">\r\n    <i class=\"uil uil-lock-alt\"></i>\r\n  </div>\r\n  <div class=\"confirm-change-title\">\r\n    <h1 class=\"h3 bold\">{{'confirmChangePassword.title' | translate}}</h1>\r\n  </div>\r\n  <div class=\"confirm-change-content\">\r\n    <p class=\"confirm-change-text body-sm\">{{'confirmChangePassword.content' | translate}}</p>\r\n    <div class=\"confirm-change-btn\">\r\n      <button class=\"confirm-btn btn btn-large primary body-l bold\" (click)=\"onClose(true)\">{{'button.ok' | translate}}</button>\r\n    </div>\r\n  </div>\r\n</div>";

/***/ }),

/***/ 68598:
/*!**********************************************************************!*\
  !*** ./src/app/pages/edit-profile/edit-profile.page.html?ngResource ***!
  \**********************************************************************/
/***/ ((module) => {

module.exports = "<div class=\"edit-profile-container\">\r\n    <nextcare-layout class=\"body\">\r\n        <ng-template header>\r\n            <ion-row>\r\n                <ion-col size=\"2\" class=\"d-flex\">\r\n                    <button (click)=\"onBack()\" class=\"btn btn-circle\">\r\n                        <!-- <i class=\"icon-back body-l\"></i> -->\r\n                        <ion-icon  class=\"icon-back body-l\" name=\"arrow-back-outline\"></ion-icon>\r\n                    </button>\r\n                </ion-col>\r\n                <ion-col size=\"8\" class=\"row\">\r\n                    <span class=\"title-text h6 bold\">{{'editProfile.title'|translate}}</span>\r\n                </ion-col>\r\n                <ion-col size=\"2\">\r\n                </ion-col>\r\n            </ion-row>\r\n        </ng-template>\r\n\r\n        <ng-template body>           \r\n            <div class=\"profile-image-box\">\r\n                <div class=\"avatar-container\">\r\n                    <div>\r\n                        <div *ngIf=\"userImage;else noUserImage\">\r\n                            <img class=\"icon-avatar profile-image\" src=\"data:image/png;base64,{{userImage}}\" />\r\n                        </div>\r\n                        <ng-template #noUserImage>\r\n                            <img class=\"icon-avatar profile-image\" src=\"../../../assets/images/user-profile.svg\" />\r\n                        </ng-template>\r\n                        <label (click)=\"openSelection()\" class=\"uil uil-camera camera-icon\">\r\n                        </label>\r\n                    </div>\r\n                </div>\r\n            </div>\r\n\r\n            <div class=\"details-box\">\r\n            <form [formGroup]=\"profileForm\">\r\n                <div class=\"border-box\"></div>\r\n                <div class=\"details-subtitle\" *ngIf=\"!showEditName\">\r\n                    <span class=\"details-text body-sm\">{{'editProfile.name'| translate}}</span><br>\r\n                    <span class=\"details-content body-n bold\">{{profile?.firstName}} {{profile?.lastName}}</span>\r\n                    <span  class=\"uil uil-edit right-icon\" (click)=\"getName()\"></span>                    \r\n                </div>\r\n                <div class=\"details-subtitle\" *ngIf=\"showEditName\">\r\n                <nextgen-control \r\n                    [type]=\"TYPE.INPUT\"\r\n                    [placeholder]=\"'editProfile.placeholderFirstName'|translate\"\r\n                    [label-property]=\"'editProfile.firstName'|translate\"\r\n                    formControlName=\"firstName\"\r\n                ></nextgen-control>  \r\n                <nextgen-control \r\n                    [type]=\"TYPE.INPUT\"\r\n                    [placeholder]=\"'editProfile.placeholderLastName'|translate\"\r\n                    [label-property]=\"'editProfile.lastName'|translate\"\r\n                    formControlName=\"lastName\"\r\n            ></nextgen-control> \r\n                </div>\r\n                <!-- <div class=\"details-subtitle\">\r\n                    <span class=\"details-text body-sm\">{{'editProfile.dob'| translate}}</span><br>\r\n                    <span class=\"details-content body-n bold\">{{userProfile?.dateOfBirth | date: 'd MMMM y':'':lang}}</span>\r\n                </div>\r\n                <div class=\"details-subtitle\">\r\n                    <span class=\"details-text body-sm\">{{'editProfile.gender'| translate}}</span><br>\r\n                    <span class=\"details-content body-n bold\">{{userProfile?.genderId > 0? 'Male' : 'Female'}}</span>\r\n                </div> -->\r\n                <div class=\"details-subtitle\" *ngIf=\"showEditName\">\r\n                    <button class=\"btn primary bold\" [disabled]=\"profileForm.invalid\" (click)=\"updateName()\">{{'editProfile.update'|translate}}</button>\r\n                </div>\r\n            </form>\r\n                <div class=\"border-box\"></div>\r\n\r\n                <div class=\"details-subtitle\">\r\n                    <div class=\"details-text body-sm\">{{'editProfile.email'| translate}}</div>\r\n                    <ng-container *ngFor=\"let email of userContact?.emails\">\r\n                        <div class=\"email-profile\">\r\n                            <div class=\"email-account\">\r\n                                <span class=\"details-content body-n bold\">{{email?.contactInfo}}</span>\r\n                                <div *ngIf=\"email.isVerified\" class=\"check-icon\">\r\n                                    <img src=\"../../../../assets/icon/icon-check.svg\" width=\"15px\" height=\"15px\">\r\n                                    <span class=\"verified\">{{'editProfile.verified' | translate}}</span>\r\n                                </div>\r\n                            </div>\r\n                            <span *ngIf=\"email.isVerified  || !email.contactID\" class=\"uil uil-edit right-icon\" (click)=\"onUpdateEmail(email)\"></span>\r\n                            <div *ngIf=\"!email.isVerified && canVerifyEmail && email.contactID\" class=\"verify-now body-n bold\" (click)=\"onVerifyEmail(email)\">{{'editProfile.verifyNow' | translate}}</div>\r\n                        </div>\r\n                    </ng-container>\r\n                </div>\r\n                <div class=\"details-subtitle\">\r\n                    <div class=\"details-text body-sm\">{{'editProfile.mobile'| translate}}</div>\r\n                    <ng-container *ngFor=\"let phone of userContact?.phones\">\r\n                        <div class=\"email-profile\">\r\n                            <div class=\"email-account\">\r\n                                <span class=\"details-content body-n bold\" *ngIf=\"phone?.contactInfo\">+{{phone?.contactInfo}}</span>\r\n                                <div *ngIf=\"phone.isVerified\" class=\"check-icon\">\r\n                                    <img src=\"../../../../assets/icon/icon-check.svg\" width=\"15px\" height=\"15px\">\r\n                                    <span class=\"verified\">{{'editProfile.verified' | translate}}</span>\r\n                                </div>\r\n                                <div *ngIf=\"!phone.isVerified && canVerifyPhone && phone.contactID\" class=\"verify-now body-n bold\" (click)=\"onVerifyPhone(phone)\">\r\n                                    {{'editProfile.verifyNow' | translate}} \r\n                                </div>\r\n                            </div>\r\n                            <!-- <span *ngIf=\"phone.isVerified || !phone.contactID\" class=\"uil uil-edit right-icon\" (click)=\"onUpdatePhone(phone)\"></span> -->\r\n                            <div class=\"update-phone-box\">\r\n                                <span class=\"uil uil-edit right-icon\" (click)=\"onUpdatePhone(phone)\"></span>\r\n                            </div>\r\n                            \r\n                        </div>\r\n                    </ng-container>\r\n\r\n                </div>\r\n            </div>\r\n\r\n            <div class=\"menu-item-container\">\r\n                <div class=\"border-box\"></div>\r\n                <div class=\"menu-item\" *ngFor=\"let item of actionList\" (click)=\"onNavigate(item)\"\r\n                    [hidden]=\"!item.isShow\">\r\n                    <i class=\"uil h4\" [ngClass]=\"'uil-'+ item.startClassIcon\"></i>\r\n                    <span class=\"title body-n bold ion-margin\">{{item.title | translate}}\r\n                    </span>\r\n                    <i *ngIf=\"item.isShowNavigationIcon\" class=\"uil uil-angle-right\"></i>\r\n                    <ion-toggle [ngModel]=\"isToggle\" class=\"uil h5\" *ngIf=\"item.key === 'biometricLogin'\"></ion-toggle>\r\n                    <!-- <i class=\"uil h4\" *ngIf=\"item.key !== 'biometricLogin'\" [ngClass]=\"'uil-'+ item.endClassIcon\"></i> -->\r\n                    <ion-icon name=\"chevron-forward-outline\" class=\"icon-ion uil h4\" *ngIf=\"item.key !== 'biometricLogin'\"></ion-icon>\r\n                </div>\r\n\r\n            </div>\r\n\r\n        </ng-template>\r\n    </nextcare-layout>\r\n</div>";

/***/ }),

/***/ 24215:
/*!*************************************************************************************!*\
  !*** ./src/app/pages/edit-profile/saved-address/saved-address.page.html?ngResource ***!
  \*************************************************************************************/
/***/ ((module) => {

module.exports = "<div class=\"add-bank-container\" *ngIf=\"listAddress?.length>0\">\r\n  <nextcare-layout>\r\n    <ng-template header>\r\n      <div class=\"page-header\">\r\n        <button class=\"btn btn-circle\" (click)=\"onBack()\">\r\n          <!-- <i class=\"icon-back body-l\"></i> -->\r\n          <ion-icon  class=\"icon-back body-l\" name=\"arrow-back-outline\"></ion-icon>\r\n        </button>\r\n        <span class=\"title-text h6 bold\">{{'savedAddress.savedAddress' | translate}}</span>\r\n      </div>\r\n    </ng-template>\r\n    <ng-template body>\r\n      <ion-row class=\"content\" *ngFor=\"let item of listAddress\">\r\n        <ion-col class=\"ion-align-self-center \">\r\n          <div class=\"body-l bold headerCard\">{{item.title}}</div>\r\n          <div class=\"body-sm bodyCard\">{{item.floor}}, {{item.building}}</div>\r\n          <div class=\"body-sm bodyCard\">{{item.street}}, {{item.city}}</div>\r\n          <div class=\"action\">\r\n            <button class=\"btn-action body-n bold\" (click)=\"onEdit(item)\">\r\n              <i class=\"uil uil-edit bold body-l icon-btn-action\"></i>\r\n              {{'savedAddress.edit' | translate }}</button>\r\n            <button class=\"btn-action body-n bold\" (click)=\"onDelete(item)\">\r\n              <i class=\"uil uil-trash bold body-l icon-btn-action\"></i>\r\n              {{'savedAddress.delete' | translate }}</button>\r\n          </div>\r\n        </ion-col>\r\n      </ion-row>\r\n    </ng-template>\r\n    <ng-template bottom>\r\n      <div class=\"bottom-saved-address\">\r\n        <button class=\"btn primary bold body-l btn-saved-address\" *ngIf=\"isShowButtonAddNewAddress\"\r\n          (click)=\"addAddress()\">\r\n          <i class=\"uil uil-plus bold body-l icon-btn-saved-address\"></i>\r\n          {{'savedAddress.addAddress' | translate }}</button>\r\n      </div>\r\n    </ng-template>\r\n  </nextcare-layout>\r\n</div>\r\n<div class=\"no-address-container\" *ngIf=\"!(listAddress?.length>0)\">\r\n  <nextcare-layout>\r\n    <ng-template header>\r\n      <div class=\"page-header\">\r\n        <button class=\"btn btn-circle\" (click)=\"onBack()\">\r\n          <!-- <i class=\"icon-back body-l\"></i> -->\r\n          <ion-icon  class=\"icon-back body-l\" name=\"arrow-back-outline\"></ion-icon>\r\n        </button>\r\n      </div>\r\n    </ng-template>\r\n    <ng-template body>\r\n      <div class=\"body-no-address\">\r\n        <div class=\"img-house\">\r\n          <img src=\"../../../assets/images/saved-address.svg\" />\r\n        </div>\r\n\r\n        <p class=\"h4 bold header-no-address\">{{'savedAddress.noAddressFound' | translate}}</p>\r\n\r\n        <p class=\"body-sm content-no-address\">{{'savedAddress.contentNoAddressFound' | translate}}</p>\r\n\r\n        <div class=\"bottom-saved-address\">\r\n          <button class=\"btn primary bold body-l btn-saved-address\" *ngIf=\"isShowButtonAddNewAddress\"\r\n            (click)=\"addAddress()\">\r\n            <i class=\"uil uil-plus bold body-l icon-btn-saved-address\"></i>\r\n            {{'savedAddress.addAddress' | translate }}</button>\r\n        </div>\r\n      </div>\r\n    </ng-template>\r\n\r\n  </nextcare-layout>\r\n</div>";

/***/ }),

/***/ 87139:
/*!******************************************************************************************************!*\
  !*** ./src/app/pages/edit-profile/update-phone-number/update-phone-number.component.html?ngResource ***!
  \******************************************************************************************************/
/***/ ((module) => {

module.exports = "<div class=\"update-phone-number-container\">\r\n    <nextcare-layout>\r\n        <ng-template header>\r\n            <button class=\"btn btn-circle d-block\" (click)=\"onBack()\">\r\n                <ion-icon  class=\"icon-back body-l\" name=\"arrow-back-outline\"></ion-icon>\r\n            </button>\r\n        </ng-template>\r\n\r\n        <ng-template body>\r\n            <div class=\"update-phone-number-content\">\r\n                <div class=\"update-phone-number-title h3 bold\">\r\n                    {{'updatePhone.title' | translate}}\r\n                </div>\r\n                <div class=\"update-phone-number-OTP body-n\">\r\n                    {{'updatePhone.sendOTP' | translate}}\r\n                </div>\r\n                <form [formGroup]=\"numberPhoneForm\">\r\n                    <div class=\"add-phone-number\">\r\n                        <nextgen-control [type]=\"TYPE.INPUTNUMBERPHONE\" (ngModelChange)=\"changeNumber($event)\" [titleCountry]=\"'updatePhone.chooseCountry' | translate\" [items]=\"countryList\"\r\n                            [label-property]=\"'updatePhone.contactNumber' | translate\" [placeholder]=\"'XXXXXX'|translate\" formControlName=\"phone\">\r\n                        </nextgen-control>\r\n                    </div>\r\n                </form>\r\n                <div class=\"button-update\">\r\n                    <button class=\"btn btn-large primary bold\" [disabled]=\"isDisable\"\r\n                        (click)=\"verifyHandler()\">{{'updatePhone.update'|translate}}</button>\r\n                </div>\r\n            </div>\r\n        </ng-template>\r\n    </nextcare-layout>\r\n</div>";

/***/ }),

/***/ 21780:
/*!********************************************************!*\
  !*** ./node_modules/@angular/cdk/fesm2015/stepper.mjs ***!
  \********************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CdkStep": () => (/* binding */ CdkStep),
/* harmony export */   "CdkStepHeader": () => (/* binding */ CdkStepHeader),
/* harmony export */   "CdkStepLabel": () => (/* binding */ CdkStepLabel),
/* harmony export */   "CdkStepper": () => (/* binding */ CdkStepper),
/* harmony export */   "CdkStepperModule": () => (/* binding */ CdkStepperModule),
/* harmony export */   "CdkStepperNext": () => (/* binding */ CdkStepperNext),
/* harmony export */   "CdkStepperPrevious": () => (/* binding */ CdkStepperPrevious),
/* harmony export */   "STEPPER_GLOBAL_OPTIONS": () => (/* binding */ STEPPER_GLOBAL_OPTIONS),
/* harmony export */   "STEP_STATE": () => (/* binding */ STEP_STATE),
/* harmony export */   "StepperSelectionEvent": () => (/* binding */ StepperSelectionEvent)
/* harmony export */ });
/* harmony import */ var _angular_cdk_a11y__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/cdk/a11y */ 84128);
/* harmony import */ var _angular_cdk_coercion__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/cdk/coercion */ 76484);
/* harmony import */ var _angular_cdk_keycodes__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/cdk/keycodes */ 75939);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_cdk_platform__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/cdk/platform */ 14390);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ 92218);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs */ 64139);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ 25722);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/operators */ 85921);
/* harmony import */ var _angular_cdk_bidi__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/cdk/bidi */ 51588);











/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

function CdkStep_ng_template_0_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵprojection"](0);
  }
}

const _c0 = ["*"];

class CdkStepHeader {
  constructor(_elementRef) {
    this._elementRef = _elementRef;
  }
  /** Focuses the step header. */


  focus() {
    this._elementRef.nativeElement.focus();
  }

}

CdkStepHeader.ɵfac = function CdkStepHeader_Factory(t) {
  return new (t || CdkStepHeader)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__.ElementRef));
};

CdkStepHeader.ɵdir = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineDirective"]({
  type: CdkStepHeader,
  selectors: [["", "cdkStepHeader", ""]],
  hostAttrs: ["role", "tab"]
});

(function () {
  (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](CdkStepHeader, [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Directive,
    args: [{
      selector: '[cdkStepHeader]',
      host: {
        'role': 'tab'
      }
    }]
  }], function () {
    return [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ElementRef
    }];
  }, null);
})();
/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */


class CdkStepLabel {
  constructor(
  /** @docs-private */
  template) {
    this.template = template;
  }

}

CdkStepLabel.ɵfac = function CdkStepLabel_Factory(t) {
  return new (t || CdkStepLabel)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__.TemplateRef));
};

CdkStepLabel.ɵdir = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineDirective"]({
  type: CdkStepLabel,
  selectors: [["", "cdkStepLabel", ""]]
});

(function () {
  (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](CdkStepLabel, [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Directive,
    args: [{
      selector: '[cdkStepLabel]'
    }]
  }], function () {
    return [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.TemplateRef
    }];
  }, null);
})();
/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/** Used to generate unique ID for each stepper component. */


let nextId = 0;
/** Change event emitted on selection changes. */

class StepperSelectionEvent {}
/** Enum to represent the different states of the steps. */


const STEP_STATE = {
  NUMBER: 'number',
  EDIT: 'edit',
  DONE: 'done',
  ERROR: 'error'
};
/** InjectionToken that can be used to specify the global stepper options. */

const STEPPER_GLOBAL_OPTIONS = new _angular_core__WEBPACK_IMPORTED_MODULE_0__.InjectionToken('STEPPER_GLOBAL_OPTIONS');

class CdkStep {
  constructor(_stepper, stepperOptions) {
    this._stepper = _stepper;
    /** Whether user has attempted to move away from the step. */

    this.interacted = false;
    /** Emits when the user has attempted to move away from the step. */

    this.interactedStream = new _angular_core__WEBPACK_IMPORTED_MODULE_0__.EventEmitter();
    this._editable = true;
    this._optional = false;
    this._completedOverride = null;
    this._customError = null;
    this._stepperOptions = stepperOptions ? stepperOptions : {};
    this._displayDefaultIndicatorType = this._stepperOptions.displayDefaultIndicatorType !== false;
  }
  /** Whether the user can return to this step once it has been marked as completed. */


  get editable() {
    return this._editable;
  }

  set editable(value) {
    this._editable = (0,_angular_cdk_coercion__WEBPACK_IMPORTED_MODULE_1__.coerceBooleanProperty)(value);
  }
  /** Whether the completion of step is optional. */


  get optional() {
    return this._optional;
  }

  set optional(value) {
    this._optional = (0,_angular_cdk_coercion__WEBPACK_IMPORTED_MODULE_1__.coerceBooleanProperty)(value);
  }
  /** Whether step is marked as completed. */


  get completed() {
    return this._completedOverride == null ? this._getDefaultCompleted() : this._completedOverride;
  }

  set completed(value) {
    this._completedOverride = (0,_angular_cdk_coercion__WEBPACK_IMPORTED_MODULE_1__.coerceBooleanProperty)(value);
  }

  _getDefaultCompleted() {
    return this.stepControl ? this.stepControl.valid && this.interacted : this.interacted;
  }
  /** Whether step has an error. */


  get hasError() {
    return this._customError == null ? this._getDefaultError() : this._customError;
  }

  set hasError(value) {
    this._customError = (0,_angular_cdk_coercion__WEBPACK_IMPORTED_MODULE_1__.coerceBooleanProperty)(value);
  }

  _getDefaultError() {
    return this.stepControl && this.stepControl.invalid && this.interacted;
  }
  /** Selects this step component. */


  select() {
    this._stepper.selected = this;
  }
  /** Resets the step to its initial state. Note that this includes resetting form data. */


  reset() {
    this.interacted = false;

    if (this._completedOverride != null) {
      this._completedOverride = false;
    }

    if (this._customError != null) {
      this._customError = false;
    }

    if (this.stepControl) {
      this.stepControl.reset();
    }
  }

  ngOnChanges() {
    // Since basically all inputs of the MatStep get proxied through the view down to the
    // underlying MatStepHeader, we have to make sure that change detection runs correctly.
    this._stepper._stateChanged();
  }

  _markAsInteracted() {
    if (!this.interacted) {
      this.interacted = true;
      this.interactedStream.emit(this);
    }
  }
  /** Determines whether the error state can be shown. */


  _showError() {
    var _a; // We want to show the error state either if the user opted into/out of it using the
    // global options, or if they've explicitly set it through the `hasError` input.


    return (_a = this._stepperOptions.showError) !== null && _a !== void 0 ? _a : this._customError != null;
  }

}

CdkStep.ɵfac = function CdkStep_Factory(t) {
  return new (t || CdkStep)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"]((0,_angular_core__WEBPACK_IMPORTED_MODULE_0__.forwardRef)(() => CdkStepper)), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](STEPPER_GLOBAL_OPTIONS, 8));
};

CdkStep.ɵcmp = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
  type: CdkStep,
  selectors: [["cdk-step"]],
  contentQueries: function CdkStep_ContentQueries(rf, ctx, dirIndex) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵcontentQuery"](dirIndex, CdkStepLabel, 5);
    }

    if (rf & 2) {
      let _t;

      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵloadQuery"]()) && (ctx.stepLabel = _t.first);
    }
  },
  viewQuery: function CdkStep_Query(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵviewQuery"](_angular_core__WEBPACK_IMPORTED_MODULE_0__.TemplateRef, 7);
    }

    if (rf & 2) {
      let _t;

      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵloadQuery"]()) && (ctx.content = _t.first);
    }
  },
  inputs: {
    stepControl: "stepControl",
    label: "label",
    errorMessage: "errorMessage",
    ariaLabel: ["aria-label", "ariaLabel"],
    ariaLabelledby: ["aria-labelledby", "ariaLabelledby"],
    state: "state",
    editable: "editable",
    optional: "optional",
    completed: "completed",
    hasError: "hasError"
  },
  outputs: {
    interactedStream: "interacted"
  },
  exportAs: ["cdkStep"],
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵNgOnChangesFeature"]],
  ngContentSelectors: _c0,
  decls: 1,
  vars: 0,
  template: function CdkStep_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵprojectionDef"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](0, CdkStep_ng_template_0_Template, 1, 0, "ng-template");
    }
  },
  encapsulation: 2,
  changeDetection: 0
});

(function () {
  (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](CdkStep, [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Component,
    args: [{
      selector: 'cdk-step',
      exportAs: 'cdkStep',
      template: '<ng-template><ng-content></ng-content></ng-template>',
      encapsulation: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ViewEncapsulation.None,
      changeDetection: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ChangeDetectionStrategy.OnPush
    }]
  }], function () {
    return [{
      type: CdkStepper,
      decorators: [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Inject,
        args: [(0,_angular_core__WEBPACK_IMPORTED_MODULE_0__.forwardRef)(() => CdkStepper)]
      }]
    }, {
      type: undefined,
      decorators: [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Optional
      }, {
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Inject,
        args: [STEPPER_GLOBAL_OPTIONS]
      }]
    }];
  }, {
    stepLabel: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ContentChild,
      args: [CdkStepLabel]
    }],
    content: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ViewChild,
      args: [_angular_core__WEBPACK_IMPORTED_MODULE_0__.TemplateRef, {
        static: true
      }]
    }],
    stepControl: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    interactedStream: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Output,
      args: ['interacted']
    }],
    label: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    errorMessage: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    ariaLabel: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input,
      args: ['aria-label']
    }],
    ariaLabelledby: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input,
      args: ['aria-labelledby']
    }],
    state: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    editable: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    optional: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    completed: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    hasError: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }]
  });
})();

class CdkStepper {
  constructor(_dir, _changeDetectorRef, _elementRef,
  /**
   * @deprecated No longer in use, to be removed.
   * @breaking-change 13.0.0
   */
  _document) {
    this._dir = _dir;
    this._changeDetectorRef = _changeDetectorRef;
    this._elementRef = _elementRef;
    /** Emits when the component is destroyed. */

    this._destroyed = new rxjs__WEBPACK_IMPORTED_MODULE_2__.Subject();
    /** Steps that belong to the current stepper, excluding ones from nested steppers. */

    this.steps = new _angular_core__WEBPACK_IMPORTED_MODULE_0__.QueryList();
    /** List of step headers sorted based on their DOM order. */

    this._sortedHeaders = new _angular_core__WEBPACK_IMPORTED_MODULE_0__.QueryList();
    this._linear = false;
    this._selectedIndex = 0;
    /** Event emitted when the selected step has changed. */

    this.selectionChange = new _angular_core__WEBPACK_IMPORTED_MODULE_0__.EventEmitter();
    /**
     * @deprecated To be turned into a private property. Use `orientation` instead.
     * @breaking-change 13.0.0
     */

    this._orientation = 'horizontal';
    this._groupId = nextId++;
  }
  /** Whether the validity of previous steps should be checked or not. */


  get linear() {
    return this._linear;
  }

  set linear(value) {
    this._linear = (0,_angular_cdk_coercion__WEBPACK_IMPORTED_MODULE_1__.coerceBooleanProperty)(value);
  }
  /** The index of the selected step. */


  get selectedIndex() {
    return this._selectedIndex;
  }

  set selectedIndex(index) {
    var _a;

    const newIndex = (0,_angular_cdk_coercion__WEBPACK_IMPORTED_MODULE_1__.coerceNumberProperty)(index);

    if (this.steps && this._steps) {
      // Ensure that the index can't be out of bounds.
      if (!this._isValidIndex(newIndex) && (typeof ngDevMode === 'undefined' || ngDevMode)) {
        throw Error('cdkStepper: Cannot assign out-of-bounds value to `selectedIndex`.');
      }

      (_a = this.selected) === null || _a === void 0 ? void 0 : _a._markAsInteracted();

      if (this._selectedIndex !== newIndex && !this._anyControlsInvalidOrPending(newIndex) && (newIndex >= this._selectedIndex || this.steps.toArray()[newIndex].editable)) {
        this._updateSelectedItemIndex(newIndex);
      }
    } else {
      this._selectedIndex = newIndex;
    }
  }
  /** The step that is selected. */


  get selected() {
    return this.steps ? this.steps.toArray()[this.selectedIndex] : undefined;
  }

  set selected(step) {
    this.selectedIndex = step && this.steps ? this.steps.toArray().indexOf(step) : -1;
  }
  /** Orientation of the stepper. */


  get orientation() {
    return this._orientation;
  }

  set orientation(value) {
    // This is a protected method so that `MatSteppter` can hook into it.
    this._orientation = value;

    if (this._keyManager) {
      this._keyManager.withVerticalOrientation(value === 'vertical');
    }
  }

  ngAfterContentInit() {
    this._steps.changes.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.startWith)(this._steps), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.takeUntil)(this._destroyed)).subscribe(steps => {
      this.steps.reset(steps.filter(step => step._stepper === this));
      this.steps.notifyOnChanges();
    });
  }

  ngAfterViewInit() {
    // If the step headers are defined outside of the `ngFor` that renders the steps, like in the
    // Material stepper, they won't appear in the `QueryList` in the same order as they're
    // rendered in the DOM which will lead to incorrect keyboard navigation. We need to sort
    // them manually to ensure that they're correct. Alternatively, we can change the Material
    // template to inline the headers in the `ngFor`, but that'll result in a lot of
    // code duplciation. See #23539.
    this._stepHeader.changes.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.startWith)(this._stepHeader), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.takeUntil)(this._destroyed)).subscribe(headers => {
      this._sortedHeaders.reset(headers.toArray().sort((a, b) => {
        const documentPosition = a._elementRef.nativeElement.compareDocumentPosition(b._elementRef.nativeElement); // `compareDocumentPosition` returns a bitmask so we have to use a bitwise operator.
        // https://developer.mozilla.org/en-US/docs/Web/API/Node/compareDocumentPosition
        // tslint:disable-next-line:no-bitwise


        return documentPosition & Node.DOCUMENT_POSITION_FOLLOWING ? -1 : 1;
      }));

      this._sortedHeaders.notifyOnChanges();
    }); // Note that while the step headers are content children by default, any components that
    // extend this one might have them as view children. We initialize the keyboard handling in
    // AfterViewInit so we're guaranteed for both view and content children to be defined.


    this._keyManager = new _angular_cdk_a11y__WEBPACK_IMPORTED_MODULE_5__.FocusKeyManager(this._sortedHeaders).withWrap().withHomeAndEnd().withVerticalOrientation(this._orientation === 'vertical');
    (this._dir ? this._dir.change : (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.of)()).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.startWith)(this._layoutDirection()), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.takeUntil)(this._destroyed)).subscribe(direction => this._keyManager.withHorizontalOrientation(direction));

    this._keyManager.updateActiveItem(this._selectedIndex); // No need to `takeUntil` here, because we're the ones destroying `steps`.


    this.steps.changes.subscribe(() => {
      if (!this.selected) {
        this._selectedIndex = Math.max(this._selectedIndex - 1, 0);
      }
    }); // The logic which asserts that the selected index is within bounds doesn't run before the
    // steps are initialized, because we don't how many steps there are yet so we may have an
    // invalid index on init. If that's the case, auto-correct to the default so we don't throw.

    if (!this._isValidIndex(this._selectedIndex)) {
      this._selectedIndex = 0;
    }
  }

  ngOnDestroy() {
    this.steps.destroy();

    this._sortedHeaders.destroy();

    this._destroyed.next();

    this._destroyed.complete();
  }
  /** Selects and focuses the next step in list. */


  next() {
    this.selectedIndex = Math.min(this._selectedIndex + 1, this.steps.length - 1);
  }
  /** Selects and focuses the previous step in list. */


  previous() {
    this.selectedIndex = Math.max(this._selectedIndex - 1, 0);
  }
  /** Resets the stepper to its initial state. Note that this includes clearing form data. */


  reset() {
    this._updateSelectedItemIndex(0);

    this.steps.forEach(step => step.reset());

    this._stateChanged();
  }
  /** Returns a unique id for each step label element. */


  _getStepLabelId(i) {
    return `cdk-step-label-${this._groupId}-${i}`;
  }
  /** Returns unique id for each step content element. */


  _getStepContentId(i) {
    return `cdk-step-content-${this._groupId}-${i}`;
  }
  /** Marks the component to be change detected. */


  _stateChanged() {
    this._changeDetectorRef.markForCheck();
  }
  /** Returns position state of the step with the given index. */


  _getAnimationDirection(index) {
    const position = index - this._selectedIndex;

    if (position < 0) {
      return this._layoutDirection() === 'rtl' ? 'next' : 'previous';
    } else if (position > 0) {
      return this._layoutDirection() === 'rtl' ? 'previous' : 'next';
    }

    return 'current';
  }
  /** Returns the type of icon to be displayed. */


  _getIndicatorType(index, state = STEP_STATE.NUMBER) {
    const step = this.steps.toArray()[index];

    const isCurrentStep = this._isCurrentStep(index);

    return step._displayDefaultIndicatorType ? this._getDefaultIndicatorLogic(step, isCurrentStep) : this._getGuidelineLogic(step, isCurrentStep, state);
  }

  _getDefaultIndicatorLogic(step, isCurrentStep) {
    if (step._showError() && step.hasError && !isCurrentStep) {
      return STEP_STATE.ERROR;
    } else if (!step.completed || isCurrentStep) {
      return STEP_STATE.NUMBER;
    } else {
      return step.editable ? STEP_STATE.EDIT : STEP_STATE.DONE;
    }
  }

  _getGuidelineLogic(step, isCurrentStep, state = STEP_STATE.NUMBER) {
    if (step._showError() && step.hasError && !isCurrentStep) {
      return STEP_STATE.ERROR;
    } else if (step.completed && !isCurrentStep) {
      return STEP_STATE.DONE;
    } else if (step.completed && isCurrentStep) {
      return state;
    } else if (step.editable && isCurrentStep) {
      return STEP_STATE.EDIT;
    } else {
      return state;
    }
  }

  _isCurrentStep(index) {
    return this._selectedIndex === index;
  }
  /** Returns the index of the currently-focused step header. */


  _getFocusIndex() {
    return this._keyManager ? this._keyManager.activeItemIndex : this._selectedIndex;
  }

  _updateSelectedItemIndex(newIndex) {
    const stepsArray = this.steps.toArray();
    this.selectionChange.emit({
      selectedIndex: newIndex,
      previouslySelectedIndex: this._selectedIndex,
      selectedStep: stepsArray[newIndex],
      previouslySelectedStep: stepsArray[this._selectedIndex]
    }); // If focus is inside the stepper, move it to the next header, otherwise it may become
    // lost when the active step content is hidden. We can't be more granular with the check
    // (e.g. checking whether focus is inside the active step), because we don't have a
    // reference to the elements that are rendering out the content.

    this._containsFocus() ? this._keyManager.setActiveItem(newIndex) : this._keyManager.updateActiveItem(newIndex);
    this._selectedIndex = newIndex;

    this._stateChanged();
  }

  _onKeydown(event) {
    const hasModifier = (0,_angular_cdk_keycodes__WEBPACK_IMPORTED_MODULE_7__.hasModifierKey)(event);
    const keyCode = event.keyCode;
    const manager = this._keyManager;

    if (manager.activeItemIndex != null && !hasModifier && (keyCode === _angular_cdk_keycodes__WEBPACK_IMPORTED_MODULE_7__.SPACE || keyCode === _angular_cdk_keycodes__WEBPACK_IMPORTED_MODULE_7__.ENTER)) {
      this.selectedIndex = manager.activeItemIndex;
      event.preventDefault();
    } else {
      manager.onKeydown(event);
    }
  }

  _anyControlsInvalidOrPending(index) {
    if (this._linear && index >= 0) {
      return this.steps.toArray().slice(0, index).some(step => {
        const control = step.stepControl;
        const isIncomplete = control ? control.invalid || control.pending || !step.interacted : !step.completed;
        return isIncomplete && !step.optional && !step._completedOverride;
      });
    }

    return false;
  }

  _layoutDirection() {
    return this._dir && this._dir.value === 'rtl' ? 'rtl' : 'ltr';
  }
  /** Checks whether the stepper contains the focused element. */


  _containsFocus() {
    const stepperElement = this._elementRef.nativeElement;

    const focusedElement = (0,_angular_cdk_platform__WEBPACK_IMPORTED_MODULE_8__._getFocusedElementPierceShadowDom)();

    return stepperElement === focusedElement || stepperElement.contains(focusedElement);
  }
  /** Checks whether the passed-in index is a valid step index. */


  _isValidIndex(index) {
    return index > -1 && (!this.steps || index < this.steps.length);
  }

}

CdkStepper.ɵfac = function CdkStepper_Factory(t) {
  return new (t || CdkStepper)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_cdk_bidi__WEBPACK_IMPORTED_MODULE_9__.Directionality, 8), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__.ChangeDetectorRef), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__.ElementRef), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_common__WEBPACK_IMPORTED_MODULE_10__.DOCUMENT));
};

CdkStepper.ɵdir = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineDirective"]({
  type: CdkStepper,
  selectors: [["", "cdkStepper", ""]],
  contentQueries: function CdkStepper_ContentQueries(rf, ctx, dirIndex) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵcontentQuery"](dirIndex, CdkStep, 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵcontentQuery"](dirIndex, CdkStepHeader, 5);
    }

    if (rf & 2) {
      let _t;

      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵloadQuery"]()) && (ctx._steps = _t);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵloadQuery"]()) && (ctx._stepHeader = _t);
    }
  },
  inputs: {
    linear: "linear",
    selectedIndex: "selectedIndex",
    selected: "selected",
    orientation: "orientation"
  },
  outputs: {
    selectionChange: "selectionChange"
  },
  exportAs: ["cdkStepper"]
});

(function () {
  (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](CdkStepper, [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Directive,
    args: [{
      selector: '[cdkStepper]',
      exportAs: 'cdkStepper'
    }]
  }], function () {
    return [{
      type: _angular_cdk_bidi__WEBPACK_IMPORTED_MODULE_9__.Directionality,
      decorators: [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Optional
      }]
    }, {
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ChangeDetectorRef
    }, {
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ElementRef
    }, {
      type: undefined,
      decorators: [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Inject,
        args: [_angular_common__WEBPACK_IMPORTED_MODULE_10__.DOCUMENT]
      }]
    }];
  }, {
    _steps: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ContentChildren,
      args: [CdkStep, {
        descendants: true
      }]
    }],
    _stepHeader: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ContentChildren,
      args: [CdkStepHeader, {
        descendants: true
      }]
    }],
    linear: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    selectedIndex: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    selected: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    selectionChange: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Output
    }],
    orientation: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }]
  });
})();
/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/** Button that moves to the next step in a stepper workflow. */


class CdkStepperNext {
  constructor(_stepper) {
    this._stepper = _stepper;
    /** Type of the next button. Defaults to "submit" if not specified. */

    this.type = 'submit';
  }

}

CdkStepperNext.ɵfac = function CdkStepperNext_Factory(t) {
  return new (t || CdkStepperNext)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](CdkStepper));
};

CdkStepperNext.ɵdir = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineDirective"]({
  type: CdkStepperNext,
  selectors: [["button", "cdkStepperNext", ""]],
  hostVars: 1,
  hostBindings: function CdkStepperNext_HostBindings(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function CdkStepperNext_click_HostBindingHandler() {
        return ctx._stepper.next();
      });
    }

    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵhostProperty"]("type", ctx.type);
    }
  },
  inputs: {
    type: "type"
  }
});

(function () {
  (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](CdkStepperNext, [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Directive,
    args: [{
      selector: 'button[cdkStepperNext]',
      host: {
        '[type]': 'type',
        '(click)': '_stepper.next()'
      }
    }]
  }], function () {
    return [{
      type: CdkStepper
    }];
  }, {
    type: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }]
  });
})();
/** Button that moves to the previous step in a stepper workflow. */


class CdkStepperPrevious {
  constructor(_stepper) {
    this._stepper = _stepper;
    /** Type of the previous button. Defaults to "button" if not specified. */

    this.type = 'button';
  }

}

CdkStepperPrevious.ɵfac = function CdkStepperPrevious_Factory(t) {
  return new (t || CdkStepperPrevious)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](CdkStepper));
};

CdkStepperPrevious.ɵdir = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineDirective"]({
  type: CdkStepperPrevious,
  selectors: [["button", "cdkStepperPrevious", ""]],
  hostVars: 1,
  hostBindings: function CdkStepperPrevious_HostBindings(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function CdkStepperPrevious_click_HostBindingHandler() {
        return ctx._stepper.previous();
      });
    }

    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵhostProperty"]("type", ctx.type);
    }
  },
  inputs: {
    type: "type"
  }
});

(function () {
  (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](CdkStepperPrevious, [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Directive,
    args: [{
      selector: 'button[cdkStepperPrevious]',
      host: {
        '[type]': 'type',
        '(click)': '_stepper.previous()'
      }
    }]
  }], function () {
    return [{
      type: CdkStepper
    }];
  }, {
    type: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }]
  });
})();
/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */


class CdkStepperModule {}

CdkStepperModule.ɵfac = function CdkStepperModule_Factory(t) {
  return new (t || CdkStepperModule)();
};

CdkStepperModule.ɵmod = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineNgModule"]({
  type: CdkStepperModule,
  declarations: [CdkStep, CdkStepper, CdkStepHeader, CdkStepLabel, CdkStepperNext, CdkStepperPrevious],
  imports: [_angular_cdk_bidi__WEBPACK_IMPORTED_MODULE_9__.BidiModule],
  exports: [CdkStep, CdkStepper, CdkStepHeader, CdkStepLabel, CdkStepperNext, CdkStepperPrevious]
});
CdkStepperModule.ɵinj = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjector"]({
  imports: [[_angular_cdk_bidi__WEBPACK_IMPORTED_MODULE_9__.BidiModule]]
});

(function () {
  (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](CdkStepperModule, [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.NgModule,
    args: [{
      imports: [_angular_cdk_bidi__WEBPACK_IMPORTED_MODULE_9__.BidiModule],
      exports: [CdkStep, CdkStepper, CdkStepHeader, CdkStepLabel, CdkStepperNext, CdkStepperPrevious],
      declarations: [CdkStep, CdkStepper, CdkStepHeader, CdkStepLabel, CdkStepperNext, CdkStepperPrevious]
    }]
  }], null, null);
})();
/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/**
 * Generated bundle index. Do not edit.
 */




/***/ }),

/***/ 65590:
/*!**********************************************************!*\
  !*** ./node_modules/@angular/material/fesm2015/icon.mjs ***!
  \**********************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ICON_REGISTRY_PROVIDER": () => (/* binding */ ICON_REGISTRY_PROVIDER),
/* harmony export */   "ICON_REGISTRY_PROVIDER_FACTORY": () => (/* binding */ ICON_REGISTRY_PROVIDER_FACTORY),
/* harmony export */   "MAT_ICON_LOCATION": () => (/* binding */ MAT_ICON_LOCATION),
/* harmony export */   "MAT_ICON_LOCATION_FACTORY": () => (/* binding */ MAT_ICON_LOCATION_FACTORY),
/* harmony export */   "MatIcon": () => (/* binding */ MatIcon),
/* harmony export */   "MatIconModule": () => (/* binding */ MatIconModule),
/* harmony export */   "MatIconRegistry": () => (/* binding */ MatIconRegistry),
/* harmony export */   "getMatIconFailedToSanitizeLiteralError": () => (/* binding */ getMatIconFailedToSanitizeLiteralError),
/* harmony export */   "getMatIconFailedToSanitizeUrlError": () => (/* binding */ getMatIconFailedToSanitizeUrlError),
/* harmony export */   "getMatIconNameNotFoundError": () => (/* binding */ getMatIconNameNotFoundError),
/* harmony export */   "getMatIconNoHttpProviderError": () => (/* binding */ getMatIconNoHttpProviderError)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_material_core__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/material/core */ 88133);
/* harmony import */ var _angular_cdk_coercion__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/cdk/coercion */ 76484);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ 64139);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ 66587);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs */ 54350);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! rxjs */ 32425);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs/operators */ 83663);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ 86942);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs/operators */ 47418);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs/operators */ 44661);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs/operators */ 24514);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! rxjs/operators */ 83910);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/common/http */ 28784);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/platform-browser */ 50318);











/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/**
 * The Trusted Types policy, or null if Trusted Types are not
 * enabled/supported, or undefined if the policy has not been created yet.
 */

const _c0 = ["*"];
let policy;
/**
 * Returns the Trusted Types policy, or null if Trusted Types are not
 * enabled/supported. The first call to this function will create the policy.
 */

function getPolicy() {
  if (policy === undefined) {
    policy = null;

    if (typeof window !== 'undefined') {
      const ttWindow = window;

      if (ttWindow.trustedTypes !== undefined) {
        policy = ttWindow.trustedTypes.createPolicy('angular#components', {
          createHTML: s => s
        });
      }
    }
  }

  return policy;
}
/**
 * Unsafely promote a string to a TrustedHTML, falling back to strings when
 * Trusted Types are not available.
 * @security This is a security-sensitive function; any use of this function
 * must go through security review. In particular, it must be assured that the
 * provided string will never cause an XSS vulnerability if used in a context
 * that will be interpreted as HTML by a browser, e.g. when assigning to
 * element.innerHTML.
 */


function trustedHTMLFromString(html) {
  var _a;

  return ((_a = getPolicy()) === null || _a === void 0 ? void 0 : _a.createHTML(html)) || html;
}
/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/**
 * Returns an exception to be thrown in the case when attempting to
 * load an icon with a name that cannot be found.
 * @docs-private
 */


function getMatIconNameNotFoundError(iconName) {
  return Error(`Unable to find icon with the name "${iconName}"`);
}
/**
 * Returns an exception to be thrown when the consumer attempts to use
 * `<mat-icon>` without including @angular/common/http.
 * @docs-private
 */


function getMatIconNoHttpProviderError() {
  return Error('Could not find HttpClient provider for use with Angular Material icons. ' + 'Please include the HttpClientModule from @angular/common/http in your ' + 'app imports.');
}
/**
 * Returns an exception to be thrown when a URL couldn't be sanitized.
 * @param url URL that was attempted to be sanitized.
 * @docs-private
 */


function getMatIconFailedToSanitizeUrlError(url) {
  return Error(`The URL provided to MatIconRegistry was not trusted as a resource URL ` + `via Angular's DomSanitizer. Attempted URL was "${url}".`);
}
/**
 * Returns an exception to be thrown when a HTML string couldn't be sanitized.
 * @param literal HTML that was attempted to be sanitized.
 * @docs-private
 */


function getMatIconFailedToSanitizeLiteralError(literal) {
  return Error(`The literal provided to MatIconRegistry was not trusted as safe HTML by ` + `Angular's DomSanitizer. Attempted literal was "${literal}".`);
}
/**
 * Configuration for an icon, including the URL and possibly the cached SVG element.
 * @docs-private
 */


class SvgIconConfig {
  constructor(url, svgText, options) {
    this.url = url;
    this.svgText = svgText;
    this.options = options;
  }

}
/**
 * Service to register and display icons used by the `<mat-icon>` component.
 * - Registers icon URLs by namespace and name.
 * - Registers icon set URLs by namespace.
 * - Registers aliases for CSS classes, for use with icon fonts.
 * - Loads icons from URLs and extracts individual icons from icon sets.
 */


class MatIconRegistry {
  constructor(_httpClient, _sanitizer, document, _errorHandler) {
    this._httpClient = _httpClient;
    this._sanitizer = _sanitizer;
    this._errorHandler = _errorHandler;
    /**
     * URLs and cached SVG elements for individual icons. Keys are of the format "[namespace]:[icon]".
     */

    this._svgIconConfigs = new Map();
    /**
     * SvgIconConfig objects and cached SVG elements for icon sets, keyed by namespace.
     * Multiple icon sets can be registered under the same namespace.
     */

    this._iconSetConfigs = new Map();
    /** Cache for icons loaded by direct URLs. */

    this._cachedIconsByUrl = new Map();
    /** In-progress icon fetches. Used to coalesce multiple requests to the same URL. */

    this._inProgressUrlFetches = new Map();
    /** Map from font identifiers to their CSS class names. Used for icon fonts. */

    this._fontCssClassesByAlias = new Map();
    /** Registered icon resolver functions. */

    this._resolvers = [];
    /**
     * The CSS class to apply when an `<mat-icon>` component has no icon name, url, or font specified.
     * The default 'material-icons' value assumes that the material icon font has been loaded as
     * described at http://google.github.io/material-design-icons/#icon-font-for-the-web
     */

    this._defaultFontSetClass = 'material-icons';
    this._document = document;
  }
  /**
   * Registers an icon by URL in the default namespace.
   * @param iconName Name under which the icon should be registered.
   * @param url
   */


  addSvgIcon(iconName, url, options) {
    return this.addSvgIconInNamespace('', iconName, url, options);
  }
  /**
   * Registers an icon using an HTML string in the default namespace.
   * @param iconName Name under which the icon should be registered.
   * @param literal SVG source of the icon.
   */


  addSvgIconLiteral(iconName, literal, options) {
    return this.addSvgIconLiteralInNamespace('', iconName, literal, options);
  }
  /**
   * Registers an icon by URL in the specified namespace.
   * @param namespace Namespace in which the icon should be registered.
   * @param iconName Name under which the icon should be registered.
   * @param url
   */


  addSvgIconInNamespace(namespace, iconName, url, options) {
    return this._addSvgIconConfig(namespace, iconName, new SvgIconConfig(url, null, options));
  }
  /**
   * Registers an icon resolver function with the registry. The function will be invoked with the
   * name and namespace of an icon when the registry tries to resolve the URL from which to fetch
   * the icon. The resolver is expected to return a `SafeResourceUrl` that points to the icon,
   * an object with the icon URL and icon options, or `null` if the icon is not supported. Resolvers
   * will be invoked in the order in which they have been registered.
   * @param resolver Resolver function to be registered.
   */


  addSvgIconResolver(resolver) {
    this._resolvers.push(resolver);

    return this;
  }
  /**
   * Registers an icon using an HTML string in the specified namespace.
   * @param namespace Namespace in which the icon should be registered.
   * @param iconName Name under which the icon should be registered.
   * @param literal SVG source of the icon.
   */


  addSvgIconLiteralInNamespace(namespace, iconName, literal, options) {
    const cleanLiteral = this._sanitizer.sanitize(_angular_core__WEBPACK_IMPORTED_MODULE_0__.SecurityContext.HTML, literal); // TODO: add an ngDevMode check


    if (!cleanLiteral) {
      throw getMatIconFailedToSanitizeLiteralError(literal);
    } // Security: The literal is passed in as SafeHtml, and is thus trusted.


    const trustedLiteral = trustedHTMLFromString(cleanLiteral);
    return this._addSvgIconConfig(namespace, iconName, new SvgIconConfig('', trustedLiteral, options));
  }
  /**
   * Registers an icon set by URL in the default namespace.
   * @param url
   */


  addSvgIconSet(url, options) {
    return this.addSvgIconSetInNamespace('', url, options);
  }
  /**
   * Registers an icon set using an HTML string in the default namespace.
   * @param literal SVG source of the icon set.
   */


  addSvgIconSetLiteral(literal, options) {
    return this.addSvgIconSetLiteralInNamespace('', literal, options);
  }
  /**
   * Registers an icon set by URL in the specified namespace.
   * @param namespace Namespace in which to register the icon set.
   * @param url
   */


  addSvgIconSetInNamespace(namespace, url, options) {
    return this._addSvgIconSetConfig(namespace, new SvgIconConfig(url, null, options));
  }
  /**
   * Registers an icon set using an HTML string in the specified namespace.
   * @param namespace Namespace in which to register the icon set.
   * @param literal SVG source of the icon set.
   */


  addSvgIconSetLiteralInNamespace(namespace, literal, options) {
    const cleanLiteral = this._sanitizer.sanitize(_angular_core__WEBPACK_IMPORTED_MODULE_0__.SecurityContext.HTML, literal);

    if (!cleanLiteral) {
      throw getMatIconFailedToSanitizeLiteralError(literal);
    } // Security: The literal is passed in as SafeHtml, and is thus trusted.


    const trustedLiteral = trustedHTMLFromString(cleanLiteral);
    return this._addSvgIconSetConfig(namespace, new SvgIconConfig('', trustedLiteral, options));
  }
  /**
   * Defines an alias for a CSS class name to be used for icon fonts. Creating an matIcon
   * component with the alias as the fontSet input will cause the class name to be applied
   * to the `<mat-icon>` element.
   *
   * @param alias Alias for the font.
   * @param className Class name override to be used instead of the alias.
   */


  registerFontClassAlias(alias, className = alias) {
    this._fontCssClassesByAlias.set(alias, className);

    return this;
  }
  /**
   * Returns the CSS class name associated with the alias by a previous call to
   * registerFontClassAlias. If no CSS class has been associated, returns the alias unmodified.
   */


  classNameForFontAlias(alias) {
    return this._fontCssClassesByAlias.get(alias) || alias;
  }
  /**
   * Sets the CSS class name to be used for icon fonts when an `<mat-icon>` component does not
   * have a fontSet input value, and is not loading an icon by name or URL.
   *
   * @param className
   */


  setDefaultFontSetClass(className) {
    this._defaultFontSetClass = className;
    return this;
  }
  /**
   * Returns the CSS class name to be used for icon fonts when an `<mat-icon>` component does not
   * have a fontSet input value, and is not loading an icon by name or URL.
   */


  getDefaultFontSetClass() {
    return this._defaultFontSetClass;
  }
  /**
   * Returns an Observable that produces the icon (as an `<svg>` DOM element) from the given URL.
   * The response from the URL may be cached so this will not always cause an HTTP request, but
   * the produced element will always be a new copy of the originally fetched icon. (That is,
   * it will not contain any modifications made to elements previously returned).
   *
   * @param safeUrl URL from which to fetch the SVG icon.
   */


  getSvgIconFromUrl(safeUrl) {
    const url = this._sanitizer.sanitize(_angular_core__WEBPACK_IMPORTED_MODULE_0__.SecurityContext.RESOURCE_URL, safeUrl);

    if (!url) {
      throw getMatIconFailedToSanitizeUrlError(safeUrl);
    }

    const cachedIcon = this._cachedIconsByUrl.get(url);

    if (cachedIcon) {
      return (0,rxjs__WEBPACK_IMPORTED_MODULE_1__.of)(cloneSvg(cachedIcon));
    }

    return this._loadSvgIconFromConfig(new SvgIconConfig(safeUrl, null)).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_2__.tap)(svg => this._cachedIconsByUrl.set(url, svg)), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.map)(svg => cloneSvg(svg)));
  }
  /**
   * Returns an Observable that produces the icon (as an `<svg>` DOM element) with the given name
   * and namespace. The icon must have been previously registered with addIcon or addIconSet;
   * if not, the Observable will throw an error.
   *
   * @param name Name of the icon to be retrieved.
   * @param namespace Namespace in which to look for the icon.
   */


  getNamedSvgIcon(name, namespace = '') {
    const key = iconKey(namespace, name);

    let config = this._svgIconConfigs.get(key); // Return (copy of) cached icon if possible.


    if (config) {
      return this._getSvgFromConfig(config);
    } // Otherwise try to resolve the config from one of the resolver functions.


    config = this._getIconConfigFromResolvers(namespace, name);

    if (config) {
      this._svgIconConfigs.set(key, config);

      return this._getSvgFromConfig(config);
    } // See if we have any icon sets registered for the namespace.


    const iconSetConfigs = this._iconSetConfigs.get(namespace);

    if (iconSetConfigs) {
      return this._getSvgFromIconSetConfigs(name, iconSetConfigs);
    }

    return (0,rxjs__WEBPACK_IMPORTED_MODULE_4__.throwError)(getMatIconNameNotFoundError(key));
  }

  ngOnDestroy() {
    this._resolvers = [];

    this._svgIconConfigs.clear();

    this._iconSetConfigs.clear();

    this._cachedIconsByUrl.clear();
  }
  /**
   * Returns the cached icon for a SvgIconConfig if available, or fetches it from its URL if not.
   */


  _getSvgFromConfig(config) {
    if (config.svgText) {
      // We already have the SVG element for this icon, return a copy.
      return (0,rxjs__WEBPACK_IMPORTED_MODULE_1__.of)(cloneSvg(this._svgElementFromConfig(config)));
    } else {
      // Fetch the icon from the config's URL, cache it, and return a copy.
      return this._loadSvgIconFromConfig(config).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.map)(svg => cloneSvg(svg)));
    }
  }
  /**
   * Attempts to find an icon with the specified name in any of the SVG icon sets.
   * First searches the available cached icons for a nested element with a matching name, and
   * if found copies the element to a new `<svg>` element. If not found, fetches all icon sets
   * that have not been cached, and searches again after all fetches are completed.
   * The returned Observable produces the SVG element if possible, and throws
   * an error if no icon with the specified name can be found.
   */


  _getSvgFromIconSetConfigs(name, iconSetConfigs) {
    // For all the icon set SVG elements we've fetched, see if any contain an icon with the
    // requested name.
    const namedIcon = this._extractIconWithNameFromAnySet(name, iconSetConfigs);

    if (namedIcon) {
      // We could cache namedIcon in _svgIconConfigs, but since we have to make a copy every
      // time anyway, there's probably not much advantage compared to just always extracting
      // it from the icon set.
      return (0,rxjs__WEBPACK_IMPORTED_MODULE_1__.of)(namedIcon);
    } // Not found in any cached icon sets. If there are icon sets with URLs that we haven't
    // fetched, fetch them now and look for iconName in the results.


    const iconSetFetchRequests = iconSetConfigs.filter(iconSetConfig => !iconSetConfig.svgText).map(iconSetConfig => {
      return this._loadSvgIconSetFromConfig(iconSetConfig).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.catchError)(err => {
        const url = this._sanitizer.sanitize(_angular_core__WEBPACK_IMPORTED_MODULE_0__.SecurityContext.RESOURCE_URL, iconSetConfig.url); // Swallow errors fetching individual URLs so the
        // combined Observable won't necessarily fail.


        const errorMessage = `Loading icon set URL: ${url} failed: ${err.message}`;

        this._errorHandler.handleError(new Error(errorMessage));

        return (0,rxjs__WEBPACK_IMPORTED_MODULE_1__.of)(null);
      }));
    }); // Fetch all the icon set URLs. When the requests complete, every IconSet should have a
    // cached SVG element (unless the request failed), and we can check again for the icon.

    return (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.forkJoin)(iconSetFetchRequests).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.map)(() => {
      const foundIcon = this._extractIconWithNameFromAnySet(name, iconSetConfigs); // TODO: add an ngDevMode check


      if (!foundIcon) {
        throw getMatIconNameNotFoundError(name);
      }

      return foundIcon;
    }));
  }
  /**
   * Searches the cached SVG elements for the given icon sets for a nested icon element whose "id"
   * tag matches the specified name. If found, copies the nested element to a new SVG element and
   * returns it. Returns null if no matching element is found.
   */


  _extractIconWithNameFromAnySet(iconName, iconSetConfigs) {
    // Iterate backwards, so icon sets added later have precedence.
    for (let i = iconSetConfigs.length - 1; i >= 0; i--) {
      const config = iconSetConfigs[i]; // Parsing the icon set's text into an SVG element can be expensive. We can avoid some of
      // the parsing by doing a quick check using `indexOf` to see if there's any chance for the
      // icon to be in the set. This won't be 100% accurate, but it should help us avoid at least
      // some of the parsing.

      if (config.svgText && config.svgText.toString().indexOf(iconName) > -1) {
        const svg = this._svgElementFromConfig(config);

        const foundIcon = this._extractSvgIconFromSet(svg, iconName, config.options);

        if (foundIcon) {
          return foundIcon;
        }
      }
    }

    return null;
  }
  /**
   * Loads the content of the icon URL specified in the SvgIconConfig and creates an SVG element
   * from it.
   */


  _loadSvgIconFromConfig(config) {
    return this._fetchIcon(config).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_2__.tap)(svgText => config.svgText = svgText), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.map)(() => this._svgElementFromConfig(config)));
  }
  /**
   * Loads the content of the icon set URL specified in the
   * SvgIconConfig and attaches it to the config.
   */


  _loadSvgIconSetFromConfig(config) {
    if (config.svgText) {
      return (0,rxjs__WEBPACK_IMPORTED_MODULE_1__.of)(null);
    }

    return this._fetchIcon(config).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_2__.tap)(svgText => config.svgText = svgText));
  }
  /**
   * Searches the cached element of the given SvgIconConfig for a nested icon element whose "id"
   * tag matches the specified name. If found, copies the nested element to a new SVG element and
   * returns it. Returns null if no matching element is found.
   */


  _extractSvgIconFromSet(iconSet, iconName, options) {
    // Use the `id="iconName"` syntax in order to escape special
    // characters in the ID (versus using the #iconName syntax).
    const iconSource = iconSet.querySelector(`[id="${iconName}"]`);

    if (!iconSource) {
      return null;
    } // Clone the element and remove the ID to prevent multiple elements from being added
    // to the page with the same ID.


    const iconElement = iconSource.cloneNode(true);
    iconElement.removeAttribute('id'); // If the icon node is itself an <svg> node, clone and return it directly. If not, set it as
    // the content of a new <svg> node.

    if (iconElement.nodeName.toLowerCase() === 'svg') {
      return this._setSvgAttributes(iconElement, options);
    } // If the node is a <symbol>, it won't be rendered so we have to convert it into <svg>. Note
    // that the same could be achieved by referring to it via <use href="#id">, however the <use>
    // tag is problematic on Firefox, because it needs to include the current page path.


    if (iconElement.nodeName.toLowerCase() === 'symbol') {
      return this._setSvgAttributes(this._toSvgElement(iconElement), options);
    } // createElement('SVG') doesn't work as expected; the DOM ends up with
    // the correct nodes, but the SVG content doesn't render. Instead we
    // have to create an empty SVG node using innerHTML and append its content.
    // Elements created using DOMParser.parseFromString have the same problem.
    // http://stackoverflow.com/questions/23003278/svg-innerhtml-in-firefox-can-not-display


    const svg = this._svgElementFromString(trustedHTMLFromString('<svg></svg>')); // Clone the node so we don't remove it from the parent icon set element.


    svg.appendChild(iconElement);
    return this._setSvgAttributes(svg, options);
  }
  /**
   * Creates a DOM element from the given SVG string.
   */


  _svgElementFromString(str) {
    const div = this._document.createElement('DIV');

    div.innerHTML = str;
    const svg = div.querySelector('svg'); // TODO: add an ngDevMode check

    if (!svg) {
      throw Error('<svg> tag not found');
    }

    return svg;
  }
  /**
   * Converts an element into an SVG node by cloning all of its children.
   */


  _toSvgElement(element) {
    const svg = this._svgElementFromString(trustedHTMLFromString('<svg></svg>'));

    const attributes = element.attributes; // Copy over all the attributes from the `symbol` to the new SVG, except the id.

    for (let i = 0; i < attributes.length; i++) {
      const {
        name,
        value
      } = attributes[i];

      if (name !== 'id') {
        svg.setAttribute(name, value);
      }
    }

    for (let i = 0; i < element.childNodes.length; i++) {
      if (element.childNodes[i].nodeType === this._document.ELEMENT_NODE) {
        svg.appendChild(element.childNodes[i].cloneNode(true));
      }
    }

    return svg;
  }
  /**
   * Sets the default attributes for an SVG element to be used as an icon.
   */


  _setSvgAttributes(svg, options) {
    svg.setAttribute('fit', '');
    svg.setAttribute('height', '100%');
    svg.setAttribute('width', '100%');
    svg.setAttribute('preserveAspectRatio', 'xMidYMid meet');
    svg.setAttribute('focusable', 'false'); // Disable IE11 default behavior to make SVGs focusable.

    if (options && options.viewBox) {
      svg.setAttribute('viewBox', options.viewBox);
    }

    return svg;
  }
  /**
   * Returns an Observable which produces the string contents of the given icon. Results may be
   * cached, so future calls with the same URL may not cause another HTTP request.
   */


  _fetchIcon(iconConfig) {
    var _a;

    const {
      url: safeUrl,
      options
    } = iconConfig;
    const withCredentials = (_a = options === null || options === void 0 ? void 0 : options.withCredentials) !== null && _a !== void 0 ? _a : false;

    if (!this._httpClient) {
      throw getMatIconNoHttpProviderError();
    } // TODO: add an ngDevMode check


    if (safeUrl == null) {
      throw Error(`Cannot fetch icon from URL "${safeUrl}".`);
    }

    const url = this._sanitizer.sanitize(_angular_core__WEBPACK_IMPORTED_MODULE_0__.SecurityContext.RESOURCE_URL, safeUrl); // TODO: add an ngDevMode check


    if (!url) {
      throw getMatIconFailedToSanitizeUrlError(safeUrl);
    } // Store in-progress fetches to avoid sending a duplicate request for a URL when there is
    // already a request in progress for that URL. It's necessary to call share() on the
    // Observable returned by http.get() so that multiple subscribers don't cause multiple XHRs.


    const inProgressFetch = this._inProgressUrlFetches.get(url);

    if (inProgressFetch) {
      return inProgressFetch;
    }

    const req = this._httpClient.get(url, {
      responseType: 'text',
      withCredentials
    }).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.map)(svg => {
      // Security: This SVG is fetched from a SafeResourceUrl, and is thus
      // trusted HTML.
      return trustedHTMLFromString(svg);
    }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_7__.finalize)(() => this._inProgressUrlFetches.delete(url)), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_8__.share)());

    this._inProgressUrlFetches.set(url, req);

    return req;
  }
  /**
   * Registers an icon config by name in the specified namespace.
   * @param namespace Namespace in which to register the icon config.
   * @param iconName Name under which to register the config.
   * @param config Config to be registered.
   */


  _addSvgIconConfig(namespace, iconName, config) {
    this._svgIconConfigs.set(iconKey(namespace, iconName), config);

    return this;
  }
  /**
   * Registers an icon set config in the specified namespace.
   * @param namespace Namespace in which to register the icon config.
   * @param config Config to be registered.
   */


  _addSvgIconSetConfig(namespace, config) {
    const configNamespace = this._iconSetConfigs.get(namespace);

    if (configNamespace) {
      configNamespace.push(config);
    } else {
      this._iconSetConfigs.set(namespace, [config]);
    }

    return this;
  }
  /** Parses a config's text into an SVG element. */


  _svgElementFromConfig(config) {
    if (!config.svgElement) {
      const svg = this._svgElementFromString(config.svgText);

      this._setSvgAttributes(svg, config.options);

      config.svgElement = svg;
    }

    return config.svgElement;
  }
  /** Tries to create an icon config through the registered resolver functions. */


  _getIconConfigFromResolvers(namespace, name) {
    for (let i = 0; i < this._resolvers.length; i++) {
      const result = this._resolvers[i](name, namespace);

      if (result) {
        return isSafeUrlWithOptions(result) ? new SvgIconConfig(result.url, null, result.options) : new SvgIconConfig(result, null);
      }
    }

    return undefined;
  }

}

MatIconRegistry.ɵfac = function MatIconRegistry_Factory(t) {
  return new (t || MatIconRegistry)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_9__.HttpClient, 8), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](_angular_platform_browser__WEBPACK_IMPORTED_MODULE_10__.DomSanitizer), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](_angular_common__WEBPACK_IMPORTED_MODULE_11__.DOCUMENT, 8), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__.ErrorHandler));
};

MatIconRegistry.ɵprov = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjectable"]({
  token: MatIconRegistry,
  factory: MatIconRegistry.ɵfac,
  providedIn: 'root'
});

(function () {
  (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](MatIconRegistry, [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Injectable,
    args: [{
      providedIn: 'root'
    }]
  }], function () {
    return [{
      type: _angular_common_http__WEBPACK_IMPORTED_MODULE_9__.HttpClient,
      decorators: [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Optional
      }]
    }, {
      type: _angular_platform_browser__WEBPACK_IMPORTED_MODULE_10__.DomSanitizer
    }, {
      type: undefined,
      decorators: [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Optional
      }, {
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Inject,
        args: [_angular_common__WEBPACK_IMPORTED_MODULE_11__.DOCUMENT]
      }]
    }, {
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ErrorHandler
    }];
  }, null);
})();
/** @docs-private */


function ICON_REGISTRY_PROVIDER_FACTORY(parentRegistry, httpClient, sanitizer, errorHandler, document) {
  return parentRegistry || new MatIconRegistry(httpClient, sanitizer, document, errorHandler);
}
/** @docs-private */


const ICON_REGISTRY_PROVIDER = {
  // If there is already an MatIconRegistry available, use that. Otherwise, provide a new one.
  provide: MatIconRegistry,
  deps: [[new _angular_core__WEBPACK_IMPORTED_MODULE_0__.Optional(), new _angular_core__WEBPACK_IMPORTED_MODULE_0__.SkipSelf(), MatIconRegistry], [new _angular_core__WEBPACK_IMPORTED_MODULE_0__.Optional(), _angular_common_http__WEBPACK_IMPORTED_MODULE_9__.HttpClient], _angular_platform_browser__WEBPACK_IMPORTED_MODULE_10__.DomSanitizer, _angular_core__WEBPACK_IMPORTED_MODULE_0__.ErrorHandler, [new _angular_core__WEBPACK_IMPORTED_MODULE_0__.Optional(), _angular_common__WEBPACK_IMPORTED_MODULE_11__.DOCUMENT]],
  useFactory: ICON_REGISTRY_PROVIDER_FACTORY
};
/** Clones an SVGElement while preserving type information. */

function cloneSvg(svg) {
  return svg.cloneNode(true);
}
/** Returns the cache key to use for an icon namespace and name. */


function iconKey(namespace, name) {
  return namespace + ':' + name;
}

function isSafeUrlWithOptions(value) {
  return !!(value.url && value.options);
}
/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */
// Boilerplate for applying mixins to MatIcon.

/** @docs-private */


const _MatIconBase = (0,_angular_material_core__WEBPACK_IMPORTED_MODULE_12__.mixinColor)(class {
  constructor(_elementRef) {
    this._elementRef = _elementRef;
  }

});
/**
 * Injection token used to provide the current location to `MatIcon`.
 * Used to handle server-side rendering and to stub out during unit tests.
 * @docs-private
 */


const MAT_ICON_LOCATION = new _angular_core__WEBPACK_IMPORTED_MODULE_0__.InjectionToken('mat-icon-location', {
  providedIn: 'root',
  factory: MAT_ICON_LOCATION_FACTORY
});
/** @docs-private */

function MAT_ICON_LOCATION_FACTORY() {
  const _document = (0,_angular_core__WEBPACK_IMPORTED_MODULE_0__.inject)(_angular_common__WEBPACK_IMPORTED_MODULE_11__.DOCUMENT);

  const _location = _document ? _document.location : null;

  return {
    // Note that this needs to be a function, rather than a property, because Angular
    // will only resolve it once, but we want the current path on each call.
    getPathname: () => _location ? _location.pathname + _location.search : ''
  };
}
/** SVG attributes that accept a FuncIRI (e.g. `url(<something>)`). */


const funcIriAttributes = ['clip-path', 'color-profile', 'src', 'cursor', 'fill', 'filter', 'marker', 'marker-start', 'marker-mid', 'marker-end', 'mask', 'stroke'];
/** Selector that can be used to find all elements that are using a `FuncIRI`. */

const funcIriAttributeSelector = funcIriAttributes.map(attr => `[${attr}]`).join(', ');
/** Regex that can be used to extract the id out of a FuncIRI. */

const funcIriPattern = /^url\(['"]?#(.*?)['"]?\)$/;
/**
 * Component to display an icon. It can be used in the following ways:
 *
 * - Specify the svgIcon input to load an SVG icon from a URL previously registered with the
 *   addSvgIcon, addSvgIconInNamespace, addSvgIconSet, or addSvgIconSetInNamespace methods of
 *   MatIconRegistry. If the svgIcon value contains a colon it is assumed to be in the format
 *   "[namespace]:[name]", if not the value will be the name of an icon in the default namespace.
 *   Examples:
 *     `<mat-icon svgIcon="left-arrow"></mat-icon>
 *     <mat-icon svgIcon="animals:cat"></mat-icon>`
 *
 * - Use a font ligature as an icon by putting the ligature text in the content of the `<mat-icon>`
 *   component. By default the Material icons font is used as described at
 *   http://google.github.io/material-design-icons/#icon-font-for-the-web. You can specify an
 *   alternate font by setting the fontSet input to either the CSS class to apply to use the
 *   desired font, or to an alias previously registered with MatIconRegistry.registerFontClassAlias.
 *   Examples:
 *     `<mat-icon>home</mat-icon>
 *     <mat-icon fontSet="myfont">sun</mat-icon>`
 *
 * - Specify a font glyph to be included via CSS rules by setting the fontSet input to specify the
 *   font, and the fontIcon input to specify the icon. Typically the fontIcon will specify a
 *   CSS class which causes the glyph to be displayed via a :before selector, as in
 *   https://fortawesome.github.io/Font-Awesome/examples/
 *   Example:
 *     `<mat-icon fontSet="fa" fontIcon="alarm"></mat-icon>`
 */

class MatIcon extends _MatIconBase {
  constructor(elementRef, _iconRegistry, ariaHidden, _location, _errorHandler) {
    super(elementRef);
    this._iconRegistry = _iconRegistry;
    this._location = _location;
    this._errorHandler = _errorHandler;
    this._inline = false;
    /** Subscription to the current in-progress SVG icon request. */

    this._currentIconFetch = rxjs__WEBPACK_IMPORTED_MODULE_13__.Subscription.EMPTY; // If the user has not explicitly set aria-hidden, mark the icon as hidden, as this is
    // the right thing to do for the majority of icon use-cases.

    if (!ariaHidden) {
      elementRef.nativeElement.setAttribute('aria-hidden', 'true');
    }
  }
  /**
   * Whether the icon should be inlined, automatically sizing the icon to match the font size of
   * the element the icon is contained in.
   */


  get inline() {
    return this._inline;
  }

  set inline(inline) {
    this._inline = (0,_angular_cdk_coercion__WEBPACK_IMPORTED_MODULE_14__.coerceBooleanProperty)(inline);
  }
  /** Name of the icon in the SVG icon set. */


  get svgIcon() {
    return this._svgIcon;
  }

  set svgIcon(value) {
    if (value !== this._svgIcon) {
      if (value) {
        this._updateSvgIcon(value);
      } else if (this._svgIcon) {
        this._clearSvgElement();
      }

      this._svgIcon = value;
    }
  }
  /** Font set that the icon is a part of. */


  get fontSet() {
    return this._fontSet;
  }

  set fontSet(value) {
    const newValue = this._cleanupFontValue(value);

    if (newValue !== this._fontSet) {
      this._fontSet = newValue;

      this._updateFontIconClasses();
    }
  }
  /** Name of an icon within a font set. */


  get fontIcon() {
    return this._fontIcon;
  }

  set fontIcon(value) {
    const newValue = this._cleanupFontValue(value);

    if (newValue !== this._fontIcon) {
      this._fontIcon = newValue;

      this._updateFontIconClasses();
    }
  }
  /**
   * Splits an svgIcon binding value into its icon set and icon name components.
   * Returns a 2-element array of [(icon set), (icon name)].
   * The separator for the two fields is ':'. If there is no separator, an empty
   * string is returned for the icon set and the entire value is returned for
   * the icon name. If the argument is falsy, returns an array of two empty strings.
   * Throws an error if the name contains two or more ':' separators.
   * Examples:
   *   `'social:cake' -> ['social', 'cake']
   *   'penguin' -> ['', 'penguin']
   *   null -> ['', '']
   *   'a:b:c' -> (throws Error)`
   */


  _splitIconName(iconName) {
    if (!iconName) {
      return ['', ''];
    }

    const parts = iconName.split(':');

    switch (parts.length) {
      case 1:
        return ['', parts[0]];
      // Use default namespace.

      case 2:
        return parts;

      default:
        throw Error(`Invalid icon name: "${iconName}"`);
      // TODO: add an ngDevMode check
    }
  }

  ngOnInit() {
    // Update font classes because ngOnChanges won't be called if none of the inputs are present,
    // e.g. <mat-icon>arrow</mat-icon> In this case we need to add a CSS class for the default font.
    this._updateFontIconClasses();
  }

  ngAfterViewChecked() {
    const cachedElements = this._elementsWithExternalReferences;

    if (cachedElements && cachedElements.size) {
      const newPath = this._location.getPathname(); // We need to check whether the URL has changed on each change detection since
      // the browser doesn't have an API that will let us react on link clicks and
      // we can't depend on the Angular router. The references need to be updated,
      // because while most browsers don't care whether the URL is correct after
      // the first render, Safari will break if the user navigates to a different
      // page and the SVG isn't re-rendered.


      if (newPath !== this._previousPath) {
        this._previousPath = newPath;

        this._prependPathToReferences(newPath);
      }
    }
  }

  ngOnDestroy() {
    this._currentIconFetch.unsubscribe();

    if (this._elementsWithExternalReferences) {
      this._elementsWithExternalReferences.clear();
    }
  }

  _usingFontIcon() {
    return !this.svgIcon;
  }

  _setSvgElement(svg) {
    this._clearSvgElement(); // Workaround for IE11 and Edge ignoring `style` tags inside dynamically-created SVGs.
    // See: https://developer.microsoft.com/en-us/microsoft-edge/platform/issues/10898469/
    // Do this before inserting the element into the DOM, in order to avoid a style recalculation.


    const styleTags = svg.querySelectorAll('style');

    for (let i = 0; i < styleTags.length; i++) {
      styleTags[i].textContent += ' ';
    } // Note: we do this fix here, rather than the icon registry, because the
    // references have to point to the URL at the time that the icon was created.


    const path = this._location.getPathname();

    this._previousPath = path;

    this._cacheChildrenWithExternalReferences(svg);

    this._prependPathToReferences(path);

    this._elementRef.nativeElement.appendChild(svg);
  }

  _clearSvgElement() {
    const layoutElement = this._elementRef.nativeElement;
    let childCount = layoutElement.childNodes.length;

    if (this._elementsWithExternalReferences) {
      this._elementsWithExternalReferences.clear();
    } // Remove existing non-element child nodes and SVGs, and add the new SVG element. Note that
    // we can't use innerHTML, because IE will throw if the element has a data binding.


    while (childCount--) {
      const child = layoutElement.childNodes[childCount]; // 1 corresponds to Node.ELEMENT_NODE. We remove all non-element nodes in order to get rid
      // of any loose text nodes, as well as any SVG elements in order to remove any old icons.

      if (child.nodeType !== 1 || child.nodeName.toLowerCase() === 'svg') {
        child.remove();
      }
    }
  }

  _updateFontIconClasses() {
    if (!this._usingFontIcon()) {
      return;
    }

    const elem = this._elementRef.nativeElement;
    const fontSetClass = this.fontSet ? this._iconRegistry.classNameForFontAlias(this.fontSet) : this._iconRegistry.getDefaultFontSetClass();

    if (fontSetClass != this._previousFontSetClass) {
      if (this._previousFontSetClass) {
        elem.classList.remove(this._previousFontSetClass);
      }

      if (fontSetClass) {
        elem.classList.add(fontSetClass);
      }

      this._previousFontSetClass = fontSetClass;
    }

    if (this.fontIcon != this._previousFontIconClass) {
      if (this._previousFontIconClass) {
        elem.classList.remove(this._previousFontIconClass);
      }

      if (this.fontIcon) {
        elem.classList.add(this.fontIcon);
      }

      this._previousFontIconClass = this.fontIcon;
    }
  }
  /**
   * Cleans up a value to be used as a fontIcon or fontSet.
   * Since the value ends up being assigned as a CSS class, we
   * have to trim the value and omit space-separated values.
   */


  _cleanupFontValue(value) {
    return typeof value === 'string' ? value.trim().split(' ')[0] : value;
  }
  /**
   * Prepends the current path to all elements that have an attribute pointing to a `FuncIRI`
   * reference. This is required because WebKit browsers require references to be prefixed with
   * the current path, if the page has a `base` tag.
   */


  _prependPathToReferences(path) {
    const elements = this._elementsWithExternalReferences;

    if (elements) {
      elements.forEach((attrs, element) => {
        attrs.forEach(attr => {
          element.setAttribute(attr.name, `url('${path}#${attr.value}')`);
        });
      });
    }
  }
  /**
   * Caches the children of an SVG element that have `url()`
   * references that we need to prefix with the current path.
   */


  _cacheChildrenWithExternalReferences(element) {
    const elementsWithFuncIri = element.querySelectorAll(funcIriAttributeSelector);
    const elements = this._elementsWithExternalReferences = this._elementsWithExternalReferences || new Map();

    for (let i = 0; i < elementsWithFuncIri.length; i++) {
      funcIriAttributes.forEach(attr => {
        const elementWithReference = elementsWithFuncIri[i];
        const value = elementWithReference.getAttribute(attr);
        const match = value ? value.match(funcIriPattern) : null;

        if (match) {
          let attributes = elements.get(elementWithReference);

          if (!attributes) {
            attributes = [];
            elements.set(elementWithReference, attributes);
          }

          attributes.push({
            name: attr,
            value: match[1]
          });
        }
      });
    }
  }
  /** Sets a new SVG icon with a particular name. */


  _updateSvgIcon(rawName) {
    this._svgNamespace = null;
    this._svgName = null;

    this._currentIconFetch.unsubscribe();

    if (rawName) {
      const [namespace, iconName] = this._splitIconName(rawName);

      if (namespace) {
        this._svgNamespace = namespace;
      }

      if (iconName) {
        this._svgName = iconName;
      }

      this._currentIconFetch = this._iconRegistry.getNamedSvgIcon(iconName, namespace).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_15__.take)(1)).subscribe(svg => this._setSvgElement(svg), err => {
        const errorMessage = `Error retrieving icon ${namespace}:${iconName}! ${err.message}`;

        this._errorHandler.handleError(new Error(errorMessage));
      });
    }
  }

}

MatIcon.ɵfac = function MatIcon_Factory(t) {
  return new (t || MatIcon)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__.ElementRef), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](MatIconRegistry), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinjectAttribute"]('aria-hidden'), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](MAT_ICON_LOCATION), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__.ErrorHandler));
};

MatIcon.ɵcmp = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
  type: MatIcon,
  selectors: [["mat-icon"]],
  hostAttrs: ["role", "img", 1, "mat-icon", "notranslate"],
  hostVars: 7,
  hostBindings: function MatIcon_HostBindings(rf, ctx) {
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵattribute"]("data-mat-icon-type", ctx._usingFontIcon() ? "font" : "svg")("data-mat-icon-name", ctx._svgName || ctx.fontIcon)("data-mat-icon-namespace", ctx._svgNamespace || ctx.fontSet);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassProp"]("mat-icon-inline", ctx.inline)("mat-icon-no-color", ctx.color !== "primary" && ctx.color !== "accent" && ctx.color !== "warn");
    }
  },
  inputs: {
    color: "color",
    inline: "inline",
    svgIcon: "svgIcon",
    fontSet: "fontSet",
    fontIcon: "fontIcon"
  },
  exportAs: ["matIcon"],
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵInheritDefinitionFeature"]],
  ngContentSelectors: _c0,
  decls: 1,
  vars: 0,
  template: function MatIcon_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵprojectionDef"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵprojection"](0);
    }
  },
  styles: [".mat-icon{-webkit-user-select:none;-moz-user-select:none;user-select:none;background-repeat:no-repeat;display:inline-block;fill:currentColor;height:24px;width:24px}.mat-icon.mat-icon-inline{font-size:inherit;height:inherit;line-height:inherit;width:inherit}[dir=rtl] .mat-icon-rtl-mirror{transform:scale(-1, 1)}.mat-form-field:not(.mat-form-field-appearance-legacy) .mat-form-field-prefix .mat-icon,.mat-form-field:not(.mat-form-field-appearance-legacy) .mat-form-field-suffix .mat-icon{display:block}.mat-form-field:not(.mat-form-field-appearance-legacy) .mat-form-field-prefix .mat-icon-button .mat-icon,.mat-form-field:not(.mat-form-field-appearance-legacy) .mat-form-field-suffix .mat-icon-button .mat-icon{margin:auto}\n"],
  encapsulation: 2,
  changeDetection: 0
});

(function () {
  (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](MatIcon, [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Component,
    args: [{
      template: '<ng-content></ng-content>',
      selector: 'mat-icon',
      exportAs: 'matIcon',
      inputs: ['color'],
      host: {
        'role': 'img',
        'class': 'mat-icon notranslate',
        '[attr.data-mat-icon-type]': '_usingFontIcon() ? "font" : "svg"',
        '[attr.data-mat-icon-name]': '_svgName || fontIcon',
        '[attr.data-mat-icon-namespace]': '_svgNamespace || fontSet',
        '[class.mat-icon-inline]': 'inline',
        '[class.mat-icon-no-color]': 'color !== "primary" && color !== "accent" && color !== "warn"'
      },
      encapsulation: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ViewEncapsulation.None,
      changeDetection: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ChangeDetectionStrategy.OnPush,
      styles: [".mat-icon{-webkit-user-select:none;-moz-user-select:none;user-select:none;background-repeat:no-repeat;display:inline-block;fill:currentColor;height:24px;width:24px}.mat-icon.mat-icon-inline{font-size:inherit;height:inherit;line-height:inherit;width:inherit}[dir=rtl] .mat-icon-rtl-mirror{transform:scale(-1, 1)}.mat-form-field:not(.mat-form-field-appearance-legacy) .mat-form-field-prefix .mat-icon,.mat-form-field:not(.mat-form-field-appearance-legacy) .mat-form-field-suffix .mat-icon{display:block}.mat-form-field:not(.mat-form-field-appearance-legacy) .mat-form-field-prefix .mat-icon-button .mat-icon,.mat-form-field:not(.mat-form-field-appearance-legacy) .mat-form-field-suffix .mat-icon-button .mat-icon{margin:auto}\n"]
    }]
  }], function () {
    return [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ElementRef
    }, {
      type: MatIconRegistry
    }, {
      type: undefined,
      decorators: [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Attribute,
        args: ['aria-hidden']
      }]
    }, {
      type: undefined,
      decorators: [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Inject,
        args: [MAT_ICON_LOCATION]
      }]
    }, {
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ErrorHandler
    }];
  }, {
    inline: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    svgIcon: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    fontSet: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    fontIcon: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }]
  });
})();
/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */


class MatIconModule {}

MatIconModule.ɵfac = function MatIconModule_Factory(t) {
  return new (t || MatIconModule)();
};

MatIconModule.ɵmod = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineNgModule"]({
  type: MatIconModule,
  declarations: [MatIcon],
  imports: [_angular_material_core__WEBPACK_IMPORTED_MODULE_12__.MatCommonModule],
  exports: [MatIcon, _angular_material_core__WEBPACK_IMPORTED_MODULE_12__.MatCommonModule]
});
MatIconModule.ɵinj = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjector"]({
  imports: [[_angular_material_core__WEBPACK_IMPORTED_MODULE_12__.MatCommonModule], _angular_material_core__WEBPACK_IMPORTED_MODULE_12__.MatCommonModule]
});

(function () {
  (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](MatIconModule, [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.NgModule,
    args: [{
      imports: [_angular_material_core__WEBPACK_IMPORTED_MODULE_12__.MatCommonModule],
      exports: [MatIcon, _angular_material_core__WEBPACK_IMPORTED_MODULE_12__.MatCommonModule],
      declarations: [MatIcon]
    }]
  }], null, null);
})();
/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/**
 * Generated bundle index. Do not edit.
 */




/***/ }),

/***/ 7650:
/*!*************************************************************!*\
  !*** ./node_modules/@angular/material/fesm2015/stepper.mjs ***!
  \*************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MAT_STEPPER_INTL_PROVIDER": () => (/* binding */ MAT_STEPPER_INTL_PROVIDER),
/* harmony export */   "MAT_STEPPER_INTL_PROVIDER_FACTORY": () => (/* binding */ MAT_STEPPER_INTL_PROVIDER_FACTORY),
/* harmony export */   "MatHorizontalStepper": () => (/* binding */ MatHorizontalStepper),
/* harmony export */   "MatStep": () => (/* binding */ MatStep),
/* harmony export */   "MatStepContent": () => (/* binding */ MatStepContent),
/* harmony export */   "MatStepHeader": () => (/* binding */ MatStepHeader),
/* harmony export */   "MatStepLabel": () => (/* binding */ MatStepLabel),
/* harmony export */   "MatStepper": () => (/* binding */ MatStepper),
/* harmony export */   "MatStepperIcon": () => (/* binding */ MatStepperIcon),
/* harmony export */   "MatStepperIntl": () => (/* binding */ MatStepperIntl),
/* harmony export */   "MatStepperModule": () => (/* binding */ MatStepperModule),
/* harmony export */   "MatStepperNext": () => (/* binding */ MatStepperNext),
/* harmony export */   "MatStepperPrevious": () => (/* binding */ MatStepperPrevious),
/* harmony export */   "MatVerticalStepper": () => (/* binding */ MatVerticalStepper),
/* harmony export */   "matStepperAnimations": () => (/* binding */ matStepperAnimations)
/* harmony export */ });
/* harmony import */ var _angular_cdk_portal__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/cdk/portal */ 24476);
/* harmony import */ var _angular_cdk_stepper__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/cdk/stepper */ 21780);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_material_button__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/material/button */ 87317);
/* harmony import */ var _angular_material_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/material/core */ 88133);
/* harmony import */ var _angular_material_icon__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/material/icon */ 65590);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ 92218);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs */ 32425);
/* harmony import */ var _angular_cdk_a11y__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/cdk/a11y */ 84128);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! rxjs/operators */ 59095);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! rxjs/operators */ 86942);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! rxjs/operators */ 25722);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! rxjs/operators */ 85921);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! rxjs/operators */ 53298);
/* harmony import */ var _angular_animations__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/animations */ 31631);
/* harmony import */ var _angular_cdk_bidi__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/cdk/bidi */ 51588);

















/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

function MatStepHeader_ng_container_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainer"](0, 8);
  }

  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngTemplateOutlet", ctx_r0.iconOverrides[ctx_r0.state])("ngTemplateOutletContext", ctx_r0._getIconContext());
  }
}

function MatStepHeader_ng_container_4_span_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "span", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](ctx_r6._getDefaultTextForState(ctx_r6.state));
  }
}

function MatStepHeader_ng_container_4_span_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "span", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    const ctx_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](ctx_r7._intl.completedLabel);
  }
}

function MatStepHeader_ng_container_4_span_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "span", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    const ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](ctx_r8._intl.editableLabel);
  }
}

function MatStepHeader_ng_container_4_mat_icon_4_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "mat-icon", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    const ctx_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](ctx_r9._getDefaultTextForState(ctx_r9.state));
  }
}

function MatStepHeader_ng_container_4_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerStart"](0, 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, MatStepHeader_ng_container_4_span_1_Template, 2, 1, "span", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](2, MatStepHeader_ng_container_4_span_2_Template, 2, 1, "span", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](3, MatStepHeader_ng_container_4_span_3_Template, 2, 1, "span", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](4, MatStepHeader_ng_container_4_mat_icon_4_Template, 2, 1, "mat-icon", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerEnd"]();
  }

  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngSwitch", ctx_r1.state);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngSwitchCase", "number");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r1.state === "done");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r1.state === "edit");
  }
}

function MatStepHeader_div_6_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainer"](1, 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngTemplateOutlet", ctx_r2._templateLabel().template);
  }
}

function MatStepHeader_div_7_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](ctx_r3.label);
  }
}

function MatStepHeader_div_8_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](ctx_r4._intl.optionalLabel);
  }
}

function MatStepHeader_div_9_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](ctx_r5.errorMessage);
  }
}

function MatStep_ng_template_0_ng_template_1_Template(rf, ctx) {}

function MatStep_ng_template_0_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵprojection"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, MatStep_ng_template_0_ng_template_1_Template, 0, 0, "ng-template", 0);
  }

  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("cdkPortalOutlet", ctx_r0._portal);
  }
}

const _c0 = ["*"];

function MatStepper_ng_container_1_ng_container_2_div_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "div", 9);
  }
}

const _c1 = function (a0, a1) {
  return {
    step: a0,
    i: a1
  };
};

function MatStepper_ng_container_1_ng_container_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainer"](1, 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](2, MatStepper_ng_container_1_ng_container_2_div_2_Template, 1, 0, "div", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerEnd"]();
  }

  if (rf & 2) {
    const step_r6 = ctx.$implicit;
    const i_r7 = ctx.index;
    const isLast_r8 = ctx.last;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);

    const _r2 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](4);

    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngTemplateOutlet", _r2)("ngTemplateOutletContext", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction2"](3, _c1, step_r6, i_r7));
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", !isLast_r8);
  }
}

function MatStepper_ng_container_1_div_4_Template(rf, ctx) {
  if (rf & 1) {
    const _r13 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();

    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("@horizontalStepTransition.done", function MatStepper_ng_container_1_div_4_Template_div_animation_horizontalStepTransition_done_0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r13);
      const ctx_r12 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
      return ctx_r12._animationDone.next($event);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainer"](1, 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    const step_r10 = ctx.$implicit;
    const i_r11 = ctx.index;
    const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("@horizontalStepTransition", ctx_r5._getAnimationDirection(i_r11))("id", ctx_r5._getStepContentId(i_r11));
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵattribute"]("aria-labelledby", ctx_r5._getStepLabelId(i_r11))("aria-expanded", ctx_r5.selectedIndex === i_r11);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngTemplateOutlet", step_r10.content);
  }
}

function MatStepper_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](2, MatStepper_ng_container_1_ng_container_2_Template, 3, 6, "ng-container", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "div", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](4, MatStepper_ng_container_1_div_4_Template, 2, 5, "div", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerEnd"]();
  }

  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx_r0.steps);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx_r0.steps);
  }
}

function MatStepper_ng_container_2_div_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r19 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();

    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainer"](1, 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "div", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "div", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("@verticalStepTransition.done", function MatStepper_ng_container_2_div_1_Template_div_animation_verticalStepTransition_done_3_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r19);
      const ctx_r18 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
      return ctx_r18._animationDone.next($event);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "div", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainer"](5, 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    const step_r15 = ctx.$implicit;
    const i_r16 = ctx.index;
    const isLast_r17 = ctx.last;
    const ctx_r14 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);

    const _r2 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](4);

    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngTemplateOutlet", _r2)("ngTemplateOutletContext", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction2"](9, _c1, step_r15, i_r16));
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassProp"]("mat-stepper-vertical-line", !isLast_r17);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("@verticalStepTransition", ctx_r14._getAnimationDirection(i_r16))("id", ctx_r14._getStepContentId(i_r16));
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵattribute"]("aria-labelledby", ctx_r14._getStepLabelId(i_r16))("aria-expanded", ctx_r14.selectedIndex === i_r16);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngTemplateOutlet", step_r15.content);
  }
}

function MatStepper_ng_container_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, MatStepper_ng_container_2_div_1_Template, 6, 12, "div", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerEnd"]();
  }

  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx_r1.steps);
  }
}

function MatStepper_ng_template_3_Template(rf, ctx) {
  if (rf & 1) {
    const _r23 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();

    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "mat-step-header", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function MatStepper_ng_template_3_Template_mat_step_header_click_0_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r23);
      const step_r20 = restoredCtx.step;
      return step_r20.select();
    })("keydown", function MatStepper_ng_template_3_Template_mat_step_header_keydown_0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r23);
      const ctx_r24 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
      return ctx_r24._onKeydown($event);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    const step_r20 = ctx.step;
    const i_r21 = ctx.i;
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassProp"]("mat-horizontal-stepper-header", ctx_r3.orientation === "horizontal")("mat-vertical-stepper-header", ctx_r3.orientation === "vertical");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("tabIndex", ctx_r3._getFocusIndex() === i_r21 ? 0 : -1)("id", ctx_r3._getStepLabelId(i_r21))("index", i_r21)("state", ctx_r3._getIndicatorType(i_r21, step_r20.state))("label", step_r20.stepLabel || step_r20.label)("selected", ctx_r3.selectedIndex === i_r21)("active", ctx_r3._stepIsNavigable(i_r21, step_r20))("optional", step_r20.optional)("errorMessage", step_r20.errorMessage)("iconOverrides", ctx_r3._iconOverrides)("disableRipple", ctx_r3.disableRipple || !ctx_r3._stepIsNavigable(i_r21, step_r20))("color", step_r20.color || ctx_r3.color);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵattribute"]("aria-posinset", i_r21 + 1)("aria-setsize", ctx_r3.steps.length)("aria-controls", ctx_r3._getStepContentId(i_r21))("aria-selected", ctx_r3.selectedIndex == i_r21)("aria-label", step_r20.ariaLabel || null)("aria-labelledby", !step_r20.ariaLabel && step_r20.ariaLabelledby ? step_r20.ariaLabelledby : null)("aria-disabled", ctx_r3._stepIsNavigable(i_r21, step_r20) ? null : true);
  }
}

class MatStepLabel extends _angular_cdk_stepper__WEBPACK_IMPORTED_MODULE_1__.CdkStepLabel {}

MatStepLabel.ɵfac = /* @__PURE__ */function () {
  let ɵMatStepLabel_BaseFactory;
  return function MatStepLabel_Factory(t) {
    return (ɵMatStepLabel_BaseFactory || (ɵMatStepLabel_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetInheritedFactory"](MatStepLabel)))(t || MatStepLabel);
  };
}();

MatStepLabel.ɵdir = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineDirective"]({
  type: MatStepLabel,
  selectors: [["", "matStepLabel", ""]],
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵInheritDefinitionFeature"]]
});

(function () {
  (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](MatStepLabel, [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Directive,
    args: [{
      selector: '[matStepLabel]'
    }]
  }], null, null);
})();
/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/** Stepper data that is required for internationalization. */


class MatStepperIntl {
  constructor() {
    /**
     * Stream that emits whenever the labels here are changed. Use this to notify
     * components if the labels have changed after initialization.
     */
    this.changes = new rxjs__WEBPACK_IMPORTED_MODULE_2__.Subject();
    /** Label that is rendered below optional steps. */

    this.optionalLabel = 'Optional';
    /** Label that is used to indicate step as completed to screen readers. */

    this.completedLabel = 'Completed';
    /** Label that is used to indicate step as editable to screen readers. */

    this.editableLabel = 'Editable';
  }

}

MatStepperIntl.ɵfac = function MatStepperIntl_Factory(t) {
  return new (t || MatStepperIntl)();
};

MatStepperIntl.ɵprov = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjectable"]({
  token: MatStepperIntl,
  factory: MatStepperIntl.ɵfac,
  providedIn: 'root'
});

(function () {
  (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](MatStepperIntl, [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Injectable,
    args: [{
      providedIn: 'root'
    }]
  }], null, null);
})();
/** @docs-private */


function MAT_STEPPER_INTL_PROVIDER_FACTORY(parentIntl) {
  return parentIntl || new MatStepperIntl();
}
/** @docs-private */


const MAT_STEPPER_INTL_PROVIDER = {
  provide: MatStepperIntl,
  deps: [[new _angular_core__WEBPACK_IMPORTED_MODULE_0__.Optional(), new _angular_core__WEBPACK_IMPORTED_MODULE_0__.SkipSelf(), MatStepperIntl]],
  useFactory: MAT_STEPPER_INTL_PROVIDER_FACTORY
}; // Boilerplate for applying mixins to MatStepHeader.

/** @docs-private */

const _MatStepHeaderBase = (0,_angular_material_core__WEBPACK_IMPORTED_MODULE_3__.mixinColor)(class MatStepHeaderBase extends _angular_cdk_stepper__WEBPACK_IMPORTED_MODULE_1__.CdkStepHeader {
  constructor(elementRef) {
    super(elementRef);
  }

}, 'primary');

class MatStepHeader extends _MatStepHeaderBase {
  constructor(_intl, _focusMonitor, _elementRef, changeDetectorRef) {
    super(_elementRef);
    this._intl = _intl;
    this._focusMonitor = _focusMonitor;
    this._intlSubscription = _intl.changes.subscribe(() => changeDetectorRef.markForCheck());
  }

  ngAfterViewInit() {
    this._focusMonitor.monitor(this._elementRef, true);
  }

  ngOnDestroy() {
    this._intlSubscription.unsubscribe();

    this._focusMonitor.stopMonitoring(this._elementRef);
  }
  /** Focuses the step header. */


  focus(origin, options) {
    if (origin) {
      this._focusMonitor.focusVia(this._elementRef, origin, options);
    } else {
      this._elementRef.nativeElement.focus(options);
    }
  }
  /** Returns string label of given step if it is a text label. */


  _stringLabel() {
    return this.label instanceof MatStepLabel ? null : this.label;
  }
  /** Returns MatStepLabel if the label of given step is a template label. */


  _templateLabel() {
    return this.label instanceof MatStepLabel ? this.label : null;
  }
  /** Returns the host HTML element. */


  _getHostElement() {
    return this._elementRef.nativeElement;
  }
  /** Template context variables that are exposed to the `matStepperIcon` instances. */


  _getIconContext() {
    return {
      index: this.index,
      active: this.active,
      optional: this.optional
    };
  }

  _getDefaultTextForState(state) {
    if (state == 'number') {
      return `${this.index + 1}`;
    }

    if (state == 'edit') {
      return 'create';
    }

    if (state == 'error') {
      return 'warning';
    }

    return state;
  }

}

MatStepHeader.ɵfac = function MatStepHeader_Factory(t) {
  return new (t || MatStepHeader)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](MatStepperIntl), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_cdk_a11y__WEBPACK_IMPORTED_MODULE_4__.FocusMonitor), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__.ElementRef), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__.ChangeDetectorRef));
};

MatStepHeader.ɵcmp = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
  type: MatStepHeader,
  selectors: [["mat-step-header"]],
  hostAttrs: ["role", "tab", 1, "mat-step-header"],
  inputs: {
    color: "color",
    state: "state",
    label: "label",
    errorMessage: "errorMessage",
    iconOverrides: "iconOverrides",
    index: "index",
    selected: "selected",
    active: "active",
    optional: "optional",
    disableRipple: "disableRipple"
  },
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵInheritDefinitionFeature"]],
  decls: 10,
  vars: 19,
  consts: [["matRipple", "", 1, "mat-step-header-ripple", "mat-focus-indicator", 3, "matRippleTrigger", "matRippleDisabled"], [1, "mat-step-icon-content", 3, "ngSwitch"], [3, "ngTemplateOutlet", "ngTemplateOutletContext", 4, "ngSwitchCase"], [3, "ngSwitch", 4, "ngSwitchDefault"], [1, "mat-step-label"], ["class", "mat-step-text-label", 4, "ngIf"], ["class", "mat-step-optional", 4, "ngIf"], ["class", "mat-step-sub-label-error", 4, "ngIf"], [3, "ngTemplateOutlet", "ngTemplateOutletContext"], [3, "ngSwitch"], ["aria-hidden", "true", 4, "ngSwitchCase"], ["class", "cdk-visually-hidden", 4, "ngIf"], ["aria-hidden", "true", 4, "ngSwitchDefault"], ["aria-hidden", "true"], [1, "cdk-visually-hidden"], [1, "mat-step-text-label"], [3, "ngTemplateOutlet"], [1, "mat-step-optional"], [1, "mat-step-sub-label-error"]],
  template: function MatStepHeader_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "div", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div");
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "div", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](3, MatStepHeader_ng_container_3_Template, 1, 2, "ng-container", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](4, MatStepHeader_ng_container_4_Template, 5, 4, "ng-container", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "div", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](6, MatStepHeader_div_6_Template, 2, 1, "div", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](7, MatStepHeader_div_7_Template, 2, 1, "div", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](8, MatStepHeader_div_8_Template, 2, 1, "div", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](9, MatStepHeader_div_9_Template, 2, 1, "div", 7);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    }

    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("matRippleTrigger", ctx._getHostElement())("matRippleDisabled", ctx.disableRipple);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassMapInterpolate1"]("mat-step-icon-state-", ctx.state, " mat-step-icon");
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassProp"]("mat-step-icon-selected", ctx.selected);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngSwitch", !!(ctx.iconOverrides && ctx.iconOverrides[ctx.state]));
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngSwitchCase", true);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassProp"]("mat-step-label-active", ctx.active)("mat-step-label-selected", ctx.selected)("mat-step-label-error", ctx.state == "error");
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx._templateLabel());
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx._stringLabel());
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.optional && ctx.state != "error");
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.state == "error");
    }
  },
  directives: [_angular_material_core__WEBPACK_IMPORTED_MODULE_3__.MatRipple, _angular_common__WEBPACK_IMPORTED_MODULE_5__.NgSwitch, _angular_common__WEBPACK_IMPORTED_MODULE_5__.NgSwitchCase, _angular_common__WEBPACK_IMPORTED_MODULE_5__.NgSwitchDefault, _angular_common__WEBPACK_IMPORTED_MODULE_5__.NgIf, _angular_common__WEBPACK_IMPORTED_MODULE_5__.NgTemplateOutlet, _angular_material_icon__WEBPACK_IMPORTED_MODULE_6__.MatIcon],
  styles: [".mat-step-header{overflow:hidden;outline:none;cursor:pointer;position:relative;box-sizing:content-box;-webkit-tap-highlight-color:transparent}.cdk-high-contrast-active .mat-step-header{outline:solid 1px}.cdk-high-contrast-active .mat-step-header.cdk-keyboard-focused,.cdk-high-contrast-active .mat-step-header.cdk-program-focused{outline:solid 3px}.cdk-high-contrast-active .mat-step-header[aria-selected=true] .mat-step-label{text-decoration:underline}.mat-step-optional,.mat-step-sub-label-error{font-size:12px}.mat-step-icon{border-radius:50%;height:24px;width:24px;flex-shrink:0;position:relative}.mat-step-icon-content{position:absolute;top:50%;left:50%;transform:translate(-50%, -50%);display:flex}.mat-step-icon .mat-icon{font-size:16px;height:16px;width:16px}.mat-step-icon-state-error .mat-icon{font-size:24px;height:24px;width:24px}.mat-step-label{display:inline-block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;min-width:50px;vertical-align:middle}.mat-step-text-label{text-overflow:ellipsis;overflow:hidden}.mat-step-header .mat-step-header-ripple{top:0;left:0;right:0;bottom:0;position:absolute;pointer-events:none}\n"],
  encapsulation: 2,
  changeDetection: 0
});

(function () {
  (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](MatStepHeader, [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Component,
    args: [{
      selector: 'mat-step-header',
      inputs: ['color'],
      host: {
        'class': 'mat-step-header',
        'role': 'tab'
      },
      encapsulation: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ViewEncapsulation.None,
      changeDetection: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ChangeDetectionStrategy.OnPush,
      template: "<div class=\"mat-step-header-ripple mat-focus-indicator\" matRipple\n     [matRippleTrigger]=\"_getHostElement()\"\n     [matRippleDisabled]=\"disableRipple\"></div>\n\n<div class=\"mat-step-icon-state-{{state}} mat-step-icon\" [class.mat-step-icon-selected]=\"selected\">\n  <div class=\"mat-step-icon-content\" [ngSwitch]=\"!!(iconOverrides && iconOverrides[state])\">\n    <ng-container\n      *ngSwitchCase=\"true\"\n      [ngTemplateOutlet]=\"iconOverrides[state]\"\n      [ngTemplateOutletContext]=\"_getIconContext()\"></ng-container>\n    <ng-container *ngSwitchDefault [ngSwitch]=\"state\">\n      <span aria-hidden=\"true\" *ngSwitchCase=\"'number'\">{{_getDefaultTextForState(state)}}</span>\n      <span class=\"cdk-visually-hidden\" *ngIf=\"state === 'done'\">{{_intl.completedLabel}}</span>\n      <span class=\"cdk-visually-hidden\" *ngIf=\"state === 'edit'\">{{_intl.editableLabel}}</span>\n      <mat-icon aria-hidden=\"true\" *ngSwitchDefault>{{_getDefaultTextForState(state)}}</mat-icon>\n    </ng-container>\n  </div>\n</div>\n<div class=\"mat-step-label\"\n     [class.mat-step-label-active]=\"active\"\n     [class.mat-step-label-selected]=\"selected\"\n     [class.mat-step-label-error]=\"state == 'error'\">\n  <!-- If there is a label template, use it. -->\n  <div class=\"mat-step-text-label\" *ngIf=\"_templateLabel()\">\n    <ng-container [ngTemplateOutlet]=\"_templateLabel()!.template\"></ng-container>\n  </div>\n  <!-- If there is no label template, fall back to the text label. -->\n  <div class=\"mat-step-text-label\" *ngIf=\"_stringLabel()\">{{label}}</div>\n\n  <div class=\"mat-step-optional\" *ngIf=\"optional && state != 'error'\">{{_intl.optionalLabel}}</div>\n  <div class=\"mat-step-sub-label-error\" *ngIf=\"state == 'error'\">{{errorMessage}}</div>\n</div>\n\n",
      styles: [".mat-step-header{overflow:hidden;outline:none;cursor:pointer;position:relative;box-sizing:content-box;-webkit-tap-highlight-color:transparent}.cdk-high-contrast-active .mat-step-header{outline:solid 1px}.cdk-high-contrast-active .mat-step-header.cdk-keyboard-focused,.cdk-high-contrast-active .mat-step-header.cdk-program-focused{outline:solid 3px}.cdk-high-contrast-active .mat-step-header[aria-selected=true] .mat-step-label{text-decoration:underline}.mat-step-optional,.mat-step-sub-label-error{font-size:12px}.mat-step-icon{border-radius:50%;height:24px;width:24px;flex-shrink:0;position:relative}.mat-step-icon-content{position:absolute;top:50%;left:50%;transform:translate(-50%, -50%);display:flex}.mat-step-icon .mat-icon{font-size:16px;height:16px;width:16px}.mat-step-icon-state-error .mat-icon{font-size:24px;height:24px;width:24px}.mat-step-label{display:inline-block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;min-width:50px;vertical-align:middle}.mat-step-text-label{text-overflow:ellipsis;overflow:hidden}.mat-step-header .mat-step-header-ripple{top:0;left:0;right:0;bottom:0;position:absolute;pointer-events:none}\n"]
    }]
  }], function () {
    return [{
      type: MatStepperIntl
    }, {
      type: _angular_cdk_a11y__WEBPACK_IMPORTED_MODULE_4__.FocusMonitor
    }, {
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ElementRef
    }, {
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ChangeDetectorRef
    }];
  }, {
    state: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    label: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    errorMessage: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    iconOverrides: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    index: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    selected: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    active: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    optional: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    disableRipple: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }]
  });
})();
/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/**
 * Animations used by the Material steppers.
 * @docs-private
 */


const matStepperAnimations = {
  /** Animation that transitions the step along the X axis in a horizontal stepper. */
  horizontalStepTransition: (0,_angular_animations__WEBPACK_IMPORTED_MODULE_7__.trigger)('horizontalStepTransition', [(0,_angular_animations__WEBPACK_IMPORTED_MODULE_7__.state)('previous', (0,_angular_animations__WEBPACK_IMPORTED_MODULE_7__.style)({
    transform: 'translate3d(-100%, 0, 0)',
    visibility: 'hidden'
  })), // Transition to `inherit`, rather than `visible`,
  // because visibility on a child element the one from the parent,
  // making this element focusable inside of a `hidden` element.
  (0,_angular_animations__WEBPACK_IMPORTED_MODULE_7__.state)('current', (0,_angular_animations__WEBPACK_IMPORTED_MODULE_7__.style)({
    transform: 'none',
    visibility: 'inherit'
  })), (0,_angular_animations__WEBPACK_IMPORTED_MODULE_7__.state)('next', (0,_angular_animations__WEBPACK_IMPORTED_MODULE_7__.style)({
    transform: 'translate3d(100%, 0, 0)',
    visibility: 'hidden'
  })), (0,_angular_animations__WEBPACK_IMPORTED_MODULE_7__.transition)('* => *', (0,_angular_animations__WEBPACK_IMPORTED_MODULE_7__.animate)('500ms cubic-bezier(0.35, 0, 0.25, 1)'))]),

  /** Animation that transitions the step along the Y axis in a vertical stepper. */
  verticalStepTransition: (0,_angular_animations__WEBPACK_IMPORTED_MODULE_7__.trigger)('verticalStepTransition', [(0,_angular_animations__WEBPACK_IMPORTED_MODULE_7__.state)('previous', (0,_angular_animations__WEBPACK_IMPORTED_MODULE_7__.style)({
    height: '0px',
    visibility: 'hidden'
  })), (0,_angular_animations__WEBPACK_IMPORTED_MODULE_7__.state)('next', (0,_angular_animations__WEBPACK_IMPORTED_MODULE_7__.style)({
    height: '0px',
    visibility: 'hidden'
  })), // Transition to `inherit`, rather than `visible`,
  // because visibility on a child element the one from the parent,
  // making this element focusable inside of a `hidden` element.
  (0,_angular_animations__WEBPACK_IMPORTED_MODULE_7__.state)('current', (0,_angular_animations__WEBPACK_IMPORTED_MODULE_7__.style)({
    height: '*',
    visibility: 'inherit'
  })), (0,_angular_animations__WEBPACK_IMPORTED_MODULE_7__.transition)('* <=> current', (0,_angular_animations__WEBPACK_IMPORTED_MODULE_7__.animate)('225ms cubic-bezier(0.4, 0.0, 0.2, 1)'))])
};
/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/**
 * Template to be used to override the icons inside the step header.
 */

class MatStepperIcon {
  constructor(templateRef) {
    this.templateRef = templateRef;
  }

}

MatStepperIcon.ɵfac = function MatStepperIcon_Factory(t) {
  return new (t || MatStepperIcon)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__.TemplateRef));
};

MatStepperIcon.ɵdir = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineDirective"]({
  type: MatStepperIcon,
  selectors: [["ng-template", "matStepperIcon", ""]],
  inputs: {
    name: ["matStepperIcon", "name"]
  }
});

(function () {
  (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](MatStepperIcon, [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Directive,
    args: [{
      selector: 'ng-template[matStepperIcon]'
    }]
  }], function () {
    return [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.TemplateRef
    }];
  }, {
    name: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input,
      args: ['matStepperIcon']
    }]
  });
})();
/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/**
 * Content for a `mat-step` that will be rendered lazily.
 */


class MatStepContent {
  constructor(_template) {
    this._template = _template;
  }

}

MatStepContent.ɵfac = function MatStepContent_Factory(t) {
  return new (t || MatStepContent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__.TemplateRef));
};

MatStepContent.ɵdir = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineDirective"]({
  type: MatStepContent,
  selectors: [["ng-template", "matStepContent", ""]]
});

(function () {
  (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](MatStepContent, [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Directive,
    args: [{
      selector: 'ng-template[matStepContent]'
    }]
  }], function () {
    return [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.TemplateRef
    }];
  }, null);
})();

class MatStep extends _angular_cdk_stepper__WEBPACK_IMPORTED_MODULE_1__.CdkStep {
  constructor(stepper, _errorStateMatcher, _viewContainerRef, stepperOptions) {
    super(stepper, stepperOptions);
    this._errorStateMatcher = _errorStateMatcher;
    this._viewContainerRef = _viewContainerRef;
    this._isSelected = rxjs__WEBPACK_IMPORTED_MODULE_8__.Subscription.EMPTY;
  }

  ngAfterContentInit() {
    this._isSelected = this._stepper.steps.changes.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_9__.switchMap)(() => {
      return this._stepper.selectionChange.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_10__.map)(event => event.selectedStep === this), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_11__.startWith)(this._stepper.selected === this));
    })).subscribe(isSelected => {
      if (isSelected && this._lazyContent && !this._portal) {
        this._portal = new _angular_cdk_portal__WEBPACK_IMPORTED_MODULE_12__.TemplatePortal(this._lazyContent._template, this._viewContainerRef);
      }
    });
  }

  ngOnDestroy() {
    this._isSelected.unsubscribe();
  }
  /** Custom error state matcher that additionally checks for validity of interacted form. */


  isErrorState(control, form) {
    const originalErrorState = this._errorStateMatcher.isErrorState(control, form); // Custom error state checks for the validity of form that is not submitted or touched
    // since user can trigger a form change by calling for another step without directly
    // interacting with the current form.


    const customErrorState = !!(control && control.invalid && this.interacted);
    return originalErrorState || customErrorState;
  }

}

MatStep.ɵfac = function MatStep_Factory(t) {
  return new (t || MatStep)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"]((0,_angular_core__WEBPACK_IMPORTED_MODULE_0__.forwardRef)(() => MatStepper)), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_material_core__WEBPACK_IMPORTED_MODULE_3__.ErrorStateMatcher, 4), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__.ViewContainerRef), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_cdk_stepper__WEBPACK_IMPORTED_MODULE_1__.STEPPER_GLOBAL_OPTIONS, 8));
};

MatStep.ɵcmp = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
  type: MatStep,
  selectors: [["mat-step"]],
  contentQueries: function MatStep_ContentQueries(rf, ctx, dirIndex) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵcontentQuery"](dirIndex, MatStepLabel, 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵcontentQuery"](dirIndex, MatStepContent, 5);
    }

    if (rf & 2) {
      let _t;

      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵloadQuery"]()) && (ctx.stepLabel = _t.first);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵloadQuery"]()) && (ctx._lazyContent = _t.first);
    }
  },
  inputs: {
    color: "color"
  },
  exportAs: ["matStep"],
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵProvidersFeature"]([{
    provide: _angular_material_core__WEBPACK_IMPORTED_MODULE_3__.ErrorStateMatcher,
    useExisting: MatStep
  }, {
    provide: _angular_cdk_stepper__WEBPACK_IMPORTED_MODULE_1__.CdkStep,
    useExisting: MatStep
  }]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵInheritDefinitionFeature"]],
  ngContentSelectors: _c0,
  decls: 1,
  vars: 0,
  consts: [[3, "cdkPortalOutlet"]],
  template: function MatStep_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵprojectionDef"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](0, MatStep_ng_template_0_Template, 2, 1, "ng-template");
    }
  },
  directives: [_angular_cdk_portal__WEBPACK_IMPORTED_MODULE_12__.CdkPortalOutlet],
  encapsulation: 2,
  changeDetection: 0
});

(function () {
  (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](MatStep, [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Component,
    args: [{
      selector: 'mat-step',
      providers: [{
        provide: _angular_material_core__WEBPACK_IMPORTED_MODULE_3__.ErrorStateMatcher,
        useExisting: MatStep
      }, {
        provide: _angular_cdk_stepper__WEBPACK_IMPORTED_MODULE_1__.CdkStep,
        useExisting: MatStep
      }],
      encapsulation: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ViewEncapsulation.None,
      exportAs: 'matStep',
      changeDetection: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ChangeDetectionStrategy.OnPush,
      template: "<ng-template>\n  <ng-content></ng-content>\n  <ng-template [cdkPortalOutlet]=\"_portal\"></ng-template>\n</ng-template>\n"
    }]
  }], function () {
    return [{
      type: MatStepper,
      decorators: [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Inject,
        args: [(0,_angular_core__WEBPACK_IMPORTED_MODULE_0__.forwardRef)(() => MatStepper)]
      }]
    }, {
      type: _angular_material_core__WEBPACK_IMPORTED_MODULE_3__.ErrorStateMatcher,
      decorators: [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.SkipSelf
      }]
    }, {
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ViewContainerRef
    }, {
      type: undefined,
      decorators: [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Optional
      }, {
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Inject,
        args: [_angular_cdk_stepper__WEBPACK_IMPORTED_MODULE_1__.STEPPER_GLOBAL_OPTIONS]
      }]
    }];
  }, {
    stepLabel: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ContentChild,
      args: [MatStepLabel]
    }],
    color: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    _lazyContent: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ContentChild,
      args: [MatStepContent, {
        static: false
      }]
    }]
  });
})();
/**
 * Proxies the public APIs from `MatStepper` to the deprecated `MatHorizontalStepper` and
 * `MatVerticalStepper`.
 * @deprecated Use `MatStepper` instead.
 * @breaking-change 13.0.0
 * @docs-private
 */


class _MatProxyStepperBase extends _angular_cdk_stepper__WEBPACK_IMPORTED_MODULE_1__.CdkStepper {}

_MatProxyStepperBase.ɵfac = /* @__PURE__ */function () {
  let ɵ_MatProxyStepperBase_BaseFactory;
  return function _MatProxyStepperBase_Factory(t) {
    return (ɵ_MatProxyStepperBase_BaseFactory || (ɵ_MatProxyStepperBase_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetInheritedFactory"](_MatProxyStepperBase)))(t || _MatProxyStepperBase);
  };
}();

_MatProxyStepperBase.ɵdir = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineDirective"]({
  type: _MatProxyStepperBase,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵInheritDefinitionFeature"]]
});

(function () {
  (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](_MatProxyStepperBase, [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Directive
  }], null, null);
})();
/**
 * @deprecated Use `MatStepper` instead.
 * @breaking-change 13.0.0
 */


class MatHorizontalStepper extends _MatProxyStepperBase {}

MatHorizontalStepper.ɵfac = /* @__PURE__ */function () {
  let ɵMatHorizontalStepper_BaseFactory;
  return function MatHorizontalStepper_Factory(t) {
    return (ɵMatHorizontalStepper_BaseFactory || (ɵMatHorizontalStepper_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetInheritedFactory"](MatHorizontalStepper)))(t || MatHorizontalStepper);
  };
}();

MatHorizontalStepper.ɵdir = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineDirective"]({
  type: MatHorizontalStepper,
  selectors: [["mat-horizontal-stepper"]],
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵInheritDefinitionFeature"]]
});

(function () {
  (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](MatHorizontalStepper, [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Directive,
    args: [{
      selector: 'mat-horizontal-stepper'
    }]
  }], null, null);
})();
/**
 * @deprecated Use `MatStepper` instead.
 * @breaking-change 13.0.0
 */


class MatVerticalStepper extends _MatProxyStepperBase {}

MatVerticalStepper.ɵfac = /* @__PURE__ */function () {
  let ɵMatVerticalStepper_BaseFactory;
  return function MatVerticalStepper_Factory(t) {
    return (ɵMatVerticalStepper_BaseFactory || (ɵMatVerticalStepper_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetInheritedFactory"](MatVerticalStepper)))(t || MatVerticalStepper);
  };
}();

MatVerticalStepper.ɵdir = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineDirective"]({
  type: MatVerticalStepper,
  selectors: [["mat-vertical-stepper"]],
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵInheritDefinitionFeature"]]
});

(function () {
  (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](MatVerticalStepper, [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Directive,
    args: [{
      selector: 'mat-vertical-stepper'
    }]
  }], null, null);
})();

class MatStepper extends _angular_cdk_stepper__WEBPACK_IMPORTED_MODULE_1__.CdkStepper {
  constructor(dir, changeDetectorRef, elementRef, _document) {
    super(dir, changeDetectorRef, elementRef, _document);
    /** Steps that belong to the current stepper, excluding ones from nested steppers. */

    this.steps = new _angular_core__WEBPACK_IMPORTED_MODULE_0__.QueryList();
    /** Event emitted when the current step is done transitioning in. */

    this.animationDone = new _angular_core__WEBPACK_IMPORTED_MODULE_0__.EventEmitter();
    /**
     * Whether the label should display in bottom or end position.
     * Only applies in the `horizontal` orientation.
     */

    this.labelPosition = 'end';
    /** Consumer-specified template-refs to be used to override the header icons. */

    this._iconOverrides = {};
    /** Stream of animation `done` events when the body expands/collapses. */

    this._animationDone = new rxjs__WEBPACK_IMPORTED_MODULE_2__.Subject();
    const nodeName = elementRef.nativeElement.nodeName.toLowerCase();
    this.orientation = nodeName === 'mat-vertical-stepper' ? 'vertical' : 'horizontal';
  }

  ngAfterContentInit() {
    super.ngAfterContentInit();

    this._icons.forEach(({
      name,
      templateRef
    }) => this._iconOverrides[name] = templateRef); // Mark the component for change detection whenever the content children query changes


    this.steps.changes.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_13__.takeUntil)(this._destroyed)).subscribe(() => {
      this._stateChanged();
    });

    this._animationDone.pipe( // This needs a `distinctUntilChanged` in order to avoid emitting the same event twice due
    // to a bug in animations where the `.done` callback gets invoked twice on some browsers.
    // See https://github.com/angular/angular/issues/24084
    (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_14__.distinctUntilChanged)((x, y) => x.fromState === y.fromState && x.toState === y.toState), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_13__.takeUntil)(this._destroyed)).subscribe(event => {
      if (event.toState === 'current') {
        this.animationDone.emit();
      }
    });
  }

  _stepIsNavigable(index, step) {
    return step.completed || this.selectedIndex === index || !this.linear;
  }

}

MatStepper.ɵfac = function MatStepper_Factory(t) {
  return new (t || MatStepper)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_cdk_bidi__WEBPACK_IMPORTED_MODULE_15__.Directionality, 8), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__.ChangeDetectorRef), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__.ElementRef), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_common__WEBPACK_IMPORTED_MODULE_5__.DOCUMENT));
};

MatStepper.ɵcmp = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
  type: MatStepper,
  selectors: [["mat-stepper"], ["mat-vertical-stepper"], ["mat-horizontal-stepper"], ["", "matStepper", ""]],
  contentQueries: function MatStepper_ContentQueries(rf, ctx, dirIndex) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵcontentQuery"](dirIndex, MatStep, 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵcontentQuery"](dirIndex, MatStepperIcon, 5);
    }

    if (rf & 2) {
      let _t;

      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵloadQuery"]()) && (ctx._steps = _t);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵloadQuery"]()) && (ctx._icons = _t);
    }
  },
  viewQuery: function MatStepper_Query(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵviewQuery"](MatStepHeader, 5);
    }

    if (rf & 2) {
      let _t;

      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵloadQuery"]()) && (ctx._stepHeader = _t);
    }
  },
  hostAttrs: ["role", "tablist"],
  hostVars: 9,
  hostBindings: function MatStepper_HostBindings(rf, ctx) {
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵattribute"]("aria-orientation", ctx.orientation);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassProp"]("mat-stepper-horizontal", ctx.orientation === "horizontal")("mat-stepper-vertical", ctx.orientation === "vertical")("mat-stepper-label-position-end", ctx.orientation === "horizontal" && ctx.labelPosition == "end")("mat-stepper-label-position-bottom", ctx.orientation === "horizontal" && ctx.labelPosition == "bottom");
    }
  },
  inputs: {
    selectedIndex: "selectedIndex",
    disableRipple: "disableRipple",
    color: "color",
    labelPosition: "labelPosition"
  },
  outputs: {
    animationDone: "animationDone"
  },
  exportAs: ["matStepper", "matVerticalStepper", "matHorizontalStepper"],
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵProvidersFeature"]([{
    provide: _angular_cdk_stepper__WEBPACK_IMPORTED_MODULE_1__.CdkStepper,
    useExisting: MatStepper
  }, {
    provide: MatHorizontalStepper,
    useExisting: MatStepper
  }, {
    provide: MatVerticalStepper,
    useExisting: MatStepper
  }]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵInheritDefinitionFeature"]],
  decls: 5,
  vars: 3,
  consts: [[3, "ngSwitch"], [4, "ngSwitchCase"], ["stepTemplate", ""], [1, "mat-horizontal-stepper-header-container"], [4, "ngFor", "ngForOf"], [1, "mat-horizontal-content-container"], ["class", "mat-horizontal-stepper-content", "role", "tabpanel", 3, "id", 4, "ngFor", "ngForOf"], [3, "ngTemplateOutlet", "ngTemplateOutletContext"], ["class", "mat-stepper-horizontal-line", 4, "ngIf"], [1, "mat-stepper-horizontal-line"], ["role", "tabpanel", 1, "mat-horizontal-stepper-content", 3, "id"], [3, "ngTemplateOutlet"], ["class", "mat-step", 4, "ngFor", "ngForOf"], [1, "mat-step"], [1, "mat-vertical-content-container"], ["role", "tabpanel", 1, "mat-vertical-stepper-content", 3, "id"], [1, "mat-vertical-content"], [3, "tabIndex", "id", "index", "state", "label", "selected", "active", "optional", "errorMessage", "iconOverrides", "disableRipple", "color", "click", "keydown"]],
  template: function MatStepper_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerStart"](0, 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, MatStepper_ng_container_1_Template, 5, 2, "ng-container", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](2, MatStepper_ng_container_2_Template, 2, 1, "ng-container", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](3, MatStepper_ng_template_3_Template, 1, 23, "ng-template", null, 2, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplateRefExtractor"]);
    }

    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngSwitch", ctx.orientation);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngSwitchCase", "horizontal");
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngSwitchCase", "vertical");
    }
  },
  directives: [_angular_common__WEBPACK_IMPORTED_MODULE_5__.NgSwitch, _angular_common__WEBPACK_IMPORTED_MODULE_5__.NgSwitchCase, _angular_common__WEBPACK_IMPORTED_MODULE_5__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_5__.NgTemplateOutlet, _angular_common__WEBPACK_IMPORTED_MODULE_5__.NgIf, MatStepHeader],
  styles: [".mat-stepper-vertical,.mat-stepper-horizontal{display:block}.mat-horizontal-stepper-header-container{white-space:nowrap;display:flex;align-items:center}.mat-stepper-label-position-bottom .mat-horizontal-stepper-header-container{align-items:flex-start}.mat-stepper-horizontal-line{border-top-width:1px;border-top-style:solid;flex:auto;height:0;margin:0 -16px;min-width:32px}.mat-stepper-label-position-bottom .mat-stepper-horizontal-line{margin:0;min-width:0;position:relative}.mat-stepper-label-position-bottom .mat-horizontal-stepper-header:not(:first-child)::before,[dir=rtl] .mat-stepper-label-position-bottom .mat-horizontal-stepper-header:not(:last-child)::before,.mat-stepper-label-position-bottom .mat-horizontal-stepper-header:not(:last-child)::after,[dir=rtl] .mat-stepper-label-position-bottom .mat-horizontal-stepper-header:not(:first-child)::after{border-top-width:1px;border-top-style:solid;content:\"\";display:inline-block;height:0;position:absolute;width:calc(50% - 20px)}.mat-horizontal-stepper-header{display:flex;height:72px;overflow:hidden;align-items:center;padding:0 24px}.mat-horizontal-stepper-header .mat-step-icon{margin-right:8px;flex:none}[dir=rtl] .mat-horizontal-stepper-header .mat-step-icon{margin-right:0;margin-left:8px}.mat-stepper-label-position-bottom .mat-horizontal-stepper-header{box-sizing:border-box;flex-direction:column;height:auto}.mat-stepper-label-position-bottom .mat-horizontal-stepper-header:not(:last-child)::after,[dir=rtl] .mat-stepper-label-position-bottom .mat-horizontal-stepper-header:not(:first-child)::after{right:0}.mat-stepper-label-position-bottom .mat-horizontal-stepper-header:not(:first-child)::before,[dir=rtl] .mat-stepper-label-position-bottom .mat-horizontal-stepper-header:not(:last-child)::before{left:0}[dir=rtl] .mat-stepper-label-position-bottom .mat-horizontal-stepper-header:last-child::before,[dir=rtl] .mat-stepper-label-position-bottom .mat-horizontal-stepper-header:first-child::after{display:none}.mat-stepper-label-position-bottom .mat-horizontal-stepper-header .mat-step-icon{margin-right:0;margin-left:0}.mat-stepper-label-position-bottom .mat-horizontal-stepper-header .mat-step-label{padding:16px 0 0 0;text-align:center;width:100%}.mat-vertical-stepper-header{display:flex;align-items:center;height:24px}.mat-vertical-stepper-header .mat-step-icon{margin-right:12px}[dir=rtl] .mat-vertical-stepper-header .mat-step-icon{margin-right:0;margin-left:12px}.mat-horizontal-stepper-content{outline:0}.mat-horizontal-stepper-content[aria-expanded=false]{height:0;overflow:hidden}.mat-horizontal-content-container{overflow:hidden;padding:0 24px 24px 24px}.cdk-high-contrast-active .mat-horizontal-content-container{outline:solid 1px}.mat-vertical-content-container{margin-left:36px;border:0;position:relative}.cdk-high-contrast-active .mat-vertical-content-container{outline:solid 1px}[dir=rtl] .mat-vertical-content-container{margin-left:0;margin-right:36px}.mat-stepper-vertical-line::before{content:\"\";position:absolute;left:0;border-left-width:1px;border-left-style:solid}[dir=rtl] .mat-stepper-vertical-line::before{left:auto;right:0}.mat-vertical-stepper-content{overflow:hidden;outline:0}.mat-vertical-content{padding:0 24px 24px 24px}.mat-step:last-child .mat-vertical-content-container{border:none}\n"],
  encapsulation: 2,
  data: {
    animation: [matStepperAnimations.horizontalStepTransition, matStepperAnimations.verticalStepTransition]
  },
  changeDetection: 0
});

(function () {
  (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](MatStepper, [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Component,
    args: [{
      selector: 'mat-stepper, mat-vertical-stepper, mat-horizontal-stepper, [matStepper]',
      exportAs: 'matStepper, matVerticalStepper, matHorizontalStepper',
      inputs: ['selectedIndex'],
      host: {
        '[class.mat-stepper-horizontal]': 'orientation === "horizontal"',
        '[class.mat-stepper-vertical]': 'orientation === "vertical"',
        '[class.mat-stepper-label-position-end]': 'orientation === "horizontal" && labelPosition == "end"',
        '[class.mat-stepper-label-position-bottom]': 'orientation === "horizontal" && labelPosition == "bottom"',
        '[attr.aria-orientation]': 'orientation',
        'role': 'tablist'
      },
      animations: [matStepperAnimations.horizontalStepTransition, matStepperAnimations.verticalStepTransition],
      providers: [{
        provide: _angular_cdk_stepper__WEBPACK_IMPORTED_MODULE_1__.CdkStepper,
        useExisting: MatStepper
      }, {
        provide: MatHorizontalStepper,
        useExisting: MatStepper
      }, {
        provide: MatVerticalStepper,
        useExisting: MatStepper
      }],
      encapsulation: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ViewEncapsulation.None,
      changeDetection: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ChangeDetectionStrategy.OnPush,
      template: "<ng-container [ngSwitch]=\"orientation\">\n  <!-- Horizontal stepper -->\n  <ng-container *ngSwitchCase=\"'horizontal'\">\n    <div class=\"mat-horizontal-stepper-header-container\">\n      <ng-container *ngFor=\"let step of steps; let i = index; let isLast = last\">\n        <ng-container\n          [ngTemplateOutlet]=\"stepTemplate\"\n          [ngTemplateOutletContext]=\"{step: step, i: i}\"></ng-container>\n        <div *ngIf=\"!isLast\" class=\"mat-stepper-horizontal-line\"></div>\n      </ng-container>\n    </div>\n\n    <div class=\"mat-horizontal-content-container\">\n      <div *ngFor=\"let step of steps; let i = index\"\n           class=\"mat-horizontal-stepper-content\" role=\"tabpanel\"\n           [@horizontalStepTransition]=\"_getAnimationDirection(i)\"\n           (@horizontalStepTransition.done)=\"_animationDone.next($event)\"\n           [id]=\"_getStepContentId(i)\"\n           [attr.aria-labelledby]=\"_getStepLabelId(i)\"\n           [attr.aria-expanded]=\"selectedIndex === i\">\n        <ng-container [ngTemplateOutlet]=\"step.content\"></ng-container>\n      </div>\n    </div>\n  </ng-container>\n\n  <!-- Vertical stepper -->\n  <ng-container *ngSwitchCase=\"'vertical'\">\n    <div class=\"mat-step\" *ngFor=\"let step of steps; let i = index; let isLast = last\">\n      <ng-container\n        [ngTemplateOutlet]=\"stepTemplate\"\n        [ngTemplateOutletContext]=\"{step: step, i: i}\"></ng-container>\n      <div class=\"mat-vertical-content-container\" [class.mat-stepper-vertical-line]=\"!isLast\">\n        <div class=\"mat-vertical-stepper-content\" role=\"tabpanel\"\n             [@verticalStepTransition]=\"_getAnimationDirection(i)\"\n             (@verticalStepTransition.done)=\"_animationDone.next($event)\"\n             [id]=\"_getStepContentId(i)\"\n             [attr.aria-labelledby]=\"_getStepLabelId(i)\"\n             [attr.aria-expanded]=\"selectedIndex === i\">\n          <div class=\"mat-vertical-content\">\n            <ng-container [ngTemplateOutlet]=\"step.content\"></ng-container>\n          </div>\n        </div>\n      </div>\n    </div>\n  </ng-container>\n\n</ng-container>\n\n<!-- Common step templating -->\n<ng-template let-step=\"step\" let-i=\"i\" #stepTemplate>\n  <mat-step-header\n    [class.mat-horizontal-stepper-header]=\"orientation === 'horizontal'\"\n    [class.mat-vertical-stepper-header]=\"orientation === 'vertical'\"\n    (click)=\"step.select()\"\n    (keydown)=\"_onKeydown($event)\"\n    [tabIndex]=\"_getFocusIndex() === i ? 0 : -1\"\n    [id]=\"_getStepLabelId(i)\"\n    [attr.aria-posinset]=\"i + 1\"\n    [attr.aria-setsize]=\"steps.length\"\n    [attr.aria-controls]=\"_getStepContentId(i)\"\n    [attr.aria-selected]=\"selectedIndex == i\"\n    [attr.aria-label]=\"step.ariaLabel || null\"\n    [attr.aria-labelledby]=\"(!step.ariaLabel && step.ariaLabelledby) ? step.ariaLabelledby : null\"\n    [attr.aria-disabled]=\"_stepIsNavigable(i, step) ? null : true\"\n    [index]=\"i\"\n    [state]=\"_getIndicatorType(i, step.state)\"\n    [label]=\"step.stepLabel || step.label\"\n    [selected]=\"selectedIndex === i\"\n    [active]=\"_stepIsNavigable(i, step)\"\n    [optional]=\"step.optional\"\n    [errorMessage]=\"step.errorMessage\"\n    [iconOverrides]=\"_iconOverrides\"\n    [disableRipple]=\"disableRipple || !_stepIsNavigable(i, step)\"\n    [color]=\"step.color || color\"></mat-step-header>\n</ng-template>\n",
      styles: [".mat-stepper-vertical,.mat-stepper-horizontal{display:block}.mat-horizontal-stepper-header-container{white-space:nowrap;display:flex;align-items:center}.mat-stepper-label-position-bottom .mat-horizontal-stepper-header-container{align-items:flex-start}.mat-stepper-horizontal-line{border-top-width:1px;border-top-style:solid;flex:auto;height:0;margin:0 -16px;min-width:32px}.mat-stepper-label-position-bottom .mat-stepper-horizontal-line{margin:0;min-width:0;position:relative}.mat-stepper-label-position-bottom .mat-horizontal-stepper-header:not(:first-child)::before,[dir=rtl] .mat-stepper-label-position-bottom .mat-horizontal-stepper-header:not(:last-child)::before,.mat-stepper-label-position-bottom .mat-horizontal-stepper-header:not(:last-child)::after,[dir=rtl] .mat-stepper-label-position-bottom .mat-horizontal-stepper-header:not(:first-child)::after{border-top-width:1px;border-top-style:solid;content:\"\";display:inline-block;height:0;position:absolute;width:calc(50% - 20px)}.mat-horizontal-stepper-header{display:flex;height:72px;overflow:hidden;align-items:center;padding:0 24px}.mat-horizontal-stepper-header .mat-step-icon{margin-right:8px;flex:none}[dir=rtl] .mat-horizontal-stepper-header .mat-step-icon{margin-right:0;margin-left:8px}.mat-stepper-label-position-bottom .mat-horizontal-stepper-header{box-sizing:border-box;flex-direction:column;height:auto}.mat-stepper-label-position-bottom .mat-horizontal-stepper-header:not(:last-child)::after,[dir=rtl] .mat-stepper-label-position-bottom .mat-horizontal-stepper-header:not(:first-child)::after{right:0}.mat-stepper-label-position-bottom .mat-horizontal-stepper-header:not(:first-child)::before,[dir=rtl] .mat-stepper-label-position-bottom .mat-horizontal-stepper-header:not(:last-child)::before{left:0}[dir=rtl] .mat-stepper-label-position-bottom .mat-horizontal-stepper-header:last-child::before,[dir=rtl] .mat-stepper-label-position-bottom .mat-horizontal-stepper-header:first-child::after{display:none}.mat-stepper-label-position-bottom .mat-horizontal-stepper-header .mat-step-icon{margin-right:0;margin-left:0}.mat-stepper-label-position-bottom .mat-horizontal-stepper-header .mat-step-label{padding:16px 0 0 0;text-align:center;width:100%}.mat-vertical-stepper-header{display:flex;align-items:center;height:24px}.mat-vertical-stepper-header .mat-step-icon{margin-right:12px}[dir=rtl] .mat-vertical-stepper-header .mat-step-icon{margin-right:0;margin-left:12px}.mat-horizontal-stepper-content{outline:0}.mat-horizontal-stepper-content[aria-expanded=false]{height:0;overflow:hidden}.mat-horizontal-content-container{overflow:hidden;padding:0 24px 24px 24px}.cdk-high-contrast-active .mat-horizontal-content-container{outline:solid 1px}.mat-vertical-content-container{margin-left:36px;border:0;position:relative}.cdk-high-contrast-active .mat-vertical-content-container{outline:solid 1px}[dir=rtl] .mat-vertical-content-container{margin-left:0;margin-right:36px}.mat-stepper-vertical-line::before{content:\"\";position:absolute;left:0;border-left-width:1px;border-left-style:solid}[dir=rtl] .mat-stepper-vertical-line::before{left:auto;right:0}.mat-vertical-stepper-content{overflow:hidden;outline:0}.mat-vertical-content{padding:0 24px 24px 24px}.mat-step:last-child .mat-vertical-content-container{border:none}\n"]
    }]
  }], function () {
    return [{
      type: _angular_cdk_bidi__WEBPACK_IMPORTED_MODULE_15__.Directionality,
      decorators: [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Optional
      }]
    }, {
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ChangeDetectorRef
    }, {
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ElementRef
    }, {
      type: undefined,
      decorators: [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Inject,
        args: [_angular_common__WEBPACK_IMPORTED_MODULE_5__.DOCUMENT]
      }]
    }];
  }, {
    _stepHeader: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ViewChildren,
      args: [MatStepHeader]
    }],
    _steps: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ContentChildren,
      args: [MatStep, {
        descendants: true
      }]
    }],
    _icons: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ContentChildren,
      args: [MatStepperIcon, {
        descendants: true
      }]
    }],
    animationDone: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Output
    }],
    disableRipple: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    color: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    labelPosition: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }]
  });
})();
/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/** Button that moves to the next step in a stepper workflow. */


class MatStepperNext extends _angular_cdk_stepper__WEBPACK_IMPORTED_MODULE_1__.CdkStepperNext {}

MatStepperNext.ɵfac = /* @__PURE__ */function () {
  let ɵMatStepperNext_BaseFactory;
  return function MatStepperNext_Factory(t) {
    return (ɵMatStepperNext_BaseFactory || (ɵMatStepperNext_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetInheritedFactory"](MatStepperNext)))(t || MatStepperNext);
  };
}();

MatStepperNext.ɵdir = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineDirective"]({
  type: MatStepperNext,
  selectors: [["button", "matStepperNext", ""]],
  hostAttrs: [1, "mat-stepper-next"],
  hostVars: 1,
  hostBindings: function MatStepperNext_HostBindings(rf, ctx) {
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵhostProperty"]("type", ctx.type);
    }
  },
  inputs: {
    type: "type"
  },
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵInheritDefinitionFeature"]]
});

(function () {
  (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](MatStepperNext, [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Directive,
    args: [{
      selector: 'button[matStepperNext]',
      host: {
        'class': 'mat-stepper-next',
        '[type]': 'type'
      },
      inputs: ['type']
    }]
  }], null, null);
})();
/** Button that moves to the previous step in a stepper workflow. */


class MatStepperPrevious extends _angular_cdk_stepper__WEBPACK_IMPORTED_MODULE_1__.CdkStepperPrevious {}

MatStepperPrevious.ɵfac = /* @__PURE__ */function () {
  let ɵMatStepperPrevious_BaseFactory;
  return function MatStepperPrevious_Factory(t) {
    return (ɵMatStepperPrevious_BaseFactory || (ɵMatStepperPrevious_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetInheritedFactory"](MatStepperPrevious)))(t || MatStepperPrevious);
  };
}();

MatStepperPrevious.ɵdir = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineDirective"]({
  type: MatStepperPrevious,
  selectors: [["button", "matStepperPrevious", ""]],
  hostAttrs: [1, "mat-stepper-previous"],
  hostVars: 1,
  hostBindings: function MatStepperPrevious_HostBindings(rf, ctx) {
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵhostProperty"]("type", ctx.type);
    }
  },
  inputs: {
    type: "type"
  },
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵInheritDefinitionFeature"]]
});

(function () {
  (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](MatStepperPrevious, [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Directive,
    args: [{
      selector: 'button[matStepperPrevious]',
      host: {
        'class': 'mat-stepper-previous',
        '[type]': 'type'
      },
      inputs: ['type']
    }]
  }], null, null);
})();
/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */


class MatStepperModule {}

MatStepperModule.ɵfac = function MatStepperModule_Factory(t) {
  return new (t || MatStepperModule)();
};

MatStepperModule.ɵmod = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineNgModule"]({
  type: MatStepperModule,
  declarations: [MatHorizontalStepper, MatVerticalStepper, MatStep, MatStepLabel, MatStepper, MatStepperNext, MatStepperPrevious, MatStepHeader, MatStepperIcon, MatStepContent],
  imports: [_angular_material_core__WEBPACK_IMPORTED_MODULE_3__.MatCommonModule, _angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule, _angular_cdk_portal__WEBPACK_IMPORTED_MODULE_12__.PortalModule, _angular_material_button__WEBPACK_IMPORTED_MODULE_16__.MatButtonModule, _angular_cdk_stepper__WEBPACK_IMPORTED_MODULE_1__.CdkStepperModule, _angular_material_icon__WEBPACK_IMPORTED_MODULE_6__.MatIconModule, _angular_material_core__WEBPACK_IMPORTED_MODULE_3__.MatRippleModule],
  exports: [_angular_material_core__WEBPACK_IMPORTED_MODULE_3__.MatCommonModule, MatStep, MatStepLabel, MatStepper, MatStepperNext, MatStepperPrevious, MatStepHeader, MatStepperIcon, MatStepContent]
});
MatStepperModule.ɵinj = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjector"]({
  providers: [MAT_STEPPER_INTL_PROVIDER, _angular_material_core__WEBPACK_IMPORTED_MODULE_3__.ErrorStateMatcher],
  imports: [[_angular_material_core__WEBPACK_IMPORTED_MODULE_3__.MatCommonModule, _angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule, _angular_cdk_portal__WEBPACK_IMPORTED_MODULE_12__.PortalModule, _angular_material_button__WEBPACK_IMPORTED_MODULE_16__.MatButtonModule, _angular_cdk_stepper__WEBPACK_IMPORTED_MODULE_1__.CdkStepperModule, _angular_material_icon__WEBPACK_IMPORTED_MODULE_6__.MatIconModule, _angular_material_core__WEBPACK_IMPORTED_MODULE_3__.MatRippleModule], _angular_material_core__WEBPACK_IMPORTED_MODULE_3__.MatCommonModule]
});

(function () {
  (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](MatStepperModule, [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.NgModule,
    args: [{
      imports: [_angular_material_core__WEBPACK_IMPORTED_MODULE_3__.MatCommonModule, _angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule, _angular_cdk_portal__WEBPACK_IMPORTED_MODULE_12__.PortalModule, _angular_material_button__WEBPACK_IMPORTED_MODULE_16__.MatButtonModule, _angular_cdk_stepper__WEBPACK_IMPORTED_MODULE_1__.CdkStepperModule, _angular_material_icon__WEBPACK_IMPORTED_MODULE_6__.MatIconModule, _angular_material_core__WEBPACK_IMPORTED_MODULE_3__.MatRippleModule],
      exports: [_angular_material_core__WEBPACK_IMPORTED_MODULE_3__.MatCommonModule, MatStep, MatStepLabel, MatStepper, MatStepperNext, MatStepperPrevious, MatStepHeader, MatStepperIcon, MatStepContent],
      declarations: [MatHorizontalStepper, MatVerticalStepper, MatStep, MatStepLabel, MatStepper, MatStepperNext, MatStepperPrevious, MatStepHeader, MatStepperIcon, MatStepContent],
      providers: [MAT_STEPPER_INTL_PROVIDER, _angular_material_core__WEBPACK_IMPORTED_MODULE_3__.ErrorStateMatcher]
    }]
  }], null, null);
})();
/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/**
 * Generated bundle index. Do not edit.
 */




/***/ })

}]);
//# sourceMappingURL=src_app_pages_edit-profile_edit-profile_module_ts.js.map