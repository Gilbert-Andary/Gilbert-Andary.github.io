"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_biometrics_biometrics_module_ts"],{

/***/ 7013:
/*!***************************************************************!*\
  !*** ./src/app/pages/biometrics/biometrics-routing.module.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "BiometricsPageRoutingModule": () => (/* binding */ BiometricsPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _biometrics_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./biometrics.page */ 25697);
/* harmony import */ var _face_id_face_id_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./face-id/face-id.component */ 75066);
/* harmony import */ var _finger_finger_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./finger/finger.component */ 10535);






const routes = [
    {
        path: '',
        component: _biometrics_page__WEBPACK_IMPORTED_MODULE_0__.BiometricsPage,
        children: [
            {
                path: 'finger',
                component: _finger_finger_component__WEBPACK_IMPORTED_MODULE_2__.FingerComponent,
            },
            {
                path: 'face-id',
                component: _face_id_face_id_component__WEBPACK_IMPORTED_MODULE_1__.FaceIdComponent,
            },
        ],
    },
];
let BiometricsPageRoutingModule = class BiometricsPageRoutingModule {
};
BiometricsPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_5__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_5__.RouterModule],
    })
], BiometricsPageRoutingModule);



/***/ }),

/***/ 32292:
/*!*******************************************************!*\
  !*** ./src/app/pages/biometrics/biometrics.module.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "BiometricsPageModule": () => (/* binding */ BiometricsPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _biometrics_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./biometrics-routing.module */ 7013);
/* harmony import */ var _biometrics_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./biometrics.page */ 25697);
/* harmony import */ var src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/shared/shared.module */ 44466);
/* harmony import */ var _finger_finger_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./finger/finger.component */ 10535);
/* harmony import */ var _face_id_face_id_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./face-id/face-id.component */ 75066);










let BiometricsPageModule = class BiometricsPageModule {
};
BiometricsPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.NgModule)({
        imports: [
            src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_2__.SharedModule,
            _angular_common__WEBPACK_IMPORTED_MODULE_7__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_8__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.IonicModule,
            _biometrics_routing_module__WEBPACK_IMPORTED_MODULE_0__.BiometricsPageRoutingModule,
        ],
        declarations: [_biometrics_page__WEBPACK_IMPORTED_MODULE_1__.BiometricsPage, _finger_finger_component__WEBPACK_IMPORTED_MODULE_3__.FingerComponent, _face_id_face_id_component__WEBPACK_IMPORTED_MODULE_4__.FaceIdComponent],
    })
], BiometricsPageModule);



/***/ }),

/***/ 25697:
/*!*****************************************************!*\
  !*** ./src/app/pages/biometrics/biometrics.page.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "BiometricsPage": () => (/* binding */ BiometricsPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _biometrics_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./biometrics.page.html?ngResource */ 4809);
/* harmony import */ var _biometrics_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./biometrics.page.scss?ngResource */ 31980);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/shared/data/enum/screen */ 68302);
/* harmony import */ var _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/storage-angular */ 80190);
/* harmony import */ var capacitor_native_biometric__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! capacitor-native-biometric */ 31506);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/shared/data/constants */ 74676);










let BiometricsPage = class BiometricsPage {
    constructor(router, location, storage) {
        this.router = router;
        this.location = location;
        this.storage = storage;
        this.isSupportTouchID = false;
        this.isSupportFaceID = true;
        // Set language for i18n
        this.setupBiometricAvailableSetting();
    }
    ngOnInit() { }
    setupBiometricAvailableSetting() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            console.log('Setting biometric');
            capacitor_native_biometric__WEBPACK_IMPORTED_MODULE_3__.NativeBiometric.isAvailable().then((result) => {
                if (result.biometryType == capacitor_native_biometric__WEBPACK_IMPORTED_MODULE_3__.BiometryType.FACE_AUTHENTICATION
                    || result.biometryType == capacitor_native_biometric__WEBPACK_IMPORTED_MODULE_3__.BiometryType.FACE_ID
                    || result.biometryType == capacitor_native_biometric__WEBPACK_IMPORTED_MODULE_3__.BiometryType.IRIS_AUTHENTICATION) {
                    this.isSupportFaceID = true;
                }
                if (result.biometryType == capacitor_native_biometric__WEBPACK_IMPORTED_MODULE_3__.BiometryType.FINGERPRINT
                    || result.biometryType == capacitor_native_biometric__WEBPACK_IMPORTED_MODULE_3__.BiometryType.TOUCH_ID) {
                    this.isSupportFaceID = true;
                }
            }, () => {
                // Couldn't check availability
            });
        });
    }
    finger() {
        this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__.Screens.Finger]);
        this.verifyBiometricAuthentication();
    }
    faceId() {
        this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__.Screens.FaceId]);
        this.verifyBiometricAuthentication();
    }
    setBiometricSetting(value) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            yield this.storage.set(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_4__.Constants.BIOMETRIC_READY, value ? 'true' : 'false');
            this.location.historyGo(-2);
        });
    }
    verifyBiometricAuthentication() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            capacitor_native_biometric__WEBPACK_IMPORTED_MODULE_3__.NativeBiometric.verifyIdentity({
                reason: 'User Biometric to login',
                title: 'Log in',
                subtitle: 'Maybe add subtitle here?',
                description: 'Maybe a description too?',
            }).then(() => {
                // Authentication successful, login here
                this.setBiometricSetting(true);
            }, () => {
                // Failed to authenticate
            });
        });
    }
};
BiometricsPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_6__.Router },
    { type: _angular_common__WEBPACK_IMPORTED_MODULE_7__.Location },
    { type: _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_8__.Storage }
];
BiometricsPage = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_9__.Component)({
        selector: 'app-biometrics',
        template: _biometrics_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_biometrics_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], BiometricsPage);



/***/ }),

/***/ 75066:
/*!***************************************************************!*\
  !*** ./src/app/pages/biometrics/face-id/face-id.component.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FaceIdComponent": () => (/* binding */ FaceIdComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _face_id_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./face-id.component.html?ngResource */ 2617);
/* harmony import */ var _face_id_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./face-id.component.scss?ngResource */ 68908);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);




let FaceIdComponent = class FaceIdComponent {
    constructor() {
        // Set language for i18n
    }
    ngOnInit() { }
};
FaceIdComponent.ctorParameters = () => [];
FaceIdComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-face-id',
        template: _face_id_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_face_id_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], FaceIdComponent);



/***/ }),

/***/ 10535:
/*!*************************************************************!*\
  !*** ./src/app/pages/biometrics/finger/finger.component.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FingerComponent": () => (/* binding */ FingerComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _finger_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./finger.component.html?ngResource */ 16872);
/* harmony import */ var _finger_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./finger.component.scss?ngResource */ 15343);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);




let FingerComponent = class FingerComponent {
    constructor() {
        // Set language for i18n
    }
    ngOnInit() { }
};
FingerComponent.ctorParameters = () => [];
FingerComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-finger',
        template: _finger_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_finger_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], FingerComponent);



/***/ }),

/***/ 31980:
/*!******************************************************************!*\
  !*** ./src/app/pages/biometrics/biometrics.page.scss?ngResource ***!
  \******************************************************************/
/***/ ((module) => {

module.exports = ".biometrics {\n  background: #3c3c3c;\n  height: 100%;\n}\n.biometrics p {\n  font-family: Roboto;\n  font-style: normal;\n  font-weight: bold;\n  font-size: 30px;\n  line-height: 35px;\n  text-align: center;\n  color: #ffffff;\n  margin: 79px 4.8% 0;\n}\n.biometrics .group-biometric {\n  margin: 120px auto 0;\n  max-width: 500px;\n}\n.biometrics .group-biometric .btn-biometrics {\n  margin: 41px 40px 19px 40px;\n  text-align: center;\n  font-size: 20px;\n  color: #ffffff;\n  height: 55px;\n  border: 1.5px solid #747474;\n  line-height: 50px;\n  box-sizing: border-box;\n  background-color: transparent;\n  border-radius: 52px;\n}\n.biometrics .group-biometric .btn-biometrics img {\n  position: relative;\n  top: 9%;\n  right: 5%;\n}\n@media screen and (max-height: 740px) {\n  .biometrics .group-biometric {\n    margin: 37px auto 0;\n    max-width: 500px;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImJpb21ldHJpY3MucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsbUJBQUE7RUFDQSxZQUFBO0FBQ0Y7QUFBRTtFQUNFLG1CQUFBO0VBQ0Esa0JBQUE7RUFDQSxpQkFBQTtFQUNBLGVBQUE7RUFDQSxpQkFBQTtFQUNBLGtCQUFBO0VBRUEsY0FBQTtFQUNBLG1CQUFBO0FBQ0o7QUFFRTtFQUNFLG9CQUFBO0VBQ0EsZ0JBQUE7QUFBSjtBQUNJO0VBQ0UsMkJBQUE7RUFDQSxrQkFBQTtFQUNBLGVBQUE7RUFDQSxjQUFBO0VBQ0EsWUFBQTtFQUNBLDJCQUFBO0VBQ0EsaUJBQUE7RUFDQSxzQkFBQTtFQUNBLDZCQUFBO0VBQ0EsbUJBQUE7QUFDTjtBQUNNO0VBQ0Usa0JBQUE7RUFDQSxPQUFBO0VBQ0EsU0FBQTtBQUNSO0FBS0E7RUFFSTtJQUNFLG1CQUFBO0lBQ0EsZ0JBQUE7RUFISjtBQUNGIiwiZmlsZSI6ImJpb21ldHJpY3MucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmJpb21ldHJpY3Mge1xyXG4gIGJhY2tncm91bmQ6ICMzYzNjM2M7XHJcbiAgaGVpZ2h0OiAxMDAlO1xyXG4gIHAge1xyXG4gICAgZm9udC1mYW1pbHk6IFJvYm90bztcclxuICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcclxuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG4gICAgZm9udC1zaXplOiAzMHB4O1xyXG4gICAgbGluZS1oZWlnaHQ6IDM1cHg7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcblxyXG4gICAgY29sb3I6ICNmZmZmZmY7XHJcbiAgICBtYXJnaW46IDc5cHggNC44JSAwO1xyXG4gIH1cclxuXHJcbiAgLmdyb3VwLWJpb21ldHJpYyB7XHJcbiAgICBtYXJnaW46IDEyMHB4IGF1dG8gMDtcclxuICAgIG1heC13aWR0aDogNTAwcHg7XHJcbiAgICAuYnRuLWJpb21ldHJpY3Mge1xyXG4gICAgICBtYXJnaW46IDQxcHggNDBweCAxOXB4IDQwcHg7XHJcbiAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgICAgZm9udC1zaXplOiAyMHB4O1xyXG4gICAgICBjb2xvcjogI2ZmZmZmZjtcclxuICAgICAgaGVpZ2h0OiA1NXB4O1xyXG4gICAgICBib3JkZXI6IDEuNXB4IHNvbGlkICM3NDc0NzQ7XHJcbiAgICAgIGxpbmUtaGVpZ2h0OiA1MHB4O1xyXG4gICAgICBib3gtc2l6aW5nOiBib3JkZXItYm94O1xyXG4gICAgICBiYWNrZ3JvdW5kLWNvbG9yOiB0cmFuc3BhcmVudDtcclxuICAgICAgYm9yZGVyLXJhZGl1czogNTJweDtcclxuXHJcbiAgICAgIGltZyB7XHJcbiAgICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgICAgIHRvcDogOSU7XHJcbiAgICAgICAgcmlnaHQ6IDUlO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfVxyXG59XHJcblxyXG5AbWVkaWEgc2NyZWVuIGFuZCAobWF4LWhlaWdodDogNzQwcHgpIHtcclxuICAuYmlvbWV0cmljcyB7XHJcbiAgICAuZ3JvdXAtYmlvbWV0cmljIHtcclxuICAgICAgbWFyZ2luOiAzN3B4IGF1dG8gMDtcclxuICAgICAgbWF4LXdpZHRoOiA1MDBweDtcclxuICAgIH1cclxuICB9XHJcbn1cclxuIl19 */";

/***/ }),

/***/ 68908:
/*!****************************************************************************!*\
  !*** ./src/app/pages/biometrics/face-id/face-id.component.scss?ngResource ***!
  \****************************************************************************/
/***/ ((module) => {

module.exports = ".faceid-container {\n  position: absolute;\n  bottom: 0;\n  background: #ffffff;\n  left: 0;\n  right: 0;\n}\n.faceid-container p {\n  font-family: Roboto;\n  font-style: normal;\n  font-weight: normal;\n  font-size: 19px;\n  line-height: 22px;\n  text-align: center;\n  margin: 0 13.07%;\n  color: #242424;\n  margin-top: 40px;\n}\n.faceid-container .auth {\n  text-align: center;\n  margin-top: 25px;\n  margin-bottom: 77px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZhY2UtaWQuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxrQkFBQTtFQUNBLFNBQUE7RUFDQSxtQkFBQTtFQUNBLE9BQUE7RUFDQSxRQUFBO0FBQ0Y7QUFBRTtFQUNFLG1CQUFBO0VBQ0Esa0JBQUE7RUFDQSxtQkFBQTtFQUNBLGVBQUE7RUFDQSxpQkFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7RUFFQSxjQUFBO0VBQ0EsZ0JBQUE7QUFDSjtBQUNFO0VBQ0Usa0JBQUE7RUFDQSxnQkFBQTtFQUNBLG1CQUFBO0FBQ0oiLCJmaWxlIjoiZmFjZS1pZC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5mYWNlaWQtY29udGFpbmVyIHtcclxuICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgYm90dG9tOiAwO1xyXG4gIGJhY2tncm91bmQ6ICNmZmZmZmY7XHJcbiAgbGVmdDogMDtcclxuICByaWdodDogMDtcclxuICBwIHtcclxuICAgIGZvbnQtZmFtaWx5OiBSb2JvdG87XHJcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XHJcbiAgICBmb250LXdlaWdodDogbm9ybWFsO1xyXG4gICAgZm9udC1zaXplOiAxOXB4O1xyXG4gICAgbGluZS1oZWlnaHQ6IDIycHg7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBtYXJnaW46IDAgMTMuMDclO1xyXG5cclxuICAgIGNvbG9yOiAjMjQyNDI0O1xyXG4gICAgbWFyZ2luLXRvcDogNDBweDtcclxuICB9XHJcbiAgLmF1dGgge1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgbWFyZ2luLXRvcDogMjVweDtcclxuICAgIG1hcmdpbi1ib3R0b206IDc3cHg7XHJcbiAgfVxyXG59XHJcbiJdfQ== */";

/***/ }),

/***/ 15343:
/*!**************************************************************************!*\
  !*** ./src/app/pages/biometrics/finger/finger.component.scss?ngResource ***!
  \**************************************************************************/
/***/ ((module) => {

module.exports = ".finger-container {\n  position: absolute;\n  bottom: 0;\n  background: #ffffff;\n  left: 0;\n  right: 0;\n}\n.finger-container p {\n  font-family: Roboto;\n  font-style: normal;\n  font-weight: normal;\n  font-size: 19px;\n  line-height: 22px;\n  text-align: center;\n  margin: 0 13.07%;\n  color: #242424;\n  margin-top: 40px;\n}\n.finger-container .auth {\n  text-align: center;\n  margin-top: 25px;\n  margin-bottom: 77px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbmdlci5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGtCQUFBO0VBQ0EsU0FBQTtFQUNBLG1CQUFBO0VBQ0EsT0FBQTtFQUNBLFFBQUE7QUFDRjtBQUFFO0VBQ0UsbUJBQUE7RUFDQSxrQkFBQTtFQUNBLG1CQUFBO0VBQ0EsZUFBQTtFQUNBLGlCQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtFQUVBLGNBQUE7RUFDQSxnQkFBQTtBQUNKO0FBQ0U7RUFDRSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0EsbUJBQUE7QUFDSiIsImZpbGUiOiJmaW5nZXIuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuZmluZ2VyLWNvbnRhaW5lciB7XHJcbiAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gIGJvdHRvbTogMDtcclxuICBiYWNrZ3JvdW5kOiAjZmZmZmZmO1xyXG4gIGxlZnQ6IDA7XHJcbiAgcmlnaHQ6IDA7XHJcbiAgcCB7XHJcbiAgICBmb250LWZhbWlseTogUm9ib3RvO1xyXG4gICAgZm9udC1zdHlsZTogbm9ybWFsO1xyXG4gICAgZm9udC13ZWlnaHQ6IG5vcm1hbDtcclxuICAgIGZvbnQtc2l6ZTogMTlweDtcclxuICAgIGxpbmUtaGVpZ2h0OiAyMnB4O1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgbWFyZ2luOiAwIDEzLjA3JTtcclxuXHJcbiAgICBjb2xvcjogIzI0MjQyNDtcclxuICAgIG1hcmdpbi10b3A6IDQwcHg7XHJcbiAgfVxyXG4gIC5hdXRoIHtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIG1hcmdpbi10b3A6IDI1cHg7XHJcbiAgICBtYXJnaW4tYm90dG9tOiA3N3B4O1xyXG4gIH1cclxufVxyXG4iXX0= */";

/***/ }),

/***/ 4809:
/*!******************************************************************!*\
  !*** ./src/app/pages/biometrics/biometrics.page.html?ngResource ***!
  \******************************************************************/
/***/ ((module) => {

module.exports = "<div class=\"biometrics\">\r\n  <p>{{'biometric.title' | translate}}</p>\r\n  <div class=\"group-biometric\">\r\n    <div class=\"btn-biometrics\" (click)=\"finger()\" [hidden]=\"!isSupportTouchID\">\r\n      <img src=\"../../../assets/icon/finger.svg\" /> {{'biometric.finger' |\r\n      translate}}\r\n    </div>\r\n    <div class=\"btn-biometrics\" (click)=\"faceId()\" [hidden]=\"!isSupportFaceID\">\r\n      <img src=\"../../../assets/icon/login-biometric.svg\" /> {{'biometric.faceId' | translate}}\r\n    </div>\r\n  </div>\r\n  <router-outlet></router-outlet>\r\n</div>\r\n";

/***/ }),

/***/ 2617:
/*!****************************************************************************!*\
  !*** ./src/app/pages/biometrics/face-id/face-id.component.html?ngResource ***!
  \****************************************************************************/
/***/ ((module) => {

module.exports = "<div class=\"faceid-container\">\r\n  <p>{{ \"faceId.title\" | translate }}</p>\r\n  <div class=\"auth\">\r\n    <img src=\"../../../../../assets/icon/faceID-auth.svg\" alt=\"\" />\r\n  </div>\r\n</div>\r\n";

/***/ }),

/***/ 16872:
/*!**************************************************************************!*\
  !*** ./src/app/pages/biometrics/finger/finger.component.html?ngResource ***!
  \**************************************************************************/
/***/ ((module) => {

module.exports = "<div class=\"finger-container\">\r\n  <p>{{ \"finger.title\" | translate }}</p>\r\n  <div class=\"auth\">\r\n    <img src=\"../../../../../assets/icon/finger-auth.svg\" alt=\"\" />\r\n  </div>\r\n</div>\r\n";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_biometrics_biometrics_module_ts.js.map