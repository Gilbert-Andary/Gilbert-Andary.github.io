"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_screen-navigator_screen-navigator_module_ts"],{

/***/ 55879:
/*!***************************************************************************!*\
  !*** ./src/app/pages/screen-navigator/screen-navigator-routing.module.ts ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ScreenNavigatorPageRoutingModule": () => (/* binding */ ScreenNavigatorPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _screen_navigator_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./screen-navigator.page */ 4922);




const routes = [
    {
        path: '',
        component: _screen_navigator_page__WEBPACK_IMPORTED_MODULE_0__.ScreenNavigatorPage
    }
];
let ScreenNavigatorPageRoutingModule = class ScreenNavigatorPageRoutingModule {
};
ScreenNavigatorPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], ScreenNavigatorPageRoutingModule);



/***/ }),

/***/ 30481:
/*!*******************************************************************!*\
  !*** ./src/app/pages/screen-navigator/screen-navigator.module.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ScreenNavigatorPageModule": () => (/* binding */ ScreenNavigatorPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _screen_navigator_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./screen-navigator-routing.module */ 55879);
/* harmony import */ var _screen_navigator_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./screen-navigator.page */ 4922);







let ScreenNavigatorPageModule = class ScreenNavigatorPageModule {
};
ScreenNavigatorPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _screen_navigator_routing_module__WEBPACK_IMPORTED_MODULE_0__.ScreenNavigatorPageRoutingModule
        ],
        declarations: [_screen_navigator_page__WEBPACK_IMPORTED_MODULE_1__.ScreenNavigatorPage]
    })
], ScreenNavigatorPageModule);



/***/ }),

/***/ 4922:
/*!*****************************************************************!*\
  !*** ./src/app/pages/screen-navigator/screen-navigator.page.ts ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ScreenNavigatorPage": () => (/* binding */ ScreenNavigatorPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _screen_navigator_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./screen-navigator.page.html?ngResource */ 80245);
/* harmony import */ var _screen_navigator_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./screen-navigator.page.scss?ngResource */ 17214);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/storage-angular */ 80190);
/* harmony import */ var src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/shared/data/enum/screen */ 68302);
/* harmony import */ var src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/shared/data/constants */ 74676);
/* harmony import */ var src_app_service_signin_signin_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/service/signin/signin.service */ 91265);









let ScreenNavigatorPage = class ScreenNavigatorPage {
    constructor(authService, storage, router) {
        this.authService = authService;
        this.storage = storage;
        this.router = router;
        this.startupNavigator();
    }
    ngOnInit() {
    }
    startupNavigator() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            const language = window.localStorage.getItem(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_3__.Constants.PREFERED_LANGUAGE);
            if (language != '' && language != null) {
                const staySignIn = yield this.storage.get(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_3__.Constants.STAY_SIGN_IN);
                if (!staySignIn) {
                    this.authService.eraseUserData();
                    this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__.Screens.SignIn]);
                }
                else {
                    const locked = window.localStorage.getItem(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_3__.Constants.LOCKED);
                    // const policy = await this.storage.get(Constants.POLICY_ADDED);
                    // if (policy != null && policy != "") {
                    //   this.router.navigate(["/" + Screens.HomeInsurance]);
                    // } else {
                    //   this.router.navigate(["/" + Screens.AddPolicy]);
                    // }
                    if (this.authService.isLoggedIn() && locked === '1') {
                        this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__.Screens.lockScreen]);
                    }
                    else {
                        this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__.Screens.Home]);
                    }
                }
            }
            else {
                this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__.Screens.GetStarted]);
                // this.storage.get(Constants.PLATFORM).then(platform => {
                //   if (platform === PlatformEnum.Browser) {
                //     this.router.navigate(['/' + Screens.Welcome]);
                //   } else {
                //     this.router.navigate(['/' + Screens.LanguageSelection]);
                //   }
                // })
            }
        });
    }
};
ScreenNavigatorPage.ctorParameters = () => [
    { type: src_app_service_signin_signin_service__WEBPACK_IMPORTED_MODULE_4__.SigninService },
    { type: _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_6__.Storage },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_7__.Router }
];
ScreenNavigatorPage = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.Component)({
        selector: 'app-screen-navigator',
        template: _screen_navigator_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_screen_navigator_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], ScreenNavigatorPage);



/***/ }),

/***/ 17214:
/*!******************************************************************************!*\
  !*** ./src/app/pages/screen-navigator/screen-navigator.page.scss?ngResource ***!
  \******************************************************************************/
/***/ ((module) => {

module.exports = ".screen-navigator-container {\n  background-color: #FFFFFF;\n  height: 100%;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNjcmVlbi1uYXZpZ2F0b3IucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0kseUJBQUE7RUFDQSxZQUFBO0FBQ0oiLCJmaWxlIjoic2NyZWVuLW5hdmlnYXRvci5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuc2NyZWVuLW5hdmlnYXRvci1jb250YWluZXIge1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogI0ZGRkZGRjtcclxuICAgIGhlaWdodDogMTAwJTtcclxufSJdfQ== */";

/***/ }),

/***/ 80245:
/*!******************************************************************************!*\
  !*** ./src/app/pages/screen-navigator/screen-navigator.page.html?ngResource ***!
  \******************************************************************************/
/***/ ((module) => {

module.exports = "<div class=\"screen-navigator-container\">\r\n</div>";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_screen-navigator_screen-navigator_module_ts.js.map