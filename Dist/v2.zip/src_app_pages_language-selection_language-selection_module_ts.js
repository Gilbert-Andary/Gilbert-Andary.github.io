"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_language-selection_language-selection_module_ts"],{

/***/ 32042:
/*!*******************************************************************************!*\
  !*** ./src/app/pages/language-selection/language-selection-routing.module.ts ***!
  \*******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LanguageSelectionPageRoutingModule": () => (/* binding */ LanguageSelectionPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _language_selection_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./language-selection.page */ 27095);




const routes = [
    {
        path: '',
        component: _language_selection_page__WEBPACK_IMPORTED_MODULE_0__.LanguageSelectionPage
    }
];
let LanguageSelectionPageRoutingModule = class LanguageSelectionPageRoutingModule {
};
LanguageSelectionPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], LanguageSelectionPageRoutingModule);



/***/ }),

/***/ 53458:
/*!***********************************************************************!*\
  !*** ./src/app/pages/language-selection/language-selection.module.ts ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LanguageSelectionPageModule": () => (/* binding */ LanguageSelectionPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _language_selection_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./language-selection-routing.module */ 32042);
/* harmony import */ var _language_selection_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./language-selection.page */ 27095);
/* harmony import */ var src_app_service_service_register_service_register_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/service/service-register/service-register.service */ 12829);
/* harmony import */ var src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/shared/shared.module */ 44466);









let LanguageSelectionPageModule = class LanguageSelectionPageModule {
};
LanguageSelectionPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_6__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.IonicModule,
            src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_3__.SharedModule,
            _language_selection_routing_module__WEBPACK_IMPORTED_MODULE_0__.LanguageSelectionPageRoutingModule,
        ],
        declarations: [_language_selection_page__WEBPACK_IMPORTED_MODULE_1__.LanguageSelectionPage],
        providers: [
            src_app_service_service_register_service_register_service__WEBPACK_IMPORTED_MODULE_2__.ServiceRegisterService
        ]
    })
], LanguageSelectionPageModule);



/***/ }),

/***/ 27095:
/*!*********************************************************************!*\
  !*** ./src/app/pages/language-selection/language-selection.page.ts ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LanguageSelectionPage": () => (/* binding */ LanguageSelectionPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _language_selection_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./language-selection.page.html?ngResource */ 98034);
/* harmony import */ var _language_selection_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./language-selection.page.scss?ngResource */ 80109);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ionic/storage-angular */ 80190);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var _awesome_cordova_plugins_clevertap_ngx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @awesome-cordova-plugins/clevertap/ngx */ 45363);
/* harmony import */ var _awesome_cordova_plugins_firebase_analytics_ngx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @awesome-cordova-plugins/firebase-analytics/ngx */ 48852);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var src_app_animations_nav_animation_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/animations/nav-animation.service */ 52707);
/* harmony import */ var src_app_service_language_language_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/service/language/language.service */ 11281);
/* harmony import */ var src_app_service_service_register_service_register_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/service/service-register/service-register.service */ 12829);
/* harmony import */ var src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/shared/data/constants */ 74676);
/* harmony import */ var src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/shared/data/enum/event */ 38570);
/* harmony import */ var src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/shared/data/enum/screen */ 68302);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/common */ 36362);

















let LanguageSelectionPage = class LanguageSelectionPage {
    constructor(storage, router, route, translate, navCtrl, registerService, platform, navAnimationService, languageService, firebaseAnalytics, clevertap, location, menu) {
        this.storage = storage;
        this.router = router;
        this.route = route;
        this.translate = translate;
        this.navCtrl = navCtrl;
        this.registerService = registerService;
        this.platform = platform;
        this.navAnimationService = navAnimationService;
        this.languageService = languageService;
        this.firebaseAnalytics = firebaseAnalytics;
        this.clevertap = clevertap;
        this.location = location;
        this.menu = menu;
    }
    ngOnInit() {
        this.platform.ready().then(() => (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__awaiter)(this, void 0, void 0, function* () {
            this.currentLanguage = yield window.localStorage.getItem(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_7__.Constants.PREFERED_LANGUAGE);
            if (!this.currentLanguage) {
                this.currentLanguage = src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_7__.Constants.DEFAULT_LANGUAGE;
                yield window.localStorage.setItem(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_7__.Constants.PREFERED_LANGUAGE, src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_7__.Constants.DEFAULT_LANGUAGE);
            }
            if (this.registerService.isAvailable()) {
                yield this.registerService.getDeliveredNotifications();
            }
        }));
        this.getLanguages();
    }
    ionViewDidEnter() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__awaiter)(this, void 0, void 0, function* () {
            this.params = this.route.snapshot.queryParams;
            this.subscription = this.platform.backButton.subscribeWithPriority(9999, () => {
                this.location.back();
                this.menu.open('profile-menu');
            });
        });
    }
    ionViewWillLeave() {
        this.subscription.unsubscribe();
    }
    // this.listDashboard = this.listDashboard.filter(
    //   _ => _.code != 'seeDoctor'
    // )
    getLanguages() {
        this.languageService.getLanguages().subscribe((data) => {
            this.languageList = data;
            this.languageList = this.languageList.filter(_ => _.id != '6');
            src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_7__.Constants.LANGUAGE_LIST = this.languageList;
        }, (error) => {
            return error;
        });
    }
    onSelectLanguage(language) {
        this.firebaseAnalytics.logEvent(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_8__.GA4Event.LanguageSelected, { language: language.culture });
        this.clevertap.recordEventWithNameAndProps(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_8__.ClevertapEvent.registration_language_selection, { language: language.culture });
        this.clevertap.recordEventWithNameAndProps(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_8__.ClevertapEvent.login_language_selection, { language: language.culture });
        this.clevertap.profileSet({ Language: language.culture });
        this.onNavigateToNextScreen(language.culture);
    }
    onNavigateToNextScreen(selectedLanguageCode) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__awaiter)(this, void 0, void 0, function* () {
            this.currentLanguage = selectedLanguageCode;
            this.languageService.changeLanguage(selectedLanguageCode);
            //this.registerService.setDeviceId();
            this.navAnimationService.getAnimationSource();
            this.redirectToSignUp();
        });
    }
    redirectToSignUp() {
        var _a;
        if ((_a = this.params) === null || _a === void 0 ? void 0 : _a.redirectTo) {
            this.router.navigate(['/' + this.params.redirectTo]).then(() => {
            });
        }
        else {
            this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_9__.Screens.SignIn]).then(() => {
            });
        }
    }
    onBack() {
        this.navCtrl.back();
        this.menu.open('profile-menu');
    }
};
LanguageSelectionPage.ctorParameters = () => [
    { type: _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_11__.Storage },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_12__.Router },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_12__.ActivatedRoute },
    { type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_13__.TranslateService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_14__.NavController },
    { type: src_app_service_service_register_service_register_service__WEBPACK_IMPORTED_MODULE_6__.ServiceRegisterService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_14__.Platform },
    { type: src_app_animations_nav_animation_service__WEBPACK_IMPORTED_MODULE_4__.NavAnimationService },
    { type: src_app_service_language_language_service__WEBPACK_IMPORTED_MODULE_5__.LanguageService },
    { type: _awesome_cordova_plugins_firebase_analytics_ngx__WEBPACK_IMPORTED_MODULE_3__.FirebaseAnalytics },
    { type: _awesome_cordova_plugins_clevertap_ngx__WEBPACK_IMPORTED_MODULE_2__.CleverTap },
    { type: _angular_common__WEBPACK_IMPORTED_MODULE_15__.Location },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_14__.MenuController }
];
LanguageSelectionPage = (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_16__.Component)({
        selector: 'app-language-selection',
        template: _language_selection_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_language_selection_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], LanguageSelectionPage);



/***/ }),

/***/ 80109:
/*!**********************************************************************************!*\
  !*** ./src/app/pages/language-selection/language-selection.page.scss?ngResource ***!
  \**********************************************************************************/
/***/ ((module) => {

module.exports = ":root {\n  --nc-color-nextgen-neutral-grey-50: red;\n  --nc-color-nextgen-white: yellow;\n  --nc-color-nextgen-blue: #0d152e;\n  --nc-color-nextgen-green: #00908d;\n  --nc-color-nextgen-black: #000000;\n  --nc-color-nextgen-grey-background: #c8d3da;\n  --nc-color-nextgen-grey: #92a2ac;\n  --nc-color-nextgen-stone-grey: #fafafa;\n  --nc-color-nextgen-error: #fc1055;\n  --nc-color-nextgen-neutral-grey: #414141;\n  --nc-color-nextgen-fibrant-green: #00bab6;\n  --nc-color-nextgen-warning: #ffd048;\n  --nc-color-nextgen-green-background: #e6f2f2;\n  --nc-color-nextgen-neutral-grey-400: #7a7a7a;\n  --nc-color-nextgen-neutral-grey-100: #eff3f5;\n  --nc-color-nextgen-status-error: #ba0c3f;\n  --nc-color-nextgen-status-error-background: #ffeff4;\n  --nc-color-nextgen-status-warning: #cba127;\n  --nc-color-nextgen-status-warning-background: #fff8e6;\n  --nc-color-nextgen-blue-100: #dfeff2;\n  --nc-color-nextgen-error-red-700: #f62459;\n  --nc-color-nextgen-blue-500: #006192;\n  --nc-color-nextgen-blue-400: #79cdec;\n  --nc-color-nextgen-red-500: #ff6592;\n  --nc-color-nextgen-secondary-blue-300: #13a0d3;\n  --lumi-white-color: #ffffff;\n  --lumi-primary-yellow-color: #fab600;\n}\n\n.ion-color-green {\n  --ion-color-base: var(--nc-color-nextgen-green);\n  --ion-color-base-rgb: var(--nc-color-nextgen-green);\n  --ion-color-contrast: var(--nc-color-nextgen-white);\n  --ion-color-contrast-rgb: var(--nc-color-nextgen-green);\n  --ion-color-shade: var(--nc-color-nextgen-green);\n  --ion-color-tint: var(--nc-color-nextgen-green);\n}\n\n.language-selection-container {\n  background-color: #FFFFFF;\n}\n\n.language-selection-img {\n  width: 50%;\n  display: block;\n  margin-left: auto;\n  margin-right: auto;\n  margin-top: 100px;\n  margin-bottom: 100px;\n}\n\n.language-selection-prefered-language {\n  text-align: center;\n  font-size: 30px;\n  line-height: 30px;\n  color: #595959;\n  margin: 0 20px 40px 20px;\n}\n\n.language-selection-button {\n  padding: 9px 40px;\n  text-align: center;\n  font-size: 20px;\n  color: #00908D;\n  height: 55px;\n  line-height: 50px;\n  border: 2px solid #00908D;\n  box-sizing: border-box;\n  border-radius: 52px;\n}\n\n.prefered-language {\n  width: 100%;\n  color: var(--nc-color-nextgen-black);\n  padding-top: 2rem;\n}\n\n.continue {\n  text-align: center;\n}\n\n.slect-language {\n  padding-top: 8rem;\n  display: flex;\n  height: max-content;\n  justify-content: center;\n}\n\n.select-area {\n  color: var(--nc-color-nextgen-black);\n  padding-bottom: 56px;\n  display: flex;\n  align-items: center;\n}\n\n.pr-1 {\n  padding-right: 1rem !important;\n  padding-left: 1rem !important;\n}\n\n.ml-1 {\n  padding-left: 1rem !important;\n}\n\n.checked {\n  font-weight: 700 !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXGNvbG9yLnNjc3MiLCJsYW5ndWFnZS1zZWxlY3Rpb24ucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0MsdUNBQUE7RUFDQSxnQ0FBQTtFQUNBLGdDQUFBO0VBQ0EsaUNBQUE7RUFDQSxpQ0FBQTtFQUNBLDJDQUFBO0VBQ0EsZ0NBQUE7RUFDQSxzQ0FBQTtFQUNBLGlDQUFBO0VBQ0Esd0NBQUE7RUFDQSx5Q0FBQTtFQUNBLG1DQUFBO0VBQ0EsNENBQUE7RUFDQSw0Q0FBQTtFQUNBLDRDQUFBO0VBQ0Esd0NBQUE7RUFDQSxtREFBQTtFQUNBLDBDQUFBO0VBQ0EscURBQUE7RUFDQSxvQ0FBQTtFQUNBLHlDQUFBO0VBQ0Esb0NBQUE7RUFDQSxvQ0FBQTtFQUNBLG1DQUFBO0VBQ0EsOENBQUE7RUFFQSwyQkFBQTtFQUNBLG9DQUFBO0FDQUQ7O0FEZ0NBO0VBQ0MsK0NBQUE7RUFDQSxtREFBQTtFQUNBLG1EQUFBO0VBQ0EsdURBQUE7RUFDQSxnREFBQTtFQUNBLCtDQUFBO0FDN0JEOztBQW5DQTtFQUNJLHlCQUFBO0FBc0NKOztBQW5DQTtFQUNJLFVBQUE7RUFDQSxjQUFBO0VBQ0EsaUJBQUE7RUFDQSxrQkFBQTtFQUNBLGlCQUFBO0VBQ0Esb0JBQUE7QUFzQ0o7O0FBbkNBO0VBQ0ksa0JBQUE7RUFDQSxlQUFBO0VBQ0EsaUJBQUE7RUFDQSxjQUFBO0VBQ0Esd0JBQUE7QUFzQ0o7O0FBbkNBO0VBQ0ksaUJBQUE7RUFDQSxrQkFBQTtFQUNBLGVBQUE7RUFDQSxjQUFBO0VBQ0EsWUFBQTtFQUNBLGlCQUFBO0VBQ0EseUJBQUE7RUFDQSxzQkFBQTtFQUNBLG1CQUFBO0FBc0NKOztBQW5DQTtFQUNJLFdBQUE7RUFDQSxvQ0RKa0I7RUNLbEIsaUJBQUE7QUFzQ0o7O0FBbkNBO0VBQ0ksa0JBQUE7QUFzQ0o7O0FBbkNBO0VBQ0ksaUJBQUE7RUFDQSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSx1QkFBQTtBQXNDSjs7QUFuQ0E7RUFDSSxvQ0RwQmtCO0VDcUJsQixvQkFBQTtFQUNBLGFBQUE7RUFDQSxtQkFBQTtBQXNDSjs7QUFuQ0E7RUFDSSw4QkFBQTtFQUNBLDZCQUFBO0FBc0NKOztBQW5DQTtFQUNJLDZCQUFBO0FBc0NKOztBQW5DQTtFQUNJLDJCQUFBO0FBc0NKIiwiZmlsZSI6Imxhbmd1YWdlLXNlbGVjdGlvbi5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyI6cm9vdCB7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS01MDogcmVkO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi13aGl0ZTogeWVsbG93O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlOiAjMGQxNTJlO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbjogIzAwOTA4ZDtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tYmxhY2s6ICMwMDAwMDA7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWdyZXktYmFja2dyb3VuZDogI2M4ZDNkYTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tZ3JleTogIzkyYTJhYztcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc3RvbmUtZ3JleTogI2ZhZmFmYTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tZXJyb3I6ICNmYzEwNTU7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleTogIzQxNDE0MTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tZmlicmFudC1ncmVlbjogIzAwYmFiNjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4td2FybmluZzogI2ZmZDA0ODtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4tYmFja2dyb3VuZDogI2U2ZjJmMjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTQwMDogIzdhN2E3YTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTEwMDogI2VmZjNmNTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yOiAjYmEwYzNmO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtZXJyb3ItYmFja2dyb3VuZDogI2ZmZWZmNDtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLXdhcm5pbmc6ICNjYmExMjc7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy13YXJuaW5nLWJhY2tncm91bmQ6ICNmZmY4ZTY7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWJsdWUtMTAwOiAjZGZlZmYyO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1lcnJvci1yZWQtNzAwOiAjZjYyNDU5O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlLTUwMDogIzAwNjE5MjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZS00MDA6ICM3OWNkZWM7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXJlZC01MDA6ICNmZjY1OTI7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXNlY29uZGFyeS1ibHVlLTMwMDogIzEzYTBkMztcclxuXHJcblx0LS1sdW1pLXdoaXRlLWNvbG9yOiAjZmZmZmZmO1xyXG5cdC0tbHVtaS1wcmltYXJ5LXllbGxvdy1jb2xvcjogI2ZhYjYwMDtcclxufVxyXG4kY29sb3ItbmV4dGdlbi1ibHVlOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWJsdWUpO1xyXG4kY29sb3ItbmV4dGdlbi1ncmVlbjogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbik7XHJcbiRjb2xvci1uZXh0Z2VuLXdoaXRlOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXdoaXRlKTtcclxuJGNvbG9yLW5leHRnZW4tYmxhY2s6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tYmxhY2spO1xyXG4kY29sb3ItbmV4dGdlbi1ncmV5LWJhY2tncm91bmQ6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JleS1iYWNrZ3JvdW5kKTtcclxuJGNvbG9yLW5leHRnZW4tZ3JleTogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmV5KTtcclxuJGNvbG9yLW5leHRnZW4tc3RvbmUtZ3JleTogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1zdG9uZS1ncmV5KTtcclxuJGNvbG9yLW5leHRnZW4tZXJyb3I6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZXJyb3IpO1xyXG4kY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXk6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5KTtcclxuJGNvbG9yLW5leHRnZW4tZmlicmFudC1ncmVlbjogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1maWJyYW50LWdyZWVuKTtcclxuJGNvbG9yLW5leHRnZW4td2FybmluZzogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi13YXJuaW5nKTtcclxuJGNvbG9yLW5leHRnZW4tZ3JlZW4tYmFja2dyb3VuZDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbi1iYWNrZ3JvdW5kKTtcclxuJGNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTUwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS01MCk7XHJcbiRjb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS00MDA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTQwMCk7XHJcbiRjb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS0xMDA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTEwMCk7XHJcbiRjb2xvci1uZXh0Z2VuLXN0YXR1cy1lcnJvcjogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtZXJyb3IpO1xyXG4kY29sb3ItbmV4dGdlbi1zdGF0dXMtZXJyb3ItYmFja2dyb3VuZDogdmFyKFxyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtZXJyb3ItYmFja2dyb3VuZFxyXG4pO1xyXG4kY29sb3ItbmV4dGdlbi1zdGF0dXMtd2FybmluZzogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtd2FybmluZyk7XHJcbiRjb2xvci1uZXh0Z2VuLXN0YXR1cy13YXJuaW5nLWJhY2tncm91bmQ6IHZhcihcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLXdhcm5pbmctYmFja2dyb3VuZFxyXG4pO1xyXG4kY29sb3ItbmV4dGdlbi1ibHVlLTEwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlLTEwMCk7XHJcbiRjb2xvci1uZXh0Z2VuLWVycm9yLXJlZC03MDA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZXJyb3ItcmVkLTcwMCk7XHJcbiRjb2xvci1uZXh0Z2VuLWJsdWUtNTAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWJsdWUtNTAwKTtcclxuJGNvbG9yLW5leHRnZW4tYmx1ZS00MDA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZS00MDApO1xyXG4kY29sb3ItbmV4dGdlbi1yZWQtNTAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXJlZC01MDApO1xyXG4kY29sb3ItbmV4dGdlbi1zZWNvbmRhcnktYmx1ZS0zMDA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tc2Vjb25kYXJ5LWJsdWUtMzAwKTtcclxuXHJcbi5pb24tY29sb3ItZ3JlZW4ge1xyXG5cdC0taW9uLWNvbG9yLWJhc2U6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4pO1xyXG5cdC0taW9uLWNvbG9yLWJhc2UtcmdiOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuKTtcclxuXHQtLWlvbi1jb2xvci1jb250cmFzdDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi13aGl0ZSk7XHJcblx0LS1pb24tY29sb3ItY29udHJhc3QtcmdiOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuKTtcclxuXHQtLWlvbi1jb2xvci1zaGFkZTogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbik7XHJcblx0LS1pb24tY29sb3ItdGludDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbik7XHJcbn1cclxuIiwiQGltcG9ydCBcIi4uLy4uLy4uL2NvbG9yLnNjc3NcIjtcclxuXHJcbi5sYW5ndWFnZS1zZWxlY3Rpb24tY29udGFpbmVyIHtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICNGRkZGRkY7XHJcbn1cclxuXHJcbi5sYW5ndWFnZS1zZWxlY3Rpb24taW1nIHtcclxuICAgIHdpZHRoOiA1MCU7XHJcbiAgICBkaXNwbGF5OiBibG9jaztcclxuICAgIG1hcmdpbi1sZWZ0OiBhdXRvO1xyXG4gICAgbWFyZ2luLXJpZ2h0OiBhdXRvO1xyXG4gICAgbWFyZ2luLXRvcDogMTAwcHg7XHJcbiAgICBtYXJnaW4tYm90dG9tOiAxMDBweDtcclxufVxyXG5cclxuLmxhbmd1YWdlLXNlbGVjdGlvbi1wcmVmZXJlZC1sYW5ndWFnZSB7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBmb250LXNpemU6IDMwcHg7XHJcbiAgICBsaW5lLWhlaWdodDogMzBweDtcclxuICAgIGNvbG9yOiAjNTk1OTU5O1xyXG4gICAgbWFyZ2luOiAwIDIwcHggNDBweCAyMHB4O1xyXG59XHJcblxyXG4ubGFuZ3VhZ2Utc2VsZWN0aW9uLWJ1dHRvbiB7XHJcbiAgICBwYWRkaW5nOiA5cHggNDBweDtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIGZvbnQtc2l6ZTogMjBweDtcclxuICAgIGNvbG9yOiAjMDA5MDhEO1xyXG4gICAgaGVpZ2h0OiA1NXB4O1xyXG4gICAgbGluZS1oZWlnaHQ6IDUwcHg7XHJcbiAgICBib3JkZXI6IDJweCBzb2xpZCAjMDA5MDhEO1xyXG4gICAgYm94LXNpemluZzogYm9yZGVyLWJveDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDUycHg7XHJcbn1cclxuXHJcbi5wcmVmZXJlZC1sYW5ndWFnZSB7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIGNvbG9yOiAkY29sb3ItbmV4dGdlbi1ibGFjaztcclxuICAgIHBhZGRpbmctdG9wOiAycmVtO1xyXG59XHJcblxyXG4uY29udGludWUge1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG59XHJcblxyXG4uc2xlY3QtbGFuZ3VhZ2Uge1xyXG4gICAgcGFkZGluZy10b3A6IDhyZW07XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgaGVpZ2h0OiBtYXgtY29udGVudDtcclxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG59XHJcblxyXG4uc2VsZWN0LWFyZWEge1xyXG4gICAgY29sb3I6JGNvbG9yLW5leHRnZW4tYmxhY2s7XHJcbiAgICBwYWRkaW5nLWJvdHRvbTogNTZweDtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG59XHJcblxyXG4ucHItMSB7XHJcbiAgICBwYWRkaW5nLXJpZ2h0OiAxcmVtICFpbXBvcnRhbnQ7XHJcbiAgICBwYWRkaW5nLWxlZnQ6IDFyZW0gIWltcG9ydGFudDtcclxufVxyXG5cclxuLm1sLTEge1xyXG4gICAgcGFkZGluZy1sZWZ0OiAxcmVtICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5jaGVja2VkIHtcclxuICAgIGZvbnQtd2VpZ2h0OiA3MDAgIWltcG9ydGFudDtcclxufSJdfQ== */";

/***/ }),

/***/ 98034:
/*!**********************************************************************************!*\
  !*** ./src/app/pages/language-selection/language-selection.page.html?ngResource ***!
  \**********************************************************************************/
/***/ ((module) => {

module.exports = "<div class=\"language-selection-container\">\r\n  <nextcare-layout>\r\n    <ng-template header>\r\n      <ion-row>\r\n        <ion-col size=\"6\" class=\"d-flex\">\r\n          <button class=\"btn btn-circle\" (click)=\"onBack()\">\r\n            <ion-icon  class=\"icon-back body-l\" name=\"arrow-back-outline\"></ion-icon>\r\n          </button>\r\n        </ion-col>\r\n        <ion-col size=\"6\">\r\n        </ion-col>\r\n      </ion-row>\r\n    </ng-template>\r\n    <ng-template body>\r\n      <div class=\"prefered-language h1 bold\">\r\n        {{'languageSelection.preferedLanguage' | translate}}\r\n      </div>\r\n      <div class=\"slect-language\">\r\n        <div>\r\n          <div *ngFor=\"let lang of languageList\" (click)=\"onSelectLanguage(lang)\" class=\"select-area body-l\"\r\n            [ngClass]=\"lang.culture === currentLanguage ? 'checked' : ''\">\r\n            <img src=\"data:image/png;base64,{{lang.flag}}\" class=\"pr-1\" />\r\n            {{lang.name}}\r\n            <img class=\"ml-1\" *ngIf=\"lang.culture === currentLanguage\" src=\"../../../assets/icon/checked.svg\" />\r\n          </div>\r\n        </div>\r\n      </div>\r\n    </ng-template>\r\n    <ng-template bottom>\r\n      <div class=\"continue\">\r\n        <button class=\"btn btn-large primary bold\" (click)=\"redirectToSignUp()\">{{ 'button.continue' |\r\n          translate }}</button>\r\n      </div>\r\n    </ng-template>\r\n  </nextcare-layout>\r\n</div>";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_language-selection_language-selection_module_ts.js.map