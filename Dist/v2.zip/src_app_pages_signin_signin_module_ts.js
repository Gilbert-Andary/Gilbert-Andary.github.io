"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_signin_signin_module_ts"],{

/***/ 30174:
/*!*******************************************************!*\
  !*** ./src/app/pages/signin/signin-routing.module.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SigninPageRoutingModule": () => (/* binding */ SigninPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _signin_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./signin.page */ 92590);




const routes = [
    {
        path: '',
        component: _signin_page__WEBPACK_IMPORTED_MODULE_0__.SigninPage,
    },
];
let SigninPageRoutingModule = class SigninPageRoutingModule {
};
SigninPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], SigninPageRoutingModule);



/***/ }),

/***/ 46779:
/*!***********************************************!*\
  !*** ./src/app/pages/signin/signin.module.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SigninPageModule": () => (/* binding */ SigninPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _signin_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./signin-routing.module */ 30174);
/* harmony import */ var _signin_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./signin.page */ 92590);
/* harmony import */ var src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/shared/shared.module */ 44466);







let SigninPageModule = class SigninPageModule {
};
SigninPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _signin_routing_module__WEBPACK_IMPORTED_MODULE_0__.SigninPageRoutingModule,
            src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_2__.SharedModule,
        ],
        declarations: [_signin_page__WEBPACK_IMPORTED_MODULE_1__.SigninPage],
    })
], SigninPageModule);



/***/ }),

/***/ 92590:
/*!*********************************************!*\
  !*** ./src/app/pages/signin/signin.page.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SigninPage": () => (/* binding */ SigninPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _signin_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./signin.page.html?ngResource */ 54204);
/* harmony import */ var _signin_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./signin.page.scss?ngResource */ 23611);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _awesome_cordova_plugins_clevertap_ngx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @awesome-cordova-plugins/clevertap/ngx */ 45363);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _awesome_cordova_plugins_app_version_ngx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @awesome-cordova-plugins/app-version/ngx */ 74582);
/* harmony import */ var _awesome_cordova_plugins_firebase_analytics_ngx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @awesome-cordova-plugins/firebase-analytics/ngx */ 48852);
/* harmony import */ var _capacitor_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @capacitor/core */ 26549);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @environments/environment */ 92340);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! @ionic/storage-angular */ 80190);
/* harmony import */ var capacitor_native_biometric__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! capacitor-native-biometric */ 31506);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! rxjs/operators */ 80823);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! rxjs/operators */ 59095);
/* harmony import */ var src_app_model_control_control_model__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/model/control/control.model */ 45482);
/* harmony import */ var src_app_service_service_register_service_register_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/service/service-register/service-register.service */ 12829);
/* harmony import */ var src_app_service_signin_signin_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/app/service/signin/signin.service */ 91265);
/* harmony import */ var src_app_service_utilities_navigator_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/app/service/utilities/navigator.service */ 38903);
/* harmony import */ var src_app_shared_components_nextgen_dialog_nextgen_dialog_service__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! src/app/shared/components/nextgen-dialog/nextgen-dialog.service */ 96485);
/* harmony import */ var src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! src/app/shared/data/constants */ 74676);
/* harmony import */ var src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! src/app/shared/data/enum/event */ 38570);
/* harmony import */ var src_app_shared_data_enum_platform__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! src/app/shared/data/enum/platform */ 8760);
/* harmony import */ var src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! src/app/shared/data/enum/screen */ 68302);
/* harmony import */ var _service_language_language_service__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ../../service/language/language.service */ 11281);
/* harmony import */ var _signup_language_selection_language_selection_component__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ../signup/language-selection/language-selection.component */ 34658);


























let SigninPage = class SigninPage {
    constructor(router, fb, storage, dialogSevice, signinService, languageService, navigatorHelperService, route, firebaseAnalytics, clevertap, registerService, appVersion, platform) {
        this.router = router;
        this.fb = fb;
        this.storage = storage;
        this.dialogSevice = dialogSevice;
        this.signinService = signinService;
        this.languageService = languageService;
        this.navigatorHelperService = navigatorHelperService;
        this.route = route;
        this.firebaseAnalytics = firebaseAnalytics;
        this.clevertap = clevertap;
        this.registerService = registerService;
        this.appVersion = appVersion;
        this.platform = platform;
        this.versionApp = _environments_environment__WEBPACK_IMPORTED_MODULE_6__.environment.appVersion;
        this.emailValidation = 'vunnt@fsoft.com.vn';
        this.TYPE = src_app_model_control_control_model__WEBPACK_IMPORTED_MODULE_8__.ControlType; //type input control
        this.showPassword = false; //status password(hide=false/show)
        this.isMobileApp = false;
        this.secondIcon = 'uil uil-eye-slash';
        this.typeInputPassword = this.TYPE.PASSWORD;
        this.countLogin = 4;
        this.showValidation = true;
        this.customValidation = [
            {
                key: 'pattern',
                message: 'validationSummary.email',
            },
        ];
        // Build formGroup
        this.initScreen();
        this.loadPlatformInformation();
    }
    ionViewDidEnter() {
        setTimeout(() => {
            if (_capacitor_core__WEBPACK_IMPORTED_MODULE_5__.Capacitor.getPlatform() !== 'ios') {
                return;
            }
            document.getElementById('emailInput').addEventListener('change', (ev) => {
                requestAnimationFrame(() => {
                    this.signInForm.controls.login.setValue(ev.target.value);
                });
            });
            document.getElementById('passwordInput').addEventListener('change', (ev) => {
                requestAnimationFrame(() => {
                    this.signInForm.controls.password.setValue(ev.target.value);
                });
            });
        }, 100);
        this.subscription = this.platform.backButton.subscribeWithPriority(9999, () => {
            navigator['app'].exitApp();
        });
    }
    ionViewWillLeave() {
        this.subscription.unsubscribe();
    }
    ionViewWillEnter() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_19__.__awaiter)(this, void 0, void 0, function* () {
            try {
                this.versionApp = yield this.appVersion.getVersionNumber();
            }
            catch (error) {
                console.log(error);
            }
            if (this.signInForm) {
                this.signInForm.reset();
            }
            // this.initScreen();
        });
    }
    loadPlatformInformation() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_19__.__awaiter)(this, void 0, void 0, function* () {
            const platform = yield this.storage.get(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_13__.Constants.PLATFORM);
            if (platform == src_app_shared_data_enum_platform__WEBPACK_IMPORTED_MODULE_15__.PlatformEnum.Mobile) {
                this.isMobileApp = true;
            }
        });
    }
    ngOnInit() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_19__.__awaiter)(this, void 0, void 0, function* () {
            if (this.registerService.isAvailable()) {
                yield this.registerService.getDeliveredNotifications();
            }
        });
    }
    initScreen() {
        var _a, _b;
        this.signInForm = this.fb.group({
            login: [''],
            password: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_20__.Validators.required]],
        });
        this.ipAddress = (_b = (_a = this.route.snapshot.data) === null || _a === void 0 ? void 0 : _a.ipAddress) === null || _b === void 0 ? void 0 : _b.ip;
        this.signInForm.controls.login.valueChanges.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_21__.debounceTime)(500)).subscribe((res) => {
            if ((res === null || res === void 0 ? void 0 : res.indexOf(' ')) >= 0) {
                this.signInForm.controls.login.setValue(res.replace(/\s/g, ''));
            }
        });
        this.getAllLanguage();
    }
    getAllLanguage() {
        if (src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_13__.Constants.LANGUAGE_LIST.length > 0) {
            this.listLanguages = src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_13__.Constants.LANGUAGE_LIST;
            this.filterLanguages();
        }
        else {
            this.languageService.getLanguages().subscribe((data) => (0,tslib__WEBPACK_IMPORTED_MODULE_19__.__awaiter)(this, void 0, void 0, function* () {
                this.listLanguages = data;
                yield this.filterLanguages();
                src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_13__.Constants.LANGUAGE_LIST = this.listLanguages;
            }));
        }
    }
    filterLanguages() {
        var _a;
        return (0,tslib__WEBPACK_IMPORTED_MODULE_19__.__awaiter)(this, void 0, void 0, function* () {
            this.listLanguages = this.listLanguages.filter((_) => _.id != '6');
            this.currentLanguage = window.localStorage.getItem(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_13__.Constants.PREFERED_LANGUAGE);
            this.currentLanguageName = (_a = this.listLanguages.find((x) => x.culture == this.currentLanguage)) === null || _a === void 0 ? void 0 : _a.name;
        });
    }
    togglePassword() {
        if (this.showPassword) {
            this.typeInputPassword = this.TYPE.INPUT;
            this.secondIcon = 'uil uil-eye';
        }
        else {
            this.typeInputPassword = this.TYPE.PASSWORD;
            this.secondIcon = 'uil uil-eye-slash';
        }
        this.showPassword = !this.showPassword;
    }
    openDialogLanguage() {
        this.dialogSevice
            .open(_signup_language_selection_language_selection_component__WEBPACK_IMPORTED_MODULE_18__.LanguageSelectionComponent, {
            data: {
                currentLanguage: this.currentLanguage,
                listLanguages: this.listLanguages,
            },
            title: 'signup.languageSelectionTitle',
        })
            .afterClosed()
            .subscribe((_) => (0,tslib__WEBPACK_IMPORTED_MODULE_19__.__awaiter)(this, void 0, void 0, function* () {
            yield this.filterLanguages();
        }));
    }
    login() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_19__.__awaiter)(this, void 0, void 0, function* () {
            this.firebaseAnalytics.logEvent(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_14__.GA4Event.LoginInitiated, {});
            this.clevertap.recordEventWithName(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_14__.GA4Event.LoginInitiated);
            // Stop if form is not in valid state
            if (!this.signInForm.valid) {
                return;
            }
            else {
                const value = this.signInForm.value;
                const deviceId = yield this.storage.get(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_13__.Constants.DEVICE_ID);
                const OSName = this.navigatorHelperService.getOSName();
                const browser = this.navigatorHelperService.getBowserName();
                const appVersion = this.navigatorHelperService.getAppVersion();
                const userId = yield this.storage.get(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_13__.Constants.USERID);
                (yield this.registerService.setDeviceId())
                    .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_22__.switchMap)((res) => {
                    return this.signinService.loginUser(Object.assign({}, value, {
                        deviceId: deviceId || res,
                        os: OSName,
                        browser,
                        machineName: appVersion,
                        ipAddress: this.ipAddress,
                        appID: _environments_environment__WEBPACK_IMPORTED_MODULE_6__.environment.AppID,
                    }));
                }))
                    .subscribe((_) => (0,tslib__WEBPACK_IMPORTED_MODULE_19__.__awaiter)(this, void 0, void 0, function* () {
                    this.firebaseAnalytics.logEvent(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_14__.GA4Event.LoginCompleted, { user_email: value.login || value.email });
                    this.clevertap.recordEventWithName(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_14__.ClevertapEvent.registration_login);
                    this.clevertap.recordEventWithNameAndProps(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_14__.ClevertapEvent.login_login_account, { user_id: userId, user_email: value.login || value.email });
                    const clevertapProfileInfo = yield this.storage.get(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_13__.Constants.CLEVERTAP_PROFILE_INFO);
                    if (clevertapProfileInfo) {
                        this.clevertap.onUserLogin(clevertapProfileInfo);
                        this.storage.set(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_13__.Constants.CLEVERTAP_PROFILE_INFO, userId);
                        this.clevertap.profileSet({ Identity: userId });
                    }
                    this.storage.set('UEmail', value.login);
                    this.signinService.setBiomatricService(value);
                    const bioReady = yield this.signinService.getBiomatricStatus();
                    if (bioReady) {
                        this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_16__.Screens.Home]);
                    }
                    else {
                        try {
                            yield capacitor_native_biometric__WEBPACK_IMPORTED_MODULE_7__.NativeBiometric.isAvailable().then((result) => (0,tslib__WEBPACK_IMPORTED_MODULE_19__.__awaiter)(this, void 0, void 0, function* () {
                                this.isSupportBiometric = result.isAvailable;
                                if (this.isSupportBiometric) {
                                    if (result.biometryType == capacitor_native_biometric__WEBPACK_IMPORTED_MODULE_7__.BiometryType.FACE_AUTHENTICATION ||
                                        result.biometryType == capacitor_native_biometric__WEBPACK_IMPORTED_MODULE_7__.BiometryType.FACE_ID ||
                                        result.biometryType == capacitor_native_biometric__WEBPACK_IMPORTED_MODULE_7__.BiometryType.IRIS_AUTHENTICATION) {
                                        this.redirectToEnableFaceID(value);
                                        return;
                                    }
                                    if (result.biometryType == capacitor_native_biometric__WEBPACK_IMPORTED_MODULE_7__.BiometryType.FINGERPRINT || result.biometryType == capacitor_native_biometric__WEBPACK_IMPORTED_MODULE_7__.BiometryType.TOUCH_ID) {
                                        this.redirectToEnableFaceID(value);
                                        return;
                                    }
                                }
                                this.clevertap.recordEventWithName(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_14__.ClevertapEvent.login_home_screen);
                                this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_16__.Screens.Home]);
                            }));
                        }
                        catch (_) {
                            this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_16__.Screens.Home]);
                        }
                    }
                    // on check if this login is a first time
                    // the sys will redirect to enable face id page
                    // if not redirect to home page.
                }), (err) => {
                    // this.dialogSevice.open<ShowInformationAlertComponent>(ShowInformationAlertComponent, {
                    //   data: {
                    //     title: _err.status,
                    //     text: _err?.error?.message || JSON.stringify(_err?.error?.errors),
                    //     buttontext: 'button.ok',
                    //   },
                    //   position: 'middle',
                    //   height: '40%',
                    // });
                    this.signinService.handleLoginError(err);
                });
            }
        });
    }
    redirectToEnableFaceID(user) {
        this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_16__.Screens.EnableFaceId], {
            queryParams: {
                fromLogin: 'signin',
            },
            state: Object.assign(Object.assign({}, user), { email: (user === null || user === void 0 ? void 0 : user.email) || (user === null || user === void 0 ? void 0 : user.login) }),
        });
    }
    onBack() {
        this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_16__.Screens.GetStarted]);
    }
    redirectToNeedHelp() {
        this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_16__.Screens.InquiryBeforeLogin], { queryParams: { redirectTo: 'login' } });
    }
    redirectToRegister() {
        this.firebaseAnalytics.logEvent(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_14__.GA4Event.OnboardingProceeded, {});
        this.clevertap.recordEventWithName(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_14__.GA4Event.OnboardingProceeded);
        this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_16__.Screens.SignUp]).then(() => { });
    }
    redirectToForgotPassword() {
        this.firebaseAnalytics.logEvent(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_14__.GA4Event.PasswordResetInitiated, {});
        this.clevertap.recordEventWithName(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_14__.ClevertapEvent.login_forgot_password);
        this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_16__.Screens.ForgotPassword]);
    }
    focusoutHandler() {
        this.showValidation = true;
        this.signInForm.controls['login'].setValidators([_angular_forms__WEBPACK_IMPORTED_MODULE_20__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_20__.Validators.pattern(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/)]);
        this.signInForm.controls['login'].updateValueAndValidity();
    }
    onFocusInputEvent() {
        this.showValidation = false;
        this.signInForm.controls['login'].clearValidators();
        this.signInForm.controls['login'].updateValueAndValidity();
    }
    onPaste(event) {
        const clipboardData = event.clipboardData;
        let content = clipboardData.getData('text');
        if ((content === null || content === void 0 ? void 0 : content.indexOf(' ')) >= 0)
            content = content.replace(/\s/g, '');
        this.signInForm.controls['login'].setValue(content);
        this.signInForm.controls['login'].updateValueAndValidity();
        event.preventDefault();
    }
    onInput() {
        var _a;
        if (((_a = this.email) === null || _a === void 0 ? void 0 : _a.indexOf(' ')) >= 0) {
            this.email = this.email.replace(/\s/g, '');
        }
    }
};
SigninPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_23__.Router },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_20__.FormBuilder },
    { type: _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_24__.Storage },
    { type: src_app_shared_components_nextgen_dialog_nextgen_dialog_service__WEBPACK_IMPORTED_MODULE_12__.DialogService },
    { type: src_app_service_signin_signin_service__WEBPACK_IMPORTED_MODULE_10__.SigninService },
    { type: _service_language_language_service__WEBPACK_IMPORTED_MODULE_17__.LanguageService },
    { type: src_app_service_utilities_navigator_service__WEBPACK_IMPORTED_MODULE_11__.NavigatorHelperService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_23__.ActivatedRoute },
    { type: _awesome_cordova_plugins_firebase_analytics_ngx__WEBPACK_IMPORTED_MODULE_4__.FirebaseAnalytics },
    { type: _awesome_cordova_plugins_clevertap_ngx__WEBPACK_IMPORTED_MODULE_2__.CleverTap },
    { type: src_app_service_service_register_service_register_service__WEBPACK_IMPORTED_MODULE_9__.ServiceRegisterService },
    { type: _awesome_cordova_plugins_app_version_ngx__WEBPACK_IMPORTED_MODULE_3__.AppVersion },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_25__.Platform }
];
SigninPage = (0,tslib__WEBPACK_IMPORTED_MODULE_19__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_26__.Component)({
        selector: 'app-signin',
        template: _signin_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_signin_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], SigninPage);

// }


/***/ }),

/***/ 23611:
/*!**********************************************************!*\
  !*** ./src/app/pages/signin/signin.page.scss?ngResource ***!
  \**********************************************************/
/***/ ((module) => {

module.exports = ":root {\n  --nc-color-nextgen-neutral-grey-50: red;\n  --nc-color-nextgen-white: yellow;\n  --nc-color-nextgen-blue: #0d152e;\n  --nc-color-nextgen-green: #00908d;\n  --nc-color-nextgen-black: #000000;\n  --nc-color-nextgen-grey-background: #c8d3da;\n  --nc-color-nextgen-grey: #92a2ac;\n  --nc-color-nextgen-stone-grey: #fafafa;\n  --nc-color-nextgen-error: #fc1055;\n  --nc-color-nextgen-neutral-grey: #414141;\n  --nc-color-nextgen-fibrant-green: #00bab6;\n  --nc-color-nextgen-warning: #ffd048;\n  --nc-color-nextgen-green-background: #e6f2f2;\n  --nc-color-nextgen-neutral-grey-400: #7a7a7a;\n  --nc-color-nextgen-neutral-grey-100: #eff3f5;\n  --nc-color-nextgen-status-error: #ba0c3f;\n  --nc-color-nextgen-status-error-background: #ffeff4;\n  --nc-color-nextgen-status-warning: #cba127;\n  --nc-color-nextgen-status-warning-background: #fff8e6;\n  --nc-color-nextgen-blue-100: #dfeff2;\n  --nc-color-nextgen-error-red-700: #f62459;\n  --nc-color-nextgen-blue-500: #006192;\n  --nc-color-nextgen-blue-400: #79cdec;\n  --nc-color-nextgen-red-500: #ff6592;\n  --nc-color-nextgen-secondary-blue-300: #13a0d3;\n  --lumi-white-color: #ffffff;\n  --lumi-primary-yellow-color: #fab600;\n}\n\n.ion-color-green {\n  --ion-color-base: var(--nc-color-nextgen-green);\n  --ion-color-base-rgb: var(--nc-color-nextgen-green);\n  --ion-color-contrast: var(--nc-color-nextgen-white);\n  --ion-color-contrast-rgb: var(--nc-color-nextgen-green);\n  --ion-color-shade: var(--nc-color-nextgen-green);\n  --ion-color-tint: var(--nc-color-nextgen-green);\n}\n\n.control-aria {\n  padding-bottom: 24px;\n}\n\n.sigin-header {\n  justify-content: space-between;\n}\n\n.sign-in-container {\n  background: var(--nc-color-nextgen-neutral-grey-50);\n}\n\n.need-help-text {\n  color: var(--nc-color-nextgen-green);\n}\n\n.title-text {\n  padding-left: 2rem;\n  color: var(--nc-color-nextgen-blue);\n}\n\n.sign-in-title {\n  color: var(--nc-color-nextgen-black);\n  padding-top: 40px;\n}\n\n.form-sign-in {\n  width: 100%;\n  padding-top: 32px;\n}\n\n.text-forgot-password {\n  text-align: center;\n  padding-top: 24px;\n}\n\n.text-dont-have-account-register {\n  text-align: center;\n  padding-top: 72px;\n}\n\n.text-dont-have-account {\n  color: var(--nc-color-nextgen-neutral-grey-400);\n}\n\n.button-login-account {\n  text-align: center;\n  padding-top: 40px;\n}\n\n.button-language {\n  text-align: center;\n  justify-content: center;\n  display: flex;\n  align-items: flex-end;\n  padding-top: 80px;\n}\n\n.text-link {\n  color: var(--nc-color-nextgen-green) !important;\n}\n\n.icon-input {\n  color: var(--nc-color-nextgen-grey);\n}\n\n.text-validation {\n  color: var(--nc-color-nextgen-grey) !important;\n}\n\n.icon-language {\n  color: var(--nc-color-nextgen-green) !important;\n}\n\n.sign-in-content {\n  background: var(--nc-color-nextgen-neutral-grey-50);\n  height: 100% !important;\n}\n\n.text-current-language {\n  padding-left: 0.5rem;\n  padding-right: 0.5rem;\n  color: var(--nc-color-nextgen-green) !important;\n}\n\n.version-app {\n  text-align: center;\n  color: var(--nc-color-nextgen-black);\n  padding-top: 1.8rem;\n}\n\nion-icon {\n  height: 11px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXGNvbG9yLnNjc3MiLCJzaWduaW4ucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0MsdUNBQUE7RUFDQSxnQ0FBQTtFQUNBLGdDQUFBO0VBQ0EsaUNBQUE7RUFDQSxpQ0FBQTtFQUNBLDJDQUFBO0VBQ0EsZ0NBQUE7RUFDQSxzQ0FBQTtFQUNBLGlDQUFBO0VBQ0Esd0NBQUE7RUFDQSx5Q0FBQTtFQUNBLG1DQUFBO0VBQ0EsNENBQUE7RUFDQSw0Q0FBQTtFQUNBLDRDQUFBO0VBQ0Esd0NBQUE7RUFDQSxtREFBQTtFQUNBLDBDQUFBO0VBQ0EscURBQUE7RUFDQSxvQ0FBQTtFQUNBLHlDQUFBO0VBQ0Esb0NBQUE7RUFDQSxvQ0FBQTtFQUNBLG1DQUFBO0VBQ0EsOENBQUE7RUFFQSwyQkFBQTtFQUNBLG9DQUFBO0FDQUQ7O0FEZ0NBO0VBQ0MsK0NBQUE7RUFDQSxtREFBQTtFQUNBLG1EQUFBO0VBQ0EsdURBQUE7RUFDQSxnREFBQTtFQUNBLCtDQUFBO0FDN0JEOztBQW5DQTtFQUNFLG9CQUFBO0FBc0NGOztBQW5DQTtFQUNFLDhCQUFBO0FBc0NGOztBQW5DQTtFQUNFLG1ERCtCOEI7QUNPaEM7O0FBbkNBO0VBQ0Usb0NEZ0JvQjtBQ3NCdEI7O0FBbENBO0VBQ0Usa0JBQUE7RUFDQSxtQ0RTbUI7QUM0QnJCOztBQWxDQTtFQUNFLG9DRFFvQjtFQ1BwQixpQkFBQTtBQXFDRjs7QUFsQ0E7RUFDRSxXQUFBO0VBQ0EsaUJBQUE7QUFxQ0Y7O0FBbENBO0VBQ0Usa0JBQUE7RUFDQSxpQkFBQTtBQXFDRjs7QUFsQ0E7RUFDRSxrQkFBQTtFQUNBLGlCQUFBO0FBcUNGOztBQWxDQTtFQUNFLCtDREYrQjtBQ3VDakM7O0FBbENBO0VBQ0Usa0JBQUE7RUFDQSxpQkFBQTtBQXFDRjs7QUFsQ0E7RUFDRSxrQkFBQTtFQUNBLHVCQUFBO0VBQ0EsYUFBQTtFQUNBLHFCQUFBO0VBQ0EsaUJBQUE7QUFxQ0Y7O0FBbENBO0VBQ0UsK0NBQUE7QUFxQ0Y7O0FBbENBO0VBQ0UsbUNEL0JtQjtBQ29FckI7O0FBbENBO0VBQ0UsOENBQUE7QUFxQ0Y7O0FBbENBO0VBQ0UsK0NBQUE7QUFxQ0Y7O0FBbENBO0VBQ0UsbUREcEM4QjtFQ3FDOUIsdUJBQUE7QUFxQ0Y7O0FBbENBO0VBQ0Usb0JBQUE7RUFDQSxxQkFBQTtFQUNBLCtDQUFBO0FBcUNGOztBQW5DQTtFQUNFLGtCQUFBO0VBQ0Esb0NEeERvQjtFQ3lEcEIsbUJBQUE7QUFzQ0Y7O0FBcENBO0VBQ0UsWUFBQTtBQXVDRiIsImZpbGUiOiJzaWduaW4ucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiOnJvb3Qge1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNTA6IHJlZDtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4td2hpdGU6IHllbGxvdztcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZTogIzBkMTUyZTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW46ICMwMDkwOGQ7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWJsYWNrOiAjMDAwMDAwO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ncmV5LWJhY2tncm91bmQ6ICNjOGQzZGE7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWdyZXk6ICM5MmEyYWM7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0b25lLWdyZXk6ICNmYWZhZmE7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWVycm9yOiAjZmMxMDU1O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXk6ICM0MTQxNDE7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWZpYnJhbnQtZ3JlZW46ICMwMGJhYjY7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXdhcm5pbmc6ICNmZmQwNDg7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuLWJhY2tncm91bmQ6ICNlNmYyZjI7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS00MDA6ICM3YTdhN2E7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS0xMDA6ICNlZmYzZjU7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy1lcnJvcjogI2JhMGMzZjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yLWJhY2tncm91bmQ6ICNmZmVmZjQ7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy13YXJuaW5nOiAjY2JhMTI3O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtd2FybmluZy1iYWNrZ3JvdW5kOiAjZmZmOGU2O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlLTEwMDogI2RmZWZmMjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tZXJyb3ItcmVkLTcwMDogI2Y2MjQ1OTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZS01MDA6ICMwMDYxOTI7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWJsdWUtNDAwOiAjNzljZGVjO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1yZWQtNTAwOiAjZmY2NTkyO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zZWNvbmRhcnktYmx1ZS0zMDA6ICMxM2EwZDM7XHJcblxyXG5cdC0tbHVtaS13aGl0ZS1jb2xvcjogI2ZmZmZmZjtcclxuXHQtLWx1bWktcHJpbWFyeS15ZWxsb3ctY29sb3I6ICNmYWI2MDA7XHJcbn1cclxuJGNvbG9yLW5leHRnZW4tYmx1ZTogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlKTtcclxuJGNvbG9yLW5leHRnZW4tZ3JlZW46IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4pO1xyXG4kY29sb3ItbmV4dGdlbi13aGl0ZTogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi13aGl0ZSk7XHJcbiRjb2xvci1uZXh0Z2VuLWJsYWNrOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWJsYWNrKTtcclxuJGNvbG9yLW5leHRnZW4tZ3JleS1iYWNrZ3JvdW5kOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZXktYmFja2dyb3VuZCk7XHJcbiRjb2xvci1uZXh0Z2VuLWdyZXk6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JleSk7XHJcbiRjb2xvci1uZXh0Z2VuLXN0b25lLWdyZXk6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tc3RvbmUtZ3JleSk7XHJcbiRjb2xvci1uZXh0Z2VuLWVycm9yOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWVycm9yKTtcclxuJGNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5OiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleSk7XHJcbiRjb2xvci1uZXh0Z2VuLWZpYnJhbnQtZ3JlZW46IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZmlicmFudC1ncmVlbik7XHJcbiRjb2xvci1uZXh0Z2VuLXdhcm5pbmc6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4td2FybmluZyk7XHJcbiRjb2xvci1uZXh0Z2VuLWdyZWVuLWJhY2tncm91bmQ6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4tYmFja2dyb3VuZCk7XHJcbiRjb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS01MDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNTApO1xyXG4kY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNDAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS00MDApO1xyXG4kY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktMTAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS0xMDApO1xyXG4kY29sb3ItbmV4dGdlbi1zdGF0dXMtZXJyb3I6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yKTtcclxuJGNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yLWJhY2tncm91bmQ6IHZhcihcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yLWJhY2tncm91bmRcclxuKTtcclxuJGNvbG9yLW5leHRnZW4tc3RhdHVzLXdhcm5pbmc6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLXdhcm5pbmcpO1xyXG4kY29sb3ItbmV4dGdlbi1zdGF0dXMtd2FybmluZy1iYWNrZ3JvdW5kOiB2YXIoXHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy13YXJuaW5nLWJhY2tncm91bmRcclxuKTtcclxuJGNvbG9yLW5leHRnZW4tYmx1ZS0xMDA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZS0xMDApO1xyXG4kY29sb3ItbmV4dGdlbi1lcnJvci1yZWQtNzAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWVycm9yLXJlZC03MDApO1xyXG4kY29sb3ItbmV4dGdlbi1ibHVlLTUwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlLTUwMCk7XHJcbiRjb2xvci1uZXh0Z2VuLWJsdWUtNDAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWJsdWUtNDAwKTtcclxuJGNvbG9yLW5leHRnZW4tcmVkLTUwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1yZWQtNTAwKTtcclxuJGNvbG9yLW5leHRnZW4tc2Vjb25kYXJ5LWJsdWUtMzAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXNlY29uZGFyeS1ibHVlLTMwMCk7XHJcblxyXG4uaW9uLWNvbG9yLWdyZWVuIHtcclxuXHQtLWlvbi1jb2xvci1iYXNlOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuKTtcclxuXHQtLWlvbi1jb2xvci1iYXNlLXJnYjogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbik7XHJcblx0LS1pb24tY29sb3ItY29udHJhc3Q6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4td2hpdGUpO1xyXG5cdC0taW9uLWNvbG9yLWNvbnRyYXN0LXJnYjogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbik7XHJcblx0LS1pb24tY29sb3Itc2hhZGU6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4pO1xyXG5cdC0taW9uLWNvbG9yLXRpbnQ6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4pO1xyXG59XHJcbiIsIkBpbXBvcnQgXCIuLi8uLi8uLi9jb2xvci5zY3NzXCI7XHJcblxyXG4uY29udHJvbC1hcmlhe1xyXG4gIHBhZGRpbmctYm90dG9tOiAyNHB4O1xyXG59XHJcblxyXG4uc2lnaW4taGVhZGVye1xyXG4gIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcclxufVxyXG5cclxuLnNpZ24taW4tY29udGFpbmVyIHtcclxuICBiYWNrZ3JvdW5kOiAkY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNTA7XHJcbn1cclxuXHJcbi5uZWVkLWhlbHAtdGV4dCB7XHJcbiAgY29sb3I6ICRjb2xvci1uZXh0Z2VuLWdyZWVuO1xyXG4gIC8vIGZsb2F0OiByaWdodCAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4udGl0bGUtdGV4dCB7XHJcbiAgcGFkZGluZy1sZWZ0OiAycmVtO1xyXG4gIGNvbG9yOiAkY29sb3ItbmV4dGdlbi1ibHVlO1xyXG59XHJcblxyXG4uc2lnbi1pbi10aXRsZSB7XHJcbiAgY29sb3I6ICRjb2xvci1uZXh0Z2VuLWJsYWNrO1xyXG4gIHBhZGRpbmctdG9wOiA0MHB4O1xyXG59XHJcblxyXG4uZm9ybS1zaWduLWluIHtcclxuICB3aWR0aDogMTAwJTtcclxuICBwYWRkaW5nLXRvcDogMzJweDtcclxufVxyXG5cclxuLnRleHQtZm9yZ290LXBhc3N3b3JkIHtcclxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgcGFkZGluZy10b3A6IDI0cHg7XHJcbn1cclxuXHJcbi50ZXh0LWRvbnQtaGF2ZS1hY2NvdW50LXJlZ2lzdGVyIHtcclxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgcGFkZGluZy10b3A6IDcycHg7XHJcbn1cclxuXHJcbi50ZXh0LWRvbnQtaGF2ZS1hY2NvdW50IHtcclxuICBjb2xvcjogJGNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTQwMDtcclxufVxyXG5cclxuLmJ1dHRvbi1sb2dpbi1hY2NvdW50IHtcclxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgcGFkZGluZy10b3A6IDQwcHg7XHJcbn1cclxuXHJcbi5idXR0b24tbGFuZ3VhZ2Uge1xyXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGFsaWduLWl0ZW1zOiBmbGV4LWVuZDtcclxuICBwYWRkaW5nLXRvcDogODBweDtcclxufVxyXG5cclxuLnRleHQtbGluayB7XHJcbiAgY29sb3I6ICRjb2xvci1uZXh0Z2VuLWdyZWVuICAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4uaWNvbi1pbnB1dCB7XHJcbiAgY29sb3I6ICRjb2xvci1uZXh0Z2VuLWdyZXk7XHJcbn1cclxuXHJcbi50ZXh0LXZhbGlkYXRpb24ge1xyXG4gIGNvbG9yOiAkY29sb3ItbmV4dGdlbi1ncmV5ICAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4uaWNvbi1sYW5ndWFnZSB7XHJcbiAgY29sb3I6ICRjb2xvci1uZXh0Z2VuLWdyZWVuICAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4uc2lnbi1pbi1jb250ZW50IHtcclxuICBiYWNrZ3JvdW5kOiAkY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNTA7XHJcbiAgaGVpZ2h0OiAxMDAlICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi50ZXh0LWN1cnJlbnQtbGFuZ3VhZ2Uge1xyXG4gIHBhZGRpbmctbGVmdDogMC41cmVtO1xyXG4gIHBhZGRpbmctcmlnaHQ6IDAuNXJlbTtcclxuICBjb2xvcjogJGNvbG9yLW5leHRnZW4tZ3JlZW4gICFpbXBvcnRhbnQ7XHJcbn1cclxuLnZlcnNpb24tYXBwe1xyXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICBjb2xvcjogJGNvbG9yLW5leHRnZW4tYmxhY2s7XHJcbiAgcGFkZGluZy10b3A6IDEuOHJlbTtcclxufVxyXG5pb24taWNvbntcclxuICBoZWlnaHQ6IDExcHg7XHJcbn0iXX0= */";

/***/ }),

/***/ 54204:
/*!**********************************************************!*\
  !*** ./src/app/pages/signin/signin.page.html?ngResource ***!
  \**********************************************************/
/***/ ((module) => {

module.exports = "<div class=\"sign-in-container\">\r\n  <nextcare-layout>\r\n    <ng-template header>\r\n      <ion-row class=\"sigin-header d-flex\">\r\n        <div>\r\n          <!-- <button class=\"btn btn-circle\" (click)=\"onBack()\"><i class=\"icon-back body-l\"></i></button> -->\r\n        </div>\r\n        <div>\r\n          <span class=\"need-help-text body-l bold\" (click)=\"redirectToNeedHelp()\">{{\r\n            'signin.needHelp' |\r\n            translate }}</span>\r\n        </div>\r\n      </ion-row>\r\n    </ng-template>\r\n    <ng-template body>\r\n      <div class=\"sign-in-content\">\r\n        <div class=\"sign-in-title h1 bold col-7\">\r\n          {{'signin.title' | translate}}\r\n        </div>\r\n        <div>\r\n          <form class=\"form-sign-in\" [formGroup]=\"signInForm\" autocomplete=\"on\">\r\n            <div class=\"control-aria\">\r\n              <nextgen-control [type]=\"TYPE.INPUT\" [label-property]=\"'signin.email' | translate\"\r\n              (focusHandler)=\"onFocusInputEvent()\"\r\n                [placeholder]=\"'signin.emailPlaceholder' | translate\" first-icon=\"uil uil-envelope\"\r\n                formControlName=\"login\" \r\n                (focusoutHandler)=\"focusoutHandler()\"\r\n                [showValidation]=\"showValidation\"\r\n                [custom-validation]=\"customValidation\"\r\n                >\r\n              </nextgen-control>\r\n            </div>\r\n            <div>\r\n              <nextgen-control [type]=\"typeInputPassword\" [label-property]=\"'signin.password' | translate\"\r\n                [placeholder]=\"'signin.passwordPlaceholder' | translate\" first-icon=\"uil uil-lock-alt\"\r\n                [second-icon]=\"secondIcon\" (secondIconHandler)=\"togglePassword()\" formControlName=\"password\">\r\n              </nextgen-control>\r\n            </div>\r\n\r\n            <div class=\"button-login-account\">\r\n              <button class=\"btn btn-large primary bold\" (click)=\"login()\" [disabled]=\"signInForm.invalid\">{{\r\n                'signin.login' | translate }}</button>\r\n            </div>\r\n            <div class=\"text-forgot-password\">\r\n              <span class=\"body-n bold text-link\" (click)=\"redirectToForgotPassword()\">{{'signin.forgotPassword'|\r\n                translate}}</span>\r\n            </div>\r\n            <div class=\"text-dont-have-account-register\">\r\n              <span class=\"body-n text-dont-have-account\">{{'signin.dontHaveAnAccount'| translate}}</span>\r\n              <span class=\"body-n bold text-link\" (click)=\"redirectToRegister()\">{{'signin.register'| translate}}</span>\r\n            </div>\r\n          </form>\r\n        </div>\r\n        <div class=\"button-language\">\r\n          <button class=\"btn transparent btn-no-space semibold body-sm\" (click)=\"openDialogLanguage()\">\r\n            <i class=\"uil uil-globe icon-language\"></i>\r\n            <span class=\"text-current-language\">{{currentLanguageName}}</span>\r\n            <!-- <img src=\"../../../assets/icon/Polygon.svg\" /> -->\r\n            <ion-icon class=\"uil\" name=\"caret-forward-outline\"></ion-icon>\r\n          </button>\r\n        </div>\r\n        <p class=\"version-app body-xs\">{{'home.appversion' | translate}} {{versionApp}}</p>\r\n      </div>\r\n    </ng-template>\r\n  </nextcare-layout>\r\n</div>";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_signin_signin_module_ts.js.map