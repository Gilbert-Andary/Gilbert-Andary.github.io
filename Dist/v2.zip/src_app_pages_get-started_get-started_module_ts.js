"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_get-started_get-started_module_ts"],{

/***/ 37187:
/*!*****************************************************************!*\
  !*** ./src/app/pages/get-started/get-started-routing.module.ts ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "GetStartedRoutingModule": () => (/* binding */ GetStartedRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _get_started_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./get-started.page */ 30446);




const routes = [
    {
        path: '',
        component: _get_started_page__WEBPACK_IMPORTED_MODULE_0__.GetStartedPage,
    },
];
let GetStartedRoutingModule = class GetStartedRoutingModule {
};
GetStartedRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], GetStartedRoutingModule);



/***/ }),

/***/ 61675:
/*!*********************************************************!*\
  !*** ./src/app/pages/get-started/get-started.module.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "GetStartedModule": () => (/* binding */ GetStartedModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _get_started_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./get-started.page */ 30446);
/* harmony import */ var _get_started_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./get-started-routing.module */ 37187);
/* harmony import */ var src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/shared/shared.module */ 44466);








let GetStartedModule = class GetStartedModule {
};
GetStartedModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonicModule,
            _get_started_routing_module__WEBPACK_IMPORTED_MODULE_1__.GetStartedRoutingModule,
            src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_2__.SharedModule,
        ],
        declarations: [_get_started_page__WEBPACK_IMPORTED_MODULE_0__.GetStartedPage]
    })
], GetStartedModule);



/***/ }),

/***/ 30446:
/*!*******************************************************!*\
  !*** ./src/app/pages/get-started/get-started.page.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "GetStartedPage": () => (/* binding */ GetStartedPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _get_started_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./get-started.page.html?ngResource */ 79996);
/* harmony import */ var _get_started_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./get-started.page.scss?ngResource */ 89640);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _awesome_cordova_plugins_app_version_ngx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @awesome-cordova-plugins/app-version/ngx */ 74582);
/* harmony import */ var _awesome_cordova_plugins_clevertap_ngx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @awesome-cordova-plugins/clevertap/ngx */ 45363);
/* harmony import */ var _awesome_cordova_plugins_firebase_analytics_ngx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @awesome-cordova-plugins/firebase-analytics/ngx */ 48852);
/* harmony import */ var _capgo_capacitor_navigation_bar__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @capgo/capacitor-navigation-bar */ 48012);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @environments/environment */ 92340);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @ionic/storage-angular */ 80190);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var src_app_service_language_language_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/service/language/language.service */ 11281);
/* harmony import */ var src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/shared/data/constants */ 74676);
/* harmony import */ var src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/shared/data/enum/event */ 38570);
/* harmony import */ var src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/app/shared/data/enum/screen */ 68302);

















let GetStartedPage = class GetStartedPage {
    constructor(router, storage, firebaseAnalytics, clevertap, appVersion, platform, languageService, translate) {
        this.router = router;
        this.storage = storage;
        this.firebaseAnalytics = firebaseAnalytics;
        this.clevertap = clevertap;
        this.appVersion = appVersion;
        this.platform = platform;
        this.languageService = languageService;
        this.translate = translate;
        this.versionApp = _environments_environment__WEBPACK_IMPORTED_MODULE_6__.environment.appVersion;
        this.language = null;
        this.labels = [];
        this.currentIndex = 0;
        this.currentLabel = undefined;
    }
    ngOnInit() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_11__.__awaiter)(this, void 0, void 0, function* () {
            this.languageService.getLanguages().subscribe((data) => (0,tslib__WEBPACK_IMPORTED_MODULE_11__.__awaiter)(this, void 0, void 0, function* () {
                data.forEach((obj, idx, array) => (0,tslib__WEBPACK_IMPORTED_MODULE_11__.__awaiter)(this, void 0, void 0, function* () {
                    let translatedvalue = yield this.languageService.getJsonKeyValue('getStarted', 'getStarted', obj.culture);
                    this.labels.push(translatedvalue);
                    if (array.length - 1 == idx) {
                        this.triggerInterval();
                    }
                }));
            }));
            try {
                this.versionApp = yield this.appVersion.getVersionNumber();
            }
            catch (error) {
                console.log(error);
            }
        });
    }
    triggerInterval() {
        this.currentLabel = this.labels[this.currentIndex];
        setInterval(() => {
            this.currentIndex = (this.currentIndex + 1) % this.labels.length;
            this.currentLabel = undefined;
            setTimeout(() => {
                this.currentLabel = this.labels[this.currentIndex];
            }, 10);
        }, 2000);
    }
    ionViewWillEnter() {
        this.platform.ready().then(() => {
            _capgo_capacitor_navigation_bar__WEBPACK_IMPORTED_MODULE_5__.NavigationBar.setNavigationBarColor({
                color: '#0D152E',
            });
        });
    }
    ionViewDidEnter() {
        this.subscription = this.platform.backButton.subscribeWithPriority(9999, () => {
            navigator['app'].exitApp();
        });
    }
    ionViewWillLeave() {
        this.platform.ready().then(() => {
            _capgo_capacitor_navigation_bar__WEBPACK_IMPORTED_MODULE_5__.NavigationBar.setNavigationBarColor({
                color: '#FFFFFF',
            });
        });
        this.subscription.unsubscribe();
    }
    redirectToSelectLanguage() {
        this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_10__.Screens.LanguageSelection]).then(() => { });
        this.firebaseAnalytics.logEvent(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_9__.GA4Event.OnboardingProceeded, {});
        this.clevertap.recordEventWithName(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_9__.GA4Event.OnboardingProceeded);
    }
    redirectToSignIn() {
        this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_10__.Screens.SignIn]).then(() => { });
        this.firebaseAnalytics.logEvent(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_9__.GA4Event.OnboardingProceeded, {});
        this.clevertap.recordEventWithName('registration_home_screen');
        window.localStorage.setItem(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_8__.Constants.PREFERED_LANGUAGE, src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_8__.Constants.DEFAULT_LANGUAGE);
    }
};
GetStartedPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_12__.Router },
    { type: _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_13__.Storage },
    { type: _awesome_cordova_plugins_firebase_analytics_ngx__WEBPACK_IMPORTED_MODULE_4__.FirebaseAnalytics },
    { type: _awesome_cordova_plugins_clevertap_ngx__WEBPACK_IMPORTED_MODULE_3__.CleverTap },
    { type: _awesome_cordova_plugins_app_version_ngx__WEBPACK_IMPORTED_MODULE_2__.AppVersion },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_14__.Platform },
    { type: src_app_service_language_language_service__WEBPACK_IMPORTED_MODULE_7__.LanguageService },
    { type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_15__.TranslateService }
];
GetStartedPage = (0,tslib__WEBPACK_IMPORTED_MODULE_11__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_16__.Component)({
        selector: 'app-get-started',
        template: _get_started_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_get_started_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], GetStartedPage);



/***/ }),

/***/ 74675:
/*!******************************************************************************!*\
  !*** ./node_modules/@capgo/capacitor-navigation-bar/dist/esm/definitions.js ***!
  \******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);



/***/ }),

/***/ 48012:
/*!************************************************************************!*\
  !*** ./node_modules/@capgo/capacitor-navigation-bar/dist/esm/index.js ***!
  \************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NavigationBar": () => (/* binding */ NavigationBar)
/* harmony export */ });
/* harmony import */ var _capacitor_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @capacitor/core */ 26549);
/* harmony import */ var _definitions__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./definitions */ 74675);

const NavigationBar = (0,_capacitor_core__WEBPACK_IMPORTED_MODULE_0__.registerPlugin)('NavigationBar', {
    web: () => __webpack_require__.e(/*! import() */ "node_modules_capgo_capacitor-navigation-bar_dist_esm_web_js").then(__webpack_require__.bind(__webpack_require__, /*! ./web */ 15610)).then(m => new m.NavigationBarWeb()),
});




/***/ }),

/***/ 89640:
/*!********************************************************************!*\
  !*** ./src/app/pages/get-started/get-started.page.scss?ngResource ***!
  \********************************************************************/
/***/ ((module) => {

module.exports = ":root {\n  --nc-color-nextgen-neutral-grey-50: red;\n  --nc-color-nextgen-white: yellow;\n  --nc-color-nextgen-blue: #0d152e;\n  --nc-color-nextgen-green: #00908d;\n  --nc-color-nextgen-black: #000000;\n  --nc-color-nextgen-grey-background: #c8d3da;\n  --nc-color-nextgen-grey: #92a2ac;\n  --nc-color-nextgen-stone-grey: #fafafa;\n  --nc-color-nextgen-error: #fc1055;\n  --nc-color-nextgen-neutral-grey: #414141;\n  --nc-color-nextgen-fibrant-green: #00bab6;\n  --nc-color-nextgen-warning: #ffd048;\n  --nc-color-nextgen-green-background: #e6f2f2;\n  --nc-color-nextgen-neutral-grey-400: #7a7a7a;\n  --nc-color-nextgen-neutral-grey-100: #eff3f5;\n  --nc-color-nextgen-status-error: #ba0c3f;\n  --nc-color-nextgen-status-error-background: #ffeff4;\n  --nc-color-nextgen-status-warning: #cba127;\n  --nc-color-nextgen-status-warning-background: #fff8e6;\n  --nc-color-nextgen-blue-100: #dfeff2;\n  --nc-color-nextgen-error-red-700: #f62459;\n  --nc-color-nextgen-blue-500: #006192;\n  --nc-color-nextgen-blue-400: #79cdec;\n  --nc-color-nextgen-red-500: #ff6592;\n  --nc-color-nextgen-secondary-blue-300: #13a0d3;\n  --lumi-white-color: #ffffff;\n  --lumi-primary-yellow-color: #fab600;\n}\n\n.ion-color-green {\n  --ion-color-base: var(--nc-color-nextgen-green);\n  --ion-color-base-rgb: var(--nc-color-nextgen-green);\n  --ion-color-contrast: var(--nc-color-nextgen-white);\n  --ion-color-contrast-rgb: var(--nc-color-nextgen-green);\n  --ion-color-shade: var(--nc-color-nextgen-green);\n  --ion-color-tint: var(--nc-color-nextgen-green);\n}\n\n.get-started-container nextcare-layout {\n  background: var(--lumi-primary-yellow-color);\n}\n\n.get-started-container .login {\n  text-align: right;\n}\n\n.get-started-container .login .login-text {\n  color: var(--lumi-white-color);\n}\n\n.get-started-container .next-care-logo {\n  display: flex;\n  align-items: center;\n  height: 80%;\n  justify-content: center;\n}\n\n.get-started-container .get-started {\n  text-align: center;\n  height: 57px;\n}\n\n:host ::ng-deep ion-title {\n  background-color: var(--lumi-primary-yellow-color) !important;\n}\n\n.version-app {\n  text-align: center;\n  color: var(--lumi-white-color);\n  padding-top: 1.8rem;\n}\n\n.lumi-primary {\n  background: var(--lumi-white-color);\n  color: var(--lumi-primary-yellow-color);\n  font-weight: bold;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXGNvbG9yLnNjc3MiLCJnZXQtc3RhcnRlZC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDQyx1Q0FBQTtFQUNBLGdDQUFBO0VBQ0EsZ0NBQUE7RUFDQSxpQ0FBQTtFQUNBLGlDQUFBO0VBQ0EsMkNBQUE7RUFDQSxnQ0FBQTtFQUNBLHNDQUFBO0VBQ0EsaUNBQUE7RUFDQSx3Q0FBQTtFQUNBLHlDQUFBO0VBQ0EsbUNBQUE7RUFDQSw0Q0FBQTtFQUNBLDRDQUFBO0VBQ0EsNENBQUE7RUFDQSx3Q0FBQTtFQUNBLG1EQUFBO0VBQ0EsMENBQUE7RUFDQSxxREFBQTtFQUNBLG9DQUFBO0VBQ0EseUNBQUE7RUFDQSxvQ0FBQTtFQUNBLG9DQUFBO0VBQ0EsbUNBQUE7RUFDQSw4Q0FBQTtFQUVBLDJCQUFBO0VBQ0Esb0NBQUE7QUNBRDs7QURnQ0E7RUFDQywrQ0FBQTtFQUNBLG1EQUFBO0VBQ0EsbURBQUE7RUFDQSx1REFBQTtFQUNBLGdEQUFBO0VBQ0EsK0NBQUE7QUM3QkQ7O0FBbkNDO0VBQ0MsNENBQUE7QUFzQ0Y7O0FBcENDO0VBQ0MsaUJBQUE7QUFzQ0Y7O0FBckNFO0VBQ0MsOEJBQUE7QUF1Q0g7O0FBcENDO0VBQ0MsYUFBQTtFQUNBLG1CQUFBO0VBQ0EsV0FBQTtFQUNBLHVCQUFBO0FBc0NGOztBQWhDQztFQUNDLGtCQUFBO0VBQ0EsWUFBQTtBQWtDRjs7QUE5QkE7RUFDQyw2REFBQTtBQWlDRDs7QUEvQkE7RUFDQyxrQkFBQTtFQUNBLDhCQUFBO0VBQ0EsbUJBQUE7QUFrQ0Q7O0FBL0JBO0VBQ0MsbUNBQUE7RUFDQSx1Q0FBQTtFQUNBLGlCQUFBO0FBa0NEIiwiZmlsZSI6ImdldC1zdGFydGVkLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIjpyb290IHtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTUwOiByZWQ7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXdoaXRlOiB5ZWxsb3c7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWJsdWU6ICMwZDE1MmU7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuOiAjMDA5MDhkO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ibGFjazogIzAwMDAwMDtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tZ3JleS1iYWNrZ3JvdW5kOiAjYzhkM2RhO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ncmV5OiAjOTJhMmFjO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zdG9uZS1ncmV5OiAjZmFmYWZhO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1lcnJvcjogI2ZjMTA1NTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5OiAjNDE0MTQxO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1maWJyYW50LWdyZWVuOiAjMDBiYWI2O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi13YXJuaW5nOiAjZmZkMDQ4O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbi1iYWNrZ3JvdW5kOiAjZTZmMmYyO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNDAwOiAjN2E3YTdhO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktMTAwOiAjZWZmM2Y1O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtZXJyb3I6ICNiYTBjM2Y7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy1lcnJvci1iYWNrZ3JvdW5kOiAjZmZlZmY0O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtd2FybmluZzogI2NiYTEyNztcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLXdhcm5pbmctYmFja2dyb3VuZDogI2ZmZjhlNjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZS0xMDA6ICNkZmVmZjI7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWVycm9yLXJlZC03MDA6ICNmNjI0NTk7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWJsdWUtNTAwOiAjMDA2MTkyO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlLTQwMDogIzc5Y2RlYztcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tcmVkLTUwMDogI2ZmNjU5MjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc2Vjb25kYXJ5LWJsdWUtMzAwOiAjMTNhMGQzO1xyXG5cclxuXHQtLWx1bWktd2hpdGUtY29sb3I6ICNmZmZmZmY7XHJcblx0LS1sdW1pLXByaW1hcnkteWVsbG93LWNvbG9yOiAjZmFiNjAwO1xyXG59XHJcbiRjb2xvci1uZXh0Z2VuLWJsdWU6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZSk7XHJcbiRjb2xvci1uZXh0Z2VuLWdyZWVuOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuKTtcclxuJGNvbG9yLW5leHRnZW4td2hpdGU6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4td2hpdGUpO1xyXG4kY29sb3ItbmV4dGdlbi1ibGFjazogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ibGFjayk7XHJcbiRjb2xvci1uZXh0Z2VuLWdyZXktYmFja2dyb3VuZDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmV5LWJhY2tncm91bmQpO1xyXG4kY29sb3ItbmV4dGdlbi1ncmV5OiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZXkpO1xyXG4kY29sb3ItbmV4dGdlbi1zdG9uZS1ncmV5OiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXN0b25lLWdyZXkpO1xyXG4kY29sb3ItbmV4dGdlbi1lcnJvcjogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1lcnJvcik7XHJcbiRjb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleTogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXkpO1xyXG4kY29sb3ItbmV4dGdlbi1maWJyYW50LWdyZWVuOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWZpYnJhbnQtZ3JlZW4pO1xyXG4kY29sb3ItbmV4dGdlbi13YXJuaW5nOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXdhcm5pbmcpO1xyXG4kY29sb3ItbmV4dGdlbi1ncmVlbi1iYWNrZ3JvdW5kOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuLWJhY2tncm91bmQpO1xyXG4kY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNTA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTUwKTtcclxuJGNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTQwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNDAwKTtcclxuJGNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTEwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktMTAwKTtcclxuJGNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy1lcnJvcik7XHJcbiRjb2xvci1uZXh0Z2VuLXN0YXR1cy1lcnJvci1iYWNrZ3JvdW5kOiB2YXIoXHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy1lcnJvci1iYWNrZ3JvdW5kXHJcbik7XHJcbiRjb2xvci1uZXh0Z2VuLXN0YXR1cy13YXJuaW5nOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy13YXJuaW5nKTtcclxuJGNvbG9yLW5leHRnZW4tc3RhdHVzLXdhcm5pbmctYmFja2dyb3VuZDogdmFyKFxyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtd2FybmluZy1iYWNrZ3JvdW5kXHJcbik7XHJcbiRjb2xvci1uZXh0Z2VuLWJsdWUtMTAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWJsdWUtMTAwKTtcclxuJGNvbG9yLW5leHRnZW4tZXJyb3ItcmVkLTcwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1lcnJvci1yZWQtNzAwKTtcclxuJGNvbG9yLW5leHRnZW4tYmx1ZS01MDA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZS01MDApO1xyXG4kY29sb3ItbmV4dGdlbi1ibHVlLTQwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlLTQwMCk7XHJcbiRjb2xvci1uZXh0Z2VuLXJlZC01MDA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tcmVkLTUwMCk7XHJcbiRjb2xvci1uZXh0Z2VuLXNlY29uZGFyeS1ibHVlLTMwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1zZWNvbmRhcnktYmx1ZS0zMDApO1xyXG5cclxuLmlvbi1jb2xvci1ncmVlbiB7XHJcblx0LS1pb24tY29sb3ItYmFzZTogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbik7XHJcblx0LS1pb24tY29sb3ItYmFzZS1yZ2I6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4pO1xyXG5cdC0taW9uLWNvbG9yLWNvbnRyYXN0OiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXdoaXRlKTtcclxuXHQtLWlvbi1jb2xvci1jb250cmFzdC1yZ2I6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4pO1xyXG5cdC0taW9uLWNvbG9yLXNoYWRlOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuKTtcclxuXHQtLWlvbi1jb2xvci10aW50OiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuKTtcclxufVxyXG4iLCJAaW1wb3J0IFwiLi4vLi4vLi4vY29sb3Iuc2Nzc1wiO1xyXG4uZ2V0LXN0YXJ0ZWQtY29udGFpbmVyIHtcclxuXHRuZXh0Y2FyZS1sYXlvdXQge1xyXG5cdFx0YmFja2dyb3VuZDogdmFyKC0tbHVtaS1wcmltYXJ5LXllbGxvdy1jb2xvcik7XHJcblx0fVxyXG5cdC5sb2dpbiB7XHJcblx0XHR0ZXh0LWFsaWduOiByaWdodDtcclxuXHRcdC5sb2dpbi10ZXh0IHtcclxuXHRcdFx0Y29sb3I6IHZhcigtLWx1bWktd2hpdGUtY29sb3IpO1xyXG5cdFx0fVxyXG5cdH1cclxuXHQubmV4dC1jYXJlLWxvZ28ge1xyXG5cdFx0ZGlzcGxheTogZmxleDtcclxuXHRcdGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcblx0XHRoZWlnaHQ6IDgwJTtcclxuXHRcdGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG5cdFx0aW1nIHtcclxuXHRcdFx0Ly8gaGVpZ2h0OiAzNHB4O1xyXG5cdFx0XHQvLyB3aWR0aDogMTkwcHg7XHJcblx0XHR9XHJcblx0fVxyXG5cdC5nZXQtc3RhcnRlZCB7XHJcblx0XHR0ZXh0LWFsaWduOiBjZW50ZXI7XHJcblx0XHRoZWlnaHQ6IDU3cHg7XHJcblx0fVxyXG59XHJcblxyXG46aG9zdCA6Om5nLWRlZXAgaW9uLXRpdGxlIHtcclxuXHRiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1sdW1pLXByaW1hcnkteWVsbG93LWNvbG9yKSAhaW1wb3J0YW50O1xyXG59XHJcbi52ZXJzaW9uLWFwcCB7XHJcblx0dGV4dC1hbGlnbjogY2VudGVyO1xyXG5cdGNvbG9yOiB2YXIoLS1sdW1pLXdoaXRlLWNvbG9yKTtcclxuXHRwYWRkaW5nLXRvcDogMS44cmVtO1xyXG59XHJcblxyXG4ubHVtaS1wcmltYXJ5IHtcclxuXHRiYWNrZ3JvdW5kOiB2YXIoLS1sdW1pLXdoaXRlLWNvbG9yKTtcclxuXHRjb2xvcjogdmFyKC0tbHVtaS1wcmltYXJ5LXllbGxvdy1jb2xvcik7XHJcblx0Zm9udC13ZWlnaHQ6IGJvbGQ7XHJcbn1cclxuIl19 */";

/***/ }),

/***/ 79996:
/*!********************************************************************!*\
  !*** ./src/app/pages/get-started/get-started.page.html?ngResource ***!
  \********************************************************************/
/***/ ((module) => {

module.exports = "<div class=\"get-started-container\">\r\n\t<nextcare-layout>\r\n\t\t<ng-template header>\r\n\t\t\t<div class=\"login\">\r\n\t\t\t\t<div class=\"login-text h5 bold\" (click)=\"redirectToSignIn()\">{{ 'getStarted.login' | translate }}</div>\r\n\t\t\t</div>\r\n\t\t</ng-template>\r\n\t\t<ng-template body>\r\n\t\t\t<div class=\"next-care-logo\">\r\n\t\t\t\t<img src=\"../../../assets/icon/logo-white.svg\" />\r\n\t\t\t</div>\r\n\t\t\t<div class=\"bottom-section\">\r\n\t\t\t\t<!-- <div class=\"get-started\">\r\n          <button class=\"btn btn-large primary bold\" (click)=\"redirectToSelectLanguage()\">{{ 'getStarted.getStarted' |\r\n            translate }}</button>\r\n        </div> -->\r\n\t\t\t\t<div class=\"iphone get-started\">\r\n\t\t\t\t\t<button class=\"btn btn-large primary bold lumi-primary\" (click)=\"redirectToSelectLanguage()\">\r\n\t\t\t\t\t\t<div class=\"lumi-primary animate__animated animate__slideInRight\" *ngIf=\"currentLabel\">{{ labels[currentIndex] }}</div>\r\n\t\t\t\t\t</button>\r\n\t\t\t\t</div>\r\n\t\t\t\t<p class=\"version-app body-xs\">{{'home.appversion' | translate}} {{versionApp}}</p>\r\n\t\t\t</div>\r\n\t\t</ng-template>\r\n\t</nextcare-layout>\r\n</div>\r\n";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_get-started_get-started_module_ts.js.map