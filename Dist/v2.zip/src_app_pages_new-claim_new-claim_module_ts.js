"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_new-claim_new-claim_module_ts"],{

/***/ 58551:
/*!**************************************************************************!*\
  !*** ./src/app/pages/new-claim/claim-details/claim-details.component.ts ***!
  \**************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ClaimDetailsComponent": () => (/* binding */ ClaimDetailsComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _claim_details_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./claim-details.component.html?ngResource */ 64192);
/* harmony import */ var _claim_details_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./claim-details.component.scss?ngResource */ 53228);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _awesome_cordova_plugins_clevertap_ngx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @awesome-cordova-plugins/clevertap/ngx */ 45363);
/* harmony import */ var _awesome_cordova_plugins_firebase_analytics_ngx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @awesome-cordova-plugins/firebase-analytics/ngx */ 48852);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var country_iso_3_to_2__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! country-iso-3-to-2 */ 97754);
/* harmony import */ var country_iso_3_to_2__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(country_iso_3_to_2__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! rxjs */ 92218);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! rxjs/operators */ 85921);
/* harmony import */ var src_app_model_control_control_model__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/model/control/control.model */ 45482);
/* harmony import */ var src_app_service_country_countries_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/service/country/countries.service */ 51249);
/* harmony import */ var src_app_service_insurance_insurance_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/service/insurance/insurance.service */ 57072);
/* harmony import */ var src_app_service_new_claim_coverages_coverages_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/service/new-claim/coverages/coverages.service */ 86280);
/* harmony import */ var src_app_service_new_claim_currencies_currencies_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/service/new-claim/currencies/currencies.service */ 60564);
/* harmony import */ var src_app_service_new_claim_new_claim_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/app/service/new-claim/new-claim.service */ 90888);
/* harmony import */ var src_app_service_new_claim_provider_agreement_provider_agreement_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/app/service/new-claim/provider-agreement/provider-agreement.service */ 40050);
/* harmony import */ var src_app_service_new_claim_service_type_service_types_service__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! src/app/service/new-claim/service-type/service-types.service */ 99466);
/* harmony import */ var src_app_shared_components_nextgen_dialog_nextgen_dialog_service__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! src/app/shared/components/nextgen-dialog/nextgen-dialog.service */ 96485);
/* harmony import */ var src_app_shared_components_popup_message_popup_message_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! src/app/shared/components/popup-message/popup-message.component */ 18290);
/* harmony import */ var src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! src/app/shared/data/enum/event */ 38570);
/* harmony import */ var src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! src/app/shared/data/enum/screen */ 68302);
/* harmony import */ var src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! src/app/shared/data/constants */ 74676);
/* harmony import */ var src_app_shared_components_privacy_consent_dialog_privacy_consent_dialog_component__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! src/app/shared/components/privacy-consent-dialog/privacy-consent-dialog.component */ 61262);
/* harmony import */ var src_app_service_new_claim_consent_consent_service__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! src/app/service/new-claim/consent/consent.service */ 41413);
/* harmony import */ var src_app_shared_components_save_draft_save_draft_component__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! src/app/shared/components/save-draft/save-draft.component */ 38317);





























let ClaimDetailsComponent = class ClaimDetailsComponent {
    constructor(serviceType, router, firebaseAnalytics, insuranceService, currencyService, dialogSevice, newClaimService, countryService, form, clevertap, datePipe, coveragesService, consentService, providerAgreementService, platform) {
        this.serviceType = serviceType;
        this.router = router;
        this.firebaseAnalytics = firebaseAnalytics;
        this.insuranceService = insuranceService;
        this.currencyService = currencyService;
        this.dialogSevice = dialogSevice;
        this.newClaimService = newClaimService;
        this.countryService = countryService;
        this.form = form;
        this.clevertap = clevertap;
        this.datePipe = datePipe;
        this.coveragesService = coveragesService;
        this.consentService = consentService;
        this.providerAgreementService = providerAgreementService;
        this.platform = platform;
        this.isShowDischargeDate = false;
        this.TYPE = src_app_model_control_control_model__WEBPACK_IMPORTED_MODULE_5__.ControlType;
        this.maxDate = new Date().toISOString();
        this.unsubscribe$ = new rxjs__WEBPACK_IMPORTED_MODULE_21__.Subject();
        this.onContinue = () => {
            this.claimForm.markAllAsTouched();
            this.claimForm.markAsDirty();
            if (this.claimForm.valid) {
                this.firebaseAnalytics.logEvent(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_15__.GA4Event.ReimbursmentClaimDetailsConfirmed, {
                    member_name: this.claimForm.value.memberSelect.name,
                    country_name: this.claimForm.value.countrySelect.name,
                    service_type: this.claimForm.value.serviceType.name,
                    service_date: this.claimForm.value.serviceDate,
                    currency_name: this.claimForm.value.currency.name,
                    amount_number: this.claimForm.value.amount,
                });
                this.clevertap.recordEventWithNameAndProps(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_15__.GA4Event.ReimbursmentClaimDetailsConfirmed, {
                    member_name: this.claimForm.value.memberSelect.name,
                    country_name: this.claimForm.value.countrySelect.name,
                    service_type: this.claimForm.value.serviceType.name,
                    service_date: this.claimForm.value.serviceDate,
                    currency_name: this.claimForm.value.currency.name,
                    amount_number: this.claimForm.value.amount,
                });
                this.newClaimService.setLocalStorageSubmitClaim();
                if (this.displayDisclosure) {
                    this.newClaimService.claimForm.controls.step.setValue(2);
                    this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_16__.Screens.UploadDocumentClaim]);
                }
                else {
                    this.newClaimService.claimForm.controls.step.setValue(1);
                    this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_16__.Screens.UploadDocumentClaim]);
                }
            }
        };
        this.onBack = () => {
            this.newClaimService.claimForm.controls.step.setValue(0);
            this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_16__.Screens.DisclosureAccident]);
        };
        this.onBackClaim = () => {
            if (this.displayDisclosure) {
                this.valueForm = this.newClaimService.claimForm.controls.disclosureForm.value;
            }
            else {
                this.valueForm = this.newClaimService.claimForm.controls.detailForm.value;
            }
            const canSaveDraft = Object.keys(this.valueForm).some(key => {
                if (this.valueForm[key]) {
                    return true;
                }
            });
            if (canSaveDraft) {
                this.dialogSevice.open(src_app_shared_components_save_draft_save_draft_component__WEBPACK_IMPORTED_MODULE_20__.SaveDraftComponent, {
                    position: 'middle',
                    width: '90%',
                    title: 'saveDocument.title',
                    data: {
                        disable: false
                    }
                })
                    .afterClosed()
                    .subscribe((isSave) => {
                    if (isSave === undefined)
                        return;
                    if (isSave) {
                        this.newClaimService.setLocalStorageSubmitClaim();
                        this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_16__.Screens.Home]).then(() => {
                            this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_16__.Screens.ClaimHistory]);
                        });
                    }
                    else {
                        this.newClaimService.clearClaim();
                        this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_16__.Screens.Home]).then(() => {
                            this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_16__.Screens.ClaimHistory]);
                        });
                    }
                });
            }
            else {
                this.dialogSevice.open(src_app_shared_components_save_draft_save_draft_component__WEBPACK_IMPORTED_MODULE_20__.SaveDraftComponent, {
                    position: 'middle',
                    width: '90%',
                    title: 'saveDocument.title',
                    data: {
                        disable: true
                    }
                })
                    .afterClosed()
                    .subscribe((isSave) => {
                    if (isSave === undefined)
                        return;
                    if (!isSave) {
                        this.newClaimService.clearClaim();
                        this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_16__.Screens.Home]).then(() => {
                            this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_16__.Screens.ClaimHistory]);
                        });
                    }
                });
            }
        };
    }
    get claimForm() {
        return this.newClaimService.claimForm.controls.detailForm;
    }
    ngOnInit() {
        this.displayDisclosure = this.insuranceService.checkPayerSetting(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_17__.Constants.ENABLE_DISCLOSURE_SECTION, true);
        this.claimForm.valueChanges.subscribe((res) => {
            if (res.serviceDate) {
                this.claimForm.controls.dischargeDate.enable({
                    emitEvent: false,
                    onlySelf: true,
                });
                this.claimForm.controls.dischargeDate.updateValueAndValidity({
                    emitEvent: false,
                    onlySelf: true,
                });
            }
            else {
                this.claimForm.controls.dischargeDate.disable({
                    emitEvent: false,
                    onlySelf: true,
                });
                this.claimForm.controls.dischargeDate.updateValueAndValidity({
                    emitEvent: false,
                    onlySelf: true,
                });
            }
        });
        this.claimForm.controls.serviceDate.valueChanges.subscribe((res) => {
            if (res) {
                this.minDate = res;
                this.checkCoveredServiceType(res);
                this.claimForm.controls.dischargeDate.setValue(null);
            }
        });
        this.claimForm.controls.serviceType.valueChanges.subscribe((res) => {
            var _a;
            this.claimForm.controls.serviceDate.setValue('', {
                emitEvent: false
            });
            this.claimForm.controls.dischargeDate.setValue('', {
                emitEvent: false
            });
            this.newClaimService.claimForm.controls.documentForm = this.form.array([]);
            if (res) {
                if ((res === null || res === void 0 ? void 0 : res.id) == 1 || (res === null || res === void 0 ? void 0 : res.id) == 8) {
                    this.isShowDischargeDate = true;
                    this.claimForm.controls.dischargeDate.addValidators(_angular_forms__WEBPACK_IMPORTED_MODULE_22__.Validators.required);
                }
                else {
                    this.isShowDischargeDate = false;
                    this.claimForm.controls.dischargeDate.clearValidators();
                }
                this.claimForm.controls.dischargeDate.updateValueAndValidity();
                if ((_a = this.claimForm.controls.countrySelect.value) === null || _a === void 0 ? void 0 : _a.id) {
                    this.checkProviderAgreement();
                }
                else {
                    this.dialogSevice.open(src_app_shared_components_popup_message_popup_message_component__WEBPACK_IMPORTED_MODULE_14__.PopupMessageComponent, {
                        data: {
                            content: 'newClaim.selectCountry',
                            textYes: 'button.ok',
                        },
                        title: 'title.wrongTitleMessage',
                        position: 'middle',
                        width: '90%',
                    }).afterClosed().subscribe(_ => {
                        this.claimForm.controls.serviceType.setValue(null);
                    });
                }
            }
        });
        if (this.displayDisclosure) {
            this.commands = [
                {
                    actionName: 'button.back',
                    action: 'onBack',
                    class: 'transparent',
                    icon: 'uil uil-arrow-left body-l bold',
                    position: 'left',
                },
                {
                    actionName: 'button.next',
                    action: 'onContinue',
                    class: 'primary',
                    icon: 'uil uil-arrow-right body-l bold',
                    position: 'right',
                },
            ];
        }
        else {
            this.commands = [
                {
                    actionName: 'button.next',
                    action: 'onContinue',
                    class: 'primary',
                },
            ];
        }
        this.getCountryList();
    }
    ionViewWillEnter() {
        var _a;
        return (0,tslib__WEBPACK_IMPORTED_MODULE_23__.__awaiter)(this, void 0, void 0, function* () {
            this.unsubscribe$ = new rxjs__WEBPACK_IMPORTED_MODULE_21__.Subject();
            const submitClaimForm = yield this.newClaimService.getLocalStorageSubmitClaim();
            if (submitClaimForm) {
                this.claimForm.controls.currency.setValue((_a = submitClaimForm === null || submitClaimForm === void 0 ? void 0 : submitClaimForm.detailForm) === null || _a === void 0 ? void 0 : _a.currency);
            }
            this.getInformation();
        });
    }
    ionViewDidEnter() {
        this.subscription = this.platform.backButton.subscribeWithPriority(9999, () => {
            if (this.displayDisclosure) {
                this.newClaimService.claimForm.controls.step.setValue(0);
                this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_16__.Screens.DisclosureAccident]);
            }
            else {
                this.onBackClaim();
            }
        });
    }
    ionViewWillLeave() {
        this.unsubscribe$.next();
        this.unsubscribe$.complete();
        this.subscription.unsubscribe();
    }
    getInformation() {
        this.insuranceService.getPolicyInformation().pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_24__.takeUntil)(this.unsubscribe$)).subscribe((res) => {
            var _a;
            if (!res || ((_a = this.currentPolicy) === null || _a === void 0 ? void 0 : _a.beneficiaryId) === (res === null || res === void 0 ? void 0 : res.beneficiaryId))
                return;
            this.currentPolicy = res;
            this.getInformationPolicyDetails(res);
            this.getMemberSelect();
            this.getAllServices();
            this.getCurrencies();
            this.consentCheck();
        });
    }
    getMemberSelect() {
        this.members = this.insuranceService.getMemberListValue().map((item) => ({
            name: item.benefFullName,
            id: item.beneficiaryId.toString(),
        }));
        if (this.currentPolicy.dependent) {
            const member = this.members.find(e => e.name === 'MySelf');
            this.claimForm.controls.memberSelect.setValue(member);
        }
    }
    getAllServices() {
        const requestServiceTypes = {
            userPolicyId: this.currentPolicy.userPolicyId,
        };
        this.serviceType.getServiceTypes(requestServiceTypes).subscribe((data) => {
            if (!data)
                return;
            this.serviceTypes = data
                .map((item) => ((item.id != 2 ||
                (item.id == 2 && (item.classId == 3 || item.classId == 5))) &&
                item.classId != 8)
                ? { name: item.description, id: item.classId.toString(), valueId: item.id }
                : null)
                .filter((_) => _).sort(function (a, b) {
                const nameA = a.name.toUpperCase(); // ignore upper and lowercase
                const nameB = b.name.toUpperCase(); // ignore upper and lowercase
                if (nameA < nameB) {
                    return -1;
                }
                if (nameA > nameB) {
                    return 1;
                }
                return 0;
            });
        });
    }
    getCurrencies() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_23__.__awaiter)(this, void 0, void 0, function* () {
            const requestCurrency = {
                userPolicyId: this.currentPolicy.userPolicyId
            };
            this.currencyList = yield this.currencyService.populateCurrenciesList(requestCurrency);
        });
    }
    detectCurrencies(currencyId) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_23__.__awaiter)(this, void 0, void 0, function* () {
            const requestCurrency = {
                userPolicyId: this.currentPolicy.userPolicyId,
                currencyId: currencyId
            };
            this.currency = yield this.currencyService.detectCurrencies(requestCurrency, this.currencyList);
        });
    }
    groupNames(arr) {
        arr.sort(function (a, b) {
            const nameA = a.name.toUpperCase(); // ignore upper and lowercase
            const nameB = b.name.toUpperCase(); // ignore upper and lowercase
            if (nameA < nameB) {
                return -1;
            }
            if (nameA > nameB) {
                return 1;
            }
            return 0;
        });
        const map = arr.reduce((acc, val) => {
            const char = val.name.charAt(0).toUpperCase();
            acc[char] = [].concat(acc[char] || [], val);
            return acc;
        }, {});
        const res = Object.keys(map).map((el) => ({
            letter: el,
            names: map[el],
        }));
        return res;
    }
    consentCheck() {
        if (!this.displayDisclosure) {
            const requestConsent = {
                userPolicyId: this.currentPolicy.userPolicyId,
                beneficiaryId: this.currentPolicy.beneficiaryId,
            };
            this.consentService.getConsent(requestConsent).subscribe((data) => {
                if (!data) {
                    this.getPrivacyConsent(requestConsent);
                }
            });
        }
    }
    ;
    getPrivacyConsent(requestConsent) {
        this.consentService.getPrivacyConsent().subscribe((data) => {
            this.dialogSevice
                .open(src_app_shared_components_privacy_consent_dialog_privacy_consent_dialog_component__WEBPACK_IMPORTED_MODULE_18__.PrivacyConsentDialogComponent, {
                data: {
                    text: data[0].description,
                    requestConsent: requestConsent,
                },
                title: data[0].title,
                position: 'middle',
                width: '90%',
                height: '80%',
            })
                .afterClosed()
                .subscribe((data) => {
                if (data) {
                    this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_16__.Screens.ClaimDetail]);
                }
                else {
                    this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_16__.Screens.ClaimHistory]);
                }
            });
        });
    }
    ;
    getCountryList() {
        this.countryService.getCountries().subscribe((res) => {
            this.countryList = res.map((res) => {
                var _a;
                return ({
                    id: res.countryId,
                    name: res.countryDescription,
                    icon: res.countryCodeISO2.toLocaleLowerCase() || ((_a = country_iso_3_to_2__WEBPACK_IMPORTED_MODULE_4__(res.countryCodeISO)) === null || _a === void 0 ? void 0 : _a.toLocaleLowerCase()) || 'empty',
                    currencyId: res.currencyId
                });
            });
        });
    }
    ;
    checkCoveredServiceType(date) {
        date = this.datePipe.transform(date, 'yyyy-M-d');
        if (date) {
            const model = {
                mdAsAtDate: date,
                beneficiaryId: this.currentPolicy.beneficiaryId,
                userPolicyId: this.currentPolicy.userPolicyId
            };
            this.coveragesService.getCoverages(model).subscribe(res => {
                if (res && !res[0].details.isCovered) {
                    this.claimForm.controls.serviceDate.setValue('', {
                        emitEvent: false
                    });
                    this.claimForm.controls.dischargeDate.setValue('', {
                        emitEvent: false
                    });
                    this.dialogSevice.open(src_app_shared_components_popup_message_popup_message_component__WEBPACK_IMPORTED_MODULE_14__.PopupMessageComponent, {
                        data: {
                            content: 'This service date is not covered by your insurance policy',
                            textYes: 'button.ok',
                        },
                        title: 'Coverages Service Date Incorrect',
                        position: 'middle',
                        width: '90%',
                    });
                }
            });
        }
    }
    ;
    checkProviderAgreement() {
        const ProviderAgreement = {
            userPolicyId: this.currentPolicy.userPolicyId,
            beneficiaryId: this.currentPolicy.beneficiaryId,
            productId: this.currentPolicyDetail.productId,
            endorsementId: this.currentPolicyDetail.endorsementId,
            fobId: this.claimForm.value.serviceType.valueId,
            providerCountryId: this.claimForm.value.countrySelect.id,
        };
        this.providerAgreementService.getServiceTypes(ProviderAgreement).subscribe((res) => {
            if (!res || res.agreementId == 0) {
                this.claimForm.controls.serviceType.setValue(null, {
                    emitEvent: false
                });
                this.claimForm.controls.serviceDate.setValue('', {
                    emitEvent: false
                });
                this.claimForm.controls.dischargeDate.setValue('', {
                    emitEvent: false
                });
                this.dialogSevice.open(src_app_shared_components_popup_message_popup_message_component__WEBPACK_IMPORTED_MODULE_14__.PopupMessageComponent, {
                    data: {
                        content: 'This service type is not covered by your insurance policy',
                        textYes: 'button.ok',
                    },
                    title: 'Coverages Service Type Incorrect',
                    position: 'middle',
                    width: '90%',
                });
            }
        }, _ => {
            this.claimForm.controls.serviceType.setValue(null, {
                emitEvent: false
            });
            this.claimForm.controls.serviceDate.setValue('', {
                emitEvent: false
            });
            this.claimForm.controls.dischargeDate.setValue('', {
                emitEvent: false
            });
        });
    }
    ;
    getInformationPolicyDetails(policy) {
        if (policy) {
            const data = this.insuranceService.getPolicyDetailResponse();
            this.currentPolicyDetail = {
                contractId: policy.policiesDetails[0].contractId,
                mcontractId: policy.policiesDetails[0].mcontractId,
                payerId: policy.policiesDetails[0].payerId,
                payerName: data[0].Payer.entity.name,
                productId: data[0].Beneficiary.product.productId,
                policyStartDay: data[0].Mcontract.STARTDATE,
                policyEndDay: data[0].Mcontract.EXPDATE,
                policyNumber: data[0].Contract.EXTERNALREF,
                policyHolder: data[0].Contract.NAME,
                serviceProvId: data[0].ServiceProviderId,
                endorsementId: data[0].Endorsement.ENDORSEMENTID,
                moralEntity: data[0].Mcontract.MORALENTITY,
                isActive: data[0].Beneficiary.IsActive,
                beneficiaryId: data[0].Beneficiary.BeneficiaryID,
                firstName: data[0].Beneficiary.firstname,
            };
        }
        ;
    }
    ;
    // handleCountryChange() {
    //   // const countryId = this.insuranceService.getPolicyDetailResponse()[0].Mcontract.PAYERID;
    //   const countryId = this.insuranceService.getPolicyDetailResponse()[0].Payer.Address.countryId;
    //   if(countryId){
    //     this.detectCurrencies(countryId);
    //   }
    // }
    handleCountryChange(e) {
        if (e === null || e === void 0 ? void 0 : e.currencyId) {
            this.detectCurrencies(e.currencyId);
        }
    }
    ;
    focusNoteHandler() {
        setTimeout(() => {
            if (this.content.scrollToBottom) {
                this.content.scrollToBottom(300);
            }
        }, 500);
    }
};
ClaimDetailsComponent.ctorParameters = () => [
    { type: src_app_service_new_claim_service_type_service_types_service__WEBPACK_IMPORTED_MODULE_12__.ServiceTypesService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_25__.Router },
    { type: _awesome_cordova_plugins_firebase_analytics_ngx__WEBPACK_IMPORTED_MODULE_3__.FirebaseAnalytics },
    { type: src_app_service_insurance_insurance_service__WEBPACK_IMPORTED_MODULE_7__.InsuranceService },
    { type: src_app_service_new_claim_currencies_currencies_service__WEBPACK_IMPORTED_MODULE_9__.CurrenciesService },
    { type: src_app_shared_components_nextgen_dialog_nextgen_dialog_service__WEBPACK_IMPORTED_MODULE_13__.DialogService },
    { type: src_app_service_new_claim_new_claim_service__WEBPACK_IMPORTED_MODULE_10__.NewClaimService },
    { type: src_app_service_country_countries_service__WEBPACK_IMPORTED_MODULE_6__.CountriesService },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_22__.FormBuilder },
    { type: _awesome_cordova_plugins_clevertap_ngx__WEBPACK_IMPORTED_MODULE_2__.CleverTap },
    { type: _angular_common__WEBPACK_IMPORTED_MODULE_26__.DatePipe },
    { type: src_app_service_new_claim_coverages_coverages_service__WEBPACK_IMPORTED_MODULE_8__.CoveragesService },
    { type: src_app_service_new_claim_consent_consent_service__WEBPACK_IMPORTED_MODULE_19__.ConsentService },
    { type: src_app_service_new_claim_provider_agreement_provider_agreement_service__WEBPACK_IMPORTED_MODULE_11__.ProviderAgreementService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_27__.Platform }
];
ClaimDetailsComponent.propDecorators = {
    content: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_28__.ViewChild, args: ['content',] }]
};
ClaimDetailsComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_23__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_28__.Component)({
        selector: 'app-claim-details',
        template: _claim_details_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_claim_details_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], ClaimDetailsComponent);



/***/ }),

/***/ 33798:
/*!**************************************************************************************!*\
  !*** ./src/app/pages/new-claim/disclosure-accident/disclosure-accident.component.ts ***!
  \**************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DisclosureAccidentComponent": () => (/* binding */ DisclosureAccidentComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _disclosure_accident_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./disclosure-accident.component.html?ngResource */ 2209);
/* harmony import */ var _disclosure_accident_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./disclosure-accident.component.scss?ngResource */ 24086);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var src_app_service_new_claim_new_claim_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/service/new-claim/new-claim.service */ 90888);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! rxjs */ 92218);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! rxjs/operators */ 85921);
/* harmony import */ var src_app_model_control_control_model__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/model/control/control.model */ 45482);
/* harmony import */ var src_app_service_insurance_insurance_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/service/insurance/insurance.service */ 57072);
/* harmony import */ var src_app_service_new_claim_consent_consent_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/service/new-claim/consent/consent.service */ 41413);
/* harmony import */ var src_app_shared_components_nextgen_dialog_nextgen_dialog_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/shared/components/nextgen-dialog/nextgen-dialog.service */ 96485);
/* harmony import */ var src_app_shared_components_privacy_consent_dialog_privacy_consent_dialog_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/shared/components/privacy-consent-dialog/privacy-consent-dialog.component */ 61262);
/* harmony import */ var src_app_shared_components_save_draft_save_draft_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/shared/components/save-draft/save-draft.component */ 38317);
/* harmony import */ var src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/shared/data/constants */ 74676);
/* harmony import */ var src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/app/shared/data/enum/screen */ 68302);


















let DisclosureAccidentComponent = class DisclosureAccidentComponent {
    constructor(newClaimService, router, insuranceService, consentService, dialogSevice, platform) {
        this.newClaimService = newClaimService;
        this.router = router;
        this.insuranceService = insuranceService;
        this.consentService = consentService;
        this.dialogSevice = dialogSevice;
        this.platform = platform;
        this.TYPE = src_app_model_control_control_model__WEBPACK_IMPORTED_MODULE_3__.ControlType;
        this.displayFirstDateTreatment = false;
        this.displayAccidentDescription = false;
        this.maxDate = new Date().toISOString();
        this.minDate = null;
        this.unsubscribe$ = new rxjs__WEBPACK_IMPORTED_MODULE_11__.Subject();
        this.checkBox = [
            {
                name: 'disclosure.agree',
                value: 'true'
            },
            {
                name: 'disclosure.disagree',
                value: 'false'
            }
        ];
        this.onContinue = () => {
            this.disclosureForm.markAllAsTouched();
            this.disclosureForm.markAsDirty();
            if (this.disclosureForm.valid) {
                this.newClaimService.claimForm.controls.step.setValue(1);
                this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_10__.Screens.ClaimDetail]);
            }
            // this.newClaimService.claimForm.controls.step.setValue(1);
            // this.router.navigate(['/' + Screens.ClaimDetail]);
        };
        this.onBackClaim = () => {
            if (this.displayDisclosure) {
                this.valueForm = this.newClaimService.claimForm.controls.disclosureForm.value;
            }
            else {
                this.valueForm = this.newClaimService.claimForm.controls.detailForm.value;
            }
            const canSaveDraft = Object.keys(this.valueForm).some(key => {
                if (this.valueForm[key]) {
                    return true;
                }
            });
            if (canSaveDraft) {
                this.dialogSevice.open(src_app_shared_components_save_draft_save_draft_component__WEBPACK_IMPORTED_MODULE_8__.SaveDraftComponent, {
                    position: 'middle',
                    width: '90%',
                    title: 'saveDocument.title',
                    data: {
                        disable: false
                    }
                })
                    .afterClosed()
                    .subscribe((isSave) => {
                    if (isSave === undefined)
                        return;
                    if (isSave) {
                        this.newClaimService.setLocalStorageSubmitClaim();
                        this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_10__.Screens.Home]).then(() => {
                            this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_10__.Screens.ClaimHistory]);
                        });
                    }
                    else {
                        this.newClaimService.clearClaim();
                        this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_10__.Screens.Home]).then(() => {
                            this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_10__.Screens.ClaimHistory]);
                        });
                    }
                });
            }
            else {
                this.dialogSevice.open(src_app_shared_components_save_draft_save_draft_component__WEBPACK_IMPORTED_MODULE_8__.SaveDraftComponent, {
                    position: 'middle',
                    width: '90%',
                    title: 'saveDocument.title',
                    data: {
                        disable: true
                    }
                })
                    .afterClosed()
                    .subscribe((isSave) => {
                    if (isSave === undefined)
                        return;
                    if (!isSave) {
                        this.newClaimService.clearClaim();
                        this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_10__.Screens.Home]).then(() => {
                            this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_10__.Screens.ClaimHistory]);
                        });
                    }
                });
            }
        };
    }
    get disclosureForm() {
        return this.newClaimService.claimForm.controls.disclosureForm;
    }
    ionViewWillEnter() {
        this.unsubscribe$ = new rxjs__WEBPACK_IMPORTED_MODULE_11__.Subject();
        this.disclosureForm.controls.treatmentSymtoms.valueChanges.subscribe((res) => {
            if (res === 'true') {
                this.displayFirstDateTreatment = true;
                this.disclosureForm.controls.dateFirstTreatmentOfSymptoms.addValidators(_angular_forms__WEBPACK_IMPORTED_MODULE_12__.Validators.required);
            }
            else {
                this.displayFirstDateTreatment = false;
                this.disclosureForm.controls.dateFirstTreatmentOfSymptoms.clearValidators();
            }
            this.disclosureForm.controls.dateFirstTreatmentOfSymptoms.updateValueAndValidity();
        });
        this.disclosureForm.controls.accident.valueChanges.subscribe((res) => {
            if (res === 'true') {
                this.displayAccidentDescription = true;
                this.disclosureForm.controls.accidentDesc.addValidators(_angular_forms__WEBPACK_IMPORTED_MODULE_12__.Validators.required);
            }
            else {
                this.displayAccidentDescription = false;
                this.disclosureForm.controls.accidentDesc.clearValidators();
            }
            this.disclosureForm.controls.accidentDesc.updateValueAndValidity();
        });
        this.disclosureForm.controls.firstOccurrenceDate.valueChanges.subscribe((res) => {
            this.minDate = new Date(res).toISOString();
            this.disclosureForm.controls.accidentDesc.updateValueAndValidity();
        });
    }
    ionViewWillLeave() {
        this.unsubscribe$.next();
        this.unsubscribe$.complete();
        this.subscription.unsubscribe();
    }
    ionViewDidEnter() {
        this.subscription = this.platform.backButton.subscribeWithPriority(9999, () => {
            this.onBackClaim();
        });
    }
    ngOnInit() {
        this.displayDisclosure = this.insuranceService.checkPayerSetting(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_9__.Constants.ENABLE_DISCLOSURE_SECTION, true);
        this.getInformation();
        this.commands = [
            {
                actionName: 'button.next',
                action: 'onContinue',
                class: 'primary',
            },
        ];
    }
    getInformation() {
        this.insuranceService
            .getPolicyInformation()
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_13__.takeUntil)(this.unsubscribe$))
            .subscribe((res) => {
            var _a;
            if (!res || ((_a = this.currentPolicy) === null || _a === void 0 ? void 0 : _a.beneficiaryId) === (res === null || res === void 0 ? void 0 : res.beneficiaryId))
                return;
            this.currentPolicy = res;
            this.consentCheck();
        });
    }
    consentCheck() {
        const requestConsent = {
            userPolicyId: this.currentPolicy.userPolicyId,
            beneficiaryId: this.currentPolicy.beneficiaryId,
        };
        this.consentService.getConsent(requestConsent).subscribe((data) => {
            if (!data) {
                this.getPrivacyConsent(requestConsent);
            }
        });
    }
    getPrivacyConsent(requestConsent) {
        this.consentService.getPrivacyConsent().subscribe((data) => {
            this.dialogSevice
                .open(src_app_shared_components_privacy_consent_dialog_privacy_consent_dialog_component__WEBPACK_IMPORTED_MODULE_7__.PrivacyConsentDialogComponent, {
                data: {
                    text: data[0].description,
                    requestConsent: requestConsent,
                },
                title: data[0].title,
                position: 'middle',
                width: '90%',
                height: '80%',
            })
                .afterClosed()
                .subscribe((data) => {
                if (data) {
                    this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_10__.Screens.DisclosureAccident]);
                }
                else {
                    this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_10__.Screens.ClaimHistory]);
                }
            });
        });
    }
    changeCheckBox(value) {
        setTimeout(() => {
            if (this.content.scrollToBottom && value == 'true') {
                this.content.scrollToBottom(300);
            }
        }, 500);
    }
};
DisclosureAccidentComponent.ctorParameters = () => [
    { type: src_app_service_new_claim_new_claim_service__WEBPACK_IMPORTED_MODULE_2__.NewClaimService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_14__.Router },
    { type: src_app_service_insurance_insurance_service__WEBPACK_IMPORTED_MODULE_4__.InsuranceService },
    { type: src_app_service_new_claim_consent_consent_service__WEBPACK_IMPORTED_MODULE_5__.ConsentService },
    { type: src_app_shared_components_nextgen_dialog_nextgen_dialog_service__WEBPACK_IMPORTED_MODULE_6__.DialogService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_15__.Platform }
];
DisclosureAccidentComponent.propDecorators = {
    content: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_16__.ViewChild, args: ['content',] }]
};
DisclosureAccidentComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_17__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_16__.Component)({
        selector: 'app-disclosure-accident',
        template: _disclosure_accident_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_disclosure_accident_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], DisclosureAccidentComponent);



/***/ }),

/***/ 12388:
/*!*************************************************************!*\
  !*** ./src/app/pages/new-claim/new-claim-routing.module.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NewClaimPageRoutingModule": () => (/* binding */ NewClaimPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _disclosure_accident_disclosure_accident_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./disclosure-accident/disclosure-accident.component */ 33798);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _claim_details_claim_details_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./claim-details/claim-details.component */ 58551);
/* harmony import */ var _new_claim_page__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./new-claim.page */ 56452);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _upload_detail_upload_detail_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./upload-detail/upload-detail.component */ 54583);
/* harmony import */ var _payment_detail_payment_detail_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./payment-detail/payment-detail.component */ 93499);
/* harmony import */ var _review_and_submit_review_and_submit_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./review-and-submit/review-and-submit.component */ 21661);









const routes = [
    {
        path: '',
        component: _new_claim_page__WEBPACK_IMPORTED_MODULE_2__.NewClaimPage,
        children: [
            {
                path: 'disclosure-accident',
                component: _disclosure_accident_disclosure_accident_component__WEBPACK_IMPORTED_MODULE_0__.DisclosureAccidentComponent,
            },
            {
                path: 'disclosure-accident/:id',
                component: _disclosure_accident_disclosure_accident_component__WEBPACK_IMPORTED_MODULE_0__.DisclosureAccidentComponent,
            },
            {
                path: 'claim-details',
                component: _claim_details_claim_details_component__WEBPACK_IMPORTED_MODULE_1__.ClaimDetailsComponent,
            },
            {
                path: 'claim-details/:id',
                component: _claim_details_claim_details_component__WEBPACK_IMPORTED_MODULE_1__.ClaimDetailsComponent,
            },
            {
                path: 'upload-detail',
                component: _upload_detail_upload_detail_component__WEBPACK_IMPORTED_MODULE_3__.UploadDetailComponent,
            },
            {
                path: 'upload-detail/:id',
                component: _upload_detail_upload_detail_component__WEBPACK_IMPORTED_MODULE_3__.UploadDetailComponent,
            },
            {
                path: 'payment-detail',
                component: _payment_detail_payment_detail_component__WEBPACK_IMPORTED_MODULE_4__.PaymentDetailComponent,
            },
            {
                path: 'payment-detail/:id',
                component: _payment_detail_payment_detail_component__WEBPACK_IMPORTED_MODULE_4__.PaymentDetailComponent,
            },
            {
                path: 'review-and-submit',
                component: _review_and_submit_review_and_submit_component__WEBPACK_IMPORTED_MODULE_5__.ReviewAndSubmitComponent,
            },
            {
                path: 'review-and-submit/:id',
                component: _review_and_submit_review_and_submit_component__WEBPACK_IMPORTED_MODULE_5__.ReviewAndSubmitComponent,
            },
            // {
            //   path: '**',
            //   redirectTo: 'claim-details',
            //   pathMatch: 'full',
            // },
        ],
    },
];
let NewClaimPageRoutingModule = class NewClaimPageRoutingModule {
};
NewClaimPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_8__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_8__.RouterModule],
    })
], NewClaimPageRoutingModule);



/***/ }),

/***/ 63831:
/*!*****************************************************!*\
  !*** ./src/app/pages/new-claim/new-claim.module.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NewClaimPageModule": () => (/* binding */ NewClaimPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _disclosure_accident_disclosure_accident_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./disclosure-accident/disclosure-accident.component */ 33798);
/* harmony import */ var _claim_details_claim_details_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./claim-details/claim-details.component */ 58551);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var src_app_service_new_claim_select_member_member_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/service/new-claim/select-member/member.service */ 78447);
/* harmony import */ var _new_claim_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./new-claim.page */ 56452);
/* harmony import */ var _new_claim_routing_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./new-claim-routing.module */ 12388);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var src_app_service_new_claim_service_type_service_type_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/service/new-claim/service-type/service-type.service */ 97140);
/* harmony import */ var src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/shared/shared.module */ 44466);
/* harmony import */ var _payment_detail_payment_detail_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./payment-detail/payment-detail.component */ 93499);
/* harmony import */ var _review_and_submit_review_and_submit_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./review-and-submit/review-and-submit.component */ 21661);














let NewClaimPageModule = class NewClaimPageModule {
};
NewClaimPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_10__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_11__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_12__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_13__.IonicModule,
            _new_claim_routing_module__WEBPACK_IMPORTED_MODULE_4__.NewClaimPageRoutingModule,
            src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_6__.SharedModule,
        ],
        declarations: [
            _disclosure_accident_disclosure_accident_component__WEBPACK_IMPORTED_MODULE_0__.DisclosureAccidentComponent,
            _new_claim_page__WEBPACK_IMPORTED_MODULE_3__.NewClaimPage,
            _claim_details_claim_details_component__WEBPACK_IMPORTED_MODULE_1__.ClaimDetailsComponent,
            _payment_detail_payment_detail_component__WEBPACK_IMPORTED_MODULE_7__.PaymentDetailComponent,
            _review_and_submit_review_and_submit_component__WEBPACK_IMPORTED_MODULE_8__.ReviewAndSubmitComponent,
        ],
        providers: [src_app_service_new_claim_select_member_member_service__WEBPACK_IMPORTED_MODULE_2__.MemberService, src_app_service_new_claim_service_type_service_type_service__WEBPACK_IMPORTED_MODULE_5__.ServiceTypeService],
    })
], NewClaimPageModule);



/***/ }),

/***/ 56452:
/*!***************************************************!*\
  !*** ./src/app/pages/new-claim/new-claim.page.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NewClaimPage": () => (/* binding */ NewClaimPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _new_claim_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./new-claim.page.html?ngResource */ 24235);
/* harmony import */ var _new_claim_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./new-claim.page.scss?ngResource */ 68788);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/shared/data/enum/screen */ 68302);
/* harmony import */ var src_app_shared_components_nextgen_dialog_nextgen_dialog_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/shared/components/nextgen-dialog/nextgen-dialog.service */ 96485);
/* harmony import */ var _shared_components_save_draft_save_draft_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../shared/components/save-draft/save-draft.component */ 38317);
/* harmony import */ var src_app_service_new_claim_new_claim_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/service/new-claim/new-claim.service */ 90888);
/* harmony import */ var src_app_service_insurance_insurance_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/service/insurance/insurance.service */ 57072);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var src_app_service_new_claim_upload_document_upload_document_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/service/new-claim/upload-document/upload-document.service */ 66848);
/* harmony import */ var src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/shared/data/constants */ 74676);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! rxjs/operators */ 85921);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! rxjs */ 92218);










// import { RequestClaimDocumentType } from 'src/app/model/new-claim/upload-document/upload-document';





let NewClaimPage = class NewClaimPage {
    constructor(router, dialogService, newClaimService, insuranceService, fb, uploadDocumentService) {
        this.router = router;
        this.dialogService = dialogService;
        this.newClaimService = newClaimService;
        this.insuranceService = insuranceService;
        this.fb = fb;
        this.uploadDocumentService = uploadDocumentService;
        this.step = 1;
        this.width = 25;
        this.currentStep = 0;
        this.currentStatus = 'inProgress';
        this.stepProgress = [];
        this.unsubscribe$ = new rxjs__WEBPACK_IMPORTED_MODULE_9__.Subject();
        this.onBack = () => {
            if (this.displayDisclosure) {
                this.valueForm = this.newClaimService.claimForm.controls.disclosureForm.value;
            }
            else {
                this.valueForm = this.newClaimService.claimForm.controls.detailForm.value;
            }
            const canSaveDraft = Object.keys(this.valueForm).some(key => {
                if (this.valueForm[key]) {
                    return true;
                }
            });
            if (canSaveDraft) {
                this.dialogService.open(_shared_components_save_draft_save_draft_component__WEBPACK_IMPORTED_MODULE_4__.SaveDraftComponent, {
                    position: 'middle',
                    width: '90%',
                    title: 'saveDocument.title',
                    data: {
                        disable: false
                    }
                })
                    .afterClosed()
                    .subscribe((isSave) => {
                    if (isSave === undefined)
                        return;
                    if (isSave) {
                        this.newClaimService.setLocalStorageSubmitClaim();
                        this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__.Screens.Home]).then(() => {
                            this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__.Screens.ClaimHistory]);
                        });
                    }
                    else {
                        this.newClaimService.clearClaim();
                        this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__.Screens.Home]).then(() => {
                            this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__.Screens.ClaimHistory]);
                        });
                    }
                });
            }
            else {
                this.dialogService.open(_shared_components_save_draft_save_draft_component__WEBPACK_IMPORTED_MODULE_4__.SaveDraftComponent, {
                    position: 'middle',
                    width: '90%',
                    title: 'saveDocument.title',
                    data: {
                        disable: true
                    }
                })
                    .afterClosed()
                    .subscribe((isSave) => {
                    if (isSave === undefined)
                        return;
                    if (!isSave) {
                        this.newClaimService.clearClaim();
                        this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__.Screens.Home]).then(() => {
                            this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__.Screens.ClaimHistory]);
                        });
                    }
                });
            }
        };
    }
    get documentForm() {
        return this.newClaimService.claimForm.controls.documentForm;
    }
    ngOnDestroy() {
        this.unsubscribe$.next();
        this.unsubscribe$.complete();
    }
    ngOnInit() {
        this.displayDisclosure = this.insuranceService.checkPayerSetting(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_8__.Constants.ENABLE_DISCLOSURE_SECTION, true);
        this.insuranceService.getPolicyInformation().pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_10__.takeUntil)(this.unsubscribe$)).subscribe(res => {
            if (res) {
                if (this.displayDisclosure) {
                    if (this.checkNavigate()) {
                        this.stepProgress = [
                            {
                                id: 1,
                                direction: src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__.Screens.DisclosureAccident,
                                step: 0,
                            },
                            {
                                id: 2,
                                direction: src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__.Screens.ClaimDetail,
                                step: 1,
                            },
                            {
                                id: 3,
                                direction: src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__.Screens.UploadDocumentClaim,
                                step: 2,
                            },
                            {
                                id: 4,
                                direction: src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__.Screens.PaymentMethod,
                                step: 3,
                            },
                            {
                                id: 5,
                                direction: src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__.Screens.ClaimReviewAndSubmit,
                                step: 4,
                            },
                        ];
                    }
                    else {
                        this.stepProgress = [
                            {
                                id: 1,
                                direction: src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__.Screens.DisclosureAccident,
                                step: 0,
                            },
                            {
                                id: 2,
                                direction: src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__.Screens.ClaimDetail,
                                step: 1,
                            },
                            {
                                id: 3,
                                direction: src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__.Screens.UploadDocumentClaim,
                                step: 2,
                            },
                            {
                                id: 4,
                                direction: src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__.Screens.ClaimReviewAndSubmit,
                                step: 3,
                            },
                        ];
                    }
                    if (this.stepProgress[0].id === this.currentStep + 1) {
                        this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__.Screens.DisclosureAccident]);
                    }
                }
                else {
                    if (this.checkNavigate()) {
                        this.stepProgress = [
                            {
                                id: 1,
                                direction: src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__.Screens.ClaimDetail,
                                step: 0,
                            },
                            {
                                id: 2,
                                direction: src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__.Screens.UploadDocumentClaim,
                                step: 1,
                            },
                            {
                                id: 3,
                                direction: src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__.Screens.PaymentMethod,
                                step: 2,
                            },
                            {
                                id: 4,
                                direction: src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__.Screens.ClaimReviewAndSubmit,
                                step: 3,
                            },
                        ];
                    }
                    else {
                        this.stepProgress = [
                            {
                                id: 1,
                                direction: src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__.Screens.ClaimDetail,
                                step: 0,
                            },
                            {
                                id: 2,
                                direction: src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__.Screens.UploadDocumentClaim,
                                step: 1,
                            },
                            {
                                id: 3,
                                direction: src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__.Screens.ClaimReviewAndSubmit,
                                step: 2,
                            },
                        ];
                    }
                    if (this.stepProgress[0].id === this.currentStep + 1) {
                        this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__.Screens.ClaimDetail]);
                    }
                }
                this.command = {
                    actionName: 'Back',
                    action: 'onBack',
                    class: '',
                };
                this.checkStep();
            }
        });
    }
    //true -payment method
    checkNavigate() {
        const benefBankTransfer = this.insuranceService.checkPayerSetting(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_8__.Constants.ENABLE_BENEF_BANK_TRANSFER, true);
        const benefChequePayment = this.insuranceService.checkPayerSetting(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_8__.Constants.ENABLE_BENEF_CHEQUE_PAYMENT, true);
        if (
        // this.insuranceService
        //   .getPayerSettingValue()
        //   .some(
        //     (_) =>
        //       (_.columnname == 'MyNCEnableBenefBankTransfer' ||
        //         _.columnname == 'MyNCEnableBenefChequePayment') &&
        //       _.required == true,
        //   )
        benefBankTransfer == false && benefChequePayment == false) {
            return false;
        }
        else {
            return true;
        }
    }
    ;
    checkStep() {
        var _a;
        return (0,tslib__WEBPACK_IMPORTED_MODULE_11__.__awaiter)(this, void 0, void 0, function* () {
            const submitClaim = yield this.newClaimService.getLocalStorageSubmitClaim();
            if (submitClaim) {
                this.newClaimService.claimForm.patchValue(submitClaim, { emitEvent: false });
                if (((_a = submitClaim === null || submitClaim === void 0 ? void 0 : submitClaim.detailForm) === null || _a === void 0 ? void 0 : _a.serviceType) && (submitClaim === null || submitClaim === void 0 ? void 0 : submitClaim.step) > 2) {
                    this.getClaimDocumentTypes( /*submitClaim?.detailForm?.serviceType.id*/);
                }
                else {
                    if ((submitClaim === null || submitClaim === void 0 ? void 0 : submitClaim.step) != null) {
                        if (this.displayDisclosure) {
                            switch (submitClaim.step) {
                                case 0:
                                    this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__.Screens.DisclosureAccident]);
                                    break;
                                case 1:
                                    this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__.Screens.ClaimDetail]);
                                    break;
                                case 2:
                                    this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__.Screens.UploadDocumentClaim]);
                                    break;
                                case 3:
                                    this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__.Screens.PaymentMethod]);
                                    break;
                                case 4:
                                    this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__.Screens.ClaimReviewAndSubmit]);
                                    break;
                            }
                        }
                        else {
                            switch (submitClaim.step) {
                                case 0:
                                    this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__.Screens.ClaimDetail]);
                                    break;
                                case 1:
                                    this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__.Screens.UploadDocumentClaim]);
                                    break;
                                case 2:
                                    this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__.Screens.PaymentMethod]);
                                    break;
                                case 3:
                                    this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__.Screens.ClaimReviewAndSubmit]);
                                    break;
                            }
                        }
                    }
                }
            }
        });
    }
    ;
    getClaimDocumentTypes( /*serviceType: number*/) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_11__.__awaiter)(this, void 0, void 0, function* () {
            // const request: RequestClaimDocumentType = {
            //   userPolicyId: this.insuranceService.policyValue.userPolicyId,
            //   serviceType,
            // };
            // this.uploadDocumentService
            //   .getClaimDocumentType(request)
            //   .subscribe(async (data) => {
            this.documentForm.clear();
            const submitClaim = yield this.newClaimService.getLocalStorageSubmitClaim();
            // data.forEach((item) => {
            const docs = submitClaim === null || submitClaim === void 0 ? void 0 : submitClaim.documentForm;
            docs.forEach((item) => {
                this.documentForm.push(this.fb.group({
                    title: item.title,
                    expanded: item ? item.expanded : false,
                    document: this.fb.control(item ? item.document : []),
                    mandatory: item.mandatory,
                    description: item.description,
                }));
                // });
            });
            // if (this.documentForm.length == 0) {
            //   this.documentForm.push(this.fb.group({
            //     title: 'uploadDocuments.invoice',
            //     expanded: docs ? docs.expanded : false,
            //     document: [],
            //     mandatory: true,
            //     description: 'uploadDocuments.noDocumentUploaded',
            //   }));
            //   this.documentForm.push(this.fb.group({
            //     title: 'uploadDocuments.other',
            //     expanded: docs ? docs.expanded : false,
            //     document: [],
            //     mandatory: false,
            //     description: 'uploadDocuments.noDocumentUploaded',
            //   })
            //   );
            // }
            if ((submitClaim === null || submitClaim === void 0 ? void 0 : submitClaim.step) != null) {
                if (this.displayDisclosure) {
                    switch (submitClaim.step) {
                        case 0:
                            this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__.Screens.DisclosureAccident]);
                            break;
                        case 1:
                            this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__.Screens.ClaimDetail]);
                            break;
                        case 2:
                            this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__.Screens.UploadDocumentClaim]);
                            break;
                        case 3:
                            this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__.Screens.PaymentMethod]);
                            break;
                        case 4:
                            this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__.Screens.ClaimReviewAndSubmit]);
                            break;
                    }
                }
                else {
                    switch (submitClaim.step) {
                        case 0:
                            this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__.Screens.ClaimDetail]);
                            break;
                        case 1:
                            this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__.Screens.UploadDocumentClaim]);
                            break;
                        case 2:
                            this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__.Screens.PaymentMethod]);
                            break;
                        case 3:
                            this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__.Screens.ClaimReviewAndSubmit]);
                            break;
                    }
                }
            }
        });
    }
};
NewClaimPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_12__.Router },
    { type: src_app_shared_components_nextgen_dialog_nextgen_dialog_service__WEBPACK_IMPORTED_MODULE_3__.DialogService },
    { type: src_app_service_new_claim_new_claim_service__WEBPACK_IMPORTED_MODULE_5__.NewClaimService },
    { type: src_app_service_insurance_insurance_service__WEBPACK_IMPORTED_MODULE_6__.InsuranceService },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_13__.FormBuilder },
    { type: src_app_service_new_claim_upload_document_upload_document_service__WEBPACK_IMPORTED_MODULE_7__.UploadDocumentService }
];
NewClaimPage = (0,tslib__WEBPACK_IMPORTED_MODULE_11__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_14__.Component)({
        selector: 'app-new-claim',
        template: _new_claim_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_new_claim_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], NewClaimPage);



/***/ }),

/***/ 93499:
/*!****************************************************************************!*\
  !*** ./src/app/pages/new-claim/payment-detail/payment-detail.component.ts ***!
  \****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PaymentDetailComponent": () => (/* binding */ PaymentDetailComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _payment_detail_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./payment-detail.component.html?ngResource */ 37279);
/* harmony import */ var _payment_detail_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./payment-detail.component.scss?ngResource */ 55212);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _awesome_cordova_plugins_clevertap_ngx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @awesome-cordova-plugins/clevertap/ngx */ 45363);
/* harmony import */ var _awesome_cordova_plugins_firebase_analytics_ngx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @awesome-cordova-plugins/firebase-analytics/ngx */ 48852);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! rxjs */ 92218);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! rxjs/operators */ 85921);
/* harmony import */ var src_app_service_insurance_insurance_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/service/insurance/insurance.service */ 57072);
/* harmony import */ var src_app_service_new_claim_new_claim_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/service/new-claim/new-claim.service */ 90888);
/* harmony import */ var src_app_service_new_claim_payment_method_payment_method_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/service/new-claim/payment-method/payment-method.service */ 18620);
/* harmony import */ var src_app_shared_components_add_bank_account_add_bank_account_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/shared/components/add-bank-account/add-bank-account.component */ 13883);
/* harmony import */ var src_app_shared_components_nextgen_dialog_nextgen_dialog_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/shared/components/nextgen-dialog/nextgen-dialog.service */ 96485);
/* harmony import */ var src_app_shared_components_popup_message_popup_message_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/shared/components/popup-message/popup-message.component */ 18290);
/* harmony import */ var src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/app/shared/data/enum/event */ 38570);
/* harmony import */ var src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/app/shared/data/enum/screen */ 68302);
/* harmony import */ var _shared_components_add_address_add_address_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../../shared/components/add-address/add-address.component */ 93697);
/* harmony import */ var src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! src/app/shared/data/constants */ 74676);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @angular/common */ 36362);





















let PaymentDetailComponent = class PaymentDetailComponent {
    constructor(newClaimService, router, modalCtrl, firebaseAnalytics, paymentMethodService, insuranceService, clevertap, dialogService, platform, location) {
        this.newClaimService = newClaimService;
        this.router = router;
        this.modalCtrl = modalCtrl;
        this.firebaseAnalytics = firebaseAnalytics;
        this.paymentMethodService = paymentMethodService;
        this.insuranceService = insuranceService;
        this.clevertap = clevertap;
        this.dialogService = dialogService;
        this.platform = platform;
        this.location = location;
        this.switchCase = 'banktransfer';
        this.listBank = [];
        this.commands = [
            {
                actionName: 'button.back',
                action: 'onBack',
                class: 'transparent',
                icon: 'uil uil-arrow-left body-l bold',
                position: 'left',
            },
            {
                actionName: 'button.next',
                action: 'nextStep',
                class: 'primary',
                icon: 'uil uil-arrow-right body-l bold',
                position: 'right',
                disabled: true
            },
        ];
        this.unsubscribe$ = new rxjs__WEBPACK_IMPORTED_MODULE_14__.Subject();
        this.displayBank = false;
        this.displayCheque = false;
        this.displayPayments = false;
        this.disableHome = false;
        this.disableOfice = false;
        this.disableOther = false;
        this.disableAddNew = false;
        this.onBack = () => {
            if (this.displayDisclosure) {
                this.newClaimService.claimForm.controls.step.setValue(2);
            }
            else {
                this.newClaimService.claimForm.controls.step.setValue(1);
            }
            this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_11__.Screens.UploadDocumentClaim]);
        };
        this.nextStep = () => {
            if (this.bankControl.value || this.addressControl.value) {
                this.firebaseAnalytics.logEvent(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_10__.GA4Event.ReimbursmentClaimPaymentMethodChosen, {
                    paymentMethod: {
                        bankAccount: this.bankControl.value,
                        address: this.addressControl.value
                    }
                });
                this.clevertap.recordEventWithName(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_10__.GA4Event.ReimbursmentClaimPaymentMethodChosen);
                if (this.displayDisclosure) {
                    this.newClaimService.claimForm.controls.step.setValue(4);
                }
                else {
                    this.newClaimService.claimForm.controls.step.setValue(3);
                }
                this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_11__.Screens.ClaimReviewAndSubmit]);
            }
            else {
                this.dialogService
                    .open(src_app_shared_components_popup_message_popup_message_component__WEBPACK_IMPORTED_MODULE_9__.PopupMessageComponent, {
                    data: {
                        content: 'Please choose the bank transfer and cheque delivery!',
                        textYes: 'Yes',
                    },
                    // title: 'Message',
                    title: 'title.wrongTitleMessage',
                    position: 'middle',
                    width: '90%'
                });
            }
        };
    }
    get bankControl() {
        return this.newClaimService.claimForm.controls.bankControl;
    }
    get addressControl() {
        return this.newClaimService.claimForm.controls.addressControl;
    }
    ionViewWillEnter() {
        var _a, _b, _c, _d, _e;
        this.unsubscribe$ = new rxjs__WEBPACK_IMPORTED_MODULE_14__.Subject();
        this.displayDisclosure = this.insuranceService.checkPayerSetting(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_13__.Constants.ENABLE_DISCLOSURE_SECTION, true);
        this.getInformation();
        this.displayPayment();
        if (((_a = this.addressControl) === null || _a === void 0 ? void 0 : _a.value) != null || ((_b = this.bankControl) === null || _b === void 0 ? void 0 : _b.value) != null) {
            this.commands[1] = {
                actionName: 'button.next',
                action: 'nextStep',
                class: 'primary',
                icon: 'uil uil-arrow-right body-l bold',
                position: 'right',
                disabled: false
            };
        }
        console.log((_d = (_c = this.addressControl) === null || _c === void 0 ? void 0 : _c.value) === null || _d === void 0 ? void 0 : _d.length, (_e = this.bankControl.value) === null || _e === void 0 ? void 0 : _e.length);
    }
    ionViewDidEnter() {
        this.subscription = this.platform.backButton.subscribeWithPriority(9999, () => {
            this.location.back();
        });
    }
    ionViewWillLeave() {
        this.unsubscribe$.next();
        this.unsubscribe$.complete();
        this.subscription.unsubscribe();
    }
    getInformation() {
        this.insuranceService.getPolicyInformation().pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_15__.takeUntil)(this.unsubscribe$)).subscribe((res) => {
            var _a;
            if (!res || ((_a = this.currentPolicy) === null || _a === void 0 ? void 0 : _a.beneficiaryId) === (res === null || res === void 0 ? void 0 : res.beneficiaryId))
                return;
            this.currentPolicy = res;
            this.getListBankAccount();
            this.getListAddress();
        });
    }
    getListBankAccount(newBankItem) {
        const requestBankAccount = {
            userPolicyId: this.currentPolicy.userPolicyId,
            beneficiaryId: this.currentPolicy.beneficiaryId,
            seqId: 0,
        };
        this.paymentMethodService
            .getBankAccount(requestBankAccount)
            .subscribe((data) => {
            this.listBank = data;
            // if(newBankItem.bankName){
            //   this.listBank.unshift(newBankItem);
            // }
            if (newBankItem) {
                const bankItem = this.listBank.filter(_ => _.seqId == newBankItem);
                if (bankItem.length != 0) {
                    this.bankControl.setValue(bankItem[0]);
                }
                //else{
                //   this.bankControl.setValue(newBankItem);
                // }
                this.commands[1] = {
                    actionName: 'button.next',
                    action: 'nextStep',
                    class: 'primary',
                    icon: 'uil uil-arrow-right body-l bold',
                    position: 'right',
                    disabled: false
                };
                this.addressControl.setValue(null);
            }
        });
    }
    getListAddress() {
        this.paymentMethodService.getAddress().subscribe((data) => {
            this.listAddress = data;
        });
    }
    segmentChanged(event) {
        if (this.displayBank) {
            this.switchCase = event.detail.value;
            this.listAddress.forEach(item => {
                if (item.title == 'Home') {
                    this.disableHome = true;
                }
                if (item.title == 'Other') {
                    this.disableOther = true;
                }
                if (item.title == 'Office') {
                    this.disableOfice = true;
                }
            });
            if (this.disableHome && this.disableOther && this.disableOfice && this.switchCase != 'banktransfer') {
                this.disableAddNew = true;
            }
            else {
                this.disableAddNew = false;
            }
        }
    }
    onClickCreate(switchCase) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__awaiter)(this, void 0, void 0, function* () {
            const switchDefault = 'banktransfer';
            if (switchCase === switchDefault) {
                const ref = yield this.modalCtrl.create({
                    component: src_app_shared_components_add_bank_account_add_bank_account_component__WEBPACK_IMPORTED_MODULE_7__.AddBankAccountComponent,
                });
                ref.present();
                const { data } = yield ref.onWillDismiss();
                if (data) {
                    // this.newBankId = data;
                    // this.getListBankAccount(this.newBankId);
                    this.newBankItem = data;
                    // else{
                    //   this.newBankItem = {
                    //     bankPhoneNbr: data.mobileNumber,
                    //     bankEmail: data.email,
                    //     bankName: data.bankName,
                    //     bankAccountName: data.accountName,
                    //     bankAccountNbr: data.accountNumber,
                    //     bankAcctValFromType: data.iban,
                    //     bankSwiftCode: data.swiftCode,
                    //     bankAddress: data.bankAddress,
                    //     bankCountryId: data.country.id,
                    //     bankCurrencyId: data.currency.id,
                    //   };
                    // }
                    this.getListBankAccount(this.newBankItem);
                }
            }
            else {
                const ref = yield this.modalCtrl.create({
                    component: _shared_components_add_address_add_address_component__WEBPACK_IMPORTED_MODULE_12__.AddAddressComponent,
                    componentProps: {
                        dataSource: this.listAddress,
                        addNew: true
                    }
                });
                ref.present();
                const { data } = yield ref.onWillDismiss();
                if (data) {
                    this.getListAddress();
                    if (this.listAddress.length >= 2) {
                        this.disableAddNew = true;
                    }
                    else {
                        this.disableAddNew = false;
                    }
                }
            }
        });
    }
    onClickBankAccount(item) {
        this.newBankItem = null;
        this.bankControl.setValue(item);
        this.commands[1] = {
            actionName: 'button.next',
            action: 'nextStep',
            class: 'primary',
            icon: 'uil uil-arrow-right body-l bold',
            position: 'right',
            disabled: false
        };
        this.addressControl.setValue(null);
    }
    onClickAddress(item) {
        this.newBankItem = null;
        this.addressControl.setValue(item);
        this.commands[1] = {
            actionName: 'button.next',
            action: 'nextStep',
            class: 'primary',
            icon: 'uil uil-arrow-right body-l bold',
            position: 'right',
            disabled: false
        };
        this.bankControl.setValue(null);
    }
    displayPayment() {
        const columnnameBank = this.insuranceService.checkPayerSetting(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_13__.Constants.ENABLE_BENEF_BANK_TRANSFER, true);
        if (columnnameBank == true) {
            this.displayBank = true;
        }
        else {
            this.displayBank = false;
            this.segmentChanged(this.switchCase = 'chequeDelivery');
        }
        const columnnameCheque = this.insuranceService.checkPayerSetting(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_13__.Constants.ENABLE_BENEF_CHEQUE_PAYMENT, true);
        if (columnnameCheque == true) {
            this.displayCheque = true;
        }
        else {
            this.displayCheque = false;
        }
    }
};
PaymentDetailComponent.ctorParameters = () => [
    { type: src_app_service_new_claim_new_claim_service__WEBPACK_IMPORTED_MODULE_5__.NewClaimService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_17__.Router },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_18__.ModalController },
    { type: _awesome_cordova_plugins_firebase_analytics_ngx__WEBPACK_IMPORTED_MODULE_3__.FirebaseAnalytics },
    { type: src_app_service_new_claim_payment_method_payment_method_service__WEBPACK_IMPORTED_MODULE_6__.PaymentMethodService },
    { type: src_app_service_insurance_insurance_service__WEBPACK_IMPORTED_MODULE_4__.InsuranceService },
    { type: _awesome_cordova_plugins_clevertap_ngx__WEBPACK_IMPORTED_MODULE_2__.CleverTap },
    { type: src_app_shared_components_nextgen_dialog_nextgen_dialog_service__WEBPACK_IMPORTED_MODULE_8__.DialogService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_18__.Platform },
    { type: _angular_common__WEBPACK_IMPORTED_MODULE_19__.Location }
];
PaymentDetailComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_20__.Component)({
        selector: 'app-payment-detail',
        template: _payment_detail_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_payment_detail_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], PaymentDetailComponent);



/***/ }),

/***/ 21661:
/*!**********************************************************************************!*\
  !*** ./src/app/pages/new-claim/review-and-submit/review-and-submit.component.ts ***!
  \**********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ReviewAndSubmitComponent": () => (/* binding */ ReviewAndSubmitComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _review_and_submit_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./review-and-submit.component.html?ngResource */ 73041);
/* harmony import */ var _review_and_submit_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./review-and-submit.component.scss?ngResource */ 54544);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _awesome_cordova_plugins_clevertap_ngx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @awesome-cordova-plugins/clevertap/ngx */ 45363);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _awesome_cordova_plugins_firebase_analytics_ngx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @awesome-cordova-plugins/firebase-analytics/ngx */ 48852);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! rxjs */ 92218);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! rxjs/operators */ 85921);
/* harmony import */ var src_app_service_insurance_insurance_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/service/insurance/insurance.service */ 57072);
/* harmony import */ var src_app_service_new_claim_new_claim_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/service/new-claim/new-claim.service */ 90888);
/* harmony import */ var src_app_shared_components_nextgen_dialog_nextgen_dialog_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/shared/components/nextgen-dialog/nextgen-dialog.service */ 96485);
/* harmony import */ var src_app_shared_components_popup_message_popup_message_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/shared/components/popup-message/popup-message.component */ 18290);
/* harmony import */ var src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/shared/data/constants */ 74676);
/* harmony import */ var src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/shared/data/enum/event */ 38570);
/* harmony import */ var src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/app/shared/data/enum/screen */ 68302);
/* harmony import */ var _service_language_language_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../../service/language/language.service */ 11281);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @angular/common */ 36362);



















let ReviewAndSubmitComponent = class ReviewAndSubmitComponent {
    constructor(router, firebaseAnalytics, newClaimService, insuranceService, clevertap, dialogService, languageService, platform, location) {
        this.router = router;
        this.firebaseAnalytics = firebaseAnalytics;
        this.newClaimService = newClaimService;
        this.insuranceService = insuranceService;
        this.clevertap = clevertap;
        this.dialogService = dialogService;
        this.languageService = languageService;
        this.platform = platform;
        this.location = location;
        this.testChecked = false;
        this.checkedHighlight = true;
        this.commands = [
            {
                actionName: 'button.back',
                action: 'onBack',
                class: 'transparent',
                icon: 'uil uil-arrow-left body-l bold',
                position: 'left',
            },
            {
                actionName: 'button.submit',
                action: 'onSubmit',
                class: 'primary',
            },
        ];
        this.unsubscribe$ = new rxjs__WEBPACK_IMPORTED_MODULE_12__.Subject();
        this.lang = 'en';
        this.onBack = () => {
            this.checkNavigateBack();
        };
        this.onSubmit = () => {
            if (this.testChecked == false && this.displayDeclaration) {
                this.checkedHighlight = false;
            }
            else {
                this.checkedHighlight = true;
                this.firebaseAnalytics.logEvent(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_9__.GA4Event.ReimbursmentClaimSubmitted, { claim_type: '' });
                this.clevertap.recordEventWithName(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_9__.GA4Event.ReimbursmentClaimSubmitted);
                // this.router.navigate(['/' + Screens.SubmittedSuccessfully]);
                const request = {
                    userPolicyId: this.policy.userPolicyId,
                    beneficiaryId: this.claimValue.detailForm.memberSelect.id,
                    requestSource: src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_8__.Constants.REQUEST_SOURCE,
                };
                this.newClaimService.reimbursement(request).subscribe((res) => {
                    if (res.status == 0) {
                        this.dialogService.open(src_app_shared_components_popup_message_popup_message_component__WEBPACK_IMPORTED_MODULE_7__.PopupMessageComponent, {
                            data: {
                                content: res.message,
                                textYes: 'button.ok',
                            },
                            title: 'submittedSuccessfully.wrongMessage',
                            position: 'middle',
                            width: '90%',
                        });
                    }
                    else {
                        this.newClaimService.clearClaim();
                        this.checkNavigate(res);
                    }
                }, (error) => {
                    console.log(error);
                });
                // TODO
            }
        };
    }
    get claimValue() {
        return this.newClaimService.claimForm.value;
    }
    ngOnInit() {
        // this.claimInfo = {
        //   member: this.claimValue.detailForm.memberSelect.name,
        //   countryName: this.claimValue.detailForm.countrySelect.name,
        //   claimCurrency: this.claimValue.detailForm.currency.name,
        //   treatmentName: this.claimValue.detailForm.serviceType.name,
        //   serviceDate: this.claimValue.detailForm.serviceDate,
        //   codeCurrency: this.claimValue.detailForm.amount,
        // }
        // this.documentInfo = this.claimValue.documentForm;
        // this.paymentInfo = this.claimValue.bankControl;
        // console.log(this.claimValue)
        // const claimDocumentsDup = [...this.claimDocuments];
        // this.claimDocumentsDup = claimDocumentsDup.filter(
        //   (value, index, self) =>
        //     index === self.findIndex((t) => t.id === value.id),
        // );
        // console.log(this.claimDocumentsDup, this.claimDocuments);
    }
    loadReviewAndSubmit() {
        this.disclosureInfo = {
            treatmentOfSymptoms: this.claimValue.disclosureForm.treatmentOfSymptoms,
            firstOccurrenceDate: this.claimValue.disclosureForm.firstOccurrenceDate,
            dateFirstTreatmentOfSymptoms: this.claimValue.disclosureForm.dateFirstTreatmentOfSymptoms,
            accidentDesc: this.claimValue.disclosureForm.accidentDesc,
            accident: this.claimValue.disclosureForm.accident,
            treatmentSymtoms: this.claimValue.disclosureForm.treatmentSymtoms,
        };
        this.claimInfo = {
            member: this.claimValue.detailForm.memberSelect.name,
            countryName: this.claimValue.detailForm.countrySelect.name,
            claimCurrency: this.claimValue.detailForm.currency.currencyDescription,
            treatmentName: this.claimValue.detailForm.serviceType.name,
            serviceDate: this.claimValue.detailForm.serviceDate,
            codeCurrency: this.claimValue.detailForm.amount,
        };
        this.documentInfo = this.claimValue.documentForm;
        this.paymentInfo = this.claimValue.bankControl;
        this.addressControl = this.claimValue.addressControl;
        console.log(this.claimInfo);
    }
    ionViewWillEnter() {
        this.loadReviewAndSubmit();
        this.unsubscribe$ = new rxjs__WEBPACK_IMPORTED_MODULE_12__.Subject();
        this.displayDisclosure = this.insuranceService.checkPayerSetting(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_8__.Constants.ENABLE_DISCLOSURE_SECTION, true);
        this.insuranceService
            .getPolicyInformation()
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_13__.takeUntil)(this.unsubscribe$))
            .subscribe((res) => {
            if (!res)
                return;
            this.policy = res;
        });
        this.getLanguage();
        this.checkDisplayDeclaration();
    }
    ionViewDidEnter() {
        this.subscription = this.platform.backButton.subscribeWithPriority(9999, () => {
            this.location.back();
        });
    }
    ionViewWillLeave() {
        this.unsubscribe$.next();
        this.unsubscribe$.complete();
        this.subscription.unsubscribe();
    }
    getLanguage() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_14__.__awaiter)(this, void 0, void 0, function* () {
            this.lang = this.languageService.getISOLanguageCode();
        });
    }
    onNavigateToClaimDetails() {
        if (this.displayDisclosure) {
            this.newClaimService.claimForm.controls.step.setValue(1);
        }
        else {
            this.newClaimService.claimForm.controls.step.setValue(0);
        }
        this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_10__.Screens.ClaimDetail]);
    }
    onNavigateToDocument() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_14__.__awaiter)(this, void 0, void 0, function* () {
            if (this.displayDisclosure) {
                this.newClaimService.claimForm.controls.step.setValue(2);
            }
            else {
                this.newClaimService.claimForm.controls.step.setValue(1);
            }
            this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_10__.Screens.UploadDocumentClaim]);
        });
    }
    onNavigateToPayMent() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_14__.__awaiter)(this, void 0, void 0, function* () {
            if (this.displayDisclosure) {
                this.newClaimService.claimForm.controls.step.setValue(3);
            }
            else {
                this.newClaimService.claimForm.controls.step.setValue(2);
            }
            this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_10__.Screens.PaymentMethod]);
        });
    }
    onNavigateToDisclosure() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_14__.__awaiter)(this, void 0, void 0, function* () {
            if (this.displayDisclosure) {
                this.newClaimService.claimForm.controls.step.setValue(0);
                this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_10__.Screens.DisclosureAccident]);
            }
        });
    }
    checkNavigate(value) {
        if (
        // this.insuranceService
        //   .getPayerSettingValue()
        //   .some(
        //     (_) =>
        //       _.columnname == 'EnableMobileAppRateMyVisit' && _.required == true,
        //   )
        this.insuranceService.checkPayerSetting(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_8__.Constants.ENABLE_MOBILE_APP_RATE_VISIT, true)) {
            this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_10__.Screens.SubmittedSuccessfully], {
                queryParams: { asoapNbr: value.asoapNbr, asoapPlanId: value.asoapPlanId, externalReference: value.externalReference },
            });
        }
        else {
            this.router.navigate(['/home/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_10__.Screens.Home]);
        }
    }
    checkNavigateBack() {
        const benefBankTransfer = this.insuranceService.checkPayerSetting(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_8__.Constants.ENABLE_BENEF_BANK_TRANSFER, true);
        const benefChequePayment = this.insuranceService.checkPayerSetting(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_8__.Constants.ENABLE_BENEF_CHEQUE_PAYMENT, true);
        if (
        // this.insuranceService
        //   .getPayerSettingValue()
        //   .some(
        //     (_) =>
        //       (_.columnname == 'MyNCEnableBenefBankTransfer' ||
        //         _.columnname == 'MyNCEnableBenefChequePayment') &&
        //       _.required == true,
        //   )
        benefBankTransfer == false &&
            benefChequePayment == false) {
            if (this.displayDisclosure) {
                this.newClaimService.claimForm.controls.step.setValue(2);
            }
            else {
                this.newClaimService.claimForm.controls.step.setValue(1);
            }
            this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_10__.Screens.UploadDocumentClaim]);
        }
        else {
            if (this.displayDisclosure) {
                this.newClaimService.claimForm.controls.step.setValue(3);
            }
            else {
                this.newClaimService.claimForm.controls.step.setValue(2);
            }
            this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_10__.Screens.PaymentMethod]);
        }
    }
    checkDisplayDeclaration() {
        // const countryId = this.insuranceService.getPolicyDetailResponse()?.[0]?.Payer?.Address.countryId;
        const displayDeclaration = this.insuranceService.checkPayerSetting(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_8__.Constants.ENABLED_REIMBURSEMENT_DECLARATION, true);
        if (displayDeclaration == true) {
            this.displayDeclaration = true;
            this.commands[1] = {
                actionName: 'button.submit',
                action: 'onSubmit',
                class: 'btnSubmit',
            };
        }
        else {
            this.displayDeclaration = false;
            this.commands[1] = {
                actionName: 'button.submit',
                action: 'onSubmit',
                class: 'primary',
            };
        }
    }
    onChecked(event) {
        event.preventDefault();
        this.testChecked = !event.target.checked;
        if (event.target.checked) {
            this.commands[1] = {
                actionName: 'button.submit',
                action: 'onSubmit',
                class: 'btnSubmit',
            };
        }
        else {
            this.checkedHighlight = true;
            this.commands[1] = {
                actionName: 'button.submit',
                action: 'onSubmit',
                class: 'primary',
            };
        }
    }
};
ReviewAndSubmitComponent.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_15__.Router },
    { type: _awesome_cordova_plugins_firebase_analytics_ngx__WEBPACK_IMPORTED_MODULE_3__.FirebaseAnalytics },
    { type: src_app_service_new_claim_new_claim_service__WEBPACK_IMPORTED_MODULE_5__.NewClaimService },
    { type: src_app_service_insurance_insurance_service__WEBPACK_IMPORTED_MODULE_4__.InsuranceService },
    { type: _awesome_cordova_plugins_clevertap_ngx__WEBPACK_IMPORTED_MODULE_2__.CleverTap },
    { type: src_app_shared_components_nextgen_dialog_nextgen_dialog_service__WEBPACK_IMPORTED_MODULE_6__.DialogService },
    { type: _service_language_language_service__WEBPACK_IMPORTED_MODULE_11__.LanguageService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_16__.Platform },
    { type: _angular_common__WEBPACK_IMPORTED_MODULE_17__.Location }
];
ReviewAndSubmitComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_14__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_18__.Component)({
        selector: 'app-review-and-submit',
        template: _review_and_submit_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_review_and_submit_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], ReviewAndSubmitComponent);



/***/ }),

/***/ 53228:
/*!***************************************************************************************!*\
  !*** ./src/app/pages/new-claim/claim-details/claim-details.component.scss?ngResource ***!
  \***************************************************************************************/
/***/ ((module) => {

module.exports = ":root {\n  --nc-color-nextgen-neutral-grey-50: red;\n  --nc-color-nextgen-white: yellow;\n  --nc-color-nextgen-blue: #0d152e;\n  --nc-color-nextgen-green: #00908d;\n  --nc-color-nextgen-black: #000000;\n  --nc-color-nextgen-grey-background: #c8d3da;\n  --nc-color-nextgen-grey: #92a2ac;\n  --nc-color-nextgen-stone-grey: #fafafa;\n  --nc-color-nextgen-error: #fc1055;\n  --nc-color-nextgen-neutral-grey: #414141;\n  --nc-color-nextgen-fibrant-green: #00bab6;\n  --nc-color-nextgen-warning: #ffd048;\n  --nc-color-nextgen-green-background: #e6f2f2;\n  --nc-color-nextgen-neutral-grey-400: #7a7a7a;\n  --nc-color-nextgen-neutral-grey-100: #eff3f5;\n  --nc-color-nextgen-status-error: #ba0c3f;\n  --nc-color-nextgen-status-error-background: #ffeff4;\n  --nc-color-nextgen-status-warning: #cba127;\n  --nc-color-nextgen-status-warning-background: #fff8e6;\n  --nc-color-nextgen-blue-100: #dfeff2;\n  --nc-color-nextgen-error-red-700: #f62459;\n  --nc-color-nextgen-blue-500: #006192;\n  --nc-color-nextgen-blue-400: #79cdec;\n  --nc-color-nextgen-red-500: #ff6592;\n  --nc-color-nextgen-secondary-blue-300: #13a0d3;\n  --lumi-white-color: #ffffff;\n  --lumi-primary-yellow-color: #fab600;\n}\n\n.ion-color-green {\n  --ion-color-base: var(--nc-color-nextgen-green);\n  --ion-color-base-rgb: var(--nc-color-nextgen-green);\n  --ion-color-contrast: var(--nc-color-nextgen-white);\n  --ion-color-contrast-rgb: var(--nc-color-nextgen-green);\n  --ion-color-shade: var(--nc-color-nextgen-green);\n  --ion-color-tint: var(--nc-color-nextgen-green);\n}\n\n/*\n * 1. Custom CSS \n * ----------------------------------------------------------------------------\n */\n\n:root {\n  --nc-color-nextgen-neutral-grey-50: red;\n  --nc-color-nextgen-white: yellow;\n  --nc-color-nextgen-blue: #0d152e;\n  --nc-color-nextgen-green: #00908d;\n  --nc-color-nextgen-black: #000000;\n  --nc-color-nextgen-grey-background: #c8d3da;\n  --nc-color-nextgen-grey: #92a2ac;\n  --nc-color-nextgen-stone-grey: #fafafa;\n  --nc-color-nextgen-error: #fc1055;\n  --nc-color-nextgen-neutral-grey: #414141;\n  --nc-color-nextgen-fibrant-green: #00bab6;\n  --nc-color-nextgen-warning: #ffd048;\n  --nc-color-nextgen-green-background: #e6f2f2;\n  --nc-color-nextgen-neutral-grey-400: #7a7a7a;\n  --nc-color-nextgen-neutral-grey-100: #eff3f5;\n  --nc-color-nextgen-status-error: #ba0c3f;\n  --nc-color-nextgen-status-error-background: #ffeff4;\n  --nc-color-nextgen-status-warning: #cba127;\n  --nc-color-nextgen-status-warning-background: #fff8e6;\n  --nc-color-nextgen-blue-100: #dfeff2;\n  --nc-color-nextgen-error-red-700: #f62459;\n  --nc-color-nextgen-blue-500: #006192;\n  --nc-color-nextgen-blue-400: #79cdec;\n  --nc-color-nextgen-red-500: #ff6592;\n  --nc-color-nextgen-secondary-blue-300: #13a0d3;\n  --lumi-white-color: #ffffff;\n  --lumi-primary-yellow-color: #fab600;\n}\n\n.ion-color-green {\n  --ion-color-base: var(--nc-color-nextgen-green);\n  --ion-color-base-rgb: var(--nc-color-nextgen-green);\n  --ion-color-contrast: var(--nc-color-nextgen-white);\n  --ion-color-contrast-rgb: var(--nc-color-nextgen-green);\n  --ion-color-shade: var(--nc-color-nextgen-green);\n  --ion-color-tint: var(--nc-color-nextgen-green);\n}\n\n.display-xl {\n  font-size: 41px !important;\n  font-weight: 400 !important;\n  line-height: 120% !important;\n}\n\n.display-md {\n  font-size: 36px !important;\n  font-weight: 400 !important;\n  line-height: 120% !important;\n}\n\n.h1 {\n  font-size: 31px !important;\n  font-weight: 400 !important;\n  line-height: 120% !important;\n}\n\n.h2 {\n  font-size: 28px !important;\n  font-weight: 400 !important;\n  line-height: 120% !important;\n}\n\n.h3 {\n  font-size: 25px !important;\n  font-weight: 400 !important;\n  line-height: 120% !important;\n}\n\n.h4 {\n  font-size: 22px !important;\n  font-weight: 400 !important;\n  line-height: 120% !important;\n}\n\n.h5 {\n  font-size: 19px !important;\n  font-weight: 400 !important;\n  line-height: 120% !important;\n}\n\n.h6 {\n  font-size: 17px !important;\n  font-weight: 400 !important;\n  line-height: 120% !important;\n}\n\n.body-l {\n  font-size: 17px !important;\n  font-weight: 400 !important;\n  line-height: 120% !important;\n}\n\n.body-n {\n  font-size: 15px !important;\n  font-weight: 400 !important;\n  line-height: 120% !important;\n}\n\n.body-sm {\n  font-size: 13px !important;\n  font-weight: 400 !important;\n  line-height: 120% !important;\n}\n\n.body-xs {\n  font-size: 12px !important;\n  font-weight: 400 !important;\n  line-height: 120% !important;\n}\n\n.semibold.display-xl {\n  font-weight: 600 !important;\n}\n\n.semibold.display-md {\n  font-weight: 600 !important;\n}\n\n.semibold.h1 {\n  font-weight: 600 !important;\n}\n\n.semibold.h2 {\n  font-weight: 600 !important;\n}\n\n.semibold.h3 {\n  font-weight: 600 !important;\n}\n\n.semibold.h4 {\n  font-weight: 600 !important;\n}\n\n.semibold.h5 {\n  font-weight: 600 !important;\n}\n\n.semibold.h6 {\n  font-weight: 600 !important;\n}\n\n.semibold.body-l {\n  font-weight: 600 !important;\n}\n\n.semibold.body-n {\n  font-weight: 600 !important;\n}\n\n.semibold.body-sm {\n  font-weight: 600 !important;\n}\n\n.semibold.body-xs {\n  font-weight: 600 !important;\n}\n\n.bold.display-xl {\n  font-weight: 700 !important;\n}\n\n.bold.display-md {\n  font-weight: 700 !important;\n}\n\n.bold.h1 {\n  font-weight: 700 !important;\n}\n\n.bold.h2 {\n  font-weight: 700 !important;\n}\n\n.bold.h3 {\n  font-weight: 700 !important;\n}\n\n.bold.h4 {\n  font-weight: 700 !important;\n}\n\n.bold.h5 {\n  font-weight: 700 !important;\n}\n\n.bold.h6 {\n  font-weight: 700 !important;\n}\n\n.bold.body-l {\n  font-weight: 700 !important;\n}\n\n.bold.body-n {\n  font-weight: 700 !important;\n}\n\n.bold.body-sm {\n  font-weight: 700 !important;\n}\n\n.bold.body-xs {\n  font-weight: 700 !important;\n}\n\n@font-face {\n  font-family: \"Allianz Neo\";\n  font-style: normal;\n  font-weight: 300;\n  font-display: swap;\n  src: url('AllianzNeoW04-Light.woff2') format(\"woff2\"), url('AllianzNeoW04-Light.woff') format(\"woff\");\n}\n\n@font-face {\n  font-family: \"Allianz Neo\";\n  font-style: italic;\n  font-weight: 300;\n  font-display: swap;\n  src: url('AllianzNeoW04-LightItalic.woff2') format(\"woff2\"), url('AllianzNeoW04-LightItalic.woff') format(\"woff\");\n}\n\n@font-face {\n  font-family: \"Allianz Neo\";\n  font-style: normal;\n  font-weight: 400;\n  font-display: swap;\n  src: url('AllianzNeoW04-Regular.woff2') format(\"woff2\"), url('AllianzNeoW04-Regular.woff') format(\"woff\");\n}\n\n@font-face {\n  font-family: \"Allianz Neo\";\n  font-style: italic;\n  font-weight: 400;\n  font-display: swap;\n  src: url('AllianzNeoW04-Italic.woff2') format(\"woff2\"), url('AllianzNeoW04-Italic.woff') format(\"woff\");\n}\n\n@font-face {\n  font-family: \"Allianz Neo\";\n  font-style: normal;\n  font-weight: 600;\n  font-display: swap;\n  src: url('AllianzNeoW04-SemiBold.woff2') format(\"woff2\"), url('AllianzNeoW04-SemiBold.woff') format(\"woff\");\n}\n\n@font-face {\n  font-family: \"Allianz Neo\";\n  font-style: italic;\n  font-weight: 600;\n  font-display: swap;\n  src: url('AllianzNeoW04-SemiBoldIt.woff2') format(\"woff2\"), url('AllianzNeoW04-SemiBoldIt.woff') format(\"woff\");\n}\n\n@font-face {\n  font-family: \"Allianz Neo\";\n  font-style: normal;\n  font-weight: 700;\n  font-display: swap;\n  src: url('AllianzNeoW04-Bold.woff2') format(\"woff2\"), url('AllianzNeoW04-Bold.woff') format(\"woff\");\n}\n\n@font-face {\n  font-family: \"Allianz Neo\";\n  font-style: italic;\n  font-weight: 700;\n  font-display: swap;\n  src: url('AllianzNeoW04-BoldItalic.woff2') format(\"woff2\"), url('AllianzNeoW04-BoldItalic.woff') format(\"woff\");\n}\n\n* {\n  color: var(--nc-color-nextgen-neutral-grey);\n  font-family: \"Allianz Neo\", sans-serif;\n  font-weight: 400;\n  font-size: 16px;\n}\n\nhtml {\n  --ion-safe-area-top: 0px;\n}\n\n.col-1 {\n  width: 8.33%;\n}\n\n.col-2 {\n  width: 16.66%;\n}\n\n.col-3 {\n  width: 25%;\n}\n\n.col-4 {\n  width: 33.33%;\n}\n\n.col-5 {\n  width: 41.66%;\n}\n\n.col-6 {\n  width: 50%;\n}\n\n.col-7 {\n  width: 58.33%;\n}\n\n.col-8 {\n  width: 66.66%;\n}\n\n.col-9 {\n  width: 75%;\n}\n\n.col-10 {\n  width: 83.33%;\n}\n\n.col-11 {\n  width: 91.66%;\n}\n\n.col-12 {\n  width: 100%;\n}\n\n@media only screen and (max-width: 576px) {\n  /* For tablets: */\n  .col-sm-1 {\n    width: 8.33%;\n  }\n\n  .col-sm-2 {\n    width: 16.66%;\n  }\n\n  .col-sm-3 {\n    width: 25%;\n  }\n\n  .col-sm-4 {\n    width: 33.33%;\n  }\n\n  .col-sm-5 {\n    width: 41.66%;\n  }\n\n  .col-sm-6 {\n    width: 50%;\n  }\n\n  .col-sm-7 {\n    width: 58.33%;\n  }\n\n  .col-sm-8 {\n    width: 66.66%;\n  }\n\n  .col-sm-9 {\n    width: 75%;\n  }\n\n  .col-sm-10 {\n    width: 83.33%;\n  }\n\n  .col-sm-11 {\n    width: 91.66%;\n  }\n\n  .col-sm-12 {\n    width: 100%;\n  }\n}\n\n@media only screen and (max-width: 768px) and (min-width: 577px) {\n  /* For tablets: */\n  .col-md-1 {\n    width: 8.33%;\n  }\n\n  .col-md-2 {\n    width: 16.66%;\n  }\n\n  .col-md-3 {\n    width: 25%;\n  }\n\n  .col-md-4 {\n    width: 33.33%;\n  }\n\n  .col-md-5 {\n    width: 41.66%;\n  }\n\n  .col-md-6 {\n    width: 50%;\n  }\n\n  .col-md-7 {\n    width: 58.33%;\n  }\n\n  .col-md-8 {\n    width: 66.66%;\n  }\n\n  .col-md-9 {\n    width: 75%;\n  }\n\n  .col-md-10 {\n    width: 83.33%;\n  }\n\n  .col-md-11 {\n    width: 91.66%;\n  }\n\n  .col-md-12 {\n    width: 100%;\n  }\n}\n\n@media only screen and (min-width: 769px) {\n  /* For tablets: */\n  .col-lg-1 {\n    width: 8.33%;\n  }\n\n  .col-lg-2 {\n    width: 16.66%;\n  }\n\n  .col-lg-3 {\n    width: 25%;\n  }\n\n  .col-lg-4 {\n    width: 33.33%;\n  }\n\n  .col-lg-5 {\n    width: 41.66%;\n  }\n\n  .col-lg-6 {\n    width: 50%;\n  }\n\n  .col-lg-7 {\n    width: 58.33%;\n  }\n\n  .col-lg-8 {\n    width: 66.66%;\n  }\n\n  .col-lg-9 {\n    width: 75%;\n  }\n\n  .col-lg-10 {\n    width: 83.33%;\n  }\n\n  .col-lg-11 {\n    width: 91.66%;\n  }\n\n  .col-lg-12 {\n    width: 100%;\n  }\n}\n\n.row {\n  display: flex;\n  justify-content: center;\n  align-items: center;\n}\n\n.custom-toast {\n  --max-width: fit-content;\n}\n\n/*\n * 2. Custom CSS for compatibility with Edge\n * ----------------------------------------------------------------------------\n */\n\ninput::-ms-reveal,\ninput::-ms-clear {\n  display: none;\n}\n\n.swal2-popup {\n  margin-top: 20px;\n}\n\n/*\n * 3. Custom CSS for loading controller\n * ----------------------------------------------------------------------------\n */\n\n.transparent-loading-class {\n  --background: transparent;\n  --spinner-color: #47e6b1;\n}\n\n.loading-wrapper.sc-ion-loading-md {\n  box-shadow: unset;\n  -webkit-box-shadow: unset;\n}\n\n.uil {\n  color: var(--nc-color-nextgen-grey);\n}\n\n.btn {\n  height: 48px;\n  border-radius: 28px;\n  padding: 0px 41px 0px 41px;\n  box-shadow: none;\n}\n\n.btn.btn-circle {\n  background-color: var(--nc-color-nextgen-stone-grey) !important;\n  color: var(--nc-color-nextgen-black);\n  padding: unset !important;\n  height: 36px !important;\n  width: 36px !important;\n  border-radius: 50% !important;\n}\n\n.btn.btn-circle i {\n  color: var(--nc-color-nextgen-black);\n}\n\n.btn.primary {\n  background: var(--nc-color-nextgen-green);\n  color: var(--nc-color-nextgen-white);\n}\n\n.btn.primary .uil {\n  color: var(--nc-color-nextgen-white);\n}\n\n.btn.primary:disabled {\n  background-color: var(--nc-color-nextgen-grey-background) !important;\n  color: var(--nc-color-nextgen-grey) !important;\n}\n\n.btn.secondary {\n  background: var(--nc-color-nextgen-white) !important;\n  border-color: var(--nc-color-nextgen-green);\n  border: solid 1px;\n  color: var(--nc-color-nextgen-green);\n}\n\n.btn.secondary .uil {\n  color: var(--nc-color-nextgen-green);\n}\n\n.btn.secondary:disabled {\n  background-color: var(--nc-color-nextgen-white) !important;\n  color: var(--nc-color-nextgen-grey) !important;\n  border-color: var(--nc-color-nextgen-grey-background) !important;\n}\n\n.btn.transparent {\n  background: transparent !important;\n  border-color: var(--nc-color-nextgen-green);\n  border: solid 1px;\n  color: var(--nc-color-nextgen-green);\n}\n\n.btn.transparent .uil {\n  color: var(--nc-color-nextgen-green);\n}\n\n.btn.transparent:disabled {\n  background-color: transparent !important;\n  color: var(--nc-color-nextgen-grey) !important;\n  border-color: var(--nc-color-nextgen-grey-background) !important;\n}\n\n.btn.btn-large {\n  height: 56px !important;\n  width: 100%;\n}\n\n.btn.bold {\n  font-weight: 700 !important;\n}\n\n.btn.semibold {\n  font-weight: 600 !important;\n}\n\n.btn-no-space {\n  padding: 5px !important;\n  height: -moz-fit-content;\n  height: fit-content;\n}\n\n.btn-back {\n  width: 31px;\n  height: 28px;\n  background-color: transparent;\n  padding: 0;\n  color: var(--nc-color-nextgen-green);\n}\n\n.container {\n  padding: 2rem;\n  height: 100%;\n}\n\n.body-section {\n  width: 100%;\n  height: 95%;\n  overflow-y: auto;\n  position: relative;\n}\n\n.top-section {\n  width: 100%;\n  height: 10%;\n  justify-content: space-between;\n  display: flex;\n  align-items: center;\n}\n\n.form-control {\n  position: relative;\n  height: 85px;\n  margin-bottom: 8px;\n}\n\n.control {\n  border-radius: 8px;\n  height: 56px;\n  border: 1px solid var(--nc-color-nextgen-grey-background);\n  width: 100%;\n  position: absolute;\n  top: 32px;\n  background-color: var(--nc-color-nextgen-white);\n}\n\n.control table {\n  table-layout: fixed;\n  border-collapse: unset;\n}\n\n.control input {\n  height: 54px;\n  border: unset;\n  border-radius: 8px;\n  width: max-content;\n  width: 100%;\n  pointer-events: auto;\n  background-color: var(--nc-color-nextgen-white);\n}\n\n.control.textarea {\n  height: 108px;\n}\n\n.control textarea {\n  height: 106px;\n  border: unset;\n  border-radius: 8px;\n  width: max-content;\n  width: 100%;\n  pointer-events: auto;\n  resize: none;\n  background-color: var(--nc-color-nextgen-white);\n}\n\n.control input:focus {\n  outline: none;\n}\n\n.control:focus-within {\n  border-color: var(--nc-color-nextgen-green);\n}\n\n.control:focus-within .first-icon {\n  display: none;\n}\n\n.control:focus-within .first-icon.non-hidden {\n  display: table-cell;\n}\n\n.control .first-icon {\n  width: 32px;\n  text-align: center;\n  padding-left: 8px;\n}\n\n.control .first-icon i {\n  font-size: 24px !important;\n}\n\n.control .second-icon {\n  width: 32px;\n  text-align: center;\n}\n\n.control .second-icon i {\n  font-size: 24px !important;\n}\n\n.control:focus-within ~ div .control-label {\n  color: var(--nc-color-nextgen-green);\n}\n\n.control-error .control {\n  border-color: var(--nc-color-nextgen-error);\n}\n\n.control-error .control-label {\n  color: var(--nc-color-nextgen-error) !important;\n}\n\n.validation-summary li {\n  color: var(--nc-color-nextgen-error) !important;\n  list-style: none;\n}\n\n.validation-summary li i {\n  color: var(--nc-color-nextgen-error) !important;\n}\n\n.mr-1 {\n  margin-right: 0.5rem;\n}\n\n.mb-1 {\n  margin-bottom: 0.5rem;\n}\n\n.dialog-pane {\n  position: absolute;\n  pointer-events: auto;\n  box-sizing: border-box;\n  z-index: 1000;\n  display: block;\n  max-width: 100%;\n  max-height: 100%;\n}\n\n.overlay-backdrop {\n  background-color: var(--nc-color-nextgen-neutral-grey);\n  opacity: 0.2 !important;\n}\n\n.dialog-container {\n  animation: fadeIn 0.5s linear;\n  background-color: var(--nc-color-nextgen-white);\n}\n\n@keyframes fadeIn {\n  from {\n    transform: translateY(100%);\n  }\n  to {\n    transform: translateY(0%);\n  }\n}\n\n.error {\n  color: var(--nc-color-nextgen-error);\n}\n\n.error.background {\n  background-color: var(--nc-color-nextgen-error);\n}\n\n.success {\n  color: var(--nc-color-nextgen-fibrant-green);\n}\n\n.success.background {\n  background-color: var(--nc-color-nextgen-fibrant-green);\n}\n\n.warning {\n  color: var(--nc-color-nextgen-warning);\n}\n\n.warning.background {\n  background-color: var(--nc-color-nextgen-warning);\n}\n\n.select {\n  width: 100%;\n  height: 54px;\n  border: unset;\n  border-radius: 8px;\n  display: grid;\n  -webkit-appearance: none;\n          appearance: none;\n  grid-template-areas: \"select\";\n}\n\n.select:focus {\n  outline: unset;\n}\n\n.color-black {\n  color: var(--nc-color-nextgen-black);\n}\n\n.modal-default {\n  --width: 100%;\n  --height: 100%;\n}\n\n.integration-panel {\n  width: 100%;\n  height: 100%;\n  max-width: 100% !important;\n}\n\n.verloop-button {\n  visibility: hidden;\n}\n\n.back-area {\n  position: fixed;\n  top: 0;\n  right: 0;\n  height: 50px;\n  width: 100%;\n  background-color: var(--nc-color-nextgen-neutral-grey-50);\n  z-index: 9999999;\n}\n\n.back-area.ios {\n  height: 80px;\n}\n\n.title-widget {\n  text-align: center;\n  position: sticky;\n  top: 48px;\n}\n\n.button-back {\n  background-color: #fafafa;\n  height: 36px;\n  width: 36px;\n  border-radius: 50%;\n  position: absolute;\n  left: 18px;\n  bottom: 4px;\n}\n\n.icon-close-widget {\n  position: absolute;\n  z-index: 250;\n  left: 11px;\n  bottom: 13px;\n}\n\n.data-default {\n  position: absolute;\n  top: 50%;\n  left: 50%;\n  transform: translate(-50%, -50%);\n  text-align: center;\n  color: var(--nc-color-nextgen-neutral-grey-400);\n  z-index: 1000;\n}\n\n.avaamo__icon {\n  visibility: hidden !important;\n}\n\n.avaamo__chat__widget.ios #avaamo__popup {\n  padding-top: 40px;\n}\n\n.d-flex {\n  display: flex;\n}\n\nnextcare-layout {\n  left: 0;\n  right: 0;\n  top: 0;\n  bottom: 0;\n  display: flex;\n  position: absolute;\n  flex-direction: column;\n  justify-content: space-between;\n  contain: layout size style;\n  overflow: hidden;\n  background-color: var(--nc-color-nextgen-neutral-grey-50);\n  padding-right: 24px;\n  padding-left: 24px;\n}\n\nion-header.ios.header-ios {\n  margin-top: 40px;\n}\n\n.header-ios ion-toolbar:last-of-type {\n  --border-width: 0px !important;\n}\n\n.header-md.md::after {\n  display: none;\n}\n\nion-toolbar {\n  padding-right: unset !important;\n  padding-left: unset !important;\n}\n\ni.icon-back {\n  content: url('long-arrow-left-icon.svg');\n}\n\n.verloop-widget.ios .verloop-container.visible {\n  height: calc(100% - 40px);\n  top: 40px;\n}\n\n#nextcare-ads {\n  display: none;\n  overflow: scroll;\n  height: 180px;\n}\n\n.d-block {\n  display: block;\n}\n\n.title-text {\n  color: var(--nc-color-nextgen-blue);\n}\n\n:host ion-datetime #shadow-root .datetime-calendar .calendar-header .calendar-action-buttons .calendar-month-year {\n  align-items: center;\n  justify-content: center;\n  display: flex;\n  width: 100%;\n}\n\n:host ion-datetime #shadow-root .datetime-calendar .calendar-header .calendar-action-buttons .calendar-month-year ion-icon {\n  display: none;\n}\n\n:host ion-datetime #shadow-root .datetime-calendar .calendar-header .calendar-action-buttons .calendar-next-prev {\n  position: absolute;\n  width: 100%;\n  right: 0;\n}\n\n:host ion-datetime #shadow-root .datetime-calendar .calendar-header .calendar-action-buttons .calendar-next-prev ion-buttons {\n  display: flex;\n  justify-content: space-between;\n  width: 100%;\n}\n\n.mat-dialog-container {\n  padding: unset !important;\n}\n\n/* Change autocomplete styles in WebKit */\n\ninput:-webkit-autofill,\ninput:-webkit-autofill:hover,\ninput:-webkit-autofill:focus,\ntextarea:-webkit-autofill,\ntextarea:-webkit-autofill:hover,\ntextarea:-webkit-autofill:focus,\nselect:-webkit-autofill,\nselect:-webkit-autofill:hover,\nselect:-webkit-autofill:focus {\n  -webkit-text-fill-color: black;\n  -webkit-box-shadow: 0 0 0px 1000px white inset;\n  -webkit-transition: background-color 5000s ease-in-out 0s;\n  transition: background-color 5000s ease-in-out 0s;\n}\n\n.force-update-popup + .cdk-global-overlay-wrapper .save-btn {\n  background: var(--lumi-primary-yellow-color) !important;\n  color: var(--lumi-white-color) !important;\n  font-weight: bold !important;\n}\n\n.force-update-popup + .cdk-global-overlay-wrapper .cancel-btn {\n  color: var(--lumi-primary-yellow-color) !important;\n}\n\n@keyframes slideInRight {\n  0% {\n    transform: translate3d(100%, 0, 0);\n    visibility: visible;\n  }\n  to {\n    transform: translateZ(0);\n  }\n}\n\n.animate__slideInRight {\n  animation-name: slideInRight;\n}\n\n.animate__animated {\n  animation-duration: 0.5s;\n  animation-duration: 0.5s;\n  animation-fill-mode: both;\n}\n\nion-content {\n  --background: #F1EFEF;\n}\n\n.claim-details-main {\n  margin-bottom: 128px;\n}\n\n.claim-details-main .claim-details-content .detail-content {\n  margin-bottom: 1.9rem;\n}\n\n.claim-details-main .claim-details-content .detail-content .detail-title {\n  margin-bottom: 0.2rem;\n}\n\n.claim-details-main .claim-details-content .detail-content button {\n  display: flex;\n  justify-content: space-between;\n  background-color: var(--nc-color-nextgen-white);\n  width: 100%;\n  padding: 18px 8px 18px 15px;\n  border: 1px solid var(--nc-color-nextgen-grey-background);\n  border-radius: 8px;\n}\n\n.claim-details-main .claim-details-content .detail-content button span {\n  color: var(--nc-color-nextgen-blue);\n}\n\n.claim-details-main .claim-details-content .currency-content {\n  display: flex;\n  justify-content: space-between;\n  margin-bottom: 1.9rem;\n}\n\n.claim-details-main .claim-details-content .currency-content .currency {\n  width: 100%;\n}\n\n.claim-details-main .claim-details-content .currency-content .currency .detail-title {\n  margin-bottom: 0.2rem;\n}\n\n.claim-details-main .claim-details-content .currency-content .currency button {\n  display: flex;\n  justify-content: space-between;\n  background-color: var(--nc-color-nextgen-white);\n  width: 100%;\n  padding: 1.1rem 1rem;\n  border: 1px solid var(--nc-color-nextgen-grey-background);\n  border-radius: 8px;\n}\n\n.claim-details-main .claim-details-content .currency-content .currency button span {\n  color: var(--nc-color-nextgen-blue);\n}\n\n.claim-details-main .claim-details-content .currency-content .amount {\n  width: 100%;\n}\n\n.claim-details-main .claim-details-content .currency-content .amount .detail-title {\n  margin-bottom: 0.2rem;\n}\n\n.claim-details-main .claim-details-content .currency-content .amount ion-card {\n  background-color: var(--nc-color-nextgen-white);\n  width: 100%;\n  padding: 1.1rem 1rem;\n  border: 1px solid var(--nc-color-nextgen-grey-background);\n  border-radius: 8px;\n  box-shadow: none;\n}\n\n.claim-details-main .claim-details-content .currency-content .amount ion-card span {\n  color: var(--nc-color-nextgen-blue);\n}\n\n.claim-details-main .claim-details-content .notes-content {\n  padding-bottom: 3.5rem;\n}\n\n.another-placehold {\n  color: var(--nc-color-nextgen-grey) !important;\n}\n\n.space {\n  display: flex;\n  justify-content: center;\n  width: 134px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFxjb2xvci5zY3NzIiwiY2xhaW0tZGV0YWlscy5jb21wb25lbnQuc2NzcyIsIi4uXFwuLlxcLi5cXC4uXFxzdHlsZS5zY3NzIiwiLi5cXC4uXFwuLlxcLi5cXGZvbnQtc2l6ZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0MsdUNBQUE7RUFDQSxnQ0FBQTtFQUNBLGdDQUFBO0VBQ0EsaUNBQUE7RUFDQSxpQ0FBQTtFQUNBLDJDQUFBO0VBQ0EsZ0NBQUE7RUFDQSxzQ0FBQTtFQUNBLGlDQUFBO0VBQ0Esd0NBQUE7RUFDQSx5Q0FBQTtFQUNBLG1DQUFBO0VBQ0EsNENBQUE7RUFDQSw0Q0FBQTtFQUNBLDRDQUFBO0VBQ0Esd0NBQUE7RUFDQSxtREFBQTtFQUNBLDBDQUFBO0VBQ0EscURBQUE7RUFDQSxvQ0FBQTtFQUNBLHlDQUFBO0VBQ0Esb0NBQUE7RUFDQSxvQ0FBQTtFQUNBLG1DQUFBO0VBQ0EsOENBQUE7RUFFQSwyQkFBQTtFQUNBLG9DQUFBO0FDQUQ7O0FEZ0NBO0VBQ0MsK0NBQUE7RUFDQSxtREFBQTtFQUNBLG1EQUFBO0VBQ0EsdURBQUE7RUFDQSxnREFBQTtFQUNBLCtDQUFBO0FDN0JEOztBQ3JDQTs7O0VBQUE7O0FGQUE7RUFDQyx1Q0FBQTtFQUNBLGdDQUFBO0VBQ0EsZ0NBQUE7RUFDQSxpQ0FBQTtFQUNBLGlDQUFBO0VBQ0EsMkNBQUE7RUFDQSxnQ0FBQTtFQUNBLHNDQUFBO0VBQ0EsaUNBQUE7RUFDQSx3Q0FBQTtFQUNBLHlDQUFBO0VBQ0EsbUNBQUE7RUFDQSw0Q0FBQTtFQUNBLDRDQUFBO0VBQ0EsNENBQUE7RUFDQSx3Q0FBQTtFQUNBLG1EQUFBO0VBQ0EsMENBQUE7RUFDQSxxREFBQTtFQUNBLG9DQUFBO0VBQ0EseUNBQUE7RUFDQSxvQ0FBQTtFQUNBLG9DQUFBO0VBQ0EsbUNBQUE7RUFDQSw4Q0FBQTtFQUVBLDJCQUFBO0VBQ0Esb0NBQUE7QUMyQ0Q7O0FEWEE7RUFDQywrQ0FBQTtFQUNBLG1EQUFBO0VBQ0EsbURBQUE7RUFDQSx1REFBQTtFQUNBLGdEQUFBO0VBQ0EsK0NBQUE7QUNjRDs7QUVoRkE7RUFDSSwwQkFBQTtFQUNBLDJCQUFBO0VBQ0EsNEJBQUE7QUZtRko7O0FFaEZBO0VBQ0ksMEJBQUE7RUFDQSwyQkFBQTtFQUNBLDRCQUFBO0FGbUZKOztBRWhGQTtFQUNJLDBCQUFBO0VBQ0EsMkJBQUE7RUFDQSw0QkFBQTtBRm1GSjs7QUVoRkE7RUFDSSwwQkFBQTtFQUNBLDJCQUFBO0VBQ0EsNEJBQUE7QUZtRko7O0FFaEZBO0VBQ0ksMEJBQUE7RUFDQSwyQkFBQTtFQUNBLDRCQUFBO0FGbUZKOztBRWhGQTtFQUNJLDBCQUFBO0VBQ0EsMkJBQUE7RUFDQSw0QkFBQTtBRm1GSjs7QUVoRkE7RUFDSSwwQkFBQTtFQUNBLDJCQUFBO0VBQ0EsNEJBQUE7QUZtRko7O0FFaEZBO0VBQ0ksMEJBQUE7RUFDQSwyQkFBQTtFQUNBLDRCQUFBO0FGbUZKOztBRWhGQTtFQUNJLDBCQUFBO0VBQ0EsMkJBQUE7RUFDQSw0QkFBQTtBRm1GSjs7QUVoRkE7RUFDSSwwQkFBQTtFQUNBLDJCQUFBO0VBQ0EsNEJBQUE7QUZtRko7O0FFaEZBO0VBQ0ksMEJBQUE7RUFDQSwyQkFBQTtFQUNBLDRCQUFBO0FGbUZKOztBRWhGQTtFQUNJLDBCQUFBO0VBQ0EsMkJBQUE7RUFDQSw0QkFBQTtBRm1GSjs7QUUvRUk7RUFDSSwyQkFBQTtBRmtGUjs7QUVoRkk7RUFDSSwyQkFBQTtBRmtGUjs7QUVoRkk7RUFDSSwyQkFBQTtBRmtGUjs7QUVoRkk7RUFDSSwyQkFBQTtBRmtGUjs7QUVoRkk7RUFDSSwyQkFBQTtBRmtGUjs7QUVoRkk7RUFDSSwyQkFBQTtBRmtGUjs7QUVoRkk7RUFDSSwyQkFBQTtBRmtGUjs7QUVoRkk7RUFDSSwyQkFBQTtBRmtGUjs7QUVoRkk7RUFDSSwyQkFBQTtBRmtGUjs7QUVoRkk7RUFDSSwyQkFBQTtBRmtGUjs7QUVoRkk7RUFDSSwyQkFBQTtBRmtGUjs7QUVoRkk7RUFDSSwyQkFBQTtBRmtGUjs7QUU3RUk7RUFDSSwyQkFBQTtBRmdGUjs7QUU5RUk7RUFDSSwyQkFBQTtBRmdGUjs7QUU5RUk7RUFDSSwyQkFBQTtBRmdGUjs7QUU5RUk7RUFDSSwyQkFBQTtBRmdGUjs7QUU5RUk7RUFDSSwyQkFBQTtBRmdGUjs7QUU5RUk7RUFDSSwyQkFBQTtBRmdGUjs7QUU5RUk7RUFDSSwyQkFBQTtBRmdGUjs7QUU5RUk7RUFDSSwyQkFBQTtBRmdGUjs7QUU5RUk7RUFDSSwyQkFBQTtBRmdGUjs7QUU5RUk7RUFDSSwyQkFBQTtBRmdGUjs7QUU5RUk7RUFDSSwyQkFBQTtBRmdGUjs7QUU5RUk7RUFDSSwyQkFBQTtBRmdGUjs7QUN2TkE7RUFDQywwQkFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrQkFBQTtFQUNBLHFHQUFBO0FEME5EOztBQ3BOQTtFQUNDLDBCQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtFQUNBLGtCQUFBO0VBQ0EsaUhBQUE7QURzTkQ7O0FDaE5BO0VBQ0MsMEJBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0Esa0JBQUE7RUFDQSx5R0FBQTtBRGtORDs7QUM1TUE7RUFDQywwQkFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrQkFBQTtFQUNBLHVHQUFBO0FEOE1EOztBQ3hNQTtFQUNDLDBCQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtFQUNBLGtCQUFBO0VBQ0EsMkdBQUE7QUQwTUQ7O0FDcE1BO0VBQ0MsMEJBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0Esa0JBQUE7RUFDQSwrR0FBQTtBRHNNRDs7QUNoTUE7RUFDQywwQkFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrQkFBQTtFQUNBLG1HQUFBO0FEa01EOztBQzVMQTtFQUNDLDBCQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtFQUNBLGtCQUFBO0VBQ0EsK0dBQUE7QUQ4TEQ7O0FDeExBO0VBQ0MsMkNGOUQ0QjtFRStENUIsc0NBQUE7RUFDQSxnQkFBQTtFQUNBLGVBQUE7QUQwTEQ7O0FDdkxBO0VBQ0Msd0JBQUE7QUQwTEQ7O0FDdkxBO0VBQ0MsWUFBQTtBRDBMRDs7QUN2TEE7RUFDQyxhQUFBO0FEMExEOztBQ3ZMQTtFQUNDLFVBQUE7QUQwTEQ7O0FDdkxBO0VBQ0MsYUFBQTtBRDBMRDs7QUN2TEE7RUFDQyxhQUFBO0FEMExEOztBQ3ZMQTtFQUNDLFVBQUE7QUQwTEQ7O0FDdkxBO0VBQ0MsYUFBQTtBRDBMRDs7QUN2TEE7RUFDQyxhQUFBO0FEMExEOztBQ3ZMQTtFQUNDLFVBQUE7QUQwTEQ7O0FDdkxBO0VBQ0MsYUFBQTtBRDBMRDs7QUN2TEE7RUFDQyxhQUFBO0FEMExEOztBQ3ZMQTtFQUNDLFdBQUE7QUQwTEQ7O0FDdkxBO0VBQ0MsaUJBQUE7RUFDQTtJQUNDLFlBQUE7RUQwTEE7O0VDdkxEO0lBQ0MsYUFBQTtFRDBMQTs7RUN2TEQ7SUFDQyxVQUFBO0VEMExBOztFQ3ZMRDtJQUNDLGFBQUE7RUQwTEE7O0VDdkxEO0lBQ0MsYUFBQTtFRDBMQTs7RUN2TEQ7SUFDQyxVQUFBO0VEMExBOztFQ3ZMRDtJQUNDLGFBQUE7RUQwTEE7O0VDdkxEO0lBQ0MsYUFBQTtFRDBMQTs7RUN2TEQ7SUFDQyxVQUFBO0VEMExBOztFQ3ZMRDtJQUNDLGFBQUE7RUQwTEE7O0VDdkxEO0lBQ0MsYUFBQTtFRDBMQTs7RUN2TEQ7SUFDQyxXQUFBO0VEMExBO0FBQ0Y7O0FDdkxBO0VBQ0MsaUJBQUE7RUFDQTtJQUNDLFlBQUE7RUR5TEE7O0VDdExEO0lBQ0MsYUFBQTtFRHlMQTs7RUN0TEQ7SUFDQyxVQUFBO0VEeUxBOztFQ3RMRDtJQUNDLGFBQUE7RUR5TEE7O0VDdExEO0lBQ0MsYUFBQTtFRHlMQTs7RUN0TEQ7SUFDQyxVQUFBO0VEeUxBOztFQ3RMRDtJQUNDLGFBQUE7RUR5TEE7O0VDdExEO0lBQ0MsYUFBQTtFRHlMQTs7RUN0TEQ7SUFDQyxVQUFBO0VEeUxBOztFQ3RMRDtJQUNDLGFBQUE7RUR5TEE7O0VDdExEO0lBQ0MsYUFBQTtFRHlMQTs7RUN0TEQ7SUFDQyxXQUFBO0VEeUxBO0FBQ0Y7O0FDdExBO0VBQ0MsaUJBQUE7RUFDQTtJQUNDLFlBQUE7RUR3TEE7O0VDckxEO0lBQ0MsYUFBQTtFRHdMQTs7RUNyTEQ7SUFDQyxVQUFBO0VEd0xBOztFQ3JMRDtJQUNDLGFBQUE7RUR3TEE7O0VDckxEO0lBQ0MsYUFBQTtFRHdMQTs7RUNyTEQ7SUFDQyxVQUFBO0VEd0xBOztFQ3JMRDtJQUNDLGFBQUE7RUR3TEE7O0VDckxEO0lBQ0MsYUFBQTtFRHdMQTs7RUNyTEQ7SUFDQyxVQUFBO0VEd0xBOztFQ3JMRDtJQUNDLGFBQUE7RUR3TEE7O0VDckxEO0lBQ0MsYUFBQTtFRHdMQTs7RUNyTEQ7SUFDQyxXQUFBO0VEd0xBO0FBQ0Y7O0FDckxBO0VBQ0MsYUFBQTtFQUNBLHVCQUFBO0VBQ0EsbUJBQUE7QUR1TEQ7O0FDbkxBO0VBQ0Msd0JBQUE7QURzTEQ7O0FDbkxBOzs7RUFBQTs7QUFJQTs7RUFFQyxhQUFBO0FEc0xEOztBQ25MQTtFQUNDLGdCQUFBO0FEc0xEOztBQ25MQTs7O0VBQUE7O0FBSUE7RUFDQyx5QkFBQTtFQUNBLHdCQUFBO0FEc0xEOztBQ25MQTtFQUNDLGlCQUFBO0VBQ0EseUJBQUE7QURzTEQ7O0FDbkxBO0VBQ0MsbUNGM1RvQjtBQ2lmckI7O0FDbkxBO0VBQ0MsWUFBQTtFQUNBLG1CQUFBO0VBQ0EsMEJBQUE7RUFDQSxnQkFBQTtBRHNMRDs7QUNwTEM7RUFDQywrREFBQTtFQUNBLG9DRnhVb0I7RUV5VXBCLHlCQUFBO0VBQ0EsdUJBQUE7RUFDQSxzQkFBQTtFQUNBLDZCQUFBO0FEc0xGOztBQ3BMRTtFQUNDLG9DRi9VbUI7QUNxZ0J0Qjs7QUNsTEM7RUFDQyx5Q0Z0Vm9CO0VFdVZwQixvQ0Z0Vm9CO0FDMGdCdEI7O0FDbExFO0VBQ0Msb0NGelZtQjtBQzZnQnRCOztBQ2pMRTtFQUNDLG9FQUFBO0VBQ0EsOENBQUE7QURtTEg7O0FDL0tDO0VBQ0Msb0RBQUE7RUFDQSwyQ0ZyV29CO0VFc1dwQixpQkFBQTtFQUNBLG9DRnZXb0I7QUN3aEJ0Qjs7QUMvS0U7RUFDQyxvQ0YxV21CO0FDMmhCdEI7O0FDOUtFO0VBQ0MsMERBQUE7RUFDQSw4Q0FBQTtFQUNBLGdFQUFBO0FEZ0xIOztBQzVLQztFQUNDLGtDQUFBO0VBQ0EsMkNGdFhvQjtFRXVYcEIsaUJBQUE7RUFDQSxvQ0Z4WG9CO0FDc2lCdEI7O0FDNUtFO0VBQ0Msb0NGM1htQjtBQ3lpQnRCOztBQzNLRTtFQUNDLHdDQUFBO0VBQ0EsOENBQUE7RUFDQSxnRUFBQTtBRDZLSDs7QUN6S0M7RUFDQyx1QkFBQTtFQUNBLFdBQUE7QUQyS0Y7O0FDeEtDO0VBQ0MsMkJBQUE7QUQwS0Y7O0FDdktDO0VBQ0MsMkJBQUE7QUR5S0Y7O0FDcktBO0VBQ0MsdUJBQUE7RUFDQSx3QkFBQTtFQUFBLG1CQUFBO0FEd0tEOztBQ3JLQTtFQUNDLFdBQUE7RUFDQSxZQUFBO0VBQ0EsNkJBQUE7RUFDQSxVQUFBO0VBQ0Esb0NGN1pxQjtBQ3FrQnRCOztBQ3JLQTtFQUNDLGFBQUE7RUFDQSxZQUFBO0FEd0tEOztBQ3JLQTtFQUNDLFdBQUE7RUFDQSxXQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrQkFBQTtBRHdLRDs7QUNyS0E7RUFDQyxXQUFBO0VBQ0EsV0FBQTtFQUNBLDhCQUFBO0VBQ0EsYUFBQTtFQUNBLG1CQUFBO0FEd0tEOztBQ3JLQTtFQUNDLGtCQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0FEd0tEOztBQ3JLQTtFQUNDLGtCQUFBO0VBQ0EsWUFBQTtFQUNBLHlEQUFBO0VBQ0EsV0FBQTtFQUNBLGtCQUFBO0VBQ0EsU0FBQTtFQUNBLCtDRmhjcUI7QUN3bUJ0Qjs7QUN0S0M7RUFDQyxtQkFBQTtFQUNBLHNCQUFBO0FEd0tGOztBQ3JLQztFQUNDLFlBQUE7RUFDQSxhQUFBO0VBQ0Esa0JBQUE7RUFDQSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxvQkFBQTtFQUNBLCtDRjljb0I7QUNxbkJ0Qjs7QUNwS0M7RUFDQyxhQUFBO0FEc0tGOztBQ25LQztFQUNDLGFBQUE7RUFDQSxhQUFBO0VBQ0Esa0JBQUE7RUFDQSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxvQkFBQTtFQUNBLFlBQUE7RUFDQSwrQ0Y3ZG9CO0FDa29CdEI7O0FDbEtDO0VBQ0MsYUFBQTtBRG9LRjs7QUNqS0M7RUFDQywyQ0Z0ZW9CO0FDeW9CdEI7O0FDaktFO0VBQ0MsYUFBQTtBRG1LSDs7QUNoS0U7RUFDQyxtQkFBQTtBRGtLSDs7QUM5SkM7RUFDQyxXQUFBO0VBQ0Esa0JBQUE7RUFDQSxpQkFBQTtBRGdLRjs7QUM5SkU7RUFDQywwQkFBQTtBRGdLSDs7QUM1SkM7RUFDQyxXQUFBO0VBQ0Esa0JBQUE7QUQ4SkY7O0FDM0pFO0VBQ0MsMEJBQUE7QUQ2Skg7O0FDeEpBO0VBQ0Msb0NGdmdCcUI7QUNrcUJ0Qjs7QUN2SkM7RUFDQywyQ0Z0Z0JvQjtBQ2dxQnRCOztBQ3ZKQztFQUNDLCtDQUFBO0FEeUpGOztBQ3BKQztFQUNDLCtDQUFBO0VBQ0EsZ0JBQUE7QUR1SkY7O0FDckpFO0VBQ0MsK0NBQUE7QUR1Skg7O0FDbEpBO0VBQ0Msb0JBQUE7QURxSkQ7O0FDbEpBO0VBQ0MscUJBQUE7QURxSkQ7O0FDbEpBO0VBQ0Msa0JBQUE7RUFDQSxvQkFBQTtFQUNBLHNCQUFBO0VBQ0EsYUFBQTtFQUNBLGNBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7QURxSkQ7O0FDbEpBO0VBQ0Msc0RGM2lCNEI7RUU0aUI1Qix1QkFBQTtBRHFKRDs7QUNsSkE7RUFDQyw2QkFBQTtFQUNBLCtDRnZqQnFCO0FDNHNCdEI7O0FDbEpBO0VBQ0M7SUFDQywyQkFBQTtFRHFKQTtFQ2xKRDtJQUNDLHlCQUFBO0VEb0pBO0FBQ0Y7O0FDakpBO0VBQ0Msb0NGaGtCcUI7QUNtdEJ0Qjs7QUNqSkM7RUFDQywrQ0Zua0JvQjtBQ3N0QnRCOztBQy9JQTtFQUNDLDRDRnRrQjZCO0FDd3RCOUI7O0FDaEpDO0VBQ0MsdURGemtCNEI7QUMydEI5Qjs7QUM5SUE7RUFDQyxzQ0Y3a0J1QjtBQzh0QnhCOztBQy9JQztFQUNDLGlERmhsQnNCO0FDaXVCeEI7O0FDN0lBO0VBQ0MsV0FBQTtFQUNBLFlBQUE7RUFDQSxhQUFBO0VBQ0Esa0JBQUE7RUFDQSxhQUFBO0VBQ0Esd0JBQUE7VUFBQSxnQkFBQTtFQUNBLDZCQUFBO0FEZ0pEOztBQzlJQztFQUNDLGNBQUE7QURnSkY7O0FDNUlBO0VBQ0Msb0NGMW1CcUI7QUN5dkJ0Qjs7QUM1SUE7RUFDQyxhQUFBO0VBQ0EsY0FBQTtBRCtJRDs7QUM1SUE7RUFDQyxXQUFBO0VBQ0EsWUFBQTtFQUNBLDBCQUFBO0FEK0lEOztBQzVJQTtFQUNDLGtCQUFBO0FEK0lEOztBQzVJQTtFQUNDLGVBQUE7RUFDQSxNQUFBO0VBQ0EsUUFBQTtFQUNBLFlBQUE7RUFDQSxXQUFBO0VBQ0EseURGem5CK0I7RUUwbkIvQixnQkFBQTtBRCtJRDs7QUM3SUM7RUFDQyxZQUFBO0FEK0lGOztBQzNJQTtFQUNDLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxTQUFBO0FEOElEOztBQzNJQTtFQUNDLHlCQUFBO0VBQ0EsWUFBQTtFQUNBLFdBQUE7RUFDQSxrQkFBQTtFQUNBLGtCQUFBO0VBQ0EsVUFBQTtFQUNBLFdBQUE7QUQ4SUQ7O0FDM0lBO0VBQ0Msa0JBQUE7RUFDQSxZQUFBO0VBQ0EsVUFBQTtFQUNBLFlBQUE7QUQ4SUQ7O0FDM0lBO0VBQ0Msa0JBQUE7RUFDQSxRQUFBO0VBQ0EsU0FBQTtFQUNBLGdDQUFBO0VBQ0Esa0JBQUE7RUFDQSwrQ0Y3cEJnQztFRThwQmhDLGFBQUE7QUQ4SUQ7O0FDM0lBO0VBQ0MsNkJBQUE7QUQ4SUQ7O0FDMUlDO0VBQ0MsaUJBQUE7QUQ2SUY7O0FDeklBO0VBQ0MsYUFBQTtBRDRJRDs7QUN6SUE7RUFDQyxPQUFBO0VBQ0EsUUFBQTtFQUNBLE1BQUE7RUFDQSxTQUFBO0VBQ0EsYUFBQTtFQUNBLGtCQUFBO0VBQ0Esc0JBQUE7RUFDQSw4QkFBQTtFQUNBLDBCQUFBO0VBQ0EsZ0JBQUE7RUFDQSx5REYzckIrQjtFRTRyQi9CLG1CQUFBO0VBQ0Esa0JBQUE7QUQ0SUQ7O0FDeklBO0VBQ0MsZ0JBQUE7QUQ0SUQ7O0FDeklBO0VBQ0MsOEJBQUE7QUQ0SUQ7O0FDeklBO0VBQ0MsYUFBQTtBRDRJRDs7QUN6SUE7RUFDQywrQkFBQTtFQUNBLDhCQUFBO0FENElEOztBQ3pJQTtFQUNDLHdDQUFBO0FENElEOztBQ3hJQztFQUNDLHlCQUFBO0VBQ0EsU0FBQTtBRDJJRjs7QUN2SUE7RUFDQyxhQUFBO0VBQ0EsZ0JBQUE7RUFDQSxhQUFBO0FEMElEOztBQ3ZJQTtFQUNDLGNBQUE7QUQwSUQ7O0FDdklBO0VBQ0MsbUNGbnZCb0I7QUM2M0JyQjs7QUNuSUk7RUFDQyxtQkFBQTtFQUNBLHVCQUFBO0VBQ0EsYUFBQTtFQUNBLFdBQUE7QURzSUw7O0FDcElLO0VBQ0MsYUFBQTtBRHNJTjs7QUNsSUk7RUFDQyxrQkFBQTtFQUNBLFdBQUE7RUFDQSxRQUFBO0FEb0lMOztBQ2xJSztFQUNDLGFBQUE7RUFDQSw4QkFBQTtFQUNBLFdBQUE7QURvSU47O0FDNUhBO0VBQ0MseUJBQUE7QUQrSEQ7O0FDNUhBLHlDQUFBOztBQUNBOzs7Ozs7Ozs7RUFTQyw4QkFBQTtFQUNBLDhDQUFBO0VBQ0EseURBQUE7RUFBQSxpREFBQTtBRCtIRDs7QUMzSEM7RUFDQyx1REFBQTtFQUNBLHlDQUFBO0VBQ0EsNEJBQUE7QUQ4SEY7O0FDM0hDO0VBQ0Msa0RBQUE7QUQ2SEY7O0FDNUdBO0VBQ0M7SUFFQyxrQ0FBQTtJQUNBLG1CQUFBO0VEMEhBO0VDdkhEO0lBRUMsd0JBQUE7RUR5SEE7QUFDRjs7QUN0SEE7RUFFQyw0QkFBQTtBRHdIRDs7QUNySEE7RUFFQyx3QkFBQTtFQUVBLHdCQUFBO0VBRUEseUJBQUE7QUR3SEQ7O0FBNStCQTtFQUNJLHFCQUFBO0FBKytCSjs7QUE1K0JBO0VBQ0ksb0JBQUE7QUErK0JKOztBQTMrQlE7RUFDSSxxQkFBQTtBQTYrQlo7O0FBMytCWTtFQUNJLHFCQUFBO0FBNitCaEI7O0FBMStCWTtFQUNJLGFBQUE7RUFDQSw4QkFBQTtFQUNBLCtDRFVNO0VDVE4sV0FBQTtFQUNBLDJCQUFBO0VBQ0EseURBQUE7RUFDQSxrQkFBQTtBQTQrQmhCOztBQTErQmdCO0VBQ0ksbUNEQ0M7QUMyK0JyQjs7QUFyK0JRO0VBQ0ksYUFBQTtFQUNBLDhCQUFBO0VBQ0EscUJBQUE7QUF1K0JaOztBQXQrQlk7RUFFSSxXQUFBO0FBdStCaEI7O0FBcitCZ0I7RUFDSSxxQkFBQTtBQXUrQnBCOztBQXArQmdCO0VBQ0ksYUFBQTtFQUNBLDhCQUFBO0VBQ0EsK0NEbkJFO0VDb0JGLFdBQUE7RUFDQSxvQkFBQTtFQUNBLHlEQUFBO0VBQ0Esa0JBQUE7QUFzK0JwQjs7QUFwK0JvQjtFQUNJLG1DRDVCSDtBQ2tnQ3JCOztBQWgrQlk7RUFDSSxXQUFBO0FBaytCaEI7O0FBaCtCZ0I7RUFDSSxxQkFBQTtBQWsrQnBCOztBQS85QmdCO0VBQ0ksK0NEeENFO0VDeUNGLFdBQUE7RUFDQSxvQkFBQTtFQUNBLHlEQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtBQWkrQnBCOztBQS85Qm9CO0VBQ0ksbUNEbERIO0FDbWhDckI7O0FBNTlCUTtFQUNJLHNCQUFBO0FBODlCWjs7QUF6OUJBO0VBQ0ksOENBQUE7QUE0OUJKOztBQTE5QkE7RUFDSSxhQUFBO0VBQ0EsdUJBQUE7RUFDQSxZQUFBO0FBNjlCSiIsImZpbGUiOiJjbGFpbS1kZXRhaWxzLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiOnJvb3Qge1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNTA6IHJlZDtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4td2hpdGU6IHllbGxvdztcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZTogIzBkMTUyZTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW46ICMwMDkwOGQ7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWJsYWNrOiAjMDAwMDAwO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ncmV5LWJhY2tncm91bmQ6ICNjOGQzZGE7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWdyZXk6ICM5MmEyYWM7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0b25lLWdyZXk6ICNmYWZhZmE7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWVycm9yOiAjZmMxMDU1O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXk6ICM0MTQxNDE7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWZpYnJhbnQtZ3JlZW46ICMwMGJhYjY7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXdhcm5pbmc6ICNmZmQwNDg7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuLWJhY2tncm91bmQ6ICNlNmYyZjI7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS00MDA6ICM3YTdhN2E7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS0xMDA6ICNlZmYzZjU7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy1lcnJvcjogI2JhMGMzZjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yLWJhY2tncm91bmQ6ICNmZmVmZjQ7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy13YXJuaW5nOiAjY2JhMTI3O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtd2FybmluZy1iYWNrZ3JvdW5kOiAjZmZmOGU2O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlLTEwMDogI2RmZWZmMjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tZXJyb3ItcmVkLTcwMDogI2Y2MjQ1OTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZS01MDA6ICMwMDYxOTI7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWJsdWUtNDAwOiAjNzljZGVjO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1yZWQtNTAwOiAjZmY2NTkyO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zZWNvbmRhcnktYmx1ZS0zMDA6ICMxM2EwZDM7XHJcblxyXG5cdC0tbHVtaS13aGl0ZS1jb2xvcjogI2ZmZmZmZjtcclxuXHQtLWx1bWktcHJpbWFyeS15ZWxsb3ctY29sb3I6ICNmYWI2MDA7XHJcbn1cclxuJGNvbG9yLW5leHRnZW4tYmx1ZTogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlKTtcclxuJGNvbG9yLW5leHRnZW4tZ3JlZW46IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4pO1xyXG4kY29sb3ItbmV4dGdlbi13aGl0ZTogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi13aGl0ZSk7XHJcbiRjb2xvci1uZXh0Z2VuLWJsYWNrOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWJsYWNrKTtcclxuJGNvbG9yLW5leHRnZW4tZ3JleS1iYWNrZ3JvdW5kOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZXktYmFja2dyb3VuZCk7XHJcbiRjb2xvci1uZXh0Z2VuLWdyZXk6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JleSk7XHJcbiRjb2xvci1uZXh0Z2VuLXN0b25lLWdyZXk6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tc3RvbmUtZ3JleSk7XHJcbiRjb2xvci1uZXh0Z2VuLWVycm9yOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWVycm9yKTtcclxuJGNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5OiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleSk7XHJcbiRjb2xvci1uZXh0Z2VuLWZpYnJhbnQtZ3JlZW46IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZmlicmFudC1ncmVlbik7XHJcbiRjb2xvci1uZXh0Z2VuLXdhcm5pbmc6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4td2FybmluZyk7XHJcbiRjb2xvci1uZXh0Z2VuLWdyZWVuLWJhY2tncm91bmQ6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4tYmFja2dyb3VuZCk7XHJcbiRjb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS01MDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNTApO1xyXG4kY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNDAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS00MDApO1xyXG4kY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktMTAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS0xMDApO1xyXG4kY29sb3ItbmV4dGdlbi1zdGF0dXMtZXJyb3I6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yKTtcclxuJGNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yLWJhY2tncm91bmQ6IHZhcihcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yLWJhY2tncm91bmRcclxuKTtcclxuJGNvbG9yLW5leHRnZW4tc3RhdHVzLXdhcm5pbmc6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLXdhcm5pbmcpO1xyXG4kY29sb3ItbmV4dGdlbi1zdGF0dXMtd2FybmluZy1iYWNrZ3JvdW5kOiB2YXIoXHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy13YXJuaW5nLWJhY2tncm91bmRcclxuKTtcclxuJGNvbG9yLW5leHRnZW4tYmx1ZS0xMDA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZS0xMDApO1xyXG4kY29sb3ItbmV4dGdlbi1lcnJvci1yZWQtNzAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWVycm9yLXJlZC03MDApO1xyXG4kY29sb3ItbmV4dGdlbi1ibHVlLTUwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlLTUwMCk7XHJcbiRjb2xvci1uZXh0Z2VuLWJsdWUtNDAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWJsdWUtNDAwKTtcclxuJGNvbG9yLW5leHRnZW4tcmVkLTUwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1yZWQtNTAwKTtcclxuJGNvbG9yLW5leHRnZW4tc2Vjb25kYXJ5LWJsdWUtMzAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXNlY29uZGFyeS1ibHVlLTMwMCk7XHJcblxyXG4uaW9uLWNvbG9yLWdyZWVuIHtcclxuXHQtLWlvbi1jb2xvci1iYXNlOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuKTtcclxuXHQtLWlvbi1jb2xvci1iYXNlLXJnYjogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbik7XHJcblx0LS1pb24tY29sb3ItY29udHJhc3Q6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4td2hpdGUpO1xyXG5cdC0taW9uLWNvbG9yLWNvbnRyYXN0LXJnYjogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbik7XHJcblx0LS1pb24tY29sb3Itc2hhZGU6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4pO1xyXG5cdC0taW9uLWNvbG9yLXRpbnQ6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4pO1xyXG59XHJcbiIsIkBpbXBvcnQgXCIuLi8uLi8uLi8uLi9jb2xvci5zY3NzXCI7XHJcbkBpbXBvcnQgXCIuLi8uLi8uLi8uLi9zdHlsZS5zY3NzXCI7XHJcblxyXG5pb24tY29udGVudCB7XHJcbiAgICAtLWJhY2tncm91bmQ6ICNGMUVGRUY7XHJcbn1cclxuXHJcbi5jbGFpbS1kZXRhaWxzLW1haW4ge1xyXG4gICAgbWFyZ2luLWJvdHRvbTogMTI4cHg7XHJcbiAgICAuY2xhaW0tZGV0YWlscy10aXRsZSB7fVxyXG5cclxuICAgIC5jbGFpbS1kZXRhaWxzLWNvbnRlbnQge1xyXG4gICAgICAgIC5kZXRhaWwtY29udGVudCB7XHJcbiAgICAgICAgICAgIG1hcmdpbi1ib3R0b206IDEuOXJlbTtcclxuXHJcbiAgICAgICAgICAgIC5kZXRhaWwtdGl0bGUge1xyXG4gICAgICAgICAgICAgICAgbWFyZ2luLWJvdHRvbTogMC4ycmVtO1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICBidXR0b24ge1xyXG4gICAgICAgICAgICAgICAgZGlzcGxheTogZmxleDtcclxuICAgICAgICAgICAgICAgIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcclxuICAgICAgICAgICAgICAgIGJhY2tncm91bmQtY29sb3I6ICRjb2xvci1uZXh0Z2VuLXdoaXRlIDtcclxuICAgICAgICAgICAgICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgICAgICAgICAgICAgcGFkZGluZzogMThweCA4cHggMThweCAxNXB4O1xyXG4gICAgICAgICAgICAgICAgYm9yZGVyOiAxcHggc29saWQgJGNvbG9yLW5leHRnZW4tZ3JleS1iYWNrZ3JvdW5kO1xyXG4gICAgICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogOHB4O1xyXG5cclxuICAgICAgICAgICAgICAgIHNwYW4ge1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbG9yOiAkY29sb3ItbmV4dGdlbi1ibHVlIDtcclxuICAgICAgICAgICAgICAgIH1cclxuXHJcblxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAuY3VycmVuY3ktY29udGVudCB7XHJcbiAgICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICAgICAgICAgIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcclxuICAgICAgICAgICAgbWFyZ2luLWJvdHRvbTogMS45cmVtO1xyXG4gICAgICAgICAgICAuY3VycmVuY3kge1xyXG4gICAgICAgICAgICAgICAgLy8gbWFyZ2luLXJpZ2h0OiAxNHZ3O1xyXG4gICAgICAgICAgICAgICAgd2lkdGg6IDEwMCU7XHJcblxyXG4gICAgICAgICAgICAgICAgLmRldGFpbC10aXRsZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgbWFyZ2luLWJvdHRvbTogMC4ycmVtO1xyXG4gICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgIGJ1dHRvbiB7XHJcbiAgICAgICAgICAgICAgICAgICAgZGlzcGxheTogZmxleDtcclxuICAgICAgICAgICAgICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XHJcbiAgICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogJGNvbG9yLW5leHRnZW4td2hpdGUgO1xyXG4gICAgICAgICAgICAgICAgICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgICAgICAgICAgICAgICAgIHBhZGRpbmc6IDEuMXJlbSAxcmVtO1xyXG4gICAgICAgICAgICAgICAgICAgIGJvcmRlcjogMXB4IHNvbGlkICRjb2xvci1uZXh0Z2VuLWdyZXktYmFja2dyb3VuZDtcclxuICAgICAgICAgICAgICAgICAgICBib3JkZXItcmFkaXVzOiA4cHg7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHNwYW4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb2xvcjogJGNvbG9yLW5leHRnZW4tYmx1ZSA7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgLmFtb3VudCB7XHJcbiAgICAgICAgICAgICAgICB3aWR0aDogMTAwJTtcclxuXHJcbiAgICAgICAgICAgICAgICAuZGV0YWlsLXRpdGxlIHtcclxuICAgICAgICAgICAgICAgICAgICBtYXJnaW4tYm90dG9tOiAwLjJyZW07XHJcbiAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgaW9uLWNhcmQge1xyXG4gICAgICAgICAgICAgICAgICAgIGJhY2tncm91bmQtY29sb3I6ICRjb2xvci1uZXh0Z2VuLXdoaXRlIDtcclxuICAgICAgICAgICAgICAgICAgICB3aWR0aDogMTAwJTtcclxuICAgICAgICAgICAgICAgICAgICBwYWRkaW5nOiAxLjFyZW0gMXJlbTtcclxuICAgICAgICAgICAgICAgICAgICBib3JkZXI6IDFweCBzb2xpZCAkY29sb3ItbmV4dGdlbi1ncmV5LWJhY2tncm91bmQ7XHJcbiAgICAgICAgICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogOHB4O1xyXG4gICAgICAgICAgICAgICAgICAgIGJveC1zaGFkb3c6IG5vbmU7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHNwYW4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb2xvcjogJGNvbG9yLW5leHRnZW4tYmx1ZSA7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC5ub3Rlcy1jb250ZW50e1xyXG4gICAgICAgICAgICBwYWRkaW5nLWJvdHRvbTogMy41cmVtO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG5cclxuLmFub3RoZXItcGxhY2Vob2xkIHtcclxuICAgIGNvbG9yOiAkY29sb3ItbmV4dGdlbi1ncmV5ICAhaW1wb3J0YW50O1xyXG59XHJcbi5zcGFjZXtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgIHdpZHRoOiAxMzRweDtcclxufSIsIi8qXHJcbiAqIDEuIEN1c3RvbSBDU1MgXHJcbiAqIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuICovXHJcblxyXG4vLyBjb2xvciB2YXJpYWJsZVxyXG5AaW1wb3J0IFwiLi9jb2xvci5zY3NzXCI7XHJcbi8vIHR5cG9ncmFwaHlcclxuQGltcG9ydCBcIi4vZm9udC1zaXplLnNjc3NcIjtcclxuXHJcbi8vIEZvbnRzXHJcbkBmb250LWZhY2Uge1xyXG5cdGZvbnQtZmFtaWx5OiBcIkFsbGlhbnogTmVvXCI7XHJcblx0Zm9udC1zdHlsZTogbm9ybWFsO1xyXG5cdGZvbnQtd2VpZ2h0OiAzMDA7XHJcblx0Zm9udC1kaXNwbGF5OiBzd2FwO1xyXG5cdHNyYzogdXJsKFwiLi9hc3NldHMvZm9udHMvQWxsaWFuek5lby9BbGxpYW56X05lb193ZWJmb250cy93b2ZmMi9BbGxpYW56TmVvVzA0LUxpZ2h0LndvZmYyXCIpXHJcblx0XHRcdGZvcm1hdChcIndvZmYyXCIpLFxyXG5cdFx0dXJsKFwiLi9hc3NldHMvZm9udHMvQWxsaWFuek5lby9BbGxpYW56X05lb193ZWJmb250cy93b2ZmL0FsbGlhbnpOZW9XMDQtTGlnaHQud29mZlwiKVxyXG5cdFx0XHRmb3JtYXQoXCJ3b2ZmXCIpO1xyXG59XHJcblxyXG5AZm9udC1mYWNlIHtcclxuXHRmb250LWZhbWlseTogXCJBbGxpYW56IE5lb1wiO1xyXG5cdGZvbnQtc3R5bGU6IGl0YWxpYztcclxuXHRmb250LXdlaWdodDogMzAwO1xyXG5cdGZvbnQtZGlzcGxheTogc3dhcDtcclxuXHRzcmM6IHVybChcIi4vYXNzZXRzL2ZvbnRzL0FsbGlhbnpOZW8vQWxsaWFuel9OZW9fd2ViZm9udHMvd29mZjIvQWxsaWFuek5lb1cwNC1MaWdodEl0YWxpYy53b2ZmMlwiKVxyXG5cdFx0XHRmb3JtYXQoXCJ3b2ZmMlwiKSxcclxuXHRcdHVybChcIi4vYXNzZXRzL2ZvbnRzL0FsbGlhbnpOZW8vQWxsaWFuel9OZW9fd2ViZm9udHMvd29mZi9BbGxpYW56TmVvVzA0LUxpZ2h0SXRhbGljLndvZmZcIilcclxuXHRcdFx0Zm9ybWF0KFwid29mZlwiKTtcclxufVxyXG5cclxuQGZvbnQtZmFjZSB7XHJcblx0Zm9udC1mYW1pbHk6IFwiQWxsaWFueiBOZW9cIjtcclxuXHRmb250LXN0eWxlOiBub3JtYWw7XHJcblx0Zm9udC13ZWlnaHQ6IDQwMDtcclxuXHRmb250LWRpc3BsYXk6IHN3YXA7XHJcblx0c3JjOiB1cmwoXCIuL2Fzc2V0cy9mb250cy9BbGxpYW56TmVvL0FsbGlhbnpfTmVvX3dlYmZvbnRzL3dvZmYyL0FsbGlhbnpOZW9XMDQtUmVndWxhci53b2ZmMlwiKVxyXG5cdFx0XHRmb3JtYXQoXCJ3b2ZmMlwiKSxcclxuXHRcdHVybChcIi4vYXNzZXRzL2ZvbnRzL0FsbGlhbnpOZW8vQWxsaWFuel9OZW9fd2ViZm9udHMvd29mZi9BbGxpYW56TmVvVzA0LVJlZ3VsYXIud29mZlwiKVxyXG5cdFx0XHRmb3JtYXQoXCJ3b2ZmXCIpO1xyXG59XHJcblxyXG5AZm9udC1mYWNlIHtcclxuXHRmb250LWZhbWlseTogXCJBbGxpYW56IE5lb1wiO1xyXG5cdGZvbnQtc3R5bGU6IGl0YWxpYztcclxuXHRmb250LXdlaWdodDogNDAwO1xyXG5cdGZvbnQtZGlzcGxheTogc3dhcDtcclxuXHRzcmM6IHVybChcIi4vYXNzZXRzL2ZvbnRzL0FsbGlhbnpOZW8vQWxsaWFuel9OZW9fd2ViZm9udHMvd29mZjIvQWxsaWFuek5lb1cwNC1JdGFsaWMud29mZjJcIilcclxuXHRcdFx0Zm9ybWF0KFwid29mZjJcIiksXHJcblx0XHR1cmwoXCIuL2Fzc2V0cy9mb250cy9BbGxpYW56TmVvL0FsbGlhbnpfTmVvX3dlYmZvbnRzL3dvZmYvQWxsaWFuek5lb1cwNC1JdGFsaWMud29mZlwiKVxyXG5cdFx0XHRmb3JtYXQoXCJ3b2ZmXCIpO1xyXG59XHJcblxyXG5AZm9udC1mYWNlIHtcclxuXHRmb250LWZhbWlseTogXCJBbGxpYW56IE5lb1wiO1xyXG5cdGZvbnQtc3R5bGU6IG5vcm1hbDtcclxuXHRmb250LXdlaWdodDogNjAwO1xyXG5cdGZvbnQtZGlzcGxheTogc3dhcDtcclxuXHRzcmM6IHVybChcIi4vYXNzZXRzL2ZvbnRzL0FsbGlhbnpOZW8vQWxsaWFuel9OZW9fd2ViZm9udHMvd29mZjIvQWxsaWFuek5lb1cwNC1TZW1pQm9sZC53b2ZmMlwiKVxyXG5cdFx0XHRmb3JtYXQoXCJ3b2ZmMlwiKSxcclxuXHRcdHVybChcIi4vYXNzZXRzL2ZvbnRzL0FsbGlhbnpOZW8vQWxsaWFuel9OZW9fd2ViZm9udHMvd29mZi9BbGxpYW56TmVvVzA0LVNlbWlCb2xkLndvZmZcIilcclxuXHRcdFx0Zm9ybWF0KFwid29mZlwiKTtcclxufVxyXG5cclxuQGZvbnQtZmFjZSB7XHJcblx0Zm9udC1mYW1pbHk6IFwiQWxsaWFueiBOZW9cIjtcclxuXHRmb250LXN0eWxlOiBpdGFsaWM7XHJcblx0Zm9udC13ZWlnaHQ6IDYwMDtcclxuXHRmb250LWRpc3BsYXk6IHN3YXA7XHJcblx0c3JjOiB1cmwoXCIuL2Fzc2V0cy9mb250cy9BbGxpYW56TmVvL0FsbGlhbnpfTmVvX3dlYmZvbnRzL3dvZmYyL0FsbGlhbnpOZW9XMDQtU2VtaUJvbGRJdC53b2ZmMlwiKVxyXG5cdFx0XHRmb3JtYXQoXCJ3b2ZmMlwiKSxcclxuXHRcdHVybChcIi4vYXNzZXRzL2ZvbnRzL0FsbGlhbnpOZW8vQWxsaWFuel9OZW9fd2ViZm9udHMvd29mZi9BbGxpYW56TmVvVzA0LVNlbWlCb2xkSXQud29mZlwiKVxyXG5cdFx0XHRmb3JtYXQoXCJ3b2ZmXCIpO1xyXG59XHJcblxyXG5AZm9udC1mYWNlIHtcclxuXHRmb250LWZhbWlseTogXCJBbGxpYW56IE5lb1wiO1xyXG5cdGZvbnQtc3R5bGU6IG5vcm1hbDtcclxuXHRmb250LXdlaWdodDogNzAwO1xyXG5cdGZvbnQtZGlzcGxheTogc3dhcDtcclxuXHRzcmM6IHVybChcIi4vYXNzZXRzL2ZvbnRzL0FsbGlhbnpOZW8vQWxsaWFuel9OZW9fd2ViZm9udHMvd29mZjIvQWxsaWFuek5lb1cwNC1Cb2xkLndvZmYyXCIpXHJcblx0XHRcdGZvcm1hdChcIndvZmYyXCIpLFxyXG5cdFx0dXJsKFwiLi9hc3NldHMvZm9udHMvQWxsaWFuek5lby9BbGxpYW56X05lb193ZWJmb250cy93b2ZmL0FsbGlhbnpOZW9XMDQtQm9sZC53b2ZmXCIpXHJcblx0XHRcdGZvcm1hdChcIndvZmZcIik7XHJcbn1cclxuXHJcbkBmb250LWZhY2Uge1xyXG5cdGZvbnQtZmFtaWx5OiBcIkFsbGlhbnogTmVvXCI7XHJcblx0Zm9udC1zdHlsZTogaXRhbGljO1xyXG5cdGZvbnQtd2VpZ2h0OiA3MDA7XHJcblx0Zm9udC1kaXNwbGF5OiBzd2FwO1xyXG5cdHNyYzogdXJsKFwiLi9hc3NldHMvZm9udHMvQWxsaWFuek5lby9BbGxpYW56X05lb193ZWJmb250cy93b2ZmMi9BbGxpYW56TmVvVzA0LUJvbGRJdGFsaWMud29mZjJcIilcclxuXHRcdFx0Zm9ybWF0KFwid29mZjJcIiksXHJcblx0XHR1cmwoXCIuL2Fzc2V0cy9mb250cy9BbGxpYW56TmVvL0FsbGlhbnpfTmVvX3dlYmZvbnRzL3dvZmYvQWxsaWFuek5lb1cwNC1Cb2xkSXRhbGljLndvZmZcIilcclxuXHRcdFx0Zm9ybWF0KFwid29mZlwiKTtcclxufVxyXG5cclxuKiB7XHJcblx0Y29sb3I6ICRjb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleTtcclxuXHRmb250LWZhbWlseTogXCJBbGxpYW56IE5lb1wiLCBzYW5zLXNlcmlmO1xyXG5cdGZvbnQtd2VpZ2h0OiA0MDA7XHJcblx0Zm9udC1zaXplOiAxNnB4O1xyXG59XHJcblxyXG5odG1sIHtcclxuXHQtLWlvbi1zYWZlLWFyZWEtdG9wOiAwcHg7XHJcbn1cclxuXHJcbi5jb2wtMSB7XHJcblx0d2lkdGg6IDguMzMlO1xyXG59XHJcblxyXG4uY29sLTIge1xyXG5cdHdpZHRoOiAxNi42NiU7XHJcbn1cclxuXHJcbi5jb2wtMyB7XHJcblx0d2lkdGg6IDI1JTtcclxufVxyXG5cclxuLmNvbC00IHtcclxuXHR3aWR0aDogMzMuMzMlO1xyXG59XHJcblxyXG4uY29sLTUge1xyXG5cdHdpZHRoOiA0MS42NiU7XHJcbn1cclxuXHJcbi5jb2wtNiB7XHJcblx0d2lkdGg6IDUwJTtcclxufVxyXG5cclxuLmNvbC03IHtcclxuXHR3aWR0aDogNTguMzMlO1xyXG59XHJcblxyXG4uY29sLTgge1xyXG5cdHdpZHRoOiA2Ni42NiU7XHJcbn1cclxuXHJcbi5jb2wtOSB7XHJcblx0d2lkdGg6IDc1JTtcclxufVxyXG5cclxuLmNvbC0xMCB7XHJcblx0d2lkdGg6IDgzLjMzJTtcclxufVxyXG5cclxuLmNvbC0xMSB7XHJcblx0d2lkdGg6IDkxLjY2JTtcclxufVxyXG5cclxuLmNvbC0xMiB7XHJcblx0d2lkdGg6IDEwMCU7XHJcbn1cclxuXHJcbkBtZWRpYSBvbmx5IHNjcmVlbiBhbmQgKG1heC13aWR0aDogNTc2cHgpIHtcclxuXHQvKiBGb3IgdGFibGV0czogKi9cclxuXHQuY29sLXNtLTEge1xyXG5cdFx0d2lkdGg6IDguMzMlO1xyXG5cdH1cclxuXHJcblx0LmNvbC1zbS0yIHtcclxuXHRcdHdpZHRoOiAxNi42NiU7XHJcblx0fVxyXG5cclxuXHQuY29sLXNtLTMge1xyXG5cdFx0d2lkdGg6IDI1JTtcclxuXHR9XHJcblxyXG5cdC5jb2wtc20tNCB7XHJcblx0XHR3aWR0aDogMzMuMzMlO1xyXG5cdH1cclxuXHJcblx0LmNvbC1zbS01IHtcclxuXHRcdHdpZHRoOiA0MS42NiU7XHJcblx0fVxyXG5cclxuXHQuY29sLXNtLTYge1xyXG5cdFx0d2lkdGg6IDUwJTtcclxuXHR9XHJcblxyXG5cdC5jb2wtc20tNyB7XHJcblx0XHR3aWR0aDogNTguMzMlO1xyXG5cdH1cclxuXHJcblx0LmNvbC1zbS04IHtcclxuXHRcdHdpZHRoOiA2Ni42NiU7XHJcblx0fVxyXG5cclxuXHQuY29sLXNtLTkge1xyXG5cdFx0d2lkdGg6IDc1JTtcclxuXHR9XHJcblxyXG5cdC5jb2wtc20tMTAge1xyXG5cdFx0d2lkdGg6IDgzLjMzJTtcclxuXHR9XHJcblxyXG5cdC5jb2wtc20tMTEge1xyXG5cdFx0d2lkdGg6IDkxLjY2JTtcclxuXHR9XHJcblxyXG5cdC5jb2wtc20tMTIge1xyXG5cdFx0d2lkdGg6IDEwMCU7XHJcblx0fVxyXG59XHJcblxyXG5AbWVkaWEgb25seSBzY3JlZW4gYW5kIChtYXgtd2lkdGg6IDc2OHB4KSBhbmQgKG1pbi13aWR0aDogNTc3cHgpIHtcclxuXHQvKiBGb3IgdGFibGV0czogKi9cclxuXHQuY29sLW1kLTEge1xyXG5cdFx0d2lkdGg6IDguMzMlO1xyXG5cdH1cclxuXHJcblx0LmNvbC1tZC0yIHtcclxuXHRcdHdpZHRoOiAxNi42NiU7XHJcblx0fVxyXG5cclxuXHQuY29sLW1kLTMge1xyXG5cdFx0d2lkdGg6IDI1JTtcclxuXHR9XHJcblxyXG5cdC5jb2wtbWQtNCB7XHJcblx0XHR3aWR0aDogMzMuMzMlO1xyXG5cdH1cclxuXHJcblx0LmNvbC1tZC01IHtcclxuXHRcdHdpZHRoOiA0MS42NiU7XHJcblx0fVxyXG5cclxuXHQuY29sLW1kLTYge1xyXG5cdFx0d2lkdGg6IDUwJTtcclxuXHR9XHJcblxyXG5cdC5jb2wtbWQtNyB7XHJcblx0XHR3aWR0aDogNTguMzMlO1xyXG5cdH1cclxuXHJcblx0LmNvbC1tZC04IHtcclxuXHRcdHdpZHRoOiA2Ni42NiU7XHJcblx0fVxyXG5cclxuXHQuY29sLW1kLTkge1xyXG5cdFx0d2lkdGg6IDc1JTtcclxuXHR9XHJcblxyXG5cdC5jb2wtbWQtMTAge1xyXG5cdFx0d2lkdGg6IDgzLjMzJTtcclxuXHR9XHJcblxyXG5cdC5jb2wtbWQtMTEge1xyXG5cdFx0d2lkdGg6IDkxLjY2JTtcclxuXHR9XHJcblxyXG5cdC5jb2wtbWQtMTIge1xyXG5cdFx0d2lkdGg6IDEwMCU7XHJcblx0fVxyXG59XHJcblxyXG5AbWVkaWEgb25seSBzY3JlZW4gYW5kIChtaW4td2lkdGg6IDc2OXB4KSB7XHJcblx0LyogRm9yIHRhYmxldHM6ICovXHJcblx0LmNvbC1sZy0xIHtcclxuXHRcdHdpZHRoOiA4LjMzJTtcclxuXHR9XHJcblxyXG5cdC5jb2wtbGctMiB7XHJcblx0XHR3aWR0aDogMTYuNjYlO1xyXG5cdH1cclxuXHJcblx0LmNvbC1sZy0zIHtcclxuXHRcdHdpZHRoOiAyNSU7XHJcblx0fVxyXG5cclxuXHQuY29sLWxnLTQge1xyXG5cdFx0d2lkdGg6IDMzLjMzJTtcclxuXHR9XHJcblxyXG5cdC5jb2wtbGctNSB7XHJcblx0XHR3aWR0aDogNDEuNjYlO1xyXG5cdH1cclxuXHJcblx0LmNvbC1sZy02IHtcclxuXHRcdHdpZHRoOiA1MCU7XHJcblx0fVxyXG5cclxuXHQuY29sLWxnLTcge1xyXG5cdFx0d2lkdGg6IDU4LjMzJTtcclxuXHR9XHJcblxyXG5cdC5jb2wtbGctOCB7XHJcblx0XHR3aWR0aDogNjYuNjYlO1xyXG5cdH1cclxuXHJcblx0LmNvbC1sZy05IHtcclxuXHRcdHdpZHRoOiA3NSU7XHJcblx0fVxyXG5cclxuXHQuY29sLWxnLTEwIHtcclxuXHRcdHdpZHRoOiA4My4zMyU7XHJcblx0fVxyXG5cclxuXHQuY29sLWxnLTExIHtcclxuXHRcdHdpZHRoOiA5MS42NiU7XHJcblx0fVxyXG5cclxuXHQuY29sLWxnLTEyIHtcclxuXHRcdHdpZHRoOiAxMDAlO1xyXG5cdH1cclxufVxyXG5cclxuLnJvdyB7XHJcblx0ZGlzcGxheTogZmxleDtcclxuXHRqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuXHRhbGlnbi1pdGVtczogY2VudGVyO1xyXG59XHJcblxyXG4vLyBDU1NcclxuLmN1c3RvbS10b2FzdCB7XHJcblx0LS1tYXgtd2lkdGg6IGZpdC1jb250ZW50O1xyXG59XHJcblxyXG4vKlxyXG4gKiAyLiBDdXN0b20gQ1NTIGZvciBjb21wYXRpYmlsaXR5IHdpdGggRWRnZVxyXG4gKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcbiAqL1xyXG5pbnB1dDo6LW1zLXJldmVhbCxcclxuaW5wdXQ6Oi1tcy1jbGVhciB7XHJcblx0ZGlzcGxheTogbm9uZTtcclxufVxyXG5cclxuLnN3YWwyLXBvcHVwIHtcclxuXHRtYXJnaW4tdG9wOiAyMHB4O1xyXG59XHJcblxyXG4vKlxyXG4gKiAzLiBDdXN0b20gQ1NTIGZvciBsb2FkaW5nIGNvbnRyb2xsZXJcclxuICogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG4gKi9cclxuLnRyYW5zcGFyZW50LWxvYWRpbmctY2xhc3Mge1xyXG5cdC0tYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XHJcblx0LS1zcGlubmVyLWNvbG9yOiAjNDdlNmIxO1xyXG59XHJcblxyXG4ubG9hZGluZy13cmFwcGVyLnNjLWlvbi1sb2FkaW5nLW1kIHtcclxuXHRib3gtc2hhZG93OiB1bnNldDtcclxuXHQtd2Via2l0LWJveC1zaGFkb3c6IHVuc2V0O1xyXG59XHJcblxyXG4udWlsIHtcclxuXHRjb2xvcjogJGNvbG9yLW5leHRnZW4tZ3JleTtcclxufVxyXG5cclxuLmJ0biB7XHJcblx0aGVpZ2h0OiA0OHB4O1xyXG5cdGJvcmRlci1yYWRpdXM6IDI4cHg7XHJcblx0cGFkZGluZzogMHB4IDQxcHggMHB4IDQxcHg7XHJcblx0Ym94LXNoYWRvdzogbm9uZTtcclxuXHJcblx0Ji5idG4tY2lyY2xlIHtcclxuXHRcdGJhY2tncm91bmQtY29sb3I6ICRjb2xvci1uZXh0Z2VuLXN0b25lLWdyZXkgIWltcG9ydGFudDtcclxuXHRcdGNvbG9yOiAkY29sb3ItbmV4dGdlbi1ibGFjaztcclxuXHRcdHBhZGRpbmc6IHVuc2V0ICFpbXBvcnRhbnQ7XHJcblx0XHRoZWlnaHQ6IDM2cHggIWltcG9ydGFudDtcclxuXHRcdHdpZHRoOiAzNnB4ICFpbXBvcnRhbnQ7XHJcblx0XHRib3JkZXItcmFkaXVzOiA1MCUgIWltcG9ydGFudDtcclxuXHJcblx0XHRpIHtcclxuXHRcdFx0Y29sb3I6ICRjb2xvci1uZXh0Z2VuLWJsYWNrO1xyXG5cdFx0fVxyXG5cdH1cclxuXHJcblx0Ji5wcmltYXJ5IHtcclxuXHRcdGJhY2tncm91bmQ6ICRjb2xvci1uZXh0Z2VuLWdyZWVuO1xyXG5cdFx0Y29sb3I6ICRjb2xvci1uZXh0Z2VuLXdoaXRlO1xyXG5cclxuXHRcdC51aWwge1xyXG5cdFx0XHRjb2xvcjogJGNvbG9yLW5leHRnZW4td2hpdGU7XHJcblx0XHR9XHJcblxyXG5cdFx0JjpkaXNhYmxlZCB7XHJcblx0XHRcdGJhY2tncm91bmQtY29sb3I6ICRjb2xvci1uZXh0Z2VuLWdyZXktYmFja2dyb3VuZCAhaW1wb3J0YW50O1xyXG5cdFx0XHRjb2xvcjogJGNvbG9yLW5leHRnZW4tZ3JleSAhaW1wb3J0YW50O1xyXG5cdFx0fVxyXG5cdH1cclxuXHJcblx0Ji5zZWNvbmRhcnkge1xyXG5cdFx0YmFja2dyb3VuZDogJGNvbG9yLW5leHRnZW4td2hpdGUgIWltcG9ydGFudDtcclxuXHRcdGJvcmRlci1jb2xvcjogJGNvbG9yLW5leHRnZW4tZ3JlZW47XHJcblx0XHRib3JkZXI6IHNvbGlkIDFweDtcclxuXHRcdGNvbG9yOiAkY29sb3ItbmV4dGdlbi1ncmVlbjtcclxuXHJcblx0XHQudWlsIHtcclxuXHRcdFx0Y29sb3I6ICRjb2xvci1uZXh0Z2VuLWdyZWVuO1xyXG5cdFx0fVxyXG5cclxuXHRcdCY6ZGlzYWJsZWQge1xyXG5cdFx0XHRiYWNrZ3JvdW5kLWNvbG9yOiAkY29sb3ItbmV4dGdlbi13aGl0ZSAhaW1wb3J0YW50O1xyXG5cdFx0XHRjb2xvcjogJGNvbG9yLW5leHRnZW4tZ3JleSAhaW1wb3J0YW50O1xyXG5cdFx0XHRib3JkZXItY29sb3I6ICRjb2xvci1uZXh0Z2VuLWdyZXktYmFja2dyb3VuZCAhaW1wb3J0YW50O1xyXG5cdFx0fVxyXG5cdH1cclxuXHJcblx0Ji50cmFuc3BhcmVudCB7XHJcblx0XHRiYWNrZ3JvdW5kOiB0cmFuc3BhcmVudCAhaW1wb3J0YW50O1xyXG5cdFx0Ym9yZGVyLWNvbG9yOiAkY29sb3ItbmV4dGdlbi1ncmVlbjtcclxuXHRcdGJvcmRlcjogc29saWQgMXB4O1xyXG5cdFx0Y29sb3I6ICRjb2xvci1uZXh0Z2VuLWdyZWVuO1xyXG5cclxuXHRcdC51aWwge1xyXG5cdFx0XHRjb2xvcjogJGNvbG9yLW5leHRnZW4tZ3JlZW47XHJcblx0XHR9XHJcblxyXG5cdFx0JjpkaXNhYmxlZCB7XHJcblx0XHRcdGJhY2tncm91bmQtY29sb3I6IHRyYW5zcGFyZW50ICFpbXBvcnRhbnQ7XHJcblx0XHRcdGNvbG9yOiAkY29sb3ItbmV4dGdlbi1ncmV5ICFpbXBvcnRhbnQ7XHJcblx0XHRcdGJvcmRlci1jb2xvcjogJGNvbG9yLW5leHRnZW4tZ3JleS1iYWNrZ3JvdW5kICFpbXBvcnRhbnQ7XHJcblx0XHR9XHJcblx0fVxyXG5cclxuXHQmLmJ0bi1sYXJnZSB7XHJcblx0XHRoZWlnaHQ6IDU2cHggIWltcG9ydGFudDtcclxuXHRcdHdpZHRoOiAxMDAlO1xyXG5cdH1cclxuXHJcblx0Ji5ib2xkIHtcclxuXHRcdGZvbnQtd2VpZ2h0OiA3MDAgIWltcG9ydGFudDtcclxuXHR9XHJcblxyXG5cdCYuc2VtaWJvbGQge1xyXG5cdFx0Zm9udC13ZWlnaHQ6IDYwMCAhaW1wb3J0YW50O1xyXG5cdH1cclxufVxyXG5cclxuLmJ0bi1uby1zcGFjZSB7XHJcblx0cGFkZGluZzogNXB4ICFpbXBvcnRhbnQ7XHJcblx0aGVpZ2h0OiBmaXQtY29udGVudDtcclxufVxyXG5cclxuLmJ0bi1iYWNrIHtcclxuXHR3aWR0aDogMzFweDtcclxuXHRoZWlnaHQ6IDI4cHg7XHJcblx0YmFja2dyb3VuZC1jb2xvcjogdHJhbnNwYXJlbnQ7XHJcblx0cGFkZGluZzogMDtcclxuXHRjb2xvcjogJGNvbG9yLW5leHRnZW4tZ3JlZW47XHJcbn1cclxuXHJcbi5jb250YWluZXIge1xyXG5cdHBhZGRpbmc6IDJyZW07XHJcblx0aGVpZ2h0OiAxMDAlO1xyXG59XHJcblxyXG4uYm9keS1zZWN0aW9uIHtcclxuXHR3aWR0aDogMTAwJTtcclxuXHRoZWlnaHQ6IDk1JTtcclxuXHRvdmVyZmxvdy15OiBhdXRvO1xyXG5cdHBvc2l0aW9uOiByZWxhdGl2ZTtcclxufVxyXG5cclxuLnRvcC1zZWN0aW9uIHtcclxuXHR3aWR0aDogMTAwJTtcclxuXHRoZWlnaHQ6IDEwJTtcclxuXHRqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XHJcblx0ZGlzcGxheTogZmxleDtcclxuXHRhbGlnbi1pdGVtczogY2VudGVyO1xyXG59XHJcblxyXG4uZm9ybS1jb250cm9sIHtcclxuXHRwb3NpdGlvbjogcmVsYXRpdmU7XHJcblx0aGVpZ2h0OiA4NXB4O1xyXG5cdG1hcmdpbi1ib3R0b206IDhweDtcclxufVxyXG5cclxuLmNvbnRyb2wge1xyXG5cdGJvcmRlci1yYWRpdXM6IDhweDtcclxuXHRoZWlnaHQ6IDU2cHg7XHJcblx0Ym9yZGVyOiAxcHggc29saWQgJGNvbG9yLW5leHRnZW4tZ3JleS1iYWNrZ3JvdW5kO1xyXG5cdHdpZHRoOiAxMDAlO1xyXG5cdHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuXHR0b3A6IDMycHg7XHJcblx0YmFja2dyb3VuZC1jb2xvcjogJGNvbG9yLW5leHRnZW4td2hpdGU7XHJcblxyXG5cdCYgdGFibGUge1xyXG5cdFx0dGFibGUtbGF5b3V0OiBmaXhlZDtcclxuXHRcdGJvcmRlci1jb2xsYXBzZTogdW5zZXQ7XHJcblx0fVxyXG5cclxuXHQmIGlucHV0IHtcclxuXHRcdGhlaWdodDogNTRweDtcclxuXHRcdGJvcmRlcjogdW5zZXQ7XHJcblx0XHRib3JkZXItcmFkaXVzOiA4cHg7XHJcblx0XHR3aWR0aDogbWF4LWNvbnRlbnQ7XHJcblx0XHR3aWR0aDogMTAwJTtcclxuXHRcdHBvaW50ZXItZXZlbnRzOiBhdXRvO1xyXG5cdFx0YmFja2dyb3VuZC1jb2xvcjogJGNvbG9yLW5leHRnZW4td2hpdGU7XHJcblx0fVxyXG5cclxuXHQmLnRleHRhcmVhIHtcclxuXHRcdGhlaWdodDogMTA4cHg7XHJcblx0fVxyXG5cclxuXHQmIHRleHRhcmVhIHtcclxuXHRcdGhlaWdodDogMTA2cHg7XHJcblx0XHRib3JkZXI6IHVuc2V0O1xyXG5cdFx0Ym9yZGVyLXJhZGl1czogOHB4O1xyXG5cdFx0d2lkdGg6IG1heC1jb250ZW50O1xyXG5cdFx0d2lkdGg6IDEwMCU7XHJcblx0XHRwb2ludGVyLWV2ZW50czogYXV0bztcclxuXHRcdHJlc2l6ZTogbm9uZTtcclxuXHRcdGJhY2tncm91bmQtY29sb3I6ICRjb2xvci1uZXh0Z2VuLXdoaXRlO1xyXG5cdH1cclxuXHJcblx0JiBpbnB1dDpmb2N1cyB7XHJcblx0XHRvdXRsaW5lOiBub25lO1xyXG5cdH1cclxuXHJcblx0Jjpmb2N1cy13aXRoaW4ge1xyXG5cdFx0Ym9yZGVyLWNvbG9yOiAkY29sb3ItbmV4dGdlbi1ncmVlbjtcclxuXHJcblx0XHQuZmlyc3QtaWNvbiB7XHJcblx0XHRcdGRpc3BsYXk6IG5vbmU7XHJcblx0XHR9XHJcblxyXG5cdFx0LmZpcnN0LWljb24ubm9uLWhpZGRlbiB7XHJcblx0XHRcdGRpc3BsYXk6IHRhYmxlLWNlbGw7XHJcblx0XHR9XHJcblx0fVxyXG5cclxuXHQuZmlyc3QtaWNvbiB7XHJcblx0XHR3aWR0aDogMzJweDtcclxuXHRcdHRleHQtYWxpZ246IGNlbnRlcjtcclxuXHRcdHBhZGRpbmctbGVmdDogOHB4O1xyXG5cclxuXHRcdGkge1xyXG5cdFx0XHRmb250LXNpemU6IDI0cHggIWltcG9ydGFudDtcclxuXHRcdH1cclxuXHR9XHJcblxyXG5cdC5zZWNvbmQtaWNvbiB7XHJcblx0XHR3aWR0aDogMzJweDtcclxuXHRcdHRleHQtYWxpZ246IGNlbnRlcjtcclxuXHRcdC8vIHBhZGRpbmctcmlnaHQ6IDhweDtcclxuXHJcblx0XHRpIHtcclxuXHRcdFx0Zm9udC1zaXplOiAyNHB4ICFpbXBvcnRhbnQ7XHJcblx0XHR9XHJcblx0fVxyXG59XHJcblxyXG4uY29udHJvbDpmb2N1cy13aXRoaW4gfiBkaXYgLmNvbnRyb2wtbGFiZWwge1xyXG5cdGNvbG9yOiAkY29sb3ItbmV4dGdlbi1ncmVlbjtcclxufVxyXG5cclxuLmNvbnRyb2wtZXJyb3Ige1xyXG5cdC5jb250cm9sIHtcclxuXHRcdGJvcmRlci1jb2xvcjogJGNvbG9yLW5leHRnZW4tZXJyb3I7XHJcblx0fVxyXG5cclxuXHQuY29udHJvbC1sYWJlbCB7XHJcblx0XHRjb2xvcjogJGNvbG9yLW5leHRnZW4tZXJyb3IgIWltcG9ydGFudDtcclxuXHR9XHJcbn1cclxuXHJcbi52YWxpZGF0aW9uLXN1bW1hcnkge1xyXG5cdGxpIHtcclxuXHRcdGNvbG9yOiAkY29sb3ItbmV4dGdlbi1lcnJvciAhaW1wb3J0YW50O1xyXG5cdFx0bGlzdC1zdHlsZTogbm9uZTtcclxuXHJcblx0XHRpIHtcclxuXHRcdFx0Y29sb3I6ICRjb2xvci1uZXh0Z2VuLWVycm9yICFpbXBvcnRhbnQ7XHJcblx0XHR9XHJcblx0fVxyXG59XHJcblxyXG4ubXItMSB7XHJcblx0bWFyZ2luLXJpZ2h0OiAwLjVyZW07XHJcbn1cclxuXHJcbi5tYi0xIHtcclxuXHRtYXJnaW4tYm90dG9tOiAwLjVyZW07XHJcbn1cclxuXHJcbi5kaWFsb2ctcGFuZSB7XHJcblx0cG9zaXRpb246IGFic29sdXRlO1xyXG5cdHBvaW50ZXItZXZlbnRzOiBhdXRvO1xyXG5cdGJveC1zaXppbmc6IGJvcmRlci1ib3g7XHJcblx0ei1pbmRleDogMTAwMDtcclxuXHRkaXNwbGF5OiBibG9jaztcclxuXHRtYXgtd2lkdGg6IDEwMCU7XHJcblx0bWF4LWhlaWdodDogMTAwJTtcclxufVxyXG5cclxuLm92ZXJsYXktYmFja2Ryb3Age1xyXG5cdGJhY2tncm91bmQtY29sb3I6ICRjb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleTtcclxuXHRvcGFjaXR5OiAwLjIgIWltcG9ydGFudDtcclxufVxyXG5cclxuLmRpYWxvZy1jb250YWluZXIge1xyXG5cdGFuaW1hdGlvbjogZmFkZUluIDAuNXMgbGluZWFyO1xyXG5cdGJhY2tncm91bmQtY29sb3I6ICRjb2xvci1uZXh0Z2VuLXdoaXRlO1xyXG59XHJcblxyXG5Aa2V5ZnJhbWVzIGZhZGVJbiB7XHJcblx0ZnJvbSB7XHJcblx0XHR0cmFuc2Zvcm06IHRyYW5zbGF0ZVkoMTAwJSk7XHJcblx0fVxyXG5cclxuXHR0byB7XHJcblx0XHR0cmFuc2Zvcm06IHRyYW5zbGF0ZVkoMCUpO1xyXG5cdH1cclxufVxyXG5cclxuLmVycm9yIHtcclxuXHRjb2xvcjogJGNvbG9yLW5leHRnZW4tZXJyb3I7XHJcblxyXG5cdCYuYmFja2dyb3VuZCB7XHJcblx0XHRiYWNrZ3JvdW5kLWNvbG9yOiAkY29sb3ItbmV4dGdlbi1lcnJvcjtcclxuXHR9XHJcbn1cclxuXHJcbi5zdWNjZXNzIHtcclxuXHRjb2xvcjogJGNvbG9yLW5leHRnZW4tZmlicmFudC1ncmVlbjtcclxuXHJcblx0Ji5iYWNrZ3JvdW5kIHtcclxuXHRcdGJhY2tncm91bmQtY29sb3I6ICRjb2xvci1uZXh0Z2VuLWZpYnJhbnQtZ3JlZW47XHJcblx0fVxyXG59XHJcblxyXG4ud2FybmluZyB7XHJcblx0Y29sb3I6ICRjb2xvci1uZXh0Z2VuLXdhcm5pbmc7XHJcblxyXG5cdCYuYmFja2dyb3VuZCB7XHJcblx0XHRiYWNrZ3JvdW5kLWNvbG9yOiAkY29sb3ItbmV4dGdlbi13YXJuaW5nO1xyXG5cdH1cclxufVxyXG5cclxuLnNlbGVjdCB7XHJcblx0d2lkdGg6IDEwMCU7XHJcblx0aGVpZ2h0OiA1NHB4O1xyXG5cdGJvcmRlcjogdW5zZXQ7XHJcblx0Ym9yZGVyLXJhZGl1czogOHB4O1xyXG5cdGRpc3BsYXk6IGdyaWQ7XHJcblx0YXBwZWFyYW5jZTogbm9uZTtcclxuXHRncmlkLXRlbXBsYXRlLWFyZWFzOiBcInNlbGVjdFwiO1xyXG5cclxuXHQmOmZvY3VzIHtcclxuXHRcdG91dGxpbmU6IHVuc2V0O1xyXG5cdH1cclxufVxyXG5cclxuLmNvbG9yLWJsYWNrIHtcclxuXHRjb2xvcjogJGNvbG9yLW5leHRnZW4tYmxhY2s7XHJcbn1cclxuXHJcbi5tb2RhbC1kZWZhdWx0IHtcclxuXHQtLXdpZHRoOiAxMDAlO1xyXG5cdC0taGVpZ2h0OiAxMDAlO1xyXG59XHJcblxyXG4uaW50ZWdyYXRpb24tcGFuZWwge1xyXG5cdHdpZHRoOiAxMDAlO1xyXG5cdGhlaWdodDogMTAwJTtcclxuXHRtYXgtd2lkdGg6IDEwMCUgIWltcG9ydGFudDtcclxufVxyXG5cclxuLnZlcmxvb3AtYnV0dG9uIHtcclxuXHR2aXNpYmlsaXR5OiBoaWRkZW47XHJcbn1cclxuXHJcbi5iYWNrLWFyZWEge1xyXG5cdHBvc2l0aW9uOiBmaXhlZDtcclxuXHR0b3A6IDA7XHJcblx0cmlnaHQ6IDA7XHJcblx0aGVpZ2h0OiA1MHB4O1xyXG5cdHdpZHRoOiAxMDAlO1xyXG5cdGJhY2tncm91bmQtY29sb3I6ICRjb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS01MDtcclxuXHR6LWluZGV4OiA5OTk5OTk5O1xyXG5cclxuXHQmLmlvcyB7XHJcblx0XHRoZWlnaHQ6IDgwcHg7XHJcblx0fVxyXG59XHJcblxyXG4udGl0bGUtd2lkZ2V0IHtcclxuXHR0ZXh0LWFsaWduOiBjZW50ZXI7XHJcblx0cG9zaXRpb246IHN0aWNreTtcclxuXHR0b3A6IDQ4cHg7XHJcbn1cclxuXHJcbi5idXR0b24tYmFjayB7XHJcblx0YmFja2dyb3VuZC1jb2xvcjogI2ZhZmFmYTtcclxuXHRoZWlnaHQ6IDM2cHg7XHJcblx0d2lkdGg6IDM2cHg7XHJcblx0Ym9yZGVyLXJhZGl1czogNTAlO1xyXG5cdHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuXHRsZWZ0OiAxOHB4O1xyXG5cdGJvdHRvbTogNHB4O1xyXG59XHJcblxyXG4uaWNvbi1jbG9zZS13aWRnZXQge1xyXG5cdHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuXHR6LWluZGV4OiAyNTA7XHJcblx0bGVmdDogMTFweDtcclxuXHRib3R0b206IDEzcHg7XHJcbn1cclxuXHJcbi5kYXRhLWRlZmF1bHQge1xyXG5cdHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuXHR0b3A6IDUwJTtcclxuXHRsZWZ0OiA1MCU7XHJcblx0dHJhbnNmb3JtOiB0cmFuc2xhdGUoLTUwJSwgLTUwJSk7XHJcblx0dGV4dC1hbGlnbjogY2VudGVyO1xyXG5cdGNvbG9yOiAkY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNDAwO1xyXG5cdHotaW5kZXg6IDEwMDA7XHJcbn1cclxuXHJcbi5hdmFhbW9fX2ljb24ge1xyXG5cdHZpc2liaWxpdHk6IGhpZGRlbiAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4uYXZhYW1vX19jaGF0X193aWRnZXQuaW9zIHtcclxuXHQjYXZhYW1vX19wb3B1cCB7XHJcblx0XHRwYWRkaW5nLXRvcDogNDBweDtcclxuXHR9XHJcbn1cclxuXHJcbi5kLWZsZXgge1xyXG5cdGRpc3BsYXk6IGZsZXg7XHJcbn1cclxuXHJcbm5leHRjYXJlLWxheW91dCB7XHJcblx0bGVmdDogMDtcclxuXHRyaWdodDogMDtcclxuXHR0b3A6IDA7XHJcblx0Ym90dG9tOiAwO1xyXG5cdGRpc3BsYXk6IGZsZXg7XHJcblx0cG9zaXRpb246IGFic29sdXRlO1xyXG5cdGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcblx0anVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xyXG5cdGNvbnRhaW46IGxheW91dCBzaXplIHN0eWxlO1xyXG5cdG92ZXJmbG93OiBoaWRkZW47XHJcblx0YmFja2dyb3VuZC1jb2xvcjogJGNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTUwO1xyXG5cdHBhZGRpbmctcmlnaHQ6IDI0cHg7XHJcblx0cGFkZGluZy1sZWZ0OiAyNHB4O1xyXG59XHJcblxyXG5pb24taGVhZGVyLmlvcy5oZWFkZXItaW9zIHtcclxuXHRtYXJnaW4tdG9wOiA0MHB4O1xyXG59XHJcblxyXG4uaGVhZGVyLWlvcyBpb24tdG9vbGJhcjpsYXN0LW9mLXR5cGUge1xyXG5cdC0tYm9yZGVyLXdpZHRoOiAwcHggIWltcG9ydGFudDtcclxufVxyXG5cclxuLmhlYWRlci1tZC5tZDo6YWZ0ZXIge1xyXG5cdGRpc3BsYXk6IG5vbmU7XHJcbn1cclxuXHJcbmlvbi10b29sYmFyIHtcclxuXHRwYWRkaW5nLXJpZ2h0OiB1bnNldCAhaW1wb3J0YW50O1xyXG5cdHBhZGRpbmctbGVmdDogdW5zZXQgIWltcG9ydGFudDtcclxufVxyXG5cclxuaS5pY29uLWJhY2sge1xyXG5cdGNvbnRlbnQ6IHVybChhc3NldHMvaWNvbi9sb25nLWFycm93LWxlZnQtaWNvbi5zdmcpO1xyXG59XHJcblxyXG4udmVybG9vcC13aWRnZXQuaW9zIHtcclxuXHQudmVybG9vcC1jb250YWluZXIudmlzaWJsZSB7XHJcblx0XHRoZWlnaHQ6IGNhbGMoMTAwJSAtIDQwcHgpO1xyXG5cdFx0dG9wOiA0MHB4O1xyXG5cdH1cclxufVxyXG5cclxuI25leHRjYXJlLWFkcyB7XHJcblx0ZGlzcGxheTogbm9uZTtcclxuXHRvdmVyZmxvdzogc2Nyb2xsO1xyXG5cdGhlaWdodDogMTgwcHg7XHJcbn1cclxuXHJcbi5kLWJsb2NrIHtcclxuXHRkaXNwbGF5OiBibG9jaztcclxufVxyXG5cclxuLnRpdGxlLXRleHQge1xyXG5cdGNvbG9yOiAkY29sb3ItbmV4dGdlbi1ibHVlO1xyXG59XHJcblxyXG46aG9zdCBpb24tZGF0ZXRpbWUgI3NoYWRvdy1yb290IHtcclxuXHQuZGF0ZXRpbWUtY2FsZW5kYXIge1xyXG5cdFx0LmNhbGVuZGFyLWhlYWRlciB7XHJcblx0XHRcdC5jYWxlbmRhci1hY3Rpb24tYnV0dG9ucyB7XHJcblx0XHRcdFx0LmNhbGVuZGFyLW1vbnRoLXllYXIge1xyXG5cdFx0XHRcdFx0YWxpZ24taXRlbXM6IGNlbnRlcjtcclxuXHRcdFx0XHRcdGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG5cdFx0XHRcdFx0ZGlzcGxheTogZmxleDtcclxuXHRcdFx0XHRcdHdpZHRoOiAxMDAlO1xyXG5cclxuXHRcdFx0XHRcdGlvbi1pY29uIHtcclxuXHRcdFx0XHRcdFx0ZGlzcGxheTogbm9uZTtcclxuXHRcdFx0XHRcdH1cclxuXHRcdFx0XHR9XHJcblxyXG5cdFx0XHRcdC5jYWxlbmRhci1uZXh0LXByZXYge1xyXG5cdFx0XHRcdFx0cG9zaXRpb246IGFic29sdXRlO1xyXG5cdFx0XHRcdFx0d2lkdGg6IDEwMCU7XHJcblx0XHRcdFx0XHRyaWdodDogMDtcclxuXHJcblx0XHRcdFx0XHRpb24tYnV0dG9ucyB7XHJcblx0XHRcdFx0XHRcdGRpc3BsYXk6IGZsZXg7XHJcblx0XHRcdFx0XHRcdGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcclxuXHRcdFx0XHRcdFx0d2lkdGg6IDEwMCU7XHJcblx0XHRcdFx0XHR9XHJcblx0XHRcdFx0fVxyXG5cdFx0XHR9XHJcblx0XHR9XHJcblx0fVxyXG59XHJcblxyXG4ubWF0LWRpYWxvZy1jb250YWluZXIge1xyXG5cdHBhZGRpbmc6IHVuc2V0ICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi8qIENoYW5nZSBhdXRvY29tcGxldGUgc3R5bGVzIGluIFdlYktpdCAqL1xyXG5pbnB1dDotd2Via2l0LWF1dG9maWxsLFxyXG5pbnB1dDotd2Via2l0LWF1dG9maWxsOmhvdmVyLFxyXG5pbnB1dDotd2Via2l0LWF1dG9maWxsOmZvY3VzLFxyXG50ZXh0YXJlYTotd2Via2l0LWF1dG9maWxsLFxyXG50ZXh0YXJlYTotd2Via2l0LWF1dG9maWxsOmhvdmVyLFxyXG50ZXh0YXJlYTotd2Via2l0LWF1dG9maWxsOmZvY3VzLFxyXG5zZWxlY3Q6LXdlYmtpdC1hdXRvZmlsbCxcclxuc2VsZWN0Oi13ZWJraXQtYXV0b2ZpbGw6aG92ZXIsXHJcbnNlbGVjdDotd2Via2l0LWF1dG9maWxsOmZvY3VzIHtcclxuXHQtd2Via2l0LXRleHQtZmlsbC1jb2xvcjogYmxhY2s7XHJcblx0LXdlYmtpdC1ib3gtc2hhZG93OiAwIDAgMHB4IDEwMDBweCB3aGl0ZSBpbnNldDtcclxuXHR0cmFuc2l0aW9uOiBiYWNrZ3JvdW5kLWNvbG9yIDUwMDBzIGVhc2UtaW4tb3V0IDBzO1xyXG59XHJcblxyXG4uZm9yY2UtdXBkYXRlLXBvcHVwICsgLmNkay1nbG9iYWwtb3ZlcmxheS13cmFwcGVyIHtcclxuXHQuc2F2ZS1idG4ge1xyXG5cdFx0YmFja2dyb3VuZDogdmFyKC0tbHVtaS1wcmltYXJ5LXllbGxvdy1jb2xvcikgIWltcG9ydGFudDtcclxuXHRcdGNvbG9yOiB2YXIoLS1sdW1pLXdoaXRlLWNvbG9yKSAhaW1wb3J0YW50O1xyXG5cdFx0Zm9udC13ZWlnaHQ6IGJvbGQgIWltcG9ydGFudDtcclxuXHR9XHJcblxyXG5cdC5jYW5jZWwtYnRuIHtcclxuXHRcdGNvbG9yOiB2YXIoLS1sdW1pLXByaW1hcnkteWVsbG93LWNvbG9yKSAhaW1wb3J0YW50O1xyXG5cdH1cclxufVxyXG5cclxuQC13ZWJraXQta2V5ZnJhbWVzIHNsaWRlSW5SaWdodCB7XHJcblx0MCUge1xyXG5cdFx0LXdlYmtpdC10cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKDEwMCUsIDAsIDApO1xyXG5cdFx0dHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgxMDAlLCAwLCAwKTtcclxuXHRcdHZpc2liaWxpdHk6IHZpc2libGU7XHJcblx0fVxyXG5cclxuXHR0byB7XHJcblx0XHQtd2Via2l0LXRyYW5zZm9ybTogdHJhbnNsYXRlWigwKTtcclxuXHRcdHRyYW5zZm9ybTogdHJhbnNsYXRlWigwKTtcclxuXHR9XHJcbn1cclxuXHJcbkBrZXlmcmFtZXMgc2xpZGVJblJpZ2h0IHtcclxuXHQwJSB7XHJcblx0XHQtd2Via2l0LXRyYW5zZm9ybTogdHJhbnNsYXRlM2QoMTAwJSwgMCwgMCk7XHJcblx0XHR0cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKDEwMCUsIDAsIDApO1xyXG5cdFx0dmlzaWJpbGl0eTogdmlzaWJsZTtcclxuXHR9XHJcblxyXG5cdHRvIHtcclxuXHRcdC13ZWJraXQtdHJhbnNmb3JtOiB0cmFuc2xhdGVaKDApO1xyXG5cdFx0dHJhbnNmb3JtOiB0cmFuc2xhdGVaKDApO1xyXG5cdH1cclxufVxyXG5cclxuLmFuaW1hdGVfX3NsaWRlSW5SaWdodCB7XHJcblx0LXdlYmtpdC1hbmltYXRpb24tbmFtZTogc2xpZGVJblJpZ2h0O1xyXG5cdGFuaW1hdGlvbi1uYW1lOiBzbGlkZUluUmlnaHQ7XHJcbn1cclxuXHJcbi5hbmltYXRlX19hbmltYXRlZCB7XHJcblx0LXdlYmtpdC1hbmltYXRpb24tZHVyYXRpb246IDAuNXM7XHJcblx0YW5pbWF0aW9uLWR1cmF0aW9uOiAwLjVzO1xyXG5cdC13ZWJraXQtYW5pbWF0aW9uLWR1cmF0aW9uOiAwLjVzO1xyXG5cdGFuaW1hdGlvbi1kdXJhdGlvbjogMC41cztcclxuXHQtd2Via2l0LWFuaW1hdGlvbi1maWxsLW1vZGU6IGJvdGg7XHJcblx0YW5pbWF0aW9uLWZpbGwtbW9kZTogYm90aDtcclxufVxyXG4iLCIuZGlzcGxheS14bCB7XHJcbiAgICBmb250LXNpemU6IDQxcHggIWltcG9ydGFudDtcclxuICAgIGZvbnQtd2VpZ2h0OiA0MDAgIWltcG9ydGFudDtcclxuICAgIGxpbmUtaGVpZ2h0OiAxMjAlICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5kaXNwbGF5LW1kIHtcclxuICAgIGZvbnQtc2l6ZTogMzZweCAhaW1wb3J0YW50O1xyXG4gICAgZm9udC13ZWlnaHQ6IDQwMCAhaW1wb3J0YW50O1xyXG4gICAgbGluZS1oZWlnaHQ6IDEyMCUgIWltcG9ydGFudDtcclxufVxyXG5cclxuLmgxIHtcclxuICAgIGZvbnQtc2l6ZTogMzFweCAhaW1wb3J0YW50O1xyXG4gICAgZm9udC13ZWlnaHQ6IDQwMCAhaW1wb3J0YW50O1xyXG4gICAgbGluZS1oZWlnaHQ6IDEyMCUgIWltcG9ydGFudDtcclxufVxyXG5cclxuLmgyIHtcclxuICAgIGZvbnQtc2l6ZTogMjhweCAhaW1wb3J0YW50O1xyXG4gICAgZm9udC13ZWlnaHQ6IDQwMCAhaW1wb3J0YW50O1xyXG4gICAgbGluZS1oZWlnaHQ6IDEyMCUgIWltcG9ydGFudDtcclxufVxyXG5cclxuLmgzIHtcclxuICAgIGZvbnQtc2l6ZTogMjVweCAhaW1wb3J0YW50O1xyXG4gICAgZm9udC13ZWlnaHQ6IDQwMCAhaW1wb3J0YW50O1xyXG4gICAgbGluZS1oZWlnaHQ6IDEyMCUgIWltcG9ydGFudDtcclxufVxyXG5cclxuLmg0IHtcclxuICAgIGZvbnQtc2l6ZTogMjJweCAhaW1wb3J0YW50O1xyXG4gICAgZm9udC13ZWlnaHQ6IDQwMCAhaW1wb3J0YW50O1xyXG4gICAgbGluZS1oZWlnaHQ6IDEyMCUgIWltcG9ydGFudDtcclxufVxyXG5cclxuLmg1IHtcclxuICAgIGZvbnQtc2l6ZTogMTlweCAhaW1wb3J0YW50O1xyXG4gICAgZm9udC13ZWlnaHQ6IDQwMCAhaW1wb3J0YW50O1xyXG4gICAgbGluZS1oZWlnaHQ6IDEyMCUgIWltcG9ydGFudDtcclxufVxyXG5cclxuLmg2IHtcclxuICAgIGZvbnQtc2l6ZTogMTdweCAhaW1wb3J0YW50O1xyXG4gICAgZm9udC13ZWlnaHQ6IDQwMCAhaW1wb3J0YW50O1xyXG4gICAgbGluZS1oZWlnaHQ6IDEyMCUgIWltcG9ydGFudDtcclxufVxyXG5cclxuLmJvZHktbCB7XHJcbiAgICBmb250LXNpemU6IDE3cHggIWltcG9ydGFudDtcclxuICAgIGZvbnQtd2VpZ2h0OiA0MDAgIWltcG9ydGFudDtcclxuICAgIGxpbmUtaGVpZ2h0OiAxMjAlICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5ib2R5LW4ge1xyXG4gICAgZm9udC1zaXplOiAxNXB4ICFpbXBvcnRhbnQ7XHJcbiAgICBmb250LXdlaWdodDogNDAwICFpbXBvcnRhbnQ7XHJcbiAgICBsaW5lLWhlaWdodDogMTIwJSAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4uYm9keS1zbSB7XHJcbiAgICBmb250LXNpemU6IDEzcHggIWltcG9ydGFudDtcclxuICAgIGZvbnQtd2VpZ2h0OiA0MDAgIWltcG9ydGFudDtcclxuICAgIGxpbmUtaGVpZ2h0OiAxMjAlICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5ib2R5LXhzIHtcclxuICAgIGZvbnQtc2l6ZTogMTJweCAhaW1wb3J0YW50O1xyXG4gICAgZm9udC13ZWlnaHQ6IDQwMCAhaW1wb3J0YW50O1xyXG4gICAgbGluZS1oZWlnaHQ6IDEyMCUgIWltcG9ydGFudDtcclxufVxyXG5cclxuLnNlbWlib2xkIHtcclxuICAgICYuZGlzcGxheS14bCB7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IDYwMCAhaW1wb3J0YW50O1xyXG4gICAgfVxyXG4gICAgJi5kaXNwbGF5LW1kIHtcclxuICAgICAgICBmb250LXdlaWdodDogNjAwICFpbXBvcnRhbnQ7XHJcbiAgICB9XHJcbiAgICAmLmgxIHtcclxuICAgICAgICBmb250LXdlaWdodDogNjAwICFpbXBvcnRhbnQ7XHJcbiAgICB9XHJcbiAgICAmLmgyIHtcclxuICAgICAgICBmb250LXdlaWdodDogNjAwICFpbXBvcnRhbnQ7XHJcbiAgICB9XHJcbiAgICAmLmgzIHtcclxuICAgICAgICBmb250LXdlaWdodDogNjAwICFpbXBvcnRhbnQ7XHJcbiAgICB9XHJcbiAgICAmLmg0IHtcclxuICAgICAgICBmb250LXdlaWdodDogNjAwICFpbXBvcnRhbnQ7XHJcbiAgICB9XHJcbiAgICAmLmg1IHtcclxuICAgICAgICBmb250LXdlaWdodDogNjAwICFpbXBvcnRhbnQ7XHJcbiAgICB9XHJcbiAgICAmLmg2IHtcclxuICAgICAgICBmb250LXdlaWdodDogNjAwICFpbXBvcnRhbnQ7XHJcbiAgICB9XHJcbiAgICAmLmJvZHktbCB7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IDYwMCAhaW1wb3J0YW50O1xyXG4gICAgfVxyXG4gICAgJi5ib2R5LW4ge1xyXG4gICAgICAgIGZvbnQtd2VpZ2h0OiA2MDAgIWltcG9ydGFudDtcclxuICAgIH1cclxuICAgICYuYm9keS1zbSB7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IDYwMCAhaW1wb3J0YW50O1xyXG4gICAgfVxyXG4gICAgJi5ib2R5LXhzIHtcclxuICAgICAgICBmb250LXdlaWdodDogNjAwICFpbXBvcnRhbnQ7XHJcbiAgICB9XHJcbn1cclxuXHJcbi5ib2xkIHtcclxuICAgICYuZGlzcGxheS14bCB7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IDcwMCAhaW1wb3J0YW50O1xyXG4gICAgfVxyXG4gICAgJi5kaXNwbGF5LW1kIHtcclxuICAgICAgICBmb250LXdlaWdodDogNzAwICFpbXBvcnRhbnQ7XHJcbiAgICB9XHJcbiAgICAmLmgxIHtcclxuICAgICAgICBmb250LXdlaWdodDogNzAwICFpbXBvcnRhbnQ7XHJcbiAgICB9XHJcbiAgICAmLmgyIHtcclxuICAgICAgICBmb250LXdlaWdodDogNzAwICFpbXBvcnRhbnQ7XHJcbiAgICB9XHJcbiAgICAmLmgzIHtcclxuICAgICAgICBmb250LXdlaWdodDogNzAwICFpbXBvcnRhbnQ7XHJcbiAgICB9XHJcbiAgICAmLmg0IHtcclxuICAgICAgICBmb250LXdlaWdodDogNzAwICFpbXBvcnRhbnQ7XHJcbiAgICB9XHJcbiAgICAmLmg1IHtcclxuICAgICAgICBmb250LXdlaWdodDogNzAwICFpbXBvcnRhbnQ7XHJcbiAgICB9XHJcbiAgICAmLmg2IHtcclxuICAgICAgICBmb250LXdlaWdodDogNzAwICFpbXBvcnRhbnQ7XHJcbiAgICB9XHJcbiAgICAmLmJvZHktbCB7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IDcwMCAhaW1wb3J0YW50O1xyXG4gICAgfVxyXG4gICAgJi5ib2R5LW4ge1xyXG4gICAgICAgIGZvbnQtd2VpZ2h0OiA3MDAgIWltcG9ydGFudDtcclxuICAgIH1cclxuICAgICYuYm9keS1zbSB7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IDcwMCAhaW1wb3J0YW50O1xyXG4gICAgfVxyXG4gICAgJi5ib2R5LXhzIHtcclxuICAgICAgICBmb250LXdlaWdodDogNzAwICFpbXBvcnRhbnQ7XHJcbiAgICB9XHJcbn0iXX0= */";

/***/ }),

/***/ 24086:
/*!***************************************************************************************************!*\
  !*** ./src/app/pages/new-claim/disclosure-accident/disclosure-accident.component.scss?ngResource ***!
  \***************************************************************************************************/
/***/ ((module) => {

module.exports = ":root {\n  --nc-color-nextgen-neutral-grey-50: red;\n  --nc-color-nextgen-white: yellow;\n  --nc-color-nextgen-blue: #0d152e;\n  --nc-color-nextgen-green: #00908d;\n  --nc-color-nextgen-black: #000000;\n  --nc-color-nextgen-grey-background: #c8d3da;\n  --nc-color-nextgen-grey: #92a2ac;\n  --nc-color-nextgen-stone-grey: #fafafa;\n  --nc-color-nextgen-error: #fc1055;\n  --nc-color-nextgen-neutral-grey: #414141;\n  --nc-color-nextgen-fibrant-green: #00bab6;\n  --nc-color-nextgen-warning: #ffd048;\n  --nc-color-nextgen-green-background: #e6f2f2;\n  --nc-color-nextgen-neutral-grey-400: #7a7a7a;\n  --nc-color-nextgen-neutral-grey-100: #eff3f5;\n  --nc-color-nextgen-status-error: #ba0c3f;\n  --nc-color-nextgen-status-error-background: #ffeff4;\n  --nc-color-nextgen-status-warning: #cba127;\n  --nc-color-nextgen-status-warning-background: #fff8e6;\n  --nc-color-nextgen-blue-100: #dfeff2;\n  --nc-color-nextgen-error-red-700: #f62459;\n  --nc-color-nextgen-blue-500: #006192;\n  --nc-color-nextgen-blue-400: #79cdec;\n  --nc-color-nextgen-red-500: #ff6592;\n  --nc-color-nextgen-secondary-blue-300: #13a0d3;\n  --lumi-white-color: #ffffff;\n  --lumi-primary-yellow-color: #fab600;\n}\n\n.ion-color-green {\n  --ion-color-base: var(--nc-color-nextgen-green);\n  --ion-color-base-rgb: var(--nc-color-nextgen-green);\n  --ion-color-contrast: var(--nc-color-nextgen-white);\n  --ion-color-contrast-rgb: var(--nc-color-nextgen-green);\n  --ion-color-shade: var(--nc-color-nextgen-green);\n  --ion-color-tint: var(--nc-color-nextgen-green);\n}\n\n/*\n * 1. Custom CSS \n * ----------------------------------------------------------------------------\n */\n\n:root {\n  --nc-color-nextgen-neutral-grey-50: red;\n  --nc-color-nextgen-white: yellow;\n  --nc-color-nextgen-blue: #0d152e;\n  --nc-color-nextgen-green: #00908d;\n  --nc-color-nextgen-black: #000000;\n  --nc-color-nextgen-grey-background: #c8d3da;\n  --nc-color-nextgen-grey: #92a2ac;\n  --nc-color-nextgen-stone-grey: #fafafa;\n  --nc-color-nextgen-error: #fc1055;\n  --nc-color-nextgen-neutral-grey: #414141;\n  --nc-color-nextgen-fibrant-green: #00bab6;\n  --nc-color-nextgen-warning: #ffd048;\n  --nc-color-nextgen-green-background: #e6f2f2;\n  --nc-color-nextgen-neutral-grey-400: #7a7a7a;\n  --nc-color-nextgen-neutral-grey-100: #eff3f5;\n  --nc-color-nextgen-status-error: #ba0c3f;\n  --nc-color-nextgen-status-error-background: #ffeff4;\n  --nc-color-nextgen-status-warning: #cba127;\n  --nc-color-nextgen-status-warning-background: #fff8e6;\n  --nc-color-nextgen-blue-100: #dfeff2;\n  --nc-color-nextgen-error-red-700: #f62459;\n  --nc-color-nextgen-blue-500: #006192;\n  --nc-color-nextgen-blue-400: #79cdec;\n  --nc-color-nextgen-red-500: #ff6592;\n  --nc-color-nextgen-secondary-blue-300: #13a0d3;\n  --lumi-white-color: #ffffff;\n  --lumi-primary-yellow-color: #fab600;\n}\n\n.ion-color-green {\n  --ion-color-base: var(--nc-color-nextgen-green);\n  --ion-color-base-rgb: var(--nc-color-nextgen-green);\n  --ion-color-contrast: var(--nc-color-nextgen-white);\n  --ion-color-contrast-rgb: var(--nc-color-nextgen-green);\n  --ion-color-shade: var(--nc-color-nextgen-green);\n  --ion-color-tint: var(--nc-color-nextgen-green);\n}\n\n.display-xl {\n  font-size: 41px !important;\n  font-weight: 400 !important;\n  line-height: 120% !important;\n}\n\n.display-md {\n  font-size: 36px !important;\n  font-weight: 400 !important;\n  line-height: 120% !important;\n}\n\n.h1 {\n  font-size: 31px !important;\n  font-weight: 400 !important;\n  line-height: 120% !important;\n}\n\n.h2 {\n  font-size: 28px !important;\n  font-weight: 400 !important;\n  line-height: 120% !important;\n}\n\n.h3 {\n  font-size: 25px !important;\n  font-weight: 400 !important;\n  line-height: 120% !important;\n}\n\n.h4 {\n  font-size: 22px !important;\n  font-weight: 400 !important;\n  line-height: 120% !important;\n}\n\n.h5 {\n  font-size: 19px !important;\n  font-weight: 400 !important;\n  line-height: 120% !important;\n}\n\n.h6 {\n  font-size: 17px !important;\n  font-weight: 400 !important;\n  line-height: 120% !important;\n}\n\n.body-l {\n  font-size: 17px !important;\n  font-weight: 400 !important;\n  line-height: 120% !important;\n}\n\n.body-n {\n  font-size: 15px !important;\n  font-weight: 400 !important;\n  line-height: 120% !important;\n}\n\n.body-sm {\n  font-size: 13px !important;\n  font-weight: 400 !important;\n  line-height: 120% !important;\n}\n\n.body-xs {\n  font-size: 12px !important;\n  font-weight: 400 !important;\n  line-height: 120% !important;\n}\n\n.semibold.display-xl {\n  font-weight: 600 !important;\n}\n\n.semibold.display-md {\n  font-weight: 600 !important;\n}\n\n.semibold.h1 {\n  font-weight: 600 !important;\n}\n\n.semibold.h2 {\n  font-weight: 600 !important;\n}\n\n.semibold.h3 {\n  font-weight: 600 !important;\n}\n\n.semibold.h4 {\n  font-weight: 600 !important;\n}\n\n.semibold.h5 {\n  font-weight: 600 !important;\n}\n\n.semibold.h6 {\n  font-weight: 600 !important;\n}\n\n.semibold.body-l {\n  font-weight: 600 !important;\n}\n\n.semibold.body-n {\n  font-weight: 600 !important;\n}\n\n.semibold.body-sm {\n  font-weight: 600 !important;\n}\n\n.semibold.body-xs {\n  font-weight: 600 !important;\n}\n\n.bold.display-xl {\n  font-weight: 700 !important;\n}\n\n.bold.display-md {\n  font-weight: 700 !important;\n}\n\n.bold.h1 {\n  font-weight: 700 !important;\n}\n\n.bold.h2 {\n  font-weight: 700 !important;\n}\n\n.bold.h3 {\n  font-weight: 700 !important;\n}\n\n.bold.h4 {\n  font-weight: 700 !important;\n}\n\n.bold.h5 {\n  font-weight: 700 !important;\n}\n\n.bold.h6 {\n  font-weight: 700 !important;\n}\n\n.bold.body-l {\n  font-weight: 700 !important;\n}\n\n.bold.body-n {\n  font-weight: 700 !important;\n}\n\n.bold.body-sm {\n  font-weight: 700 !important;\n}\n\n.bold.body-xs {\n  font-weight: 700 !important;\n}\n\n@font-face {\n  font-family: \"Allianz Neo\";\n  font-style: normal;\n  font-weight: 300;\n  font-display: swap;\n  src: url('AllianzNeoW04-Light.woff2') format(\"woff2\"), url('AllianzNeoW04-Light.woff') format(\"woff\");\n}\n\n@font-face {\n  font-family: \"Allianz Neo\";\n  font-style: italic;\n  font-weight: 300;\n  font-display: swap;\n  src: url('AllianzNeoW04-LightItalic.woff2') format(\"woff2\"), url('AllianzNeoW04-LightItalic.woff') format(\"woff\");\n}\n\n@font-face {\n  font-family: \"Allianz Neo\";\n  font-style: normal;\n  font-weight: 400;\n  font-display: swap;\n  src: url('AllianzNeoW04-Regular.woff2') format(\"woff2\"), url('AllianzNeoW04-Regular.woff') format(\"woff\");\n}\n\n@font-face {\n  font-family: \"Allianz Neo\";\n  font-style: italic;\n  font-weight: 400;\n  font-display: swap;\n  src: url('AllianzNeoW04-Italic.woff2') format(\"woff2\"), url('AllianzNeoW04-Italic.woff') format(\"woff\");\n}\n\n@font-face {\n  font-family: \"Allianz Neo\";\n  font-style: normal;\n  font-weight: 600;\n  font-display: swap;\n  src: url('AllianzNeoW04-SemiBold.woff2') format(\"woff2\"), url('AllianzNeoW04-SemiBold.woff') format(\"woff\");\n}\n\n@font-face {\n  font-family: \"Allianz Neo\";\n  font-style: italic;\n  font-weight: 600;\n  font-display: swap;\n  src: url('AllianzNeoW04-SemiBoldIt.woff2') format(\"woff2\"), url('AllianzNeoW04-SemiBoldIt.woff') format(\"woff\");\n}\n\n@font-face {\n  font-family: \"Allianz Neo\";\n  font-style: normal;\n  font-weight: 700;\n  font-display: swap;\n  src: url('AllianzNeoW04-Bold.woff2') format(\"woff2\"), url('AllianzNeoW04-Bold.woff') format(\"woff\");\n}\n\n@font-face {\n  font-family: \"Allianz Neo\";\n  font-style: italic;\n  font-weight: 700;\n  font-display: swap;\n  src: url('AllianzNeoW04-BoldItalic.woff2') format(\"woff2\"), url('AllianzNeoW04-BoldItalic.woff') format(\"woff\");\n}\n\n* {\n  color: var(--nc-color-nextgen-neutral-grey);\n  font-family: \"Allianz Neo\", sans-serif;\n  font-weight: 400;\n  font-size: 16px;\n}\n\nhtml {\n  --ion-safe-area-top: 0px;\n}\n\n.col-1 {\n  width: 8.33%;\n}\n\n.col-2 {\n  width: 16.66%;\n}\n\n.col-3 {\n  width: 25%;\n}\n\n.col-4 {\n  width: 33.33%;\n}\n\n.col-5 {\n  width: 41.66%;\n}\n\n.col-6 {\n  width: 50%;\n}\n\n.col-7 {\n  width: 58.33%;\n}\n\n.col-8 {\n  width: 66.66%;\n}\n\n.col-9 {\n  width: 75%;\n}\n\n.col-10 {\n  width: 83.33%;\n}\n\n.col-11 {\n  width: 91.66%;\n}\n\n.col-12 {\n  width: 100%;\n}\n\n@media only screen and (max-width: 576px) {\n  /* For tablets: */\n  .col-sm-1 {\n    width: 8.33%;\n  }\n\n  .col-sm-2 {\n    width: 16.66%;\n  }\n\n  .col-sm-3 {\n    width: 25%;\n  }\n\n  .col-sm-4 {\n    width: 33.33%;\n  }\n\n  .col-sm-5 {\n    width: 41.66%;\n  }\n\n  .col-sm-6 {\n    width: 50%;\n  }\n\n  .col-sm-7 {\n    width: 58.33%;\n  }\n\n  .col-sm-8 {\n    width: 66.66%;\n  }\n\n  .col-sm-9 {\n    width: 75%;\n  }\n\n  .col-sm-10 {\n    width: 83.33%;\n  }\n\n  .col-sm-11 {\n    width: 91.66%;\n  }\n\n  .col-sm-12 {\n    width: 100%;\n  }\n}\n\n@media only screen and (max-width: 768px) and (min-width: 577px) {\n  /* For tablets: */\n  .col-md-1 {\n    width: 8.33%;\n  }\n\n  .col-md-2 {\n    width: 16.66%;\n  }\n\n  .col-md-3 {\n    width: 25%;\n  }\n\n  .col-md-4 {\n    width: 33.33%;\n  }\n\n  .col-md-5 {\n    width: 41.66%;\n  }\n\n  .col-md-6 {\n    width: 50%;\n  }\n\n  .col-md-7 {\n    width: 58.33%;\n  }\n\n  .col-md-8 {\n    width: 66.66%;\n  }\n\n  .col-md-9 {\n    width: 75%;\n  }\n\n  .col-md-10 {\n    width: 83.33%;\n  }\n\n  .col-md-11 {\n    width: 91.66%;\n  }\n\n  .col-md-12 {\n    width: 100%;\n  }\n}\n\n@media only screen and (min-width: 769px) {\n  /* For tablets: */\n  .col-lg-1 {\n    width: 8.33%;\n  }\n\n  .col-lg-2 {\n    width: 16.66%;\n  }\n\n  .col-lg-3 {\n    width: 25%;\n  }\n\n  .col-lg-4 {\n    width: 33.33%;\n  }\n\n  .col-lg-5 {\n    width: 41.66%;\n  }\n\n  .col-lg-6 {\n    width: 50%;\n  }\n\n  .col-lg-7 {\n    width: 58.33%;\n  }\n\n  .col-lg-8 {\n    width: 66.66%;\n  }\n\n  .col-lg-9 {\n    width: 75%;\n  }\n\n  .col-lg-10 {\n    width: 83.33%;\n  }\n\n  .col-lg-11 {\n    width: 91.66%;\n  }\n\n  .col-lg-12 {\n    width: 100%;\n  }\n}\n\n.row {\n  display: flex;\n  justify-content: center;\n  align-items: center;\n}\n\n.custom-toast {\n  --max-width: fit-content;\n}\n\n/*\n * 2. Custom CSS for compatibility with Edge\n * ----------------------------------------------------------------------------\n */\n\ninput::-ms-reveal,\ninput::-ms-clear {\n  display: none;\n}\n\n.swal2-popup {\n  margin-top: 20px;\n}\n\n/*\n * 3. Custom CSS for loading controller\n * ----------------------------------------------------------------------------\n */\n\n.transparent-loading-class {\n  --background: transparent;\n  --spinner-color: #47e6b1;\n}\n\n.loading-wrapper.sc-ion-loading-md {\n  box-shadow: unset;\n  -webkit-box-shadow: unset;\n}\n\n.uil {\n  color: var(--nc-color-nextgen-grey);\n}\n\n.btn {\n  height: 48px;\n  border-radius: 28px;\n  padding: 0px 41px 0px 41px;\n  box-shadow: none;\n}\n\n.btn.btn-circle {\n  background-color: var(--nc-color-nextgen-stone-grey) !important;\n  color: var(--nc-color-nextgen-black);\n  padding: unset !important;\n  height: 36px !important;\n  width: 36px !important;\n  border-radius: 50% !important;\n}\n\n.btn.btn-circle i {\n  color: var(--nc-color-nextgen-black);\n}\n\n.btn.primary {\n  background: var(--nc-color-nextgen-green);\n  color: var(--nc-color-nextgen-white);\n}\n\n.btn.primary .uil {\n  color: var(--nc-color-nextgen-white);\n}\n\n.btn.primary:disabled {\n  background-color: var(--nc-color-nextgen-grey-background) !important;\n  color: var(--nc-color-nextgen-grey) !important;\n}\n\n.btn.secondary {\n  background: var(--nc-color-nextgen-white) !important;\n  border-color: var(--nc-color-nextgen-green);\n  border: solid 1px;\n  color: var(--nc-color-nextgen-green);\n}\n\n.btn.secondary .uil {\n  color: var(--nc-color-nextgen-green);\n}\n\n.btn.secondary:disabled {\n  background-color: var(--nc-color-nextgen-white) !important;\n  color: var(--nc-color-nextgen-grey) !important;\n  border-color: var(--nc-color-nextgen-grey-background) !important;\n}\n\n.btn.transparent {\n  background: transparent !important;\n  border-color: var(--nc-color-nextgen-green);\n  border: solid 1px;\n  color: var(--nc-color-nextgen-green);\n}\n\n.btn.transparent .uil {\n  color: var(--nc-color-nextgen-green);\n}\n\n.btn.transparent:disabled {\n  background-color: transparent !important;\n  color: var(--nc-color-nextgen-grey) !important;\n  border-color: var(--nc-color-nextgen-grey-background) !important;\n}\n\n.btn.btn-large {\n  height: 56px !important;\n  width: 100%;\n}\n\n.btn.bold {\n  font-weight: 700 !important;\n}\n\n.btn.semibold {\n  font-weight: 600 !important;\n}\n\n.btn-no-space {\n  padding: 5px !important;\n  height: -moz-fit-content;\n  height: fit-content;\n}\n\n.btn-back {\n  width: 31px;\n  height: 28px;\n  background-color: transparent;\n  padding: 0;\n  color: var(--nc-color-nextgen-green);\n}\n\n.container {\n  padding: 2rem;\n  height: 100%;\n}\n\n.body-section {\n  width: 100%;\n  height: 95%;\n  overflow-y: auto;\n  position: relative;\n}\n\n.top-section {\n  width: 100%;\n  height: 10%;\n  justify-content: space-between;\n  display: flex;\n  align-items: center;\n}\n\n.form-control {\n  position: relative;\n  height: 85px;\n  margin-bottom: 8px;\n}\n\n.control {\n  border-radius: 8px;\n  height: 56px;\n  border: 1px solid var(--nc-color-nextgen-grey-background);\n  width: 100%;\n  position: absolute;\n  top: 32px;\n  background-color: var(--nc-color-nextgen-white);\n}\n\n.control table {\n  table-layout: fixed;\n  border-collapse: unset;\n}\n\n.control input {\n  height: 54px;\n  border: unset;\n  border-radius: 8px;\n  width: max-content;\n  width: 100%;\n  pointer-events: auto;\n  background-color: var(--nc-color-nextgen-white);\n}\n\n.control.textarea {\n  height: 108px;\n}\n\n.control textarea {\n  height: 106px;\n  border: unset;\n  border-radius: 8px;\n  width: max-content;\n  width: 100%;\n  pointer-events: auto;\n  resize: none;\n  background-color: var(--nc-color-nextgen-white);\n}\n\n.control input:focus {\n  outline: none;\n}\n\n.control:focus-within {\n  border-color: var(--nc-color-nextgen-green);\n}\n\n.control:focus-within .first-icon {\n  display: none;\n}\n\n.control:focus-within .first-icon.non-hidden {\n  display: table-cell;\n}\n\n.control .first-icon {\n  width: 32px;\n  text-align: center;\n  padding-left: 8px;\n}\n\n.control .first-icon i {\n  font-size: 24px !important;\n}\n\n.control .second-icon {\n  width: 32px;\n  text-align: center;\n}\n\n.control .second-icon i {\n  font-size: 24px !important;\n}\n\n.control:focus-within ~ div .control-label {\n  color: var(--nc-color-nextgen-green);\n}\n\n.control-error .control {\n  border-color: var(--nc-color-nextgen-error);\n}\n\n.control-error .control-label {\n  color: var(--nc-color-nextgen-error) !important;\n}\n\n.validation-summary li {\n  color: var(--nc-color-nextgen-error) !important;\n  list-style: none;\n}\n\n.validation-summary li i {\n  color: var(--nc-color-nextgen-error) !important;\n}\n\n.mr-1 {\n  margin-right: 0.5rem;\n}\n\n.mb-1 {\n  margin-bottom: 0.5rem;\n}\n\n.dialog-pane {\n  position: absolute;\n  pointer-events: auto;\n  box-sizing: border-box;\n  z-index: 1000;\n  display: block;\n  max-width: 100%;\n  max-height: 100%;\n}\n\n.overlay-backdrop {\n  background-color: var(--nc-color-nextgen-neutral-grey);\n  opacity: 0.2 !important;\n}\n\n.dialog-container {\n  animation: fadeIn 0.5s linear;\n  background-color: var(--nc-color-nextgen-white);\n}\n\n@keyframes fadeIn {\n  from {\n    transform: translateY(100%);\n  }\n  to {\n    transform: translateY(0%);\n  }\n}\n\n.error {\n  color: var(--nc-color-nextgen-error);\n}\n\n.error.background {\n  background-color: var(--nc-color-nextgen-error);\n}\n\n.success {\n  color: var(--nc-color-nextgen-fibrant-green);\n}\n\n.success.background {\n  background-color: var(--nc-color-nextgen-fibrant-green);\n}\n\n.warning {\n  color: var(--nc-color-nextgen-warning);\n}\n\n.warning.background {\n  background-color: var(--nc-color-nextgen-warning);\n}\n\n.select {\n  width: 100%;\n  height: 54px;\n  border: unset;\n  border-radius: 8px;\n  display: grid;\n  -webkit-appearance: none;\n          appearance: none;\n  grid-template-areas: \"select\";\n}\n\n.select:focus {\n  outline: unset;\n}\n\n.color-black {\n  color: var(--nc-color-nextgen-black);\n}\n\n.modal-default {\n  --width: 100%;\n  --height: 100%;\n}\n\n.integration-panel {\n  width: 100%;\n  height: 100%;\n  max-width: 100% !important;\n}\n\n.verloop-button {\n  visibility: hidden;\n}\n\n.back-area {\n  position: fixed;\n  top: 0;\n  right: 0;\n  height: 50px;\n  width: 100%;\n  background-color: var(--nc-color-nextgen-neutral-grey-50);\n  z-index: 9999999;\n}\n\n.back-area.ios {\n  height: 80px;\n}\n\n.title-widget {\n  text-align: center;\n  position: sticky;\n  top: 48px;\n}\n\n.button-back {\n  background-color: #fafafa;\n  height: 36px;\n  width: 36px;\n  border-radius: 50%;\n  position: absolute;\n  left: 18px;\n  bottom: 4px;\n}\n\n.icon-close-widget {\n  position: absolute;\n  z-index: 250;\n  left: 11px;\n  bottom: 13px;\n}\n\n.data-default {\n  position: absolute;\n  top: 50%;\n  left: 50%;\n  transform: translate(-50%, -50%);\n  text-align: center;\n  color: var(--nc-color-nextgen-neutral-grey-400);\n  z-index: 1000;\n}\n\n.avaamo__icon {\n  visibility: hidden !important;\n}\n\n.avaamo__chat__widget.ios #avaamo__popup {\n  padding-top: 40px;\n}\n\n.d-flex {\n  display: flex;\n}\n\nnextcare-layout {\n  left: 0;\n  right: 0;\n  top: 0;\n  bottom: 0;\n  display: flex;\n  position: absolute;\n  flex-direction: column;\n  justify-content: space-between;\n  contain: layout size style;\n  overflow: hidden;\n  background-color: var(--nc-color-nextgen-neutral-grey-50);\n  padding-right: 24px;\n  padding-left: 24px;\n}\n\nion-header.ios.header-ios {\n  margin-top: 40px;\n}\n\n.header-ios ion-toolbar:last-of-type {\n  --border-width: 0px !important;\n}\n\n.header-md.md::after {\n  display: none;\n}\n\nion-toolbar {\n  padding-right: unset !important;\n  padding-left: unset !important;\n}\n\ni.icon-back {\n  content: url('long-arrow-left-icon.svg');\n}\n\n.verloop-widget.ios .verloop-container.visible {\n  height: calc(100% - 40px);\n  top: 40px;\n}\n\n#nextcare-ads {\n  display: none;\n  overflow: scroll;\n  height: 180px;\n}\n\n.d-block {\n  display: block;\n}\n\n.title-text {\n  color: var(--nc-color-nextgen-blue);\n}\n\n:host ion-datetime #shadow-root .datetime-calendar .calendar-header .calendar-action-buttons .calendar-month-year {\n  align-items: center;\n  justify-content: center;\n  display: flex;\n  width: 100%;\n}\n\n:host ion-datetime #shadow-root .datetime-calendar .calendar-header .calendar-action-buttons .calendar-month-year ion-icon {\n  display: none;\n}\n\n:host ion-datetime #shadow-root .datetime-calendar .calendar-header .calendar-action-buttons .calendar-next-prev {\n  position: absolute;\n  width: 100%;\n  right: 0;\n}\n\n:host ion-datetime #shadow-root .datetime-calendar .calendar-header .calendar-action-buttons .calendar-next-prev ion-buttons {\n  display: flex;\n  justify-content: space-between;\n  width: 100%;\n}\n\n.mat-dialog-container {\n  padding: unset !important;\n}\n\n/* Change autocomplete styles in WebKit */\n\ninput:-webkit-autofill,\ninput:-webkit-autofill:hover,\ninput:-webkit-autofill:focus,\ntextarea:-webkit-autofill,\ntextarea:-webkit-autofill:hover,\ntextarea:-webkit-autofill:focus,\nselect:-webkit-autofill,\nselect:-webkit-autofill:hover,\nselect:-webkit-autofill:focus {\n  -webkit-text-fill-color: black;\n  -webkit-box-shadow: 0 0 0px 1000px white inset;\n  -webkit-transition: background-color 5000s ease-in-out 0s;\n  transition: background-color 5000s ease-in-out 0s;\n}\n\n.force-update-popup + .cdk-global-overlay-wrapper .save-btn {\n  background: var(--lumi-primary-yellow-color) !important;\n  color: var(--lumi-white-color) !important;\n  font-weight: bold !important;\n}\n\n.force-update-popup + .cdk-global-overlay-wrapper .cancel-btn {\n  color: var(--lumi-primary-yellow-color) !important;\n}\n\n@keyframes slideInRight {\n  0% {\n    transform: translate3d(100%, 0, 0);\n    visibility: visible;\n  }\n  to {\n    transform: translateZ(0);\n  }\n}\n\n.animate__slideInRight {\n  animation-name: slideInRight;\n}\n\n.animate__animated {\n  animation-duration: 0.5s;\n  animation-duration: 0.5s;\n  animation-fill-mode: both;\n}\n\nion-content {\n  --background: #F1EFEF;\n}\n\n.disclosure-accident-main {\n  margin-bottom: 128px;\n}\n\n.disclosure-accident-main .disclosure-accident-content .detail-content {\n  margin-bottom: 1rem;\n}\n\n.disclosure-accident-main .disclosure-accident-content .detail-content .detail-title {\n  margin-bottom: 0.2rem;\n}\n\n.disclosure-accident-main .disclosure-accident-content .detail-content-accidentDesc {\n  padding-bottom: 1rem;\n}\n\n.disclosure-accident-main .disclosure-accident-content .text-box {\n  margin-bottom: 2rem;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFxjb2xvci5zY3NzIiwiZGlzY2xvc3VyZS1hY2NpZGVudC5jb21wb25lbnQuc2NzcyIsIi4uXFwuLlxcLi5cXC4uXFxzdHlsZS5zY3NzIiwiLi5cXC4uXFwuLlxcLi5cXGZvbnQtc2l6ZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0MsdUNBQUE7RUFDQSxnQ0FBQTtFQUNBLGdDQUFBO0VBQ0EsaUNBQUE7RUFDQSxpQ0FBQTtFQUNBLDJDQUFBO0VBQ0EsZ0NBQUE7RUFDQSxzQ0FBQTtFQUNBLGlDQUFBO0VBQ0Esd0NBQUE7RUFDQSx5Q0FBQTtFQUNBLG1DQUFBO0VBQ0EsNENBQUE7RUFDQSw0Q0FBQTtFQUNBLDRDQUFBO0VBQ0Esd0NBQUE7RUFDQSxtREFBQTtFQUNBLDBDQUFBO0VBQ0EscURBQUE7RUFDQSxvQ0FBQTtFQUNBLHlDQUFBO0VBQ0Esb0NBQUE7RUFDQSxvQ0FBQTtFQUNBLG1DQUFBO0VBQ0EsOENBQUE7RUFFQSwyQkFBQTtFQUNBLG9DQUFBO0FDQUQ7O0FEZ0NBO0VBQ0MsK0NBQUE7RUFDQSxtREFBQTtFQUNBLG1EQUFBO0VBQ0EsdURBQUE7RUFDQSxnREFBQTtFQUNBLCtDQUFBO0FDN0JEOztBQ3JDQTs7O0VBQUE7O0FGQUE7RUFDQyx1Q0FBQTtFQUNBLGdDQUFBO0VBQ0EsZ0NBQUE7RUFDQSxpQ0FBQTtFQUNBLGlDQUFBO0VBQ0EsMkNBQUE7RUFDQSxnQ0FBQTtFQUNBLHNDQUFBO0VBQ0EsaUNBQUE7RUFDQSx3Q0FBQTtFQUNBLHlDQUFBO0VBQ0EsbUNBQUE7RUFDQSw0Q0FBQTtFQUNBLDRDQUFBO0VBQ0EsNENBQUE7RUFDQSx3Q0FBQTtFQUNBLG1EQUFBO0VBQ0EsMENBQUE7RUFDQSxxREFBQTtFQUNBLG9DQUFBO0VBQ0EseUNBQUE7RUFDQSxvQ0FBQTtFQUNBLG9DQUFBO0VBQ0EsbUNBQUE7RUFDQSw4Q0FBQTtFQUVBLDJCQUFBO0VBQ0Esb0NBQUE7QUMyQ0Q7O0FEWEE7RUFDQywrQ0FBQTtFQUNBLG1EQUFBO0VBQ0EsbURBQUE7RUFDQSx1REFBQTtFQUNBLGdEQUFBO0VBQ0EsK0NBQUE7QUNjRDs7QUVoRkE7RUFDSSwwQkFBQTtFQUNBLDJCQUFBO0VBQ0EsNEJBQUE7QUZtRko7O0FFaEZBO0VBQ0ksMEJBQUE7RUFDQSwyQkFBQTtFQUNBLDRCQUFBO0FGbUZKOztBRWhGQTtFQUNJLDBCQUFBO0VBQ0EsMkJBQUE7RUFDQSw0QkFBQTtBRm1GSjs7QUVoRkE7RUFDSSwwQkFBQTtFQUNBLDJCQUFBO0VBQ0EsNEJBQUE7QUZtRko7O0FFaEZBO0VBQ0ksMEJBQUE7RUFDQSwyQkFBQTtFQUNBLDRCQUFBO0FGbUZKOztBRWhGQTtFQUNJLDBCQUFBO0VBQ0EsMkJBQUE7RUFDQSw0QkFBQTtBRm1GSjs7QUVoRkE7RUFDSSwwQkFBQTtFQUNBLDJCQUFBO0VBQ0EsNEJBQUE7QUZtRko7O0FFaEZBO0VBQ0ksMEJBQUE7RUFDQSwyQkFBQTtFQUNBLDRCQUFBO0FGbUZKOztBRWhGQTtFQUNJLDBCQUFBO0VBQ0EsMkJBQUE7RUFDQSw0QkFBQTtBRm1GSjs7QUVoRkE7RUFDSSwwQkFBQTtFQUNBLDJCQUFBO0VBQ0EsNEJBQUE7QUZtRko7O0FFaEZBO0VBQ0ksMEJBQUE7RUFDQSwyQkFBQTtFQUNBLDRCQUFBO0FGbUZKOztBRWhGQTtFQUNJLDBCQUFBO0VBQ0EsMkJBQUE7RUFDQSw0QkFBQTtBRm1GSjs7QUUvRUk7RUFDSSwyQkFBQTtBRmtGUjs7QUVoRkk7RUFDSSwyQkFBQTtBRmtGUjs7QUVoRkk7RUFDSSwyQkFBQTtBRmtGUjs7QUVoRkk7RUFDSSwyQkFBQTtBRmtGUjs7QUVoRkk7RUFDSSwyQkFBQTtBRmtGUjs7QUVoRkk7RUFDSSwyQkFBQTtBRmtGUjs7QUVoRkk7RUFDSSwyQkFBQTtBRmtGUjs7QUVoRkk7RUFDSSwyQkFBQTtBRmtGUjs7QUVoRkk7RUFDSSwyQkFBQTtBRmtGUjs7QUVoRkk7RUFDSSwyQkFBQTtBRmtGUjs7QUVoRkk7RUFDSSwyQkFBQTtBRmtGUjs7QUVoRkk7RUFDSSwyQkFBQTtBRmtGUjs7QUU3RUk7RUFDSSwyQkFBQTtBRmdGUjs7QUU5RUk7RUFDSSwyQkFBQTtBRmdGUjs7QUU5RUk7RUFDSSwyQkFBQTtBRmdGUjs7QUU5RUk7RUFDSSwyQkFBQTtBRmdGUjs7QUU5RUk7RUFDSSwyQkFBQTtBRmdGUjs7QUU5RUk7RUFDSSwyQkFBQTtBRmdGUjs7QUU5RUk7RUFDSSwyQkFBQTtBRmdGUjs7QUU5RUk7RUFDSSwyQkFBQTtBRmdGUjs7QUU5RUk7RUFDSSwyQkFBQTtBRmdGUjs7QUU5RUk7RUFDSSwyQkFBQTtBRmdGUjs7QUU5RUk7RUFDSSwyQkFBQTtBRmdGUjs7QUU5RUk7RUFDSSwyQkFBQTtBRmdGUjs7QUN2TkE7RUFDQywwQkFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrQkFBQTtFQUNBLHFHQUFBO0FEME5EOztBQ3BOQTtFQUNDLDBCQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtFQUNBLGtCQUFBO0VBQ0EsaUhBQUE7QURzTkQ7O0FDaE5BO0VBQ0MsMEJBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0Esa0JBQUE7RUFDQSx5R0FBQTtBRGtORDs7QUM1TUE7RUFDQywwQkFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrQkFBQTtFQUNBLHVHQUFBO0FEOE1EOztBQ3hNQTtFQUNDLDBCQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtFQUNBLGtCQUFBO0VBQ0EsMkdBQUE7QUQwTUQ7O0FDcE1BO0VBQ0MsMEJBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0Esa0JBQUE7RUFDQSwrR0FBQTtBRHNNRDs7QUNoTUE7RUFDQywwQkFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrQkFBQTtFQUNBLG1HQUFBO0FEa01EOztBQzVMQTtFQUNDLDBCQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtFQUNBLGtCQUFBO0VBQ0EsK0dBQUE7QUQ4TEQ7O0FDeExBO0VBQ0MsMkNGOUQ0QjtFRStENUIsc0NBQUE7RUFDQSxnQkFBQTtFQUNBLGVBQUE7QUQwTEQ7O0FDdkxBO0VBQ0Msd0JBQUE7QUQwTEQ7O0FDdkxBO0VBQ0MsWUFBQTtBRDBMRDs7QUN2TEE7RUFDQyxhQUFBO0FEMExEOztBQ3ZMQTtFQUNDLFVBQUE7QUQwTEQ7O0FDdkxBO0VBQ0MsYUFBQTtBRDBMRDs7QUN2TEE7RUFDQyxhQUFBO0FEMExEOztBQ3ZMQTtFQUNDLFVBQUE7QUQwTEQ7O0FDdkxBO0VBQ0MsYUFBQTtBRDBMRDs7QUN2TEE7RUFDQyxhQUFBO0FEMExEOztBQ3ZMQTtFQUNDLFVBQUE7QUQwTEQ7O0FDdkxBO0VBQ0MsYUFBQTtBRDBMRDs7QUN2TEE7RUFDQyxhQUFBO0FEMExEOztBQ3ZMQTtFQUNDLFdBQUE7QUQwTEQ7O0FDdkxBO0VBQ0MsaUJBQUE7RUFDQTtJQUNDLFlBQUE7RUQwTEE7O0VDdkxEO0lBQ0MsYUFBQTtFRDBMQTs7RUN2TEQ7SUFDQyxVQUFBO0VEMExBOztFQ3ZMRDtJQUNDLGFBQUE7RUQwTEE7O0VDdkxEO0lBQ0MsYUFBQTtFRDBMQTs7RUN2TEQ7SUFDQyxVQUFBO0VEMExBOztFQ3ZMRDtJQUNDLGFBQUE7RUQwTEE7O0VDdkxEO0lBQ0MsYUFBQTtFRDBMQTs7RUN2TEQ7SUFDQyxVQUFBO0VEMExBOztFQ3ZMRDtJQUNDLGFBQUE7RUQwTEE7O0VDdkxEO0lBQ0MsYUFBQTtFRDBMQTs7RUN2TEQ7SUFDQyxXQUFBO0VEMExBO0FBQ0Y7O0FDdkxBO0VBQ0MsaUJBQUE7RUFDQTtJQUNDLFlBQUE7RUR5TEE7O0VDdExEO0lBQ0MsYUFBQTtFRHlMQTs7RUN0TEQ7SUFDQyxVQUFBO0VEeUxBOztFQ3RMRDtJQUNDLGFBQUE7RUR5TEE7O0VDdExEO0lBQ0MsYUFBQTtFRHlMQTs7RUN0TEQ7SUFDQyxVQUFBO0VEeUxBOztFQ3RMRDtJQUNDLGFBQUE7RUR5TEE7O0VDdExEO0lBQ0MsYUFBQTtFRHlMQTs7RUN0TEQ7SUFDQyxVQUFBO0VEeUxBOztFQ3RMRDtJQUNDLGFBQUE7RUR5TEE7O0VDdExEO0lBQ0MsYUFBQTtFRHlMQTs7RUN0TEQ7SUFDQyxXQUFBO0VEeUxBO0FBQ0Y7O0FDdExBO0VBQ0MsaUJBQUE7RUFDQTtJQUNDLFlBQUE7RUR3TEE7O0VDckxEO0lBQ0MsYUFBQTtFRHdMQTs7RUNyTEQ7SUFDQyxVQUFBO0VEd0xBOztFQ3JMRDtJQUNDLGFBQUE7RUR3TEE7O0VDckxEO0lBQ0MsYUFBQTtFRHdMQTs7RUNyTEQ7SUFDQyxVQUFBO0VEd0xBOztFQ3JMRDtJQUNDLGFBQUE7RUR3TEE7O0VDckxEO0lBQ0MsYUFBQTtFRHdMQTs7RUNyTEQ7SUFDQyxVQUFBO0VEd0xBOztFQ3JMRDtJQUNDLGFBQUE7RUR3TEE7O0VDckxEO0lBQ0MsYUFBQTtFRHdMQTs7RUNyTEQ7SUFDQyxXQUFBO0VEd0xBO0FBQ0Y7O0FDckxBO0VBQ0MsYUFBQTtFQUNBLHVCQUFBO0VBQ0EsbUJBQUE7QUR1TEQ7O0FDbkxBO0VBQ0Msd0JBQUE7QURzTEQ7O0FDbkxBOzs7RUFBQTs7QUFJQTs7RUFFQyxhQUFBO0FEc0xEOztBQ25MQTtFQUNDLGdCQUFBO0FEc0xEOztBQ25MQTs7O0VBQUE7O0FBSUE7RUFDQyx5QkFBQTtFQUNBLHdCQUFBO0FEc0xEOztBQ25MQTtFQUNDLGlCQUFBO0VBQ0EseUJBQUE7QURzTEQ7O0FDbkxBO0VBQ0MsbUNGM1RvQjtBQ2lmckI7O0FDbkxBO0VBQ0MsWUFBQTtFQUNBLG1CQUFBO0VBQ0EsMEJBQUE7RUFDQSxnQkFBQTtBRHNMRDs7QUNwTEM7RUFDQywrREFBQTtFQUNBLG9DRnhVb0I7RUV5VXBCLHlCQUFBO0VBQ0EsdUJBQUE7RUFDQSxzQkFBQTtFQUNBLDZCQUFBO0FEc0xGOztBQ3BMRTtFQUNDLG9DRi9VbUI7QUNxZ0J0Qjs7QUNsTEM7RUFDQyx5Q0Z0Vm9CO0VFdVZwQixvQ0Z0Vm9CO0FDMGdCdEI7O0FDbExFO0VBQ0Msb0NGelZtQjtBQzZnQnRCOztBQ2pMRTtFQUNDLG9FQUFBO0VBQ0EsOENBQUE7QURtTEg7O0FDL0tDO0VBQ0Msb0RBQUE7RUFDQSwyQ0ZyV29CO0VFc1dwQixpQkFBQTtFQUNBLG9DRnZXb0I7QUN3aEJ0Qjs7QUMvS0U7RUFDQyxvQ0YxV21CO0FDMmhCdEI7O0FDOUtFO0VBQ0MsMERBQUE7RUFDQSw4Q0FBQTtFQUNBLGdFQUFBO0FEZ0xIOztBQzVLQztFQUNDLGtDQUFBO0VBQ0EsMkNGdFhvQjtFRXVYcEIsaUJBQUE7RUFDQSxvQ0Z4WG9CO0FDc2lCdEI7O0FDNUtFO0VBQ0Msb0NGM1htQjtBQ3lpQnRCOztBQzNLRTtFQUNDLHdDQUFBO0VBQ0EsOENBQUE7RUFDQSxnRUFBQTtBRDZLSDs7QUN6S0M7RUFDQyx1QkFBQTtFQUNBLFdBQUE7QUQyS0Y7O0FDeEtDO0VBQ0MsMkJBQUE7QUQwS0Y7O0FDdktDO0VBQ0MsMkJBQUE7QUR5S0Y7O0FDcktBO0VBQ0MsdUJBQUE7RUFDQSx3QkFBQTtFQUFBLG1CQUFBO0FEd0tEOztBQ3JLQTtFQUNDLFdBQUE7RUFDQSxZQUFBO0VBQ0EsNkJBQUE7RUFDQSxVQUFBO0VBQ0Esb0NGN1pxQjtBQ3FrQnRCOztBQ3JLQTtFQUNDLGFBQUE7RUFDQSxZQUFBO0FEd0tEOztBQ3JLQTtFQUNDLFdBQUE7RUFDQSxXQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrQkFBQTtBRHdLRDs7QUNyS0E7RUFDQyxXQUFBO0VBQ0EsV0FBQTtFQUNBLDhCQUFBO0VBQ0EsYUFBQTtFQUNBLG1CQUFBO0FEd0tEOztBQ3JLQTtFQUNDLGtCQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0FEd0tEOztBQ3JLQTtFQUNDLGtCQUFBO0VBQ0EsWUFBQTtFQUNBLHlEQUFBO0VBQ0EsV0FBQTtFQUNBLGtCQUFBO0VBQ0EsU0FBQTtFQUNBLCtDRmhjcUI7QUN3bUJ0Qjs7QUN0S0M7RUFDQyxtQkFBQTtFQUNBLHNCQUFBO0FEd0tGOztBQ3JLQztFQUNDLFlBQUE7RUFDQSxhQUFBO0VBQ0Esa0JBQUE7RUFDQSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxvQkFBQTtFQUNBLCtDRjljb0I7QUNxbkJ0Qjs7QUNwS0M7RUFDQyxhQUFBO0FEc0tGOztBQ25LQztFQUNDLGFBQUE7RUFDQSxhQUFBO0VBQ0Esa0JBQUE7RUFDQSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxvQkFBQTtFQUNBLFlBQUE7RUFDQSwrQ0Y3ZG9CO0FDa29CdEI7O0FDbEtDO0VBQ0MsYUFBQTtBRG9LRjs7QUNqS0M7RUFDQywyQ0Z0ZW9CO0FDeW9CdEI7O0FDaktFO0VBQ0MsYUFBQTtBRG1LSDs7QUNoS0U7RUFDQyxtQkFBQTtBRGtLSDs7QUM5SkM7RUFDQyxXQUFBO0VBQ0Esa0JBQUE7RUFDQSxpQkFBQTtBRGdLRjs7QUM5SkU7RUFDQywwQkFBQTtBRGdLSDs7QUM1SkM7RUFDQyxXQUFBO0VBQ0Esa0JBQUE7QUQ4SkY7O0FDM0pFO0VBQ0MsMEJBQUE7QUQ2Skg7O0FDeEpBO0VBQ0Msb0NGdmdCcUI7QUNrcUJ0Qjs7QUN2SkM7RUFDQywyQ0Z0Z0JvQjtBQ2dxQnRCOztBQ3ZKQztFQUNDLCtDQUFBO0FEeUpGOztBQ3BKQztFQUNDLCtDQUFBO0VBQ0EsZ0JBQUE7QUR1SkY7O0FDckpFO0VBQ0MsK0NBQUE7QUR1Skg7O0FDbEpBO0VBQ0Msb0JBQUE7QURxSkQ7O0FDbEpBO0VBQ0MscUJBQUE7QURxSkQ7O0FDbEpBO0VBQ0Msa0JBQUE7RUFDQSxvQkFBQTtFQUNBLHNCQUFBO0VBQ0EsYUFBQTtFQUNBLGNBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7QURxSkQ7O0FDbEpBO0VBQ0Msc0RGM2lCNEI7RUU0aUI1Qix1QkFBQTtBRHFKRDs7QUNsSkE7RUFDQyw2QkFBQTtFQUNBLCtDRnZqQnFCO0FDNHNCdEI7O0FDbEpBO0VBQ0M7SUFDQywyQkFBQTtFRHFKQTtFQ2xKRDtJQUNDLHlCQUFBO0VEb0pBO0FBQ0Y7O0FDakpBO0VBQ0Msb0NGaGtCcUI7QUNtdEJ0Qjs7QUNqSkM7RUFDQywrQ0Zua0JvQjtBQ3N0QnRCOztBQy9JQTtFQUNDLDRDRnRrQjZCO0FDd3RCOUI7O0FDaEpDO0VBQ0MsdURGemtCNEI7QUMydEI5Qjs7QUM5SUE7RUFDQyxzQ0Y3a0J1QjtBQzh0QnhCOztBQy9JQztFQUNDLGlERmhsQnNCO0FDaXVCeEI7O0FDN0lBO0VBQ0MsV0FBQTtFQUNBLFlBQUE7RUFDQSxhQUFBO0VBQ0Esa0JBQUE7RUFDQSxhQUFBO0VBQ0Esd0JBQUE7VUFBQSxnQkFBQTtFQUNBLDZCQUFBO0FEZ0pEOztBQzlJQztFQUNDLGNBQUE7QURnSkY7O0FDNUlBO0VBQ0Msb0NGMW1CcUI7QUN5dkJ0Qjs7QUM1SUE7RUFDQyxhQUFBO0VBQ0EsY0FBQTtBRCtJRDs7QUM1SUE7RUFDQyxXQUFBO0VBQ0EsWUFBQTtFQUNBLDBCQUFBO0FEK0lEOztBQzVJQTtFQUNDLGtCQUFBO0FEK0lEOztBQzVJQTtFQUNDLGVBQUE7RUFDQSxNQUFBO0VBQ0EsUUFBQTtFQUNBLFlBQUE7RUFDQSxXQUFBO0VBQ0EseURGem5CK0I7RUUwbkIvQixnQkFBQTtBRCtJRDs7QUM3SUM7RUFDQyxZQUFBO0FEK0lGOztBQzNJQTtFQUNDLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxTQUFBO0FEOElEOztBQzNJQTtFQUNDLHlCQUFBO0VBQ0EsWUFBQTtFQUNBLFdBQUE7RUFDQSxrQkFBQTtFQUNBLGtCQUFBO0VBQ0EsVUFBQTtFQUNBLFdBQUE7QUQ4SUQ7O0FDM0lBO0VBQ0Msa0JBQUE7RUFDQSxZQUFBO0VBQ0EsVUFBQTtFQUNBLFlBQUE7QUQ4SUQ7O0FDM0lBO0VBQ0Msa0JBQUE7RUFDQSxRQUFBO0VBQ0EsU0FBQTtFQUNBLGdDQUFBO0VBQ0Esa0JBQUE7RUFDQSwrQ0Y3cEJnQztFRThwQmhDLGFBQUE7QUQ4SUQ7O0FDM0lBO0VBQ0MsNkJBQUE7QUQ4SUQ7O0FDMUlDO0VBQ0MsaUJBQUE7QUQ2SUY7O0FDeklBO0VBQ0MsYUFBQTtBRDRJRDs7QUN6SUE7RUFDQyxPQUFBO0VBQ0EsUUFBQTtFQUNBLE1BQUE7RUFDQSxTQUFBO0VBQ0EsYUFBQTtFQUNBLGtCQUFBO0VBQ0Esc0JBQUE7RUFDQSw4QkFBQTtFQUNBLDBCQUFBO0VBQ0EsZ0JBQUE7RUFDQSx5REYzckIrQjtFRTRyQi9CLG1CQUFBO0VBQ0Esa0JBQUE7QUQ0SUQ7O0FDeklBO0VBQ0MsZ0JBQUE7QUQ0SUQ7O0FDeklBO0VBQ0MsOEJBQUE7QUQ0SUQ7O0FDeklBO0VBQ0MsYUFBQTtBRDRJRDs7QUN6SUE7RUFDQywrQkFBQTtFQUNBLDhCQUFBO0FENElEOztBQ3pJQTtFQUNDLHdDQUFBO0FENElEOztBQ3hJQztFQUNDLHlCQUFBO0VBQ0EsU0FBQTtBRDJJRjs7QUN2SUE7RUFDQyxhQUFBO0VBQ0EsZ0JBQUE7RUFDQSxhQUFBO0FEMElEOztBQ3ZJQTtFQUNDLGNBQUE7QUQwSUQ7O0FDdklBO0VBQ0MsbUNGbnZCb0I7QUM2M0JyQjs7QUNuSUk7RUFDQyxtQkFBQTtFQUNBLHVCQUFBO0VBQ0EsYUFBQTtFQUNBLFdBQUE7QURzSUw7O0FDcElLO0VBQ0MsYUFBQTtBRHNJTjs7QUNsSUk7RUFDQyxrQkFBQTtFQUNBLFdBQUE7RUFDQSxRQUFBO0FEb0lMOztBQ2xJSztFQUNDLGFBQUE7RUFDQSw4QkFBQTtFQUNBLFdBQUE7QURvSU47O0FDNUhBO0VBQ0MseUJBQUE7QUQrSEQ7O0FDNUhBLHlDQUFBOztBQUNBOzs7Ozs7Ozs7RUFTQyw4QkFBQTtFQUNBLDhDQUFBO0VBQ0EseURBQUE7RUFBQSxpREFBQTtBRCtIRDs7QUMzSEM7RUFDQyx1REFBQTtFQUNBLHlDQUFBO0VBQ0EsNEJBQUE7QUQ4SEY7O0FDM0hDO0VBQ0Msa0RBQUE7QUQ2SEY7O0FDNUdBO0VBQ0M7SUFFQyxrQ0FBQTtJQUNBLG1CQUFBO0VEMEhBO0VDdkhEO0lBRUMsd0JBQUE7RUR5SEE7QUFDRjs7QUN0SEE7RUFFQyw0QkFBQTtBRHdIRDs7QUNySEE7RUFFQyx3QkFBQTtFQUVBLHdCQUFBO0VBRUEseUJBQUE7QUR3SEQ7O0FBNStCQTtFQUNJLHFCQUFBO0FBKytCSjs7QUE1K0JBO0VBQ0ksb0JBQUE7QUErK0JKOztBQTErQlE7RUFDSSxtQkFBQTtBQTQrQlo7O0FBMStCWTtFQUNJLHFCQUFBO0FBNCtCaEI7O0FBeCtCUTtFQUNJLG9CQUFBO0FBMCtCWjs7QUF2K0JRO0VBQ0ksbUJBQUE7QUF5K0JaIiwiZmlsZSI6ImRpc2Nsb3N1cmUtYWNjaWRlbnQuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyI6cm9vdCB7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS01MDogcmVkO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi13aGl0ZTogeWVsbG93O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlOiAjMGQxNTJlO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbjogIzAwOTA4ZDtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tYmxhY2s6ICMwMDAwMDA7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWdyZXktYmFja2dyb3VuZDogI2M4ZDNkYTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tZ3JleTogIzkyYTJhYztcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc3RvbmUtZ3JleTogI2ZhZmFmYTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tZXJyb3I6ICNmYzEwNTU7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleTogIzQxNDE0MTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tZmlicmFudC1ncmVlbjogIzAwYmFiNjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4td2FybmluZzogI2ZmZDA0ODtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4tYmFja2dyb3VuZDogI2U2ZjJmMjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTQwMDogIzdhN2E3YTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTEwMDogI2VmZjNmNTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yOiAjYmEwYzNmO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtZXJyb3ItYmFja2dyb3VuZDogI2ZmZWZmNDtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLXdhcm5pbmc6ICNjYmExMjc7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy13YXJuaW5nLWJhY2tncm91bmQ6ICNmZmY4ZTY7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWJsdWUtMTAwOiAjZGZlZmYyO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1lcnJvci1yZWQtNzAwOiAjZjYyNDU5O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlLTUwMDogIzAwNjE5MjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZS00MDA6ICM3OWNkZWM7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXJlZC01MDA6ICNmZjY1OTI7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXNlY29uZGFyeS1ibHVlLTMwMDogIzEzYTBkMztcclxuXHJcblx0LS1sdW1pLXdoaXRlLWNvbG9yOiAjZmZmZmZmO1xyXG5cdC0tbHVtaS1wcmltYXJ5LXllbGxvdy1jb2xvcjogI2ZhYjYwMDtcclxufVxyXG4kY29sb3ItbmV4dGdlbi1ibHVlOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWJsdWUpO1xyXG4kY29sb3ItbmV4dGdlbi1ncmVlbjogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbik7XHJcbiRjb2xvci1uZXh0Z2VuLXdoaXRlOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXdoaXRlKTtcclxuJGNvbG9yLW5leHRnZW4tYmxhY2s6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tYmxhY2spO1xyXG4kY29sb3ItbmV4dGdlbi1ncmV5LWJhY2tncm91bmQ6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JleS1iYWNrZ3JvdW5kKTtcclxuJGNvbG9yLW5leHRnZW4tZ3JleTogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmV5KTtcclxuJGNvbG9yLW5leHRnZW4tc3RvbmUtZ3JleTogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1zdG9uZS1ncmV5KTtcclxuJGNvbG9yLW5leHRnZW4tZXJyb3I6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZXJyb3IpO1xyXG4kY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXk6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5KTtcclxuJGNvbG9yLW5leHRnZW4tZmlicmFudC1ncmVlbjogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1maWJyYW50LWdyZWVuKTtcclxuJGNvbG9yLW5leHRnZW4td2FybmluZzogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi13YXJuaW5nKTtcclxuJGNvbG9yLW5leHRnZW4tZ3JlZW4tYmFja2dyb3VuZDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbi1iYWNrZ3JvdW5kKTtcclxuJGNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTUwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS01MCk7XHJcbiRjb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS00MDA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTQwMCk7XHJcbiRjb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS0xMDA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTEwMCk7XHJcbiRjb2xvci1uZXh0Z2VuLXN0YXR1cy1lcnJvcjogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtZXJyb3IpO1xyXG4kY29sb3ItbmV4dGdlbi1zdGF0dXMtZXJyb3ItYmFja2dyb3VuZDogdmFyKFxyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtZXJyb3ItYmFja2dyb3VuZFxyXG4pO1xyXG4kY29sb3ItbmV4dGdlbi1zdGF0dXMtd2FybmluZzogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtd2FybmluZyk7XHJcbiRjb2xvci1uZXh0Z2VuLXN0YXR1cy13YXJuaW5nLWJhY2tncm91bmQ6IHZhcihcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLXdhcm5pbmctYmFja2dyb3VuZFxyXG4pO1xyXG4kY29sb3ItbmV4dGdlbi1ibHVlLTEwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlLTEwMCk7XHJcbiRjb2xvci1uZXh0Z2VuLWVycm9yLXJlZC03MDA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZXJyb3ItcmVkLTcwMCk7XHJcbiRjb2xvci1uZXh0Z2VuLWJsdWUtNTAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWJsdWUtNTAwKTtcclxuJGNvbG9yLW5leHRnZW4tYmx1ZS00MDA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZS00MDApO1xyXG4kY29sb3ItbmV4dGdlbi1yZWQtNTAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXJlZC01MDApO1xyXG4kY29sb3ItbmV4dGdlbi1zZWNvbmRhcnktYmx1ZS0zMDA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tc2Vjb25kYXJ5LWJsdWUtMzAwKTtcclxuXHJcbi5pb24tY29sb3ItZ3JlZW4ge1xyXG5cdC0taW9uLWNvbG9yLWJhc2U6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4pO1xyXG5cdC0taW9uLWNvbG9yLWJhc2UtcmdiOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuKTtcclxuXHQtLWlvbi1jb2xvci1jb250cmFzdDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi13aGl0ZSk7XHJcblx0LS1pb24tY29sb3ItY29udHJhc3QtcmdiOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuKTtcclxuXHQtLWlvbi1jb2xvci1zaGFkZTogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbik7XHJcblx0LS1pb24tY29sb3ItdGludDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbik7XHJcbn1cclxuIiwiQGltcG9ydCBcIi4uLy4uLy4uLy4uL2NvbG9yLnNjc3NcIjtcclxuQGltcG9ydCBcIi4uLy4uLy4uLy4uL3N0eWxlLnNjc3NcIjtcclxuXHJcbmlvbi1jb250ZW50IHtcclxuICAgIC0tYmFja2dyb3VuZDogI0YxRUZFRjtcclxufVxyXG5cclxuLmRpc2Nsb3N1cmUtYWNjaWRlbnQtbWFpbiB7XHJcbiAgICBtYXJnaW4tYm90dG9tOiAxMjhweDtcclxuXHJcbiAgICAuZGlzY2xvc3VyZS1hY2NpZGVudC10aXRsZSB7fVxyXG5cclxuICAgIC5kaXNjbG9zdXJlLWFjY2lkZW50LWNvbnRlbnQge1xyXG4gICAgICAgIC5kZXRhaWwtY29udGVudCB7XHJcbiAgICAgICAgICAgIG1hcmdpbi1ib3R0b206IDFyZW07XHJcblxyXG4gICAgICAgICAgICAuZGV0YWlsLXRpdGxlIHtcclxuICAgICAgICAgICAgICAgIG1hcmdpbi1ib3R0b206IDAuMnJlbTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLmRldGFpbC1jb250ZW50LWFjY2lkZW50RGVzYyB7XHJcbiAgICAgICAgICAgIHBhZGRpbmctYm90dG9tOiAxcmVtO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLnRleHQtYm94IHtcclxuICAgICAgICAgICAgbWFyZ2luLWJvdHRvbTogMnJlbTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbn0iLCIvKlxyXG4gKiAxLiBDdXN0b20gQ1NTIFxyXG4gKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcbiAqL1xyXG5cclxuLy8gY29sb3IgdmFyaWFibGVcclxuQGltcG9ydCBcIi4vY29sb3Iuc2Nzc1wiO1xyXG4vLyB0eXBvZ3JhcGh5XHJcbkBpbXBvcnQgXCIuL2ZvbnQtc2l6ZS5zY3NzXCI7XHJcblxyXG4vLyBGb250c1xyXG5AZm9udC1mYWNlIHtcclxuXHRmb250LWZhbWlseTogXCJBbGxpYW56IE5lb1wiO1xyXG5cdGZvbnQtc3R5bGU6IG5vcm1hbDtcclxuXHRmb250LXdlaWdodDogMzAwO1xyXG5cdGZvbnQtZGlzcGxheTogc3dhcDtcclxuXHRzcmM6IHVybChcIi4vYXNzZXRzL2ZvbnRzL0FsbGlhbnpOZW8vQWxsaWFuel9OZW9fd2ViZm9udHMvd29mZjIvQWxsaWFuek5lb1cwNC1MaWdodC53b2ZmMlwiKVxyXG5cdFx0XHRmb3JtYXQoXCJ3b2ZmMlwiKSxcclxuXHRcdHVybChcIi4vYXNzZXRzL2ZvbnRzL0FsbGlhbnpOZW8vQWxsaWFuel9OZW9fd2ViZm9udHMvd29mZi9BbGxpYW56TmVvVzA0LUxpZ2h0LndvZmZcIilcclxuXHRcdFx0Zm9ybWF0KFwid29mZlwiKTtcclxufVxyXG5cclxuQGZvbnQtZmFjZSB7XHJcblx0Zm9udC1mYW1pbHk6IFwiQWxsaWFueiBOZW9cIjtcclxuXHRmb250LXN0eWxlOiBpdGFsaWM7XHJcblx0Zm9udC13ZWlnaHQ6IDMwMDtcclxuXHRmb250LWRpc3BsYXk6IHN3YXA7XHJcblx0c3JjOiB1cmwoXCIuL2Fzc2V0cy9mb250cy9BbGxpYW56TmVvL0FsbGlhbnpfTmVvX3dlYmZvbnRzL3dvZmYyL0FsbGlhbnpOZW9XMDQtTGlnaHRJdGFsaWMud29mZjJcIilcclxuXHRcdFx0Zm9ybWF0KFwid29mZjJcIiksXHJcblx0XHR1cmwoXCIuL2Fzc2V0cy9mb250cy9BbGxpYW56TmVvL0FsbGlhbnpfTmVvX3dlYmZvbnRzL3dvZmYvQWxsaWFuek5lb1cwNC1MaWdodEl0YWxpYy53b2ZmXCIpXHJcblx0XHRcdGZvcm1hdChcIndvZmZcIik7XHJcbn1cclxuXHJcbkBmb250LWZhY2Uge1xyXG5cdGZvbnQtZmFtaWx5OiBcIkFsbGlhbnogTmVvXCI7XHJcblx0Zm9udC1zdHlsZTogbm9ybWFsO1xyXG5cdGZvbnQtd2VpZ2h0OiA0MDA7XHJcblx0Zm9udC1kaXNwbGF5OiBzd2FwO1xyXG5cdHNyYzogdXJsKFwiLi9hc3NldHMvZm9udHMvQWxsaWFuek5lby9BbGxpYW56X05lb193ZWJmb250cy93b2ZmMi9BbGxpYW56TmVvVzA0LVJlZ3VsYXIud29mZjJcIilcclxuXHRcdFx0Zm9ybWF0KFwid29mZjJcIiksXHJcblx0XHR1cmwoXCIuL2Fzc2V0cy9mb250cy9BbGxpYW56TmVvL0FsbGlhbnpfTmVvX3dlYmZvbnRzL3dvZmYvQWxsaWFuek5lb1cwNC1SZWd1bGFyLndvZmZcIilcclxuXHRcdFx0Zm9ybWF0KFwid29mZlwiKTtcclxufVxyXG5cclxuQGZvbnQtZmFjZSB7XHJcblx0Zm9udC1mYW1pbHk6IFwiQWxsaWFueiBOZW9cIjtcclxuXHRmb250LXN0eWxlOiBpdGFsaWM7XHJcblx0Zm9udC13ZWlnaHQ6IDQwMDtcclxuXHRmb250LWRpc3BsYXk6IHN3YXA7XHJcblx0c3JjOiB1cmwoXCIuL2Fzc2V0cy9mb250cy9BbGxpYW56TmVvL0FsbGlhbnpfTmVvX3dlYmZvbnRzL3dvZmYyL0FsbGlhbnpOZW9XMDQtSXRhbGljLndvZmYyXCIpXHJcblx0XHRcdGZvcm1hdChcIndvZmYyXCIpLFxyXG5cdFx0dXJsKFwiLi9hc3NldHMvZm9udHMvQWxsaWFuek5lby9BbGxpYW56X05lb193ZWJmb250cy93b2ZmL0FsbGlhbnpOZW9XMDQtSXRhbGljLndvZmZcIilcclxuXHRcdFx0Zm9ybWF0KFwid29mZlwiKTtcclxufVxyXG5cclxuQGZvbnQtZmFjZSB7XHJcblx0Zm9udC1mYW1pbHk6IFwiQWxsaWFueiBOZW9cIjtcclxuXHRmb250LXN0eWxlOiBub3JtYWw7XHJcblx0Zm9udC13ZWlnaHQ6IDYwMDtcclxuXHRmb250LWRpc3BsYXk6IHN3YXA7XHJcblx0c3JjOiB1cmwoXCIuL2Fzc2V0cy9mb250cy9BbGxpYW56TmVvL0FsbGlhbnpfTmVvX3dlYmZvbnRzL3dvZmYyL0FsbGlhbnpOZW9XMDQtU2VtaUJvbGQud29mZjJcIilcclxuXHRcdFx0Zm9ybWF0KFwid29mZjJcIiksXHJcblx0XHR1cmwoXCIuL2Fzc2V0cy9mb250cy9BbGxpYW56TmVvL0FsbGlhbnpfTmVvX3dlYmZvbnRzL3dvZmYvQWxsaWFuek5lb1cwNC1TZW1pQm9sZC53b2ZmXCIpXHJcblx0XHRcdGZvcm1hdChcIndvZmZcIik7XHJcbn1cclxuXHJcbkBmb250LWZhY2Uge1xyXG5cdGZvbnQtZmFtaWx5OiBcIkFsbGlhbnogTmVvXCI7XHJcblx0Zm9udC1zdHlsZTogaXRhbGljO1xyXG5cdGZvbnQtd2VpZ2h0OiA2MDA7XHJcblx0Zm9udC1kaXNwbGF5OiBzd2FwO1xyXG5cdHNyYzogdXJsKFwiLi9hc3NldHMvZm9udHMvQWxsaWFuek5lby9BbGxpYW56X05lb193ZWJmb250cy93b2ZmMi9BbGxpYW56TmVvVzA0LVNlbWlCb2xkSXQud29mZjJcIilcclxuXHRcdFx0Zm9ybWF0KFwid29mZjJcIiksXHJcblx0XHR1cmwoXCIuL2Fzc2V0cy9mb250cy9BbGxpYW56TmVvL0FsbGlhbnpfTmVvX3dlYmZvbnRzL3dvZmYvQWxsaWFuek5lb1cwNC1TZW1pQm9sZEl0LndvZmZcIilcclxuXHRcdFx0Zm9ybWF0KFwid29mZlwiKTtcclxufVxyXG5cclxuQGZvbnQtZmFjZSB7XHJcblx0Zm9udC1mYW1pbHk6IFwiQWxsaWFueiBOZW9cIjtcclxuXHRmb250LXN0eWxlOiBub3JtYWw7XHJcblx0Zm9udC13ZWlnaHQ6IDcwMDtcclxuXHRmb250LWRpc3BsYXk6IHN3YXA7XHJcblx0c3JjOiB1cmwoXCIuL2Fzc2V0cy9mb250cy9BbGxpYW56TmVvL0FsbGlhbnpfTmVvX3dlYmZvbnRzL3dvZmYyL0FsbGlhbnpOZW9XMDQtQm9sZC53b2ZmMlwiKVxyXG5cdFx0XHRmb3JtYXQoXCJ3b2ZmMlwiKSxcclxuXHRcdHVybChcIi4vYXNzZXRzL2ZvbnRzL0FsbGlhbnpOZW8vQWxsaWFuel9OZW9fd2ViZm9udHMvd29mZi9BbGxpYW56TmVvVzA0LUJvbGQud29mZlwiKVxyXG5cdFx0XHRmb3JtYXQoXCJ3b2ZmXCIpO1xyXG59XHJcblxyXG5AZm9udC1mYWNlIHtcclxuXHRmb250LWZhbWlseTogXCJBbGxpYW56IE5lb1wiO1xyXG5cdGZvbnQtc3R5bGU6IGl0YWxpYztcclxuXHRmb250LXdlaWdodDogNzAwO1xyXG5cdGZvbnQtZGlzcGxheTogc3dhcDtcclxuXHRzcmM6IHVybChcIi4vYXNzZXRzL2ZvbnRzL0FsbGlhbnpOZW8vQWxsaWFuel9OZW9fd2ViZm9udHMvd29mZjIvQWxsaWFuek5lb1cwNC1Cb2xkSXRhbGljLndvZmYyXCIpXHJcblx0XHRcdGZvcm1hdChcIndvZmYyXCIpLFxyXG5cdFx0dXJsKFwiLi9hc3NldHMvZm9udHMvQWxsaWFuek5lby9BbGxpYW56X05lb193ZWJmb250cy93b2ZmL0FsbGlhbnpOZW9XMDQtQm9sZEl0YWxpYy53b2ZmXCIpXHJcblx0XHRcdGZvcm1hdChcIndvZmZcIik7XHJcbn1cclxuXHJcbioge1xyXG5cdGNvbG9yOiAkY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXk7XHJcblx0Zm9udC1mYW1pbHk6IFwiQWxsaWFueiBOZW9cIiwgc2Fucy1zZXJpZjtcclxuXHRmb250LXdlaWdodDogNDAwO1xyXG5cdGZvbnQtc2l6ZTogMTZweDtcclxufVxyXG5cclxuaHRtbCB7XHJcblx0LS1pb24tc2FmZS1hcmVhLXRvcDogMHB4O1xyXG59XHJcblxyXG4uY29sLTEge1xyXG5cdHdpZHRoOiA4LjMzJTtcclxufVxyXG5cclxuLmNvbC0yIHtcclxuXHR3aWR0aDogMTYuNjYlO1xyXG59XHJcblxyXG4uY29sLTMge1xyXG5cdHdpZHRoOiAyNSU7XHJcbn1cclxuXHJcbi5jb2wtNCB7XHJcblx0d2lkdGg6IDMzLjMzJTtcclxufVxyXG5cclxuLmNvbC01IHtcclxuXHR3aWR0aDogNDEuNjYlO1xyXG59XHJcblxyXG4uY29sLTYge1xyXG5cdHdpZHRoOiA1MCU7XHJcbn1cclxuXHJcbi5jb2wtNyB7XHJcblx0d2lkdGg6IDU4LjMzJTtcclxufVxyXG5cclxuLmNvbC04IHtcclxuXHR3aWR0aDogNjYuNjYlO1xyXG59XHJcblxyXG4uY29sLTkge1xyXG5cdHdpZHRoOiA3NSU7XHJcbn1cclxuXHJcbi5jb2wtMTAge1xyXG5cdHdpZHRoOiA4My4zMyU7XHJcbn1cclxuXHJcbi5jb2wtMTEge1xyXG5cdHdpZHRoOiA5MS42NiU7XHJcbn1cclxuXHJcbi5jb2wtMTIge1xyXG5cdHdpZHRoOiAxMDAlO1xyXG59XHJcblxyXG5AbWVkaWEgb25seSBzY3JlZW4gYW5kIChtYXgtd2lkdGg6IDU3NnB4KSB7XHJcblx0LyogRm9yIHRhYmxldHM6ICovXHJcblx0LmNvbC1zbS0xIHtcclxuXHRcdHdpZHRoOiA4LjMzJTtcclxuXHR9XHJcblxyXG5cdC5jb2wtc20tMiB7XHJcblx0XHR3aWR0aDogMTYuNjYlO1xyXG5cdH1cclxuXHJcblx0LmNvbC1zbS0zIHtcclxuXHRcdHdpZHRoOiAyNSU7XHJcblx0fVxyXG5cclxuXHQuY29sLXNtLTQge1xyXG5cdFx0d2lkdGg6IDMzLjMzJTtcclxuXHR9XHJcblxyXG5cdC5jb2wtc20tNSB7XHJcblx0XHR3aWR0aDogNDEuNjYlO1xyXG5cdH1cclxuXHJcblx0LmNvbC1zbS02IHtcclxuXHRcdHdpZHRoOiA1MCU7XHJcblx0fVxyXG5cclxuXHQuY29sLXNtLTcge1xyXG5cdFx0d2lkdGg6IDU4LjMzJTtcclxuXHR9XHJcblxyXG5cdC5jb2wtc20tOCB7XHJcblx0XHR3aWR0aDogNjYuNjYlO1xyXG5cdH1cclxuXHJcblx0LmNvbC1zbS05IHtcclxuXHRcdHdpZHRoOiA3NSU7XHJcblx0fVxyXG5cclxuXHQuY29sLXNtLTEwIHtcclxuXHRcdHdpZHRoOiA4My4zMyU7XHJcblx0fVxyXG5cclxuXHQuY29sLXNtLTExIHtcclxuXHRcdHdpZHRoOiA5MS42NiU7XHJcblx0fVxyXG5cclxuXHQuY29sLXNtLTEyIHtcclxuXHRcdHdpZHRoOiAxMDAlO1xyXG5cdH1cclxufVxyXG5cclxuQG1lZGlhIG9ubHkgc2NyZWVuIGFuZCAobWF4LXdpZHRoOiA3NjhweCkgYW5kIChtaW4td2lkdGg6IDU3N3B4KSB7XHJcblx0LyogRm9yIHRhYmxldHM6ICovXHJcblx0LmNvbC1tZC0xIHtcclxuXHRcdHdpZHRoOiA4LjMzJTtcclxuXHR9XHJcblxyXG5cdC5jb2wtbWQtMiB7XHJcblx0XHR3aWR0aDogMTYuNjYlO1xyXG5cdH1cclxuXHJcblx0LmNvbC1tZC0zIHtcclxuXHRcdHdpZHRoOiAyNSU7XHJcblx0fVxyXG5cclxuXHQuY29sLW1kLTQge1xyXG5cdFx0d2lkdGg6IDMzLjMzJTtcclxuXHR9XHJcblxyXG5cdC5jb2wtbWQtNSB7XHJcblx0XHR3aWR0aDogNDEuNjYlO1xyXG5cdH1cclxuXHJcblx0LmNvbC1tZC02IHtcclxuXHRcdHdpZHRoOiA1MCU7XHJcblx0fVxyXG5cclxuXHQuY29sLW1kLTcge1xyXG5cdFx0d2lkdGg6IDU4LjMzJTtcclxuXHR9XHJcblxyXG5cdC5jb2wtbWQtOCB7XHJcblx0XHR3aWR0aDogNjYuNjYlO1xyXG5cdH1cclxuXHJcblx0LmNvbC1tZC05IHtcclxuXHRcdHdpZHRoOiA3NSU7XHJcblx0fVxyXG5cclxuXHQuY29sLW1kLTEwIHtcclxuXHRcdHdpZHRoOiA4My4zMyU7XHJcblx0fVxyXG5cclxuXHQuY29sLW1kLTExIHtcclxuXHRcdHdpZHRoOiA5MS42NiU7XHJcblx0fVxyXG5cclxuXHQuY29sLW1kLTEyIHtcclxuXHRcdHdpZHRoOiAxMDAlO1xyXG5cdH1cclxufVxyXG5cclxuQG1lZGlhIG9ubHkgc2NyZWVuIGFuZCAobWluLXdpZHRoOiA3NjlweCkge1xyXG5cdC8qIEZvciB0YWJsZXRzOiAqL1xyXG5cdC5jb2wtbGctMSB7XHJcblx0XHR3aWR0aDogOC4zMyU7XHJcblx0fVxyXG5cclxuXHQuY29sLWxnLTIge1xyXG5cdFx0d2lkdGg6IDE2LjY2JTtcclxuXHR9XHJcblxyXG5cdC5jb2wtbGctMyB7XHJcblx0XHR3aWR0aDogMjUlO1xyXG5cdH1cclxuXHJcblx0LmNvbC1sZy00IHtcclxuXHRcdHdpZHRoOiAzMy4zMyU7XHJcblx0fVxyXG5cclxuXHQuY29sLWxnLTUge1xyXG5cdFx0d2lkdGg6IDQxLjY2JTtcclxuXHR9XHJcblxyXG5cdC5jb2wtbGctNiB7XHJcblx0XHR3aWR0aDogNTAlO1xyXG5cdH1cclxuXHJcblx0LmNvbC1sZy03IHtcclxuXHRcdHdpZHRoOiA1OC4zMyU7XHJcblx0fVxyXG5cclxuXHQuY29sLWxnLTgge1xyXG5cdFx0d2lkdGg6IDY2LjY2JTtcclxuXHR9XHJcblxyXG5cdC5jb2wtbGctOSB7XHJcblx0XHR3aWR0aDogNzUlO1xyXG5cdH1cclxuXHJcblx0LmNvbC1sZy0xMCB7XHJcblx0XHR3aWR0aDogODMuMzMlO1xyXG5cdH1cclxuXHJcblx0LmNvbC1sZy0xMSB7XHJcblx0XHR3aWR0aDogOTEuNjYlO1xyXG5cdH1cclxuXHJcblx0LmNvbC1sZy0xMiB7XHJcblx0XHR3aWR0aDogMTAwJTtcclxuXHR9XHJcbn1cclxuXHJcbi5yb3cge1xyXG5cdGRpc3BsYXk6IGZsZXg7XHJcblx0anVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcblx0YWxpZ24taXRlbXM6IGNlbnRlcjtcclxufVxyXG5cclxuLy8gQ1NTXHJcbi5jdXN0b20tdG9hc3Qge1xyXG5cdC0tbWF4LXdpZHRoOiBmaXQtY29udGVudDtcclxufVxyXG5cclxuLypcclxuICogMi4gQ3VzdG9tIENTUyBmb3IgY29tcGF0aWJpbGl0eSB3aXRoIEVkZ2VcclxuICogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG4gKi9cclxuaW5wdXQ6Oi1tcy1yZXZlYWwsXHJcbmlucHV0OjotbXMtY2xlYXIge1xyXG5cdGRpc3BsYXk6IG5vbmU7XHJcbn1cclxuXHJcbi5zd2FsMi1wb3B1cCB7XHJcblx0bWFyZ2luLXRvcDogMjBweDtcclxufVxyXG5cclxuLypcclxuICogMy4gQ3VzdG9tIENTUyBmb3IgbG9hZGluZyBjb250cm9sbGVyXHJcbiAqIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuICovXHJcbi50cmFuc3BhcmVudC1sb2FkaW5nLWNsYXNzIHtcclxuXHQtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xyXG5cdC0tc3Bpbm5lci1jb2xvcjogIzQ3ZTZiMTtcclxufVxyXG5cclxuLmxvYWRpbmctd3JhcHBlci5zYy1pb24tbG9hZGluZy1tZCB7XHJcblx0Ym94LXNoYWRvdzogdW5zZXQ7XHJcblx0LXdlYmtpdC1ib3gtc2hhZG93OiB1bnNldDtcclxufVxyXG5cclxuLnVpbCB7XHJcblx0Y29sb3I6ICRjb2xvci1uZXh0Z2VuLWdyZXk7XHJcbn1cclxuXHJcbi5idG4ge1xyXG5cdGhlaWdodDogNDhweDtcclxuXHRib3JkZXItcmFkaXVzOiAyOHB4O1xyXG5cdHBhZGRpbmc6IDBweCA0MXB4IDBweCA0MXB4O1xyXG5cdGJveC1zaGFkb3c6IG5vbmU7XHJcblxyXG5cdCYuYnRuLWNpcmNsZSB7XHJcblx0XHRiYWNrZ3JvdW5kLWNvbG9yOiAkY29sb3ItbmV4dGdlbi1zdG9uZS1ncmV5ICFpbXBvcnRhbnQ7XHJcblx0XHRjb2xvcjogJGNvbG9yLW5leHRnZW4tYmxhY2s7XHJcblx0XHRwYWRkaW5nOiB1bnNldCAhaW1wb3J0YW50O1xyXG5cdFx0aGVpZ2h0OiAzNnB4ICFpbXBvcnRhbnQ7XHJcblx0XHR3aWR0aDogMzZweCAhaW1wb3J0YW50O1xyXG5cdFx0Ym9yZGVyLXJhZGl1czogNTAlICFpbXBvcnRhbnQ7XHJcblxyXG5cdFx0aSB7XHJcblx0XHRcdGNvbG9yOiAkY29sb3ItbmV4dGdlbi1ibGFjaztcclxuXHRcdH1cclxuXHR9XHJcblxyXG5cdCYucHJpbWFyeSB7XHJcblx0XHRiYWNrZ3JvdW5kOiAkY29sb3ItbmV4dGdlbi1ncmVlbjtcclxuXHRcdGNvbG9yOiAkY29sb3ItbmV4dGdlbi13aGl0ZTtcclxuXHJcblx0XHQudWlsIHtcclxuXHRcdFx0Y29sb3I6ICRjb2xvci1uZXh0Z2VuLXdoaXRlO1xyXG5cdFx0fVxyXG5cclxuXHRcdCY6ZGlzYWJsZWQge1xyXG5cdFx0XHRiYWNrZ3JvdW5kLWNvbG9yOiAkY29sb3ItbmV4dGdlbi1ncmV5LWJhY2tncm91bmQgIWltcG9ydGFudDtcclxuXHRcdFx0Y29sb3I6ICRjb2xvci1uZXh0Z2VuLWdyZXkgIWltcG9ydGFudDtcclxuXHRcdH1cclxuXHR9XHJcblxyXG5cdCYuc2Vjb25kYXJ5IHtcclxuXHRcdGJhY2tncm91bmQ6ICRjb2xvci1uZXh0Z2VuLXdoaXRlICFpbXBvcnRhbnQ7XHJcblx0XHRib3JkZXItY29sb3I6ICRjb2xvci1uZXh0Z2VuLWdyZWVuO1xyXG5cdFx0Ym9yZGVyOiBzb2xpZCAxcHg7XHJcblx0XHRjb2xvcjogJGNvbG9yLW5leHRnZW4tZ3JlZW47XHJcblxyXG5cdFx0LnVpbCB7XHJcblx0XHRcdGNvbG9yOiAkY29sb3ItbmV4dGdlbi1ncmVlbjtcclxuXHRcdH1cclxuXHJcblx0XHQmOmRpc2FibGVkIHtcclxuXHRcdFx0YmFja2dyb3VuZC1jb2xvcjogJGNvbG9yLW5leHRnZW4td2hpdGUgIWltcG9ydGFudDtcclxuXHRcdFx0Y29sb3I6ICRjb2xvci1uZXh0Z2VuLWdyZXkgIWltcG9ydGFudDtcclxuXHRcdFx0Ym9yZGVyLWNvbG9yOiAkY29sb3ItbmV4dGdlbi1ncmV5LWJhY2tncm91bmQgIWltcG9ydGFudDtcclxuXHRcdH1cclxuXHR9XHJcblxyXG5cdCYudHJhbnNwYXJlbnQge1xyXG5cdFx0YmFja2dyb3VuZDogdHJhbnNwYXJlbnQgIWltcG9ydGFudDtcclxuXHRcdGJvcmRlci1jb2xvcjogJGNvbG9yLW5leHRnZW4tZ3JlZW47XHJcblx0XHRib3JkZXI6IHNvbGlkIDFweDtcclxuXHRcdGNvbG9yOiAkY29sb3ItbmV4dGdlbi1ncmVlbjtcclxuXHJcblx0XHQudWlsIHtcclxuXHRcdFx0Y29sb3I6ICRjb2xvci1uZXh0Z2VuLWdyZWVuO1xyXG5cdFx0fVxyXG5cclxuXHRcdCY6ZGlzYWJsZWQge1xyXG5cdFx0XHRiYWNrZ3JvdW5kLWNvbG9yOiB0cmFuc3BhcmVudCAhaW1wb3J0YW50O1xyXG5cdFx0XHRjb2xvcjogJGNvbG9yLW5leHRnZW4tZ3JleSAhaW1wb3J0YW50O1xyXG5cdFx0XHRib3JkZXItY29sb3I6ICRjb2xvci1uZXh0Z2VuLWdyZXktYmFja2dyb3VuZCAhaW1wb3J0YW50O1xyXG5cdFx0fVxyXG5cdH1cclxuXHJcblx0Ji5idG4tbGFyZ2Uge1xyXG5cdFx0aGVpZ2h0OiA1NnB4ICFpbXBvcnRhbnQ7XHJcblx0XHR3aWR0aDogMTAwJTtcclxuXHR9XHJcblxyXG5cdCYuYm9sZCB7XHJcblx0XHRmb250LXdlaWdodDogNzAwICFpbXBvcnRhbnQ7XHJcblx0fVxyXG5cclxuXHQmLnNlbWlib2xkIHtcclxuXHRcdGZvbnQtd2VpZ2h0OiA2MDAgIWltcG9ydGFudDtcclxuXHR9XHJcbn1cclxuXHJcbi5idG4tbm8tc3BhY2Uge1xyXG5cdHBhZGRpbmc6IDVweCAhaW1wb3J0YW50O1xyXG5cdGhlaWdodDogZml0LWNvbnRlbnQ7XHJcbn1cclxuXHJcbi5idG4tYmFjayB7XHJcblx0d2lkdGg6IDMxcHg7XHJcblx0aGVpZ2h0OiAyOHB4O1xyXG5cdGJhY2tncm91bmQtY29sb3I6IHRyYW5zcGFyZW50O1xyXG5cdHBhZGRpbmc6IDA7XHJcblx0Y29sb3I6ICRjb2xvci1uZXh0Z2VuLWdyZWVuO1xyXG59XHJcblxyXG4uY29udGFpbmVyIHtcclxuXHRwYWRkaW5nOiAycmVtO1xyXG5cdGhlaWdodDogMTAwJTtcclxufVxyXG5cclxuLmJvZHktc2VjdGlvbiB7XHJcblx0d2lkdGg6IDEwMCU7XHJcblx0aGVpZ2h0OiA5NSU7XHJcblx0b3ZlcmZsb3cteTogYXV0bztcclxuXHRwb3NpdGlvbjogcmVsYXRpdmU7XHJcbn1cclxuXHJcbi50b3Atc2VjdGlvbiB7XHJcblx0d2lkdGg6IDEwMCU7XHJcblx0aGVpZ2h0OiAxMCU7XHJcblx0anVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xyXG5cdGRpc3BsYXk6IGZsZXg7XHJcblx0YWxpZ24taXRlbXM6IGNlbnRlcjtcclxufVxyXG5cclxuLmZvcm0tY29udHJvbCB7XHJcblx0cG9zaXRpb246IHJlbGF0aXZlO1xyXG5cdGhlaWdodDogODVweDtcclxuXHRtYXJnaW4tYm90dG9tOiA4cHg7XHJcbn1cclxuXHJcbi5jb250cm9sIHtcclxuXHRib3JkZXItcmFkaXVzOiA4cHg7XHJcblx0aGVpZ2h0OiA1NnB4O1xyXG5cdGJvcmRlcjogMXB4IHNvbGlkICRjb2xvci1uZXh0Z2VuLWdyZXktYmFja2dyb3VuZDtcclxuXHR3aWR0aDogMTAwJTtcclxuXHRwb3NpdGlvbjogYWJzb2x1dGU7XHJcblx0dG9wOiAzMnB4O1xyXG5cdGJhY2tncm91bmQtY29sb3I6ICRjb2xvci1uZXh0Z2VuLXdoaXRlO1xyXG5cclxuXHQmIHRhYmxlIHtcclxuXHRcdHRhYmxlLWxheW91dDogZml4ZWQ7XHJcblx0XHRib3JkZXItY29sbGFwc2U6IHVuc2V0O1xyXG5cdH1cclxuXHJcblx0JiBpbnB1dCB7XHJcblx0XHRoZWlnaHQ6IDU0cHg7XHJcblx0XHRib3JkZXI6IHVuc2V0O1xyXG5cdFx0Ym9yZGVyLXJhZGl1czogOHB4O1xyXG5cdFx0d2lkdGg6IG1heC1jb250ZW50O1xyXG5cdFx0d2lkdGg6IDEwMCU7XHJcblx0XHRwb2ludGVyLWV2ZW50czogYXV0bztcclxuXHRcdGJhY2tncm91bmQtY29sb3I6ICRjb2xvci1uZXh0Z2VuLXdoaXRlO1xyXG5cdH1cclxuXHJcblx0Ji50ZXh0YXJlYSB7XHJcblx0XHRoZWlnaHQ6IDEwOHB4O1xyXG5cdH1cclxuXHJcblx0JiB0ZXh0YXJlYSB7XHJcblx0XHRoZWlnaHQ6IDEwNnB4O1xyXG5cdFx0Ym9yZGVyOiB1bnNldDtcclxuXHRcdGJvcmRlci1yYWRpdXM6IDhweDtcclxuXHRcdHdpZHRoOiBtYXgtY29udGVudDtcclxuXHRcdHdpZHRoOiAxMDAlO1xyXG5cdFx0cG9pbnRlci1ldmVudHM6IGF1dG87XHJcblx0XHRyZXNpemU6IG5vbmU7XHJcblx0XHRiYWNrZ3JvdW5kLWNvbG9yOiAkY29sb3ItbmV4dGdlbi13aGl0ZTtcclxuXHR9XHJcblxyXG5cdCYgaW5wdXQ6Zm9jdXMge1xyXG5cdFx0b3V0bGluZTogbm9uZTtcclxuXHR9XHJcblxyXG5cdCY6Zm9jdXMtd2l0aGluIHtcclxuXHRcdGJvcmRlci1jb2xvcjogJGNvbG9yLW5leHRnZW4tZ3JlZW47XHJcblxyXG5cdFx0LmZpcnN0LWljb24ge1xyXG5cdFx0XHRkaXNwbGF5OiBub25lO1xyXG5cdFx0fVxyXG5cclxuXHRcdC5maXJzdC1pY29uLm5vbi1oaWRkZW4ge1xyXG5cdFx0XHRkaXNwbGF5OiB0YWJsZS1jZWxsO1xyXG5cdFx0fVxyXG5cdH1cclxuXHJcblx0LmZpcnN0LWljb24ge1xyXG5cdFx0d2lkdGg6IDMycHg7XHJcblx0XHR0ZXh0LWFsaWduOiBjZW50ZXI7XHJcblx0XHRwYWRkaW5nLWxlZnQ6IDhweDtcclxuXHJcblx0XHRpIHtcclxuXHRcdFx0Zm9udC1zaXplOiAyNHB4ICFpbXBvcnRhbnQ7XHJcblx0XHR9XHJcblx0fVxyXG5cclxuXHQuc2Vjb25kLWljb24ge1xyXG5cdFx0d2lkdGg6IDMycHg7XHJcblx0XHR0ZXh0LWFsaWduOiBjZW50ZXI7XHJcblx0XHQvLyBwYWRkaW5nLXJpZ2h0OiA4cHg7XHJcblxyXG5cdFx0aSB7XHJcblx0XHRcdGZvbnQtc2l6ZTogMjRweCAhaW1wb3J0YW50O1xyXG5cdFx0fVxyXG5cdH1cclxufVxyXG5cclxuLmNvbnRyb2w6Zm9jdXMtd2l0aGluIH4gZGl2IC5jb250cm9sLWxhYmVsIHtcclxuXHRjb2xvcjogJGNvbG9yLW5leHRnZW4tZ3JlZW47XHJcbn1cclxuXHJcbi5jb250cm9sLWVycm9yIHtcclxuXHQuY29udHJvbCB7XHJcblx0XHRib3JkZXItY29sb3I6ICRjb2xvci1uZXh0Z2VuLWVycm9yO1xyXG5cdH1cclxuXHJcblx0LmNvbnRyb2wtbGFiZWwge1xyXG5cdFx0Y29sb3I6ICRjb2xvci1uZXh0Z2VuLWVycm9yICFpbXBvcnRhbnQ7XHJcblx0fVxyXG59XHJcblxyXG4udmFsaWRhdGlvbi1zdW1tYXJ5IHtcclxuXHRsaSB7XHJcblx0XHRjb2xvcjogJGNvbG9yLW5leHRnZW4tZXJyb3IgIWltcG9ydGFudDtcclxuXHRcdGxpc3Qtc3R5bGU6IG5vbmU7XHJcblxyXG5cdFx0aSB7XHJcblx0XHRcdGNvbG9yOiAkY29sb3ItbmV4dGdlbi1lcnJvciAhaW1wb3J0YW50O1xyXG5cdFx0fVxyXG5cdH1cclxufVxyXG5cclxuLm1yLTEge1xyXG5cdG1hcmdpbi1yaWdodDogMC41cmVtO1xyXG59XHJcblxyXG4ubWItMSB7XHJcblx0bWFyZ2luLWJvdHRvbTogMC41cmVtO1xyXG59XHJcblxyXG4uZGlhbG9nLXBhbmUge1xyXG5cdHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuXHRwb2ludGVyLWV2ZW50czogYXV0bztcclxuXHRib3gtc2l6aW5nOiBib3JkZXItYm94O1xyXG5cdHotaW5kZXg6IDEwMDA7XHJcblx0ZGlzcGxheTogYmxvY2s7XHJcblx0bWF4LXdpZHRoOiAxMDAlO1xyXG5cdG1heC1oZWlnaHQ6IDEwMCU7XHJcbn1cclxuXHJcbi5vdmVybGF5LWJhY2tkcm9wIHtcclxuXHRiYWNrZ3JvdW5kLWNvbG9yOiAkY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXk7XHJcblx0b3BhY2l0eTogMC4yICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5kaWFsb2ctY29udGFpbmVyIHtcclxuXHRhbmltYXRpb246IGZhZGVJbiAwLjVzIGxpbmVhcjtcclxuXHRiYWNrZ3JvdW5kLWNvbG9yOiAkY29sb3ItbmV4dGdlbi13aGl0ZTtcclxufVxyXG5cclxuQGtleWZyYW1lcyBmYWRlSW4ge1xyXG5cdGZyb20ge1xyXG5cdFx0dHJhbnNmb3JtOiB0cmFuc2xhdGVZKDEwMCUpO1xyXG5cdH1cclxuXHJcblx0dG8ge1xyXG5cdFx0dHJhbnNmb3JtOiB0cmFuc2xhdGVZKDAlKTtcclxuXHR9XHJcbn1cclxuXHJcbi5lcnJvciB7XHJcblx0Y29sb3I6ICRjb2xvci1uZXh0Z2VuLWVycm9yO1xyXG5cclxuXHQmLmJhY2tncm91bmQge1xyXG5cdFx0YmFja2dyb3VuZC1jb2xvcjogJGNvbG9yLW5leHRnZW4tZXJyb3I7XHJcblx0fVxyXG59XHJcblxyXG4uc3VjY2VzcyB7XHJcblx0Y29sb3I6ICRjb2xvci1uZXh0Z2VuLWZpYnJhbnQtZ3JlZW47XHJcblxyXG5cdCYuYmFja2dyb3VuZCB7XHJcblx0XHRiYWNrZ3JvdW5kLWNvbG9yOiAkY29sb3ItbmV4dGdlbi1maWJyYW50LWdyZWVuO1xyXG5cdH1cclxufVxyXG5cclxuLndhcm5pbmcge1xyXG5cdGNvbG9yOiAkY29sb3ItbmV4dGdlbi13YXJuaW5nO1xyXG5cclxuXHQmLmJhY2tncm91bmQge1xyXG5cdFx0YmFja2dyb3VuZC1jb2xvcjogJGNvbG9yLW5leHRnZW4td2FybmluZztcclxuXHR9XHJcbn1cclxuXHJcbi5zZWxlY3Qge1xyXG5cdHdpZHRoOiAxMDAlO1xyXG5cdGhlaWdodDogNTRweDtcclxuXHRib3JkZXI6IHVuc2V0O1xyXG5cdGJvcmRlci1yYWRpdXM6IDhweDtcclxuXHRkaXNwbGF5OiBncmlkO1xyXG5cdGFwcGVhcmFuY2U6IG5vbmU7XHJcblx0Z3JpZC10ZW1wbGF0ZS1hcmVhczogXCJzZWxlY3RcIjtcclxuXHJcblx0Jjpmb2N1cyB7XHJcblx0XHRvdXRsaW5lOiB1bnNldDtcclxuXHR9XHJcbn1cclxuXHJcbi5jb2xvci1ibGFjayB7XHJcblx0Y29sb3I6ICRjb2xvci1uZXh0Z2VuLWJsYWNrO1xyXG59XHJcblxyXG4ubW9kYWwtZGVmYXVsdCB7XHJcblx0LS13aWR0aDogMTAwJTtcclxuXHQtLWhlaWdodDogMTAwJTtcclxufVxyXG5cclxuLmludGVncmF0aW9uLXBhbmVsIHtcclxuXHR3aWR0aDogMTAwJTtcclxuXHRoZWlnaHQ6IDEwMCU7XHJcblx0bWF4LXdpZHRoOiAxMDAlICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi52ZXJsb29wLWJ1dHRvbiB7XHJcblx0dmlzaWJpbGl0eTogaGlkZGVuO1xyXG59XHJcblxyXG4uYmFjay1hcmVhIHtcclxuXHRwb3NpdGlvbjogZml4ZWQ7XHJcblx0dG9wOiAwO1xyXG5cdHJpZ2h0OiAwO1xyXG5cdGhlaWdodDogNTBweDtcclxuXHR3aWR0aDogMTAwJTtcclxuXHRiYWNrZ3JvdW5kLWNvbG9yOiAkY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNTA7XHJcblx0ei1pbmRleDogOTk5OTk5OTtcclxuXHJcblx0Ji5pb3Mge1xyXG5cdFx0aGVpZ2h0OiA4MHB4O1xyXG5cdH1cclxufVxyXG5cclxuLnRpdGxlLXdpZGdldCB7XHJcblx0dGV4dC1hbGlnbjogY2VudGVyO1xyXG5cdHBvc2l0aW9uOiBzdGlja3k7XHJcblx0dG9wOiA0OHB4O1xyXG59XHJcblxyXG4uYnV0dG9uLWJhY2sge1xyXG5cdGJhY2tncm91bmQtY29sb3I6ICNmYWZhZmE7XHJcblx0aGVpZ2h0OiAzNnB4O1xyXG5cdHdpZHRoOiAzNnB4O1xyXG5cdGJvcmRlci1yYWRpdXM6IDUwJTtcclxuXHRwb3NpdGlvbjogYWJzb2x1dGU7XHJcblx0bGVmdDogMThweDtcclxuXHRib3R0b206IDRweDtcclxufVxyXG5cclxuLmljb24tY2xvc2Utd2lkZ2V0IHtcclxuXHRwb3NpdGlvbjogYWJzb2x1dGU7XHJcblx0ei1pbmRleDogMjUwO1xyXG5cdGxlZnQ6IDExcHg7XHJcblx0Ym90dG9tOiAxM3B4O1xyXG59XHJcblxyXG4uZGF0YS1kZWZhdWx0IHtcclxuXHRwb3NpdGlvbjogYWJzb2x1dGU7XHJcblx0dG9wOiA1MCU7XHJcblx0bGVmdDogNTAlO1xyXG5cdHRyYW5zZm9ybTogdHJhbnNsYXRlKC01MCUsIC01MCUpO1xyXG5cdHRleHQtYWxpZ246IGNlbnRlcjtcclxuXHRjb2xvcjogJGNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTQwMDtcclxuXHR6LWluZGV4OiAxMDAwO1xyXG59XHJcblxyXG4uYXZhYW1vX19pY29uIHtcclxuXHR2aXNpYmlsaXR5OiBoaWRkZW4gIWltcG9ydGFudDtcclxufVxyXG5cclxuLmF2YWFtb19fY2hhdF9fd2lkZ2V0LmlvcyB7XHJcblx0I2F2YWFtb19fcG9wdXAge1xyXG5cdFx0cGFkZGluZy10b3A6IDQwcHg7XHJcblx0fVxyXG59XHJcblxyXG4uZC1mbGV4IHtcclxuXHRkaXNwbGF5OiBmbGV4O1xyXG59XHJcblxyXG5uZXh0Y2FyZS1sYXlvdXQge1xyXG5cdGxlZnQ6IDA7XHJcblx0cmlnaHQ6IDA7XHJcblx0dG9wOiAwO1xyXG5cdGJvdHRvbTogMDtcclxuXHRkaXNwbGF5OiBmbGV4O1xyXG5cdHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuXHRmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG5cdGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcclxuXHRjb250YWluOiBsYXlvdXQgc2l6ZSBzdHlsZTtcclxuXHRvdmVyZmxvdzogaGlkZGVuO1xyXG5cdGJhY2tncm91bmQtY29sb3I6ICRjb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS01MDtcclxuXHRwYWRkaW5nLXJpZ2h0OiAyNHB4O1xyXG5cdHBhZGRpbmctbGVmdDogMjRweDtcclxufVxyXG5cclxuaW9uLWhlYWRlci5pb3MuaGVhZGVyLWlvcyB7XHJcblx0bWFyZ2luLXRvcDogNDBweDtcclxufVxyXG5cclxuLmhlYWRlci1pb3MgaW9uLXRvb2xiYXI6bGFzdC1vZi10eXBlIHtcclxuXHQtLWJvcmRlci13aWR0aDogMHB4ICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5oZWFkZXItbWQubWQ6OmFmdGVyIHtcclxuXHRkaXNwbGF5OiBub25lO1xyXG59XHJcblxyXG5pb24tdG9vbGJhciB7XHJcblx0cGFkZGluZy1yaWdodDogdW5zZXQgIWltcG9ydGFudDtcclxuXHRwYWRkaW5nLWxlZnQ6IHVuc2V0ICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbmkuaWNvbi1iYWNrIHtcclxuXHRjb250ZW50OiB1cmwoYXNzZXRzL2ljb24vbG9uZy1hcnJvdy1sZWZ0LWljb24uc3ZnKTtcclxufVxyXG5cclxuLnZlcmxvb3Atd2lkZ2V0LmlvcyB7XHJcblx0LnZlcmxvb3AtY29udGFpbmVyLnZpc2libGUge1xyXG5cdFx0aGVpZ2h0OiBjYWxjKDEwMCUgLSA0MHB4KTtcclxuXHRcdHRvcDogNDBweDtcclxuXHR9XHJcbn1cclxuXHJcbiNuZXh0Y2FyZS1hZHMge1xyXG5cdGRpc3BsYXk6IG5vbmU7XHJcblx0b3ZlcmZsb3c6IHNjcm9sbDtcclxuXHRoZWlnaHQ6IDE4MHB4O1xyXG59XHJcblxyXG4uZC1ibG9jayB7XHJcblx0ZGlzcGxheTogYmxvY2s7XHJcbn1cclxuXHJcbi50aXRsZS10ZXh0IHtcclxuXHRjb2xvcjogJGNvbG9yLW5leHRnZW4tYmx1ZTtcclxufVxyXG5cclxuOmhvc3QgaW9uLWRhdGV0aW1lICNzaGFkb3ctcm9vdCB7XHJcblx0LmRhdGV0aW1lLWNhbGVuZGFyIHtcclxuXHRcdC5jYWxlbmRhci1oZWFkZXIge1xyXG5cdFx0XHQuY2FsZW5kYXItYWN0aW9uLWJ1dHRvbnMge1xyXG5cdFx0XHRcdC5jYWxlbmRhci1tb250aC15ZWFyIHtcclxuXHRcdFx0XHRcdGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcblx0XHRcdFx0XHRqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuXHRcdFx0XHRcdGRpc3BsYXk6IGZsZXg7XHJcblx0XHRcdFx0XHR3aWR0aDogMTAwJTtcclxuXHJcblx0XHRcdFx0XHRpb24taWNvbiB7XHJcblx0XHRcdFx0XHRcdGRpc3BsYXk6IG5vbmU7XHJcblx0XHRcdFx0XHR9XHJcblx0XHRcdFx0fVxyXG5cclxuXHRcdFx0XHQuY2FsZW5kYXItbmV4dC1wcmV2IHtcclxuXHRcdFx0XHRcdHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuXHRcdFx0XHRcdHdpZHRoOiAxMDAlO1xyXG5cdFx0XHRcdFx0cmlnaHQ6IDA7XHJcblxyXG5cdFx0XHRcdFx0aW9uLWJ1dHRvbnMge1xyXG5cdFx0XHRcdFx0XHRkaXNwbGF5OiBmbGV4O1xyXG5cdFx0XHRcdFx0XHRqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XHJcblx0XHRcdFx0XHRcdHdpZHRoOiAxMDAlO1xyXG5cdFx0XHRcdFx0fVxyXG5cdFx0XHRcdH1cclxuXHRcdFx0fVxyXG5cdFx0fVxyXG5cdH1cclxufVxyXG5cclxuLm1hdC1kaWFsb2ctY29udGFpbmVyIHtcclxuXHRwYWRkaW5nOiB1bnNldCAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4vKiBDaGFuZ2UgYXV0b2NvbXBsZXRlIHN0eWxlcyBpbiBXZWJLaXQgKi9cclxuaW5wdXQ6LXdlYmtpdC1hdXRvZmlsbCxcclxuaW5wdXQ6LXdlYmtpdC1hdXRvZmlsbDpob3ZlcixcclxuaW5wdXQ6LXdlYmtpdC1hdXRvZmlsbDpmb2N1cyxcclxudGV4dGFyZWE6LXdlYmtpdC1hdXRvZmlsbCxcclxudGV4dGFyZWE6LXdlYmtpdC1hdXRvZmlsbDpob3ZlcixcclxudGV4dGFyZWE6LXdlYmtpdC1hdXRvZmlsbDpmb2N1cyxcclxuc2VsZWN0Oi13ZWJraXQtYXV0b2ZpbGwsXHJcbnNlbGVjdDotd2Via2l0LWF1dG9maWxsOmhvdmVyLFxyXG5zZWxlY3Q6LXdlYmtpdC1hdXRvZmlsbDpmb2N1cyB7XHJcblx0LXdlYmtpdC10ZXh0LWZpbGwtY29sb3I6IGJsYWNrO1xyXG5cdC13ZWJraXQtYm94LXNoYWRvdzogMCAwIDBweCAxMDAwcHggd2hpdGUgaW5zZXQ7XHJcblx0dHJhbnNpdGlvbjogYmFja2dyb3VuZC1jb2xvciA1MDAwcyBlYXNlLWluLW91dCAwcztcclxufVxyXG5cclxuLmZvcmNlLXVwZGF0ZS1wb3B1cCArIC5jZGstZ2xvYmFsLW92ZXJsYXktd3JhcHBlciB7XHJcblx0LnNhdmUtYnRuIHtcclxuXHRcdGJhY2tncm91bmQ6IHZhcigtLWx1bWktcHJpbWFyeS15ZWxsb3ctY29sb3IpICFpbXBvcnRhbnQ7XHJcblx0XHRjb2xvcjogdmFyKC0tbHVtaS13aGl0ZS1jb2xvcikgIWltcG9ydGFudDtcclxuXHRcdGZvbnQtd2VpZ2h0OiBib2xkICFpbXBvcnRhbnQ7XHJcblx0fVxyXG5cclxuXHQuY2FuY2VsLWJ0biB7XHJcblx0XHRjb2xvcjogdmFyKC0tbHVtaS1wcmltYXJ5LXllbGxvdy1jb2xvcikgIWltcG9ydGFudDtcclxuXHR9XHJcbn1cclxuXHJcbkAtd2Via2l0LWtleWZyYW1lcyBzbGlkZUluUmlnaHQge1xyXG5cdDAlIHtcclxuXHRcdC13ZWJraXQtdHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgxMDAlLCAwLCAwKTtcclxuXHRcdHRyYW5zZm9ybTogdHJhbnNsYXRlM2QoMTAwJSwgMCwgMCk7XHJcblx0XHR2aXNpYmlsaXR5OiB2aXNpYmxlO1xyXG5cdH1cclxuXHJcblx0dG8ge1xyXG5cdFx0LXdlYmtpdC10cmFuc2Zvcm06IHRyYW5zbGF0ZVooMCk7XHJcblx0XHR0cmFuc2Zvcm06IHRyYW5zbGF0ZVooMCk7XHJcblx0fVxyXG59XHJcblxyXG5Aa2V5ZnJhbWVzIHNsaWRlSW5SaWdodCB7XHJcblx0MCUge1xyXG5cdFx0LXdlYmtpdC10cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKDEwMCUsIDAsIDApO1xyXG5cdFx0dHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgxMDAlLCAwLCAwKTtcclxuXHRcdHZpc2liaWxpdHk6IHZpc2libGU7XHJcblx0fVxyXG5cclxuXHR0byB7XHJcblx0XHQtd2Via2l0LXRyYW5zZm9ybTogdHJhbnNsYXRlWigwKTtcclxuXHRcdHRyYW5zZm9ybTogdHJhbnNsYXRlWigwKTtcclxuXHR9XHJcbn1cclxuXHJcbi5hbmltYXRlX19zbGlkZUluUmlnaHQge1xyXG5cdC13ZWJraXQtYW5pbWF0aW9uLW5hbWU6IHNsaWRlSW5SaWdodDtcclxuXHRhbmltYXRpb24tbmFtZTogc2xpZGVJblJpZ2h0O1xyXG59XHJcblxyXG4uYW5pbWF0ZV9fYW5pbWF0ZWQge1xyXG5cdC13ZWJraXQtYW5pbWF0aW9uLWR1cmF0aW9uOiAwLjVzO1xyXG5cdGFuaW1hdGlvbi1kdXJhdGlvbjogMC41cztcclxuXHQtd2Via2l0LWFuaW1hdGlvbi1kdXJhdGlvbjogMC41cztcclxuXHRhbmltYXRpb24tZHVyYXRpb246IDAuNXM7XHJcblx0LXdlYmtpdC1hbmltYXRpb24tZmlsbC1tb2RlOiBib3RoO1xyXG5cdGFuaW1hdGlvbi1maWxsLW1vZGU6IGJvdGg7XHJcbn1cclxuIiwiLmRpc3BsYXkteGwge1xyXG4gICAgZm9udC1zaXplOiA0MXB4ICFpbXBvcnRhbnQ7XHJcbiAgICBmb250LXdlaWdodDogNDAwICFpbXBvcnRhbnQ7XHJcbiAgICBsaW5lLWhlaWdodDogMTIwJSAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4uZGlzcGxheS1tZCB7XHJcbiAgICBmb250LXNpemU6IDM2cHggIWltcG9ydGFudDtcclxuICAgIGZvbnQtd2VpZ2h0OiA0MDAgIWltcG9ydGFudDtcclxuICAgIGxpbmUtaGVpZ2h0OiAxMjAlICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5oMSB7XHJcbiAgICBmb250LXNpemU6IDMxcHggIWltcG9ydGFudDtcclxuICAgIGZvbnQtd2VpZ2h0OiA0MDAgIWltcG9ydGFudDtcclxuICAgIGxpbmUtaGVpZ2h0OiAxMjAlICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5oMiB7XHJcbiAgICBmb250LXNpemU6IDI4cHggIWltcG9ydGFudDtcclxuICAgIGZvbnQtd2VpZ2h0OiA0MDAgIWltcG9ydGFudDtcclxuICAgIGxpbmUtaGVpZ2h0OiAxMjAlICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5oMyB7XHJcbiAgICBmb250LXNpemU6IDI1cHggIWltcG9ydGFudDtcclxuICAgIGZvbnQtd2VpZ2h0OiA0MDAgIWltcG9ydGFudDtcclxuICAgIGxpbmUtaGVpZ2h0OiAxMjAlICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5oNCB7XHJcbiAgICBmb250LXNpemU6IDIycHggIWltcG9ydGFudDtcclxuICAgIGZvbnQtd2VpZ2h0OiA0MDAgIWltcG9ydGFudDtcclxuICAgIGxpbmUtaGVpZ2h0OiAxMjAlICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5oNSB7XHJcbiAgICBmb250LXNpemU6IDE5cHggIWltcG9ydGFudDtcclxuICAgIGZvbnQtd2VpZ2h0OiA0MDAgIWltcG9ydGFudDtcclxuICAgIGxpbmUtaGVpZ2h0OiAxMjAlICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5oNiB7XHJcbiAgICBmb250LXNpemU6IDE3cHggIWltcG9ydGFudDtcclxuICAgIGZvbnQtd2VpZ2h0OiA0MDAgIWltcG9ydGFudDtcclxuICAgIGxpbmUtaGVpZ2h0OiAxMjAlICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5ib2R5LWwge1xyXG4gICAgZm9udC1zaXplOiAxN3B4ICFpbXBvcnRhbnQ7XHJcbiAgICBmb250LXdlaWdodDogNDAwICFpbXBvcnRhbnQ7XHJcbiAgICBsaW5lLWhlaWdodDogMTIwJSAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4uYm9keS1uIHtcclxuICAgIGZvbnQtc2l6ZTogMTVweCAhaW1wb3J0YW50O1xyXG4gICAgZm9udC13ZWlnaHQ6IDQwMCAhaW1wb3J0YW50O1xyXG4gICAgbGluZS1oZWlnaHQ6IDEyMCUgIWltcG9ydGFudDtcclxufVxyXG5cclxuLmJvZHktc20ge1xyXG4gICAgZm9udC1zaXplOiAxM3B4ICFpbXBvcnRhbnQ7XHJcbiAgICBmb250LXdlaWdodDogNDAwICFpbXBvcnRhbnQ7XHJcbiAgICBsaW5lLWhlaWdodDogMTIwJSAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4uYm9keS14cyB7XHJcbiAgICBmb250LXNpemU6IDEycHggIWltcG9ydGFudDtcclxuICAgIGZvbnQtd2VpZ2h0OiA0MDAgIWltcG9ydGFudDtcclxuICAgIGxpbmUtaGVpZ2h0OiAxMjAlICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5zZW1pYm9sZCB7XHJcbiAgICAmLmRpc3BsYXkteGwge1xyXG4gICAgICAgIGZvbnQtd2VpZ2h0OiA2MDAgIWltcG9ydGFudDtcclxuICAgIH1cclxuICAgICYuZGlzcGxheS1tZCB7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IDYwMCAhaW1wb3J0YW50O1xyXG4gICAgfVxyXG4gICAgJi5oMSB7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IDYwMCAhaW1wb3J0YW50O1xyXG4gICAgfVxyXG4gICAgJi5oMiB7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IDYwMCAhaW1wb3J0YW50O1xyXG4gICAgfVxyXG4gICAgJi5oMyB7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IDYwMCAhaW1wb3J0YW50O1xyXG4gICAgfVxyXG4gICAgJi5oNCB7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IDYwMCAhaW1wb3J0YW50O1xyXG4gICAgfVxyXG4gICAgJi5oNSB7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IDYwMCAhaW1wb3J0YW50O1xyXG4gICAgfVxyXG4gICAgJi5oNiB7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IDYwMCAhaW1wb3J0YW50O1xyXG4gICAgfVxyXG4gICAgJi5ib2R5LWwge1xyXG4gICAgICAgIGZvbnQtd2VpZ2h0OiA2MDAgIWltcG9ydGFudDtcclxuICAgIH1cclxuICAgICYuYm9keS1uIHtcclxuICAgICAgICBmb250LXdlaWdodDogNjAwICFpbXBvcnRhbnQ7XHJcbiAgICB9XHJcbiAgICAmLmJvZHktc20ge1xyXG4gICAgICAgIGZvbnQtd2VpZ2h0OiA2MDAgIWltcG9ydGFudDtcclxuICAgIH1cclxuICAgICYuYm9keS14cyB7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IDYwMCAhaW1wb3J0YW50O1xyXG4gICAgfVxyXG59XHJcblxyXG4uYm9sZCB7XHJcbiAgICAmLmRpc3BsYXkteGwge1xyXG4gICAgICAgIGZvbnQtd2VpZ2h0OiA3MDAgIWltcG9ydGFudDtcclxuICAgIH1cclxuICAgICYuZGlzcGxheS1tZCB7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IDcwMCAhaW1wb3J0YW50O1xyXG4gICAgfVxyXG4gICAgJi5oMSB7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IDcwMCAhaW1wb3J0YW50O1xyXG4gICAgfVxyXG4gICAgJi5oMiB7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IDcwMCAhaW1wb3J0YW50O1xyXG4gICAgfVxyXG4gICAgJi5oMyB7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IDcwMCAhaW1wb3J0YW50O1xyXG4gICAgfVxyXG4gICAgJi5oNCB7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IDcwMCAhaW1wb3J0YW50O1xyXG4gICAgfVxyXG4gICAgJi5oNSB7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IDcwMCAhaW1wb3J0YW50O1xyXG4gICAgfVxyXG4gICAgJi5oNiB7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IDcwMCAhaW1wb3J0YW50O1xyXG4gICAgfVxyXG4gICAgJi5ib2R5LWwge1xyXG4gICAgICAgIGZvbnQtd2VpZ2h0OiA3MDAgIWltcG9ydGFudDtcclxuICAgIH1cclxuICAgICYuYm9keS1uIHtcclxuICAgICAgICBmb250LXdlaWdodDogNzAwICFpbXBvcnRhbnQ7XHJcbiAgICB9XHJcbiAgICAmLmJvZHktc20ge1xyXG4gICAgICAgIGZvbnQtd2VpZ2h0OiA3MDAgIWltcG9ydGFudDtcclxuICAgIH1cclxuICAgICYuYm9keS14cyB7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IDcwMCAhaW1wb3J0YW50O1xyXG4gICAgfVxyXG59Il19 */";

/***/ }),

/***/ 68788:
/*!****************************************************************!*\
  !*** ./src/app/pages/new-claim/new-claim.page.scss?ngResource ***!
  \****************************************************************/
/***/ ((module) => {

module.exports = ":root {\n  --nc-color-nextgen-neutral-grey-50: red;\n  --nc-color-nextgen-white: yellow;\n  --nc-color-nextgen-blue: #0d152e;\n  --nc-color-nextgen-green: #00908d;\n  --nc-color-nextgen-black: #000000;\n  --nc-color-nextgen-grey-background: #c8d3da;\n  --nc-color-nextgen-grey: #92a2ac;\n  --nc-color-nextgen-stone-grey: #fafafa;\n  --nc-color-nextgen-error: #fc1055;\n  --nc-color-nextgen-neutral-grey: #414141;\n  --nc-color-nextgen-fibrant-green: #00bab6;\n  --nc-color-nextgen-warning: #ffd048;\n  --nc-color-nextgen-green-background: #e6f2f2;\n  --nc-color-nextgen-neutral-grey-400: #7a7a7a;\n  --nc-color-nextgen-neutral-grey-100: #eff3f5;\n  --nc-color-nextgen-status-error: #ba0c3f;\n  --nc-color-nextgen-status-error-background: #ffeff4;\n  --nc-color-nextgen-status-warning: #cba127;\n  --nc-color-nextgen-status-warning-background: #fff8e6;\n  --nc-color-nextgen-blue-100: #dfeff2;\n  --nc-color-nextgen-error-red-700: #f62459;\n  --nc-color-nextgen-blue-500: #006192;\n  --nc-color-nextgen-blue-400: #79cdec;\n  --nc-color-nextgen-red-500: #ff6592;\n  --nc-color-nextgen-secondary-blue-300: #13a0d3;\n  --lumi-white-color: #ffffff;\n  --lumi-primary-yellow-color: #fab600;\n}\n\n.ion-color-green {\n  --ion-color-base: var(--nc-color-nextgen-green);\n  --ion-color-base-rgb: var(--nc-color-nextgen-green);\n  --ion-color-contrast: var(--nc-color-nextgen-white);\n  --ion-color-contrast-rgb: var(--nc-color-nextgen-green);\n  --ion-color-shade: var(--nc-color-nextgen-green);\n  --ion-color-tint: var(--nc-color-nextgen-green);\n}\n\n/*\n * 1. Custom CSS \n * ----------------------------------------------------------------------------\n */\n\n:root {\n  --nc-color-nextgen-neutral-grey-50: red;\n  --nc-color-nextgen-white: yellow;\n  --nc-color-nextgen-blue: #0d152e;\n  --nc-color-nextgen-green: #00908d;\n  --nc-color-nextgen-black: #000000;\n  --nc-color-nextgen-grey-background: #c8d3da;\n  --nc-color-nextgen-grey: #92a2ac;\n  --nc-color-nextgen-stone-grey: #fafafa;\n  --nc-color-nextgen-error: #fc1055;\n  --nc-color-nextgen-neutral-grey: #414141;\n  --nc-color-nextgen-fibrant-green: #00bab6;\n  --nc-color-nextgen-warning: #ffd048;\n  --nc-color-nextgen-green-background: #e6f2f2;\n  --nc-color-nextgen-neutral-grey-400: #7a7a7a;\n  --nc-color-nextgen-neutral-grey-100: #eff3f5;\n  --nc-color-nextgen-status-error: #ba0c3f;\n  --nc-color-nextgen-status-error-background: #ffeff4;\n  --nc-color-nextgen-status-warning: #cba127;\n  --nc-color-nextgen-status-warning-background: #fff8e6;\n  --nc-color-nextgen-blue-100: #dfeff2;\n  --nc-color-nextgen-error-red-700: #f62459;\n  --nc-color-nextgen-blue-500: #006192;\n  --nc-color-nextgen-blue-400: #79cdec;\n  --nc-color-nextgen-red-500: #ff6592;\n  --nc-color-nextgen-secondary-blue-300: #13a0d3;\n  --lumi-white-color: #ffffff;\n  --lumi-primary-yellow-color: #fab600;\n}\n\n.ion-color-green {\n  --ion-color-base: var(--nc-color-nextgen-green);\n  --ion-color-base-rgb: var(--nc-color-nextgen-green);\n  --ion-color-contrast: var(--nc-color-nextgen-white);\n  --ion-color-contrast-rgb: var(--nc-color-nextgen-green);\n  --ion-color-shade: var(--nc-color-nextgen-green);\n  --ion-color-tint: var(--nc-color-nextgen-green);\n}\n\n.display-xl {\n  font-size: 41px !important;\n  font-weight: 400 !important;\n  line-height: 120% !important;\n}\n\n.display-md {\n  font-size: 36px !important;\n  font-weight: 400 !important;\n  line-height: 120% !important;\n}\n\n.h1 {\n  font-size: 31px !important;\n  font-weight: 400 !important;\n  line-height: 120% !important;\n}\n\n.h2 {\n  font-size: 28px !important;\n  font-weight: 400 !important;\n  line-height: 120% !important;\n}\n\n.h3 {\n  font-size: 25px !important;\n  font-weight: 400 !important;\n  line-height: 120% !important;\n}\n\n.h4 {\n  font-size: 22px !important;\n  font-weight: 400 !important;\n  line-height: 120% !important;\n}\n\n.h5 {\n  font-size: 19px !important;\n  font-weight: 400 !important;\n  line-height: 120% !important;\n}\n\n.h6 {\n  font-size: 17px !important;\n  font-weight: 400 !important;\n  line-height: 120% !important;\n}\n\n.body-l {\n  font-size: 17px !important;\n  font-weight: 400 !important;\n  line-height: 120% !important;\n}\n\n.body-n {\n  font-size: 15px !important;\n  font-weight: 400 !important;\n  line-height: 120% !important;\n}\n\n.body-sm {\n  font-size: 13px !important;\n  font-weight: 400 !important;\n  line-height: 120% !important;\n}\n\n.body-xs {\n  font-size: 12px !important;\n  font-weight: 400 !important;\n  line-height: 120% !important;\n}\n\n.semibold.display-xl {\n  font-weight: 600 !important;\n}\n\n.semibold.display-md {\n  font-weight: 600 !important;\n}\n\n.semibold.h1 {\n  font-weight: 600 !important;\n}\n\n.semibold.h2 {\n  font-weight: 600 !important;\n}\n\n.semibold.h3 {\n  font-weight: 600 !important;\n}\n\n.semibold.h4 {\n  font-weight: 600 !important;\n}\n\n.semibold.h5 {\n  font-weight: 600 !important;\n}\n\n.semibold.h6 {\n  font-weight: 600 !important;\n}\n\n.semibold.body-l {\n  font-weight: 600 !important;\n}\n\n.semibold.body-n {\n  font-weight: 600 !important;\n}\n\n.semibold.body-sm {\n  font-weight: 600 !important;\n}\n\n.semibold.body-xs {\n  font-weight: 600 !important;\n}\n\n.bold.display-xl {\n  font-weight: 700 !important;\n}\n\n.bold.display-md {\n  font-weight: 700 !important;\n}\n\n.bold.h1 {\n  font-weight: 700 !important;\n}\n\n.bold.h2 {\n  font-weight: 700 !important;\n}\n\n.bold.h3 {\n  font-weight: 700 !important;\n}\n\n.bold.h4 {\n  font-weight: 700 !important;\n}\n\n.bold.h5 {\n  font-weight: 700 !important;\n}\n\n.bold.h6 {\n  font-weight: 700 !important;\n}\n\n.bold.body-l {\n  font-weight: 700 !important;\n}\n\n.bold.body-n {\n  font-weight: 700 !important;\n}\n\n.bold.body-sm {\n  font-weight: 700 !important;\n}\n\n.bold.body-xs {\n  font-weight: 700 !important;\n}\n\n@font-face {\n  font-family: \"Allianz Neo\";\n  font-style: normal;\n  font-weight: 300;\n  font-display: swap;\n  src: url('AllianzNeoW04-Light.woff2') format(\"woff2\"), url('AllianzNeoW04-Light.woff') format(\"woff\");\n}\n\n@font-face {\n  font-family: \"Allianz Neo\";\n  font-style: italic;\n  font-weight: 300;\n  font-display: swap;\n  src: url('AllianzNeoW04-LightItalic.woff2') format(\"woff2\"), url('AllianzNeoW04-LightItalic.woff') format(\"woff\");\n}\n\n@font-face {\n  font-family: \"Allianz Neo\";\n  font-style: normal;\n  font-weight: 400;\n  font-display: swap;\n  src: url('AllianzNeoW04-Regular.woff2') format(\"woff2\"), url('AllianzNeoW04-Regular.woff') format(\"woff\");\n}\n\n@font-face {\n  font-family: \"Allianz Neo\";\n  font-style: italic;\n  font-weight: 400;\n  font-display: swap;\n  src: url('AllianzNeoW04-Italic.woff2') format(\"woff2\"), url('AllianzNeoW04-Italic.woff') format(\"woff\");\n}\n\n@font-face {\n  font-family: \"Allianz Neo\";\n  font-style: normal;\n  font-weight: 600;\n  font-display: swap;\n  src: url('AllianzNeoW04-SemiBold.woff2') format(\"woff2\"), url('AllianzNeoW04-SemiBold.woff') format(\"woff\");\n}\n\n@font-face {\n  font-family: \"Allianz Neo\";\n  font-style: italic;\n  font-weight: 600;\n  font-display: swap;\n  src: url('AllianzNeoW04-SemiBoldIt.woff2') format(\"woff2\"), url('AllianzNeoW04-SemiBoldIt.woff') format(\"woff\");\n}\n\n@font-face {\n  font-family: \"Allianz Neo\";\n  font-style: normal;\n  font-weight: 700;\n  font-display: swap;\n  src: url('AllianzNeoW04-Bold.woff2') format(\"woff2\"), url('AllianzNeoW04-Bold.woff') format(\"woff\");\n}\n\n@font-face {\n  font-family: \"Allianz Neo\";\n  font-style: italic;\n  font-weight: 700;\n  font-display: swap;\n  src: url('AllianzNeoW04-BoldItalic.woff2') format(\"woff2\"), url('AllianzNeoW04-BoldItalic.woff') format(\"woff\");\n}\n\n* {\n  color: var(--nc-color-nextgen-neutral-grey);\n  font-family: \"Allianz Neo\", sans-serif;\n  font-weight: 400;\n  font-size: 16px;\n}\n\nhtml {\n  --ion-safe-area-top: 0px;\n}\n\n.col-1 {\n  width: 8.33%;\n}\n\n.col-2 {\n  width: 16.66%;\n}\n\n.col-3 {\n  width: 25%;\n}\n\n.col-4 {\n  width: 33.33%;\n}\n\n.col-5 {\n  width: 41.66%;\n}\n\n.col-6 {\n  width: 50%;\n}\n\n.col-7 {\n  width: 58.33%;\n}\n\n.col-8 {\n  width: 66.66%;\n}\n\n.col-9 {\n  width: 75%;\n}\n\n.col-10 {\n  width: 83.33%;\n}\n\n.col-11 {\n  width: 91.66%;\n}\n\n.col-12 {\n  width: 100%;\n}\n\n@media only screen and (max-width: 576px) {\n  /* For tablets: */\n  .col-sm-1 {\n    width: 8.33%;\n  }\n\n  .col-sm-2 {\n    width: 16.66%;\n  }\n\n  .col-sm-3 {\n    width: 25%;\n  }\n\n  .col-sm-4 {\n    width: 33.33%;\n  }\n\n  .col-sm-5 {\n    width: 41.66%;\n  }\n\n  .col-sm-6 {\n    width: 50%;\n  }\n\n  .col-sm-7 {\n    width: 58.33%;\n  }\n\n  .col-sm-8 {\n    width: 66.66%;\n  }\n\n  .col-sm-9 {\n    width: 75%;\n  }\n\n  .col-sm-10 {\n    width: 83.33%;\n  }\n\n  .col-sm-11 {\n    width: 91.66%;\n  }\n\n  .col-sm-12 {\n    width: 100%;\n  }\n}\n\n@media only screen and (max-width: 768px) and (min-width: 577px) {\n  /* For tablets: */\n  .col-md-1 {\n    width: 8.33%;\n  }\n\n  .col-md-2 {\n    width: 16.66%;\n  }\n\n  .col-md-3 {\n    width: 25%;\n  }\n\n  .col-md-4 {\n    width: 33.33%;\n  }\n\n  .col-md-5 {\n    width: 41.66%;\n  }\n\n  .col-md-6 {\n    width: 50%;\n  }\n\n  .col-md-7 {\n    width: 58.33%;\n  }\n\n  .col-md-8 {\n    width: 66.66%;\n  }\n\n  .col-md-9 {\n    width: 75%;\n  }\n\n  .col-md-10 {\n    width: 83.33%;\n  }\n\n  .col-md-11 {\n    width: 91.66%;\n  }\n\n  .col-md-12 {\n    width: 100%;\n  }\n}\n\n@media only screen and (min-width: 769px) {\n  /* For tablets: */\n  .col-lg-1 {\n    width: 8.33%;\n  }\n\n  .col-lg-2 {\n    width: 16.66%;\n  }\n\n  .col-lg-3 {\n    width: 25%;\n  }\n\n  .col-lg-4 {\n    width: 33.33%;\n  }\n\n  .col-lg-5 {\n    width: 41.66%;\n  }\n\n  .col-lg-6 {\n    width: 50%;\n  }\n\n  .col-lg-7 {\n    width: 58.33%;\n  }\n\n  .col-lg-8 {\n    width: 66.66%;\n  }\n\n  .col-lg-9 {\n    width: 75%;\n  }\n\n  .col-lg-10 {\n    width: 83.33%;\n  }\n\n  .col-lg-11 {\n    width: 91.66%;\n  }\n\n  .col-lg-12 {\n    width: 100%;\n  }\n}\n\n.row {\n  display: flex;\n  justify-content: center;\n  align-items: center;\n}\n\n.custom-toast {\n  --max-width: fit-content;\n}\n\n/*\n * 2. Custom CSS for compatibility with Edge\n * ----------------------------------------------------------------------------\n */\n\ninput::-ms-reveal,\ninput::-ms-clear {\n  display: none;\n}\n\n.swal2-popup {\n  margin-top: 20px;\n}\n\n/*\n * 3. Custom CSS for loading controller\n * ----------------------------------------------------------------------------\n */\n\n.transparent-loading-class {\n  --background: transparent;\n  --spinner-color: #47e6b1;\n}\n\n.loading-wrapper.sc-ion-loading-md {\n  box-shadow: unset;\n  -webkit-box-shadow: unset;\n}\n\n.uil {\n  color: var(--nc-color-nextgen-grey);\n}\n\n.btn {\n  height: 48px;\n  border-radius: 28px;\n  padding: 0px 41px 0px 41px;\n  box-shadow: none;\n}\n\n.btn.btn-circle {\n  background-color: var(--nc-color-nextgen-stone-grey) !important;\n  color: var(--nc-color-nextgen-black);\n  padding: unset !important;\n  height: 36px !important;\n  width: 36px !important;\n  border-radius: 50% !important;\n}\n\n.btn.btn-circle i {\n  color: var(--nc-color-nextgen-black);\n}\n\n.btn.primary {\n  background: var(--nc-color-nextgen-green);\n  color: var(--nc-color-nextgen-white);\n}\n\n.btn.primary .uil {\n  color: var(--nc-color-nextgen-white);\n}\n\n.btn.primary:disabled {\n  background-color: var(--nc-color-nextgen-grey-background) !important;\n  color: var(--nc-color-nextgen-grey) !important;\n}\n\n.btn.secondary {\n  background: var(--nc-color-nextgen-white) !important;\n  border-color: var(--nc-color-nextgen-green);\n  border: solid 1px;\n  color: var(--nc-color-nextgen-green);\n}\n\n.btn.secondary .uil {\n  color: var(--nc-color-nextgen-green);\n}\n\n.btn.secondary:disabled {\n  background-color: var(--nc-color-nextgen-white) !important;\n  color: var(--nc-color-nextgen-grey) !important;\n  border-color: var(--nc-color-nextgen-grey-background) !important;\n}\n\n.btn.transparent {\n  background: transparent !important;\n  border-color: var(--nc-color-nextgen-green);\n  border: solid 1px;\n  color: var(--nc-color-nextgen-green);\n}\n\n.btn.transparent .uil {\n  color: var(--nc-color-nextgen-green);\n}\n\n.btn.transparent:disabled {\n  background-color: transparent !important;\n  color: var(--nc-color-nextgen-grey) !important;\n  border-color: var(--nc-color-nextgen-grey-background) !important;\n}\n\n.btn.btn-large {\n  height: 56px !important;\n  width: 100%;\n}\n\n.btn.bold {\n  font-weight: 700 !important;\n}\n\n.btn.semibold {\n  font-weight: 600 !important;\n}\n\n.btn-no-space {\n  padding: 5px !important;\n  height: -moz-fit-content;\n  height: fit-content;\n}\n\n.btn-back {\n  width: 31px;\n  height: 28px;\n  background-color: transparent;\n  padding: 0;\n  color: var(--nc-color-nextgen-green);\n}\n\n.container {\n  padding: 2rem;\n  height: 100%;\n}\n\n.body-section {\n  width: 100%;\n  height: 95%;\n  overflow-y: auto;\n  position: relative;\n}\n\n.top-section {\n  width: 100%;\n  height: 10%;\n  justify-content: space-between;\n  display: flex;\n  align-items: center;\n}\n\n.form-control {\n  position: relative;\n  height: 85px;\n  margin-bottom: 8px;\n}\n\n.control {\n  border-radius: 8px;\n  height: 56px;\n  border: 1px solid var(--nc-color-nextgen-grey-background);\n  width: 100%;\n  position: absolute;\n  top: 32px;\n  background-color: var(--nc-color-nextgen-white);\n}\n\n.control table {\n  table-layout: fixed;\n  border-collapse: unset;\n}\n\n.control input {\n  height: 54px;\n  border: unset;\n  border-radius: 8px;\n  width: max-content;\n  width: 100%;\n  pointer-events: auto;\n  background-color: var(--nc-color-nextgen-white);\n}\n\n.control.textarea {\n  height: 108px;\n}\n\n.control textarea {\n  height: 106px;\n  border: unset;\n  border-radius: 8px;\n  width: max-content;\n  width: 100%;\n  pointer-events: auto;\n  resize: none;\n  background-color: var(--nc-color-nextgen-white);\n}\n\n.control input:focus {\n  outline: none;\n}\n\n.control:focus-within {\n  border-color: var(--nc-color-nextgen-green);\n}\n\n.control:focus-within .first-icon {\n  display: none;\n}\n\n.control:focus-within .first-icon.non-hidden {\n  display: table-cell;\n}\n\n.control .first-icon {\n  width: 32px;\n  text-align: center;\n  padding-left: 8px;\n}\n\n.control .first-icon i {\n  font-size: 24px !important;\n}\n\n.control .second-icon {\n  width: 32px;\n  text-align: center;\n}\n\n.control .second-icon i {\n  font-size: 24px !important;\n}\n\n.control:focus-within ~ div .control-label {\n  color: var(--nc-color-nextgen-green);\n}\n\n.control-error .control {\n  border-color: var(--nc-color-nextgen-error);\n}\n\n.control-error .control-label {\n  color: var(--nc-color-nextgen-error) !important;\n}\n\n.validation-summary li {\n  color: var(--nc-color-nextgen-error) !important;\n  list-style: none;\n}\n\n.validation-summary li i {\n  color: var(--nc-color-nextgen-error) !important;\n}\n\n.mr-1 {\n  margin-right: 0.5rem;\n}\n\n.mb-1 {\n  margin-bottom: 0.5rem;\n}\n\n.dialog-pane {\n  position: absolute;\n  pointer-events: auto;\n  box-sizing: border-box;\n  z-index: 1000;\n  display: block;\n  max-width: 100%;\n  max-height: 100%;\n}\n\n.overlay-backdrop {\n  background-color: var(--nc-color-nextgen-neutral-grey);\n  opacity: 0.2 !important;\n}\n\n.dialog-container {\n  animation: fadeIn 0.5s linear;\n  background-color: var(--nc-color-nextgen-white);\n}\n\n@keyframes fadeIn {\n  from {\n    transform: translateY(100%);\n  }\n  to {\n    transform: translateY(0%);\n  }\n}\n\n.error {\n  color: var(--nc-color-nextgen-error);\n}\n\n.error.background {\n  background-color: var(--nc-color-nextgen-error);\n}\n\n.success {\n  color: var(--nc-color-nextgen-fibrant-green);\n}\n\n.success.background {\n  background-color: var(--nc-color-nextgen-fibrant-green);\n}\n\n.warning {\n  color: var(--nc-color-nextgen-warning);\n}\n\n.warning.background {\n  background-color: var(--nc-color-nextgen-warning);\n}\n\n.select {\n  width: 100%;\n  height: 54px;\n  border: unset;\n  border-radius: 8px;\n  display: grid;\n  -webkit-appearance: none;\n          appearance: none;\n  grid-template-areas: \"select\";\n}\n\n.select:focus {\n  outline: unset;\n}\n\n.color-black {\n  color: var(--nc-color-nextgen-black);\n}\n\n.modal-default {\n  --width: 100%;\n  --height: 100%;\n}\n\n.integration-panel {\n  width: 100%;\n  height: 100%;\n  max-width: 100% !important;\n}\n\n.verloop-button {\n  visibility: hidden;\n}\n\n.back-area {\n  position: fixed;\n  top: 0;\n  right: 0;\n  height: 50px;\n  width: 100%;\n  background-color: var(--nc-color-nextgen-neutral-grey-50);\n  z-index: 9999999;\n}\n\n.back-area.ios {\n  height: 80px;\n}\n\n.title-widget {\n  text-align: center;\n  position: sticky;\n  top: 48px;\n}\n\n.button-back {\n  background-color: #fafafa;\n  height: 36px;\n  width: 36px;\n  border-radius: 50%;\n  position: absolute;\n  left: 18px;\n  bottom: 4px;\n}\n\n.icon-close-widget {\n  position: absolute;\n  z-index: 250;\n  left: 11px;\n  bottom: 13px;\n}\n\n.data-default {\n  position: absolute;\n  top: 50%;\n  left: 50%;\n  transform: translate(-50%, -50%);\n  text-align: center;\n  color: var(--nc-color-nextgen-neutral-grey-400);\n  z-index: 1000;\n}\n\n.avaamo__icon {\n  visibility: hidden !important;\n}\n\n.avaamo__chat__widget.ios #avaamo__popup {\n  padding-top: 40px;\n}\n\n.d-flex {\n  display: flex;\n}\n\nnextcare-layout {\n  left: 0;\n  right: 0;\n  top: 0;\n  bottom: 0;\n  display: flex;\n  position: absolute;\n  flex-direction: column;\n  justify-content: space-between;\n  contain: layout size style;\n  overflow: hidden;\n  background-color: var(--nc-color-nextgen-neutral-grey-50);\n  padding-right: 24px;\n  padding-left: 24px;\n}\n\nion-header.ios.header-ios {\n  margin-top: 40px;\n}\n\n.header-ios ion-toolbar:last-of-type {\n  --border-width: 0px !important;\n}\n\n.header-md.md::after {\n  display: none;\n}\n\nion-toolbar {\n  padding-right: unset !important;\n  padding-left: unset !important;\n}\n\ni.icon-back {\n  content: url('long-arrow-left-icon.svg');\n}\n\n.verloop-widget.ios .verloop-container.visible {\n  height: calc(100% - 40px);\n  top: 40px;\n}\n\n#nextcare-ads {\n  display: none;\n  overflow: scroll;\n  height: 180px;\n}\n\n.d-block {\n  display: block;\n}\n\n.title-text {\n  color: var(--nc-color-nextgen-blue);\n}\n\n:host ion-datetime #shadow-root .datetime-calendar .calendar-header .calendar-action-buttons .calendar-month-year {\n  align-items: center;\n  justify-content: center;\n  display: flex;\n  width: 100%;\n}\n\n:host ion-datetime #shadow-root .datetime-calendar .calendar-header .calendar-action-buttons .calendar-month-year ion-icon {\n  display: none;\n}\n\n:host ion-datetime #shadow-root .datetime-calendar .calendar-header .calendar-action-buttons .calendar-next-prev {\n  position: absolute;\n  width: 100%;\n  right: 0;\n}\n\n:host ion-datetime #shadow-root .datetime-calendar .calendar-header .calendar-action-buttons .calendar-next-prev ion-buttons {\n  display: flex;\n  justify-content: space-between;\n  width: 100%;\n}\n\n.mat-dialog-container {\n  padding: unset !important;\n}\n\n/* Change autocomplete styles in WebKit */\n\ninput:-webkit-autofill,\ninput:-webkit-autofill:hover,\ninput:-webkit-autofill:focus,\ntextarea:-webkit-autofill,\ntextarea:-webkit-autofill:hover,\ntextarea:-webkit-autofill:focus,\nselect:-webkit-autofill,\nselect:-webkit-autofill:hover,\nselect:-webkit-autofill:focus {\n  -webkit-text-fill-color: black;\n  -webkit-box-shadow: 0 0 0px 1000px white inset;\n  -webkit-transition: background-color 5000s ease-in-out 0s;\n  transition: background-color 5000s ease-in-out 0s;\n}\n\n.force-update-popup + .cdk-global-overlay-wrapper .save-btn {\n  background: var(--lumi-primary-yellow-color) !important;\n  color: var(--lumi-white-color) !important;\n  font-weight: bold !important;\n}\n\n.force-update-popup + .cdk-global-overlay-wrapper .cancel-btn {\n  color: var(--lumi-primary-yellow-color) !important;\n}\n\n@keyframes slideInRight {\n  0% {\n    transform: translate3d(100%, 0, 0);\n    visibility: visible;\n  }\n  to {\n    transform: translateZ(0);\n  }\n}\n\n.animate__slideInRight {\n  animation-name: slideInRight;\n}\n\n.animate__animated {\n  animation-duration: 0.5s;\n  animation-duration: 0.5s;\n  animation-fill-mode: both;\n}\n\n.new-claim-container {\n  background-color: var(--nc-color-nextgen-neutral-grey-50);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXGNvbG9yLnNjc3MiLCJuZXctY2xhaW0ucGFnZS5zY3NzIiwiLi5cXC4uXFwuLlxcc3R5bGUuc2NzcyIsIi4uXFwuLlxcLi5cXGZvbnQtc2l6ZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0MsdUNBQUE7RUFDQSxnQ0FBQTtFQUNBLGdDQUFBO0VBQ0EsaUNBQUE7RUFDQSxpQ0FBQTtFQUNBLDJDQUFBO0VBQ0EsZ0NBQUE7RUFDQSxzQ0FBQTtFQUNBLGlDQUFBO0VBQ0Esd0NBQUE7RUFDQSx5Q0FBQTtFQUNBLG1DQUFBO0VBQ0EsNENBQUE7RUFDQSw0Q0FBQTtFQUNBLDRDQUFBO0VBQ0Esd0NBQUE7RUFDQSxtREFBQTtFQUNBLDBDQUFBO0VBQ0EscURBQUE7RUFDQSxvQ0FBQTtFQUNBLHlDQUFBO0VBQ0Esb0NBQUE7RUFDQSxvQ0FBQTtFQUNBLG1DQUFBO0VBQ0EsOENBQUE7RUFFQSwyQkFBQTtFQUNBLG9DQUFBO0FDQUQ7O0FEZ0NBO0VBQ0MsK0NBQUE7RUFDQSxtREFBQTtFQUNBLG1EQUFBO0VBQ0EsdURBQUE7RUFDQSxnREFBQTtFQUNBLCtDQUFBO0FDN0JEOztBQ3JDQTs7O0VBQUE7O0FGQUE7RUFDQyx1Q0FBQTtFQUNBLGdDQUFBO0VBQ0EsZ0NBQUE7RUFDQSxpQ0FBQTtFQUNBLGlDQUFBO0VBQ0EsMkNBQUE7RUFDQSxnQ0FBQTtFQUNBLHNDQUFBO0VBQ0EsaUNBQUE7RUFDQSx3Q0FBQTtFQUNBLHlDQUFBO0VBQ0EsbUNBQUE7RUFDQSw0Q0FBQTtFQUNBLDRDQUFBO0VBQ0EsNENBQUE7RUFDQSx3Q0FBQTtFQUNBLG1EQUFBO0VBQ0EsMENBQUE7RUFDQSxxREFBQTtFQUNBLG9DQUFBO0VBQ0EseUNBQUE7RUFDQSxvQ0FBQTtFQUNBLG9DQUFBO0VBQ0EsbUNBQUE7RUFDQSw4Q0FBQTtFQUVBLDJCQUFBO0VBQ0Esb0NBQUE7QUMyQ0Q7O0FEWEE7RUFDQywrQ0FBQTtFQUNBLG1EQUFBO0VBQ0EsbURBQUE7RUFDQSx1REFBQTtFQUNBLGdEQUFBO0VBQ0EsK0NBQUE7QUNjRDs7QUVoRkE7RUFDSSwwQkFBQTtFQUNBLDJCQUFBO0VBQ0EsNEJBQUE7QUZtRko7O0FFaEZBO0VBQ0ksMEJBQUE7RUFDQSwyQkFBQTtFQUNBLDRCQUFBO0FGbUZKOztBRWhGQTtFQUNJLDBCQUFBO0VBQ0EsMkJBQUE7RUFDQSw0QkFBQTtBRm1GSjs7QUVoRkE7RUFDSSwwQkFBQTtFQUNBLDJCQUFBO0VBQ0EsNEJBQUE7QUZtRko7O0FFaEZBO0VBQ0ksMEJBQUE7RUFDQSwyQkFBQTtFQUNBLDRCQUFBO0FGbUZKOztBRWhGQTtFQUNJLDBCQUFBO0VBQ0EsMkJBQUE7RUFDQSw0QkFBQTtBRm1GSjs7QUVoRkE7RUFDSSwwQkFBQTtFQUNBLDJCQUFBO0VBQ0EsNEJBQUE7QUZtRko7O0FFaEZBO0VBQ0ksMEJBQUE7RUFDQSwyQkFBQTtFQUNBLDRCQUFBO0FGbUZKOztBRWhGQTtFQUNJLDBCQUFBO0VBQ0EsMkJBQUE7RUFDQSw0QkFBQTtBRm1GSjs7QUVoRkE7RUFDSSwwQkFBQTtFQUNBLDJCQUFBO0VBQ0EsNEJBQUE7QUZtRko7O0FFaEZBO0VBQ0ksMEJBQUE7RUFDQSwyQkFBQTtFQUNBLDRCQUFBO0FGbUZKOztBRWhGQTtFQUNJLDBCQUFBO0VBQ0EsMkJBQUE7RUFDQSw0QkFBQTtBRm1GSjs7QUUvRUk7RUFDSSwyQkFBQTtBRmtGUjs7QUVoRkk7RUFDSSwyQkFBQTtBRmtGUjs7QUVoRkk7RUFDSSwyQkFBQTtBRmtGUjs7QUVoRkk7RUFDSSwyQkFBQTtBRmtGUjs7QUVoRkk7RUFDSSwyQkFBQTtBRmtGUjs7QUVoRkk7RUFDSSwyQkFBQTtBRmtGUjs7QUVoRkk7RUFDSSwyQkFBQTtBRmtGUjs7QUVoRkk7RUFDSSwyQkFBQTtBRmtGUjs7QUVoRkk7RUFDSSwyQkFBQTtBRmtGUjs7QUVoRkk7RUFDSSwyQkFBQTtBRmtGUjs7QUVoRkk7RUFDSSwyQkFBQTtBRmtGUjs7QUVoRkk7RUFDSSwyQkFBQTtBRmtGUjs7QUU3RUk7RUFDSSwyQkFBQTtBRmdGUjs7QUU5RUk7RUFDSSwyQkFBQTtBRmdGUjs7QUU5RUk7RUFDSSwyQkFBQTtBRmdGUjs7QUU5RUk7RUFDSSwyQkFBQTtBRmdGUjs7QUU5RUk7RUFDSSwyQkFBQTtBRmdGUjs7QUU5RUk7RUFDSSwyQkFBQTtBRmdGUjs7QUU5RUk7RUFDSSwyQkFBQTtBRmdGUjs7QUU5RUk7RUFDSSwyQkFBQTtBRmdGUjs7QUU5RUk7RUFDSSwyQkFBQTtBRmdGUjs7QUU5RUk7RUFDSSwyQkFBQTtBRmdGUjs7QUU5RUk7RUFDSSwyQkFBQTtBRmdGUjs7QUU5RUk7RUFDSSwyQkFBQTtBRmdGUjs7QUN2TkE7RUFDQywwQkFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrQkFBQTtFQUNBLHFHQUFBO0FEME5EOztBQ3BOQTtFQUNDLDBCQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtFQUNBLGtCQUFBO0VBQ0EsaUhBQUE7QURzTkQ7O0FDaE5BO0VBQ0MsMEJBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0Esa0JBQUE7RUFDQSx5R0FBQTtBRGtORDs7QUM1TUE7RUFDQywwQkFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrQkFBQTtFQUNBLHVHQUFBO0FEOE1EOztBQ3hNQTtFQUNDLDBCQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtFQUNBLGtCQUFBO0VBQ0EsMkdBQUE7QUQwTUQ7O0FDcE1BO0VBQ0MsMEJBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0Esa0JBQUE7RUFDQSwrR0FBQTtBRHNNRDs7QUNoTUE7RUFDQywwQkFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrQkFBQTtFQUNBLG1HQUFBO0FEa01EOztBQzVMQTtFQUNDLDBCQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtFQUNBLGtCQUFBO0VBQ0EsK0dBQUE7QUQ4TEQ7O0FDeExBO0VBQ0MsMkNGOUQ0QjtFRStENUIsc0NBQUE7RUFDQSxnQkFBQTtFQUNBLGVBQUE7QUQwTEQ7O0FDdkxBO0VBQ0Msd0JBQUE7QUQwTEQ7O0FDdkxBO0VBQ0MsWUFBQTtBRDBMRDs7QUN2TEE7RUFDQyxhQUFBO0FEMExEOztBQ3ZMQTtFQUNDLFVBQUE7QUQwTEQ7O0FDdkxBO0VBQ0MsYUFBQTtBRDBMRDs7QUN2TEE7RUFDQyxhQUFBO0FEMExEOztBQ3ZMQTtFQUNDLFVBQUE7QUQwTEQ7O0FDdkxBO0VBQ0MsYUFBQTtBRDBMRDs7QUN2TEE7RUFDQyxhQUFBO0FEMExEOztBQ3ZMQTtFQUNDLFVBQUE7QUQwTEQ7O0FDdkxBO0VBQ0MsYUFBQTtBRDBMRDs7QUN2TEE7RUFDQyxhQUFBO0FEMExEOztBQ3ZMQTtFQUNDLFdBQUE7QUQwTEQ7O0FDdkxBO0VBQ0MsaUJBQUE7RUFDQTtJQUNDLFlBQUE7RUQwTEE7O0VDdkxEO0lBQ0MsYUFBQTtFRDBMQTs7RUN2TEQ7SUFDQyxVQUFBO0VEMExBOztFQ3ZMRDtJQUNDLGFBQUE7RUQwTEE7O0VDdkxEO0lBQ0MsYUFBQTtFRDBMQTs7RUN2TEQ7SUFDQyxVQUFBO0VEMExBOztFQ3ZMRDtJQUNDLGFBQUE7RUQwTEE7O0VDdkxEO0lBQ0MsYUFBQTtFRDBMQTs7RUN2TEQ7SUFDQyxVQUFBO0VEMExBOztFQ3ZMRDtJQUNDLGFBQUE7RUQwTEE7O0VDdkxEO0lBQ0MsYUFBQTtFRDBMQTs7RUN2TEQ7SUFDQyxXQUFBO0VEMExBO0FBQ0Y7O0FDdkxBO0VBQ0MsaUJBQUE7RUFDQTtJQUNDLFlBQUE7RUR5TEE7O0VDdExEO0lBQ0MsYUFBQTtFRHlMQTs7RUN0TEQ7SUFDQyxVQUFBO0VEeUxBOztFQ3RMRDtJQUNDLGFBQUE7RUR5TEE7O0VDdExEO0lBQ0MsYUFBQTtFRHlMQTs7RUN0TEQ7SUFDQyxVQUFBO0VEeUxBOztFQ3RMRDtJQUNDLGFBQUE7RUR5TEE7O0VDdExEO0lBQ0MsYUFBQTtFRHlMQTs7RUN0TEQ7SUFDQyxVQUFBO0VEeUxBOztFQ3RMRDtJQUNDLGFBQUE7RUR5TEE7O0VDdExEO0lBQ0MsYUFBQTtFRHlMQTs7RUN0TEQ7SUFDQyxXQUFBO0VEeUxBO0FBQ0Y7O0FDdExBO0VBQ0MsaUJBQUE7RUFDQTtJQUNDLFlBQUE7RUR3TEE7O0VDckxEO0lBQ0MsYUFBQTtFRHdMQTs7RUNyTEQ7SUFDQyxVQUFBO0VEd0xBOztFQ3JMRDtJQUNDLGFBQUE7RUR3TEE7O0VDckxEO0lBQ0MsYUFBQTtFRHdMQTs7RUNyTEQ7SUFDQyxVQUFBO0VEd0xBOztFQ3JMRDtJQUNDLGFBQUE7RUR3TEE7O0VDckxEO0lBQ0MsYUFBQTtFRHdMQTs7RUNyTEQ7SUFDQyxVQUFBO0VEd0xBOztFQ3JMRDtJQUNDLGFBQUE7RUR3TEE7O0VDckxEO0lBQ0MsYUFBQTtFRHdMQTs7RUNyTEQ7SUFDQyxXQUFBO0VEd0xBO0FBQ0Y7O0FDckxBO0VBQ0MsYUFBQTtFQUNBLHVCQUFBO0VBQ0EsbUJBQUE7QUR1TEQ7O0FDbkxBO0VBQ0Msd0JBQUE7QURzTEQ7O0FDbkxBOzs7RUFBQTs7QUFJQTs7RUFFQyxhQUFBO0FEc0xEOztBQ25MQTtFQUNDLGdCQUFBO0FEc0xEOztBQ25MQTs7O0VBQUE7O0FBSUE7RUFDQyx5QkFBQTtFQUNBLHdCQUFBO0FEc0xEOztBQ25MQTtFQUNDLGlCQUFBO0VBQ0EseUJBQUE7QURzTEQ7O0FDbkxBO0VBQ0MsbUNGM1RvQjtBQ2lmckI7O0FDbkxBO0VBQ0MsWUFBQTtFQUNBLG1CQUFBO0VBQ0EsMEJBQUE7RUFDQSxnQkFBQTtBRHNMRDs7QUNwTEM7RUFDQywrREFBQTtFQUNBLG9DRnhVb0I7RUV5VXBCLHlCQUFBO0VBQ0EsdUJBQUE7RUFDQSxzQkFBQTtFQUNBLDZCQUFBO0FEc0xGOztBQ3BMRTtFQUNDLG9DRi9VbUI7QUNxZ0J0Qjs7QUNsTEM7RUFDQyx5Q0Z0Vm9CO0VFdVZwQixvQ0Z0Vm9CO0FDMGdCdEI7O0FDbExFO0VBQ0Msb0NGelZtQjtBQzZnQnRCOztBQ2pMRTtFQUNDLG9FQUFBO0VBQ0EsOENBQUE7QURtTEg7O0FDL0tDO0VBQ0Msb0RBQUE7RUFDQSwyQ0ZyV29CO0VFc1dwQixpQkFBQTtFQUNBLG9DRnZXb0I7QUN3aEJ0Qjs7QUMvS0U7RUFDQyxvQ0YxV21CO0FDMmhCdEI7O0FDOUtFO0VBQ0MsMERBQUE7RUFDQSw4Q0FBQTtFQUNBLGdFQUFBO0FEZ0xIOztBQzVLQztFQUNDLGtDQUFBO0VBQ0EsMkNGdFhvQjtFRXVYcEIsaUJBQUE7RUFDQSxvQ0Z4WG9CO0FDc2lCdEI7O0FDNUtFO0VBQ0Msb0NGM1htQjtBQ3lpQnRCOztBQzNLRTtFQUNDLHdDQUFBO0VBQ0EsOENBQUE7RUFDQSxnRUFBQTtBRDZLSDs7QUN6S0M7RUFDQyx1QkFBQTtFQUNBLFdBQUE7QUQyS0Y7O0FDeEtDO0VBQ0MsMkJBQUE7QUQwS0Y7O0FDdktDO0VBQ0MsMkJBQUE7QUR5S0Y7O0FDcktBO0VBQ0MsdUJBQUE7RUFDQSx3QkFBQTtFQUFBLG1CQUFBO0FEd0tEOztBQ3JLQTtFQUNDLFdBQUE7RUFDQSxZQUFBO0VBQ0EsNkJBQUE7RUFDQSxVQUFBO0VBQ0Esb0NGN1pxQjtBQ3FrQnRCOztBQ3JLQTtFQUNDLGFBQUE7RUFDQSxZQUFBO0FEd0tEOztBQ3JLQTtFQUNDLFdBQUE7RUFDQSxXQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrQkFBQTtBRHdLRDs7QUNyS0E7RUFDQyxXQUFBO0VBQ0EsV0FBQTtFQUNBLDhCQUFBO0VBQ0EsYUFBQTtFQUNBLG1CQUFBO0FEd0tEOztBQ3JLQTtFQUNDLGtCQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0FEd0tEOztBQ3JLQTtFQUNDLGtCQUFBO0VBQ0EsWUFBQTtFQUNBLHlEQUFBO0VBQ0EsV0FBQTtFQUNBLGtCQUFBO0VBQ0EsU0FBQTtFQUNBLCtDRmhjcUI7QUN3bUJ0Qjs7QUN0S0M7RUFDQyxtQkFBQTtFQUNBLHNCQUFBO0FEd0tGOztBQ3JLQztFQUNDLFlBQUE7RUFDQSxhQUFBO0VBQ0Esa0JBQUE7RUFDQSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxvQkFBQTtFQUNBLCtDRjljb0I7QUNxbkJ0Qjs7QUNwS0M7RUFDQyxhQUFBO0FEc0tGOztBQ25LQztFQUNDLGFBQUE7RUFDQSxhQUFBO0VBQ0Esa0JBQUE7RUFDQSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxvQkFBQTtFQUNBLFlBQUE7RUFDQSwrQ0Y3ZG9CO0FDa29CdEI7O0FDbEtDO0VBQ0MsYUFBQTtBRG9LRjs7QUNqS0M7RUFDQywyQ0Z0ZW9CO0FDeW9CdEI7O0FDaktFO0VBQ0MsYUFBQTtBRG1LSDs7QUNoS0U7RUFDQyxtQkFBQTtBRGtLSDs7QUM5SkM7RUFDQyxXQUFBO0VBQ0Esa0JBQUE7RUFDQSxpQkFBQTtBRGdLRjs7QUM5SkU7RUFDQywwQkFBQTtBRGdLSDs7QUM1SkM7RUFDQyxXQUFBO0VBQ0Esa0JBQUE7QUQ4SkY7O0FDM0pFO0VBQ0MsMEJBQUE7QUQ2Skg7O0FDeEpBO0VBQ0Msb0NGdmdCcUI7QUNrcUJ0Qjs7QUN2SkM7RUFDQywyQ0Z0Z0JvQjtBQ2dxQnRCOztBQ3ZKQztFQUNDLCtDQUFBO0FEeUpGOztBQ3BKQztFQUNDLCtDQUFBO0VBQ0EsZ0JBQUE7QUR1SkY7O0FDckpFO0VBQ0MsK0NBQUE7QUR1Skg7O0FDbEpBO0VBQ0Msb0JBQUE7QURxSkQ7O0FDbEpBO0VBQ0MscUJBQUE7QURxSkQ7O0FDbEpBO0VBQ0Msa0JBQUE7RUFDQSxvQkFBQTtFQUNBLHNCQUFBO0VBQ0EsYUFBQTtFQUNBLGNBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7QURxSkQ7O0FDbEpBO0VBQ0Msc0RGM2lCNEI7RUU0aUI1Qix1QkFBQTtBRHFKRDs7QUNsSkE7RUFDQyw2QkFBQTtFQUNBLCtDRnZqQnFCO0FDNHNCdEI7O0FDbEpBO0VBQ0M7SUFDQywyQkFBQTtFRHFKQTtFQ2xKRDtJQUNDLHlCQUFBO0VEb0pBO0FBQ0Y7O0FDakpBO0VBQ0Msb0NGaGtCcUI7QUNtdEJ0Qjs7QUNqSkM7RUFDQywrQ0Zua0JvQjtBQ3N0QnRCOztBQy9JQTtFQUNDLDRDRnRrQjZCO0FDd3RCOUI7O0FDaEpDO0VBQ0MsdURGemtCNEI7QUMydEI5Qjs7QUM5SUE7RUFDQyxzQ0Y3a0J1QjtBQzh0QnhCOztBQy9JQztFQUNDLGlERmhsQnNCO0FDaXVCeEI7O0FDN0lBO0VBQ0MsV0FBQTtFQUNBLFlBQUE7RUFDQSxhQUFBO0VBQ0Esa0JBQUE7RUFDQSxhQUFBO0VBQ0Esd0JBQUE7VUFBQSxnQkFBQTtFQUNBLDZCQUFBO0FEZ0pEOztBQzlJQztFQUNDLGNBQUE7QURnSkY7O0FDNUlBO0VBQ0Msb0NGMW1CcUI7QUN5dkJ0Qjs7QUM1SUE7RUFDQyxhQUFBO0VBQ0EsY0FBQTtBRCtJRDs7QUM1SUE7RUFDQyxXQUFBO0VBQ0EsWUFBQTtFQUNBLDBCQUFBO0FEK0lEOztBQzVJQTtFQUNDLGtCQUFBO0FEK0lEOztBQzVJQTtFQUNDLGVBQUE7RUFDQSxNQUFBO0VBQ0EsUUFBQTtFQUNBLFlBQUE7RUFDQSxXQUFBO0VBQ0EseURGem5CK0I7RUUwbkIvQixnQkFBQTtBRCtJRDs7QUM3SUM7RUFDQyxZQUFBO0FEK0lGOztBQzNJQTtFQUNDLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxTQUFBO0FEOElEOztBQzNJQTtFQUNDLHlCQUFBO0VBQ0EsWUFBQTtFQUNBLFdBQUE7RUFDQSxrQkFBQTtFQUNBLGtCQUFBO0VBQ0EsVUFBQTtFQUNBLFdBQUE7QUQ4SUQ7O0FDM0lBO0VBQ0Msa0JBQUE7RUFDQSxZQUFBO0VBQ0EsVUFBQTtFQUNBLFlBQUE7QUQ4SUQ7O0FDM0lBO0VBQ0Msa0JBQUE7RUFDQSxRQUFBO0VBQ0EsU0FBQTtFQUNBLGdDQUFBO0VBQ0Esa0JBQUE7RUFDQSwrQ0Y3cEJnQztFRThwQmhDLGFBQUE7QUQ4SUQ7O0FDM0lBO0VBQ0MsNkJBQUE7QUQ4SUQ7O0FDMUlDO0VBQ0MsaUJBQUE7QUQ2SUY7O0FDeklBO0VBQ0MsYUFBQTtBRDRJRDs7QUN6SUE7RUFDQyxPQUFBO0VBQ0EsUUFBQTtFQUNBLE1BQUE7RUFDQSxTQUFBO0VBQ0EsYUFBQTtFQUNBLGtCQUFBO0VBQ0Esc0JBQUE7RUFDQSw4QkFBQTtFQUNBLDBCQUFBO0VBQ0EsZ0JBQUE7RUFDQSx5REYzckIrQjtFRTRyQi9CLG1CQUFBO0VBQ0Esa0JBQUE7QUQ0SUQ7O0FDeklBO0VBQ0MsZ0JBQUE7QUQ0SUQ7O0FDeklBO0VBQ0MsOEJBQUE7QUQ0SUQ7O0FDeklBO0VBQ0MsYUFBQTtBRDRJRDs7QUN6SUE7RUFDQywrQkFBQTtFQUNBLDhCQUFBO0FENElEOztBQ3pJQTtFQUNDLHdDQUFBO0FENElEOztBQ3hJQztFQUNDLHlCQUFBO0VBQ0EsU0FBQTtBRDJJRjs7QUN2SUE7RUFDQyxhQUFBO0VBQ0EsZ0JBQUE7RUFDQSxhQUFBO0FEMElEOztBQ3ZJQTtFQUNDLGNBQUE7QUQwSUQ7O0FDdklBO0VBQ0MsbUNGbnZCb0I7QUM2M0JyQjs7QUNuSUk7RUFDQyxtQkFBQTtFQUNBLHVCQUFBO0VBQ0EsYUFBQTtFQUNBLFdBQUE7QURzSUw7O0FDcElLO0VBQ0MsYUFBQTtBRHNJTjs7QUNsSUk7RUFDQyxrQkFBQTtFQUNBLFdBQUE7RUFDQSxRQUFBO0FEb0lMOztBQ2xJSztFQUNDLGFBQUE7RUFDQSw4QkFBQTtFQUNBLFdBQUE7QURvSU47O0FDNUhBO0VBQ0MseUJBQUE7QUQrSEQ7O0FDNUhBLHlDQUFBOztBQUNBOzs7Ozs7Ozs7RUFTQyw4QkFBQTtFQUNBLDhDQUFBO0VBQ0EseURBQUE7RUFBQSxpREFBQTtBRCtIRDs7QUMzSEM7RUFDQyx1REFBQTtFQUNBLHlDQUFBO0VBQ0EsNEJBQUE7QUQ4SEY7O0FDM0hDO0VBQ0Msa0RBQUE7QUQ2SEY7O0FDNUdBO0VBQ0M7SUFFQyxrQ0FBQTtJQUNBLG1CQUFBO0VEMEhBO0VDdkhEO0lBRUMsd0JBQUE7RUR5SEE7QUFDRjs7QUN0SEE7RUFFQyw0QkFBQTtBRHdIRDs7QUNySEE7RUFFQyx3QkFBQTtFQUVBLHdCQUFBO0VBRUEseUJBQUE7QUR3SEQ7O0FBNytCQTtFQUNJLHlERHVDNEI7QUN5OEJoQyIsImZpbGUiOiJuZXctY2xhaW0ucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiOnJvb3Qge1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNTA6IHJlZDtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4td2hpdGU6IHllbGxvdztcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZTogIzBkMTUyZTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW46ICMwMDkwOGQ7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWJsYWNrOiAjMDAwMDAwO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ncmV5LWJhY2tncm91bmQ6ICNjOGQzZGE7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWdyZXk6ICM5MmEyYWM7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0b25lLWdyZXk6ICNmYWZhZmE7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWVycm9yOiAjZmMxMDU1O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXk6ICM0MTQxNDE7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWZpYnJhbnQtZ3JlZW46ICMwMGJhYjY7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXdhcm5pbmc6ICNmZmQwNDg7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuLWJhY2tncm91bmQ6ICNlNmYyZjI7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS00MDA6ICM3YTdhN2E7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS0xMDA6ICNlZmYzZjU7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy1lcnJvcjogI2JhMGMzZjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yLWJhY2tncm91bmQ6ICNmZmVmZjQ7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy13YXJuaW5nOiAjY2JhMTI3O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtd2FybmluZy1iYWNrZ3JvdW5kOiAjZmZmOGU2O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlLTEwMDogI2RmZWZmMjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tZXJyb3ItcmVkLTcwMDogI2Y2MjQ1OTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZS01MDA6ICMwMDYxOTI7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWJsdWUtNDAwOiAjNzljZGVjO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1yZWQtNTAwOiAjZmY2NTkyO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zZWNvbmRhcnktYmx1ZS0zMDA6ICMxM2EwZDM7XHJcblxyXG5cdC0tbHVtaS13aGl0ZS1jb2xvcjogI2ZmZmZmZjtcclxuXHQtLWx1bWktcHJpbWFyeS15ZWxsb3ctY29sb3I6ICNmYWI2MDA7XHJcbn1cclxuJGNvbG9yLW5leHRnZW4tYmx1ZTogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlKTtcclxuJGNvbG9yLW5leHRnZW4tZ3JlZW46IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4pO1xyXG4kY29sb3ItbmV4dGdlbi13aGl0ZTogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi13aGl0ZSk7XHJcbiRjb2xvci1uZXh0Z2VuLWJsYWNrOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWJsYWNrKTtcclxuJGNvbG9yLW5leHRnZW4tZ3JleS1iYWNrZ3JvdW5kOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZXktYmFja2dyb3VuZCk7XHJcbiRjb2xvci1uZXh0Z2VuLWdyZXk6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JleSk7XHJcbiRjb2xvci1uZXh0Z2VuLXN0b25lLWdyZXk6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tc3RvbmUtZ3JleSk7XHJcbiRjb2xvci1uZXh0Z2VuLWVycm9yOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWVycm9yKTtcclxuJGNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5OiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleSk7XHJcbiRjb2xvci1uZXh0Z2VuLWZpYnJhbnQtZ3JlZW46IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZmlicmFudC1ncmVlbik7XHJcbiRjb2xvci1uZXh0Z2VuLXdhcm5pbmc6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4td2FybmluZyk7XHJcbiRjb2xvci1uZXh0Z2VuLWdyZWVuLWJhY2tncm91bmQ6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4tYmFja2dyb3VuZCk7XHJcbiRjb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS01MDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNTApO1xyXG4kY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNDAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS00MDApO1xyXG4kY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktMTAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS0xMDApO1xyXG4kY29sb3ItbmV4dGdlbi1zdGF0dXMtZXJyb3I6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yKTtcclxuJGNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yLWJhY2tncm91bmQ6IHZhcihcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yLWJhY2tncm91bmRcclxuKTtcclxuJGNvbG9yLW5leHRnZW4tc3RhdHVzLXdhcm5pbmc6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLXdhcm5pbmcpO1xyXG4kY29sb3ItbmV4dGdlbi1zdGF0dXMtd2FybmluZy1iYWNrZ3JvdW5kOiB2YXIoXHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy13YXJuaW5nLWJhY2tncm91bmRcclxuKTtcclxuJGNvbG9yLW5leHRnZW4tYmx1ZS0xMDA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZS0xMDApO1xyXG4kY29sb3ItbmV4dGdlbi1lcnJvci1yZWQtNzAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWVycm9yLXJlZC03MDApO1xyXG4kY29sb3ItbmV4dGdlbi1ibHVlLTUwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlLTUwMCk7XHJcbiRjb2xvci1uZXh0Z2VuLWJsdWUtNDAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWJsdWUtNDAwKTtcclxuJGNvbG9yLW5leHRnZW4tcmVkLTUwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1yZWQtNTAwKTtcclxuJGNvbG9yLW5leHRnZW4tc2Vjb25kYXJ5LWJsdWUtMzAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXNlY29uZGFyeS1ibHVlLTMwMCk7XHJcblxyXG4uaW9uLWNvbG9yLWdyZWVuIHtcclxuXHQtLWlvbi1jb2xvci1iYXNlOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuKTtcclxuXHQtLWlvbi1jb2xvci1iYXNlLXJnYjogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbik7XHJcblx0LS1pb24tY29sb3ItY29udHJhc3Q6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4td2hpdGUpO1xyXG5cdC0taW9uLWNvbG9yLWNvbnRyYXN0LXJnYjogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbik7XHJcblx0LS1pb24tY29sb3Itc2hhZGU6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4pO1xyXG5cdC0taW9uLWNvbG9yLXRpbnQ6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4pO1xyXG59XHJcbiIsIkBpbXBvcnQgXCIuLi8uLi8uLi9jb2xvci5zY3NzXCI7XHJcbkBpbXBvcnQgXCIuLi8uLi8uLi9zdHlsZS5zY3NzXCI7XHJcbi5uZXctY2xhaW0tY29udGFpbmVyIHtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICRjb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS01MDtcclxufSIsIi8qXHJcbiAqIDEuIEN1c3RvbSBDU1MgXHJcbiAqIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuICovXHJcblxyXG4vLyBjb2xvciB2YXJpYWJsZVxyXG5AaW1wb3J0IFwiLi9jb2xvci5zY3NzXCI7XHJcbi8vIHR5cG9ncmFwaHlcclxuQGltcG9ydCBcIi4vZm9udC1zaXplLnNjc3NcIjtcclxuXHJcbi8vIEZvbnRzXHJcbkBmb250LWZhY2Uge1xyXG5cdGZvbnQtZmFtaWx5OiBcIkFsbGlhbnogTmVvXCI7XHJcblx0Zm9udC1zdHlsZTogbm9ybWFsO1xyXG5cdGZvbnQtd2VpZ2h0OiAzMDA7XHJcblx0Zm9udC1kaXNwbGF5OiBzd2FwO1xyXG5cdHNyYzogdXJsKFwiLi9hc3NldHMvZm9udHMvQWxsaWFuek5lby9BbGxpYW56X05lb193ZWJmb250cy93b2ZmMi9BbGxpYW56TmVvVzA0LUxpZ2h0LndvZmYyXCIpXHJcblx0XHRcdGZvcm1hdChcIndvZmYyXCIpLFxyXG5cdFx0dXJsKFwiLi9hc3NldHMvZm9udHMvQWxsaWFuek5lby9BbGxpYW56X05lb193ZWJmb250cy93b2ZmL0FsbGlhbnpOZW9XMDQtTGlnaHQud29mZlwiKVxyXG5cdFx0XHRmb3JtYXQoXCJ3b2ZmXCIpO1xyXG59XHJcblxyXG5AZm9udC1mYWNlIHtcclxuXHRmb250LWZhbWlseTogXCJBbGxpYW56IE5lb1wiO1xyXG5cdGZvbnQtc3R5bGU6IGl0YWxpYztcclxuXHRmb250LXdlaWdodDogMzAwO1xyXG5cdGZvbnQtZGlzcGxheTogc3dhcDtcclxuXHRzcmM6IHVybChcIi4vYXNzZXRzL2ZvbnRzL0FsbGlhbnpOZW8vQWxsaWFuel9OZW9fd2ViZm9udHMvd29mZjIvQWxsaWFuek5lb1cwNC1MaWdodEl0YWxpYy53b2ZmMlwiKVxyXG5cdFx0XHRmb3JtYXQoXCJ3b2ZmMlwiKSxcclxuXHRcdHVybChcIi4vYXNzZXRzL2ZvbnRzL0FsbGlhbnpOZW8vQWxsaWFuel9OZW9fd2ViZm9udHMvd29mZi9BbGxpYW56TmVvVzA0LUxpZ2h0SXRhbGljLndvZmZcIilcclxuXHRcdFx0Zm9ybWF0KFwid29mZlwiKTtcclxufVxyXG5cclxuQGZvbnQtZmFjZSB7XHJcblx0Zm9udC1mYW1pbHk6IFwiQWxsaWFueiBOZW9cIjtcclxuXHRmb250LXN0eWxlOiBub3JtYWw7XHJcblx0Zm9udC13ZWlnaHQ6IDQwMDtcclxuXHRmb250LWRpc3BsYXk6IHN3YXA7XHJcblx0c3JjOiB1cmwoXCIuL2Fzc2V0cy9mb250cy9BbGxpYW56TmVvL0FsbGlhbnpfTmVvX3dlYmZvbnRzL3dvZmYyL0FsbGlhbnpOZW9XMDQtUmVndWxhci53b2ZmMlwiKVxyXG5cdFx0XHRmb3JtYXQoXCJ3b2ZmMlwiKSxcclxuXHRcdHVybChcIi4vYXNzZXRzL2ZvbnRzL0FsbGlhbnpOZW8vQWxsaWFuel9OZW9fd2ViZm9udHMvd29mZi9BbGxpYW56TmVvVzA0LVJlZ3VsYXIud29mZlwiKVxyXG5cdFx0XHRmb3JtYXQoXCJ3b2ZmXCIpO1xyXG59XHJcblxyXG5AZm9udC1mYWNlIHtcclxuXHRmb250LWZhbWlseTogXCJBbGxpYW56IE5lb1wiO1xyXG5cdGZvbnQtc3R5bGU6IGl0YWxpYztcclxuXHRmb250LXdlaWdodDogNDAwO1xyXG5cdGZvbnQtZGlzcGxheTogc3dhcDtcclxuXHRzcmM6IHVybChcIi4vYXNzZXRzL2ZvbnRzL0FsbGlhbnpOZW8vQWxsaWFuel9OZW9fd2ViZm9udHMvd29mZjIvQWxsaWFuek5lb1cwNC1JdGFsaWMud29mZjJcIilcclxuXHRcdFx0Zm9ybWF0KFwid29mZjJcIiksXHJcblx0XHR1cmwoXCIuL2Fzc2V0cy9mb250cy9BbGxpYW56TmVvL0FsbGlhbnpfTmVvX3dlYmZvbnRzL3dvZmYvQWxsaWFuek5lb1cwNC1JdGFsaWMud29mZlwiKVxyXG5cdFx0XHRmb3JtYXQoXCJ3b2ZmXCIpO1xyXG59XHJcblxyXG5AZm9udC1mYWNlIHtcclxuXHRmb250LWZhbWlseTogXCJBbGxpYW56IE5lb1wiO1xyXG5cdGZvbnQtc3R5bGU6IG5vcm1hbDtcclxuXHRmb250LXdlaWdodDogNjAwO1xyXG5cdGZvbnQtZGlzcGxheTogc3dhcDtcclxuXHRzcmM6IHVybChcIi4vYXNzZXRzL2ZvbnRzL0FsbGlhbnpOZW8vQWxsaWFuel9OZW9fd2ViZm9udHMvd29mZjIvQWxsaWFuek5lb1cwNC1TZW1pQm9sZC53b2ZmMlwiKVxyXG5cdFx0XHRmb3JtYXQoXCJ3b2ZmMlwiKSxcclxuXHRcdHVybChcIi4vYXNzZXRzL2ZvbnRzL0FsbGlhbnpOZW8vQWxsaWFuel9OZW9fd2ViZm9udHMvd29mZi9BbGxpYW56TmVvVzA0LVNlbWlCb2xkLndvZmZcIilcclxuXHRcdFx0Zm9ybWF0KFwid29mZlwiKTtcclxufVxyXG5cclxuQGZvbnQtZmFjZSB7XHJcblx0Zm9udC1mYW1pbHk6IFwiQWxsaWFueiBOZW9cIjtcclxuXHRmb250LXN0eWxlOiBpdGFsaWM7XHJcblx0Zm9udC13ZWlnaHQ6IDYwMDtcclxuXHRmb250LWRpc3BsYXk6IHN3YXA7XHJcblx0c3JjOiB1cmwoXCIuL2Fzc2V0cy9mb250cy9BbGxpYW56TmVvL0FsbGlhbnpfTmVvX3dlYmZvbnRzL3dvZmYyL0FsbGlhbnpOZW9XMDQtU2VtaUJvbGRJdC53b2ZmMlwiKVxyXG5cdFx0XHRmb3JtYXQoXCJ3b2ZmMlwiKSxcclxuXHRcdHVybChcIi4vYXNzZXRzL2ZvbnRzL0FsbGlhbnpOZW8vQWxsaWFuel9OZW9fd2ViZm9udHMvd29mZi9BbGxpYW56TmVvVzA0LVNlbWlCb2xkSXQud29mZlwiKVxyXG5cdFx0XHRmb3JtYXQoXCJ3b2ZmXCIpO1xyXG59XHJcblxyXG5AZm9udC1mYWNlIHtcclxuXHRmb250LWZhbWlseTogXCJBbGxpYW56IE5lb1wiO1xyXG5cdGZvbnQtc3R5bGU6IG5vcm1hbDtcclxuXHRmb250LXdlaWdodDogNzAwO1xyXG5cdGZvbnQtZGlzcGxheTogc3dhcDtcclxuXHRzcmM6IHVybChcIi4vYXNzZXRzL2ZvbnRzL0FsbGlhbnpOZW8vQWxsaWFuel9OZW9fd2ViZm9udHMvd29mZjIvQWxsaWFuek5lb1cwNC1Cb2xkLndvZmYyXCIpXHJcblx0XHRcdGZvcm1hdChcIndvZmYyXCIpLFxyXG5cdFx0dXJsKFwiLi9hc3NldHMvZm9udHMvQWxsaWFuek5lby9BbGxpYW56X05lb193ZWJmb250cy93b2ZmL0FsbGlhbnpOZW9XMDQtQm9sZC53b2ZmXCIpXHJcblx0XHRcdGZvcm1hdChcIndvZmZcIik7XHJcbn1cclxuXHJcbkBmb250LWZhY2Uge1xyXG5cdGZvbnQtZmFtaWx5OiBcIkFsbGlhbnogTmVvXCI7XHJcblx0Zm9udC1zdHlsZTogaXRhbGljO1xyXG5cdGZvbnQtd2VpZ2h0OiA3MDA7XHJcblx0Zm9udC1kaXNwbGF5OiBzd2FwO1xyXG5cdHNyYzogdXJsKFwiLi9hc3NldHMvZm9udHMvQWxsaWFuek5lby9BbGxpYW56X05lb193ZWJmb250cy93b2ZmMi9BbGxpYW56TmVvVzA0LUJvbGRJdGFsaWMud29mZjJcIilcclxuXHRcdFx0Zm9ybWF0KFwid29mZjJcIiksXHJcblx0XHR1cmwoXCIuL2Fzc2V0cy9mb250cy9BbGxpYW56TmVvL0FsbGlhbnpfTmVvX3dlYmZvbnRzL3dvZmYvQWxsaWFuek5lb1cwNC1Cb2xkSXRhbGljLndvZmZcIilcclxuXHRcdFx0Zm9ybWF0KFwid29mZlwiKTtcclxufVxyXG5cclxuKiB7XHJcblx0Y29sb3I6ICRjb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleTtcclxuXHRmb250LWZhbWlseTogXCJBbGxpYW56IE5lb1wiLCBzYW5zLXNlcmlmO1xyXG5cdGZvbnQtd2VpZ2h0OiA0MDA7XHJcblx0Zm9udC1zaXplOiAxNnB4O1xyXG59XHJcblxyXG5odG1sIHtcclxuXHQtLWlvbi1zYWZlLWFyZWEtdG9wOiAwcHg7XHJcbn1cclxuXHJcbi5jb2wtMSB7XHJcblx0d2lkdGg6IDguMzMlO1xyXG59XHJcblxyXG4uY29sLTIge1xyXG5cdHdpZHRoOiAxNi42NiU7XHJcbn1cclxuXHJcbi5jb2wtMyB7XHJcblx0d2lkdGg6IDI1JTtcclxufVxyXG5cclxuLmNvbC00IHtcclxuXHR3aWR0aDogMzMuMzMlO1xyXG59XHJcblxyXG4uY29sLTUge1xyXG5cdHdpZHRoOiA0MS42NiU7XHJcbn1cclxuXHJcbi5jb2wtNiB7XHJcblx0d2lkdGg6IDUwJTtcclxufVxyXG5cclxuLmNvbC03IHtcclxuXHR3aWR0aDogNTguMzMlO1xyXG59XHJcblxyXG4uY29sLTgge1xyXG5cdHdpZHRoOiA2Ni42NiU7XHJcbn1cclxuXHJcbi5jb2wtOSB7XHJcblx0d2lkdGg6IDc1JTtcclxufVxyXG5cclxuLmNvbC0xMCB7XHJcblx0d2lkdGg6IDgzLjMzJTtcclxufVxyXG5cclxuLmNvbC0xMSB7XHJcblx0d2lkdGg6IDkxLjY2JTtcclxufVxyXG5cclxuLmNvbC0xMiB7XHJcblx0d2lkdGg6IDEwMCU7XHJcbn1cclxuXHJcbkBtZWRpYSBvbmx5IHNjcmVlbiBhbmQgKG1heC13aWR0aDogNTc2cHgpIHtcclxuXHQvKiBGb3IgdGFibGV0czogKi9cclxuXHQuY29sLXNtLTEge1xyXG5cdFx0d2lkdGg6IDguMzMlO1xyXG5cdH1cclxuXHJcblx0LmNvbC1zbS0yIHtcclxuXHRcdHdpZHRoOiAxNi42NiU7XHJcblx0fVxyXG5cclxuXHQuY29sLXNtLTMge1xyXG5cdFx0d2lkdGg6IDI1JTtcclxuXHR9XHJcblxyXG5cdC5jb2wtc20tNCB7XHJcblx0XHR3aWR0aDogMzMuMzMlO1xyXG5cdH1cclxuXHJcblx0LmNvbC1zbS01IHtcclxuXHRcdHdpZHRoOiA0MS42NiU7XHJcblx0fVxyXG5cclxuXHQuY29sLXNtLTYge1xyXG5cdFx0d2lkdGg6IDUwJTtcclxuXHR9XHJcblxyXG5cdC5jb2wtc20tNyB7XHJcblx0XHR3aWR0aDogNTguMzMlO1xyXG5cdH1cclxuXHJcblx0LmNvbC1zbS04IHtcclxuXHRcdHdpZHRoOiA2Ni42NiU7XHJcblx0fVxyXG5cclxuXHQuY29sLXNtLTkge1xyXG5cdFx0d2lkdGg6IDc1JTtcclxuXHR9XHJcblxyXG5cdC5jb2wtc20tMTAge1xyXG5cdFx0d2lkdGg6IDgzLjMzJTtcclxuXHR9XHJcblxyXG5cdC5jb2wtc20tMTEge1xyXG5cdFx0d2lkdGg6IDkxLjY2JTtcclxuXHR9XHJcblxyXG5cdC5jb2wtc20tMTIge1xyXG5cdFx0d2lkdGg6IDEwMCU7XHJcblx0fVxyXG59XHJcblxyXG5AbWVkaWEgb25seSBzY3JlZW4gYW5kIChtYXgtd2lkdGg6IDc2OHB4KSBhbmQgKG1pbi13aWR0aDogNTc3cHgpIHtcclxuXHQvKiBGb3IgdGFibGV0czogKi9cclxuXHQuY29sLW1kLTEge1xyXG5cdFx0d2lkdGg6IDguMzMlO1xyXG5cdH1cclxuXHJcblx0LmNvbC1tZC0yIHtcclxuXHRcdHdpZHRoOiAxNi42NiU7XHJcblx0fVxyXG5cclxuXHQuY29sLW1kLTMge1xyXG5cdFx0d2lkdGg6IDI1JTtcclxuXHR9XHJcblxyXG5cdC5jb2wtbWQtNCB7XHJcblx0XHR3aWR0aDogMzMuMzMlO1xyXG5cdH1cclxuXHJcblx0LmNvbC1tZC01IHtcclxuXHRcdHdpZHRoOiA0MS42NiU7XHJcblx0fVxyXG5cclxuXHQuY29sLW1kLTYge1xyXG5cdFx0d2lkdGg6IDUwJTtcclxuXHR9XHJcblxyXG5cdC5jb2wtbWQtNyB7XHJcblx0XHR3aWR0aDogNTguMzMlO1xyXG5cdH1cclxuXHJcblx0LmNvbC1tZC04IHtcclxuXHRcdHdpZHRoOiA2Ni42NiU7XHJcblx0fVxyXG5cclxuXHQuY29sLW1kLTkge1xyXG5cdFx0d2lkdGg6IDc1JTtcclxuXHR9XHJcblxyXG5cdC5jb2wtbWQtMTAge1xyXG5cdFx0d2lkdGg6IDgzLjMzJTtcclxuXHR9XHJcblxyXG5cdC5jb2wtbWQtMTEge1xyXG5cdFx0d2lkdGg6IDkxLjY2JTtcclxuXHR9XHJcblxyXG5cdC5jb2wtbWQtMTIge1xyXG5cdFx0d2lkdGg6IDEwMCU7XHJcblx0fVxyXG59XHJcblxyXG5AbWVkaWEgb25seSBzY3JlZW4gYW5kIChtaW4td2lkdGg6IDc2OXB4KSB7XHJcblx0LyogRm9yIHRhYmxldHM6ICovXHJcblx0LmNvbC1sZy0xIHtcclxuXHRcdHdpZHRoOiA4LjMzJTtcclxuXHR9XHJcblxyXG5cdC5jb2wtbGctMiB7XHJcblx0XHR3aWR0aDogMTYuNjYlO1xyXG5cdH1cclxuXHJcblx0LmNvbC1sZy0zIHtcclxuXHRcdHdpZHRoOiAyNSU7XHJcblx0fVxyXG5cclxuXHQuY29sLWxnLTQge1xyXG5cdFx0d2lkdGg6IDMzLjMzJTtcclxuXHR9XHJcblxyXG5cdC5jb2wtbGctNSB7XHJcblx0XHR3aWR0aDogNDEuNjYlO1xyXG5cdH1cclxuXHJcblx0LmNvbC1sZy02IHtcclxuXHRcdHdpZHRoOiA1MCU7XHJcblx0fVxyXG5cclxuXHQuY29sLWxnLTcge1xyXG5cdFx0d2lkdGg6IDU4LjMzJTtcclxuXHR9XHJcblxyXG5cdC5jb2wtbGctOCB7XHJcblx0XHR3aWR0aDogNjYuNjYlO1xyXG5cdH1cclxuXHJcblx0LmNvbC1sZy05IHtcclxuXHRcdHdpZHRoOiA3NSU7XHJcblx0fVxyXG5cclxuXHQuY29sLWxnLTEwIHtcclxuXHRcdHdpZHRoOiA4My4zMyU7XHJcblx0fVxyXG5cclxuXHQuY29sLWxnLTExIHtcclxuXHRcdHdpZHRoOiA5MS42NiU7XHJcblx0fVxyXG5cclxuXHQuY29sLWxnLTEyIHtcclxuXHRcdHdpZHRoOiAxMDAlO1xyXG5cdH1cclxufVxyXG5cclxuLnJvdyB7XHJcblx0ZGlzcGxheTogZmxleDtcclxuXHRqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuXHRhbGlnbi1pdGVtczogY2VudGVyO1xyXG59XHJcblxyXG4vLyBDU1NcclxuLmN1c3RvbS10b2FzdCB7XHJcblx0LS1tYXgtd2lkdGg6IGZpdC1jb250ZW50O1xyXG59XHJcblxyXG4vKlxyXG4gKiAyLiBDdXN0b20gQ1NTIGZvciBjb21wYXRpYmlsaXR5IHdpdGggRWRnZVxyXG4gKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcbiAqL1xyXG5pbnB1dDo6LW1zLXJldmVhbCxcclxuaW5wdXQ6Oi1tcy1jbGVhciB7XHJcblx0ZGlzcGxheTogbm9uZTtcclxufVxyXG5cclxuLnN3YWwyLXBvcHVwIHtcclxuXHRtYXJnaW4tdG9wOiAyMHB4O1xyXG59XHJcblxyXG4vKlxyXG4gKiAzLiBDdXN0b20gQ1NTIGZvciBsb2FkaW5nIGNvbnRyb2xsZXJcclxuICogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG4gKi9cclxuLnRyYW5zcGFyZW50LWxvYWRpbmctY2xhc3Mge1xyXG5cdC0tYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XHJcblx0LS1zcGlubmVyLWNvbG9yOiAjNDdlNmIxO1xyXG59XHJcblxyXG4ubG9hZGluZy13cmFwcGVyLnNjLWlvbi1sb2FkaW5nLW1kIHtcclxuXHRib3gtc2hhZG93OiB1bnNldDtcclxuXHQtd2Via2l0LWJveC1zaGFkb3c6IHVuc2V0O1xyXG59XHJcblxyXG4udWlsIHtcclxuXHRjb2xvcjogJGNvbG9yLW5leHRnZW4tZ3JleTtcclxufVxyXG5cclxuLmJ0biB7XHJcblx0aGVpZ2h0OiA0OHB4O1xyXG5cdGJvcmRlci1yYWRpdXM6IDI4cHg7XHJcblx0cGFkZGluZzogMHB4IDQxcHggMHB4IDQxcHg7XHJcblx0Ym94LXNoYWRvdzogbm9uZTtcclxuXHJcblx0Ji5idG4tY2lyY2xlIHtcclxuXHRcdGJhY2tncm91bmQtY29sb3I6ICRjb2xvci1uZXh0Z2VuLXN0b25lLWdyZXkgIWltcG9ydGFudDtcclxuXHRcdGNvbG9yOiAkY29sb3ItbmV4dGdlbi1ibGFjaztcclxuXHRcdHBhZGRpbmc6IHVuc2V0ICFpbXBvcnRhbnQ7XHJcblx0XHRoZWlnaHQ6IDM2cHggIWltcG9ydGFudDtcclxuXHRcdHdpZHRoOiAzNnB4ICFpbXBvcnRhbnQ7XHJcblx0XHRib3JkZXItcmFkaXVzOiA1MCUgIWltcG9ydGFudDtcclxuXHJcblx0XHRpIHtcclxuXHRcdFx0Y29sb3I6ICRjb2xvci1uZXh0Z2VuLWJsYWNrO1xyXG5cdFx0fVxyXG5cdH1cclxuXHJcblx0Ji5wcmltYXJ5IHtcclxuXHRcdGJhY2tncm91bmQ6ICRjb2xvci1uZXh0Z2VuLWdyZWVuO1xyXG5cdFx0Y29sb3I6ICRjb2xvci1uZXh0Z2VuLXdoaXRlO1xyXG5cclxuXHRcdC51aWwge1xyXG5cdFx0XHRjb2xvcjogJGNvbG9yLW5leHRnZW4td2hpdGU7XHJcblx0XHR9XHJcblxyXG5cdFx0JjpkaXNhYmxlZCB7XHJcblx0XHRcdGJhY2tncm91bmQtY29sb3I6ICRjb2xvci1uZXh0Z2VuLWdyZXktYmFja2dyb3VuZCAhaW1wb3J0YW50O1xyXG5cdFx0XHRjb2xvcjogJGNvbG9yLW5leHRnZW4tZ3JleSAhaW1wb3J0YW50O1xyXG5cdFx0fVxyXG5cdH1cclxuXHJcblx0Ji5zZWNvbmRhcnkge1xyXG5cdFx0YmFja2dyb3VuZDogJGNvbG9yLW5leHRnZW4td2hpdGUgIWltcG9ydGFudDtcclxuXHRcdGJvcmRlci1jb2xvcjogJGNvbG9yLW5leHRnZW4tZ3JlZW47XHJcblx0XHRib3JkZXI6IHNvbGlkIDFweDtcclxuXHRcdGNvbG9yOiAkY29sb3ItbmV4dGdlbi1ncmVlbjtcclxuXHJcblx0XHQudWlsIHtcclxuXHRcdFx0Y29sb3I6ICRjb2xvci1uZXh0Z2VuLWdyZWVuO1xyXG5cdFx0fVxyXG5cclxuXHRcdCY6ZGlzYWJsZWQge1xyXG5cdFx0XHRiYWNrZ3JvdW5kLWNvbG9yOiAkY29sb3ItbmV4dGdlbi13aGl0ZSAhaW1wb3J0YW50O1xyXG5cdFx0XHRjb2xvcjogJGNvbG9yLW5leHRnZW4tZ3JleSAhaW1wb3J0YW50O1xyXG5cdFx0XHRib3JkZXItY29sb3I6ICRjb2xvci1uZXh0Z2VuLWdyZXktYmFja2dyb3VuZCAhaW1wb3J0YW50O1xyXG5cdFx0fVxyXG5cdH1cclxuXHJcblx0Ji50cmFuc3BhcmVudCB7XHJcblx0XHRiYWNrZ3JvdW5kOiB0cmFuc3BhcmVudCAhaW1wb3J0YW50O1xyXG5cdFx0Ym9yZGVyLWNvbG9yOiAkY29sb3ItbmV4dGdlbi1ncmVlbjtcclxuXHRcdGJvcmRlcjogc29saWQgMXB4O1xyXG5cdFx0Y29sb3I6ICRjb2xvci1uZXh0Z2VuLWdyZWVuO1xyXG5cclxuXHRcdC51aWwge1xyXG5cdFx0XHRjb2xvcjogJGNvbG9yLW5leHRnZW4tZ3JlZW47XHJcblx0XHR9XHJcblxyXG5cdFx0JjpkaXNhYmxlZCB7XHJcblx0XHRcdGJhY2tncm91bmQtY29sb3I6IHRyYW5zcGFyZW50ICFpbXBvcnRhbnQ7XHJcblx0XHRcdGNvbG9yOiAkY29sb3ItbmV4dGdlbi1ncmV5ICFpbXBvcnRhbnQ7XHJcblx0XHRcdGJvcmRlci1jb2xvcjogJGNvbG9yLW5leHRnZW4tZ3JleS1iYWNrZ3JvdW5kICFpbXBvcnRhbnQ7XHJcblx0XHR9XHJcblx0fVxyXG5cclxuXHQmLmJ0bi1sYXJnZSB7XHJcblx0XHRoZWlnaHQ6IDU2cHggIWltcG9ydGFudDtcclxuXHRcdHdpZHRoOiAxMDAlO1xyXG5cdH1cclxuXHJcblx0Ji5ib2xkIHtcclxuXHRcdGZvbnQtd2VpZ2h0OiA3MDAgIWltcG9ydGFudDtcclxuXHR9XHJcblxyXG5cdCYuc2VtaWJvbGQge1xyXG5cdFx0Zm9udC13ZWlnaHQ6IDYwMCAhaW1wb3J0YW50O1xyXG5cdH1cclxufVxyXG5cclxuLmJ0bi1uby1zcGFjZSB7XHJcblx0cGFkZGluZzogNXB4ICFpbXBvcnRhbnQ7XHJcblx0aGVpZ2h0OiBmaXQtY29udGVudDtcclxufVxyXG5cclxuLmJ0bi1iYWNrIHtcclxuXHR3aWR0aDogMzFweDtcclxuXHRoZWlnaHQ6IDI4cHg7XHJcblx0YmFja2dyb3VuZC1jb2xvcjogdHJhbnNwYXJlbnQ7XHJcblx0cGFkZGluZzogMDtcclxuXHRjb2xvcjogJGNvbG9yLW5leHRnZW4tZ3JlZW47XHJcbn1cclxuXHJcbi5jb250YWluZXIge1xyXG5cdHBhZGRpbmc6IDJyZW07XHJcblx0aGVpZ2h0OiAxMDAlO1xyXG59XHJcblxyXG4uYm9keS1zZWN0aW9uIHtcclxuXHR3aWR0aDogMTAwJTtcclxuXHRoZWlnaHQ6IDk1JTtcclxuXHRvdmVyZmxvdy15OiBhdXRvO1xyXG5cdHBvc2l0aW9uOiByZWxhdGl2ZTtcclxufVxyXG5cclxuLnRvcC1zZWN0aW9uIHtcclxuXHR3aWR0aDogMTAwJTtcclxuXHRoZWlnaHQ6IDEwJTtcclxuXHRqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XHJcblx0ZGlzcGxheTogZmxleDtcclxuXHRhbGlnbi1pdGVtczogY2VudGVyO1xyXG59XHJcblxyXG4uZm9ybS1jb250cm9sIHtcclxuXHRwb3NpdGlvbjogcmVsYXRpdmU7XHJcblx0aGVpZ2h0OiA4NXB4O1xyXG5cdG1hcmdpbi1ib3R0b206IDhweDtcclxufVxyXG5cclxuLmNvbnRyb2wge1xyXG5cdGJvcmRlci1yYWRpdXM6IDhweDtcclxuXHRoZWlnaHQ6IDU2cHg7XHJcblx0Ym9yZGVyOiAxcHggc29saWQgJGNvbG9yLW5leHRnZW4tZ3JleS1iYWNrZ3JvdW5kO1xyXG5cdHdpZHRoOiAxMDAlO1xyXG5cdHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuXHR0b3A6IDMycHg7XHJcblx0YmFja2dyb3VuZC1jb2xvcjogJGNvbG9yLW5leHRnZW4td2hpdGU7XHJcblxyXG5cdCYgdGFibGUge1xyXG5cdFx0dGFibGUtbGF5b3V0OiBmaXhlZDtcclxuXHRcdGJvcmRlci1jb2xsYXBzZTogdW5zZXQ7XHJcblx0fVxyXG5cclxuXHQmIGlucHV0IHtcclxuXHRcdGhlaWdodDogNTRweDtcclxuXHRcdGJvcmRlcjogdW5zZXQ7XHJcblx0XHRib3JkZXItcmFkaXVzOiA4cHg7XHJcblx0XHR3aWR0aDogbWF4LWNvbnRlbnQ7XHJcblx0XHR3aWR0aDogMTAwJTtcclxuXHRcdHBvaW50ZXItZXZlbnRzOiBhdXRvO1xyXG5cdFx0YmFja2dyb3VuZC1jb2xvcjogJGNvbG9yLW5leHRnZW4td2hpdGU7XHJcblx0fVxyXG5cclxuXHQmLnRleHRhcmVhIHtcclxuXHRcdGhlaWdodDogMTA4cHg7XHJcblx0fVxyXG5cclxuXHQmIHRleHRhcmVhIHtcclxuXHRcdGhlaWdodDogMTA2cHg7XHJcblx0XHRib3JkZXI6IHVuc2V0O1xyXG5cdFx0Ym9yZGVyLXJhZGl1czogOHB4O1xyXG5cdFx0d2lkdGg6IG1heC1jb250ZW50O1xyXG5cdFx0d2lkdGg6IDEwMCU7XHJcblx0XHRwb2ludGVyLWV2ZW50czogYXV0bztcclxuXHRcdHJlc2l6ZTogbm9uZTtcclxuXHRcdGJhY2tncm91bmQtY29sb3I6ICRjb2xvci1uZXh0Z2VuLXdoaXRlO1xyXG5cdH1cclxuXHJcblx0JiBpbnB1dDpmb2N1cyB7XHJcblx0XHRvdXRsaW5lOiBub25lO1xyXG5cdH1cclxuXHJcblx0Jjpmb2N1cy13aXRoaW4ge1xyXG5cdFx0Ym9yZGVyLWNvbG9yOiAkY29sb3ItbmV4dGdlbi1ncmVlbjtcclxuXHJcblx0XHQuZmlyc3QtaWNvbiB7XHJcblx0XHRcdGRpc3BsYXk6IG5vbmU7XHJcblx0XHR9XHJcblxyXG5cdFx0LmZpcnN0LWljb24ubm9uLWhpZGRlbiB7XHJcblx0XHRcdGRpc3BsYXk6IHRhYmxlLWNlbGw7XHJcblx0XHR9XHJcblx0fVxyXG5cclxuXHQuZmlyc3QtaWNvbiB7XHJcblx0XHR3aWR0aDogMzJweDtcclxuXHRcdHRleHQtYWxpZ246IGNlbnRlcjtcclxuXHRcdHBhZGRpbmctbGVmdDogOHB4O1xyXG5cclxuXHRcdGkge1xyXG5cdFx0XHRmb250LXNpemU6IDI0cHggIWltcG9ydGFudDtcclxuXHRcdH1cclxuXHR9XHJcblxyXG5cdC5zZWNvbmQtaWNvbiB7XHJcblx0XHR3aWR0aDogMzJweDtcclxuXHRcdHRleHQtYWxpZ246IGNlbnRlcjtcclxuXHRcdC8vIHBhZGRpbmctcmlnaHQ6IDhweDtcclxuXHJcblx0XHRpIHtcclxuXHRcdFx0Zm9udC1zaXplOiAyNHB4ICFpbXBvcnRhbnQ7XHJcblx0XHR9XHJcblx0fVxyXG59XHJcblxyXG4uY29udHJvbDpmb2N1cy13aXRoaW4gfiBkaXYgLmNvbnRyb2wtbGFiZWwge1xyXG5cdGNvbG9yOiAkY29sb3ItbmV4dGdlbi1ncmVlbjtcclxufVxyXG5cclxuLmNvbnRyb2wtZXJyb3Ige1xyXG5cdC5jb250cm9sIHtcclxuXHRcdGJvcmRlci1jb2xvcjogJGNvbG9yLW5leHRnZW4tZXJyb3I7XHJcblx0fVxyXG5cclxuXHQuY29udHJvbC1sYWJlbCB7XHJcblx0XHRjb2xvcjogJGNvbG9yLW5leHRnZW4tZXJyb3IgIWltcG9ydGFudDtcclxuXHR9XHJcbn1cclxuXHJcbi52YWxpZGF0aW9uLXN1bW1hcnkge1xyXG5cdGxpIHtcclxuXHRcdGNvbG9yOiAkY29sb3ItbmV4dGdlbi1lcnJvciAhaW1wb3J0YW50O1xyXG5cdFx0bGlzdC1zdHlsZTogbm9uZTtcclxuXHJcblx0XHRpIHtcclxuXHRcdFx0Y29sb3I6ICRjb2xvci1uZXh0Z2VuLWVycm9yICFpbXBvcnRhbnQ7XHJcblx0XHR9XHJcblx0fVxyXG59XHJcblxyXG4ubXItMSB7XHJcblx0bWFyZ2luLXJpZ2h0OiAwLjVyZW07XHJcbn1cclxuXHJcbi5tYi0xIHtcclxuXHRtYXJnaW4tYm90dG9tOiAwLjVyZW07XHJcbn1cclxuXHJcbi5kaWFsb2ctcGFuZSB7XHJcblx0cG9zaXRpb246IGFic29sdXRlO1xyXG5cdHBvaW50ZXItZXZlbnRzOiBhdXRvO1xyXG5cdGJveC1zaXppbmc6IGJvcmRlci1ib3g7XHJcblx0ei1pbmRleDogMTAwMDtcclxuXHRkaXNwbGF5OiBibG9jaztcclxuXHRtYXgtd2lkdGg6IDEwMCU7XHJcblx0bWF4LWhlaWdodDogMTAwJTtcclxufVxyXG5cclxuLm92ZXJsYXktYmFja2Ryb3Age1xyXG5cdGJhY2tncm91bmQtY29sb3I6ICRjb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleTtcclxuXHRvcGFjaXR5OiAwLjIgIWltcG9ydGFudDtcclxufVxyXG5cclxuLmRpYWxvZy1jb250YWluZXIge1xyXG5cdGFuaW1hdGlvbjogZmFkZUluIDAuNXMgbGluZWFyO1xyXG5cdGJhY2tncm91bmQtY29sb3I6ICRjb2xvci1uZXh0Z2VuLXdoaXRlO1xyXG59XHJcblxyXG5Aa2V5ZnJhbWVzIGZhZGVJbiB7XHJcblx0ZnJvbSB7XHJcblx0XHR0cmFuc2Zvcm06IHRyYW5zbGF0ZVkoMTAwJSk7XHJcblx0fVxyXG5cclxuXHR0byB7XHJcblx0XHR0cmFuc2Zvcm06IHRyYW5zbGF0ZVkoMCUpO1xyXG5cdH1cclxufVxyXG5cclxuLmVycm9yIHtcclxuXHRjb2xvcjogJGNvbG9yLW5leHRnZW4tZXJyb3I7XHJcblxyXG5cdCYuYmFja2dyb3VuZCB7XHJcblx0XHRiYWNrZ3JvdW5kLWNvbG9yOiAkY29sb3ItbmV4dGdlbi1lcnJvcjtcclxuXHR9XHJcbn1cclxuXHJcbi5zdWNjZXNzIHtcclxuXHRjb2xvcjogJGNvbG9yLW5leHRnZW4tZmlicmFudC1ncmVlbjtcclxuXHJcblx0Ji5iYWNrZ3JvdW5kIHtcclxuXHRcdGJhY2tncm91bmQtY29sb3I6ICRjb2xvci1uZXh0Z2VuLWZpYnJhbnQtZ3JlZW47XHJcblx0fVxyXG59XHJcblxyXG4ud2FybmluZyB7XHJcblx0Y29sb3I6ICRjb2xvci1uZXh0Z2VuLXdhcm5pbmc7XHJcblxyXG5cdCYuYmFja2dyb3VuZCB7XHJcblx0XHRiYWNrZ3JvdW5kLWNvbG9yOiAkY29sb3ItbmV4dGdlbi13YXJuaW5nO1xyXG5cdH1cclxufVxyXG5cclxuLnNlbGVjdCB7XHJcblx0d2lkdGg6IDEwMCU7XHJcblx0aGVpZ2h0OiA1NHB4O1xyXG5cdGJvcmRlcjogdW5zZXQ7XHJcblx0Ym9yZGVyLXJhZGl1czogOHB4O1xyXG5cdGRpc3BsYXk6IGdyaWQ7XHJcblx0YXBwZWFyYW5jZTogbm9uZTtcclxuXHRncmlkLXRlbXBsYXRlLWFyZWFzOiBcInNlbGVjdFwiO1xyXG5cclxuXHQmOmZvY3VzIHtcclxuXHRcdG91dGxpbmU6IHVuc2V0O1xyXG5cdH1cclxufVxyXG5cclxuLmNvbG9yLWJsYWNrIHtcclxuXHRjb2xvcjogJGNvbG9yLW5leHRnZW4tYmxhY2s7XHJcbn1cclxuXHJcbi5tb2RhbC1kZWZhdWx0IHtcclxuXHQtLXdpZHRoOiAxMDAlO1xyXG5cdC0taGVpZ2h0OiAxMDAlO1xyXG59XHJcblxyXG4uaW50ZWdyYXRpb24tcGFuZWwge1xyXG5cdHdpZHRoOiAxMDAlO1xyXG5cdGhlaWdodDogMTAwJTtcclxuXHRtYXgtd2lkdGg6IDEwMCUgIWltcG9ydGFudDtcclxufVxyXG5cclxuLnZlcmxvb3AtYnV0dG9uIHtcclxuXHR2aXNpYmlsaXR5OiBoaWRkZW47XHJcbn1cclxuXHJcbi5iYWNrLWFyZWEge1xyXG5cdHBvc2l0aW9uOiBmaXhlZDtcclxuXHR0b3A6IDA7XHJcblx0cmlnaHQ6IDA7XHJcblx0aGVpZ2h0OiA1MHB4O1xyXG5cdHdpZHRoOiAxMDAlO1xyXG5cdGJhY2tncm91bmQtY29sb3I6ICRjb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS01MDtcclxuXHR6LWluZGV4OiA5OTk5OTk5O1xyXG5cclxuXHQmLmlvcyB7XHJcblx0XHRoZWlnaHQ6IDgwcHg7XHJcblx0fVxyXG59XHJcblxyXG4udGl0bGUtd2lkZ2V0IHtcclxuXHR0ZXh0LWFsaWduOiBjZW50ZXI7XHJcblx0cG9zaXRpb246IHN0aWNreTtcclxuXHR0b3A6IDQ4cHg7XHJcbn1cclxuXHJcbi5idXR0b24tYmFjayB7XHJcblx0YmFja2dyb3VuZC1jb2xvcjogI2ZhZmFmYTtcclxuXHRoZWlnaHQ6IDM2cHg7XHJcblx0d2lkdGg6IDM2cHg7XHJcblx0Ym9yZGVyLXJhZGl1czogNTAlO1xyXG5cdHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuXHRsZWZ0OiAxOHB4O1xyXG5cdGJvdHRvbTogNHB4O1xyXG59XHJcblxyXG4uaWNvbi1jbG9zZS13aWRnZXQge1xyXG5cdHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuXHR6LWluZGV4OiAyNTA7XHJcblx0bGVmdDogMTFweDtcclxuXHRib3R0b206IDEzcHg7XHJcbn1cclxuXHJcbi5kYXRhLWRlZmF1bHQge1xyXG5cdHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuXHR0b3A6IDUwJTtcclxuXHRsZWZ0OiA1MCU7XHJcblx0dHJhbnNmb3JtOiB0cmFuc2xhdGUoLTUwJSwgLTUwJSk7XHJcblx0dGV4dC1hbGlnbjogY2VudGVyO1xyXG5cdGNvbG9yOiAkY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNDAwO1xyXG5cdHotaW5kZXg6IDEwMDA7XHJcbn1cclxuXHJcbi5hdmFhbW9fX2ljb24ge1xyXG5cdHZpc2liaWxpdHk6IGhpZGRlbiAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4uYXZhYW1vX19jaGF0X193aWRnZXQuaW9zIHtcclxuXHQjYXZhYW1vX19wb3B1cCB7XHJcblx0XHRwYWRkaW5nLXRvcDogNDBweDtcclxuXHR9XHJcbn1cclxuXHJcbi5kLWZsZXgge1xyXG5cdGRpc3BsYXk6IGZsZXg7XHJcbn1cclxuXHJcbm5leHRjYXJlLWxheW91dCB7XHJcblx0bGVmdDogMDtcclxuXHRyaWdodDogMDtcclxuXHR0b3A6IDA7XHJcblx0Ym90dG9tOiAwO1xyXG5cdGRpc3BsYXk6IGZsZXg7XHJcblx0cG9zaXRpb246IGFic29sdXRlO1xyXG5cdGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcblx0anVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xyXG5cdGNvbnRhaW46IGxheW91dCBzaXplIHN0eWxlO1xyXG5cdG92ZXJmbG93OiBoaWRkZW47XHJcblx0YmFja2dyb3VuZC1jb2xvcjogJGNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTUwO1xyXG5cdHBhZGRpbmctcmlnaHQ6IDI0cHg7XHJcblx0cGFkZGluZy1sZWZ0OiAyNHB4O1xyXG59XHJcblxyXG5pb24taGVhZGVyLmlvcy5oZWFkZXItaW9zIHtcclxuXHRtYXJnaW4tdG9wOiA0MHB4O1xyXG59XHJcblxyXG4uaGVhZGVyLWlvcyBpb24tdG9vbGJhcjpsYXN0LW9mLXR5cGUge1xyXG5cdC0tYm9yZGVyLXdpZHRoOiAwcHggIWltcG9ydGFudDtcclxufVxyXG5cclxuLmhlYWRlci1tZC5tZDo6YWZ0ZXIge1xyXG5cdGRpc3BsYXk6IG5vbmU7XHJcbn1cclxuXHJcbmlvbi10b29sYmFyIHtcclxuXHRwYWRkaW5nLXJpZ2h0OiB1bnNldCAhaW1wb3J0YW50O1xyXG5cdHBhZGRpbmctbGVmdDogdW5zZXQgIWltcG9ydGFudDtcclxufVxyXG5cclxuaS5pY29uLWJhY2sge1xyXG5cdGNvbnRlbnQ6IHVybChhc3NldHMvaWNvbi9sb25nLWFycm93LWxlZnQtaWNvbi5zdmcpO1xyXG59XHJcblxyXG4udmVybG9vcC13aWRnZXQuaW9zIHtcclxuXHQudmVybG9vcC1jb250YWluZXIudmlzaWJsZSB7XHJcblx0XHRoZWlnaHQ6IGNhbGMoMTAwJSAtIDQwcHgpO1xyXG5cdFx0dG9wOiA0MHB4O1xyXG5cdH1cclxufVxyXG5cclxuI25leHRjYXJlLWFkcyB7XHJcblx0ZGlzcGxheTogbm9uZTtcclxuXHRvdmVyZmxvdzogc2Nyb2xsO1xyXG5cdGhlaWdodDogMTgwcHg7XHJcbn1cclxuXHJcbi5kLWJsb2NrIHtcclxuXHRkaXNwbGF5OiBibG9jaztcclxufVxyXG5cclxuLnRpdGxlLXRleHQge1xyXG5cdGNvbG9yOiAkY29sb3ItbmV4dGdlbi1ibHVlO1xyXG59XHJcblxyXG46aG9zdCBpb24tZGF0ZXRpbWUgI3NoYWRvdy1yb290IHtcclxuXHQuZGF0ZXRpbWUtY2FsZW5kYXIge1xyXG5cdFx0LmNhbGVuZGFyLWhlYWRlciB7XHJcblx0XHRcdC5jYWxlbmRhci1hY3Rpb24tYnV0dG9ucyB7XHJcblx0XHRcdFx0LmNhbGVuZGFyLW1vbnRoLXllYXIge1xyXG5cdFx0XHRcdFx0YWxpZ24taXRlbXM6IGNlbnRlcjtcclxuXHRcdFx0XHRcdGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG5cdFx0XHRcdFx0ZGlzcGxheTogZmxleDtcclxuXHRcdFx0XHRcdHdpZHRoOiAxMDAlO1xyXG5cclxuXHRcdFx0XHRcdGlvbi1pY29uIHtcclxuXHRcdFx0XHRcdFx0ZGlzcGxheTogbm9uZTtcclxuXHRcdFx0XHRcdH1cclxuXHRcdFx0XHR9XHJcblxyXG5cdFx0XHRcdC5jYWxlbmRhci1uZXh0LXByZXYge1xyXG5cdFx0XHRcdFx0cG9zaXRpb246IGFic29sdXRlO1xyXG5cdFx0XHRcdFx0d2lkdGg6IDEwMCU7XHJcblx0XHRcdFx0XHRyaWdodDogMDtcclxuXHJcblx0XHRcdFx0XHRpb24tYnV0dG9ucyB7XHJcblx0XHRcdFx0XHRcdGRpc3BsYXk6IGZsZXg7XHJcblx0XHRcdFx0XHRcdGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcclxuXHRcdFx0XHRcdFx0d2lkdGg6IDEwMCU7XHJcblx0XHRcdFx0XHR9XHJcblx0XHRcdFx0fVxyXG5cdFx0XHR9XHJcblx0XHR9XHJcblx0fVxyXG59XHJcblxyXG4ubWF0LWRpYWxvZy1jb250YWluZXIge1xyXG5cdHBhZGRpbmc6IHVuc2V0ICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi8qIENoYW5nZSBhdXRvY29tcGxldGUgc3R5bGVzIGluIFdlYktpdCAqL1xyXG5pbnB1dDotd2Via2l0LWF1dG9maWxsLFxyXG5pbnB1dDotd2Via2l0LWF1dG9maWxsOmhvdmVyLFxyXG5pbnB1dDotd2Via2l0LWF1dG9maWxsOmZvY3VzLFxyXG50ZXh0YXJlYTotd2Via2l0LWF1dG9maWxsLFxyXG50ZXh0YXJlYTotd2Via2l0LWF1dG9maWxsOmhvdmVyLFxyXG50ZXh0YXJlYTotd2Via2l0LWF1dG9maWxsOmZvY3VzLFxyXG5zZWxlY3Q6LXdlYmtpdC1hdXRvZmlsbCxcclxuc2VsZWN0Oi13ZWJraXQtYXV0b2ZpbGw6aG92ZXIsXHJcbnNlbGVjdDotd2Via2l0LWF1dG9maWxsOmZvY3VzIHtcclxuXHQtd2Via2l0LXRleHQtZmlsbC1jb2xvcjogYmxhY2s7XHJcblx0LXdlYmtpdC1ib3gtc2hhZG93OiAwIDAgMHB4IDEwMDBweCB3aGl0ZSBpbnNldDtcclxuXHR0cmFuc2l0aW9uOiBiYWNrZ3JvdW5kLWNvbG9yIDUwMDBzIGVhc2UtaW4tb3V0IDBzO1xyXG59XHJcblxyXG4uZm9yY2UtdXBkYXRlLXBvcHVwICsgLmNkay1nbG9iYWwtb3ZlcmxheS13cmFwcGVyIHtcclxuXHQuc2F2ZS1idG4ge1xyXG5cdFx0YmFja2dyb3VuZDogdmFyKC0tbHVtaS1wcmltYXJ5LXllbGxvdy1jb2xvcikgIWltcG9ydGFudDtcclxuXHRcdGNvbG9yOiB2YXIoLS1sdW1pLXdoaXRlLWNvbG9yKSAhaW1wb3J0YW50O1xyXG5cdFx0Zm9udC13ZWlnaHQ6IGJvbGQgIWltcG9ydGFudDtcclxuXHR9XHJcblxyXG5cdC5jYW5jZWwtYnRuIHtcclxuXHRcdGNvbG9yOiB2YXIoLS1sdW1pLXByaW1hcnkteWVsbG93LWNvbG9yKSAhaW1wb3J0YW50O1xyXG5cdH1cclxufVxyXG5cclxuQC13ZWJraXQta2V5ZnJhbWVzIHNsaWRlSW5SaWdodCB7XHJcblx0MCUge1xyXG5cdFx0LXdlYmtpdC10cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKDEwMCUsIDAsIDApO1xyXG5cdFx0dHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgxMDAlLCAwLCAwKTtcclxuXHRcdHZpc2liaWxpdHk6IHZpc2libGU7XHJcblx0fVxyXG5cclxuXHR0byB7XHJcblx0XHQtd2Via2l0LXRyYW5zZm9ybTogdHJhbnNsYXRlWigwKTtcclxuXHRcdHRyYW5zZm9ybTogdHJhbnNsYXRlWigwKTtcclxuXHR9XHJcbn1cclxuXHJcbkBrZXlmcmFtZXMgc2xpZGVJblJpZ2h0IHtcclxuXHQwJSB7XHJcblx0XHQtd2Via2l0LXRyYW5zZm9ybTogdHJhbnNsYXRlM2QoMTAwJSwgMCwgMCk7XHJcblx0XHR0cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKDEwMCUsIDAsIDApO1xyXG5cdFx0dmlzaWJpbGl0eTogdmlzaWJsZTtcclxuXHR9XHJcblxyXG5cdHRvIHtcclxuXHRcdC13ZWJraXQtdHJhbnNmb3JtOiB0cmFuc2xhdGVaKDApO1xyXG5cdFx0dHJhbnNmb3JtOiB0cmFuc2xhdGVaKDApO1xyXG5cdH1cclxufVxyXG5cclxuLmFuaW1hdGVfX3NsaWRlSW5SaWdodCB7XHJcblx0LXdlYmtpdC1hbmltYXRpb24tbmFtZTogc2xpZGVJblJpZ2h0O1xyXG5cdGFuaW1hdGlvbi1uYW1lOiBzbGlkZUluUmlnaHQ7XHJcbn1cclxuXHJcbi5hbmltYXRlX19hbmltYXRlZCB7XHJcblx0LXdlYmtpdC1hbmltYXRpb24tZHVyYXRpb246IDAuNXM7XHJcblx0YW5pbWF0aW9uLWR1cmF0aW9uOiAwLjVzO1xyXG5cdC13ZWJraXQtYW5pbWF0aW9uLWR1cmF0aW9uOiAwLjVzO1xyXG5cdGFuaW1hdGlvbi1kdXJhdGlvbjogMC41cztcclxuXHQtd2Via2l0LWFuaW1hdGlvbi1maWxsLW1vZGU6IGJvdGg7XHJcblx0YW5pbWF0aW9uLWZpbGwtbW9kZTogYm90aDtcclxufVxyXG4iLCIuZGlzcGxheS14bCB7XHJcbiAgICBmb250LXNpemU6IDQxcHggIWltcG9ydGFudDtcclxuICAgIGZvbnQtd2VpZ2h0OiA0MDAgIWltcG9ydGFudDtcclxuICAgIGxpbmUtaGVpZ2h0OiAxMjAlICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5kaXNwbGF5LW1kIHtcclxuICAgIGZvbnQtc2l6ZTogMzZweCAhaW1wb3J0YW50O1xyXG4gICAgZm9udC13ZWlnaHQ6IDQwMCAhaW1wb3J0YW50O1xyXG4gICAgbGluZS1oZWlnaHQ6IDEyMCUgIWltcG9ydGFudDtcclxufVxyXG5cclxuLmgxIHtcclxuICAgIGZvbnQtc2l6ZTogMzFweCAhaW1wb3J0YW50O1xyXG4gICAgZm9udC13ZWlnaHQ6IDQwMCAhaW1wb3J0YW50O1xyXG4gICAgbGluZS1oZWlnaHQ6IDEyMCUgIWltcG9ydGFudDtcclxufVxyXG5cclxuLmgyIHtcclxuICAgIGZvbnQtc2l6ZTogMjhweCAhaW1wb3J0YW50O1xyXG4gICAgZm9udC13ZWlnaHQ6IDQwMCAhaW1wb3J0YW50O1xyXG4gICAgbGluZS1oZWlnaHQ6IDEyMCUgIWltcG9ydGFudDtcclxufVxyXG5cclxuLmgzIHtcclxuICAgIGZvbnQtc2l6ZTogMjVweCAhaW1wb3J0YW50O1xyXG4gICAgZm9udC13ZWlnaHQ6IDQwMCAhaW1wb3J0YW50O1xyXG4gICAgbGluZS1oZWlnaHQ6IDEyMCUgIWltcG9ydGFudDtcclxufVxyXG5cclxuLmg0IHtcclxuICAgIGZvbnQtc2l6ZTogMjJweCAhaW1wb3J0YW50O1xyXG4gICAgZm9udC13ZWlnaHQ6IDQwMCAhaW1wb3J0YW50O1xyXG4gICAgbGluZS1oZWlnaHQ6IDEyMCUgIWltcG9ydGFudDtcclxufVxyXG5cclxuLmg1IHtcclxuICAgIGZvbnQtc2l6ZTogMTlweCAhaW1wb3J0YW50O1xyXG4gICAgZm9udC13ZWlnaHQ6IDQwMCAhaW1wb3J0YW50O1xyXG4gICAgbGluZS1oZWlnaHQ6IDEyMCUgIWltcG9ydGFudDtcclxufVxyXG5cclxuLmg2IHtcclxuICAgIGZvbnQtc2l6ZTogMTdweCAhaW1wb3J0YW50O1xyXG4gICAgZm9udC13ZWlnaHQ6IDQwMCAhaW1wb3J0YW50O1xyXG4gICAgbGluZS1oZWlnaHQ6IDEyMCUgIWltcG9ydGFudDtcclxufVxyXG5cclxuLmJvZHktbCB7XHJcbiAgICBmb250LXNpemU6IDE3cHggIWltcG9ydGFudDtcclxuICAgIGZvbnQtd2VpZ2h0OiA0MDAgIWltcG9ydGFudDtcclxuICAgIGxpbmUtaGVpZ2h0OiAxMjAlICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5ib2R5LW4ge1xyXG4gICAgZm9udC1zaXplOiAxNXB4ICFpbXBvcnRhbnQ7XHJcbiAgICBmb250LXdlaWdodDogNDAwICFpbXBvcnRhbnQ7XHJcbiAgICBsaW5lLWhlaWdodDogMTIwJSAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4uYm9keS1zbSB7XHJcbiAgICBmb250LXNpemU6IDEzcHggIWltcG9ydGFudDtcclxuICAgIGZvbnQtd2VpZ2h0OiA0MDAgIWltcG9ydGFudDtcclxuICAgIGxpbmUtaGVpZ2h0OiAxMjAlICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5ib2R5LXhzIHtcclxuICAgIGZvbnQtc2l6ZTogMTJweCAhaW1wb3J0YW50O1xyXG4gICAgZm9udC13ZWlnaHQ6IDQwMCAhaW1wb3J0YW50O1xyXG4gICAgbGluZS1oZWlnaHQ6IDEyMCUgIWltcG9ydGFudDtcclxufVxyXG5cclxuLnNlbWlib2xkIHtcclxuICAgICYuZGlzcGxheS14bCB7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IDYwMCAhaW1wb3J0YW50O1xyXG4gICAgfVxyXG4gICAgJi5kaXNwbGF5LW1kIHtcclxuICAgICAgICBmb250LXdlaWdodDogNjAwICFpbXBvcnRhbnQ7XHJcbiAgICB9XHJcbiAgICAmLmgxIHtcclxuICAgICAgICBmb250LXdlaWdodDogNjAwICFpbXBvcnRhbnQ7XHJcbiAgICB9XHJcbiAgICAmLmgyIHtcclxuICAgICAgICBmb250LXdlaWdodDogNjAwICFpbXBvcnRhbnQ7XHJcbiAgICB9XHJcbiAgICAmLmgzIHtcclxuICAgICAgICBmb250LXdlaWdodDogNjAwICFpbXBvcnRhbnQ7XHJcbiAgICB9XHJcbiAgICAmLmg0IHtcclxuICAgICAgICBmb250LXdlaWdodDogNjAwICFpbXBvcnRhbnQ7XHJcbiAgICB9XHJcbiAgICAmLmg1IHtcclxuICAgICAgICBmb250LXdlaWdodDogNjAwICFpbXBvcnRhbnQ7XHJcbiAgICB9XHJcbiAgICAmLmg2IHtcclxuICAgICAgICBmb250LXdlaWdodDogNjAwICFpbXBvcnRhbnQ7XHJcbiAgICB9XHJcbiAgICAmLmJvZHktbCB7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IDYwMCAhaW1wb3J0YW50O1xyXG4gICAgfVxyXG4gICAgJi5ib2R5LW4ge1xyXG4gICAgICAgIGZvbnQtd2VpZ2h0OiA2MDAgIWltcG9ydGFudDtcclxuICAgIH1cclxuICAgICYuYm9keS1zbSB7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IDYwMCAhaW1wb3J0YW50O1xyXG4gICAgfVxyXG4gICAgJi5ib2R5LXhzIHtcclxuICAgICAgICBmb250LXdlaWdodDogNjAwICFpbXBvcnRhbnQ7XHJcbiAgICB9XHJcbn1cclxuXHJcbi5ib2xkIHtcclxuICAgICYuZGlzcGxheS14bCB7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IDcwMCAhaW1wb3J0YW50O1xyXG4gICAgfVxyXG4gICAgJi5kaXNwbGF5LW1kIHtcclxuICAgICAgICBmb250LXdlaWdodDogNzAwICFpbXBvcnRhbnQ7XHJcbiAgICB9XHJcbiAgICAmLmgxIHtcclxuICAgICAgICBmb250LXdlaWdodDogNzAwICFpbXBvcnRhbnQ7XHJcbiAgICB9XHJcbiAgICAmLmgyIHtcclxuICAgICAgICBmb250LXdlaWdodDogNzAwICFpbXBvcnRhbnQ7XHJcbiAgICB9XHJcbiAgICAmLmgzIHtcclxuICAgICAgICBmb250LXdlaWdodDogNzAwICFpbXBvcnRhbnQ7XHJcbiAgICB9XHJcbiAgICAmLmg0IHtcclxuICAgICAgICBmb250LXdlaWdodDogNzAwICFpbXBvcnRhbnQ7XHJcbiAgICB9XHJcbiAgICAmLmg1IHtcclxuICAgICAgICBmb250LXdlaWdodDogNzAwICFpbXBvcnRhbnQ7XHJcbiAgICB9XHJcbiAgICAmLmg2IHtcclxuICAgICAgICBmb250LXdlaWdodDogNzAwICFpbXBvcnRhbnQ7XHJcbiAgICB9XHJcbiAgICAmLmJvZHktbCB7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IDcwMCAhaW1wb3J0YW50O1xyXG4gICAgfVxyXG4gICAgJi5ib2R5LW4ge1xyXG4gICAgICAgIGZvbnQtd2VpZ2h0OiA3MDAgIWltcG9ydGFudDtcclxuICAgIH1cclxuICAgICYuYm9keS1zbSB7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IDcwMCAhaW1wb3J0YW50O1xyXG4gICAgfVxyXG4gICAgJi5ib2R5LXhzIHtcclxuICAgICAgICBmb250LXdlaWdodDogNzAwICFpbXBvcnRhbnQ7XHJcbiAgICB9XHJcbn0iXX0= */";

/***/ }),

/***/ 55212:
/*!*****************************************************************************************!*\
  !*** ./src/app/pages/new-claim/payment-detail/payment-detail.component.scss?ngResource ***!
  \*****************************************************************************************/
/***/ ((module) => {

module.exports = ":root {\n  --nc-color-nextgen-neutral-grey-50: red;\n  --nc-color-nextgen-white: yellow;\n  --nc-color-nextgen-blue: #0d152e;\n  --nc-color-nextgen-green: #00908d;\n  --nc-color-nextgen-black: #000000;\n  --nc-color-nextgen-grey-background: #c8d3da;\n  --nc-color-nextgen-grey: #92a2ac;\n  --nc-color-nextgen-stone-grey: #fafafa;\n  --nc-color-nextgen-error: #fc1055;\n  --nc-color-nextgen-neutral-grey: #414141;\n  --nc-color-nextgen-fibrant-green: #00bab6;\n  --nc-color-nextgen-warning: #ffd048;\n  --nc-color-nextgen-green-background: #e6f2f2;\n  --nc-color-nextgen-neutral-grey-400: #7a7a7a;\n  --nc-color-nextgen-neutral-grey-100: #eff3f5;\n  --nc-color-nextgen-status-error: #ba0c3f;\n  --nc-color-nextgen-status-error-background: #ffeff4;\n  --nc-color-nextgen-status-warning: #cba127;\n  --nc-color-nextgen-status-warning-background: #fff8e6;\n  --nc-color-nextgen-blue-100: #dfeff2;\n  --nc-color-nextgen-error-red-700: #f62459;\n  --nc-color-nextgen-blue-500: #006192;\n  --nc-color-nextgen-blue-400: #79cdec;\n  --nc-color-nextgen-red-500: #ff6592;\n  --nc-color-nextgen-secondary-blue-300: #13a0d3;\n  --lumi-white-color: #ffffff;\n  --lumi-primary-yellow-color: #fab600;\n}\n\n.ion-color-green {\n  --ion-color-base: var(--nc-color-nextgen-green);\n  --ion-color-base-rgb: var(--nc-color-nextgen-green);\n  --ion-color-contrast: var(--nc-color-nextgen-white);\n  --ion-color-contrast-rgb: var(--nc-color-nextgen-green);\n  --ion-color-shade: var(--nc-color-nextgen-green);\n  --ion-color-tint: var(--nc-color-nextgen-green);\n}\n\n.payment-method {\n  background: var(--nc-color-nextgen-neutral-grey-50);\n  min-height: 100%;\n  margin-bottom: 128px;\n}\n\n.payment-method .title {\n  color: var(--nc-color-nextgen-blue);\n  padding-bottom: 1rem;\n}\n\n.segment {\n  width: 100%;\n  height: 3rem;\n  background: var(--nc-color-nextgen-grey-background);\n  border-radius: 6px;\n}\n\n.segment .segment-button {\n  width: 100%;\n  --indicator-color: none;\n  border-radius: 6px;\n}\n\n.segment .segment-button .segment-text {\n  color: var(--nc-color-nextgen-blue);\n}\n\n.segment .segment-button.segment-button-checked {\n  background-color: var(--nc-color-nextgen-green);\n}\n\n.segment .segment-button.segment-button-checked .segment-text {\n  color: var(--nc-color-nextgen-white);\n  font-weight: 700 !important;\n}\n\n.create-new {\n  text-align: center;\n  padding: 1.5rem;\n}\n\n.create-new .text-button {\n  color: var(--nc-color-nextgen-green);\n}\n\n.create-new .icon-create {\n  font-size: 20px !important;\n  color: var(--nc-color-nextgen-green);\n  padding: 0.5rem;\n}\n\n.btn-create {\n  background-color: transparent;\n}\n\n.content {\n  background: var(--nc-color-nextgen-white);\n  box-shadow: 0px 1px 2px rgba(0, 0, 0, 0.1);\n  border-radius: 8px;\n  padding: 1rem;\n  align-items: center;\n}\n\n.content .headerCard {\n  color: var(--nc-color-nextgen-black);\n}\n\n.content .bodyCard {\n  color: var(--nc-color-nextgen-neutral-grey-400);\n  padding-top: 0.25rem;\n}\n\n.content .icon-active {\n  text-align: right;\n}\n\n.card-payment {\n  padding-top: 1rem;\n  padding-top: 1rem;\n}\n\n.chequeButton {\n  background-color: var(--nc-color-nextgen-green);\n}\n\n.chequeDelivery-text {\n  color: var(--nc-color-nextgen-white) !important;\n  font-weight: 700 !important;\n}\n\n.uil-circle:before {\n  font-size: 23px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFxjb2xvci5zY3NzIiwicGF5bWVudC1kZXRhaWwuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDQyx1Q0FBQTtFQUNBLGdDQUFBO0VBQ0EsZ0NBQUE7RUFDQSxpQ0FBQTtFQUNBLGlDQUFBO0VBQ0EsMkNBQUE7RUFDQSxnQ0FBQTtFQUNBLHNDQUFBO0VBQ0EsaUNBQUE7RUFDQSx3Q0FBQTtFQUNBLHlDQUFBO0VBQ0EsbUNBQUE7RUFDQSw0Q0FBQTtFQUNBLDRDQUFBO0VBQ0EsNENBQUE7RUFDQSx3Q0FBQTtFQUNBLG1EQUFBO0VBQ0EsMENBQUE7RUFDQSxxREFBQTtFQUNBLG9DQUFBO0VBQ0EseUNBQUE7RUFDQSxvQ0FBQTtFQUNBLG9DQUFBO0VBQ0EsbUNBQUE7RUFDQSw4Q0FBQTtFQUVBLDJCQUFBO0VBQ0Esb0NBQUE7QUNBRDs7QURnQ0E7RUFDQywrQ0FBQTtFQUNBLG1EQUFBO0VBQ0EsbURBQUE7RUFDQSx1REFBQTtFQUNBLGdEQUFBO0VBQ0EsK0NBQUE7QUM3QkQ7O0FBcENBO0VBQ0ksbUREd0M0QjtFQ3ZDNUIsZ0JBQUE7RUFDQSxvQkFBQTtBQXVDSjs7QUF0Q0k7RUFDSSxtQ0R3QmE7RUN2QmIsb0JBQUE7QUF3Q1I7O0FBcENBO0VBQ0ksV0FBQTtFQUNBLFlBQUE7RUFDQSxtRERvQjRCO0VDbkI1QixrQkFBQTtBQXVDSjs7QUF0Q0k7RUFDSSxXQUFBO0VBQ0EsdUJBQUE7RUFDQSxrQkFBQTtBQXdDUjs7QUF2Q1E7RUFDSSxtQ0RTUztBQ2dDckI7O0FBdkNRO0VBQ0ksK0NET1U7QUNrQ3RCOztBQXhDWTtFQUNJLG9DRE1NO0VDTE4sMkJBQUE7QUEwQ2hCOztBQXBDQTtFQUNJLGtCQUFBO0VBQ0EsZUFBQTtBQXVDSjs7QUF0Q0k7RUFDSSxvQ0ROYztBQzhDdEI7O0FBdENJO0VBQ0ksMEJBQUE7RUFDQSxvQ0RWYztFQ1dkLGVBQUE7QUF3Q1I7O0FBcENBO0VBQ0ksNkJBQUE7QUF1Q0o7O0FBcENBO0VBQ0kseUNEbkJrQjtFQ29CbEIsMENBQUE7RUFDQSxrQkFBQTtFQUNBLGFBQUE7RUFDQSxtQkFBQTtBQXVDSjs7QUF0Q0k7RUFDSSxvQ0R4QmM7QUNnRXRCOztBQXRDSTtFQUNJLCtDRGpCeUI7RUNrQnpCLG9CQUFBO0FBd0NSOztBQXRDSTtFQUNJLGlCQUFBO0FBd0NSOztBQXBDQTtFQUNJLGlCQUFBO0VBQ0EsaUJBQUE7QUF1Q0o7O0FBcENBO0VBQ0ksK0NEM0NrQjtBQ2tGdEI7O0FBckNBO0VBQ0ksK0NBQUE7RUFDQSwyQkFBQTtBQXdDSjs7QUFyQ0E7RUFDSSxlQUFBO0FBd0NKIiwiZmlsZSI6InBheW1lbnQtZGV0YWlsLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiOnJvb3Qge1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNTA6IHJlZDtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4td2hpdGU6IHllbGxvdztcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZTogIzBkMTUyZTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW46ICMwMDkwOGQ7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWJsYWNrOiAjMDAwMDAwO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ncmV5LWJhY2tncm91bmQ6ICNjOGQzZGE7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWdyZXk6ICM5MmEyYWM7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0b25lLWdyZXk6ICNmYWZhZmE7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWVycm9yOiAjZmMxMDU1O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXk6ICM0MTQxNDE7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWZpYnJhbnQtZ3JlZW46ICMwMGJhYjY7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXdhcm5pbmc6ICNmZmQwNDg7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuLWJhY2tncm91bmQ6ICNlNmYyZjI7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS00MDA6ICM3YTdhN2E7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS0xMDA6ICNlZmYzZjU7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy1lcnJvcjogI2JhMGMzZjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yLWJhY2tncm91bmQ6ICNmZmVmZjQ7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy13YXJuaW5nOiAjY2JhMTI3O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtd2FybmluZy1iYWNrZ3JvdW5kOiAjZmZmOGU2O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlLTEwMDogI2RmZWZmMjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tZXJyb3ItcmVkLTcwMDogI2Y2MjQ1OTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZS01MDA6ICMwMDYxOTI7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWJsdWUtNDAwOiAjNzljZGVjO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1yZWQtNTAwOiAjZmY2NTkyO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zZWNvbmRhcnktYmx1ZS0zMDA6ICMxM2EwZDM7XHJcblxyXG5cdC0tbHVtaS13aGl0ZS1jb2xvcjogI2ZmZmZmZjtcclxuXHQtLWx1bWktcHJpbWFyeS15ZWxsb3ctY29sb3I6ICNmYWI2MDA7XHJcbn1cclxuJGNvbG9yLW5leHRnZW4tYmx1ZTogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlKTtcclxuJGNvbG9yLW5leHRnZW4tZ3JlZW46IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4pO1xyXG4kY29sb3ItbmV4dGdlbi13aGl0ZTogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi13aGl0ZSk7XHJcbiRjb2xvci1uZXh0Z2VuLWJsYWNrOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWJsYWNrKTtcclxuJGNvbG9yLW5leHRnZW4tZ3JleS1iYWNrZ3JvdW5kOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZXktYmFja2dyb3VuZCk7XHJcbiRjb2xvci1uZXh0Z2VuLWdyZXk6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JleSk7XHJcbiRjb2xvci1uZXh0Z2VuLXN0b25lLWdyZXk6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tc3RvbmUtZ3JleSk7XHJcbiRjb2xvci1uZXh0Z2VuLWVycm9yOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWVycm9yKTtcclxuJGNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5OiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleSk7XHJcbiRjb2xvci1uZXh0Z2VuLWZpYnJhbnQtZ3JlZW46IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZmlicmFudC1ncmVlbik7XHJcbiRjb2xvci1uZXh0Z2VuLXdhcm5pbmc6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4td2FybmluZyk7XHJcbiRjb2xvci1uZXh0Z2VuLWdyZWVuLWJhY2tncm91bmQ6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4tYmFja2dyb3VuZCk7XHJcbiRjb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS01MDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNTApO1xyXG4kY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNDAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS00MDApO1xyXG4kY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktMTAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS0xMDApO1xyXG4kY29sb3ItbmV4dGdlbi1zdGF0dXMtZXJyb3I6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yKTtcclxuJGNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yLWJhY2tncm91bmQ6IHZhcihcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yLWJhY2tncm91bmRcclxuKTtcclxuJGNvbG9yLW5leHRnZW4tc3RhdHVzLXdhcm5pbmc6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLXdhcm5pbmcpO1xyXG4kY29sb3ItbmV4dGdlbi1zdGF0dXMtd2FybmluZy1iYWNrZ3JvdW5kOiB2YXIoXHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy13YXJuaW5nLWJhY2tncm91bmRcclxuKTtcclxuJGNvbG9yLW5leHRnZW4tYmx1ZS0xMDA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZS0xMDApO1xyXG4kY29sb3ItbmV4dGdlbi1lcnJvci1yZWQtNzAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWVycm9yLXJlZC03MDApO1xyXG4kY29sb3ItbmV4dGdlbi1ibHVlLTUwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlLTUwMCk7XHJcbiRjb2xvci1uZXh0Z2VuLWJsdWUtNDAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWJsdWUtNDAwKTtcclxuJGNvbG9yLW5leHRnZW4tcmVkLTUwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1yZWQtNTAwKTtcclxuJGNvbG9yLW5leHRnZW4tc2Vjb25kYXJ5LWJsdWUtMzAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXNlY29uZGFyeS1ibHVlLTMwMCk7XHJcblxyXG4uaW9uLWNvbG9yLWdyZWVuIHtcclxuXHQtLWlvbi1jb2xvci1iYXNlOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuKTtcclxuXHQtLWlvbi1jb2xvci1iYXNlLXJnYjogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbik7XHJcblx0LS1pb24tY29sb3ItY29udHJhc3Q6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4td2hpdGUpO1xyXG5cdC0taW9uLWNvbG9yLWNvbnRyYXN0LXJnYjogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbik7XHJcblx0LS1pb24tY29sb3Itc2hhZGU6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4pO1xyXG5cdC0taW9uLWNvbG9yLXRpbnQ6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4pO1xyXG59XHJcbiIsIkBpbXBvcnQgXCIuLi8uLi8uLi8uLi9jb2xvci5zY3NzXCI7XHJcbi5wYXltZW50LW1ldGhvZCB7XHJcbiAgICBiYWNrZ3JvdW5kOiAkY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNTA7XHJcbiAgICBtaW4taGVpZ2h0OiAxMDAlO1xyXG4gICAgbWFyZ2luLWJvdHRvbTogMTI4cHg7XHJcbiAgICAudGl0bGUge1xyXG4gICAgICAgIGNvbG9yOiAkY29sb3ItbmV4dGdlbi1ibHVlO1xyXG4gICAgICAgIHBhZGRpbmctYm90dG9tOiAxcmVtO1xyXG4gICAgfVxyXG59XHJcblxyXG4uc2VnbWVudCB7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIGhlaWdodDogM3JlbTtcclxuICAgIGJhY2tncm91bmQ6ICRjb2xvci1uZXh0Z2VuLWdyZXktYmFja2dyb3VuZDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDZweDtcclxuICAgIC5zZWdtZW50LWJ1dHRvbiB7XHJcbiAgICAgICAgd2lkdGg6IDEwMCU7XHJcbiAgICAgICAgLS1pbmRpY2F0b3ItY29sb3I6IG5vbmU7XHJcbiAgICAgICAgYm9yZGVyLXJhZGl1czogNnB4O1xyXG4gICAgICAgIC5zZWdtZW50LXRleHQge1xyXG4gICAgICAgICAgICBjb2xvcjogJGNvbG9yLW5leHRnZW4tYmx1ZTtcclxuICAgICAgICB9XHJcbiAgICAgICAgJi5zZWdtZW50LWJ1dHRvbi1jaGVja2VkIHtcclxuICAgICAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogJGNvbG9yLW5leHRnZW4tZ3JlZW47XHJcbiAgICAgICAgICAgIC5zZWdtZW50LXRleHQge1xyXG4gICAgICAgICAgICAgICAgY29sb3I6ICRjb2xvci1uZXh0Z2VuLXdoaXRlO1xyXG4gICAgICAgICAgICAgICAgZm9udC13ZWlnaHQ6IDcwMCAhaW1wb3J0YW50O1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59XHJcblxyXG4uY3JlYXRlLW5ldyB7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBwYWRkaW5nOiAxLjVyZW07XHJcbiAgICAudGV4dC1idXR0b24ge1xyXG4gICAgICAgIGNvbG9yOiAkY29sb3ItbmV4dGdlbi1ncmVlbjtcclxuICAgIH1cclxuICAgIC5pY29uLWNyZWF0ZSB7XHJcbiAgICAgICAgZm9udC1zaXplOiAyMHB4ICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgY29sb3I6ICRjb2xvci1uZXh0Z2VuLWdyZWVuO1xyXG4gICAgICAgIHBhZGRpbmc6IDAuNXJlbTtcclxuICAgIH1cclxufVxyXG5cclxuLmJ0bi1jcmVhdGUge1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogdHJhbnNwYXJlbnQ7XHJcbn1cclxuXHJcbi5jb250ZW50IHtcclxuICAgIGJhY2tncm91bmQ6ICRjb2xvci1uZXh0Z2VuLXdoaXRlO1xyXG4gICAgYm94LXNoYWRvdzogMHB4IDFweCAycHggcmdiYSgwLCAwLCAwLCAwLjEpO1xyXG4gICAgYm9yZGVyLXJhZGl1czogOHB4O1xyXG4gICAgcGFkZGluZzogMXJlbTtcclxuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICAuaGVhZGVyQ2FyZCB7XHJcbiAgICAgICAgY29sb3I6ICRjb2xvci1uZXh0Z2VuLWJsYWNrO1xyXG4gICAgfVxyXG4gICAgLmJvZHlDYXJkIHtcclxuICAgICAgICBjb2xvcjogJGNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTQwMDtcclxuICAgICAgICBwYWRkaW5nLXRvcDogMC4yNXJlbTtcclxuICAgIH1cclxuICAgIC5pY29uLWFjdGl2ZSB7XHJcbiAgICAgICAgdGV4dC1hbGlnbjogcmlnaHQ7XHJcbiAgICB9XHJcbn1cclxuXHJcbi5jYXJkLXBheW1lbnQge1xyXG4gICAgcGFkZGluZy10b3A6IDFyZW07XHJcbiAgICBwYWRkaW5nLXRvcDogMXJlbTtcclxufVxyXG5cclxuLmNoZXF1ZUJ1dHRvbntcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICRjb2xvci1uZXh0Z2VuLWdyZWVuOyBcclxufVxyXG4uY2hlcXVlRGVsaXZlcnktdGV4dCB7XHJcbiAgICBjb2xvcjogJGNvbG9yLW5leHRnZW4td2hpdGUgIWltcG9ydGFudDtcclxuICAgIGZvbnQtd2VpZ2h0OiA3MDAgIWltcG9ydGFudDtcclxufVxyXG5cclxuLnVpbC1jaXJjbGU6YmVmb3JlIHtcclxuICAgIGZvbnQtc2l6ZTogMjNweDtcclxufSJdfQ== */";

/***/ }),

/***/ 54544:
/*!***********************************************************************************************!*\
  !*** ./src/app/pages/new-claim/review-and-submit/review-and-submit.component.scss?ngResource ***!
  \***********************************************************************************************/
/***/ ((module) => {

module.exports = ":root {\n  --nc-color-nextgen-neutral-grey-50: red;\n  --nc-color-nextgen-white: yellow;\n  --nc-color-nextgen-blue: #0d152e;\n  --nc-color-nextgen-green: #00908d;\n  --nc-color-nextgen-black: #000000;\n  --nc-color-nextgen-grey-background: #c8d3da;\n  --nc-color-nextgen-grey: #92a2ac;\n  --nc-color-nextgen-stone-grey: #fafafa;\n  --nc-color-nextgen-error: #fc1055;\n  --nc-color-nextgen-neutral-grey: #414141;\n  --nc-color-nextgen-fibrant-green: #00bab6;\n  --nc-color-nextgen-warning: #ffd048;\n  --nc-color-nextgen-green-background: #e6f2f2;\n  --nc-color-nextgen-neutral-grey-400: #7a7a7a;\n  --nc-color-nextgen-neutral-grey-100: #eff3f5;\n  --nc-color-nextgen-status-error: #ba0c3f;\n  --nc-color-nextgen-status-error-background: #ffeff4;\n  --nc-color-nextgen-status-warning: #cba127;\n  --nc-color-nextgen-status-warning-background: #fff8e6;\n  --nc-color-nextgen-blue-100: #dfeff2;\n  --nc-color-nextgen-error-red-700: #f62459;\n  --nc-color-nextgen-blue-500: #006192;\n  --nc-color-nextgen-blue-400: #79cdec;\n  --nc-color-nextgen-red-500: #ff6592;\n  --nc-color-nextgen-secondary-blue-300: #13a0d3;\n  --lumi-white-color: #ffffff;\n  --lumi-primary-yellow-color: #fab600;\n}\n\n.ion-color-green {\n  --ion-color-base: var(--nc-color-nextgen-green);\n  --ion-color-base-rgb: var(--nc-color-nextgen-green);\n  --ion-color-contrast: var(--nc-color-nextgen-white);\n  --ion-color-contrast-rgb: var(--nc-color-nextgen-green);\n  --ion-color-shade: var(--nc-color-nextgen-green);\n  --ion-color-tint: var(--nc-color-nextgen-green);\n}\n\n.menu-content {\n  --background: #F1EFEF;\n}\n\n.menu-content .body {\n  margin-bottom: 128px;\n}\n\n.menu-content .body .review-text {\n  padding-top: 0.5rem;\n  color: var(--nc-color-nextgen-blue);\n}\n\n.menu-content .body .review-detail {\n  margin-top: 1rem;\n  padding: 1rem;\n  background-color: var(--nc-color-nextgen-white);\n  border-radius: 8px;\n  box-shadow: 0px 1px 2px rgba(0, 0, 0, 0.1);\n}\n\n.menu-content .body .review-detail .review-detail-title {\n  display: flex;\n  align-content: space-between;\n  justify-content: space-between;\n}\n\n.menu-content .body .review-detail .review-detail-title .title-text {\n  color: var(--nc-color-nextgen-grey);\n  padding-left: 0.5rem;\n  padding-bottom: 1rem;\n  text-transform: uppercase;\n}\n\n.menu-content .body .review-detail .border-box {\n  border-bottom: 1px solid #EFF3F5;\n  width: 100%;\n  margin-bottom: 0.5rem;\n}\n\n.menu-content .body .review-detail .review-detail-subtitle {\n  padding-top: 0.5rem;\n  padding-bottom: 0.5rem;\n  padding-left: 0.5rem;\n}\n\n.menu-content .body .review-detail .review-detail-subtitle .review-detail-text {\n  color: var(--nc-color-nextgen-neutral-grey-400);\n}\n\n.menu-content .body .review-detail .review-detail-subtitle .review-detail-content {\n  color: var(--nc-color-nextgen-blue);\n  padding-top: 1rem;\n}\n\n.menu-content .body .review-detail .review-detail-subtitle .document-text {\n  color: var(--nc-color-nextgen-blue);\n}\n\n.menu-content .body .review-detail .review-detail-subtitle .document-content {\n  color: var(--nc-color-nextgen-neutral-grey);\n  padding-top: 1rem;\n}\n\n.menu-content .body .review-detail .review-detail-subtitle .no-file {\n  padding-top: 1rem;\n  color: var(--nc-color-nextgen-error-red-700);\n}\n\n.menu-content .body .review-detail .review-detail-subtitle .documents-add {\n  color: var(--nc-color-nextgen-error-red-700);\n}\n\n.menu-content .body .review-detail .uil-edit:before {\n  content: \"\\e990\";\n  color: var(--nc-color-nextgen-grey);\n}\n\n.testCheckbox {\n  size: 18px;\n  --background-checked: #00908d;\n  --checkmark-color: #ffffff;\n  --background: transparent;\n  --checkmark-width: 5px;\n}\n\n.testCheckbox::part(container) {\n  border: solid #92a2ac 2px;\n  border-radius: 3px;\n}\n\n.testNotCheckbox {\n  size: 18px;\n  --background-checked: #00908d;\n  --checkmark-color: #ffffff;\n  --background: transparent;\n  --checkmark-width: 5px;\n}\n\n.testNotCheckbox::part(container) {\n  border: solid var(--nc-color-nextgen-error-red-700) 2px;\n  border-radius: 3px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFxjb2xvci5zY3NzIiwicmV2aWV3LWFuZC1zdWJtaXQuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDQyx1Q0FBQTtFQUNBLGdDQUFBO0VBQ0EsZ0NBQUE7RUFDQSxpQ0FBQTtFQUNBLGlDQUFBO0VBQ0EsMkNBQUE7RUFDQSxnQ0FBQTtFQUNBLHNDQUFBO0VBQ0EsaUNBQUE7RUFDQSx3Q0FBQTtFQUNBLHlDQUFBO0VBQ0EsbUNBQUE7RUFDQSw0Q0FBQTtFQUNBLDRDQUFBO0VBQ0EsNENBQUE7RUFDQSx3Q0FBQTtFQUNBLG1EQUFBO0VBQ0EsMENBQUE7RUFDQSxxREFBQTtFQUNBLG9DQUFBO0VBQ0EseUNBQUE7RUFDQSxvQ0FBQTtFQUNBLG9DQUFBO0VBQ0EsbUNBQUE7RUFDQSw4Q0FBQTtFQUVBLDJCQUFBO0VBQ0Esb0NBQUE7QUNBRDs7QURnQ0E7RUFDQywrQ0FBQTtFQUNBLG1EQUFBO0VBQ0EsbURBQUE7RUFDQSx1REFBQTtFQUNBLGdEQUFBO0VBQ0EsK0NBQUE7QUM3QkQ7O0FBcENBO0VBQ0kscUJBQUE7QUF1Q0o7O0FBdENJO0VBQ0ksb0JBQUE7QUF3Q1I7O0FBdENRO0VBQ0ksbUJBQUE7RUFDQSxtQ0RzQlM7QUNrQnJCOztBQXRDUTtFQUNJLGdCQUFBO0VBQ0EsYUFBQTtFQUNBLCtDRG1CVTtFQ2xCVixrQkFBQTtFQUNBLDBDQUFBO0FBd0NaOztBQXZDWTtFQUNJLGFBQUE7RUFDQSw0QkFBQTtFQUNBLDhCQUFBO0FBeUNoQjs7QUF4Q2dCO0VBQ0ksbUNEY0M7RUNiRCxvQkFBQTtFQUNBLG9CQUFBO0VBQ0EseUJBQUE7QUEwQ3BCOztBQXZDWTtFQUNJLGdDQUFBO0VBQ0EsV0FBQTtFQUNBLHFCQUFBO0FBeUNoQjs7QUF2Q1k7RUFDSSxtQkFBQTtFQUNBLHNCQUFBO0VBQ0Esb0JBQUE7QUF5Q2hCOztBQXhDZ0I7RUFDSSwrQ0RNYTtBQ29DakM7O0FBeENnQjtFQUNJLG1DRFZDO0VDV0QsaUJBQUE7QUEwQ3BCOztBQXhDZ0I7RUFDSSxtQ0RkQztBQ3dEckI7O0FBeENnQjtFQUNJLDJDRFRTO0VDVVQsaUJBQUE7QUEwQ3BCOztBQXhDZ0I7RUFDSSxpQkFBQTtFQUNBLDRDREVVO0FDd0M5Qjs7QUF4Q2dCO0VBQ0ksNENERFU7QUMyQzlCOztBQXZDWTtFQUNJLGdCQUFBO0VBQ0EsbUNEekJLO0FDa0VyQjs7QUFuQ0E7RUFDSSxVQUFBO0VBQ0EsNkJBQUE7RUFDQSwwQkFBQTtFQUNBLHlCQUFBO0VBQ0Esc0JBQUE7QUFzQ0o7O0FBbENBO0VBQ0kseUJBQUE7RUFDQSxrQkFBQTtBQXFDSjs7QUFsQ0E7RUFDSSxVQUFBO0VBQ0EsNkJBQUE7RUFDQSwwQkFBQTtFQUNBLHlCQUFBO0VBQ0Esc0JBQUE7QUFxQ0o7O0FBakNBO0VBQ0ksdURBQUE7RUFDQSxrQkFBQTtBQW9DSiIsImZpbGUiOiJyZXZpZXctYW5kLXN1Ym1pdC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIjpyb290IHtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTUwOiByZWQ7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXdoaXRlOiB5ZWxsb3c7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWJsdWU6ICMwZDE1MmU7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuOiAjMDA5MDhkO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ibGFjazogIzAwMDAwMDtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tZ3JleS1iYWNrZ3JvdW5kOiAjYzhkM2RhO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ncmV5OiAjOTJhMmFjO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zdG9uZS1ncmV5OiAjZmFmYWZhO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1lcnJvcjogI2ZjMTA1NTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5OiAjNDE0MTQxO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1maWJyYW50LWdyZWVuOiAjMDBiYWI2O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi13YXJuaW5nOiAjZmZkMDQ4O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbi1iYWNrZ3JvdW5kOiAjZTZmMmYyO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNDAwOiAjN2E3YTdhO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktMTAwOiAjZWZmM2Y1O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtZXJyb3I6ICNiYTBjM2Y7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy1lcnJvci1iYWNrZ3JvdW5kOiAjZmZlZmY0O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtd2FybmluZzogI2NiYTEyNztcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLXdhcm5pbmctYmFja2dyb3VuZDogI2ZmZjhlNjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZS0xMDA6ICNkZmVmZjI7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWVycm9yLXJlZC03MDA6ICNmNjI0NTk7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWJsdWUtNTAwOiAjMDA2MTkyO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlLTQwMDogIzc5Y2RlYztcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tcmVkLTUwMDogI2ZmNjU5MjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc2Vjb25kYXJ5LWJsdWUtMzAwOiAjMTNhMGQzO1xyXG5cclxuXHQtLWx1bWktd2hpdGUtY29sb3I6ICNmZmZmZmY7XHJcblx0LS1sdW1pLXByaW1hcnkteWVsbG93LWNvbG9yOiAjZmFiNjAwO1xyXG59XHJcbiRjb2xvci1uZXh0Z2VuLWJsdWU6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZSk7XHJcbiRjb2xvci1uZXh0Z2VuLWdyZWVuOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuKTtcclxuJGNvbG9yLW5leHRnZW4td2hpdGU6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4td2hpdGUpO1xyXG4kY29sb3ItbmV4dGdlbi1ibGFjazogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ibGFjayk7XHJcbiRjb2xvci1uZXh0Z2VuLWdyZXktYmFja2dyb3VuZDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmV5LWJhY2tncm91bmQpO1xyXG4kY29sb3ItbmV4dGdlbi1ncmV5OiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZXkpO1xyXG4kY29sb3ItbmV4dGdlbi1zdG9uZS1ncmV5OiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXN0b25lLWdyZXkpO1xyXG4kY29sb3ItbmV4dGdlbi1lcnJvcjogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1lcnJvcik7XHJcbiRjb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleTogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXkpO1xyXG4kY29sb3ItbmV4dGdlbi1maWJyYW50LWdyZWVuOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWZpYnJhbnQtZ3JlZW4pO1xyXG4kY29sb3ItbmV4dGdlbi13YXJuaW5nOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXdhcm5pbmcpO1xyXG4kY29sb3ItbmV4dGdlbi1ncmVlbi1iYWNrZ3JvdW5kOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuLWJhY2tncm91bmQpO1xyXG4kY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNTA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTUwKTtcclxuJGNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTQwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNDAwKTtcclxuJGNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTEwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktMTAwKTtcclxuJGNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy1lcnJvcik7XHJcbiRjb2xvci1uZXh0Z2VuLXN0YXR1cy1lcnJvci1iYWNrZ3JvdW5kOiB2YXIoXHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy1lcnJvci1iYWNrZ3JvdW5kXHJcbik7XHJcbiRjb2xvci1uZXh0Z2VuLXN0YXR1cy13YXJuaW5nOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy13YXJuaW5nKTtcclxuJGNvbG9yLW5leHRnZW4tc3RhdHVzLXdhcm5pbmctYmFja2dyb3VuZDogdmFyKFxyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtd2FybmluZy1iYWNrZ3JvdW5kXHJcbik7XHJcbiRjb2xvci1uZXh0Z2VuLWJsdWUtMTAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWJsdWUtMTAwKTtcclxuJGNvbG9yLW5leHRnZW4tZXJyb3ItcmVkLTcwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1lcnJvci1yZWQtNzAwKTtcclxuJGNvbG9yLW5leHRnZW4tYmx1ZS01MDA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZS01MDApO1xyXG4kY29sb3ItbmV4dGdlbi1ibHVlLTQwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlLTQwMCk7XHJcbiRjb2xvci1uZXh0Z2VuLXJlZC01MDA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tcmVkLTUwMCk7XHJcbiRjb2xvci1uZXh0Z2VuLXNlY29uZGFyeS1ibHVlLTMwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1zZWNvbmRhcnktYmx1ZS0zMDApO1xyXG5cclxuLmlvbi1jb2xvci1ncmVlbiB7XHJcblx0LS1pb24tY29sb3ItYmFzZTogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbik7XHJcblx0LS1pb24tY29sb3ItYmFzZS1yZ2I6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4pO1xyXG5cdC0taW9uLWNvbG9yLWNvbnRyYXN0OiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXdoaXRlKTtcclxuXHQtLWlvbi1jb2xvci1jb250cmFzdC1yZ2I6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4pO1xyXG5cdC0taW9uLWNvbG9yLXNoYWRlOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuKTtcclxuXHQtLWlvbi1jb2xvci10aW50OiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuKTtcclxufVxyXG4iLCJAaW1wb3J0IFwiLi4vLi4vLi4vLi4vY29sb3Iuc2Nzc1wiO1xyXG4ubWVudS1jb250ZW50IHtcclxuICAgIC0tYmFja2dyb3VuZDogI0YxRUZFRjtcclxuICAgIC5ib2R5IHtcclxuICAgICAgICBtYXJnaW4tYm90dG9tOiAxMjhweDtcclxuICAgICAgICAvLyBwYWRkaW5nOiAwcmVtIDFyZW0gMXJlbSAxcmVtO1xyXG4gICAgICAgIC5yZXZpZXctdGV4dCB7XHJcbiAgICAgICAgICAgIHBhZGRpbmctdG9wOiAwLjVyZW07XHJcbiAgICAgICAgICAgIGNvbG9yOiAkY29sb3ItbmV4dGdlbi1ibHVlO1xyXG4gICAgICAgIH1cclxuICAgICAgICAucmV2aWV3LWRldGFpbCB7XHJcbiAgICAgICAgICAgIG1hcmdpbi10b3A6IDFyZW07XHJcbiAgICAgICAgICAgIHBhZGRpbmc6IDFyZW07XHJcbiAgICAgICAgICAgIGJhY2tncm91bmQtY29sb3I6ICRjb2xvci1uZXh0Z2VuLXdoaXRlO1xyXG4gICAgICAgICAgICBib3JkZXItcmFkaXVzOiA4cHg7XHJcbiAgICAgICAgICAgIGJveC1zaGFkb3c6IDBweCAxcHggMnB4IHJnYmEoMCwgMCwgMCwgMC4xKTtcclxuICAgICAgICAgICAgLnJldmlldy1kZXRhaWwtdGl0bGUge1xyXG4gICAgICAgICAgICAgICAgZGlzcGxheTogZmxleDtcclxuICAgICAgICAgICAgICAgIGFsaWduLWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XHJcbiAgICAgICAgICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XHJcbiAgICAgICAgICAgICAgICAudGl0bGUtdGV4dCB7XHJcbiAgICAgICAgICAgICAgICAgICAgY29sb3I6ICRjb2xvci1uZXh0Z2VuLWdyZXk7XHJcbiAgICAgICAgICAgICAgICAgICAgcGFkZGluZy1sZWZ0OiAwLjVyZW07XHJcbiAgICAgICAgICAgICAgICAgICAgcGFkZGluZy1ib3R0b206IDFyZW07XHJcbiAgICAgICAgICAgICAgICAgICAgdGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAuYm9yZGVyLWJveCB7XHJcbiAgICAgICAgICAgICAgICBib3JkZXItYm90dG9tOiAxcHggc29saWQgI0VGRjNGNTtcclxuICAgICAgICAgICAgICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgICAgICAgICAgICAgbWFyZ2luLWJvdHRvbTogMC41cmVtO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIC5yZXZpZXctZGV0YWlsLXN1YnRpdGxlIHtcclxuICAgICAgICAgICAgICAgIHBhZGRpbmctdG9wOiAwLjVyZW07XHJcbiAgICAgICAgICAgICAgICBwYWRkaW5nLWJvdHRvbTogMC41cmVtO1xyXG4gICAgICAgICAgICAgICAgcGFkZGluZy1sZWZ0OiAwLjVyZW07XHJcbiAgICAgICAgICAgICAgICAucmV2aWV3LWRldGFpbC10ZXh0IHtcclxuICAgICAgICAgICAgICAgICAgICBjb2xvcjogJGNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTQwMDtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIC5yZXZpZXctZGV0YWlsLWNvbnRlbnQge1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbG9yOiAkY29sb3ItbmV4dGdlbi1ibHVlO1xyXG4gICAgICAgICAgICAgICAgICAgIHBhZGRpbmctdG9wOiAxcmVtO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgLmRvY3VtZW50LXRleHQge1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbG9yOiAkY29sb3ItbmV4dGdlbi1ibHVlO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgLmRvY3VtZW50LWNvbnRlbnQge1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbG9yOiAkY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXk7XHJcbiAgICAgICAgICAgICAgICAgICAgcGFkZGluZy10b3A6IDFyZW07ICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIC5uby1maWxle1xyXG4gICAgICAgICAgICAgICAgICAgIHBhZGRpbmctdG9wOiAxcmVtO1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbG9yOiAkY29sb3ItbmV4dGdlbi1lcnJvci1yZWQtNzAwO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIC5kb2N1bWVudHMtYWRkIHtcclxuICAgICAgICAgICAgICAgICAgICBjb2xvcjogJGNvbG9yLW5leHRnZW4tZXJyb3ItcmVkLTcwMDtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAudWlsLWVkaXQ6YmVmb3JlIHtcclxuICAgICAgICAgICAgICAgIGNvbnRlbnQ6ICdcXGU5OTAnO1xyXG4gICAgICAgICAgICAgICAgY29sb3I6ICRjb2xvci1uZXh0Z2VuLWdyZXk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcbn1cclxuXHJcbi50ZXN0Q2hlY2tib3gge1xyXG4gICAgc2l6ZTogMThweDtcclxuICAgIC0tYmFja2dyb3VuZC1jaGVja2VkOiAjMDA5MDhkO1xyXG4gICAgLS1jaGVja21hcmstY29sb3I6ICNmZmZmZmY7XHJcbiAgICAtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xyXG4gICAgLS1jaGVja21hcmstd2lkdGg6IDVweDtcclxuXHJcbn1cclxuXHJcbi50ZXN0Q2hlY2tib3g6OnBhcnQoY29udGFpbmVyKSB7XHJcbiAgICBib3JkZXI6IHNvbGlkICM5MmEyYWMgMnB4O1xyXG4gICAgYm9yZGVyLXJhZGl1czogM3B4O1xyXG59XHJcblxyXG4udGVzdE5vdENoZWNrYm94IHtcclxuICAgIHNpemU6IDE4cHg7XHJcbiAgICAtLWJhY2tncm91bmQtY2hlY2tlZDogIzAwOTA4ZDtcclxuICAgIC0tY2hlY2ttYXJrLWNvbG9yOiAjZmZmZmZmO1xyXG4gICAgLS1iYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcclxuICAgIC0tY2hlY2ttYXJrLXdpZHRoOiA1cHg7XHJcblxyXG59XHJcblxyXG4udGVzdE5vdENoZWNrYm94OjpwYXJ0KGNvbnRhaW5lcikge1xyXG4gICAgYm9yZGVyOiBzb2xpZCAkY29sb3ItbmV4dGdlbi1lcnJvci1yZWQtNzAwIDJweDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDNweDtcclxufVxyXG4gICAgXHJcbiAgICAiXX0= */";

/***/ }),

/***/ 64192:
/*!***************************************************************************************!*\
  !*** ./src/app/pages/new-claim/claim-details/claim-details.component.html?ngResource ***!
  \***************************************************************************************/
/***/ ((module) => {

module.exports = "<ion-content #content>\r\n  <form [formGroup]=\"claimForm\">\r\n    <div class=\"claim-details-main mb-2\">\r\n      <div class=\"claim-details-title\">\r\n        <p class=\"h4 bold\">{{'claimDetails.title'|translate}}</p>\r\n      </div>\r\n      <div class=\"claim-details-content\">\r\n        <div class=\"detail-content\">\r\n          <nextgen-control\r\n            [type]=\"TYPE.SELECTDIALOG\"\r\n            [label-property]=\"'claimDetails.memberLabel'|translate\"\r\n            [items]=\"members\"\r\n            [dialogTitle]=\"'claimDetails.selectMemberLabel'|translate\"\r\n            [hasIcon]=\"true\"\r\n            formControlName=\"memberSelect\"\r\n            [height]=\"'45%'\"  \r\n            [placeholder]=\"'claimDetails.chooseMember'|translate\"\r\n          >\r\n          </nextgen-control>\r\n        </div>\r\n        <div class=\"detail-content\">\r\n          <nextgen-control\r\n            [type]=\"TYPE.COUNTRYSELECTION\"\r\n            [titleCountry]=\"'country.selectCountryOfInsurance' | translate\"\r\n            [label-property]=\"'claimDetails.countryOfHealthCareProvider'|translate\"\r\n            formControlName=\"countrySelect\"\r\n            [items]=\"countryList\"\r\n            [placeholder]=\"'claimDetails.chooseCountry'|translate\"            \r\n            (ngModelChange)=\"handleCountryChange($event)\"\r\n          >\r\n          </nextgen-control>\r\n        </div>\r\n        <div class=\"detail-content\">\r\n          <nextgen-control\r\n            [type]=\"TYPE.SELECTDIALOG\"\r\n            [label-property]=\"'claimDetails.serviceType'|translate\"\r\n            [items]=\"serviceTypes\"\r\n            [dialogTitle]=\"'claimDetails.serviceType'|translate\"\r\n            [placeholder]=\"'claimDetails.chooseServiceType'|translate\"\r\n            [height]=\"'45%'\"\r\n            formControlName=\"serviceType\"\r\n          ></nextgen-control>\r\n        </div>\r\n        <div class=\"detail-content\">\r\n          <nextgen-control\r\n            [type]=\"TYPE.DATETIMEDIALOG\"\r\n            [label-property]=\"'claimDetails.serviceDate'|translate\"\r\n            formControlName=\"serviceDate\"\r\n            [placeholder]=\"'claimDetails.selectServiceDate'|translate\"\r\n            [maxDate]=\"maxDate\" \r\n          >\r\n          </nextgen-control>\r\n        </div>\r\n        <div [hidden]=\"!(!!claimForm.controls?.dischargeDate?.value || isShowDischargeDate)\"\r\n        class=\"detail-content\">\r\n          <nextgen-control\r\n            [type]=\"TYPE.DATETIMEDIALOG\"\r\n            [label-property]=\"'claimDetails.dischargeDate'|translate\"\r\n            formControlName=\"dischargeDate\"\r\n            [placeholder]=\"'claimDetails.selectDischargeDate'|translate\"\r\n            [maxDate]=\"maxDate\"\r\n            [minDate]=\"minDate\"\r\n          >\r\n          </nextgen-control>\r\n        </div>       \r\n        <div class=\"currency-content\">\r\n          <div class=\"currency\">\r\n            <nextgen-control\r\n            [type]=\"TYPE.SELECTDIALOG\"\r\n            [label-property]=\"'currency.title'|translate\"   \r\n            [dialogTitle]=\"'currency.selectCurrency' | translate\"\r\n            formControlName=\"currency\"\r\n            [items]=\"currencyList\"\r\n            [hasIcon]=\"true\"   \r\n            [second-icon]=\"'uil uil-arrow-right'\"\r\n            [placeholder]=\"'claimDetails.chooseCurrency'|translate\"\r\n            [height]=\"'70%'\"\r\n            [ngModel]=\"currency\"\r\n            ></nextgen-control>\r\n          </div>\r\n          <div class=\"space\"></div>\r\n          <div class=\"amount\">\r\n            <nextgen-control \r\n            [type]=\"TYPE.INPUTNUMBER\"\r\n            placeholder=\"0.00\"\r\n            [label-property]=\"'claimDetails.amount'|translate\" \r\n            formControlName=\"amount\"         \r\n\r\n            ></nextgen-control>\r\n          </div>         \r\n        </div>   \r\n        <div class=\"notes-content\">\r\n          <nextgen-control [type]=\"TYPE.TEXTAREA\" [label-property]=\"'claimDetails.notes' | translate\"\r\n          (focusHandler)=\"focusNoteHandler()\"\r\n            formControlName=\"notes\" [placeholder]=\"'claimDetails.writeHere' | translate\">\r\n          </nextgen-control>\r\n        </div>     \r\n      </div>\r\n    </div>\r\n  </form>\r\n</ion-content>\r\n<nextcare-workflow-commands [this]=\"this\" [commands]=\"commands\"></nextcare-workflow-commands>\r\n";

/***/ }),

/***/ 2209:
/*!***************************************************************************************************!*\
  !*** ./src/app/pages/new-claim/disclosure-accident/disclosure-accident.component.html?ngResource ***!
  \***************************************************************************************************/
/***/ ((module) => {

module.exports = "<ion-content #content>\r\n\t<form [formGroup]=\"disclosureForm\">\r\n\t\t<div class=\"disclosure-accident-main mb-2\">\r\n\t\t\t<div class=\"disclosure-accident-title\">\r\n\t\t\t\t<p class=\"h4 bold\">{{'disclosure.title'|translate}}</p>\r\n\t\t\t</div>\r\n\t\t\t<div class=\"disclosure-accident-content\">\r\n\t\t\t\t<div class=\"detail-content\">\r\n\t\t\t\t\t<nextgen-control [type]=\"TYPE.INPUT\" [label-property]=\"'disclosure.treatmentOfSymptoms'|translate\" formControlName=\"treatmentOfSymptoms\"></nextgen-control>\r\n\t\t\t\t</div>\r\n\t\t\t\t<div class=\"detail-content\">\r\n\t\t\t\t\t<nextgen-control [type]=\"TYPE.DATETIMEDIALOG\" [label-property]=\"'disclosure.firstOccurrenceDate'|translate\" formControlName=\"firstOccurrenceDate\" [maxDate]=\"maxDate\"></nextgen-control>\r\n\t\t\t\t</div>\r\n\t\t\t\t<div class=\"detail-content\">\r\n\t\t\t\t\t<nextgen-control [type]=\"TYPE.CHECKRADIO\" [label-property]=\"'disclosure.treatmentSymtoms'|translate\" [items]=\"checkBox\" formControlName=\"treatmentSymtoms\"></nextgen-control>\r\n\t\t\t\t</div>\r\n\t\t\t\t<div [hidden]=\"!displayFirstDateTreatment && minDate==null\" class=\"detail-content\">\r\n\t\t\t\t\t<nextgen-control\r\n\t\t\t\t\t\t[type]=\"TYPE.DATETIMEDIALOG\"\r\n\t\t\t\t\t\t[label-property]=\"'disclosure.dateFirstTreatmentOfSymptoms'|translate\"\r\n\t\t\t\t\t\tformControlName=\"dateFirstTreatmentOfSymptoms\"\r\n\t\t\t\t\t\t[maxDate]=\"maxDate\"\r\n\t\t\t\t\t\t[minDate]=\"minDate\"\r\n\t\t\t\t\t></nextgen-control>\r\n\t\t\t\t</div>\r\n\t\t\t\t<div class=\"detail-content\">\r\n\t\t\t\t\t<nextgen-control [type]=\"TYPE.CHECKRADIO\"  (ngModelChange)=\"changeCheckBox($event)\" [label-property]=\"'disclosure.accident'|translate\" [items]=\"checkBox\" formControlName=\"accident\"></nextgen-control>\r\n\t\t\t\t</div>\r\n\t\t\t\t<div [hidden]=\"!displayAccidentDescription\" class=\"detail-content-accidentDesc\">\r\n\t\t\t\t\t<nextgen-control [type]=\"TYPE.INPUT\" [label-property]=\"'disclosure.accidentDesc'|translate\" formControlName=\"accidentDesc\"></nextgen-control>\r\n\t\t\t\t</div>\r\n\t\t\t</div>\r\n\t\t</div>\r\n\t</form>\r\n</ion-content>\r\n<nextcare-workflow-commands [this]=\"this\" [commands]=\"commands\"></nextcare-workflow-commands>\r\n";

/***/ }),

/***/ 24235:
/*!****************************************************************!*\
  !*** ./src/app/pages/new-claim/new-claim.page.html?ngResource ***!
  \****************************************************************/
/***/ ((module) => {

module.exports = "<div class=\"new-claim-container\">\r\n    <nextcare-workflow title=\"{{'newClaim.title'|translate}}\" [steps]=\"stepProgress\" [this]=\"this\" [command]=\"command\"></nextcare-workflow>\r\n</div>\r\n";

/***/ }),

/***/ 37279:
/*!*****************************************************************************************!*\
  !*** ./src/app/pages/new-claim/payment-detail/payment-detail.component.html?ngResource ***!
  \*****************************************************************************************/
/***/ ((module) => {

module.exports = "<ion-content mode=\"ios\" class=\"payment-method\">\r\n    <div class=\"payment-method\">\r\n        <div class=\"title h4 bold\">{{ 'paymentMethodClaim.paymentMethod' | translate }}</div>\r\n        <ion-segment class=\"segment\" (ionChange)=\"segmentChanged($event)\" value=\"banktransfer\">\r\n            <ion-segment-button *ngIf=\"displayBank\" class=\"segment-button body-n\" value=\"banktransfer\">\r\n                <ion-label class=\"segment-text\">{{ 'paymentMethodClaim.bankTransfer' | translate }}</ion-label>\r\n            </ion-segment-button>\r\n            <ion-segment-button *ngIf=\"displayCheque\" [ngClass]=\"!displayBank ? 'chequeButton': ''\"  class=\"segment-button body-n\" value=\"chequeDelivery\">\r\n                <ion-label [ngClass]=\"!displayBank ? 'chequeDelivery-text': ''\" class=\"segment-text\">{{ 'paymentMethodClaim.chequeDelivery' | translate }}</ion-label>\r\n            </ion-segment-button>\r\n        </ion-segment>\r\n        <div [ngSwitch]=\"switchCase\">\r\n            <ng-container *ngSwitchCase=\"'chequeDelivery'\">\r\n                <ion-grid [ngStyle]=\"{'display': (displayCheque == false)?'none':'block'}\" *ngFor=\"let item of listAddress\" class=\"card-payment\">\r\n                    <ion-row class=\"content\" (click)=\"onClickAddress(item)\">\r\n                        <ion-col class=\"ion-align-self-center\" size=\"10\">\r\n                            <div class=\"body-l bold headerCard\">{{item.title}}</div>\r\n                            <div class=\"body-sm bodyCard\">{{item.floor}}, {{item.building}}</div>\r\n                            <div class=\"body-sm bodyCard\">{{item.street}}, {{item.city}}</div>\r\n                        </ion-col>\r\n                        <ion-col size=\"2\" class=\"icon-active\" *ngIf=\"addressControl?.value?.userAddressID == item.userAddressID\">\r\n                            <button class=\"btn-create\">\r\n                                <img src=\"../../../../assets/icon/icon-check.svg\">\r\n                            </button>\r\n                        </ion-col>\r\n                        <ion-col size=\"2\" class=\"icon-active\" *ngIf=\"addressControl?.value?.userAddressID != item.userAddressID && listAddress.length > 1\">\r\n                            <button class=\"btn-create\">\r\n                                <i class=\"uil uil-circle radio-button\"></i>\r\n                            </button>\r\n                        </ion-col>\r\n                    </ion-row>\r\n                </ion-grid>\r\n            </ng-container>\r\n            <ng-container *ngSwitchDefault>\r\n                <ion-grid [ngStyle]=\"{'display': (displayBank == false)?'none':'block'}\" *ngFor=\"let item of listBank\" class=\"card-payment\">\r\n                    <ion-row class=\"content\" (click)=\"onClickBankAccount(item)\">\r\n                        <ion-col class=\"ion-align-self-center\" size=\"10\">\r\n                            <div class=\"body-l bold headerCard\">{{item.bankName}}</div>\r\n                            <div class=\"body-sm bodyCard\">{{item.bankAccountNbr}}</div>\r\n                            <div class=\"body-sm bodyCard\">{{item.bankAccountName}}</div>\r\n                        </ion-col>\r\n                        <ion-col size=\"2\" class=\"icon-active\" *ngIf=\"bankControl?.value?.seqId == item.seqId || item.seqId == newBankItem?.seqId\">\r\n                            <button class=\"btn-create\">\r\n                                <img src=\"../../../../assets/icon/icon-check.svg\">\r\n                            </button>\r\n                        </ion-col>\r\n                        <ion-col size=\"2\" class=\"icon-active\" *ngIf=\"bankControl?.value?.seqId != item.seqId && listBank.length > 1 && item.seqId != newBankItem?.seqId\">\r\n                            <button class=\"btn-create\">\r\n                                <i class=\"uil uil-circle radio-button\"></i>\r\n                            </button>\r\n                        </ion-col>\r\n                    </ion-row>\r\n                </ion-grid>\r\n            </ng-container>\r\n        </div>\r\n        <div class=\"create-new\">\r\n            <button *ngIf=\"!disableAddNew\" class=\"btn-create\" [ngSwitch]=\"switchCase\" (click)=\"onClickCreate(switchCase)\">\r\n                <span class=\"text-button body-n bold\">\r\n                    <ng-container *ngSwitchCase=\"'chequeDelivery'\">\r\n                        <div [ngStyle]=\"{'display': (displayCheque == false)?'none':'block'}\" class=\"text-button body-n bold\">\r\n                            <span><i class=\"uil uil-plus-circle icon-create body-n bold\"></i></span>\r\n                            {{ 'paymentMethodClaim.addNewAddress' | translate }}\r\n                        </div>\r\n                    </ng-container>\r\n                    <ng-container *ngSwitchDefault>\r\n                        <div [ngStyle]=\"{'display': (displayBank == false)?'none':'block'}\" class=\"text-button body-n bold\">\r\n                            <span><i class=\"uil uil-plus-circle icon-create body-n bold\"></i></span>\r\n                            {{ 'paymentMethodClaim.addBankAccount' | translate }}\r\n                        </div>\r\n                    </ng-container>\r\n                </span>\r\n            </button>\r\n        </div>\r\n    </div>\r\n</ion-content>\r\n<nextcare-workflow-commands [this]=\"this\" [commands]=\"commands\"></nextcare-workflow-commands>";

/***/ }),

/***/ 73041:
/*!***********************************************************************************************!*\
  !*** ./src/app/pages/new-claim/review-and-submit/review-and-submit.component.html?ngResource ***!
  \***********************************************************************************************/
/***/ ((module) => {

module.exports = "<ion-content class=\"menu-content\">\r\n\t<div class=\"body\">\r\n\t\t<div>\r\n\t\t\t<div class=\"review-text h4 bold\">{{'claimReview.reviewSubmission'| translate}}</div>\r\n\t\t</div>\r\n\r\n\t\t<div class=\"review-detail\" *ngIf=\"displayDisclosure && disclosureInfo\">\r\n\t\t\t<div class=\"review-detail-title\">\r\n\t\t\t\t<span class=\"title-text\">{{'claimReview.disclosureReview'| translate}}</span>\r\n\t\t\t\t<i class=\"icon-edit uil uil-edit\" (click)=\"onNavigateToDisclosure()\"></i>\r\n\t\t\t</div>\r\n\t\t\t<div class=\"border-box\"></div>\r\n\t\t\t<div class=\"review-detail-subtitle\">\r\n\t\t\t\t<span class=\"review-detail-text body-sm\">{{'disclosure.treatmentOfSymptoms'| translate}}</span>\r\n\t\t\t\t<br />\r\n\t\t\t\t<span class=\"review-detail-content body-n bold\">{{disclosureInfo?.treatmentOfSymptoms}}</span>\r\n\t\t\t</div>\r\n\t\t\t<div class=\"review-detail-subtitle\">\r\n\t\t\t\t<span class=\"review-detail-text body-sm\">{{'disclosure.firstOccurrenceDate'| translate}}</span>\r\n\t\t\t\t<br />\r\n\t\t\t\t<span class=\"review-detail-content body-n bold\">{{disclosureInfo?.firstOccurrenceDate | date: 'd MMMM y':'':lang}}</span>\r\n\t\t\t</div>\r\n\t\t\t<div class=\"review-detail-subtitle\">\r\n\t\t\t\t<span class=\"review-detail-text body-sm\">{{'disclosure.treatmentSymtoms'| translate}}</span>\r\n\t\t\t\t<br />\r\n\t\t\t\t<span class=\"review-detail-content body-n bold\">{{(disclosureInfo?.treatmentSymtoms === 'true' ? 'disclosure.agree' : 'disclosure.disagree')| translate }}</span>\r\n\t\t\t</div>\r\n\t\t\t<div *ngIf=\"claimValue.disclosureForm?.treatmentSymtoms == 'true'\" class=\"review-detail-subtitle\">\r\n\t\t\t\t<span class=\"review-detail-text body-sm\">{{'disclosure.dateFirstTreatmentOfSymptoms'| translate}}</span>\r\n\t\t\t\t<br />\r\n\t\t\t\t<span class=\"review-detail-content body-n bold\">{{disclosureInfo?.dateFirstTreatmentOfSymptoms | date: 'd MMMM y':'':lang}}</span>\r\n\t\t\t</div>\r\n\t\t\t<div class=\"review-detail-subtitle\">\r\n\t\t\t\t<span class=\"review-detail-text body-sm\">{{'disclosure.accident'| translate}}</span>\r\n\t\t\t\t<br />\r\n\t\t\t\t<span class=\"review-detail-content body-n bold\">{{(disclosureInfo?.accident === 'true' ? 'disclosure.agree' : 'disclosure.disagree') | translate}}</span>\r\n\t\t\t</div>\r\n\t\t\t<div *ngIf=\"claimValue.disclosureForm?.accident== 'true'\" class=\"review-detail-subtitle\">\r\n\t\t\t\t<span class=\"review-detail-text body-sm\">{{'disclosure.accidentDesc'| translate}}</span>\r\n\t\t\t\t<br />\r\n\t\t\t\t<span class=\"review-detail-content body-n bold\">{{disclosureInfo?.accidentDesc }}</span>\r\n\t\t\t</div>\r\n\t\t</div>\r\n\r\n\t\t<div class=\"review-detail\" *ngIf=\"claimInfo\">\r\n\t\t\t<div class=\"review-detail-title\">\r\n\t\t\t\t<span class=\"title-text\">{{'claimReview.claimDetail'| translate}}</span>\r\n\t\t\t\t<i class=\"icon-edit uil uil-edit\" (click)=\"onNavigateToClaimDetails()\"></i>\r\n\t\t\t</div>\r\n\t\t\t<div class=\"border-box\"></div>\r\n\t\t\t<div class=\"review-detail-subtitle\">\r\n\t\t\t\t<span class=\"review-detail-text body-sm\">{{'claimReview.member'| translate}}</span>\r\n\t\t\t\t<br />\r\n\t\t\t\t<span class=\"review-detail-content body-n bold\">{{claimInfo?.member |replaceMySelf |translate}}</span>\r\n\t\t\t</div>\r\n\t\t\t<div class=\"review-detail-subtitle\">\r\n\t\t\t\t<span class=\"review-detail-text body-sm\">{{'claimDetails.countryOfHealthCareProvider'| translate}}</span>\r\n\t\t\t\t<br />\r\n\t\t\t\t<span class=\"review-detail-content body-n bold\">{{claimInfo?.countryName}}</span>\r\n\t\t\t</div>\r\n\t\t\t<div class=\"review-detail-subtitle\">\r\n\t\t\t\t<span class=\"review-detail-text body-sm\">{{'claimReview.servicetype'| translate}}</span>\r\n\t\t\t\t<br />\r\n\t\t\t\t<span class=\"review-detail-content body-n bold\">{{claimInfo?.treatmentName}}</span>\r\n\t\t\t</div>\r\n\t\t\t<div class=\"review-detail-subtitle\">\r\n\t\t\t\t<span class=\"review-detail-text body-sm\">{{'claimReview.serviceDate'| translate}}</span>\r\n\t\t\t\t<br />\r\n\t\t\t\t<span class=\"review-detail-content body-n bold\">{{claimInfo?.serviceDate | date: 'd MMMM y':'':lang}}</span>\r\n\t\t\t</div>\r\n\t\t\t<div class=\"review-detail-subtitle\">\r\n\t\t\t\t<span class=\"review-detail-text body-sm\">{{'claimReview.amount'| translate}}</span>\r\n\t\t\t\t<br />\r\n\t\t\t\t<span class=\"review-detail-content body-n bold\">{{claimInfo?.claimCurrency}} {{claimInfo?.codeCurrency}}</span>\r\n\t\t\t</div>\r\n\t\t</div>\r\n\r\n\t\t<div class=\"review-detail\" *ngIf=\"documentInfo\">\r\n\t\t\t<div class=\"review-detail-title\">\r\n\t\t\t\t<span class=\"title-text\">{{'claimReview.document'| translate}}</span>\r\n\t\t\t\t<i class=\"icon-edit uil uil-edit\" (click)=\"onNavigateToDocument()\"></i>\r\n\t\t\t</div>\r\n\t\t\t<div class=\"border-box\"></div>\r\n\t\t\t<div class=\"review-detail-subtitle\" *ngFor=\"let item of documentInfo\">\r\n\t\t\t\t<span class=\"document-text body-n bold\">{{item.title |translate}}</span>\r\n\t\t\t\t<br />\r\n\t\t\t\t<div *ngIf=\"item.document?.length>0\">\r\n\t\t\t\t\t<span class=\"document-content body-sm\" *ngFor=\"let document of item.document\">\r\n\t\t\t\t\t\t- {{document.fileName}}\r\n\t\t\t\t\t\t<br />\r\n\t\t\t\t\t</span>\r\n\t\t\t\t</div>\r\n\t\t\t\t<span class=\"no-file body-sm\" *ngIf=\"item.document?.length<1\">{{'uploadDocuments.noDocumentUploaded'| translate}}</span>\r\n\t\t\t</div>\r\n\t\t</div>\r\n\r\n\t\t<div class=\"review-detail\" *ngIf=\"paymentInfo || addressControl\">\r\n\t\t\t<div class=\"review-detail-title\">\r\n\t\t\t\t<span class=\"title-text\">{{'claimReview.paymentMethod'| translate}}</span>\r\n\t\t\t\t<i class=\"icon-edit uil uil-edit\" (click)=\"onNavigateToPayMent()\"></i>\r\n\t\t\t</div>\r\n\t\t\t<div class=\"border-box\"></div>\r\n\t\t\t<div class=\"review-detail-subtitle\" *ngIf=\"paymentInfo\">\r\n\t\t\t\t<span class=\"review-detail-text body-sm\">{{ 'paymentMethodClaim.bankTransfer' | translate }}</span>\r\n\t\t\t\t<br />\r\n\t\t\t\t<span class=\"document-text body-n bold\">{{paymentInfo?.bankName}}</span>\r\n\t\t\t\t<br />\r\n\t\t\t\t<span class=\"document-content body-sm\">\r\n\t\t\t\t\t{{paymentInfo?.bankAccountNbr}}\r\n\t\t\t\t\t<br />\r\n\t\t\t\t\t{{paymentInfo?.bankAccountName}}\r\n\t\t\t\t</span>\r\n\t\t\t</div>\r\n\t\t\t<div class=\"review-detail-subtitle\" *ngIf=\"addressControl\">\r\n\t\t\t\t<span class=\"review-detail-text body-sm\">{{ 'paymentMethodClaim.chequeDelivery' | translate }}</span>\r\n\t\t\t\t<br />\r\n\t\t\t\t<span class=\"document-text body-n bold\">{{addressControl?.title}}</span>\r\n\t\t\t\t<br />\r\n\t\t\t\t<span class=\"document-content body-sm\">\r\n\t\t\t\t\t{{addressControl?.floor}}, {{addressControl?.building}}\r\n\t\t\t\t\t<br />\r\n\t\t\t\t\t{{addressControl?.street}}, {{addressControl?.city}}\r\n\t\t\t\t</span>\r\n\t\t\t</div>\r\n\t\t</div>\r\n\t\t<div class=\"review-detail\" *ngIf=\"displayDeclaration\">\r\n\t\t\t<div class=\"review-detail-title\">\r\n\t\t\t\t<span class=\"title-text\">{{'claimReview.declarationconsent'| translate}}</span>\r\n\t\t\t</div>\r\n\t\t\t<div class=\"review-detail-subtitle\" >\r\n\t\t\t\t<ion-grid>\r\n\t\t\t\t\t<ion-row>\r\n\t\t\t\t\t\t<ion-col size=\"1\">\r\n\t\t\t\t\t\t\t<span>\r\n\t\t\t\t\t\t\t\t<ion-checkbox mode=\"md\" (click)=\"onChecked($event)\" [ngClass]=\"checkedHighlight ? 'testCheckbox': 'testNotCheckbox'\"  formControlName=\"isReadAndAccept\"></ion-checkbox>\r\n\t\t\t\t\t\t\t</span>\r\n\t\t\t\t\t\t</ion-col>\r\n\t\t\t\t\t\t<ion-col size=\"11\">\r\n\t\t\t\t\t\t\t<span class=\"body-sm \">\r\n\t\t\t\t\t\t\t\t{{'claimReview.declarationContent'| translate}}\r\n\t\t\t\t\t\t\t</span>\r\n\t\t\t\t\t\t</ion-col>\r\n\t\t\t\t\t</ion-row>\r\n\t\t\t\t</ion-grid>\r\n\t\t\t</div>\r\n\t\t</div>\t\r\n\t</div>\r\n</ion-content>\r\n<nextcare-workflow-commands [this]=\"this\" [commands]=\"commands\"></nextcare-workflow-commands>\r\n";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_new-claim_new-claim_module_ts.js.map