"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_home_claims-prescription_claims-prescription_module_ts"],{

/***/ 51199:
/*!**************************************************************************************!*\
  !*** ./src/app/pages/home/claims-prescription/claims-prescription-routing.module.ts ***!
  \**************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ClaimsPrescriptionPageRoutingModule": () => (/* binding */ ClaimsPrescriptionPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _claims_prescription_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./claims-prescription.page */ 82967);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);




const routes = [
    {
        path: '',
        component: _claims_prescription_page__WEBPACK_IMPORTED_MODULE_0__.ClaimsPrescriptionPage
    },
];
let ClaimsPrescriptionPageRoutingModule = class ClaimsPrescriptionPageRoutingModule {
};
ClaimsPrescriptionPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], ClaimsPrescriptionPageRoutingModule);



/***/ }),

/***/ 95417:
/*!******************************************************************************!*\
  !*** ./src/app/pages/home/claims-prescription/claims-prescription.module.ts ***!
  \******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ClaimsPrescriptionPageModule": () => (/* binding */ ClaimsPrescriptionPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _claims_prescription_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./claims-prescription.page */ 82967);
/* harmony import */ var _claims_prescription_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./claims-prescription-routing.module */ 51199);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _prescription_content_prescription_content_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./prescription-content/prescription-content.component */ 95930);
/* harmony import */ var _angular_cdk_scrolling__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/cdk/scrolling */ 95752);
/* harmony import */ var src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/shared/shared.module */ 44466);










let ClaimsPrescriptionPageModule = class ClaimsPrescriptionPageModule {
};
ClaimsPrescriptionPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_6__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.IonicModule,
            src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_3__.SharedModule,
            _angular_cdk_scrolling__WEBPACK_IMPORTED_MODULE_9__.ScrollingModule,
            _claims_prescription_routing_module__WEBPACK_IMPORTED_MODULE_1__.ClaimsPrescriptionPageRoutingModule
        ],
        declarations: [
            _claims_prescription_page__WEBPACK_IMPORTED_MODULE_0__.ClaimsPrescriptionPage,
            _prescription_content_prescription_content_component__WEBPACK_IMPORTED_MODULE_2__.PrescriptionContentComponent,
        ]
    })
], ClaimsPrescriptionPageModule);



/***/ }),

/***/ 82967:
/*!****************************************************************************!*\
  !*** ./src/app/pages/home/claims-prescription/claims-prescription.page.ts ***!
  \****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ClaimsPrescriptionPage": () => (/* binding */ ClaimsPrescriptionPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _claims_prescription_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./claims-prescription.page.html?ngResource */ 18181);
/* harmony import */ var _claims_prescription_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./claims-prescription.page.scss?ngResource */ 87651);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var src_app_service_insurance_insurance_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/service/insurance/insurance.service */ 57072);
/* harmony import */ var src_app_service_home_prescription_claims_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/service/home/prescription-claims.service */ 55008);
/* harmony import */ var src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/shared/data/constants */ 74676);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs */ 92218);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! rxjs/operators */ 85921);
/* harmony import */ var src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/shared/data/enum/screen */ 68302);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @ionic/storage-angular */ 80190);
/* harmony import */ var src_app_service_cms_search_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/service/cms/search.service */ 81563);



/* eslint-disable @typescript-eslint/no-unused-vars */












let ClaimsPrescriptionPage = class ClaimsPrescriptionPage {
    constructor(location, insuranceService, claimsService, router, platform, storage, searchService) {
        this.location = location;
        this.insuranceService = insuranceService;
        this.claimsService = claimsService;
        this.router = router;
        this.platform = platform;
        this.storage = storage;
        this.searchService = searchService;
        this.status = src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_4__.Constants.EFERRAL_STATUS;
        this.tab = 'referral';
        this.paging = {
            pageNo: 1,
            pageSize: 5,
            pageCount: null,
        };
        this.unsubscribe$ = new rxjs__WEBPACK_IMPORTED_MODULE_7__.Subject();
    }
    get isOpen() {
        return this.searchService.getIsOpen();
    }
    set isOpen(value) {
        this.searchService.setIsOpen(value);
    }
    ionViewWillEnter() {
        this.unsubscribe$ = new rxjs__WEBPACK_IMPORTED_MODULE_7__.Subject();
        this.getPolicyInformation();
    }
    ionViewWillLeave() {
        this.unsubscribe$.next();
        this.unsubscribe$.complete();
        this.subscription.unsubscribe();
    }
    ionViewDidEnter() {
        this.subscription = this.platform.backButton.subscribeWithPriority(9999, () => (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__awaiter)(this, void 0, void 0, function* () {
            const isClaimsPrescription = yield this.storage.get(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_4__.Constants.OPENNED_CLAIMS_PRESCRIPTION);
            if (this.isOpen == true) {
                this.isOpen = false;
            }
            else {
                if (isClaimsPrescription == true) {
                    yield this.storage.set(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_4__.Constants.OPENNED_CLAIMS_PRESCRIPTION, false);
                    this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_5__.Screens.HomeCare]);
                }
                else {
                    this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_5__.Screens.Home]);
                }
            }
        }));
    }
    onBack() {
        this.location.back();
    }
    getPolicyInformation() {
        this.insuranceService.getPolicyInformation().pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_9__.takeUntil)(this.unsubscribe$)).subscribe((res) => {
            if (!res)
                return;
            this.currentPolicy = res;
            this.getMemberList();
            this.getListFilter();
            this.currentFilter = {
                beneficiaryId: [this.currentPolicy.beneficiaryId]
            };
            this.onSearchChange(this.currentFilter);
        });
    }
    getMemberList() {
        const memberList = this.insuranceService.getMemberListValue();
        this.members = memberList.map((res) => ({
            id: res.beneficiaryId,
            name: res.benefFullName,
        }));
    }
    getListFilter(erxreferenceNbrCondition) {
        if (this.tab === 'referral') {
            this.listFilter = [
                // {
                //   filterName: 'Referral Status',
                //   conditions: this.status,
                //   singleSelections: true,
                //   paramName: 'activeEreferral',
                // },
                {
                    filterName: 'filter.beneficiary',
                    conditions: this.members,
                    required: true,
                    singleSelections: true,
                    paramName: 'beneficiaryId',
                    initValues: [this.currentPolicy.beneficiaryId]
                },
                // {
                //   filterName: 'Referral Number',
                //   conditions: erxreferenceNbrCondition || [],
                //   singleSelections: true,
                //   paramName: 'erxreferenceNbr'
                // },
            ];
        }
        else {
            this.listFilter = [
                {
                    filterName: 'Prescription Status',
                    conditions: this.status,
                    singleSelections: true,
                    paramName: 'activePrescription',
                },
                {
                    filterName: 'filter.beneficiary',
                    conditions: this.members,
                    singleSelections: true,
                    paramName: 'beneficiaryId',
                    initValues: [this.currentPolicy.beneficiaryId]
                },
                {
                    filterName: 'E-Rx Number',
                    conditions: erxreferenceNbrCondition || [],
                    singleSelections: true,
                    paramName: 'erxreferenceNbr'
                },
            ];
        }
    }
    segmentChanged(event) {
        this.tab = event.detail.value;
        this.getListFilter();
        this.onSearchChange(this.currentFilter);
    }
    onSearchChange(model) {
        var _a, _b, _c;
        if (((_a = model === null || model === void 0 ? void 0 : model.keyword) === null || _a === void 0 ? void 0 : _a.length) > 0) {
            model.eReferallNo = model.keyword;
        }
        this.currentFilter = model;
        if (this.tab == 'referral') {
            const searchCondition = Object.assign(Object.assign(Object.assign({}, model), this.paging), { userPolicyId: this.currentPolicy.userPolicyId, beneficiaryId: ((_b = model === null || model === void 0 ? void 0 : model.beneficiaryId) === null || _b === void 0 ? void 0 : _b.length) > 0 && (model === null || model === void 0 ? void 0 : model.beneficiaryId) || this.currentPolicy.beneficiaryId });
            this.claimsService.getEreferral(searchCondition).subscribe((res) => {
                if (res) {
                    this.details = this.details.concat(res.results.map((value) => {
                        const expiryDate = value.expDate;
                        const remainingEreferral = value.remainingEreferral;
                        const member = this.members.find(_ => _.id === value.beneficiaryId);
                        if (expiryDate && new Date().getTime() > new Date(expiryDate).getTime() || ((remainingEreferral - 1) === -1) || remainingEreferral === null) {
                            value.active = false;
                        }
                        else {
                            value.active = true;
                        }
                        return Object.assign({ benefFullName: member.name }, value);
                    }).filter((_) => _).sort((a, b) => new Date(b.expDate).getTime() - new Date(a.expDate).getTime()));
                    const erxreferenceNbrInfo = res.results.map((data) => ({
                        id: data.erxreferenceNbr,
                        name: data.erxreferenceNbr
                    }));
                    const allowedUtilizationFrequency = res.allowedUtilizationFrequency;
                    this.listFilter.find(e => e.paramName === 'erxreferenceNbr').conditions = erxreferenceNbrInfo;
                    this.paging = {
                        pageNo: res.page,
                        pageSize: res.pageSize,
                        pageCount: res.pageCount,
                    };
                }
                else {
                    this.details = [];
                    this.paging = {
                        pageNo: 1,
                        pageSize: 5,
                        pageCount: null,
                    };
                }
                ;
            });
        }
        else {
            this.claimsService.getPrescription(Object.assign(Object.assign(Object.assign({}, model), this.paging), { userPolicyId: this.currentPolicy.userPolicyId, beneficiaryId: ((_c = model === null || model === void 0 ? void 0 : model.beneficiaryId) === null || _c === void 0 ? void 0 : _c.length) > 0 && (model === null || model === void 0 ? void 0 : model.beneficiaryId) || this.currentPolicy.beneficiaryId })).subscribe((res) => {
                if (res) {
                    this.details = res.map((res) => {
                        const expiryDate = res.expiryDate;
                        const remainingEreferral = res.remainingEreferral;
                        if (expiryDate && new Date().getTime() > new Date(expiryDate).getTime() || ((remainingEreferral - 1) === -1) || remainingEreferral === null) {
                            res.active = false;
                        }
                        else {
                            res.active = true;
                        }
                        return res;
                    });
                    const allowedUtilizationFrequency = res.allowedUtilizationFrequency;
                    const erxreferenceNbrInfo = res.map((data) => ({
                        id: data.erxreferenceNbr,
                        name: data.erxreferenceNbr
                    }));
                    this.listFilter.find(e => e.paramName === 'erxreferenceNbr').conditions = erxreferenceNbrInfo;
                    this.paging = {
                        pageNo: res.page,
                        pageSize: res.pageSize,
                        pageCount: res.pageCount,
                    };
                }
                else {
                    this.details = [];
                    this.paging = {
                        pageNo: 1,
                        pageSize: 5,
                        pageCount: null,
                    };
                }
                ;
            });
        }
    }
    logScrolling() {
        this.detectBottom();
    }
    refreshReferralHistory() {
        this.onSearchChange(this.currentFilter);
    }
    detectBottom() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__awaiter)(this, void 0, void 0, function* () {
            const scrollElement = yield this.content.getScrollElement(); // get scroll element
            // calculate if max bottom was reached
            if (scrollElement.scrollTop ===
                scrollElement.scrollHeight - scrollElement.clientHeight - 1) {
                console.info('max bottom was reached!');
                this.paging.pageNo = this.paging.pageNo + 1;
                this.onSearchChange(this.currentFilter);
            }
        });
    }
};
ClaimsPrescriptionPage.ctorParameters = () => [
    { type: _angular_common__WEBPACK_IMPORTED_MODULE_10__.Location },
    { type: src_app_service_insurance_insurance_service__WEBPACK_IMPORTED_MODULE_2__.InsuranceService },
    { type: src_app_service_home_prescription_claims_service__WEBPACK_IMPORTED_MODULE_3__.PrescriptionClaimsService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_11__.Router },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_12__.Platform },
    { type: _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_13__.Storage },
    { type: src_app_service_cms_search_service__WEBPACK_IMPORTED_MODULE_6__.SearchService }
];
ClaimsPrescriptionPage.propDecorators = {
    content: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_14__.ViewChild, args: [_ionic_angular__WEBPACK_IMPORTED_MODULE_12__.IonContent,] }]
};
ClaimsPrescriptionPage = (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_14__.Component)({
        selector: 'app-claims-prescription',
        template: _claims_prescription_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_claims_prescription_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], ClaimsPrescriptionPage);



/***/ }),

/***/ 95930:
/*!*******************************************************************************************************!*\
  !*** ./src/app/pages/home/claims-prescription/prescription-content/prescription-content.component.ts ***!
  \*******************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PrescriptionContentComponent": () => (/* binding */ PrescriptionContentComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _prescription_content_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./prescription-content.component.html?ngResource */ 19638);
/* harmony import */ var _prescription_content_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./prescription-content.component.scss?ngResource */ 89785);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/shared/data/enum/screen */ 68302);
/* harmony import */ var src_app_service_utilities_third_party_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/service/utilities/third-party.service */ 47617);
/* harmony import */ var src_app_service_insurance_insurance_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/service/insurance/insurance.service */ 57072);
/* harmony import */ var src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/shared/data/constants */ 74676);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/shared/data/enum/event */ 38570);
/* harmony import */ var _awesome_cordova_plugins_clevertap_ngx__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @awesome-cordova-plugins/clevertap/ngx */ 45363);
/* harmony import */ var _awesome_cordova_plugins_firebase_analytics_ngx__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @awesome-cordova-plugins/firebase-analytics/ngx */ 48852);



// import { InAppBrowser } from '@awesome-cordova-plugins/in-app-browser/ngx';










// import { environment } from '@environments/environment';
let PrescriptionContentComponent = class PrescriptionContentComponent {
    constructor(router, thirdPartyService, insuranceService, modalCtrl, clevertap, firebaseAnalytics) {
        this.router = router;
        this.thirdPartyService = thirdPartyService;
        this.insuranceService = insuranceService;
        this.modalCtrl = modalCtrl;
        this.clevertap = clevertap;
        this.firebaseAnalytics = firebaseAnalytics;
        this.bookApointmentBtn = false;
        this.orderOnlineBtn = false;
    }
    ngOnChanges() {
    }
    ngOnInit() {
        this.bookApointmentOrderOnline();
    }
    onBookApointment() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__awaiter)(this, void 0, void 0, function* () {
            this.clevertap.recordEventWithName(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_6__.GA4Event.ReferralAppointmentBookingStarted);
            this.firebaseAnalytics.logEvent(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_6__.GA4Event.ReferralAppointmentBookingStarted, {});
            this.thirdPartyService.openBookAppointment();
        });
    }
    onOrderOnline() {
    }
    onViewDetail(item) {
        this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__.Screens.PrescriptionDetails], { queryParams: item });
    }
    trackById(_, detail) {
        return detail.id;
    }
    bookApointmentOrderOnline() {
        this.bookApointmentBtn = this.insuranceService.checkPayerSetting(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_5__.Constants.APPOINTMENT_BOOKING, true);
        // const columnname = this.payerSetting?.find(res => res.columnname === 'MyNCEnableAppointmentBooking');
        // if (columnname && columnname.required === true) {
        //   this.bookApointmentBtn = true;
        // } else {
        //   this.bookApointmentBtn = false;
        // }
        this.orderOnlineBtn = this.insuranceService.checkPayerSetting(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_5__.Constants.ENABLE_DRUG_DELIVERY, true);
        // const columnnameOrder = this.payerSetting?.find(res => res.columnname === 'MyNCDrugDelivery');
        // if (columnnameOrder && columnnameOrder.required === true) {
        //   this.orderOnlineBtn = true;
        // } else {
        //   this.orderOnlineBtn = false;
        // }
    }
};
PrescriptionContentComponent.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_10__.Router },
    { type: src_app_service_utilities_third_party_service__WEBPACK_IMPORTED_MODULE_3__.ThirdPartyService },
    { type: src_app_service_insurance_insurance_service__WEBPACK_IMPORTED_MODULE_4__.InsuranceService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_11__.ModalController },
    { type: _awesome_cordova_plugins_clevertap_ngx__WEBPACK_IMPORTED_MODULE_7__.CleverTap },
    { type: _awesome_cordova_plugins_firebase_analytics_ngx__WEBPACK_IMPORTED_MODULE_8__.FirebaseAnalytics }
];
PrescriptionContentComponent.propDecorators = {
    type: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_12__.Input }],
    details: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_12__.Input }]
};
PrescriptionContentComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_12__.Component)({
        selector: 'app-prescription-content',
        template: _prescription_content_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_prescription_content_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], PrescriptionContentComponent);



/***/ }),

/***/ 55008:
/*!*************************************************************!*\
  !*** ./src/app/service/home/prescription-claims.service.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PrescriptionClaimsService": () => (/* binding */ PrescriptionClaimsService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 28784);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @environments/environment */ 92340);




let PrescriptionClaimsService = class PrescriptionClaimsService {
    constructor(http) {
        this.http = http;
        this.url = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.ApiURL;
    }
    getEreferral(params) {
        return this.http.get(`${this.url}/mds/api/claim/v1.0/ereferral`, {
            params: Object.assign({}, params)
        });
    }
    getPrescription(params) {
        return this.http.get(`${this.url}/mds/api/claim/v1.0/prescriptions`, {
            params: Object.assign({}, params)
        });
    }
};
PrescriptionClaimsService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient }
];
PrescriptionClaimsService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root'
    })
], PrescriptionClaimsService);



/***/ }),

/***/ 87651:
/*!*****************************************************************************************!*\
  !*** ./src/app/pages/home/claims-prescription/claims-prescription.page.scss?ngResource ***!
  \*****************************************************************************************/
/***/ ((module) => {

module.exports = ":root {\n  --nc-color-nextgen-neutral-grey-50: red;\n  --nc-color-nextgen-white: yellow;\n  --nc-color-nextgen-blue: #0d152e;\n  --nc-color-nextgen-green: #00908d;\n  --nc-color-nextgen-black: #000000;\n  --nc-color-nextgen-grey-background: #c8d3da;\n  --nc-color-nextgen-grey: #92a2ac;\n  --nc-color-nextgen-stone-grey: #fafafa;\n  --nc-color-nextgen-error: #fc1055;\n  --nc-color-nextgen-neutral-grey: #414141;\n  --nc-color-nextgen-fibrant-green: #00bab6;\n  --nc-color-nextgen-warning: #ffd048;\n  --nc-color-nextgen-green-background: #e6f2f2;\n  --nc-color-nextgen-neutral-grey-400: #7a7a7a;\n  --nc-color-nextgen-neutral-grey-100: #eff3f5;\n  --nc-color-nextgen-status-error: #ba0c3f;\n  --nc-color-nextgen-status-error-background: #ffeff4;\n  --nc-color-nextgen-status-warning: #cba127;\n  --nc-color-nextgen-status-warning-background: #fff8e6;\n  --nc-color-nextgen-blue-100: #dfeff2;\n  --nc-color-nextgen-error-red-700: #f62459;\n  --nc-color-nextgen-blue-500: #006192;\n  --nc-color-nextgen-blue-400: #79cdec;\n  --nc-color-nextgen-red-500: #ff6592;\n  --nc-color-nextgen-secondary-blue-300: #13a0d3;\n  --lumi-white-color: #ffffff;\n  --lumi-primary-yellow-color: #fab600;\n}\n\n.ion-color-green {\n  --ion-color-base: var(--nc-color-nextgen-green);\n  --ion-color-base-rgb: var(--nc-color-nextgen-green);\n  --ion-color-contrast: var(--nc-color-nextgen-white);\n  --ion-color-contrast-rgb: var(--nc-color-nextgen-green);\n  --ion-color-shade: var(--nc-color-nextgen-green);\n  --ion-color-tint: var(--nc-color-nextgen-green);\n}\n\n/*\n * 1. Custom CSS \n * ----------------------------------------------------------------------------\n */\n\n:root {\n  --nc-color-nextgen-neutral-grey-50: red;\n  --nc-color-nextgen-white: yellow;\n  --nc-color-nextgen-blue: #0d152e;\n  --nc-color-nextgen-green: #00908d;\n  --nc-color-nextgen-black: #000000;\n  --nc-color-nextgen-grey-background: #c8d3da;\n  --nc-color-nextgen-grey: #92a2ac;\n  --nc-color-nextgen-stone-grey: #fafafa;\n  --nc-color-nextgen-error: #fc1055;\n  --nc-color-nextgen-neutral-grey: #414141;\n  --nc-color-nextgen-fibrant-green: #00bab6;\n  --nc-color-nextgen-warning: #ffd048;\n  --nc-color-nextgen-green-background: #e6f2f2;\n  --nc-color-nextgen-neutral-grey-400: #7a7a7a;\n  --nc-color-nextgen-neutral-grey-100: #eff3f5;\n  --nc-color-nextgen-status-error: #ba0c3f;\n  --nc-color-nextgen-status-error-background: #ffeff4;\n  --nc-color-nextgen-status-warning: #cba127;\n  --nc-color-nextgen-status-warning-background: #fff8e6;\n  --nc-color-nextgen-blue-100: #dfeff2;\n  --nc-color-nextgen-error-red-700: #f62459;\n  --nc-color-nextgen-blue-500: #006192;\n  --nc-color-nextgen-blue-400: #79cdec;\n  --nc-color-nextgen-red-500: #ff6592;\n  --nc-color-nextgen-secondary-blue-300: #13a0d3;\n  --lumi-white-color: #ffffff;\n  --lumi-primary-yellow-color: #fab600;\n}\n\n.ion-color-green {\n  --ion-color-base: var(--nc-color-nextgen-green);\n  --ion-color-base-rgb: var(--nc-color-nextgen-green);\n  --ion-color-contrast: var(--nc-color-nextgen-white);\n  --ion-color-contrast-rgb: var(--nc-color-nextgen-green);\n  --ion-color-shade: var(--nc-color-nextgen-green);\n  --ion-color-tint: var(--nc-color-nextgen-green);\n}\n\n.display-xl {\n  font-size: 41px !important;\n  font-weight: 400 !important;\n  line-height: 120% !important;\n}\n\n.display-md {\n  font-size: 36px !important;\n  font-weight: 400 !important;\n  line-height: 120% !important;\n}\n\n.h1 {\n  font-size: 31px !important;\n  font-weight: 400 !important;\n  line-height: 120% !important;\n}\n\n.h2 {\n  font-size: 28px !important;\n  font-weight: 400 !important;\n  line-height: 120% !important;\n}\n\n.h3 {\n  font-size: 25px !important;\n  font-weight: 400 !important;\n  line-height: 120% !important;\n}\n\n.h4 {\n  font-size: 22px !important;\n  font-weight: 400 !important;\n  line-height: 120% !important;\n}\n\n.h5 {\n  font-size: 19px !important;\n  font-weight: 400 !important;\n  line-height: 120% !important;\n}\n\n.h6 {\n  font-size: 17px !important;\n  font-weight: 400 !important;\n  line-height: 120% !important;\n}\n\n.body-l {\n  font-size: 17px !important;\n  font-weight: 400 !important;\n  line-height: 120% !important;\n}\n\n.body-n {\n  font-size: 15px !important;\n  font-weight: 400 !important;\n  line-height: 120% !important;\n}\n\n.body-sm {\n  font-size: 13px !important;\n  font-weight: 400 !important;\n  line-height: 120% !important;\n}\n\n.body-xs {\n  font-size: 12px !important;\n  font-weight: 400 !important;\n  line-height: 120% !important;\n}\n\n.semibold.display-xl {\n  font-weight: 600 !important;\n}\n\n.semibold.display-md {\n  font-weight: 600 !important;\n}\n\n.semibold.h1 {\n  font-weight: 600 !important;\n}\n\n.semibold.h2 {\n  font-weight: 600 !important;\n}\n\n.semibold.h3 {\n  font-weight: 600 !important;\n}\n\n.semibold.h4 {\n  font-weight: 600 !important;\n}\n\n.semibold.h5 {\n  font-weight: 600 !important;\n}\n\n.semibold.h6 {\n  font-weight: 600 !important;\n}\n\n.semibold.body-l {\n  font-weight: 600 !important;\n}\n\n.semibold.body-n {\n  font-weight: 600 !important;\n}\n\n.semibold.body-sm {\n  font-weight: 600 !important;\n}\n\n.semibold.body-xs {\n  font-weight: 600 !important;\n}\n\n.bold.display-xl {\n  font-weight: 700 !important;\n}\n\n.bold.display-md {\n  font-weight: 700 !important;\n}\n\n.bold.h1 {\n  font-weight: 700 !important;\n}\n\n.bold.h2 {\n  font-weight: 700 !important;\n}\n\n.bold.h3 {\n  font-weight: 700 !important;\n}\n\n.bold.h4 {\n  font-weight: 700 !important;\n}\n\n.bold.h5 {\n  font-weight: 700 !important;\n}\n\n.bold.h6 {\n  font-weight: 700 !important;\n}\n\n.bold.body-l {\n  font-weight: 700 !important;\n}\n\n.bold.body-n {\n  font-weight: 700 !important;\n}\n\n.bold.body-sm {\n  font-weight: 700 !important;\n}\n\n.bold.body-xs {\n  font-weight: 700 !important;\n}\n\n@font-face {\n  font-family: \"Allianz Neo\";\n  font-style: normal;\n  font-weight: 300;\n  font-display: swap;\n  src: url('AllianzNeoW04-Light.woff2') format(\"woff2\"), url('AllianzNeoW04-Light.woff') format(\"woff\");\n}\n\n@font-face {\n  font-family: \"Allianz Neo\";\n  font-style: italic;\n  font-weight: 300;\n  font-display: swap;\n  src: url('AllianzNeoW04-LightItalic.woff2') format(\"woff2\"), url('AllianzNeoW04-LightItalic.woff') format(\"woff\");\n}\n\n@font-face {\n  font-family: \"Allianz Neo\";\n  font-style: normal;\n  font-weight: 400;\n  font-display: swap;\n  src: url('AllianzNeoW04-Regular.woff2') format(\"woff2\"), url('AllianzNeoW04-Regular.woff') format(\"woff\");\n}\n\n@font-face {\n  font-family: \"Allianz Neo\";\n  font-style: italic;\n  font-weight: 400;\n  font-display: swap;\n  src: url('AllianzNeoW04-Italic.woff2') format(\"woff2\"), url('AllianzNeoW04-Italic.woff') format(\"woff\");\n}\n\n@font-face {\n  font-family: \"Allianz Neo\";\n  font-style: normal;\n  font-weight: 600;\n  font-display: swap;\n  src: url('AllianzNeoW04-SemiBold.woff2') format(\"woff2\"), url('AllianzNeoW04-SemiBold.woff') format(\"woff\");\n}\n\n@font-face {\n  font-family: \"Allianz Neo\";\n  font-style: italic;\n  font-weight: 600;\n  font-display: swap;\n  src: url('AllianzNeoW04-SemiBoldIt.woff2') format(\"woff2\"), url('AllianzNeoW04-SemiBoldIt.woff') format(\"woff\");\n}\n\n@font-face {\n  font-family: \"Allianz Neo\";\n  font-style: normal;\n  font-weight: 700;\n  font-display: swap;\n  src: url('AllianzNeoW04-Bold.woff2') format(\"woff2\"), url('AllianzNeoW04-Bold.woff') format(\"woff\");\n}\n\n@font-face {\n  font-family: \"Allianz Neo\";\n  font-style: italic;\n  font-weight: 700;\n  font-display: swap;\n  src: url('AllianzNeoW04-BoldItalic.woff2') format(\"woff2\"), url('AllianzNeoW04-BoldItalic.woff') format(\"woff\");\n}\n\n* {\n  color: var(--nc-color-nextgen-neutral-grey);\n  font-family: \"Allianz Neo\", sans-serif;\n  font-weight: 400;\n  font-size: 16px;\n}\n\nhtml {\n  --ion-safe-area-top: 0px;\n}\n\n.col-1 {\n  width: 8.33%;\n}\n\n.col-2 {\n  width: 16.66%;\n}\n\n.col-3 {\n  width: 25%;\n}\n\n.col-4 {\n  width: 33.33%;\n}\n\n.col-5 {\n  width: 41.66%;\n}\n\n.col-6 {\n  width: 50%;\n}\n\n.col-7 {\n  width: 58.33%;\n}\n\n.col-8 {\n  width: 66.66%;\n}\n\n.col-9 {\n  width: 75%;\n}\n\n.col-10 {\n  width: 83.33%;\n}\n\n.col-11 {\n  width: 91.66%;\n}\n\n.col-12 {\n  width: 100%;\n}\n\n@media only screen and (max-width: 576px) {\n  /* For tablets: */\n  .col-sm-1 {\n    width: 8.33%;\n  }\n\n  .col-sm-2 {\n    width: 16.66%;\n  }\n\n  .col-sm-3 {\n    width: 25%;\n  }\n\n  .col-sm-4 {\n    width: 33.33%;\n  }\n\n  .col-sm-5 {\n    width: 41.66%;\n  }\n\n  .col-sm-6 {\n    width: 50%;\n  }\n\n  .col-sm-7 {\n    width: 58.33%;\n  }\n\n  .col-sm-8 {\n    width: 66.66%;\n  }\n\n  .col-sm-9 {\n    width: 75%;\n  }\n\n  .col-sm-10 {\n    width: 83.33%;\n  }\n\n  .col-sm-11 {\n    width: 91.66%;\n  }\n\n  .col-sm-12 {\n    width: 100%;\n  }\n}\n\n@media only screen and (max-width: 768px) and (min-width: 577px) {\n  /* For tablets: */\n  .col-md-1 {\n    width: 8.33%;\n  }\n\n  .col-md-2 {\n    width: 16.66%;\n  }\n\n  .col-md-3 {\n    width: 25%;\n  }\n\n  .col-md-4 {\n    width: 33.33%;\n  }\n\n  .col-md-5 {\n    width: 41.66%;\n  }\n\n  .col-md-6 {\n    width: 50%;\n  }\n\n  .col-md-7 {\n    width: 58.33%;\n  }\n\n  .col-md-8 {\n    width: 66.66%;\n  }\n\n  .col-md-9 {\n    width: 75%;\n  }\n\n  .col-md-10 {\n    width: 83.33%;\n  }\n\n  .col-md-11 {\n    width: 91.66%;\n  }\n\n  .col-md-12 {\n    width: 100%;\n  }\n}\n\n@media only screen and (min-width: 769px) {\n  /* For tablets: */\n  .col-lg-1 {\n    width: 8.33%;\n  }\n\n  .col-lg-2 {\n    width: 16.66%;\n  }\n\n  .col-lg-3 {\n    width: 25%;\n  }\n\n  .col-lg-4 {\n    width: 33.33%;\n  }\n\n  .col-lg-5 {\n    width: 41.66%;\n  }\n\n  .col-lg-6 {\n    width: 50%;\n  }\n\n  .col-lg-7 {\n    width: 58.33%;\n  }\n\n  .col-lg-8 {\n    width: 66.66%;\n  }\n\n  .col-lg-9 {\n    width: 75%;\n  }\n\n  .col-lg-10 {\n    width: 83.33%;\n  }\n\n  .col-lg-11 {\n    width: 91.66%;\n  }\n\n  .col-lg-12 {\n    width: 100%;\n  }\n}\n\n.row {\n  display: flex;\n  justify-content: center;\n  align-items: center;\n}\n\n.custom-toast {\n  --max-width: fit-content;\n}\n\n/*\n * 2. Custom CSS for compatibility with Edge\n * ----------------------------------------------------------------------------\n */\n\ninput::-ms-reveal,\ninput::-ms-clear {\n  display: none;\n}\n\n.swal2-popup {\n  margin-top: 20px;\n}\n\n/*\n * 3. Custom CSS for loading controller\n * ----------------------------------------------------------------------------\n */\n\n.transparent-loading-class {\n  --background: transparent;\n  --spinner-color: #47e6b1;\n}\n\n.loading-wrapper.sc-ion-loading-md {\n  box-shadow: unset;\n  -webkit-box-shadow: unset;\n}\n\n.uil {\n  color: var(--nc-color-nextgen-grey);\n}\n\n.btn {\n  height: 48px;\n  border-radius: 28px;\n  padding: 0px 41px 0px 41px;\n  box-shadow: none;\n}\n\n.btn.btn-circle {\n  background-color: var(--nc-color-nextgen-stone-grey) !important;\n  color: var(--nc-color-nextgen-black);\n  padding: unset !important;\n  height: 36px !important;\n  width: 36px !important;\n  border-radius: 50% !important;\n}\n\n.btn.btn-circle i {\n  color: var(--nc-color-nextgen-black);\n}\n\n.btn.primary {\n  background: var(--nc-color-nextgen-green);\n  color: var(--nc-color-nextgen-white);\n}\n\n.btn.primary .uil {\n  color: var(--nc-color-nextgen-white);\n}\n\n.btn.primary:disabled {\n  background-color: var(--nc-color-nextgen-grey-background) !important;\n  color: var(--nc-color-nextgen-grey) !important;\n}\n\n.btn.secondary {\n  background: var(--nc-color-nextgen-white) !important;\n  border-color: var(--nc-color-nextgen-green);\n  border: solid 1px;\n  color: var(--nc-color-nextgen-green);\n}\n\n.btn.secondary .uil {\n  color: var(--nc-color-nextgen-green);\n}\n\n.btn.secondary:disabled {\n  background-color: var(--nc-color-nextgen-white) !important;\n  color: var(--nc-color-nextgen-grey) !important;\n  border-color: var(--nc-color-nextgen-grey-background) !important;\n}\n\n.btn.transparent {\n  background: transparent !important;\n  border-color: var(--nc-color-nextgen-green);\n  border: solid 1px;\n  color: var(--nc-color-nextgen-green);\n}\n\n.btn.transparent .uil {\n  color: var(--nc-color-nextgen-green);\n}\n\n.btn.transparent:disabled {\n  background-color: transparent !important;\n  color: var(--nc-color-nextgen-grey) !important;\n  border-color: var(--nc-color-nextgen-grey-background) !important;\n}\n\n.btn.btn-large {\n  height: 56px !important;\n  width: 100%;\n}\n\n.btn.bold {\n  font-weight: 700 !important;\n}\n\n.btn.semibold {\n  font-weight: 600 !important;\n}\n\n.btn-no-space {\n  padding: 5px !important;\n  height: -moz-fit-content;\n  height: fit-content;\n}\n\n.btn-back {\n  width: 31px;\n  height: 28px;\n  background-color: transparent;\n  padding: 0;\n  color: var(--nc-color-nextgen-green);\n}\n\n.container {\n  padding: 2rem;\n  height: 100%;\n}\n\n.body-section {\n  width: 100%;\n  height: 95%;\n  overflow-y: auto;\n  position: relative;\n}\n\n.top-section {\n  width: 100%;\n  height: 10%;\n  justify-content: space-between;\n  display: flex;\n  align-items: center;\n}\n\n.form-control {\n  position: relative;\n  height: 85px;\n  margin-bottom: 8px;\n}\n\n.control {\n  border-radius: 8px;\n  height: 56px;\n  border: 1px solid var(--nc-color-nextgen-grey-background);\n  width: 100%;\n  position: absolute;\n  top: 32px;\n  background-color: var(--nc-color-nextgen-white);\n}\n\n.control table {\n  table-layout: fixed;\n  border-collapse: unset;\n}\n\n.control input {\n  height: 54px;\n  border: unset;\n  border-radius: 8px;\n  width: max-content;\n  width: 100%;\n  pointer-events: auto;\n  background-color: var(--nc-color-nextgen-white);\n}\n\n.control.textarea {\n  height: 108px;\n}\n\n.control textarea {\n  height: 106px;\n  border: unset;\n  border-radius: 8px;\n  width: max-content;\n  width: 100%;\n  pointer-events: auto;\n  resize: none;\n  background-color: var(--nc-color-nextgen-white);\n}\n\n.control input:focus {\n  outline: none;\n}\n\n.control:focus-within {\n  border-color: var(--nc-color-nextgen-green);\n}\n\n.control:focus-within .first-icon {\n  display: none;\n}\n\n.control:focus-within .first-icon.non-hidden {\n  display: table-cell;\n}\n\n.control .first-icon {\n  width: 32px;\n  text-align: center;\n  padding-left: 8px;\n}\n\n.control .first-icon i {\n  font-size: 24px !important;\n}\n\n.control .second-icon {\n  width: 32px;\n  text-align: center;\n}\n\n.control .second-icon i {\n  font-size: 24px !important;\n}\n\n.control:focus-within ~ div .control-label {\n  color: var(--nc-color-nextgen-green);\n}\n\n.control-error .control {\n  border-color: var(--nc-color-nextgen-error);\n}\n\n.control-error .control-label {\n  color: var(--nc-color-nextgen-error) !important;\n}\n\n.validation-summary li {\n  color: var(--nc-color-nextgen-error) !important;\n  list-style: none;\n}\n\n.validation-summary li i {\n  color: var(--nc-color-nextgen-error) !important;\n}\n\n.mr-1 {\n  margin-right: 0.5rem;\n}\n\n.mb-1 {\n  margin-bottom: 0.5rem;\n}\n\n.dialog-pane {\n  position: absolute;\n  pointer-events: auto;\n  box-sizing: border-box;\n  z-index: 1000;\n  display: block;\n  max-width: 100%;\n  max-height: 100%;\n}\n\n.overlay-backdrop {\n  background-color: var(--nc-color-nextgen-neutral-grey);\n  opacity: 0.2 !important;\n}\n\n.dialog-container {\n  animation: fadeIn 0.5s linear;\n  background-color: var(--nc-color-nextgen-white);\n}\n\n@keyframes fadeIn {\n  from {\n    transform: translateY(100%);\n  }\n  to {\n    transform: translateY(0%);\n  }\n}\n\n.error {\n  color: var(--nc-color-nextgen-error);\n}\n\n.error.background {\n  background-color: var(--nc-color-nextgen-error);\n}\n\n.success {\n  color: var(--nc-color-nextgen-fibrant-green);\n}\n\n.success.background {\n  background-color: var(--nc-color-nextgen-fibrant-green);\n}\n\n.warning {\n  color: var(--nc-color-nextgen-warning);\n}\n\n.warning.background {\n  background-color: var(--nc-color-nextgen-warning);\n}\n\n.select {\n  width: 100%;\n  height: 54px;\n  border: unset;\n  border-radius: 8px;\n  display: grid;\n  -webkit-appearance: none;\n          appearance: none;\n  grid-template-areas: \"select\";\n}\n\n.select:focus {\n  outline: unset;\n}\n\n.color-black {\n  color: var(--nc-color-nextgen-black);\n}\n\n.modal-default {\n  --width: 100%;\n  --height: 100%;\n}\n\n.integration-panel {\n  width: 100%;\n  height: 100%;\n  max-width: 100% !important;\n}\n\n.verloop-button {\n  visibility: hidden;\n}\n\n.back-area {\n  position: fixed;\n  top: 0;\n  right: 0;\n  height: 50px;\n  width: 100%;\n  background-color: var(--nc-color-nextgen-neutral-grey-50);\n  z-index: 9999999;\n}\n\n.back-area.ios {\n  height: 80px;\n}\n\n.title-widget {\n  text-align: center;\n  position: sticky;\n  top: 48px;\n}\n\n.button-back {\n  background-color: #fafafa;\n  height: 36px;\n  width: 36px;\n  border-radius: 50%;\n  position: absolute;\n  left: 18px;\n  bottom: 4px;\n}\n\n.icon-close-widget {\n  position: absolute;\n  z-index: 250;\n  left: 11px;\n  bottom: 13px;\n}\n\n.data-default {\n  position: absolute;\n  top: 50%;\n  left: 50%;\n  transform: translate(-50%, -50%);\n  text-align: center;\n  color: var(--nc-color-nextgen-neutral-grey-400);\n  z-index: 1000;\n}\n\n.avaamo__icon {\n  visibility: hidden !important;\n}\n\n.avaamo__chat__widget.ios #avaamo__popup {\n  padding-top: 40px;\n}\n\n.d-flex {\n  display: flex;\n}\n\nnextcare-layout {\n  left: 0;\n  right: 0;\n  top: 0;\n  bottom: 0;\n  display: flex;\n  position: absolute;\n  flex-direction: column;\n  justify-content: space-between;\n  contain: layout size style;\n  overflow: hidden;\n  background-color: var(--nc-color-nextgen-neutral-grey-50);\n  padding-right: 24px;\n  padding-left: 24px;\n}\n\nion-header.ios.header-ios {\n  margin-top: 40px;\n}\n\n.header-ios ion-toolbar:last-of-type {\n  --border-width: 0px !important;\n}\n\n.header-md.md::after {\n  display: none;\n}\n\nion-toolbar {\n  padding-right: unset !important;\n  padding-left: unset !important;\n}\n\ni.icon-back {\n  content: url('long-arrow-left-icon.svg');\n}\n\n.verloop-widget.ios .verloop-container.visible {\n  height: calc(100% - 40px);\n  top: 40px;\n}\n\n#nextcare-ads {\n  display: none;\n  overflow: scroll;\n  height: 180px;\n}\n\n.d-block {\n  display: block;\n}\n\n.title-text {\n  color: var(--nc-color-nextgen-blue);\n}\n\n:host ion-datetime #shadow-root .datetime-calendar .calendar-header .calendar-action-buttons .calendar-month-year {\n  align-items: center;\n  justify-content: center;\n  display: flex;\n  width: 100%;\n}\n\n:host ion-datetime #shadow-root .datetime-calendar .calendar-header .calendar-action-buttons .calendar-month-year ion-icon {\n  display: none;\n}\n\n:host ion-datetime #shadow-root .datetime-calendar .calendar-header .calendar-action-buttons .calendar-next-prev {\n  position: absolute;\n  width: 100%;\n  right: 0;\n}\n\n:host ion-datetime #shadow-root .datetime-calendar .calendar-header .calendar-action-buttons .calendar-next-prev ion-buttons {\n  display: flex;\n  justify-content: space-between;\n  width: 100%;\n}\n\n.mat-dialog-container {\n  padding: unset !important;\n}\n\n/* Change autocomplete styles in WebKit */\n\ninput:-webkit-autofill,\ninput:-webkit-autofill:hover,\ninput:-webkit-autofill:focus,\ntextarea:-webkit-autofill,\ntextarea:-webkit-autofill:hover,\ntextarea:-webkit-autofill:focus,\nselect:-webkit-autofill,\nselect:-webkit-autofill:hover,\nselect:-webkit-autofill:focus {\n  -webkit-text-fill-color: black;\n  -webkit-box-shadow: 0 0 0px 1000px white inset;\n  -webkit-transition: background-color 5000s ease-in-out 0s;\n  transition: background-color 5000s ease-in-out 0s;\n}\n\n.force-update-popup + .cdk-global-overlay-wrapper .save-btn {\n  background: var(--lumi-primary-yellow-color) !important;\n  color: var(--lumi-white-color) !important;\n  font-weight: bold !important;\n}\n\n.force-update-popup + .cdk-global-overlay-wrapper .cancel-btn {\n  color: var(--lumi-primary-yellow-color) !important;\n}\n\n@keyframes slideInRight {\n  0% {\n    transform: translate3d(100%, 0, 0);\n    visibility: visible;\n  }\n  to {\n    transform: translateZ(0);\n  }\n}\n\n.animate__slideInRight {\n  animation-name: slideInRight;\n}\n\n.animate__animated {\n  animation-duration: 0.5s;\n  animation-duration: 0.5s;\n  animation-fill-mode: both;\n}\n\n.prescription-container {\n  background: var(--nc-color-nextgen-neutral-grey-50);\n  --width: 100%;\n  --height: 100%;\n  padding-bottom: 9vh;\n}\n\n.top-prescription {\n  width: 100%;\n  height: 10%;\n  justify-content: space-between;\n  display: flex;\n  align-items: center;\n}\n\n.title-text {\n  color: var(--nc-color-nextgen-blue) !important;\n}\n\n.icon-question {\n  font-size: 2rem !important;\n  color: var(--nc-color-nextgen-neutral-grey);\n}\n\n.segment {\n  width: 100%;\n  height: 3rem;\n  background: var(--nc-color-nextgen-grey-background);\n}\n\n.segment .segment-button {\n  --indicator-color: #00908d;\n  --color-checked: #ffffff;\n}\n\n.segment .segment-button.segment-button-checked ion-label {\n  color: #ffffff;\n  font-weight: 700 !important;\n}\n\n.claim-title {\n  margin: 5% 0;\n}\n\n.claim-title span {\n  color: var(--nc-color-nextgen-blue) !important;\n}\n\n.inputSearch {\n  margin: 2rem 0 2rem 0;\n}\n\nion-content {\n  --background: $color-nextgen-neutral-grey-50;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFxjb2xvci5zY3NzIiwiY2xhaW1zLXByZXNjcmlwdGlvbi5wYWdlLnNjc3MiLCIuLlxcLi5cXC4uXFwuLlxcc3R5bGUuc2NzcyIsIi4uXFwuLlxcLi5cXC4uXFxmb250LXNpemUuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNDLHVDQUFBO0VBQ0EsZ0NBQUE7RUFDQSxnQ0FBQTtFQUNBLGlDQUFBO0VBQ0EsaUNBQUE7RUFDQSwyQ0FBQTtFQUNBLGdDQUFBO0VBQ0Esc0NBQUE7RUFDQSxpQ0FBQTtFQUNBLHdDQUFBO0VBQ0EseUNBQUE7RUFDQSxtQ0FBQTtFQUNBLDRDQUFBO0VBQ0EsNENBQUE7RUFDQSw0Q0FBQTtFQUNBLHdDQUFBO0VBQ0EsbURBQUE7RUFDQSwwQ0FBQTtFQUNBLHFEQUFBO0VBQ0Esb0NBQUE7RUFDQSx5Q0FBQTtFQUNBLG9DQUFBO0VBQ0Esb0NBQUE7RUFDQSxtQ0FBQTtFQUNBLDhDQUFBO0VBRUEsMkJBQUE7RUFDQSxvQ0FBQTtBQ0FEOztBRGdDQTtFQUNDLCtDQUFBO0VBQ0EsbURBQUE7RUFDQSxtREFBQTtFQUNBLHVEQUFBO0VBQ0EsZ0RBQUE7RUFDQSwrQ0FBQTtBQzdCRDs7QUNyQ0E7OztFQUFBOztBRkFBO0VBQ0MsdUNBQUE7RUFDQSxnQ0FBQTtFQUNBLGdDQUFBO0VBQ0EsaUNBQUE7RUFDQSxpQ0FBQTtFQUNBLDJDQUFBO0VBQ0EsZ0NBQUE7RUFDQSxzQ0FBQTtFQUNBLGlDQUFBO0VBQ0Esd0NBQUE7RUFDQSx5Q0FBQTtFQUNBLG1DQUFBO0VBQ0EsNENBQUE7RUFDQSw0Q0FBQTtFQUNBLDRDQUFBO0VBQ0Esd0NBQUE7RUFDQSxtREFBQTtFQUNBLDBDQUFBO0VBQ0EscURBQUE7RUFDQSxvQ0FBQTtFQUNBLHlDQUFBO0VBQ0Esb0NBQUE7RUFDQSxvQ0FBQTtFQUNBLG1DQUFBO0VBQ0EsOENBQUE7RUFFQSwyQkFBQTtFQUNBLG9DQUFBO0FDMkNEOztBRFhBO0VBQ0MsK0NBQUE7RUFDQSxtREFBQTtFQUNBLG1EQUFBO0VBQ0EsdURBQUE7RUFDQSxnREFBQTtFQUNBLCtDQUFBO0FDY0Q7O0FFaEZBO0VBQ0ksMEJBQUE7RUFDQSwyQkFBQTtFQUNBLDRCQUFBO0FGbUZKOztBRWhGQTtFQUNJLDBCQUFBO0VBQ0EsMkJBQUE7RUFDQSw0QkFBQTtBRm1GSjs7QUVoRkE7RUFDSSwwQkFBQTtFQUNBLDJCQUFBO0VBQ0EsNEJBQUE7QUZtRko7O0FFaEZBO0VBQ0ksMEJBQUE7RUFDQSwyQkFBQTtFQUNBLDRCQUFBO0FGbUZKOztBRWhGQTtFQUNJLDBCQUFBO0VBQ0EsMkJBQUE7RUFDQSw0QkFBQTtBRm1GSjs7QUVoRkE7RUFDSSwwQkFBQTtFQUNBLDJCQUFBO0VBQ0EsNEJBQUE7QUZtRko7O0FFaEZBO0VBQ0ksMEJBQUE7RUFDQSwyQkFBQTtFQUNBLDRCQUFBO0FGbUZKOztBRWhGQTtFQUNJLDBCQUFBO0VBQ0EsMkJBQUE7RUFDQSw0QkFBQTtBRm1GSjs7QUVoRkE7RUFDSSwwQkFBQTtFQUNBLDJCQUFBO0VBQ0EsNEJBQUE7QUZtRko7O0FFaEZBO0VBQ0ksMEJBQUE7RUFDQSwyQkFBQTtFQUNBLDRCQUFBO0FGbUZKOztBRWhGQTtFQUNJLDBCQUFBO0VBQ0EsMkJBQUE7RUFDQSw0QkFBQTtBRm1GSjs7QUVoRkE7RUFDSSwwQkFBQTtFQUNBLDJCQUFBO0VBQ0EsNEJBQUE7QUZtRko7O0FFL0VJO0VBQ0ksMkJBQUE7QUZrRlI7O0FFaEZJO0VBQ0ksMkJBQUE7QUZrRlI7O0FFaEZJO0VBQ0ksMkJBQUE7QUZrRlI7O0FFaEZJO0VBQ0ksMkJBQUE7QUZrRlI7O0FFaEZJO0VBQ0ksMkJBQUE7QUZrRlI7O0FFaEZJO0VBQ0ksMkJBQUE7QUZrRlI7O0FFaEZJO0VBQ0ksMkJBQUE7QUZrRlI7O0FFaEZJO0VBQ0ksMkJBQUE7QUZrRlI7O0FFaEZJO0VBQ0ksMkJBQUE7QUZrRlI7O0FFaEZJO0VBQ0ksMkJBQUE7QUZrRlI7O0FFaEZJO0VBQ0ksMkJBQUE7QUZrRlI7O0FFaEZJO0VBQ0ksMkJBQUE7QUZrRlI7O0FFN0VJO0VBQ0ksMkJBQUE7QUZnRlI7O0FFOUVJO0VBQ0ksMkJBQUE7QUZnRlI7O0FFOUVJO0VBQ0ksMkJBQUE7QUZnRlI7O0FFOUVJO0VBQ0ksMkJBQUE7QUZnRlI7O0FFOUVJO0VBQ0ksMkJBQUE7QUZnRlI7O0FFOUVJO0VBQ0ksMkJBQUE7QUZnRlI7O0FFOUVJO0VBQ0ksMkJBQUE7QUZnRlI7O0FFOUVJO0VBQ0ksMkJBQUE7QUZnRlI7O0FFOUVJO0VBQ0ksMkJBQUE7QUZnRlI7O0FFOUVJO0VBQ0ksMkJBQUE7QUZnRlI7O0FFOUVJO0VBQ0ksMkJBQUE7QUZnRlI7O0FFOUVJO0VBQ0ksMkJBQUE7QUZnRlI7O0FDdk5BO0VBQ0MsMEJBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0Esa0JBQUE7RUFDQSxxR0FBQTtBRDBORDs7QUNwTkE7RUFDQywwQkFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrQkFBQTtFQUNBLGlIQUFBO0FEc05EOztBQ2hOQTtFQUNDLDBCQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtFQUNBLGtCQUFBO0VBQ0EseUdBQUE7QURrTkQ7O0FDNU1BO0VBQ0MsMEJBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0Esa0JBQUE7RUFDQSx1R0FBQTtBRDhNRDs7QUN4TUE7RUFDQywwQkFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrQkFBQTtFQUNBLDJHQUFBO0FEME1EOztBQ3BNQTtFQUNDLDBCQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtFQUNBLGtCQUFBO0VBQ0EsK0dBQUE7QURzTUQ7O0FDaE1BO0VBQ0MsMEJBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0Esa0JBQUE7RUFDQSxtR0FBQTtBRGtNRDs7QUM1TEE7RUFDQywwQkFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrQkFBQTtFQUNBLCtHQUFBO0FEOExEOztBQ3hMQTtFQUNDLDJDRjlENEI7RUUrRDVCLHNDQUFBO0VBQ0EsZ0JBQUE7RUFDQSxlQUFBO0FEMExEOztBQ3ZMQTtFQUNDLHdCQUFBO0FEMExEOztBQ3ZMQTtFQUNDLFlBQUE7QUQwTEQ7O0FDdkxBO0VBQ0MsYUFBQTtBRDBMRDs7QUN2TEE7RUFDQyxVQUFBO0FEMExEOztBQ3ZMQTtFQUNDLGFBQUE7QUQwTEQ7O0FDdkxBO0VBQ0MsYUFBQTtBRDBMRDs7QUN2TEE7RUFDQyxVQUFBO0FEMExEOztBQ3ZMQTtFQUNDLGFBQUE7QUQwTEQ7O0FDdkxBO0VBQ0MsYUFBQTtBRDBMRDs7QUN2TEE7RUFDQyxVQUFBO0FEMExEOztBQ3ZMQTtFQUNDLGFBQUE7QUQwTEQ7O0FDdkxBO0VBQ0MsYUFBQTtBRDBMRDs7QUN2TEE7RUFDQyxXQUFBO0FEMExEOztBQ3ZMQTtFQUNDLGlCQUFBO0VBQ0E7SUFDQyxZQUFBO0VEMExBOztFQ3ZMRDtJQUNDLGFBQUE7RUQwTEE7O0VDdkxEO0lBQ0MsVUFBQTtFRDBMQTs7RUN2TEQ7SUFDQyxhQUFBO0VEMExBOztFQ3ZMRDtJQUNDLGFBQUE7RUQwTEE7O0VDdkxEO0lBQ0MsVUFBQTtFRDBMQTs7RUN2TEQ7SUFDQyxhQUFBO0VEMExBOztFQ3ZMRDtJQUNDLGFBQUE7RUQwTEE7O0VDdkxEO0lBQ0MsVUFBQTtFRDBMQTs7RUN2TEQ7SUFDQyxhQUFBO0VEMExBOztFQ3ZMRDtJQUNDLGFBQUE7RUQwTEE7O0VDdkxEO0lBQ0MsV0FBQTtFRDBMQTtBQUNGOztBQ3ZMQTtFQUNDLGlCQUFBO0VBQ0E7SUFDQyxZQUFBO0VEeUxBOztFQ3RMRDtJQUNDLGFBQUE7RUR5TEE7O0VDdExEO0lBQ0MsVUFBQTtFRHlMQTs7RUN0TEQ7SUFDQyxhQUFBO0VEeUxBOztFQ3RMRDtJQUNDLGFBQUE7RUR5TEE7O0VDdExEO0lBQ0MsVUFBQTtFRHlMQTs7RUN0TEQ7SUFDQyxhQUFBO0VEeUxBOztFQ3RMRDtJQUNDLGFBQUE7RUR5TEE7O0VDdExEO0lBQ0MsVUFBQTtFRHlMQTs7RUN0TEQ7SUFDQyxhQUFBO0VEeUxBOztFQ3RMRDtJQUNDLGFBQUE7RUR5TEE7O0VDdExEO0lBQ0MsV0FBQTtFRHlMQTtBQUNGOztBQ3RMQTtFQUNDLGlCQUFBO0VBQ0E7SUFDQyxZQUFBO0VEd0xBOztFQ3JMRDtJQUNDLGFBQUE7RUR3TEE7O0VDckxEO0lBQ0MsVUFBQTtFRHdMQTs7RUNyTEQ7SUFDQyxhQUFBO0VEd0xBOztFQ3JMRDtJQUNDLGFBQUE7RUR3TEE7O0VDckxEO0lBQ0MsVUFBQTtFRHdMQTs7RUNyTEQ7SUFDQyxhQUFBO0VEd0xBOztFQ3JMRDtJQUNDLGFBQUE7RUR3TEE7O0VDckxEO0lBQ0MsVUFBQTtFRHdMQTs7RUNyTEQ7SUFDQyxhQUFBO0VEd0xBOztFQ3JMRDtJQUNDLGFBQUE7RUR3TEE7O0VDckxEO0lBQ0MsV0FBQTtFRHdMQTtBQUNGOztBQ3JMQTtFQUNDLGFBQUE7RUFDQSx1QkFBQTtFQUNBLG1CQUFBO0FEdUxEOztBQ25MQTtFQUNDLHdCQUFBO0FEc0xEOztBQ25MQTs7O0VBQUE7O0FBSUE7O0VBRUMsYUFBQTtBRHNMRDs7QUNuTEE7RUFDQyxnQkFBQTtBRHNMRDs7QUNuTEE7OztFQUFBOztBQUlBO0VBQ0MseUJBQUE7RUFDQSx3QkFBQTtBRHNMRDs7QUNuTEE7RUFDQyxpQkFBQTtFQUNBLHlCQUFBO0FEc0xEOztBQ25MQTtFQUNDLG1DRjNUb0I7QUNpZnJCOztBQ25MQTtFQUNDLFlBQUE7RUFDQSxtQkFBQTtFQUNBLDBCQUFBO0VBQ0EsZ0JBQUE7QURzTEQ7O0FDcExDO0VBQ0MsK0RBQUE7RUFDQSxvQ0Z4VW9CO0VFeVVwQix5QkFBQTtFQUNBLHVCQUFBO0VBQ0Esc0JBQUE7RUFDQSw2QkFBQTtBRHNMRjs7QUNwTEU7RUFDQyxvQ0YvVW1CO0FDcWdCdEI7O0FDbExDO0VBQ0MseUNGdFZvQjtFRXVWcEIsb0NGdFZvQjtBQzBnQnRCOztBQ2xMRTtFQUNDLG9DRnpWbUI7QUM2Z0J0Qjs7QUNqTEU7RUFDQyxvRUFBQTtFQUNBLDhDQUFBO0FEbUxIOztBQy9LQztFQUNDLG9EQUFBO0VBQ0EsMkNGcldvQjtFRXNXcEIsaUJBQUE7RUFDQSxvQ0Z2V29CO0FDd2hCdEI7O0FDL0tFO0VBQ0Msb0NGMVdtQjtBQzJoQnRCOztBQzlLRTtFQUNDLDBEQUFBO0VBQ0EsOENBQUE7RUFDQSxnRUFBQTtBRGdMSDs7QUM1S0M7RUFDQyxrQ0FBQTtFQUNBLDJDRnRYb0I7RUV1WHBCLGlCQUFBO0VBQ0Esb0NGeFhvQjtBQ3NpQnRCOztBQzVLRTtFQUNDLG9DRjNYbUI7QUN5aUJ0Qjs7QUMzS0U7RUFDQyx3Q0FBQTtFQUNBLDhDQUFBO0VBQ0EsZ0VBQUE7QUQ2S0g7O0FDektDO0VBQ0MsdUJBQUE7RUFDQSxXQUFBO0FEMktGOztBQ3hLQztFQUNDLDJCQUFBO0FEMEtGOztBQ3ZLQztFQUNDLDJCQUFBO0FEeUtGOztBQ3JLQTtFQUNDLHVCQUFBO0VBQ0Esd0JBQUE7RUFBQSxtQkFBQTtBRHdLRDs7QUNyS0E7RUFDQyxXQUFBO0VBQ0EsWUFBQTtFQUNBLDZCQUFBO0VBQ0EsVUFBQTtFQUNBLG9DRjdacUI7QUNxa0J0Qjs7QUNyS0E7RUFDQyxhQUFBO0VBQ0EsWUFBQTtBRHdLRDs7QUNyS0E7RUFDQyxXQUFBO0VBQ0EsV0FBQTtFQUNBLGdCQUFBO0VBQ0Esa0JBQUE7QUR3S0Q7O0FDcktBO0VBQ0MsV0FBQTtFQUNBLFdBQUE7RUFDQSw4QkFBQTtFQUNBLGFBQUE7RUFDQSxtQkFBQTtBRHdLRDs7QUNyS0E7RUFDQyxrQkFBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtBRHdLRDs7QUNyS0E7RUFDQyxrQkFBQTtFQUNBLFlBQUE7RUFDQSx5REFBQTtFQUNBLFdBQUE7RUFDQSxrQkFBQTtFQUNBLFNBQUE7RUFDQSwrQ0ZoY3FCO0FDd21CdEI7O0FDdEtDO0VBQ0MsbUJBQUE7RUFDQSxzQkFBQTtBRHdLRjs7QUNyS0M7RUFDQyxZQUFBO0VBQ0EsYUFBQTtFQUNBLGtCQUFBO0VBQ0Esa0JBQUE7RUFDQSxXQUFBO0VBQ0Esb0JBQUE7RUFDQSwrQ0Y5Y29CO0FDcW5CdEI7O0FDcEtDO0VBQ0MsYUFBQTtBRHNLRjs7QUNuS0M7RUFDQyxhQUFBO0VBQ0EsYUFBQTtFQUNBLGtCQUFBO0VBQ0Esa0JBQUE7RUFDQSxXQUFBO0VBQ0Esb0JBQUE7RUFDQSxZQUFBO0VBQ0EsK0NGN2RvQjtBQ2tvQnRCOztBQ2xLQztFQUNDLGFBQUE7QURvS0Y7O0FDaktDO0VBQ0MsMkNGdGVvQjtBQ3lvQnRCOztBQ2pLRTtFQUNDLGFBQUE7QURtS0g7O0FDaEtFO0VBQ0MsbUJBQUE7QURrS0g7O0FDOUpDO0VBQ0MsV0FBQTtFQUNBLGtCQUFBO0VBQ0EsaUJBQUE7QURnS0Y7O0FDOUpFO0VBQ0MsMEJBQUE7QURnS0g7O0FDNUpDO0VBQ0MsV0FBQTtFQUNBLGtCQUFBO0FEOEpGOztBQzNKRTtFQUNDLDBCQUFBO0FENkpIOztBQ3hKQTtFQUNDLG9DRnZnQnFCO0FDa3FCdEI7O0FDdkpDO0VBQ0MsMkNGdGdCb0I7QUNncUJ0Qjs7QUN2SkM7RUFDQywrQ0FBQTtBRHlKRjs7QUNwSkM7RUFDQywrQ0FBQTtFQUNBLGdCQUFBO0FEdUpGOztBQ3JKRTtFQUNDLCtDQUFBO0FEdUpIOztBQ2xKQTtFQUNDLG9CQUFBO0FEcUpEOztBQ2xKQTtFQUNDLHFCQUFBO0FEcUpEOztBQ2xKQTtFQUNDLGtCQUFBO0VBQ0Esb0JBQUE7RUFDQSxzQkFBQTtFQUNBLGFBQUE7RUFDQSxjQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0FEcUpEOztBQ2xKQTtFQUNDLHNERjNpQjRCO0VFNGlCNUIsdUJBQUE7QURxSkQ7O0FDbEpBO0VBQ0MsNkJBQUE7RUFDQSwrQ0Z2akJxQjtBQzRzQnRCOztBQ2xKQTtFQUNDO0lBQ0MsMkJBQUE7RURxSkE7RUNsSkQ7SUFDQyx5QkFBQTtFRG9KQTtBQUNGOztBQ2pKQTtFQUNDLG9DRmhrQnFCO0FDbXRCdEI7O0FDakpDO0VBQ0MsK0NGbmtCb0I7QUNzdEJ0Qjs7QUMvSUE7RUFDQyw0Q0Z0a0I2QjtBQ3d0QjlCOztBQ2hKQztFQUNDLHVERnprQjRCO0FDMnRCOUI7O0FDOUlBO0VBQ0Msc0NGN2tCdUI7QUM4dEJ4Qjs7QUMvSUM7RUFDQyxpREZobEJzQjtBQ2l1QnhCOztBQzdJQTtFQUNDLFdBQUE7RUFDQSxZQUFBO0VBQ0EsYUFBQTtFQUNBLGtCQUFBO0VBQ0EsYUFBQTtFQUNBLHdCQUFBO1VBQUEsZ0JBQUE7RUFDQSw2QkFBQTtBRGdKRDs7QUM5SUM7RUFDQyxjQUFBO0FEZ0pGOztBQzVJQTtFQUNDLG9DRjFtQnFCO0FDeXZCdEI7O0FDNUlBO0VBQ0MsYUFBQTtFQUNBLGNBQUE7QUQrSUQ7O0FDNUlBO0VBQ0MsV0FBQTtFQUNBLFlBQUE7RUFDQSwwQkFBQTtBRCtJRDs7QUM1SUE7RUFDQyxrQkFBQTtBRCtJRDs7QUM1SUE7RUFDQyxlQUFBO0VBQ0EsTUFBQTtFQUNBLFFBQUE7RUFDQSxZQUFBO0VBQ0EsV0FBQTtFQUNBLHlERnpuQitCO0VFMG5CL0IsZ0JBQUE7QUQrSUQ7O0FDN0lDO0VBQ0MsWUFBQTtBRCtJRjs7QUMzSUE7RUFDQyxrQkFBQTtFQUNBLGdCQUFBO0VBQ0EsU0FBQTtBRDhJRDs7QUMzSUE7RUFDQyx5QkFBQTtFQUNBLFlBQUE7RUFDQSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSxrQkFBQTtFQUNBLFVBQUE7RUFDQSxXQUFBO0FEOElEOztBQzNJQTtFQUNDLGtCQUFBO0VBQ0EsWUFBQTtFQUNBLFVBQUE7RUFDQSxZQUFBO0FEOElEOztBQzNJQTtFQUNDLGtCQUFBO0VBQ0EsUUFBQTtFQUNBLFNBQUE7RUFDQSxnQ0FBQTtFQUNBLGtCQUFBO0VBQ0EsK0NGN3BCZ0M7RUU4cEJoQyxhQUFBO0FEOElEOztBQzNJQTtFQUNDLDZCQUFBO0FEOElEOztBQzFJQztFQUNDLGlCQUFBO0FENklGOztBQ3pJQTtFQUNDLGFBQUE7QUQ0SUQ7O0FDeklBO0VBQ0MsT0FBQTtFQUNBLFFBQUE7RUFDQSxNQUFBO0VBQ0EsU0FBQTtFQUNBLGFBQUE7RUFDQSxrQkFBQTtFQUNBLHNCQUFBO0VBQ0EsOEJBQUE7RUFDQSwwQkFBQTtFQUNBLGdCQUFBO0VBQ0EseURGM3JCK0I7RUU0ckIvQixtQkFBQTtFQUNBLGtCQUFBO0FENElEOztBQ3pJQTtFQUNDLGdCQUFBO0FENElEOztBQ3pJQTtFQUNDLDhCQUFBO0FENElEOztBQ3pJQTtFQUNDLGFBQUE7QUQ0SUQ7O0FDeklBO0VBQ0MsK0JBQUE7RUFDQSw4QkFBQTtBRDRJRDs7QUN6SUE7RUFDQyx3Q0FBQTtBRDRJRDs7QUN4SUM7RUFDQyx5QkFBQTtFQUNBLFNBQUE7QUQySUY7O0FDdklBO0VBQ0MsYUFBQTtFQUNBLGdCQUFBO0VBQ0EsYUFBQTtBRDBJRDs7QUN2SUE7RUFDQyxjQUFBO0FEMElEOztBQ3ZJQTtFQUNDLG1DRm52Qm9CO0FDNjNCckI7O0FDbklJO0VBQ0MsbUJBQUE7RUFDQSx1QkFBQTtFQUNBLGFBQUE7RUFDQSxXQUFBO0FEc0lMOztBQ3BJSztFQUNDLGFBQUE7QURzSU47O0FDbElJO0VBQ0Msa0JBQUE7RUFDQSxXQUFBO0VBQ0EsUUFBQTtBRG9JTDs7QUNsSUs7RUFDQyxhQUFBO0VBQ0EsOEJBQUE7RUFDQSxXQUFBO0FEb0lOOztBQzVIQTtFQUNDLHlCQUFBO0FEK0hEOztBQzVIQSx5Q0FBQTs7QUFDQTs7Ozs7Ozs7O0VBU0MsOEJBQUE7RUFDQSw4Q0FBQTtFQUNBLHlEQUFBO0VBQUEsaURBQUE7QUQrSEQ7O0FDM0hDO0VBQ0MsdURBQUE7RUFDQSx5Q0FBQTtFQUNBLDRCQUFBO0FEOEhGOztBQzNIQztFQUNDLGtEQUFBO0FENkhGOztBQzVHQTtFQUNDO0lBRUMsa0NBQUE7SUFDQSxtQkFBQTtFRDBIQTtFQ3ZIRDtJQUVDLHdCQUFBO0VEeUhBO0FBQ0Y7O0FDdEhBO0VBRUMsNEJBQUE7QUR3SEQ7O0FDckhBO0VBRUMsd0JBQUE7RUFFQSx3QkFBQTtFQUVBLHlCQUFBO0FEd0hEOztBQTcrQkE7RUFDRSxtRER1QzhCO0VDdEM5QixhQUFBO0VBQ0EsY0FBQTtFQUNBLG1CQUFBO0FBZy9CRjs7QUE5K0JBO0VBQ0UsV0FBQTtFQUNBLFdBQUE7RUFDQSw4QkFBQTtFQUNBLGFBQUE7RUFDQSxtQkFBQTtBQWkvQkY7O0FBLytCQTtFQUNFLDhDQUFBO0FBay9CRjs7QUEvK0JBO0VBQ0UsMEJBQUE7RUFDQSwyQ0RpQjJCO0FDaStCN0I7O0FBLytCQTtFQUNFLFdBQUE7RUFDQSxZQUFBO0VBQ0EsbURETzhCO0FDMitCaEM7O0FBai9CRTtFQUNFLDBCQUFBO0VBQ0Esd0JBQUE7QUFtL0JKOztBQWovQk07RUFDRSxjQUFBO0VBQ0EsMkJBQUE7QUFtL0JSOztBQTcrQkE7RUFDRSxZQUFBO0FBZy9CRjs7QUEvK0JFO0VBQ0UsOENBQUE7QUFpL0JKOztBQTcrQkE7RUFDRSxxQkFBQTtBQWcvQkY7O0FBOStCQTtFQUNFLDRDQUFBO0FBaS9CRiIsImZpbGUiOiJjbGFpbXMtcHJlc2NyaXB0aW9uLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIjpyb290IHtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTUwOiByZWQ7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXdoaXRlOiB5ZWxsb3c7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWJsdWU6ICMwZDE1MmU7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuOiAjMDA5MDhkO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ibGFjazogIzAwMDAwMDtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tZ3JleS1iYWNrZ3JvdW5kOiAjYzhkM2RhO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ncmV5OiAjOTJhMmFjO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zdG9uZS1ncmV5OiAjZmFmYWZhO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1lcnJvcjogI2ZjMTA1NTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5OiAjNDE0MTQxO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1maWJyYW50LWdyZWVuOiAjMDBiYWI2O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi13YXJuaW5nOiAjZmZkMDQ4O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbi1iYWNrZ3JvdW5kOiAjZTZmMmYyO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNDAwOiAjN2E3YTdhO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktMTAwOiAjZWZmM2Y1O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtZXJyb3I6ICNiYTBjM2Y7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy1lcnJvci1iYWNrZ3JvdW5kOiAjZmZlZmY0O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtd2FybmluZzogI2NiYTEyNztcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLXdhcm5pbmctYmFja2dyb3VuZDogI2ZmZjhlNjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZS0xMDA6ICNkZmVmZjI7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWVycm9yLXJlZC03MDA6ICNmNjI0NTk7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWJsdWUtNTAwOiAjMDA2MTkyO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlLTQwMDogIzc5Y2RlYztcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tcmVkLTUwMDogI2ZmNjU5MjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc2Vjb25kYXJ5LWJsdWUtMzAwOiAjMTNhMGQzO1xyXG5cclxuXHQtLWx1bWktd2hpdGUtY29sb3I6ICNmZmZmZmY7XHJcblx0LS1sdW1pLXByaW1hcnkteWVsbG93LWNvbG9yOiAjZmFiNjAwO1xyXG59XHJcbiRjb2xvci1uZXh0Z2VuLWJsdWU6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZSk7XHJcbiRjb2xvci1uZXh0Z2VuLWdyZWVuOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuKTtcclxuJGNvbG9yLW5leHRnZW4td2hpdGU6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4td2hpdGUpO1xyXG4kY29sb3ItbmV4dGdlbi1ibGFjazogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ibGFjayk7XHJcbiRjb2xvci1uZXh0Z2VuLWdyZXktYmFja2dyb3VuZDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmV5LWJhY2tncm91bmQpO1xyXG4kY29sb3ItbmV4dGdlbi1ncmV5OiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZXkpO1xyXG4kY29sb3ItbmV4dGdlbi1zdG9uZS1ncmV5OiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXN0b25lLWdyZXkpO1xyXG4kY29sb3ItbmV4dGdlbi1lcnJvcjogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1lcnJvcik7XHJcbiRjb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleTogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXkpO1xyXG4kY29sb3ItbmV4dGdlbi1maWJyYW50LWdyZWVuOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWZpYnJhbnQtZ3JlZW4pO1xyXG4kY29sb3ItbmV4dGdlbi13YXJuaW5nOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXdhcm5pbmcpO1xyXG4kY29sb3ItbmV4dGdlbi1ncmVlbi1iYWNrZ3JvdW5kOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuLWJhY2tncm91bmQpO1xyXG4kY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNTA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTUwKTtcclxuJGNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTQwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNDAwKTtcclxuJGNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTEwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktMTAwKTtcclxuJGNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy1lcnJvcik7XHJcbiRjb2xvci1uZXh0Z2VuLXN0YXR1cy1lcnJvci1iYWNrZ3JvdW5kOiB2YXIoXHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy1lcnJvci1iYWNrZ3JvdW5kXHJcbik7XHJcbiRjb2xvci1uZXh0Z2VuLXN0YXR1cy13YXJuaW5nOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy13YXJuaW5nKTtcclxuJGNvbG9yLW5leHRnZW4tc3RhdHVzLXdhcm5pbmctYmFja2dyb3VuZDogdmFyKFxyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtd2FybmluZy1iYWNrZ3JvdW5kXHJcbik7XHJcbiRjb2xvci1uZXh0Z2VuLWJsdWUtMTAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWJsdWUtMTAwKTtcclxuJGNvbG9yLW5leHRnZW4tZXJyb3ItcmVkLTcwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1lcnJvci1yZWQtNzAwKTtcclxuJGNvbG9yLW5leHRnZW4tYmx1ZS01MDA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZS01MDApO1xyXG4kY29sb3ItbmV4dGdlbi1ibHVlLTQwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlLTQwMCk7XHJcbiRjb2xvci1uZXh0Z2VuLXJlZC01MDA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tcmVkLTUwMCk7XHJcbiRjb2xvci1uZXh0Z2VuLXNlY29uZGFyeS1ibHVlLTMwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1zZWNvbmRhcnktYmx1ZS0zMDApO1xyXG5cclxuLmlvbi1jb2xvci1ncmVlbiB7XHJcblx0LS1pb24tY29sb3ItYmFzZTogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbik7XHJcblx0LS1pb24tY29sb3ItYmFzZS1yZ2I6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4pO1xyXG5cdC0taW9uLWNvbG9yLWNvbnRyYXN0OiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXdoaXRlKTtcclxuXHQtLWlvbi1jb2xvci1jb250cmFzdC1yZ2I6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4pO1xyXG5cdC0taW9uLWNvbG9yLXNoYWRlOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuKTtcclxuXHQtLWlvbi1jb2xvci10aW50OiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuKTtcclxufVxyXG4iLCJAaW1wb3J0ICcuLi8uLi8uLi8uLi9jb2xvci5zY3NzJztcclxuQGltcG9ydCAnLi4vLi4vLi4vLi4vc3R5bGUuc2Nzcyc7XHJcbi5wcmVzY3JpcHRpb24tY29udGFpbmVyIHtcclxuICBiYWNrZ3JvdW5kOiAkY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNTA7XHJcbiAgLS13aWR0aDogMTAwJTtcclxuICAtLWhlaWdodDogMTAwJTtcclxuICBwYWRkaW5nLWJvdHRvbTogOXZoO1xyXG59XHJcbi50b3AtcHJlc2NyaXB0aW9uIHtcclxuICB3aWR0aDogMTAwJTtcclxuICBoZWlnaHQ6IDEwJTtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG59XHJcbi50aXRsZS10ZXh0IHtcclxuICBjb2xvcjogJGNvbG9yLW5leHRnZW4tYmx1ZSAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4uaWNvbi1xdWVzdGlvbiB7XHJcbiAgZm9udC1zaXplOiAycmVtICFpbXBvcnRhbnQ7XHJcbiAgY29sb3I6ICRjb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleTtcclxufVxyXG5cclxuLnNlZ21lbnQge1xyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIGhlaWdodDogM3JlbTtcclxuICBiYWNrZ3JvdW5kOiAkY29sb3ItbmV4dGdlbi1ncmV5LWJhY2tncm91bmQ7XHJcbiAgLnNlZ21lbnQtYnV0dG9uIHtcclxuICAgIC0taW5kaWNhdG9yLWNvbG9yOiAjMDA5MDhkO1xyXG4gICAgLS1jb2xvci1jaGVja2VkOiAjZmZmZmZmO1xyXG4gICAgJi5zZWdtZW50LWJ1dHRvbi1jaGVja2VkIHtcclxuICAgICAgaW9uLWxhYmVsIHtcclxuICAgICAgICBjb2xvcjogI2ZmZmZmZjtcclxuICAgICAgICBmb250LXdlaWdodDogNzAwICFpbXBvcnRhbnQ7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9XHJcbn1cclxuXHJcbi5jbGFpbS10aXRsZSB7XHJcbiAgbWFyZ2luOiA1JSAwO1xyXG4gIHNwYW4ge1xyXG4gICAgY29sb3I6ICRjb2xvci1uZXh0Z2VuLWJsdWUgIWltcG9ydGFudDtcclxuICB9XHJcbn1cclxuXHJcbi5pbnB1dFNlYXJjaHtcclxuICBtYXJnaW46IDJyZW0gMCAycmVtIDA7XHJcbn1cclxuaW9uLWNvbnRlbnQge1xyXG4gIC0tYmFja2dyb3VuZDogJGNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTUwO1xyXG59IiwiLypcclxuICogMS4gQ3VzdG9tIENTUyBcclxuICogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG4gKi9cclxuXHJcbi8vIGNvbG9yIHZhcmlhYmxlXHJcbkBpbXBvcnQgXCIuL2NvbG9yLnNjc3NcIjtcclxuLy8gdHlwb2dyYXBoeVxyXG5AaW1wb3J0IFwiLi9mb250LXNpemUuc2Nzc1wiO1xyXG5cclxuLy8gRm9udHNcclxuQGZvbnQtZmFjZSB7XHJcblx0Zm9udC1mYW1pbHk6IFwiQWxsaWFueiBOZW9cIjtcclxuXHRmb250LXN0eWxlOiBub3JtYWw7XHJcblx0Zm9udC13ZWlnaHQ6IDMwMDtcclxuXHRmb250LWRpc3BsYXk6IHN3YXA7XHJcblx0c3JjOiB1cmwoXCIuL2Fzc2V0cy9mb250cy9BbGxpYW56TmVvL0FsbGlhbnpfTmVvX3dlYmZvbnRzL3dvZmYyL0FsbGlhbnpOZW9XMDQtTGlnaHQud29mZjJcIilcclxuXHRcdFx0Zm9ybWF0KFwid29mZjJcIiksXHJcblx0XHR1cmwoXCIuL2Fzc2V0cy9mb250cy9BbGxpYW56TmVvL0FsbGlhbnpfTmVvX3dlYmZvbnRzL3dvZmYvQWxsaWFuek5lb1cwNC1MaWdodC53b2ZmXCIpXHJcblx0XHRcdGZvcm1hdChcIndvZmZcIik7XHJcbn1cclxuXHJcbkBmb250LWZhY2Uge1xyXG5cdGZvbnQtZmFtaWx5OiBcIkFsbGlhbnogTmVvXCI7XHJcblx0Zm9udC1zdHlsZTogaXRhbGljO1xyXG5cdGZvbnQtd2VpZ2h0OiAzMDA7XHJcblx0Zm9udC1kaXNwbGF5OiBzd2FwO1xyXG5cdHNyYzogdXJsKFwiLi9hc3NldHMvZm9udHMvQWxsaWFuek5lby9BbGxpYW56X05lb193ZWJmb250cy93b2ZmMi9BbGxpYW56TmVvVzA0LUxpZ2h0SXRhbGljLndvZmYyXCIpXHJcblx0XHRcdGZvcm1hdChcIndvZmYyXCIpLFxyXG5cdFx0dXJsKFwiLi9hc3NldHMvZm9udHMvQWxsaWFuek5lby9BbGxpYW56X05lb193ZWJmb250cy93b2ZmL0FsbGlhbnpOZW9XMDQtTGlnaHRJdGFsaWMud29mZlwiKVxyXG5cdFx0XHRmb3JtYXQoXCJ3b2ZmXCIpO1xyXG59XHJcblxyXG5AZm9udC1mYWNlIHtcclxuXHRmb250LWZhbWlseTogXCJBbGxpYW56IE5lb1wiO1xyXG5cdGZvbnQtc3R5bGU6IG5vcm1hbDtcclxuXHRmb250LXdlaWdodDogNDAwO1xyXG5cdGZvbnQtZGlzcGxheTogc3dhcDtcclxuXHRzcmM6IHVybChcIi4vYXNzZXRzL2ZvbnRzL0FsbGlhbnpOZW8vQWxsaWFuel9OZW9fd2ViZm9udHMvd29mZjIvQWxsaWFuek5lb1cwNC1SZWd1bGFyLndvZmYyXCIpXHJcblx0XHRcdGZvcm1hdChcIndvZmYyXCIpLFxyXG5cdFx0dXJsKFwiLi9hc3NldHMvZm9udHMvQWxsaWFuek5lby9BbGxpYW56X05lb193ZWJmb250cy93b2ZmL0FsbGlhbnpOZW9XMDQtUmVndWxhci53b2ZmXCIpXHJcblx0XHRcdGZvcm1hdChcIndvZmZcIik7XHJcbn1cclxuXHJcbkBmb250LWZhY2Uge1xyXG5cdGZvbnQtZmFtaWx5OiBcIkFsbGlhbnogTmVvXCI7XHJcblx0Zm9udC1zdHlsZTogaXRhbGljO1xyXG5cdGZvbnQtd2VpZ2h0OiA0MDA7XHJcblx0Zm9udC1kaXNwbGF5OiBzd2FwO1xyXG5cdHNyYzogdXJsKFwiLi9hc3NldHMvZm9udHMvQWxsaWFuek5lby9BbGxpYW56X05lb193ZWJmb250cy93b2ZmMi9BbGxpYW56TmVvVzA0LUl0YWxpYy53b2ZmMlwiKVxyXG5cdFx0XHRmb3JtYXQoXCJ3b2ZmMlwiKSxcclxuXHRcdHVybChcIi4vYXNzZXRzL2ZvbnRzL0FsbGlhbnpOZW8vQWxsaWFuel9OZW9fd2ViZm9udHMvd29mZi9BbGxpYW56TmVvVzA0LUl0YWxpYy53b2ZmXCIpXHJcblx0XHRcdGZvcm1hdChcIndvZmZcIik7XHJcbn1cclxuXHJcbkBmb250LWZhY2Uge1xyXG5cdGZvbnQtZmFtaWx5OiBcIkFsbGlhbnogTmVvXCI7XHJcblx0Zm9udC1zdHlsZTogbm9ybWFsO1xyXG5cdGZvbnQtd2VpZ2h0OiA2MDA7XHJcblx0Zm9udC1kaXNwbGF5OiBzd2FwO1xyXG5cdHNyYzogdXJsKFwiLi9hc3NldHMvZm9udHMvQWxsaWFuek5lby9BbGxpYW56X05lb193ZWJmb250cy93b2ZmMi9BbGxpYW56TmVvVzA0LVNlbWlCb2xkLndvZmYyXCIpXHJcblx0XHRcdGZvcm1hdChcIndvZmYyXCIpLFxyXG5cdFx0dXJsKFwiLi9hc3NldHMvZm9udHMvQWxsaWFuek5lby9BbGxpYW56X05lb193ZWJmb250cy93b2ZmL0FsbGlhbnpOZW9XMDQtU2VtaUJvbGQud29mZlwiKVxyXG5cdFx0XHRmb3JtYXQoXCJ3b2ZmXCIpO1xyXG59XHJcblxyXG5AZm9udC1mYWNlIHtcclxuXHRmb250LWZhbWlseTogXCJBbGxpYW56IE5lb1wiO1xyXG5cdGZvbnQtc3R5bGU6IGl0YWxpYztcclxuXHRmb250LXdlaWdodDogNjAwO1xyXG5cdGZvbnQtZGlzcGxheTogc3dhcDtcclxuXHRzcmM6IHVybChcIi4vYXNzZXRzL2ZvbnRzL0FsbGlhbnpOZW8vQWxsaWFuel9OZW9fd2ViZm9udHMvd29mZjIvQWxsaWFuek5lb1cwNC1TZW1pQm9sZEl0LndvZmYyXCIpXHJcblx0XHRcdGZvcm1hdChcIndvZmYyXCIpLFxyXG5cdFx0dXJsKFwiLi9hc3NldHMvZm9udHMvQWxsaWFuek5lby9BbGxpYW56X05lb193ZWJmb250cy93b2ZmL0FsbGlhbnpOZW9XMDQtU2VtaUJvbGRJdC53b2ZmXCIpXHJcblx0XHRcdGZvcm1hdChcIndvZmZcIik7XHJcbn1cclxuXHJcbkBmb250LWZhY2Uge1xyXG5cdGZvbnQtZmFtaWx5OiBcIkFsbGlhbnogTmVvXCI7XHJcblx0Zm9udC1zdHlsZTogbm9ybWFsO1xyXG5cdGZvbnQtd2VpZ2h0OiA3MDA7XHJcblx0Zm9udC1kaXNwbGF5OiBzd2FwO1xyXG5cdHNyYzogdXJsKFwiLi9hc3NldHMvZm9udHMvQWxsaWFuek5lby9BbGxpYW56X05lb193ZWJmb250cy93b2ZmMi9BbGxpYW56TmVvVzA0LUJvbGQud29mZjJcIilcclxuXHRcdFx0Zm9ybWF0KFwid29mZjJcIiksXHJcblx0XHR1cmwoXCIuL2Fzc2V0cy9mb250cy9BbGxpYW56TmVvL0FsbGlhbnpfTmVvX3dlYmZvbnRzL3dvZmYvQWxsaWFuek5lb1cwNC1Cb2xkLndvZmZcIilcclxuXHRcdFx0Zm9ybWF0KFwid29mZlwiKTtcclxufVxyXG5cclxuQGZvbnQtZmFjZSB7XHJcblx0Zm9udC1mYW1pbHk6IFwiQWxsaWFueiBOZW9cIjtcclxuXHRmb250LXN0eWxlOiBpdGFsaWM7XHJcblx0Zm9udC13ZWlnaHQ6IDcwMDtcclxuXHRmb250LWRpc3BsYXk6IHN3YXA7XHJcblx0c3JjOiB1cmwoXCIuL2Fzc2V0cy9mb250cy9BbGxpYW56TmVvL0FsbGlhbnpfTmVvX3dlYmZvbnRzL3dvZmYyL0FsbGlhbnpOZW9XMDQtQm9sZEl0YWxpYy53b2ZmMlwiKVxyXG5cdFx0XHRmb3JtYXQoXCJ3b2ZmMlwiKSxcclxuXHRcdHVybChcIi4vYXNzZXRzL2ZvbnRzL0FsbGlhbnpOZW8vQWxsaWFuel9OZW9fd2ViZm9udHMvd29mZi9BbGxpYW56TmVvVzA0LUJvbGRJdGFsaWMud29mZlwiKVxyXG5cdFx0XHRmb3JtYXQoXCJ3b2ZmXCIpO1xyXG59XHJcblxyXG4qIHtcclxuXHRjb2xvcjogJGNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5O1xyXG5cdGZvbnQtZmFtaWx5OiBcIkFsbGlhbnogTmVvXCIsIHNhbnMtc2VyaWY7XHJcblx0Zm9udC13ZWlnaHQ6IDQwMDtcclxuXHRmb250LXNpemU6IDE2cHg7XHJcbn1cclxuXHJcbmh0bWwge1xyXG5cdC0taW9uLXNhZmUtYXJlYS10b3A6IDBweDtcclxufVxyXG5cclxuLmNvbC0xIHtcclxuXHR3aWR0aDogOC4zMyU7XHJcbn1cclxuXHJcbi5jb2wtMiB7XHJcblx0d2lkdGg6IDE2LjY2JTtcclxufVxyXG5cclxuLmNvbC0zIHtcclxuXHR3aWR0aDogMjUlO1xyXG59XHJcblxyXG4uY29sLTQge1xyXG5cdHdpZHRoOiAzMy4zMyU7XHJcbn1cclxuXHJcbi5jb2wtNSB7XHJcblx0d2lkdGg6IDQxLjY2JTtcclxufVxyXG5cclxuLmNvbC02IHtcclxuXHR3aWR0aDogNTAlO1xyXG59XHJcblxyXG4uY29sLTcge1xyXG5cdHdpZHRoOiA1OC4zMyU7XHJcbn1cclxuXHJcbi5jb2wtOCB7XHJcblx0d2lkdGg6IDY2LjY2JTtcclxufVxyXG5cclxuLmNvbC05IHtcclxuXHR3aWR0aDogNzUlO1xyXG59XHJcblxyXG4uY29sLTEwIHtcclxuXHR3aWR0aDogODMuMzMlO1xyXG59XHJcblxyXG4uY29sLTExIHtcclxuXHR3aWR0aDogOTEuNjYlO1xyXG59XHJcblxyXG4uY29sLTEyIHtcclxuXHR3aWR0aDogMTAwJTtcclxufVxyXG5cclxuQG1lZGlhIG9ubHkgc2NyZWVuIGFuZCAobWF4LXdpZHRoOiA1NzZweCkge1xyXG5cdC8qIEZvciB0YWJsZXRzOiAqL1xyXG5cdC5jb2wtc20tMSB7XHJcblx0XHR3aWR0aDogOC4zMyU7XHJcblx0fVxyXG5cclxuXHQuY29sLXNtLTIge1xyXG5cdFx0d2lkdGg6IDE2LjY2JTtcclxuXHR9XHJcblxyXG5cdC5jb2wtc20tMyB7XHJcblx0XHR3aWR0aDogMjUlO1xyXG5cdH1cclxuXHJcblx0LmNvbC1zbS00IHtcclxuXHRcdHdpZHRoOiAzMy4zMyU7XHJcblx0fVxyXG5cclxuXHQuY29sLXNtLTUge1xyXG5cdFx0d2lkdGg6IDQxLjY2JTtcclxuXHR9XHJcblxyXG5cdC5jb2wtc20tNiB7XHJcblx0XHR3aWR0aDogNTAlO1xyXG5cdH1cclxuXHJcblx0LmNvbC1zbS03IHtcclxuXHRcdHdpZHRoOiA1OC4zMyU7XHJcblx0fVxyXG5cclxuXHQuY29sLXNtLTgge1xyXG5cdFx0d2lkdGg6IDY2LjY2JTtcclxuXHR9XHJcblxyXG5cdC5jb2wtc20tOSB7XHJcblx0XHR3aWR0aDogNzUlO1xyXG5cdH1cclxuXHJcblx0LmNvbC1zbS0xMCB7XHJcblx0XHR3aWR0aDogODMuMzMlO1xyXG5cdH1cclxuXHJcblx0LmNvbC1zbS0xMSB7XHJcblx0XHR3aWR0aDogOTEuNjYlO1xyXG5cdH1cclxuXHJcblx0LmNvbC1zbS0xMiB7XHJcblx0XHR3aWR0aDogMTAwJTtcclxuXHR9XHJcbn1cclxuXHJcbkBtZWRpYSBvbmx5IHNjcmVlbiBhbmQgKG1heC13aWR0aDogNzY4cHgpIGFuZCAobWluLXdpZHRoOiA1NzdweCkge1xyXG5cdC8qIEZvciB0YWJsZXRzOiAqL1xyXG5cdC5jb2wtbWQtMSB7XHJcblx0XHR3aWR0aDogOC4zMyU7XHJcblx0fVxyXG5cclxuXHQuY29sLW1kLTIge1xyXG5cdFx0d2lkdGg6IDE2LjY2JTtcclxuXHR9XHJcblxyXG5cdC5jb2wtbWQtMyB7XHJcblx0XHR3aWR0aDogMjUlO1xyXG5cdH1cclxuXHJcblx0LmNvbC1tZC00IHtcclxuXHRcdHdpZHRoOiAzMy4zMyU7XHJcblx0fVxyXG5cclxuXHQuY29sLW1kLTUge1xyXG5cdFx0d2lkdGg6IDQxLjY2JTtcclxuXHR9XHJcblxyXG5cdC5jb2wtbWQtNiB7XHJcblx0XHR3aWR0aDogNTAlO1xyXG5cdH1cclxuXHJcblx0LmNvbC1tZC03IHtcclxuXHRcdHdpZHRoOiA1OC4zMyU7XHJcblx0fVxyXG5cclxuXHQuY29sLW1kLTgge1xyXG5cdFx0d2lkdGg6IDY2LjY2JTtcclxuXHR9XHJcblxyXG5cdC5jb2wtbWQtOSB7XHJcblx0XHR3aWR0aDogNzUlO1xyXG5cdH1cclxuXHJcblx0LmNvbC1tZC0xMCB7XHJcblx0XHR3aWR0aDogODMuMzMlO1xyXG5cdH1cclxuXHJcblx0LmNvbC1tZC0xMSB7XHJcblx0XHR3aWR0aDogOTEuNjYlO1xyXG5cdH1cclxuXHJcblx0LmNvbC1tZC0xMiB7XHJcblx0XHR3aWR0aDogMTAwJTtcclxuXHR9XHJcbn1cclxuXHJcbkBtZWRpYSBvbmx5IHNjcmVlbiBhbmQgKG1pbi13aWR0aDogNzY5cHgpIHtcclxuXHQvKiBGb3IgdGFibGV0czogKi9cclxuXHQuY29sLWxnLTEge1xyXG5cdFx0d2lkdGg6IDguMzMlO1xyXG5cdH1cclxuXHJcblx0LmNvbC1sZy0yIHtcclxuXHRcdHdpZHRoOiAxNi42NiU7XHJcblx0fVxyXG5cclxuXHQuY29sLWxnLTMge1xyXG5cdFx0d2lkdGg6IDI1JTtcclxuXHR9XHJcblxyXG5cdC5jb2wtbGctNCB7XHJcblx0XHR3aWR0aDogMzMuMzMlO1xyXG5cdH1cclxuXHJcblx0LmNvbC1sZy01IHtcclxuXHRcdHdpZHRoOiA0MS42NiU7XHJcblx0fVxyXG5cclxuXHQuY29sLWxnLTYge1xyXG5cdFx0d2lkdGg6IDUwJTtcclxuXHR9XHJcblxyXG5cdC5jb2wtbGctNyB7XHJcblx0XHR3aWR0aDogNTguMzMlO1xyXG5cdH1cclxuXHJcblx0LmNvbC1sZy04IHtcclxuXHRcdHdpZHRoOiA2Ni42NiU7XHJcblx0fVxyXG5cclxuXHQuY29sLWxnLTkge1xyXG5cdFx0d2lkdGg6IDc1JTtcclxuXHR9XHJcblxyXG5cdC5jb2wtbGctMTAge1xyXG5cdFx0d2lkdGg6IDgzLjMzJTtcclxuXHR9XHJcblxyXG5cdC5jb2wtbGctMTEge1xyXG5cdFx0d2lkdGg6IDkxLjY2JTtcclxuXHR9XHJcblxyXG5cdC5jb2wtbGctMTIge1xyXG5cdFx0d2lkdGg6IDEwMCU7XHJcblx0fVxyXG59XHJcblxyXG4ucm93IHtcclxuXHRkaXNwbGF5OiBmbGV4O1xyXG5cdGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG5cdGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbn1cclxuXHJcbi8vIENTU1xyXG4uY3VzdG9tLXRvYXN0IHtcclxuXHQtLW1heC13aWR0aDogZml0LWNvbnRlbnQ7XHJcbn1cclxuXHJcbi8qXHJcbiAqIDIuIEN1c3RvbSBDU1MgZm9yIGNvbXBhdGliaWxpdHkgd2l0aCBFZGdlXHJcbiAqIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuICovXHJcbmlucHV0OjotbXMtcmV2ZWFsLFxyXG5pbnB1dDo6LW1zLWNsZWFyIHtcclxuXHRkaXNwbGF5OiBub25lO1xyXG59XHJcblxyXG4uc3dhbDItcG9wdXAge1xyXG5cdG1hcmdpbi10b3A6IDIwcHg7XHJcbn1cclxuXHJcbi8qXHJcbiAqIDMuIEN1c3RvbSBDU1MgZm9yIGxvYWRpbmcgY29udHJvbGxlclxyXG4gKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcbiAqL1xyXG4udHJhbnNwYXJlbnQtbG9hZGluZy1jbGFzcyB7XHJcblx0LS1iYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcclxuXHQtLXNwaW5uZXItY29sb3I6ICM0N2U2YjE7XHJcbn1cclxuXHJcbi5sb2FkaW5nLXdyYXBwZXIuc2MtaW9uLWxvYWRpbmctbWQge1xyXG5cdGJveC1zaGFkb3c6IHVuc2V0O1xyXG5cdC13ZWJraXQtYm94LXNoYWRvdzogdW5zZXQ7XHJcbn1cclxuXHJcbi51aWwge1xyXG5cdGNvbG9yOiAkY29sb3ItbmV4dGdlbi1ncmV5O1xyXG59XHJcblxyXG4uYnRuIHtcclxuXHRoZWlnaHQ6IDQ4cHg7XHJcblx0Ym9yZGVyLXJhZGl1czogMjhweDtcclxuXHRwYWRkaW5nOiAwcHggNDFweCAwcHggNDFweDtcclxuXHRib3gtc2hhZG93OiBub25lO1xyXG5cclxuXHQmLmJ0bi1jaXJjbGUge1xyXG5cdFx0YmFja2dyb3VuZC1jb2xvcjogJGNvbG9yLW5leHRnZW4tc3RvbmUtZ3JleSAhaW1wb3J0YW50O1xyXG5cdFx0Y29sb3I6ICRjb2xvci1uZXh0Z2VuLWJsYWNrO1xyXG5cdFx0cGFkZGluZzogdW5zZXQgIWltcG9ydGFudDtcclxuXHRcdGhlaWdodDogMzZweCAhaW1wb3J0YW50O1xyXG5cdFx0d2lkdGg6IDM2cHggIWltcG9ydGFudDtcclxuXHRcdGJvcmRlci1yYWRpdXM6IDUwJSAhaW1wb3J0YW50O1xyXG5cclxuXHRcdGkge1xyXG5cdFx0XHRjb2xvcjogJGNvbG9yLW5leHRnZW4tYmxhY2s7XHJcblx0XHR9XHJcblx0fVxyXG5cclxuXHQmLnByaW1hcnkge1xyXG5cdFx0YmFja2dyb3VuZDogJGNvbG9yLW5leHRnZW4tZ3JlZW47XHJcblx0XHRjb2xvcjogJGNvbG9yLW5leHRnZW4td2hpdGU7XHJcblxyXG5cdFx0LnVpbCB7XHJcblx0XHRcdGNvbG9yOiAkY29sb3ItbmV4dGdlbi13aGl0ZTtcclxuXHRcdH1cclxuXHJcblx0XHQmOmRpc2FibGVkIHtcclxuXHRcdFx0YmFja2dyb3VuZC1jb2xvcjogJGNvbG9yLW5leHRnZW4tZ3JleS1iYWNrZ3JvdW5kICFpbXBvcnRhbnQ7XHJcblx0XHRcdGNvbG9yOiAkY29sb3ItbmV4dGdlbi1ncmV5ICFpbXBvcnRhbnQ7XHJcblx0XHR9XHJcblx0fVxyXG5cclxuXHQmLnNlY29uZGFyeSB7XHJcblx0XHRiYWNrZ3JvdW5kOiAkY29sb3ItbmV4dGdlbi13aGl0ZSAhaW1wb3J0YW50O1xyXG5cdFx0Ym9yZGVyLWNvbG9yOiAkY29sb3ItbmV4dGdlbi1ncmVlbjtcclxuXHRcdGJvcmRlcjogc29saWQgMXB4O1xyXG5cdFx0Y29sb3I6ICRjb2xvci1uZXh0Z2VuLWdyZWVuO1xyXG5cclxuXHRcdC51aWwge1xyXG5cdFx0XHRjb2xvcjogJGNvbG9yLW5leHRnZW4tZ3JlZW47XHJcblx0XHR9XHJcblxyXG5cdFx0JjpkaXNhYmxlZCB7XHJcblx0XHRcdGJhY2tncm91bmQtY29sb3I6ICRjb2xvci1uZXh0Z2VuLXdoaXRlICFpbXBvcnRhbnQ7XHJcblx0XHRcdGNvbG9yOiAkY29sb3ItbmV4dGdlbi1ncmV5ICFpbXBvcnRhbnQ7XHJcblx0XHRcdGJvcmRlci1jb2xvcjogJGNvbG9yLW5leHRnZW4tZ3JleS1iYWNrZ3JvdW5kICFpbXBvcnRhbnQ7XHJcblx0XHR9XHJcblx0fVxyXG5cclxuXHQmLnRyYW5zcGFyZW50IHtcclxuXHRcdGJhY2tncm91bmQ6IHRyYW5zcGFyZW50ICFpbXBvcnRhbnQ7XHJcblx0XHRib3JkZXItY29sb3I6ICRjb2xvci1uZXh0Z2VuLWdyZWVuO1xyXG5cdFx0Ym9yZGVyOiBzb2xpZCAxcHg7XHJcblx0XHRjb2xvcjogJGNvbG9yLW5leHRnZW4tZ3JlZW47XHJcblxyXG5cdFx0LnVpbCB7XHJcblx0XHRcdGNvbG9yOiAkY29sb3ItbmV4dGdlbi1ncmVlbjtcclxuXHRcdH1cclxuXHJcblx0XHQmOmRpc2FibGVkIHtcclxuXHRcdFx0YmFja2dyb3VuZC1jb2xvcjogdHJhbnNwYXJlbnQgIWltcG9ydGFudDtcclxuXHRcdFx0Y29sb3I6ICRjb2xvci1uZXh0Z2VuLWdyZXkgIWltcG9ydGFudDtcclxuXHRcdFx0Ym9yZGVyLWNvbG9yOiAkY29sb3ItbmV4dGdlbi1ncmV5LWJhY2tncm91bmQgIWltcG9ydGFudDtcclxuXHRcdH1cclxuXHR9XHJcblxyXG5cdCYuYnRuLWxhcmdlIHtcclxuXHRcdGhlaWdodDogNTZweCAhaW1wb3J0YW50O1xyXG5cdFx0d2lkdGg6IDEwMCU7XHJcblx0fVxyXG5cclxuXHQmLmJvbGQge1xyXG5cdFx0Zm9udC13ZWlnaHQ6IDcwMCAhaW1wb3J0YW50O1xyXG5cdH1cclxuXHJcblx0Ji5zZW1pYm9sZCB7XHJcblx0XHRmb250LXdlaWdodDogNjAwICFpbXBvcnRhbnQ7XHJcblx0fVxyXG59XHJcblxyXG4uYnRuLW5vLXNwYWNlIHtcclxuXHRwYWRkaW5nOiA1cHggIWltcG9ydGFudDtcclxuXHRoZWlnaHQ6IGZpdC1jb250ZW50O1xyXG59XHJcblxyXG4uYnRuLWJhY2sge1xyXG5cdHdpZHRoOiAzMXB4O1xyXG5cdGhlaWdodDogMjhweDtcclxuXHRiYWNrZ3JvdW5kLWNvbG9yOiB0cmFuc3BhcmVudDtcclxuXHRwYWRkaW5nOiAwO1xyXG5cdGNvbG9yOiAkY29sb3ItbmV4dGdlbi1ncmVlbjtcclxufVxyXG5cclxuLmNvbnRhaW5lciB7XHJcblx0cGFkZGluZzogMnJlbTtcclxuXHRoZWlnaHQ6IDEwMCU7XHJcbn1cclxuXHJcbi5ib2R5LXNlY3Rpb24ge1xyXG5cdHdpZHRoOiAxMDAlO1xyXG5cdGhlaWdodDogOTUlO1xyXG5cdG92ZXJmbG93LXk6IGF1dG87XHJcblx0cG9zaXRpb246IHJlbGF0aXZlO1xyXG59XHJcblxyXG4udG9wLXNlY3Rpb24ge1xyXG5cdHdpZHRoOiAxMDAlO1xyXG5cdGhlaWdodDogMTAlO1xyXG5cdGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcclxuXHRkaXNwbGF5OiBmbGV4O1xyXG5cdGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbn1cclxuXHJcbi5mb3JtLWNvbnRyb2wge1xyXG5cdHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuXHRoZWlnaHQ6IDg1cHg7XHJcblx0bWFyZ2luLWJvdHRvbTogOHB4O1xyXG59XHJcblxyXG4uY29udHJvbCB7XHJcblx0Ym9yZGVyLXJhZGl1czogOHB4O1xyXG5cdGhlaWdodDogNTZweDtcclxuXHRib3JkZXI6IDFweCBzb2xpZCAkY29sb3ItbmV4dGdlbi1ncmV5LWJhY2tncm91bmQ7XHJcblx0d2lkdGg6IDEwMCU7XHJcblx0cG9zaXRpb246IGFic29sdXRlO1xyXG5cdHRvcDogMzJweDtcclxuXHRiYWNrZ3JvdW5kLWNvbG9yOiAkY29sb3ItbmV4dGdlbi13aGl0ZTtcclxuXHJcblx0JiB0YWJsZSB7XHJcblx0XHR0YWJsZS1sYXlvdXQ6IGZpeGVkO1xyXG5cdFx0Ym9yZGVyLWNvbGxhcHNlOiB1bnNldDtcclxuXHR9XHJcblxyXG5cdCYgaW5wdXQge1xyXG5cdFx0aGVpZ2h0OiA1NHB4O1xyXG5cdFx0Ym9yZGVyOiB1bnNldDtcclxuXHRcdGJvcmRlci1yYWRpdXM6IDhweDtcclxuXHRcdHdpZHRoOiBtYXgtY29udGVudDtcclxuXHRcdHdpZHRoOiAxMDAlO1xyXG5cdFx0cG9pbnRlci1ldmVudHM6IGF1dG87XHJcblx0XHRiYWNrZ3JvdW5kLWNvbG9yOiAkY29sb3ItbmV4dGdlbi13aGl0ZTtcclxuXHR9XHJcblxyXG5cdCYudGV4dGFyZWEge1xyXG5cdFx0aGVpZ2h0OiAxMDhweDtcclxuXHR9XHJcblxyXG5cdCYgdGV4dGFyZWEge1xyXG5cdFx0aGVpZ2h0OiAxMDZweDtcclxuXHRcdGJvcmRlcjogdW5zZXQ7XHJcblx0XHRib3JkZXItcmFkaXVzOiA4cHg7XHJcblx0XHR3aWR0aDogbWF4LWNvbnRlbnQ7XHJcblx0XHR3aWR0aDogMTAwJTtcclxuXHRcdHBvaW50ZXItZXZlbnRzOiBhdXRvO1xyXG5cdFx0cmVzaXplOiBub25lO1xyXG5cdFx0YmFja2dyb3VuZC1jb2xvcjogJGNvbG9yLW5leHRnZW4td2hpdGU7XHJcblx0fVxyXG5cclxuXHQmIGlucHV0OmZvY3VzIHtcclxuXHRcdG91dGxpbmU6IG5vbmU7XHJcblx0fVxyXG5cclxuXHQmOmZvY3VzLXdpdGhpbiB7XHJcblx0XHRib3JkZXItY29sb3I6ICRjb2xvci1uZXh0Z2VuLWdyZWVuO1xyXG5cclxuXHRcdC5maXJzdC1pY29uIHtcclxuXHRcdFx0ZGlzcGxheTogbm9uZTtcclxuXHRcdH1cclxuXHJcblx0XHQuZmlyc3QtaWNvbi5ub24taGlkZGVuIHtcclxuXHRcdFx0ZGlzcGxheTogdGFibGUtY2VsbDtcclxuXHRcdH1cclxuXHR9XHJcblxyXG5cdC5maXJzdC1pY29uIHtcclxuXHRcdHdpZHRoOiAzMnB4O1xyXG5cdFx0dGV4dC1hbGlnbjogY2VudGVyO1xyXG5cdFx0cGFkZGluZy1sZWZ0OiA4cHg7XHJcblxyXG5cdFx0aSB7XHJcblx0XHRcdGZvbnQtc2l6ZTogMjRweCAhaW1wb3J0YW50O1xyXG5cdFx0fVxyXG5cdH1cclxuXHJcblx0LnNlY29uZC1pY29uIHtcclxuXHRcdHdpZHRoOiAzMnB4O1xyXG5cdFx0dGV4dC1hbGlnbjogY2VudGVyO1xyXG5cdFx0Ly8gcGFkZGluZy1yaWdodDogOHB4O1xyXG5cclxuXHRcdGkge1xyXG5cdFx0XHRmb250LXNpemU6IDI0cHggIWltcG9ydGFudDtcclxuXHRcdH1cclxuXHR9XHJcbn1cclxuXHJcbi5jb250cm9sOmZvY3VzLXdpdGhpbiB+IGRpdiAuY29udHJvbC1sYWJlbCB7XHJcblx0Y29sb3I6ICRjb2xvci1uZXh0Z2VuLWdyZWVuO1xyXG59XHJcblxyXG4uY29udHJvbC1lcnJvciB7XHJcblx0LmNvbnRyb2wge1xyXG5cdFx0Ym9yZGVyLWNvbG9yOiAkY29sb3ItbmV4dGdlbi1lcnJvcjtcclxuXHR9XHJcblxyXG5cdC5jb250cm9sLWxhYmVsIHtcclxuXHRcdGNvbG9yOiAkY29sb3ItbmV4dGdlbi1lcnJvciAhaW1wb3J0YW50O1xyXG5cdH1cclxufVxyXG5cclxuLnZhbGlkYXRpb24tc3VtbWFyeSB7XHJcblx0bGkge1xyXG5cdFx0Y29sb3I6ICRjb2xvci1uZXh0Z2VuLWVycm9yICFpbXBvcnRhbnQ7XHJcblx0XHRsaXN0LXN0eWxlOiBub25lO1xyXG5cclxuXHRcdGkge1xyXG5cdFx0XHRjb2xvcjogJGNvbG9yLW5leHRnZW4tZXJyb3IgIWltcG9ydGFudDtcclxuXHRcdH1cclxuXHR9XHJcbn1cclxuXHJcbi5tci0xIHtcclxuXHRtYXJnaW4tcmlnaHQ6IDAuNXJlbTtcclxufVxyXG5cclxuLm1iLTEge1xyXG5cdG1hcmdpbi1ib3R0b206IDAuNXJlbTtcclxufVxyXG5cclxuLmRpYWxvZy1wYW5lIHtcclxuXHRwb3NpdGlvbjogYWJzb2x1dGU7XHJcblx0cG9pbnRlci1ldmVudHM6IGF1dG87XHJcblx0Ym94LXNpemluZzogYm9yZGVyLWJveDtcclxuXHR6LWluZGV4OiAxMDAwO1xyXG5cdGRpc3BsYXk6IGJsb2NrO1xyXG5cdG1heC13aWR0aDogMTAwJTtcclxuXHRtYXgtaGVpZ2h0OiAxMDAlO1xyXG59XHJcblxyXG4ub3ZlcmxheS1iYWNrZHJvcCB7XHJcblx0YmFja2dyb3VuZC1jb2xvcjogJGNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5O1xyXG5cdG9wYWNpdHk6IDAuMiAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4uZGlhbG9nLWNvbnRhaW5lciB7XHJcblx0YW5pbWF0aW9uOiBmYWRlSW4gMC41cyBsaW5lYXI7XHJcblx0YmFja2dyb3VuZC1jb2xvcjogJGNvbG9yLW5leHRnZW4td2hpdGU7XHJcbn1cclxuXHJcbkBrZXlmcmFtZXMgZmFkZUluIHtcclxuXHRmcm9tIHtcclxuXHRcdHRyYW5zZm9ybTogdHJhbnNsYXRlWSgxMDAlKTtcclxuXHR9XHJcblxyXG5cdHRvIHtcclxuXHRcdHRyYW5zZm9ybTogdHJhbnNsYXRlWSgwJSk7XHJcblx0fVxyXG59XHJcblxyXG4uZXJyb3Ige1xyXG5cdGNvbG9yOiAkY29sb3ItbmV4dGdlbi1lcnJvcjtcclxuXHJcblx0Ji5iYWNrZ3JvdW5kIHtcclxuXHRcdGJhY2tncm91bmQtY29sb3I6ICRjb2xvci1uZXh0Z2VuLWVycm9yO1xyXG5cdH1cclxufVxyXG5cclxuLnN1Y2Nlc3Mge1xyXG5cdGNvbG9yOiAkY29sb3ItbmV4dGdlbi1maWJyYW50LWdyZWVuO1xyXG5cclxuXHQmLmJhY2tncm91bmQge1xyXG5cdFx0YmFja2dyb3VuZC1jb2xvcjogJGNvbG9yLW5leHRnZW4tZmlicmFudC1ncmVlbjtcclxuXHR9XHJcbn1cclxuXHJcbi53YXJuaW5nIHtcclxuXHRjb2xvcjogJGNvbG9yLW5leHRnZW4td2FybmluZztcclxuXHJcblx0Ji5iYWNrZ3JvdW5kIHtcclxuXHRcdGJhY2tncm91bmQtY29sb3I6ICRjb2xvci1uZXh0Z2VuLXdhcm5pbmc7XHJcblx0fVxyXG59XHJcblxyXG4uc2VsZWN0IHtcclxuXHR3aWR0aDogMTAwJTtcclxuXHRoZWlnaHQ6IDU0cHg7XHJcblx0Ym9yZGVyOiB1bnNldDtcclxuXHRib3JkZXItcmFkaXVzOiA4cHg7XHJcblx0ZGlzcGxheTogZ3JpZDtcclxuXHRhcHBlYXJhbmNlOiBub25lO1xyXG5cdGdyaWQtdGVtcGxhdGUtYXJlYXM6IFwic2VsZWN0XCI7XHJcblxyXG5cdCY6Zm9jdXMge1xyXG5cdFx0b3V0bGluZTogdW5zZXQ7XHJcblx0fVxyXG59XHJcblxyXG4uY29sb3ItYmxhY2sge1xyXG5cdGNvbG9yOiAkY29sb3ItbmV4dGdlbi1ibGFjaztcclxufVxyXG5cclxuLm1vZGFsLWRlZmF1bHQge1xyXG5cdC0td2lkdGg6IDEwMCU7XHJcblx0LS1oZWlnaHQ6IDEwMCU7XHJcbn1cclxuXHJcbi5pbnRlZ3JhdGlvbi1wYW5lbCB7XHJcblx0d2lkdGg6IDEwMCU7XHJcblx0aGVpZ2h0OiAxMDAlO1xyXG5cdG1heC13aWR0aDogMTAwJSAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4udmVybG9vcC1idXR0b24ge1xyXG5cdHZpc2liaWxpdHk6IGhpZGRlbjtcclxufVxyXG5cclxuLmJhY2stYXJlYSB7XHJcblx0cG9zaXRpb246IGZpeGVkO1xyXG5cdHRvcDogMDtcclxuXHRyaWdodDogMDtcclxuXHRoZWlnaHQ6IDUwcHg7XHJcblx0d2lkdGg6IDEwMCU7XHJcblx0YmFja2dyb3VuZC1jb2xvcjogJGNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTUwO1xyXG5cdHotaW5kZXg6IDk5OTk5OTk7XHJcblxyXG5cdCYuaW9zIHtcclxuXHRcdGhlaWdodDogODBweDtcclxuXHR9XHJcbn1cclxuXHJcbi50aXRsZS13aWRnZXQge1xyXG5cdHRleHQtYWxpZ246IGNlbnRlcjtcclxuXHRwb3NpdGlvbjogc3RpY2t5O1xyXG5cdHRvcDogNDhweDtcclxufVxyXG5cclxuLmJ1dHRvbi1iYWNrIHtcclxuXHRiYWNrZ3JvdW5kLWNvbG9yOiAjZmFmYWZhO1xyXG5cdGhlaWdodDogMzZweDtcclxuXHR3aWR0aDogMzZweDtcclxuXHRib3JkZXItcmFkaXVzOiA1MCU7XHJcblx0cG9zaXRpb246IGFic29sdXRlO1xyXG5cdGxlZnQ6IDE4cHg7XHJcblx0Ym90dG9tOiA0cHg7XHJcbn1cclxuXHJcbi5pY29uLWNsb3NlLXdpZGdldCB7XHJcblx0cG9zaXRpb246IGFic29sdXRlO1xyXG5cdHotaW5kZXg6IDI1MDtcclxuXHRsZWZ0OiAxMXB4O1xyXG5cdGJvdHRvbTogMTNweDtcclxufVxyXG5cclxuLmRhdGEtZGVmYXVsdCB7XHJcblx0cG9zaXRpb246IGFic29sdXRlO1xyXG5cdHRvcDogNTAlO1xyXG5cdGxlZnQ6IDUwJTtcclxuXHR0cmFuc2Zvcm06IHRyYW5zbGF0ZSgtNTAlLCAtNTAlKTtcclxuXHR0ZXh0LWFsaWduOiBjZW50ZXI7XHJcblx0Y29sb3I6ICRjb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS00MDA7XHJcblx0ei1pbmRleDogMTAwMDtcclxufVxyXG5cclxuLmF2YWFtb19faWNvbiB7XHJcblx0dmlzaWJpbGl0eTogaGlkZGVuICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5hdmFhbW9fX2NoYXRfX3dpZGdldC5pb3Mge1xyXG5cdCNhdmFhbW9fX3BvcHVwIHtcclxuXHRcdHBhZGRpbmctdG9wOiA0MHB4O1xyXG5cdH1cclxufVxyXG5cclxuLmQtZmxleCB7XHJcblx0ZGlzcGxheTogZmxleDtcclxufVxyXG5cclxubmV4dGNhcmUtbGF5b3V0IHtcclxuXHRsZWZ0OiAwO1xyXG5cdHJpZ2h0OiAwO1xyXG5cdHRvcDogMDtcclxuXHRib3R0b206IDA7XHJcblx0ZGlzcGxheTogZmxleDtcclxuXHRwb3NpdGlvbjogYWJzb2x1dGU7XHJcblx0ZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxuXHRqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XHJcblx0Y29udGFpbjogbGF5b3V0IHNpemUgc3R5bGU7XHJcblx0b3ZlcmZsb3c6IGhpZGRlbjtcclxuXHRiYWNrZ3JvdW5kLWNvbG9yOiAkY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNTA7XHJcblx0cGFkZGluZy1yaWdodDogMjRweDtcclxuXHRwYWRkaW5nLWxlZnQ6IDI0cHg7XHJcbn1cclxuXHJcbmlvbi1oZWFkZXIuaW9zLmhlYWRlci1pb3Mge1xyXG5cdG1hcmdpbi10b3A6IDQwcHg7XHJcbn1cclxuXHJcbi5oZWFkZXItaW9zIGlvbi10b29sYmFyOmxhc3Qtb2YtdHlwZSB7XHJcblx0LS1ib3JkZXItd2lkdGg6IDBweCAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4uaGVhZGVyLW1kLm1kOjphZnRlciB7XHJcblx0ZGlzcGxheTogbm9uZTtcclxufVxyXG5cclxuaW9uLXRvb2xiYXIge1xyXG5cdHBhZGRpbmctcmlnaHQ6IHVuc2V0ICFpbXBvcnRhbnQ7XHJcblx0cGFkZGluZy1sZWZ0OiB1bnNldCAhaW1wb3J0YW50O1xyXG59XHJcblxyXG5pLmljb24tYmFjayB7XHJcblx0Y29udGVudDogdXJsKGFzc2V0cy9pY29uL2xvbmctYXJyb3ctbGVmdC1pY29uLnN2Zyk7XHJcbn1cclxuXHJcbi52ZXJsb29wLXdpZGdldC5pb3Mge1xyXG5cdC52ZXJsb29wLWNvbnRhaW5lci52aXNpYmxlIHtcclxuXHRcdGhlaWdodDogY2FsYygxMDAlIC0gNDBweCk7XHJcblx0XHR0b3A6IDQwcHg7XHJcblx0fVxyXG59XHJcblxyXG4jbmV4dGNhcmUtYWRzIHtcclxuXHRkaXNwbGF5OiBub25lO1xyXG5cdG92ZXJmbG93OiBzY3JvbGw7XHJcblx0aGVpZ2h0OiAxODBweDtcclxufVxyXG5cclxuLmQtYmxvY2sge1xyXG5cdGRpc3BsYXk6IGJsb2NrO1xyXG59XHJcblxyXG4udGl0bGUtdGV4dCB7XHJcblx0Y29sb3I6ICRjb2xvci1uZXh0Z2VuLWJsdWU7XHJcbn1cclxuXHJcbjpob3N0IGlvbi1kYXRldGltZSAjc2hhZG93LXJvb3Qge1xyXG5cdC5kYXRldGltZS1jYWxlbmRhciB7XHJcblx0XHQuY2FsZW5kYXItaGVhZGVyIHtcclxuXHRcdFx0LmNhbGVuZGFyLWFjdGlvbi1idXR0b25zIHtcclxuXHRcdFx0XHQuY2FsZW5kYXItbW9udGgteWVhciB7XHJcblx0XHRcdFx0XHRhbGlnbi1pdGVtczogY2VudGVyO1xyXG5cdFx0XHRcdFx0anVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcblx0XHRcdFx0XHRkaXNwbGF5OiBmbGV4O1xyXG5cdFx0XHRcdFx0d2lkdGg6IDEwMCU7XHJcblxyXG5cdFx0XHRcdFx0aW9uLWljb24ge1xyXG5cdFx0XHRcdFx0XHRkaXNwbGF5OiBub25lO1xyXG5cdFx0XHRcdFx0fVxyXG5cdFx0XHRcdH1cclxuXHJcblx0XHRcdFx0LmNhbGVuZGFyLW5leHQtcHJldiB7XHJcblx0XHRcdFx0XHRwb3NpdGlvbjogYWJzb2x1dGU7XHJcblx0XHRcdFx0XHR3aWR0aDogMTAwJTtcclxuXHRcdFx0XHRcdHJpZ2h0OiAwO1xyXG5cclxuXHRcdFx0XHRcdGlvbi1idXR0b25zIHtcclxuXHRcdFx0XHRcdFx0ZGlzcGxheTogZmxleDtcclxuXHRcdFx0XHRcdFx0anVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xyXG5cdFx0XHRcdFx0XHR3aWR0aDogMTAwJTtcclxuXHRcdFx0XHRcdH1cclxuXHRcdFx0XHR9XHJcblx0XHRcdH1cclxuXHRcdH1cclxuXHR9XHJcbn1cclxuXHJcbi5tYXQtZGlhbG9nLWNvbnRhaW5lciB7XHJcblx0cGFkZGluZzogdW5zZXQgIWltcG9ydGFudDtcclxufVxyXG5cclxuLyogQ2hhbmdlIGF1dG9jb21wbGV0ZSBzdHlsZXMgaW4gV2ViS2l0ICovXHJcbmlucHV0Oi13ZWJraXQtYXV0b2ZpbGwsXHJcbmlucHV0Oi13ZWJraXQtYXV0b2ZpbGw6aG92ZXIsXHJcbmlucHV0Oi13ZWJraXQtYXV0b2ZpbGw6Zm9jdXMsXHJcbnRleHRhcmVhOi13ZWJraXQtYXV0b2ZpbGwsXHJcbnRleHRhcmVhOi13ZWJraXQtYXV0b2ZpbGw6aG92ZXIsXHJcbnRleHRhcmVhOi13ZWJraXQtYXV0b2ZpbGw6Zm9jdXMsXHJcbnNlbGVjdDotd2Via2l0LWF1dG9maWxsLFxyXG5zZWxlY3Q6LXdlYmtpdC1hdXRvZmlsbDpob3Zlcixcclxuc2VsZWN0Oi13ZWJraXQtYXV0b2ZpbGw6Zm9jdXMge1xyXG5cdC13ZWJraXQtdGV4dC1maWxsLWNvbG9yOiBibGFjaztcclxuXHQtd2Via2l0LWJveC1zaGFkb3c6IDAgMCAwcHggMTAwMHB4IHdoaXRlIGluc2V0O1xyXG5cdHRyYW5zaXRpb246IGJhY2tncm91bmQtY29sb3IgNTAwMHMgZWFzZS1pbi1vdXQgMHM7XHJcbn1cclxuXHJcbi5mb3JjZS11cGRhdGUtcG9wdXAgKyAuY2RrLWdsb2JhbC1vdmVybGF5LXdyYXBwZXIge1xyXG5cdC5zYXZlLWJ0biB7XHJcblx0XHRiYWNrZ3JvdW5kOiB2YXIoLS1sdW1pLXByaW1hcnkteWVsbG93LWNvbG9yKSAhaW1wb3J0YW50O1xyXG5cdFx0Y29sb3I6IHZhcigtLWx1bWktd2hpdGUtY29sb3IpICFpbXBvcnRhbnQ7XHJcblx0XHRmb250LXdlaWdodDogYm9sZCAhaW1wb3J0YW50O1xyXG5cdH1cclxuXHJcblx0LmNhbmNlbC1idG4ge1xyXG5cdFx0Y29sb3I6IHZhcigtLWx1bWktcHJpbWFyeS15ZWxsb3ctY29sb3IpICFpbXBvcnRhbnQ7XHJcblx0fVxyXG59XHJcblxyXG5ALXdlYmtpdC1rZXlmcmFtZXMgc2xpZGVJblJpZ2h0IHtcclxuXHQwJSB7XHJcblx0XHQtd2Via2l0LXRyYW5zZm9ybTogdHJhbnNsYXRlM2QoMTAwJSwgMCwgMCk7XHJcblx0XHR0cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKDEwMCUsIDAsIDApO1xyXG5cdFx0dmlzaWJpbGl0eTogdmlzaWJsZTtcclxuXHR9XHJcblxyXG5cdHRvIHtcclxuXHRcdC13ZWJraXQtdHJhbnNmb3JtOiB0cmFuc2xhdGVaKDApO1xyXG5cdFx0dHJhbnNmb3JtOiB0cmFuc2xhdGVaKDApO1xyXG5cdH1cclxufVxyXG5cclxuQGtleWZyYW1lcyBzbGlkZUluUmlnaHQge1xyXG5cdDAlIHtcclxuXHRcdC13ZWJraXQtdHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgxMDAlLCAwLCAwKTtcclxuXHRcdHRyYW5zZm9ybTogdHJhbnNsYXRlM2QoMTAwJSwgMCwgMCk7XHJcblx0XHR2aXNpYmlsaXR5OiB2aXNpYmxlO1xyXG5cdH1cclxuXHJcblx0dG8ge1xyXG5cdFx0LXdlYmtpdC10cmFuc2Zvcm06IHRyYW5zbGF0ZVooMCk7XHJcblx0XHR0cmFuc2Zvcm06IHRyYW5zbGF0ZVooMCk7XHJcblx0fVxyXG59XHJcblxyXG4uYW5pbWF0ZV9fc2xpZGVJblJpZ2h0IHtcclxuXHQtd2Via2l0LWFuaW1hdGlvbi1uYW1lOiBzbGlkZUluUmlnaHQ7XHJcblx0YW5pbWF0aW9uLW5hbWU6IHNsaWRlSW5SaWdodDtcclxufVxyXG5cclxuLmFuaW1hdGVfX2FuaW1hdGVkIHtcclxuXHQtd2Via2l0LWFuaW1hdGlvbi1kdXJhdGlvbjogMC41cztcclxuXHRhbmltYXRpb24tZHVyYXRpb246IDAuNXM7XHJcblx0LXdlYmtpdC1hbmltYXRpb24tZHVyYXRpb246IDAuNXM7XHJcblx0YW5pbWF0aW9uLWR1cmF0aW9uOiAwLjVzO1xyXG5cdC13ZWJraXQtYW5pbWF0aW9uLWZpbGwtbW9kZTogYm90aDtcclxuXHRhbmltYXRpb24tZmlsbC1tb2RlOiBib3RoO1xyXG59XHJcbiIsIi5kaXNwbGF5LXhsIHtcclxuICAgIGZvbnQtc2l6ZTogNDFweCAhaW1wb3J0YW50O1xyXG4gICAgZm9udC13ZWlnaHQ6IDQwMCAhaW1wb3J0YW50O1xyXG4gICAgbGluZS1oZWlnaHQ6IDEyMCUgIWltcG9ydGFudDtcclxufVxyXG5cclxuLmRpc3BsYXktbWQge1xyXG4gICAgZm9udC1zaXplOiAzNnB4ICFpbXBvcnRhbnQ7XHJcbiAgICBmb250LXdlaWdodDogNDAwICFpbXBvcnRhbnQ7XHJcbiAgICBsaW5lLWhlaWdodDogMTIwJSAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4uaDEge1xyXG4gICAgZm9udC1zaXplOiAzMXB4ICFpbXBvcnRhbnQ7XHJcbiAgICBmb250LXdlaWdodDogNDAwICFpbXBvcnRhbnQ7XHJcbiAgICBsaW5lLWhlaWdodDogMTIwJSAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4uaDIge1xyXG4gICAgZm9udC1zaXplOiAyOHB4ICFpbXBvcnRhbnQ7XHJcbiAgICBmb250LXdlaWdodDogNDAwICFpbXBvcnRhbnQ7XHJcbiAgICBsaW5lLWhlaWdodDogMTIwJSAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4uaDMge1xyXG4gICAgZm9udC1zaXplOiAyNXB4ICFpbXBvcnRhbnQ7XHJcbiAgICBmb250LXdlaWdodDogNDAwICFpbXBvcnRhbnQ7XHJcbiAgICBsaW5lLWhlaWdodDogMTIwJSAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4uaDQge1xyXG4gICAgZm9udC1zaXplOiAyMnB4ICFpbXBvcnRhbnQ7XHJcbiAgICBmb250LXdlaWdodDogNDAwICFpbXBvcnRhbnQ7XHJcbiAgICBsaW5lLWhlaWdodDogMTIwJSAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4uaDUge1xyXG4gICAgZm9udC1zaXplOiAxOXB4ICFpbXBvcnRhbnQ7XHJcbiAgICBmb250LXdlaWdodDogNDAwICFpbXBvcnRhbnQ7XHJcbiAgICBsaW5lLWhlaWdodDogMTIwJSAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4uaDYge1xyXG4gICAgZm9udC1zaXplOiAxN3B4ICFpbXBvcnRhbnQ7XHJcbiAgICBmb250LXdlaWdodDogNDAwICFpbXBvcnRhbnQ7XHJcbiAgICBsaW5lLWhlaWdodDogMTIwJSAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4uYm9keS1sIHtcclxuICAgIGZvbnQtc2l6ZTogMTdweCAhaW1wb3J0YW50O1xyXG4gICAgZm9udC13ZWlnaHQ6IDQwMCAhaW1wb3J0YW50O1xyXG4gICAgbGluZS1oZWlnaHQ6IDEyMCUgIWltcG9ydGFudDtcclxufVxyXG5cclxuLmJvZHktbiB7XHJcbiAgICBmb250LXNpemU6IDE1cHggIWltcG9ydGFudDtcclxuICAgIGZvbnQtd2VpZ2h0OiA0MDAgIWltcG9ydGFudDtcclxuICAgIGxpbmUtaGVpZ2h0OiAxMjAlICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5ib2R5LXNtIHtcclxuICAgIGZvbnQtc2l6ZTogMTNweCAhaW1wb3J0YW50O1xyXG4gICAgZm9udC13ZWlnaHQ6IDQwMCAhaW1wb3J0YW50O1xyXG4gICAgbGluZS1oZWlnaHQ6IDEyMCUgIWltcG9ydGFudDtcclxufVxyXG5cclxuLmJvZHkteHMge1xyXG4gICAgZm9udC1zaXplOiAxMnB4ICFpbXBvcnRhbnQ7XHJcbiAgICBmb250LXdlaWdodDogNDAwICFpbXBvcnRhbnQ7XHJcbiAgICBsaW5lLWhlaWdodDogMTIwJSAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4uc2VtaWJvbGQge1xyXG4gICAgJi5kaXNwbGF5LXhsIHtcclxuICAgICAgICBmb250LXdlaWdodDogNjAwICFpbXBvcnRhbnQ7XHJcbiAgICB9XHJcbiAgICAmLmRpc3BsYXktbWQge1xyXG4gICAgICAgIGZvbnQtd2VpZ2h0OiA2MDAgIWltcG9ydGFudDtcclxuICAgIH1cclxuICAgICYuaDEge1xyXG4gICAgICAgIGZvbnQtd2VpZ2h0OiA2MDAgIWltcG9ydGFudDtcclxuICAgIH1cclxuICAgICYuaDIge1xyXG4gICAgICAgIGZvbnQtd2VpZ2h0OiA2MDAgIWltcG9ydGFudDtcclxuICAgIH1cclxuICAgICYuaDMge1xyXG4gICAgICAgIGZvbnQtd2VpZ2h0OiA2MDAgIWltcG9ydGFudDtcclxuICAgIH1cclxuICAgICYuaDQge1xyXG4gICAgICAgIGZvbnQtd2VpZ2h0OiA2MDAgIWltcG9ydGFudDtcclxuICAgIH1cclxuICAgICYuaDUge1xyXG4gICAgICAgIGZvbnQtd2VpZ2h0OiA2MDAgIWltcG9ydGFudDtcclxuICAgIH1cclxuICAgICYuaDYge1xyXG4gICAgICAgIGZvbnQtd2VpZ2h0OiA2MDAgIWltcG9ydGFudDtcclxuICAgIH1cclxuICAgICYuYm9keS1sIHtcclxuICAgICAgICBmb250LXdlaWdodDogNjAwICFpbXBvcnRhbnQ7XHJcbiAgICB9XHJcbiAgICAmLmJvZHktbiB7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IDYwMCAhaW1wb3J0YW50O1xyXG4gICAgfVxyXG4gICAgJi5ib2R5LXNtIHtcclxuICAgICAgICBmb250LXdlaWdodDogNjAwICFpbXBvcnRhbnQ7XHJcbiAgICB9XHJcbiAgICAmLmJvZHkteHMge1xyXG4gICAgICAgIGZvbnQtd2VpZ2h0OiA2MDAgIWltcG9ydGFudDtcclxuICAgIH1cclxufVxyXG5cclxuLmJvbGQge1xyXG4gICAgJi5kaXNwbGF5LXhsIHtcclxuICAgICAgICBmb250LXdlaWdodDogNzAwICFpbXBvcnRhbnQ7XHJcbiAgICB9XHJcbiAgICAmLmRpc3BsYXktbWQge1xyXG4gICAgICAgIGZvbnQtd2VpZ2h0OiA3MDAgIWltcG9ydGFudDtcclxuICAgIH1cclxuICAgICYuaDEge1xyXG4gICAgICAgIGZvbnQtd2VpZ2h0OiA3MDAgIWltcG9ydGFudDtcclxuICAgIH1cclxuICAgICYuaDIge1xyXG4gICAgICAgIGZvbnQtd2VpZ2h0OiA3MDAgIWltcG9ydGFudDtcclxuICAgIH1cclxuICAgICYuaDMge1xyXG4gICAgICAgIGZvbnQtd2VpZ2h0OiA3MDAgIWltcG9ydGFudDtcclxuICAgIH1cclxuICAgICYuaDQge1xyXG4gICAgICAgIGZvbnQtd2VpZ2h0OiA3MDAgIWltcG9ydGFudDtcclxuICAgIH1cclxuICAgICYuaDUge1xyXG4gICAgICAgIGZvbnQtd2VpZ2h0OiA3MDAgIWltcG9ydGFudDtcclxuICAgIH1cclxuICAgICYuaDYge1xyXG4gICAgICAgIGZvbnQtd2VpZ2h0OiA3MDAgIWltcG9ydGFudDtcclxuICAgIH1cclxuICAgICYuYm9keS1sIHtcclxuICAgICAgICBmb250LXdlaWdodDogNzAwICFpbXBvcnRhbnQ7XHJcbiAgICB9XHJcbiAgICAmLmJvZHktbiB7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IDcwMCAhaW1wb3J0YW50O1xyXG4gICAgfVxyXG4gICAgJi5ib2R5LXNtIHtcclxuICAgICAgICBmb250LXdlaWdodDogNzAwICFpbXBvcnRhbnQ7XHJcbiAgICB9XHJcbiAgICAmLmJvZHkteHMge1xyXG4gICAgICAgIGZvbnQtd2VpZ2h0OiA3MDAgIWltcG9ydGFudDtcclxuICAgIH1cclxufSJdfQ== */";

/***/ }),

/***/ 89785:
/*!********************************************************************************************************************!*\
  !*** ./src/app/pages/home/claims-prescription/prescription-content/prescription-content.component.scss?ngResource ***!
  \********************************************************************************************************************/
/***/ ((module) => {

module.exports = ":root {\n  --nc-color-nextgen-neutral-grey-50: red;\n  --nc-color-nextgen-white: yellow;\n  --nc-color-nextgen-blue: #0d152e;\n  --nc-color-nextgen-green: #00908d;\n  --nc-color-nextgen-black: #000000;\n  --nc-color-nextgen-grey-background: #c8d3da;\n  --nc-color-nextgen-grey: #92a2ac;\n  --nc-color-nextgen-stone-grey: #fafafa;\n  --nc-color-nextgen-error: #fc1055;\n  --nc-color-nextgen-neutral-grey: #414141;\n  --nc-color-nextgen-fibrant-green: #00bab6;\n  --nc-color-nextgen-warning: #ffd048;\n  --nc-color-nextgen-green-background: #e6f2f2;\n  --nc-color-nextgen-neutral-grey-400: #7a7a7a;\n  --nc-color-nextgen-neutral-grey-100: #eff3f5;\n  --nc-color-nextgen-status-error: #ba0c3f;\n  --nc-color-nextgen-status-error-background: #ffeff4;\n  --nc-color-nextgen-status-warning: #cba127;\n  --nc-color-nextgen-status-warning-background: #fff8e6;\n  --nc-color-nextgen-blue-100: #dfeff2;\n  --nc-color-nextgen-error-red-700: #f62459;\n  --nc-color-nextgen-blue-500: #006192;\n  --nc-color-nextgen-blue-400: #79cdec;\n  --nc-color-nextgen-red-500: #ff6592;\n  --nc-color-nextgen-secondary-blue-300: #13a0d3;\n  --lumi-white-color: #ffffff;\n  --lumi-primary-yellow-color: #fab600;\n}\n\n.ion-color-green {\n  --ion-color-base: var(--nc-color-nextgen-green);\n  --ion-color-base-rgb: var(--nc-color-nextgen-green);\n  --ion-color-contrast: var(--nc-color-nextgen-white);\n  --ion-color-contrast-rgb: var(--nc-color-nextgen-green);\n  --ion-color-shade: var(--nc-color-nextgen-green);\n  --ion-color-tint: var(--nc-color-nextgen-green);\n}\n\n.expired {\n  background: var(--nc-color-nextgen-status-error-background);\n  border-radius: 0.125em;\n  color: var(--nc-color-nextgen-status-error);\n  padding: 4px 8px;\n}\n\n.active {\n  background: var(--nc-color-nextgen-green-background);\n  border-radius: 0.125em;\n  color: var(--nc-color-nextgen-fibrant-green);\n  padding: 0.25em 0.5em;\n}\n\n.claim-cards {\n  margin-bottom: 0.6em;\n  background-color: white;\n}\n\n.card-row {\n  display: flex;\n  justify-content: space-between;\n  padding: 0.6em 0 0.6em 0;\n}\n\n.card-row .col-left {\n  text-align: left;\n}\n\n.card-row .col-right {\n  text-align: right;\n}\n\n.card-row .text-content {\n  margin: 0;\n}\n\n.sub-title {\n  color: var(--nc-color-nextgen-neutral-grey-400);\n}\n\n.name {\n  color: var(--nc-color-nextgen-neutral-grey-400);\n}\n\n.type {\n  color: var(--nc-color-nextgen-neutral-grey-400);\n}\n\n.icon-next {\n  color: var(--nc-color-nextgen-green);\n}\n\n.noData {\n  padding-top: 20%;\n  text-align: center;\n  color: var(--nc-color-nextgen-neutral-grey-400);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFwuLlxcY29sb3Iuc2NzcyIsInByZXNjcmlwdGlvbi1jb250ZW50LmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0MsdUNBQUE7RUFDQSxnQ0FBQTtFQUNBLGdDQUFBO0VBQ0EsaUNBQUE7RUFDQSxpQ0FBQTtFQUNBLDJDQUFBO0VBQ0EsZ0NBQUE7RUFDQSxzQ0FBQTtFQUNBLGlDQUFBO0VBQ0Esd0NBQUE7RUFDQSx5Q0FBQTtFQUNBLG1DQUFBO0VBQ0EsNENBQUE7RUFDQSw0Q0FBQTtFQUNBLDRDQUFBO0VBQ0Esd0NBQUE7RUFDQSxtREFBQTtFQUNBLDBDQUFBO0VBQ0EscURBQUE7RUFDQSxvQ0FBQTtFQUNBLHlDQUFBO0VBQ0Esb0NBQUE7RUFDQSxvQ0FBQTtFQUNBLG1DQUFBO0VBQ0EsOENBQUE7RUFFQSwyQkFBQTtFQUNBLG9DQUFBO0FDQUQ7O0FEZ0NBO0VBQ0MsK0NBQUE7RUFDQSxtREFBQTtFQUNBLG1EQUFBO0VBQ0EsdURBQUE7RUFDQSxnREFBQTtFQUNBLCtDQUFBO0FDN0JEOztBQW5DQTtFQUNFLDJERDJDc0M7RUMxQ3RDLHNCQUFBO0VBQ0EsMkNEd0MyQjtFQ3ZDM0IsZ0JBQUE7QUFzQ0Y7O0FBcENBO0VBQ0Usb0REZ0MrQjtFQy9CL0Isc0JBQUE7RUFDQSw0Q0Q0QjRCO0VDM0I1QixxQkFBQTtBQXVDRjs7QUFyQ0E7RUFDRSxvQkFBQTtFQUNBLHVCQUFBO0FBd0NGOztBQXJDQTtFQUNFLGFBQUE7RUFDQSw4QkFBQTtFQUNBLHdCQUFBO0FBd0NGOztBQXZDRTtFQUNFLGdCQUFBO0FBeUNKOztBQXZDRTtFQUNFLGlCQUFBO0FBeUNKOztBQXRDRTtFQUNFLFNBQUE7QUF3Q0o7O0FBcENBO0VBQ0UsK0NETytCO0FDZ0NqQzs7QUFwQ0E7RUFDRSwrQ0RHK0I7QUNvQ2pDOztBQXBDQTtFQUNFLCtDREQrQjtBQ3dDakM7O0FBcENBO0VBQ0Usb0NEakJvQjtBQ3dEdEI7O0FBckNBO0VBQ0UsZ0JBQUE7RUFDQSxrQkFBQTtFQUNBLCtDRFYrQjtBQ2tEakMiLCJmaWxlIjoicHJlc2NyaXB0aW9uLWNvbnRlbnQuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyI6cm9vdCB7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS01MDogcmVkO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi13aGl0ZTogeWVsbG93O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlOiAjMGQxNTJlO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbjogIzAwOTA4ZDtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tYmxhY2s6ICMwMDAwMDA7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWdyZXktYmFja2dyb3VuZDogI2M4ZDNkYTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tZ3JleTogIzkyYTJhYztcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc3RvbmUtZ3JleTogI2ZhZmFmYTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tZXJyb3I6ICNmYzEwNTU7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleTogIzQxNDE0MTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tZmlicmFudC1ncmVlbjogIzAwYmFiNjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4td2FybmluZzogI2ZmZDA0ODtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4tYmFja2dyb3VuZDogI2U2ZjJmMjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTQwMDogIzdhN2E3YTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTEwMDogI2VmZjNmNTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yOiAjYmEwYzNmO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtZXJyb3ItYmFja2dyb3VuZDogI2ZmZWZmNDtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLXdhcm5pbmc6ICNjYmExMjc7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy13YXJuaW5nLWJhY2tncm91bmQ6ICNmZmY4ZTY7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWJsdWUtMTAwOiAjZGZlZmYyO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1lcnJvci1yZWQtNzAwOiAjZjYyNDU5O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlLTUwMDogIzAwNjE5MjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZS00MDA6ICM3OWNkZWM7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXJlZC01MDA6ICNmZjY1OTI7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXNlY29uZGFyeS1ibHVlLTMwMDogIzEzYTBkMztcclxuXHJcblx0LS1sdW1pLXdoaXRlLWNvbG9yOiAjZmZmZmZmO1xyXG5cdC0tbHVtaS1wcmltYXJ5LXllbGxvdy1jb2xvcjogI2ZhYjYwMDtcclxufVxyXG4kY29sb3ItbmV4dGdlbi1ibHVlOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWJsdWUpO1xyXG4kY29sb3ItbmV4dGdlbi1ncmVlbjogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbik7XHJcbiRjb2xvci1uZXh0Z2VuLXdoaXRlOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXdoaXRlKTtcclxuJGNvbG9yLW5leHRnZW4tYmxhY2s6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tYmxhY2spO1xyXG4kY29sb3ItbmV4dGdlbi1ncmV5LWJhY2tncm91bmQ6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JleS1iYWNrZ3JvdW5kKTtcclxuJGNvbG9yLW5leHRnZW4tZ3JleTogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmV5KTtcclxuJGNvbG9yLW5leHRnZW4tc3RvbmUtZ3JleTogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1zdG9uZS1ncmV5KTtcclxuJGNvbG9yLW5leHRnZW4tZXJyb3I6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZXJyb3IpO1xyXG4kY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXk6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5KTtcclxuJGNvbG9yLW5leHRnZW4tZmlicmFudC1ncmVlbjogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1maWJyYW50LWdyZWVuKTtcclxuJGNvbG9yLW5leHRnZW4td2FybmluZzogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi13YXJuaW5nKTtcclxuJGNvbG9yLW5leHRnZW4tZ3JlZW4tYmFja2dyb3VuZDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbi1iYWNrZ3JvdW5kKTtcclxuJGNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTUwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS01MCk7XHJcbiRjb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS00MDA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTQwMCk7XHJcbiRjb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS0xMDA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTEwMCk7XHJcbiRjb2xvci1uZXh0Z2VuLXN0YXR1cy1lcnJvcjogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtZXJyb3IpO1xyXG4kY29sb3ItbmV4dGdlbi1zdGF0dXMtZXJyb3ItYmFja2dyb3VuZDogdmFyKFxyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtZXJyb3ItYmFja2dyb3VuZFxyXG4pO1xyXG4kY29sb3ItbmV4dGdlbi1zdGF0dXMtd2FybmluZzogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtd2FybmluZyk7XHJcbiRjb2xvci1uZXh0Z2VuLXN0YXR1cy13YXJuaW5nLWJhY2tncm91bmQ6IHZhcihcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLXdhcm5pbmctYmFja2dyb3VuZFxyXG4pO1xyXG4kY29sb3ItbmV4dGdlbi1ibHVlLTEwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlLTEwMCk7XHJcbiRjb2xvci1uZXh0Z2VuLWVycm9yLXJlZC03MDA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZXJyb3ItcmVkLTcwMCk7XHJcbiRjb2xvci1uZXh0Z2VuLWJsdWUtNTAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWJsdWUtNTAwKTtcclxuJGNvbG9yLW5leHRnZW4tYmx1ZS00MDA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZS00MDApO1xyXG4kY29sb3ItbmV4dGdlbi1yZWQtNTAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXJlZC01MDApO1xyXG4kY29sb3ItbmV4dGdlbi1zZWNvbmRhcnktYmx1ZS0zMDA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tc2Vjb25kYXJ5LWJsdWUtMzAwKTtcclxuXHJcbi5pb24tY29sb3ItZ3JlZW4ge1xyXG5cdC0taW9uLWNvbG9yLWJhc2U6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4pO1xyXG5cdC0taW9uLWNvbG9yLWJhc2UtcmdiOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuKTtcclxuXHQtLWlvbi1jb2xvci1jb250cmFzdDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi13aGl0ZSk7XHJcblx0LS1pb24tY29sb3ItY29udHJhc3QtcmdiOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuKTtcclxuXHQtLWlvbi1jb2xvci1zaGFkZTogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbik7XHJcblx0LS1pb24tY29sb3ItdGludDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbik7XHJcbn1cclxuIiwiQGltcG9ydCAnLi4vLi4vLi4vLi4vLi4vY29sb3Iuc2Nzcyc7XHJcblxyXG4uZXhwaXJlZCB7XHJcbiAgYmFja2dyb3VuZDogJGNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yLWJhY2tncm91bmQ7XHJcbiAgYm9yZGVyLXJhZGl1czogMC4xMjVlbTtcclxuICBjb2xvcjogJGNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yO1xyXG4gIHBhZGRpbmc6IDRweCA4cHg7XHJcbn1cclxuLmFjdGl2ZSB7XHJcbiAgYmFja2dyb3VuZDogJGNvbG9yLW5leHRnZW4tZ3JlZW4tYmFja2dyb3VuZDtcclxuICBib3JkZXItcmFkaXVzOiAwLjEyNWVtO1xyXG4gIGNvbG9yOiAkY29sb3ItbmV4dGdlbi1maWJyYW50LWdyZWVuO1xyXG4gIHBhZGRpbmc6IDAuMjVlbSAwLjVlbTtcclxufVxyXG4uY2xhaW0tY2FyZHMge1xyXG4gIG1hcmdpbi1ib3R0b206IDAuNmVtO1xyXG4gIGJhY2tncm91bmQtY29sb3I6IHdoaXRlO1xyXG59XHJcblxyXG4uY2FyZC1yb3cge1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xyXG4gIHBhZGRpbmc6IDAuNmVtIDAgMC42ZW0gMDtcclxuICAuY29sLWxlZnQge1xyXG4gICAgdGV4dC1hbGlnbjogbGVmdDtcclxuICB9XHJcbiAgLmNvbC1yaWdodCB7XHJcbiAgICB0ZXh0LWFsaWduOiByaWdodDtcclxuICB9XHJcblxyXG4gIC50ZXh0LWNvbnRlbnQge1xyXG4gICAgbWFyZ2luOiAwO1xyXG4gIH1cclxufVxyXG5cclxuLnN1Yi10aXRsZSB7XHJcbiAgY29sb3I6ICRjb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS00MDA7XHJcbn1cclxuXHJcbi5uYW1lIHtcclxuICBjb2xvcjogJGNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTQwMDtcclxufVxyXG5cclxuLnR5cGUge1xyXG4gIGNvbG9yOiAkY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNDAwO1xyXG59XHJcblxyXG4uaWNvbi1uZXh0IHtcclxuICBjb2xvcjogJGNvbG9yLW5leHRnZW4tZ3JlZW47XHJcbn1cclxuLm5vRGF0YXtcclxuICBwYWRkaW5nLXRvcDoyMCU7XHJcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gIGNvbG9yOiAkY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNDAwO1xyXG59Il19 */";

/***/ }),

/***/ 18181:
/*!*****************************************************************************************!*\
  !*** ./src/app/pages/home/claims-prescription/claims-prescription.page.html?ngResource ***!
  \*****************************************************************************************/
/***/ ((module) => {

module.exports = "<div class=\"prescription-container\">\r\n  <nextcare-layout>\r\n    <ng-template header>\r\n      <ion-row>\r\n        <ion-col size=\"2\" class=\"d-flex\">\r\n          <button class=\"btn btn-circle\" (click)=\"onBack()\">\r\n            <ion-icon  class=\"icon-back body-l\" name=\"arrow-back-outline\"></ion-icon>\r\n          </button>\r\n        </ion-col>\r\n        <ion-col size=\"8\" class=\"row\">\r\n          <span (click)=\"refreshReferralHistory()\" class=\"title-text h6 bold\">{{'prescriptionClaim.title' | translate}}</span>\r\n        </ion-col>\r\n        <ion-col size=\"2\">\r\n        </ion-col>\r\n      </ion-row>\r\n    </ng-template>\r\n\r\n    <ng-template body>\r\n      <ion-content mode=\"ios\" scrollEvents=\"true\" (ionScrollEnd)=\"logScrolling()\">\r\n        <div class=\"prescription-container\">\r\n          <!-- <ion-segment class=\"segment\" (ionChange)=\"segmentChanged($event)\" value=\"referral\">\r\n            <ion-segment-button class=\"segment-button body-n\" value=\"referral\">\r\n              <ion-label>{{ 'prescriptionClaim.referral'| translate }}</ion-label>\r\n            </ion-segment-button>\r\n            <ion-segment-button class=\"segment-button body-n\" value=\"prescription\">\r\n              <ion-label>{{ 'prescriptionClaim.prescription'| translate }}</ion-label>\r\n            </ion-segment-button>\r\n          </ion-segment> -->\r\n\r\n          <!-- search-hisoty component  -->\r\n          <!-- <div class=\"inputSearch\"> -->\r\n            <!-- <app-history-search screen=\"prescription\" [placeholder]=\"'symptomChecker.search'| translate\"\r\n              (onSearchChange)=\"onSearchChange($event)\" [showFilterCount]=\"true\" [listFilter]=\"listFilter\"\r\n              *ngIf=\"listFilter\"></app-history-search>\r\n          </div> -->\r\n\r\n          <div class=\"claim-title\">\r\n            <ion-label class=\"body-l bold\" [ngSwitch]=\"tab\">\r\n              <!-- <span class=\"body-l bold\" *ngSwitchCase=\"'prescription'\">{{ 'prescriptionClaim.prescriptionTitle'|\r\n                translate }}</span> -->\r\n              <span class=\"body-l bold\" *ngSwitchDefault>\r\n                {{ 'prescriptionClaim.referralsTitle'| translate }}</span>\r\n            </ion-label>\r\n          </div>\r\n          <div class=\"inputSearch\">\r\n            <!-- search-hisoty component  -->\r\n            <app-history-search [placeholder]=\"'prescriptionClaim.placeholderSearch'| translate\" *ngIf=\"listFilter\"\r\n              [showFilterCount]=\"false\" [listFilter]=\"listFilter\" [showResetButton] = \"false\" (onSearchChange)=\"onSearchChange($event)\"></app-history-search>\r\n          </div>\r\n          <!-- history-contents component  -->\r\n          <app-prescription-content [details]=\"details\" [type]=\"tab\"></app-prescription-content>\r\n        </div>\r\n      </ion-content>\r\n    </ng-template>\r\n  </nextcare-layout>\r\n</div>";

/***/ }),

/***/ 19638:
/*!********************************************************************************************************************!*\
  !*** ./src/app/pages/home/claims-prescription/prescription-content/prescription-content.component.html?ngResource ***!
  \********************************************************************************************************************/
/***/ ((module) => {

module.exports = "<ion-card class=\"claim-cards\" *ngFor=\"let detail of details;  trackBy:trackById\" trackBy:detailById >\r\n  <ion-card-content  >\r\n      <ion-grid>\r\n          <ion-row class=\"card-row\">\r\n            <div class=\"col-left\">\r\n                <div [ngSwitch]=\"type\">\r\n                    <ion-text class=\"body-sm name\" *ngSwitchDefault> {{'claimDetailReferral.referral' | translate}} </ion-text>\r\n                    <ion-text class=\"body-sm name\" *ngSwitchCase=\"'prescription'\">{{'claimDetailReferral.prescription' | translate}}</ion-text>\r\n                    <h6 class=\"text-content body-n bold color-black\">{{ detail.erxreferenceNbr }}</h6>\r\n                </div>\r\n            </div>\r\n            <div class=\"col-right\">\r\n                <div>\r\n                    <ion-label class=\"body-xs\"  [ngClass]=\"detail.active?'active':'expired'\"> {{detail.active?'Active':'Expired'}}\r\n                    </ion-label>\r\n                </div>\r\n            </div>\r\n        </ion-row>\r\n\r\n          <ion-row class=\"card-row\">\r\n              <div class=\"col-left\">\r\n                  <div>\r\n                    <ion-text class=\"body-sm name\">{{'claimDetailReferral.member' | translate}}</ion-text>\r\n                    <h6 class=\"text-content body-n bold color-black\">{{ detail?.benefFullName ??detail.beneficiaryId.toString()|replaceMySelf |translate}}</h6>\r\n                    \r\n                  </div>\r\n              </div>\r\n              <div class=\"col-right\">\r\n                  <div [ngSwitch]=\"type\"> \r\n                    <ion-text class=\"body-sm type\" *ngSwitchDefault>{{'claimDetailReferral.validUntil' | translate}}</ion-text>\r\n                    <ion-text class=\"body-sm type\" *ngSwitchCase=\"'prescription'\">{{'claimDetailReferral.date' | translate}}</ion-text>\r\n                    <h6 class=\"text-content body-n bold color-black\">{{ detail.expiryDate| date:'dd MMMM yyyy'}}</h6>\r\n                  </div>\r\n              </div>\r\n          </ion-row>\r\n          <ion-row class=\"card-row\">\r\n            <ion-col [ngSwitch]=\"type\">\r\n                <ion-text class=\"body-sm sub-title\" >{{'claimDetailReferral.numberOfUser' | translate}} </ion-text>\r\n                <h6 class=\"text-content body-l bold color-black\">{{ detail.remainingEreferral}}/{{ detail.allowedUtilizationFrequency }}</h6>\r\n               \r\n            </ion-col>\r\n        </ion-row>\r\n          <ion-row class=\"card-row\">\r\n            <ion-col [ngSwitch]=\"type\">\r\n                <ion-text class=\"body-sm sub-title\" *ngSwitchDefault>{{'claimDetailReferral.referred' | translate}} </ion-text>\r\n                <ion-text class=\"body-sm sub-title\" *ngSwitchCase=\"'prescription'\">{{'claimDetailReferral.doctor' | translate}}</ion-text>\r\n                <h6 class=\"text-content body-l bold color-black\">{{ detail?.physician?.physicianName}}</h6>\r\n               \r\n            </ion-col>\r\n        </ion-row>\r\n        <ion-row class=\"card-row\">\r\n          <ion-col [ngSwitch]=\"type\">\r\n              <ion-text class=\"body-sm sub-title\">{{'claimDetailReferral.specialty' | translate}} </ion-text>\r\n              <h6 class=\"text-content body-l bold color-black\">{{ detail.referringSpecialtyRefDesc}}</h6>\r\n             \r\n          </ion-col>\r\n      </ion-row>     \r\n            \r\n      </ion-grid>      \r\n      <ion-row class=\"card-row\" *ngIf=\"detail.active\">\r\n        <ion-col [ngSwitch]=\"type\">\r\n          <button  [hidden]=\"!bookApointmentBtn\" class=\"btn primary secondary\"  *ngSwitchDefault (click)=\"onBookApointment()\" >{{'claimDetailReferral.bookAnAppointment' | translate}} <i class=\"uil uil-arrow-right body-l icon-next\"></i></button>\r\n          <button [hidden]=\"orderOnlineBtn == false\" class=\"btn primary secondary\"  (click)=\"onOrderOnline()\" *ngSwitchCase=\"'prescription'\" >{{'claimDetailReferral.buttonOrderOnline' | translate}} <i class=\"uil uil-arrow-right body-l icon-next\"></i></button>\r\n        </ion-col>\r\n      </ion-row>\r\n  </ion-card-content>\r\n</ion-card>\r\n\r\n<div class=\"noData\" *ngIf=\"!details || details.length === 0\" [ngSwitch]=\"type\">\r\n  <ion-text *ngSwitchDefault class=\"body-l\">{{ 'prescriptionClaim.dataDefaultReferral' | translate}}</ion-text>\r\n  <ion-text *ngSwitchCase=\"'prescription'\" class=\"body-l\">{{ 'prescriptionClaim.dataDefaultPrescription' | translate}}</ion-text>\r\n</div>";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_home_claims-prescription_claims-prescription_module_ts.js.map