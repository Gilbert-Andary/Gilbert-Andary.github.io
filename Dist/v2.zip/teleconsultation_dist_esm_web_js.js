"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["teleconsultation_dist_esm_web_js"],{

/***/ 40078:
/*!******************************************!*\
  !*** ./teleconsultation/dist/esm/web.js ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TeleconsultationWeb": () => (/* binding */ TeleconsultationWeb)
/* harmony export */ });
/* harmony import */ var C_Users_Gilbert_Andary_Desktop_Workspace_mynextcarev3_3_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 71670);
/* harmony import */ var _capacitor_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @capacitor/core */ 72155);


class TeleconsultationWeb extends _capacitor_core__WEBPACK_IMPORTED_MODULE_1__.WebPlugin {
  echo(options) {
    return (0,C_Users_Gilbert_Andary_Desktop_Workspace_mynextcarev3_3_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      console.log('ECHO', options);
      return options;
    })();
  }

  openHahconnectSdk(_options) {
    return (0,C_Users_Gilbert_Andary_Desktop_Workspace_mynextcarev3_3_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      console.log('Start Customer consultation: ');
    })();
  }

  openHahconnectFromNofify(_options) {
    return (0,C_Users_Gilbert_Andary_Desktop_Workspace_mynextcarev3_3_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      console.log('Start Customer consultation: ');
    })();
  }

}

/***/ })

}]);
//# sourceMappingURL=teleconsultation_dist_esm_web_js.js.map