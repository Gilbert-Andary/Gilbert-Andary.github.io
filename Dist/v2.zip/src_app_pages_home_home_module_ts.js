"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_home_home_module_ts"],{

/***/ 85176:
/*!****************************************************************************!*\
  !*** ./src/app/pages/home/claims-history/claims-history-routing.module.ts ***!
  \****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ClaimsHistoryPageRoutingModule": () => (/* binding */ ClaimsHistoryPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _claims_history_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./claims-history.page */ 31162);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);




const routes = [
    {
        path: '',
        component: _claims_history_page__WEBPACK_IMPORTED_MODULE_0__.ClaimsHistoryPage,
    },
];
let ClaimsHistoryPageRoutingModule = class ClaimsHistoryPageRoutingModule {
};
ClaimsHistoryPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], ClaimsHistoryPageRoutingModule);



/***/ }),

/***/ 22702:
/*!********************************************************************!*\
  !*** ./src/app/pages/home/claims-history/claims-history.module.ts ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ClaimsHistoryPageModule": () => (/* binding */ ClaimsHistoryPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _claims_history_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./claims-history.page */ 31162);
/* harmony import */ var _claims_history_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./claims-history-routing.module */ 85176);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _history_content_history_content_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./history-content/history-content.component */ 93817);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_cdk_scrolling__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/cdk/scrolling */ 95752);
/* harmony import */ var src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/shared/shared.module */ 44466);
/* harmony import */ var _claim_details_upload_missing_docs_upload_missing_docs_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./claim-details/upload-missing-docs/upload-missing-docs.component */ 22032);






// import { HistorySearchComponent } from '../../../shared/components/history-search/history-search.component';





let ClaimsHistoryPageModule = class ClaimsHistoryPageModule {
};
ClaimsHistoryPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_7__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_8__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.IonicModule,
            src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_3__.SharedModule,
            _angular_cdk_scrolling__WEBPACK_IMPORTED_MODULE_10__.ScrollingModule,
            _claims_history_routing_module__WEBPACK_IMPORTED_MODULE_1__.ClaimsHistoryPageRoutingModule
        ],
        declarations: [
            _claims_history_page__WEBPACK_IMPORTED_MODULE_0__.ClaimsHistoryPage,
            _history_content_history_content_component__WEBPACK_IMPORTED_MODULE_2__.HistoryContentComponent,
            // HistorySearchComponent,
            _claim_details_upload_missing_docs_upload_missing_docs_component__WEBPACK_IMPORTED_MODULE_4__.UploadMissingDocsComponent
        ],
    })
], ClaimsHistoryPageModule);



/***/ }),

/***/ 31162:
/*!******************************************************************!*\
  !*** ./src/app/pages/home/claims-history/claims-history.page.ts ***!
  \******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ClaimsHistoryPage": () => (/* binding */ ClaimsHistoryPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _claims_history_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./claims-history.page.html?ngResource */ 6954);
/* harmony import */ var _claims_history_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./claims-history.page.scss?ngResource */ 59181);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _awesome_cordova_plugins_clevertap_ngx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @awesome-cordova-plugins/clevertap/ngx */ 45363);
/* harmony import */ var _awesome_cordova_plugins_firebase_analytics_ngx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @awesome-cordova-plugins/firebase-analytics/ngx */ 48852);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @environments/environment */ 92340);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! @ionic/storage-angular */ 80190);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! rxjs */ 92218);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! rxjs/operators */ 85921);
/* harmony import */ var src_app_providers_common_loading_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/providers/common/loading.service */ 90574);
/* harmony import */ var src_app_service_cms_search_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/service/cms/search.service */ 81563);
/* harmony import */ var src_app_service_home_history_claims_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/service/home/history-claims.service */ 89224);
/* harmony import */ var src_app_service_insurance_insurance_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/service/insurance/insurance.service */ 57072);
/* harmony import */ var src_app_service_new_claim_consent_consent_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/service/new-claim/consent/consent.service */ 41413);
/* harmony import */ var src_app_service_new_claim_new_claim_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/app/service/new-claim/new-claim.service */ 90888);
/* harmony import */ var src_app_service_new_re_approval_new_pre_approval_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/app/service/new-re-approval/new-pre-approval.service */ 80518);
/* harmony import */ var src_app_shared_components_nextgen_dialog_nextgen_dialog_service__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! src/app/shared/components/nextgen-dialog/nextgen-dialog.service */ 96485);
/* harmony import */ var src_app_shared_components_popup_message_popup_message_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! src/app/shared/components/popup-message/popup-message.component */ 18290);
/* harmony import */ var src_app_shared_components_privacy_consent_dialog_privacy_consent_dialog_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! src/app/shared/components/privacy-consent-dialog/privacy-consent-dialog.component */ 61262);
/* harmony import */ var _awesome_cordova_plugins_app_rate_ngx__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @awesome-cordova-plugins/app-rate/ngx */ 86607);
/* harmony import */ var src_app_service_utilities_third_party_service__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! src/app/service/utilities/third-party.service */ 47617);
/* harmony import */ var src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! src/app/shared/data/constants */ 74676);
/* harmony import */ var src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! src/app/shared/data/enum/event */ 38570);
/* harmony import */ var src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! src/app/shared/data/enum/screen */ 68302);



























// import { CurrencyList } from 'src/app/shared/data/currencyList';
let ClaimsHistoryPage = class ClaimsHistoryPage {
    constructor(router, route, insuranceService, searchService, firebaseAnalytics, historyClaimsService, newClaimService, newPreApprovalService, clevertap, dialogService, consentService, platform, apprate, storage, thirdPartyService, loadingService) {
        var _a, _b, _c;
        this.router = router;
        this.route = route;
        this.insuranceService = insuranceService;
        this.searchService = searchService;
        this.firebaseAnalytics = firebaseAnalytics;
        this.historyClaimsService = historyClaimsService;
        this.newClaimService = newClaimService;
        this.newPreApprovalService = newPreApprovalService;
        this.clevertap = clevertap;
        this.dialogService = dialogService;
        this.consentService = consentService;
        this.platform = platform;
        this.apprate = apprate;
        this.storage = storage;
        this.thirdPartyService = thirdPartyService;
        this.loadingService = loadingService;
        this.details = [];
        this.status = src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_17__.Constants.CLAIM_STATUS;
        this.additionalStatus = src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_17__.Constants.ADDITIONAL_STATUS;
        this.bundleName = _environments_environment__WEBPACK_IMPORTED_MODULE_4__.environment.Apn;
        this.appIdIOS = _environments_environment__WEBPACK_IMPORTED_MODULE_4__.environment.isi;
        this.paging = {
            pageNo: 1,
            pageSize: 5,
            pageCount: null,
        };
        this.unsubscribe$ = new rxjs__WEBPACK_IMPORTED_MODULE_20__.Subject();
        this.tab = 5;
        this.recentlyServiceType = (_c = (_b = (_a = this.route) === null || _a === void 0 ? void 0 : _a.snapshot) === null || _b === void 0 ? void 0 : _b.data) === null || _c === void 0 ? void 0 : _c.recentlyServiceType;
    }
    get isOpen() {
        return this.searchService.getIsOpen();
    }
    set isOpen(value) {
        this.searchService.setIsOpen(value);
    }
    ngOnInit() {
    }
    ionViewWillLeave() {
        this.unsubscribe$.next();
        this.unsubscribe$.complete();
        this.subscription.unsubscribe();
    }
    ionViewDidEnter() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__awaiter)(this, void 0, void 0, function* () {
            const isShowRatingApp = yield this.storage.get(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_17__.Constants.SHOW_RATING_APP);
            this.platform.ready().then(() => {
                if (isShowRatingApp == true) {
                    this.rateMyApp(this.bundleName, this.appIdIOS);
                }
            });
            this.loadingService.dismissLoading();
            this.subscription = this.platform.backButton.subscribeWithPriority(9999, () => (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__awaiter)(this, void 0, void 0, function* () {
                if (this.tab == 4) {
                    if (this.isOpen == true) {
                        this.isOpen = false;
                    }
                    else {
                        this.tab = 5;
                    }
                }
                else if (this.isOpen == true) {
                    this.isOpen = false;
                }
                else {
                    this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_19__.Screens.Home]);
                }
            }));
        });
    }
    loadDraftClaim() {
        var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r, _s, _t, _u, _v, _w, _x;
        return (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__awaiter)(this, void 0, void 0, function* () {
            const submitClaim = yield this.newClaimService.getLocalStorageSubmitClaim();
            if (submitClaim) {
                this.draftClaim = {
                    className: 'abc',
                    status: 'Draft',
                    beneficiaryName: (_b = (_a = submitClaim.detailForm) === null || _a === void 0 ? void 0 : _a.memberSelect) === null || _b === void 0 ? void 0 : _b.name,
                    treatmentName: (_d = (_c = submitClaim.detailForm) === null || _c === void 0 ? void 0 : _c.serviceType) === null || _d === void 0 ? void 0 : _d.name,
                    declarationDate: (_e = submitClaim.detailForm) === null || _e === void 0 ? void 0 : _e.serviceDate,
                    providerName: ((_f = submitClaim.addressControl) === null || _f === void 0 ? void 0 : _f.street) != undefined && ((_g = submitClaim === null || submitClaim === void 0 ? void 0 : submitClaim.addressControl) === null || _g === void 0 ? void 0 : _g.city) != undefined
                        ? ((_h = submitClaim.addressControl) === null || _h === void 0 ? void 0 : _h.street) + ', ' + ((_j = submitClaim === null || submitClaim === void 0 ? void 0 : submitClaim.addressControl) === null || _j === void 0 ? void 0 : _j.city)
                        : '',
                    claimCurrency: (_l = (_k = submitClaim.detailForm) === null || _k === void 0 ? void 0 : _k.currency) === null || _l === void 0 ? void 0 : _l.name,
                    paidAmount: (_m = submitClaim.detailForm) === null || _m === void 0 ? void 0 : _m.amount,
                };
            }
            else {
                this.draftClaim = null;
            }
            const submitPre = yield this.newPreApprovalService.getLocalStorageSubmitPre();
            if (submitPre) {
                this.draftPre = {
                    className: 'abc',
                    status: 'Draft',
                    beneficiaryName: (_p = (_o = submitPre.detailForm) === null || _o === void 0 ? void 0 : _o.memberSelect) === null || _p === void 0 ? void 0 : _p.name,
                    treatmentName: (_r = (_q = submitPre.detailForm) === null || _q === void 0 ? void 0 : _q.serviceType) === null || _r === void 0 ? void 0 : _r.name,
                    providerName: ((_t = (_s = submitPre.detailForm) === null || _s === void 0 ? void 0 : _s.healthcareProvider) === null || _t === void 0 ? void 0 : _t.addressCountryName) != undefined ? (_v = (_u = submitPre.detailForm) === null || _u === void 0 ? void 0 : _u.healthcareProvider) === null || _v === void 0 ? void 0 : _v.addressCountryName : '',
                    declarationDate: (_w = submitPre.detailForm) === null || _w === void 0 ? void 0 : _w.serviceDate,
                    claimCurrency: (_x = submitPre.detailForm.currency) === null || _x === void 0 ? void 0 : _x.name,
                };
            }
            else {
                this.draftPre = null;
            }
        });
    }
    ionViewWillEnter() {
        this.unsubscribe$ = new rxjs__WEBPACK_IMPORTED_MODULE_20__.Subject();
        this.getUserPolicyInformation();
        this.details = [];
        this.paging = {
            pageNo: 1,
            pageSize: 5,
            pageCount: null,
        };
    }
    rateMyApp(bundleName, appId) {
        this.apprate.setPreferences({
            displayAppName: 'Lumi by Nextcare',
            usesUntilPrompt: 5,
            promptAgainForEachNewVersion: false,
            simpleMode: true,
            storeAppURL: {
                ios: `${appId}`,
                android: `market://details?id=${bundleName}`,
            },
            reviewType: {
                ios: _awesome_cordova_plugins_app_rate_ngx__WEBPACK_IMPORTED_MODULE_15__.AppRateReviewTypeIos.InAppReview,
                android: _awesome_cordova_plugins_app_rate_ngx__WEBPACK_IMPORTED_MODULE_15__.AppRateReviewTypeAndroid.InAppReview,
            },
            customLocale: {
                title: 'Would you mind rating %@?',
                message: `It won’t take more than a minute and helps to promote our app. Thanks for your support!`,
                cancelButtonLabel: 'No, Thanks',
                rateButtonLabel: 'Rate It Now',
                yesButtonLabel: 'Yes!',
                noButtonLabel: 'Not really',
                appRatePromptTitle: 'Do you like using %@',
                feedbackPromptTitle: 'Mind giving us some feedback?',
            },
            callbacks: {
                onButtonClicked(buttonIndex, buttonLabel, promptType) {
                    console.log('buttonIndex', buttonIndex);
                    console.log('buttonLabel', buttonLabel);
                    console.log('promptType', promptType);
                },
                onRateDialogShow(buttonIndex) {
                    console.log(buttonIndex);
                },
            },
        });
        this.apprate.promptForRating(true);
        this.storage.set(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_17__.Constants.DISABLE_POPUP_RATING, true);
        this.storage.set(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_17__.Constants.SHOW_RATING_APP, false);
    }
    getUserPolicyInformation() {
        this.insuranceService
            .getPolicyInformation()
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_22__.takeUntil)(this.unsubscribe$))
            .subscribe((res) => {
            if (!res)
                return;
            this.listFilter = null;
            this.filterNotUsed = this.insuranceService.checkPayerSetting(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_17__.Constants.SHOW_NOTUSED_CLAIMS, true);
            // const columnname = this.payerSetting?.find(res => res.columnname === 'MyNCShowNotusedclaims');
            // if (columnname && columnname.required === true) {
            //   this.filterNotUsed = true;
            // } else {
            //   this.filterNotUsed = false;
            // }
            this.currentUserPolicy = res;
            this.getMemberList();
            this.getPolicyDetails();
            // this.showButtonClaim();
            this.currentFilter = {
                beneficiaryId: [this.currentUserPolicy.beneficiaryId],
            };
            this.onSearch(this.currentFilter);
            // this.consentCheck(false);
        });
    }
    // showButtonClaim(){
    //   const date = new Date().getTime();
    //   const dateExpired = new Date().setDate(new Date(this.currentUserPolicy.maxExpiry).getDate() + 89);
    //   if(date <= dateExpired){
    //     this.isShow = true;
    //   }
    // }
    getPolicyDetails() {
        var _a;
        this.productId = (_a = this.insuranceService.getPolicyDetailResponse()) === null || _a === void 0 ? void 0 : _a[0].Beneficiary.product.productId;
        this.getReimbursmentActionStatus();
        this.getPreapprovalActionStatus();
    }
    getMemberList() {
        this.members = this.insuranceService.getMemberListValue();
        console.log(this.members);
        this.formatListFilter();
    }
    formatListFilter() {
        const mappedMember = this.members.map((res) => ({
            id: res.beneficiaryId,
            name: res.benefFullName,
        }));
        this.listFilter = [
            {
                filterName: 'claimsHistory.member',
                conditions: mappedMember,
                singleSelections: true,
                paramName: 'beneficiaryId',
                initValues: [this.currentUserPolicy.beneficiaryId],
                required: true,
            },
            {
                filterName: 'claimsHistory.status',
                conditions: this.status,
                singleSelections: true,
                paramName: 'claimStatus',
            },
            {
                filterName: 'claimsHistory.additionalStatus',
                conditions: this.additionalStatus.filter((e) => {
                    if (this.filterNotUsed) {
                        return e;
                    }
                    else if (e.id !== 2) {
                        return e;
                    }
                }),
                singleSelections: true,
                paramName: 'additionalStatus',
            },
            {
                filterName: 'keyword',
                conditions: [],
                singleSelections: true,
                paramName: 'keyword',
                hidden: true,
            },
        ];
    }
    segmentChanged(event) {
        this.details = [];
        this.tab = event.detail.value;
        this.onSearch(this.currentFilter);
        this.loadingService.dismissLoading();
    }
    onSearch(model) {
        var _a, _b;
        this.isLoading = false;
        this.loadDraftClaim();
        if (((_a = model === null || model === void 0 ? void 0 : model.keyword) === null || _a === void 0 ? void 0 : _a.length) > 0) {
            model.claimReference = model.keyword;
        }
        this.currentFilter = model;
        const searchCondition = Object.assign(Object.assign(Object.assign({}, model), this.paging), { claimType: this.tab, userPolicyId: this.currentUserPolicy.userPolicyId, beneficiaryId: (((_b = model === null || model === void 0 ? void 0 : model.beneficiaryId) === null || _b === void 0 ? void 0 : _b.length) > 0 && (model === null || model === void 0 ? void 0 : model.beneficiaryId)) || this.currentUserPolicy.beneficiaryId, notUsed: this.filterNotUsed ? null : 0 });
        if (searchCondition === null || searchCondition === void 0 ? void 0 : searchCondition.additionalStatus) {
            const status = src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_17__.Constants.ADDITIONAL_STATUS.find((e) => e.id === model.additionalStatus[0]);
            if (status) {
                searchCondition[status.condition] = 1;
            }
        }
        if (searchCondition.notUsed === null) {
            delete searchCondition.notUsed;
        }
        /// cal api
        this.searchService.getClaimsHistorySearch(searchCondition).subscribe((res) => {
            if (res) {
                this.details = this.details.concat(res.results.map((e) => {
                    const member = this.members.find((_) => _.beneficiaryId === e.beneficiaryId);
                    return Object.assign({ benefFullName: member.benefFullName }, e);
                }) || []);
                this.paging = {
                    pageNo: res.page,
                    pageSize: res.pageSize,
                    pageCount: res.pageCount,
                };
            }
            else {
                this.details = [];
                this.paging = {
                    pageNo: 1,
                    pageSize: 5,
                    pageCount: null,
                };
            }
            if (this.tab == 5) {
                if (this.draftClaim) {
                    this.details.unshift(this.draftClaim);
                }
            }
            else {
                if (this.draftPre) {
                    this.details.unshift(this.draftPre);
                }
            }
            this.isLoading = true;
        });
    }
    onChangeCreate() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__awaiter)(this, void 0, void 0, function* () {
            // const requestConsent: RequestConsent = {
            //   userPolicyId: this.currentUserPolicy.userPolicyId,
            //   beneficiaryId: this.currentUserPolicy.beneficiaryId,
            // };
            // this.consentService.getConsent(requestConsent).subscribe((data) => {
            //   if (!data) {
            //     this.getPrivacyConsent(requestConsent,true);
            //   }
            //   else{
            this.checkSaveDraft();
            //   }
            // });
        });
    }
    // get enablesubmitclaim in api submitreimbclaimsettings
    getReimbursmentActionStatus() {
        const request = {
            userPolicyId: this.currentUserPolicy.userPolicyId,
            productId: this.productId,
        };
        this.historyClaimsService.getReimbursmentActionStatus(request).subscribe((res) => {
            if (!res)
                return;
            const enablesubmitclaim = res.enablesubmitclaim;
            const disableSubmitClaim = this.insuranceService.checkPayerSetting(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_17__.Constants.DISABLE_SUBMIT_CLAIM, false);
            if (enablesubmitclaim === 1 && disableSubmitClaim == true) {
                this.isEnabledReimbursmentBtn = true;
            }
            else if (disableSubmitClaim == true && enablesubmitclaim == 0) {
                this.isEnabledReimbursmentBtn = false;
            }
            else if (disableSubmitClaim == false && (enablesubmitclaim == 1 || enablesubmitclaim == 0)) {
                this.isEnabledReimbursmentBtn = false;
            }
            //Hide Create New Claim button when have upcoming policy
            if (new Date().getTime() < new Date(this.currentUserPolicy.minEffective).getTime()) {
                this.isEnabledReimbursmentBtn = false;
            }
        });
    }
    // get columnname in api getPayerSettings
    getPreapprovalActionStatus() {
        this.isActiveMember = this.insuranceService.getMemberListValue().some((value) => value.isActive === 1);
        this.isEnabledApointmentBooking = this.insuranceService.checkPayerSetting(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_17__.Constants.APPOINTMENT_BOOKING, true);
        this.isEnabledPreapprovalBtn = this.insuranceService.checkPayerSetting(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_17__.Constants.PRE_APPROVAL, true);
        // const payerSetting = this.insuranceService.getPayerSettingValue();
        // const columnBookAppointment = payerSetting.find(
        //   (x) => x.columnname === 'MyNCEnableAppointmentBooking',
        // );
        // const columnPreApproval = payerSetting.find(
        //   (x) => x.columnname === 'MyNEXtCAREPreApproval',
        // );
        // const required = payerSetting.find((x) => x.required == true);
        // if (columnPreApproval) {
        //   if (required) {
        //     this.isEnabledPreapprovalBtn = true;
        //   }
        // }
        // // set appointmentBooking
        // if (columnBookAppointment) {
        //   if (required) {
        //     this.isEnabledApointmentBooking = true;
        //   }
        // }
    }
    logScrolling() {
        this.detectBottom();
    }
    detectBottom() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__awaiter)(this, void 0, void 0, function* () {
            const scrollElement = yield this.content.getScrollElement(); // get scroll element
            // console.log(scrollElement);
            // calculate if max bottom was reached
            const number = scrollElement.scrollTop - (scrollElement.scrollHeight - scrollElement.clientHeight);
            const isEndOfScroll = number >= -10 && number <= 10;
            const currentPage = this.paging.pageNo;
            const currentPageCount = this.paging.pageCount;
            const isNoMoreItems = currentPage >= currentPageCount;
            if (isEndOfScroll && !isNoMoreItems) {
                this.paging.pageNo = this.paging.pageNo + 1;
                this.onSearch(this.currentFilter);
            }
        });
    }
    consentCheck(isCreate) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__awaiter)(this, void 0, void 0, function* () {
            // true --- showButton create neww
            const requestConsent = {
                userPolicyId: this.currentUserPolicy.userPolicyId,
                beneficiaryId: this.currentUserPolicy.beneficiaryId,
            };
            this.consentService.getConsent(requestConsent).subscribe((data) => {
                if (!data) {
                    this.getPrivacyConsent(requestConsent, isCreate);
                }
            });
        });
    }
    getPrivacyConsent(requestConsent, isCreate) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__awaiter)(this, void 0, void 0, function* () {
            this.consentService.getPrivacyConsent().subscribe((data) => {
                this.dialogService
                    .open(src_app_shared_components_privacy_consent_dialog_privacy_consent_dialog_component__WEBPACK_IMPORTED_MODULE_14__.PrivacyConsentDialogComponent, {
                    data: {
                        text: data[0].description,
                        requestConsent: requestConsent,
                    },
                    title: data[0].title,
                    position: 'middle',
                    width: '90%',
                    height: '80%',
                })
                    .afterClosed()
                    .subscribe((data) => (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__awaiter)(this, void 0, void 0, function* () {
                    if (isCreate == true) {
                        if (data) {
                            this.checkSaveDraft();
                        }
                        else {
                            this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_19__.Screens.ClaimHistory]);
                        }
                    }
                    else {
                        this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_19__.Screens.ClaimHistory]);
                    }
                }));
            });
        });
    }
    checkSaveDraft() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__awaiter)(this, void 0, void 0, function* () {
            if (this.tab == 5) {
                this.firebaseAnalytics.logEvent(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_18__.GA4Event.ReimbursmentClaimInitiated, {
                    claim_type: this.tab,
                });
                this.clevertap.recordEventWithNameAndProps(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_18__.GA4Event.ReimbursmentClaimInitiated, {
                    claim_type: this.tab,
                });
                const submitClaim = yield this.newClaimService.getLocalStorageSubmitClaim();
                if (submitClaim) {
                    this.dialogService
                        .open(src_app_shared_components_popup_message_popup_message_component__WEBPACK_IMPORTED_MODULE_13__.PopupMessageComponent, {
                        data: {
                            content: 'claimsHistory.replaceDraft',
                            textYes: 'claimsHistory.no',
                            textNo: 'button.yes',
                        },
                        title: 'claimsHistory.messageTitle',
                        position: 'middle',
                        width: '90%',
                    })
                        .afterClosed()
                        .subscribe((isNo) => {
                        if (isNo) {
                            this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_19__.Screens.NewClaim]);
                        }
                        else {
                            this.newClaimService.clearClaim();
                            this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_19__.Screens.NewClaim]);
                        }
                    });
                }
                else {
                    this.newClaimService.clearClaim();
                    this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_19__.Screens.NewClaim]);
                }
            }
            else if (this.tab == 4) {
                this.firebaseAnalytics.logEvent(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_18__.GA4Event.PreApprovalClaimInitiated, { claim_type: this.tab });
                this.clevertap.recordEventWithNameAndProps(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_18__.GA4Event.PreApprovalClaimInitiated, { claim_type: this.tab });
                const submitPre = yield this.newPreApprovalService.getLocalStorageSubmitPre();
                if (submitPre) {
                    this.dialogService
                        .open(src_app_shared_components_popup_message_popup_message_component__WEBPACK_IMPORTED_MODULE_13__.PopupMessageComponent, {
                        data: {
                            content: 'claimsHistory.replaceDraft',
                            textYes: 'claimsHistory.no',
                            textNo: 'button.yes',
                        },
                        title: 'claimsHistory.messageTitle',
                        position: 'middle',
                        width: '90%',
                    })
                        .afterClosed()
                        .subscribe((isNo) => {
                        if (isNo) {
                            this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_19__.Screens.NewPreApproval]);
                        }
                        else {
                            this.newPreApprovalService.clearPreapprovals();
                            this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_19__.Screens.NewPreApproval]);
                        }
                    });
                }
                else {
                    this.newPreApprovalService.clearPreapprovals();
                    this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_19__.Screens.NewPreApproval]);
                }
            }
        });
    }
};
ClaimsHistoryPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_23__.Router },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_23__.ActivatedRoute },
    { type: src_app_service_insurance_insurance_service__WEBPACK_IMPORTED_MODULE_8__.InsuranceService },
    { type: src_app_service_cms_search_service__WEBPACK_IMPORTED_MODULE_6__.SearchService },
    { type: _awesome_cordova_plugins_firebase_analytics_ngx__WEBPACK_IMPORTED_MODULE_3__.FirebaseAnalytics },
    { type: src_app_service_home_history_claims_service__WEBPACK_IMPORTED_MODULE_7__.HistoryClaimsService },
    { type: src_app_service_new_claim_new_claim_service__WEBPACK_IMPORTED_MODULE_10__.NewClaimService },
    { type: src_app_service_new_re_approval_new_pre_approval_service__WEBPACK_IMPORTED_MODULE_11__.NewPreApprovalService },
    { type: _awesome_cordova_plugins_clevertap_ngx__WEBPACK_IMPORTED_MODULE_2__.CleverTap },
    { type: src_app_shared_components_nextgen_dialog_nextgen_dialog_service__WEBPACK_IMPORTED_MODULE_12__.DialogService },
    { type: src_app_service_new_claim_consent_consent_service__WEBPACK_IMPORTED_MODULE_9__.ConsentService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_24__.Platform },
    { type: _awesome_cordova_plugins_app_rate_ngx__WEBPACK_IMPORTED_MODULE_15__.AppRate },
    { type: _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_25__.Storage },
    { type: src_app_service_utilities_third_party_service__WEBPACK_IMPORTED_MODULE_16__.ThirdPartyService },
    { type: src_app_providers_common_loading_service__WEBPACK_IMPORTED_MODULE_5__.LoadingService }
];
ClaimsHistoryPage.propDecorators = {
    content: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_26__.ViewChild, args: [_ionic_angular__WEBPACK_IMPORTED_MODULE_24__.IonContent,] }]
};
ClaimsHistoryPage = (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_26__.Component)({
        selector: 'app-claims-history',
        template: _claims_history_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_claims_history_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], ClaimsHistoryPage);



/***/ }),

/***/ 93817:
/*!****************************************************************************************!*\
  !*** ./src/app/pages/home/claims-history/history-content/history-content.component.ts ***!
  \****************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HistoryContentComponent": () => (/* binding */ HistoryContentComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _history_content_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./history-content.component.html?ngResource */ 69763);
/* harmony import */ var _history_content_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./history-content.component.scss?ngResource */ 22378);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/shared/data/enum/screen */ 68302);
/* harmony import */ var src_app_service_new_claim_new_claim_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/service/new-claim/new-claim.service */ 90888);
/* harmony import */ var src_app_service_utilities_third_party_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/service/utilities/third-party.service */ 47617);
/* harmony import */ var src_app_service_new_re_approval_new_pre_approval_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/service/new-re-approval/new-pre-approval.service */ 80518);
/* harmony import */ var src_app_shared_components_nextgen_dialog_nextgen_dialog_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/shared/components/nextgen-dialog/nextgen-dialog.service */ 96485);
/* harmony import */ var src_app_service_new_claim_consent_consent_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/service/new-claim/consent/consent.service */ 41413);
/* harmony import */ var src_app_shared_components_privacy_consent_dialog_privacy_consent_dialog_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/shared/components/privacy-consent-dialog/privacy-consent-dialog.component */ 61262);
/* harmony import */ var src_app_service_language_language_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/service/language/language.service */ 11281);













let HistoryContentComponent = class HistoryContentComponent {
    constructor(router, newClaimService, thirdPartyService, newPreApprovalService, dialogSevice, consentService, languageService) {
        this.router = router;
        this.newClaimService = newClaimService;
        this.thirdPartyService = thirdPartyService;
        this.newPreApprovalService = newPreApprovalService;
        this.dialogSevice = dialogSevice;
        this.consentService = consentService;
        this.languageService = languageService;
        this.lang = 'en';
    }
    ngOnChanges() {
        this.getLanguage();
    }
    ngOnInit() {
    }
    onBookApointment() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__awaiter)(this, void 0, void 0, function* () {
            this.thirdPartyService.openBookAppointment();
        });
    }
    onViewDetail(item) {
        // const requestConsent: RequestConsent = {
        //   userPolicyId: this.currentPolicy.userPolicyId,
        //   beneficiaryId: this.currentPolicy.beneficiaryId,
        // };
        // return this.consentService.getConsent(requestConsent).subscribe((data) => {
        //   if (!data) {
        //     this.getPrivacyConsent(requestConsent,item);
        //   }
        //   else{
        this.checkSaveDraft(item);
        //   }
        // });
    }
    checkSaveDraft(item) {
        if (this.type == 4) {
            if (item.status != 'Draft') {
                this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__.Screens.ClaimDetails], { state: { detailInfo: item } });
            }
            else {
                if (this.currentPolicy.status == 'expired') {
                    this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__.Screens.ClaimDetails], { state: { detailInfo: item } });
                }
                else {
                    this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__.Screens.NewPreApproval]);
                }
            }
        }
        else {
            if (item.status != 'Draft') {
                this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__.Screens.ClaimDetails], { state: { detailInfo: item, type: this.type } });
            }
            else {
                // if (this.currentPolicy.status == 'expired') {
                //   this.router.navigate(['/' + Screens.ClaimDetails], { state: { detailInfo: item } });
                // }
                // else {
                this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__.Screens.NewClaim]);
                // }
            }
        }
    }
    consentCheck(item) {
        const requestConsent = {
            userPolicyId: this.currentPolicy.userPolicyId,
            beneficiaryId: this.currentPolicy.beneficiaryId,
        };
        return this.consentService.getConsent(requestConsent).subscribe((data) => {
            if (!data) {
                this.getPrivacyConsent(requestConsent, item);
            }
        });
    }
    getPrivacyConsent(requestConsent, item) {
        this.consentService.getPrivacyConsent().subscribe((data) => {
            this.dialogSevice
                .open(src_app_shared_components_privacy_consent_dialog_privacy_consent_dialog_component__WEBPACK_IMPORTED_MODULE_8__.PrivacyConsentDialogComponent, {
                data: {
                    text: data[0].description,
                    requestConsent: requestConsent,
                },
                title: data[0].title,
                position: 'middle',
                width: '90%',
                height: '80%',
            })
                .afterClosed()
                .subscribe((data) => {
                if (data) {
                    this.checkSaveDraft(item);
                }
                else {
                    this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__.Screens.ClaimHistory]);
                }
            });
        });
    }
    onDelete(event, value) {
        event.stopPropagation();
        if (value.status == 'Draft') {
            if (this.type == 5) {
                this.newClaimService.clearClaim();
            }
            else if (this.type == 4) {
                this.newPreApprovalService.clearPreapprovals();
            }
            this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__.Screens.Home]).then(() => {
                this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__.Screens.ClaimHistory]);
            });
        }
    }
    trackById(_, detail) {
        return detail.id;
    }
    getLanguage() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__awaiter)(this, void 0, void 0, function* () {
            this.lang = this.languageService.getISOLanguageCode();
        });
    }
};
HistoryContentComponent.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_11__.Router },
    { type: src_app_service_new_claim_new_claim_service__WEBPACK_IMPORTED_MODULE_3__.NewClaimService },
    { type: src_app_service_utilities_third_party_service__WEBPACK_IMPORTED_MODULE_4__.ThirdPartyService },
    { type: src_app_service_new_re_approval_new_pre_approval_service__WEBPACK_IMPORTED_MODULE_5__.NewPreApprovalService },
    { type: src_app_shared_components_nextgen_dialog_nextgen_dialog_service__WEBPACK_IMPORTED_MODULE_6__.DialogService },
    { type: src_app_service_new_claim_consent_consent_service__WEBPACK_IMPORTED_MODULE_7__.ConsentService },
    { type: src_app_service_language_language_service__WEBPACK_IMPORTED_MODULE_9__.LanguageService }
];
HistoryContentComponent.propDecorators = {
    type: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_12__.Input }],
    details: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_12__.Input }],
    isEnabledApointmentBooking: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_12__.Input }],
    currentPolicy: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_12__.Input }],
    isLoading: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_12__.Input }]
};
HistoryContentComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_12__.Component)({
        selector: 'app-history-contents',
        template: _history_content_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_history_content_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], HistoryContentComponent);



/***/ }),

/***/ 35669:
/*!******************************************************************!*\
  !*** ./src/app/pages/home/dashboard/dashboard-routing.module.ts ***!
  \******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DashboardPageRoutingModule": () => (/* binding */ DashboardPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _dashboard_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./dashboard.page */ 36457);




const routes = [
    {
        path: '',
        component: _dashboard_page__WEBPACK_IMPORTED_MODULE_0__.DashboardPage
    },
];
let DashboardPageRoutingModule = class DashboardPageRoutingModule {
};
DashboardPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
    })
], DashboardPageRoutingModule);



/***/ }),

/***/ 18259:
/*!**********************************************************!*\
  !*** ./src/app/pages/home/dashboard/dashboard.module.ts ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DashboardPageModule": () => (/* binding */ DashboardPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _dashboard_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./dashboard.page */ 36457);
/* harmony import */ var _dashboard_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./dashboard-routing.module */ 35669);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _medical_card_medical_card_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./medical-card/medical-card.component */ 91099);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/shared/shared.module */ 44466);
/* harmony import */ var _insurance_card_insurance_card_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./insurance-card/insurance-card.component */ 73899);










let DashboardPageModule = class DashboardPageModule {
};
DashboardPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.NgModule)({
        declarations: [
            _dashboard_page__WEBPACK_IMPORTED_MODULE_0__.DashboardPage,
            _medical_card_medical_card_component__WEBPACK_IMPORTED_MODULE_2__.MedicalCardComponent,
            _insurance_card_insurance_card_component__WEBPACK_IMPORTED_MODULE_4__.InsuranceCardComponent,
        ],
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_7__.CommonModule,
            _dashboard_routing_module__WEBPACK_IMPORTED_MODULE_1__.DashboardPageRoutingModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_8__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.IonicModule,
            src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_3__.SharedModule,
        ],
    })
], DashboardPageModule);



/***/ }),

/***/ 36457:
/*!********************************************************!*\
  !*** ./src/app/pages/home/dashboard/dashboard.page.ts ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DashboardPage": () => (/* binding */ DashboardPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _dashboard_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./dashboard.page.html?ngResource */ 35045);
/* harmony import */ var _dashboard_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./dashboard.page.scss?ngResource */ 34322);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _awesome_cordova_plugins_clevertap_ngx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @awesome-cordova-plugins/clevertap/ngx */ 45363);
/* harmony import */ var _awesome_cordova_plugins_firebase_analytics_ngx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @awesome-cordova-plugins/firebase-analytics/ngx */ 48852);
/* harmony import */ var _awesome_cordova_plugins_in_app_browser_ngx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @awesome-cordova-plugins/in-app-browser/ngx */ 12407);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! @ionic/storage-angular */ 80190);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! rxjs */ 92218);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! rxjs/operators */ 85921);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! rxjs/operators */ 80522);
/* harmony import */ var src_app_service_home_home_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/service/home/home.service */ 58425);
/* harmony import */ var src_app_service_insurance_insurance_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/service/insurance/insurance.service */ 57072);
/* harmony import */ var src_app_service_signin_signin_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/service/signin/signin.service */ 91265);
/* harmony import */ var src_app_service_utilities_third_party_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/service/utilities/third-party.service */ 47617);
/* harmony import */ var src_app_shared_components_nextgen_dialog_nextgen_dialog_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/shared/components/nextgen-dialog/nextgen-dialog.service */ 96485);
/* harmony import */ var src_app_shared_components_popup_message_popup_message_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/app/shared/components/popup-message/popup-message.component */ 18290);
/* harmony import */ var src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/app/shared/data/constants */ 74676);
/* harmony import */ var _switch_policy_switch_policy_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../switch-policy/switch-policy.component */ 48473);
/* harmony import */ var src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! src/app/shared/data/enum/event */ 38570);
/* harmony import */ var _capacitor_app__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @capacitor/app */ 93253);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../../../shared/data/enum/screen */ 68302);
























let DashboardPage = class DashboardPage {
    constructor(router, homeService, dialogService, insuranceService, firebaseAnalytics, iab, clevertap, storage, route, authService, platform, thirdPartyService, location, menu) {
        this.router = router;
        this.homeService = homeService;
        this.dialogService = dialogService;
        this.insuranceService = insuranceService;
        this.firebaseAnalytics = firebaseAnalytics;
        this.iab = iab;
        this.clevertap = clevertap;
        this.storage = storage;
        this.route = route;
        this.authService = authService;
        this.platform = platform;
        this.thirdPartyService = thirdPartyService;
        this.location = location;
        this.menu = menu;
        this.slideOpts = {
            speed: 1000,
            spaceBetween: 20,
            breakpoints: {
                '320': { slidesPerView: 1 },
                '360': { slidesPerView: 1.2 },
                '480': { slidesPerView: 1.4 },
                '720': { slidesPerView: 2.2 },
                '1080': { slidesPerView: 2.4 },
                '1440': { slidesPerView: 3.2 },
            },
        };
        this.slideMemberOpts = {
            speed: 1000,
            spaceBetween: 10,
            breakpoints: {
                '320': { slidesPerView: 1.2 },
                '360': { slidesPerView: 1.4 },
                '480': { slidesPerView: 1.6 },
                '720': { slidesPerView: 2.2 },
                '1080': { slidesPerView: 2.4 },
                '1440': { slidesPerView: 3.2 },
            },
        };
        this.unsubscribe$ = new rxjs__WEBPACK_IMPORTED_MODULE_16__.Subject();
        this.isPopupMessageShowing = false;
        this.checkBlackedlist = (policyDetail) => {
            const blacklistMember = policyDetail.blacklisted;
            //check for the same element in policy
            const listPolicy = this.insuranceService.getPolicyList().map(_ => { var _a, _b; return (_b = (_a = _.policiesDetails) === null || _a === void 0 ? void 0 : _a[0]) === null || _b === void 0 ? void 0 : _b.beneficiaryId; });
            const checklistSameBeneficiary = this.checkSameBeneficiary(listPolicy, listPolicy.length);
            if (blacklistMember && (blacklistMember || checklistSameBeneficiary == 1)) {
                this.warningPolicyDialog();
            }
        };
        this.linkPolicy = () => {
            this.dialogService
                .open(_switch_policy_switch_policy_component__WEBPACK_IMPORTED_MODULE_12__.SwitchPolicyComponent, {
                position: 'bottom',
                width: '90%',
                data: {
                    policy: this.policy,
                },
                title: 'switchpolicy.title',
                canClose: true,
            })
                .afterClosed()
                .subscribe((res) => (0,tslib__WEBPACK_IMPORTED_MODULE_17__.__awaiter)(this, void 0, void 0, function* () {
                console.log('abc', res);
                if (res === undefined) {
                    this.showPopUpClosedPolicy();
                    return;
                }
                if (res !== 'link-new-policy') {
                    this.getCommonSetting(res);
                }
            }));
        };
        this.lockScreen();
        // this.onloadAds();
    }
    lockScreen() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_17__.__awaiter)(this, void 0, void 0, function* () {
            // this.platform.pause.subscribe(() => {
            //   const isLoggedIn = JSON.parse(window.localStorage.getItem(Constants.LOGGEDIN));
            //   if (isLoggedIn) {
            //     this.pauseTime = Date.now();
            //   }
            // });
            //
            // this.platform.resume.subscribe(async () => {
            //   if ((Date.now() - this.pauseTime) >= 24 * 60 * 60 * 1000) {
            //     setTimeout(() => {
            //       this.router.navigate(['/' + Screens.lockScreen]);
            //     }, 100);
            //   }
            // });
        });
    }
    ionViewWillEnter() {
        var _a;
        this.unsubscribe$ = new rxjs__WEBPACK_IMPORTED_MODULE_16__.Subject();
        this.getPolicyInformation();
        this.policy = ((_a = this.route.snapshot.data) === null || _a === void 0 ? void 0 : _a.policy) || this.insuranceService.getPolicyList();
        // this.onloadAds();
    }
    ionViewDidEnter() {
        this.subscription = this.platform.backButton.subscribeWithPriority(9999, () => (0,tslib__WEBPACK_IMPORTED_MODULE_17__.__awaiter)(this, void 0, void 0, function* () {
            const isShowMenu = yield this.menu.isOpen('profile-menu');
            if (this.location.path().includes('home/inquiriesHistory')) {
                this.location.back();
            }
            else if (isShowMenu == true) {
                this.menu.close('profile-menu');
            }
            else {
                _capacitor_app__WEBPACK_IMPORTED_MODULE_14__.App.minimizeApp();
            }
        }));
    }
    ionViewWillLeave() {
        this.unsubscribe$.next();
        this.unsubscribe$.complete();
        // this.hideloadAds();
        this.subscription.unsubscribe();
    }
    getPolicyInformation() {
        this.getListDashboardCard();
        this.getListInsuranceCard();
        this.getListMedicalCard();
        this.getListMemberCard();
        this.insuranceService.getPolicyInformation().pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_18__.takeUntil)(this.unsubscribe$)).subscribe((res) => {
            if (!res || this.currentPolicy && this.currentPolicy.policyNumber === res.policyNumber) {
                return;
            }
            ;
            this.currentPolicy = res;
            this.getListDashboardCard();
            this.getListInsuranceCard();
            this.getListMedicalCard();
            this.getListMemberCard();
            this.getInformationPolicyDetails(res);
        });
    }
    getListDashboardCard() {
        this.homeService.getListDashboardCard().subscribe((data) => {
            this.listDashboard = data;
            this.listDashboard.forEach((itemCard) => (0,tslib__WEBPACK_IMPORTED_MODULE_17__.__awaiter)(this, void 0, void 0, function* () {
                // just comment and we will un-comment it soon
                // const contacts = await this.storage.get(Constants.USER_CONTACT);
                // const userContact = {
                //   emails: contacts.filter(e => e.type === 'email'),
                //   phones: contacts.filter(e => e.type === 'phone')
                // };
                // if (userContact.phones.some(e => e.isVerified === 1)) {
                //   if (itemCard.code == 'profile') {
                //     this.listDashboard = this.listDashboard.filter(
                //       _ => _.code != 'profile');
                //   }
                // }
                if (itemCard.code == 'profile') {
                    this.listDashboard = this.listDashboard.filter(_ => _.code != 'profile');
                }
                if (itemCard.code == 'seeDoctor') {
                    const symptomChecker = this.insuranceService.checkPayerSetting(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_11__.Constants.SYMPTOM_CHECKER, false);
                    const teleconsultation = this.insuranceService.checkPayerSetting(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_11__.Constants.TELECONSULTATION, true);
                    if (symptomChecker == true || teleconsultation == true && this.currentPolicy.status === 'active') {
                        this.listDashboard = data;
                    }
                    else {
                        this.listDashboard = this.listDashboard.filter(_ => _.code != 'seeDoctor');
                    }
                    // if (
                    //   this.insuranceService.getPayerSettingValue().some(
                    //     (_) =>
                    //       (_.columnname == 'Symptom Checker' ||
                    //         _.columnname == 'EnableTeleconsultation') &&
                    //       _.required == true && this.currentPolicy.status === 'active',
                    //   )
                    // ) {
                    //   this.listDashboard = data;
                    // } else {
                    //   this.listDashboard = this.listDashboard.filter(
                    //     _ => _.code != 'seeDoctor'
                    //   )
                    // }
                }
                if (!this.currentPolicy) {
                    this.listDashboard = this.listDashboard.filter(res => res.code != 'policy');
                }
            }));
        });
    }
    getListMedicalCard() {
        this.homeService.getListMedicalCard().subscribe((data) => {
            this.listMedical = data;
        });
    }
    getListInsuranceCard() {
        this.homeService.getListInsuranceCard().subscribe((data) => {
            this.listInsurance = data;
        });
    }
    getListMemberCard() {
        this.listFamilyMember = this.insuranceService.getMemberListValue();
    }
    showpopup(item) {
        this.homeService.showpopup(item);
    }
    onClickInsuranceCard(item) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_17__.__awaiter)(this, void 0, void 0, function* () {
            const enableReferalsAndPrescriptions = this.insuranceService.checkPayerSetting(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_11__.Constants.ENABLE_REFERRALS_AND_PRESCRIPTIONS, true);
            if (item.textHeader == 'listInsuranceCard.healthcareProvider') {
                this.thirdPartyService.openBookAppointment();
            }
            else if (item.textHeader == 'listInsuranceCard.referralsandPrescriptions') {
                if (this.currentPolicy) {
                    if (enableReferalsAndPrescriptions) {
                        this.clevertap.recordEventWithName(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_13__.GA4Event.ReferralandPrescriptionStarted);
                        this.firebaseAnalytics.logEvent(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_13__.GA4Event.ReferralandPrescriptionStarted, {});
                        this.router.navigate(['/' + item.link]);
                    }
                    else {
                        this.dialogService
                            .open(src_app_shared_components_popup_message_popup_message_component__WEBPACK_IMPORTED_MODULE_10__.PopupMessageComponent, {
                            data: {
                                content: 'linkinsurance.messageNotPolicy',
                                textYes: 'button.ok',
                            },
                            // title: 'Message',
                            title: 'title.wrongTitleMessage',
                            width: '90%',
                            position: 'middle',
                            canClose: true,
                        });
                    }
                }
                else {
                    this.dialogService.open(src_app_shared_components_popup_message_popup_message_component__WEBPACK_IMPORTED_MODULE_10__.PopupMessageComponent, {
                        data: {
                            content: 'policy.message',
                            textYes: 'policy.linkNewPolicy',
                        },
                        position: 'middle',
                        title: 'title.wrongTitleMessage',
                        width: '90%',
                    }).afterClosed().subscribe(isYes => {
                        console.log(isYes);
                        if (isYes === true) {
                            this.router.navigate(['/' + _shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_15__.Screens.addInsurance]).then(() => { });
                        }
                        else if (isYes === false) {
                            this.authService.logout();
                        }
                    });
                }
            }
            else {
                this.router.navigate(['/' + item.link]);
            }
        });
    }
    onClickDashboardCard(item) {
        if (item.textButton === 'Book Appointment') {
            this.iab.create(item.link);
        }
        this.router.navigate(['/' + item.link]);
    }
    getInformationPolicyDetails(policy) {
        var _a, _b, _c, _d, _e, _f;
        if (policy) {
            const data = this.insuranceService.getPolicyDetailResponse();
            this.currentPolicyDetail = {
                contractId: (_b = (_a = policy.policiesDetails) === null || _a === void 0 ? void 0 : _a[0]) === null || _b === void 0 ? void 0 : _b.contractId,
                mcontractId: (_d = (_c = policy.policiesDetails) === null || _c === void 0 ? void 0 : _c[0]) === null || _d === void 0 ? void 0 : _d.mcontractId,
                payerId: (_f = (_e = policy.policiesDetails) === null || _e === void 0 ? void 0 : _e[0]) === null || _f === void 0 ? void 0 : _f.payerId,
                payerName: data[0].Payer.entity.name,
                productId: data[0].Beneficiary.product.productId,
                policyStartDay: data[0].Mcontract.STARTDATE,
                policyEndDay: data[0].Mcontract.EXPDATE,
                policyNumber: data[0].Contract.EXTERNALREF,
                policyHolder: data[0].Contract.NAME,
                serviceProvId: data[0].ServiceProviderId,
                endorsementId: data[0].Endorsement.ENDORSEMENTID,
                moralEntity: data[0].Mcontract.MORALENTITY,
                isActive: data[0].Beneficiary.IsActive,
                beneficiaryId: data[0].Beneficiary.BeneficiaryID,
                firstName: data[0].Beneficiary.firstname,
                blacklisted: data[0].Beneficiary.blacklisted,
            };
            // get blacklistmember
            this.checkBlackedlist(this.currentPolicyDetail);
        }
        ;
    }
    //check for the same element in policy
    checkSameBeneficiary(arr, size) {
        let flag = 0;
        for (let i = 0; i < size - 1; ++i) {
            for (let j = i + 1; j < size; ++j) {
                if (arr[i] == arr[j]) {
                    flag = 1;
                    break;
                }
            }
        }
        return flag;
    }
    warningPolicyDialog() {
        this.dialogService
            .open(src_app_shared_components_popup_message_popup_message_component__WEBPACK_IMPORTED_MODULE_10__.PopupMessageComponent, {
            data: {
                content: 'linkinsurance.messageWarningPolicy',
                textYes: 'linkinsurance.titleLinkInsurance',
                textNo: 'addInsurance.needHelp'
            },
            // title: 'Message',
            title: 'title.wrongTitleMessage',
            width: '90%',
            position: 'middle',
            canClose: false,
        })
            .afterClosed()
            .subscribe((isYes) => {
            if (isYes || isYes === undefined) {
                this.linkPolicy();
            }
            else {
                this.router.navigate(['/' + 'auth/verloop-chatbot'], {
                    queryParams: {
                        pageName: 'Registration',
                        inquiryType: 'Registration',
                    }
                });
                this.checkBlackedlist(this.currentPolicyDetail);
            }
        });
    }
    getCommonSetting(policyApply) {
        var _a, _b;
        this.currentPolicy = policyApply;
        this.currentPolicy.beneficiaryId = (_b = (_a = policyApply.policiesDetails) === null || _a === void 0 ? void 0 : _a[0]) === null || _b === void 0 ? void 0 : _b.beneficiaryId;
        this.insuranceService.getPayerSetting(policyApply).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_19__.mergeMap)(payersetting => {
            this.insuranceService.setPayerSettingValue(payersetting);
            return this.insuranceService.getMemberList(policyApply);
        })).subscribe(res => {
            this.insuranceService.setMemberListValue(res);
            if (res && res.length > 0) {
                policyApply.dependent = res.length === 1 ? true : false;
            }
            this.insuranceService.setPolicyInformation(policyApply);
            this.storage.set(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_11__.Constants.CURRENT_USER_POLICY_ID, policyApply.userPolicyId);
        });
    }
    showPopUpClosedPolicy() {
        this.dialogService.open(src_app_shared_components_popup_message_popup_message_component__WEBPACK_IMPORTED_MODULE_10__.PopupMessageComponent, {
            data: {
                content: 'linkinsurance.messagelinkPolicy',
                textYes: 'button.ok',
            },
            position: 'middle',
            // title: 'Message',
            title: 'title.wrongTitleMessage',
            width: '90%',
            canClose: true,
        }).afterClosed().subscribe(() => {
            this.linkPolicy();
        });
    }
    onloadAds() {
        const element1 = document.getElementById('nextcare-ads');
        element1.style.display = 'block';
        const element2 = document.getElementById('main-content');
        element2.style.marginTop = '180px';
    }
    hideloadAds() {
        const element1 = document.getElementById('nextcare-ads');
        element1.style.display = 'none';
        const element2 = document.getElementById('main-content');
        element2.style.marginTop = 'unset';
    }
};
DashboardPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_20__.Router },
    { type: src_app_service_home_home_service__WEBPACK_IMPORTED_MODULE_5__.HomeService },
    { type: src_app_shared_components_nextgen_dialog_nextgen_dialog_service__WEBPACK_IMPORTED_MODULE_9__.DialogService },
    { type: src_app_service_insurance_insurance_service__WEBPACK_IMPORTED_MODULE_6__.InsuranceService },
    { type: _awesome_cordova_plugins_firebase_analytics_ngx__WEBPACK_IMPORTED_MODULE_3__.FirebaseAnalytics },
    { type: _awesome_cordova_plugins_in_app_browser_ngx__WEBPACK_IMPORTED_MODULE_4__.InAppBrowser },
    { type: _awesome_cordova_plugins_clevertap_ngx__WEBPACK_IMPORTED_MODULE_2__.CleverTap },
    { type: _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_21__.Storage },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_20__.ActivatedRoute },
    { type: src_app_service_signin_signin_service__WEBPACK_IMPORTED_MODULE_7__.SigninService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_22__.Platform },
    { type: src_app_service_utilities_third_party_service__WEBPACK_IMPORTED_MODULE_8__.ThirdPartyService },
    { type: _angular_common__WEBPACK_IMPORTED_MODULE_23__.Location },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_22__.MenuController }
];
DashboardPage = (0,tslib__WEBPACK_IMPORTED_MODULE_17__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_24__.Component)({
        selector: 'app-dashboard',
        template: _dashboard_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_dashboard_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], DashboardPage);



/***/ }),

/***/ 73899:
/*!*********************************************************************************!*\
  !*** ./src/app/pages/home/dashboard/insurance-card/insurance-card.component.ts ***!
  \*********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "InsuranceCardComponent": () => (/* binding */ InsuranceCardComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _insurance_card_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./insurance-card.component.html?ngResource */ 30400);
/* harmony import */ var _insurance_card_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./insurance-card.component.scss?ngResource */ 25333);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);




let InsuranceCardComponent = class InsuranceCardComponent {
    constructor() { }
    ngOnInit() { }
};
InsuranceCardComponent.ctorParameters = () => [];
InsuranceCardComponent.propDecorators = {
    card: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.Input, args: ['card',] }]
};
InsuranceCardComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.Component)({
        selector: 'app-insurance-card',
        template: _insurance_card_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_insurance_card_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], InsuranceCardComponent);



/***/ }),

/***/ 91099:
/*!*****************************************************************************!*\
  !*** ./src/app/pages/home/dashboard/medical-card/medical-card.component.ts ***!
  \*****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MedicalCardComponent": () => (/* binding */ MedicalCardComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _medical_card_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./medical-card.component.html?ngResource */ 70935);
/* harmony import */ var _medical_card_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./medical-card.component.scss?ngResource */ 26401);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);




let MedicalCardComponent = class MedicalCardComponent {
    constructor() { }
    ngOnInit() { }
};
MedicalCardComponent.ctorParameters = () => [];
MedicalCardComponent.propDecorators = {
    card: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.Input, args: ['card',] }]
};
MedicalCardComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.Component)({
        selector: 'app-medical-card',
        template: _medical_card_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_medical_card_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], MedicalCardComponent);



/***/ }),

/***/ 94926:
/*!*************************************************************!*\
  !*** ./src/app/pages/home/home-care/home-care.component.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HomeCareComponent": () => (/* binding */ HomeCareComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _home_care_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./home-care.component.html?ngResource */ 79887);
/* harmony import */ var _home_care_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./home-care.component.scss?ngResource */ 96588);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _awesome_cordova_plugins_clevertap_ngx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @awesome-cordova-plugins/clevertap/ngx */ 45363);
/* harmony import */ var _awesome_cordova_plugins_firebase_analytics_ngx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @awesome-cordova-plugins/firebase-analytics/ngx */ 48852);
/* harmony import */ var _awesome_cordova_plugins_in_app_browser_ngx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @awesome-cordova-plugins/in-app-browser/ngx */ 12407);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @ionic/storage-angular */ 80190);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! rxjs */ 92218);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! rxjs/operators */ 85921);
/* harmony import */ var src_app_providers_api_api_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/providers/api/api.service */ 57985);
/* harmony import */ var src_app_service_home_home_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/service/home/home.service */ 58425);
/* harmony import */ var src_app_service_insurance_insurance_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/service/insurance/insurance.service */ 57072);
/* harmony import */ var src_app_service_utilities_third_party_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/service/utilities/third-party.service */ 47617);
/* harmony import */ var src_app_shared_components_nextgen_dialog_nextgen_dialog_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/shared/components/nextgen-dialog/nextgen-dialog.service */ 96485);
/* harmony import */ var src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/app/shared/data/constants */ 74676);
/* harmony import */ var src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/app/shared/data/enum/screen */ 68302);



















let HomeCareComponent = class HomeCareComponent {
    constructor(homeService, insuranceService, storage, dialogService, firebaseAnalytics, clevertap, router, iab, apiService, thirdPartyService, platform) {
        this.homeService = homeService;
        this.insuranceService = insuranceService;
        this.storage = storage;
        this.dialogService = dialogService;
        this.firebaseAnalytics = firebaseAnalytics;
        this.clevertap = clevertap;
        this.router = router;
        this.iab = iab;
        this.apiService = apiService;
        this.thirdPartyService = thirdPartyService;
        this.platform = platform;
        this.slideOpts = {
            speed: 1000,
            slidesPerView: 1.2,
            spaceBetween: 20,
            breakpoints: {
                '320': { slidesPerView: 1 },
                '360': { slidesPerView: 1.2 },
                '480': { slidesPerView: 1.4 },
                '720': { slidesPerView: 2.2 },
                '1080': { slidesPerView: 2.4 },
                '1440': { slidesPerView: 3.2 },
            },
        };
        this.title = false;
        this.unsubscribe$ = new rxjs__WEBPACK_IMPORTED_MODULE_12__.Subject();
    }
    ngOnInit() {
        // this.getPolicyInformation();
    }
    ionViewWillLeave() {
        this.unsubscribe$.next();
        this.unsubscribe$.complete();
        this.subscription.unsubscribe();
    }
    ngOnDestroy() {
        this.unsubscribe$.next();
        this.unsubscribe$.complete();
    }
    ionViewDidEnter() {
        this.subscription = this.platform.backButton.subscribeWithPriority(9999, () => (0,tslib__WEBPACK_IMPORTED_MODULE_13__.__awaiter)(this, void 0, void 0, function* () {
            const isShowChatWithDoctor = yield this.storage.get(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_10__.Constants.OPENNED_CHAT_WITH_DOCTOR);
            if (isShowChatWithDoctor == true) {
                this.closeChatWithDoctor();
            }
            else {
                this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_11__.Screens.Home]);
            }
        }));
    }
    ionViewWillEnter() {
        this.unsubscribe$ = new rxjs__WEBPACK_IMPORTED_MODULE_12__.Subject();
        this.getPolicyInformation();
    }
    closeChatWithDoctor() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_13__.__awaiter)(this, void 0, void 0, function* () {
            window === null || window === void 0 ? void 0 : window.Avaamo.closeChatBox();
            yield this.storage.set(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_10__.Constants.OPENNED_CHAT_WITH_DOCTOR, false);
        });
    }
    getPolicyInformation() {
        this.insuranceService.getPolicyInformation().pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_14__.takeUntil)(this.unsubscribe$)).subscribe((res) => (0,tslib__WEBPACK_IMPORTED_MODULE_13__.__awaiter)(this, void 0, void 0, function* () {
            if (!res)
                return;
            this.currentPolicy = res;
            this.getListDashboardCard();
            this.getCareData();
        }));
    }
    getCareData() {
        this.homeService.getAllCareCard().subscribe(data => {
            this.careDatas = data;
            if (this.careDatas != null) {
                this.title = true;
            }
        });
    }
    getListDashboardCard() {
        this.homeService.getListDashboardCard().subscribe((data) => {
            this.listDashboard = data;
            this.listDashboard.forEach(itemCard => {
                // const contacts = await this.storage.get(Constants.USER_CONTACT);
                // const userContact = {
                //   emails: contacts.filter(e => e.type === 'email'),
                //   phones: contacts.filter(e => e.type === 'phone')
                // };
                // if (userContact.phones.some(e => e.isVerified === 1)) {
                //   if (itemCard.code == 'profile') {
                //     this.listDashboard = this.listDashboard.filter(
                //       _ => _.code != 'profile');
                //   }
                // }
                if (itemCard.code == 'profile') {
                    this.listDashboard = this.listDashboard.filter(_ => _.code != 'profile');
                }
                if (itemCard.code == 'seeDoctor') {
                    const symptomChecker = this.insuranceService.checkPayerSetting(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_10__.Constants.SYMPTOM_CHECKER, false);
                    const teleconsultation = this.insuranceService.checkPayerSetting(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_10__.Constants.TELECONSULTATION, true);
                    if (symptomChecker == true || teleconsultation == true && this.currentPolicy.status === 'active') {
                        this.listDashboard = data;
                    }
                    else {
                        this.listDashboard = this.listDashboard.filter(_ => _.code != 'seeDoctor');
                    }
                }
            });
        });
    }
    showpopup(item) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_13__.__awaiter)(this, void 0, void 0, function* () {
            yield this.storage.set(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_10__.Constants.OPENNED_SYMPTOM_CHECKER, true);
            this.homeService.showpopup(item);
        });
    }
};
HomeCareComponent.ctorParameters = () => [
    { type: src_app_service_home_home_service__WEBPACK_IMPORTED_MODULE_6__.HomeService },
    { type: src_app_service_insurance_insurance_service__WEBPACK_IMPORTED_MODULE_7__.InsuranceService },
    { type: _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_15__.Storage },
    { type: src_app_shared_components_nextgen_dialog_nextgen_dialog_service__WEBPACK_IMPORTED_MODULE_9__.DialogService },
    { type: _awesome_cordova_plugins_firebase_analytics_ngx__WEBPACK_IMPORTED_MODULE_3__.FirebaseAnalytics },
    { type: _awesome_cordova_plugins_clevertap_ngx__WEBPACK_IMPORTED_MODULE_2__.CleverTap },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_16__.Router },
    { type: _awesome_cordova_plugins_in_app_browser_ngx__WEBPACK_IMPORTED_MODULE_4__.InAppBrowser },
    { type: src_app_providers_api_api_service__WEBPACK_IMPORTED_MODULE_5__.ApiService },
    { type: src_app_service_utilities_third_party_service__WEBPACK_IMPORTED_MODULE_8__.ThirdPartyService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_17__.Platform }
];
HomeCareComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_13__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_18__.Component)({
        selector: 'app-home-care',
        template: _home_care_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_home_care_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], HomeCareComponent);



/***/ }),

/***/ 96610:
/*!***************************************************!*\
  !*** ./src/app/pages/home/home-routing.module.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HomePageRoutingModule": () => (/* binding */ HomePageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _home_care_home_care_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./home-care/home-care.component */ 94926);
/* harmony import */ var _home_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./home.page */ 10678);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _inquiries_history_inquiries_history_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./inquiries-history/inquiries-history.component */ 70320);
/* harmony import */ var _shared_guards_policy_guard__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../shared/guards/policy.guard */ 80589);







const routes = [
    {
        path: '',
        component: _home_page__WEBPACK_IMPORTED_MODULE_1__.HomePage,
        children: [
            // {
            //   path: 'home-insurance',
            //   component: HomeInsuranceComponent,
            // },
            // {
            //   path: 'add-policy',
            //   component: AddPolicyComponent,
            // },
            {
                path: 'dashboard',
                loadChildren: () => Promise.resolve(/*! import() */).then(__webpack_require__.bind(__webpack_require__, /*! ./dashboard/dashboard.module */ 18259)).then((m) => m.DashboardPageModule),
            },
            {
                path: 'claims-history',
                loadChildren: () => Promise.resolve(/*! import() */).then(__webpack_require__.bind(__webpack_require__, /*! ./claims-history/claims-history.module */ 22702)).then((m) => m.ClaimsHistoryPageModule),
                canActivate: [_shared_guards_policy_guard__WEBPACK_IMPORTED_MODULE_3__.PolicyGuard]
            },
            {
                path: 'policy-page',
                loadChildren: () => Promise.resolve(/*! import() */).then(__webpack_require__.bind(__webpack_require__, /*! ./policy/policy.module */ 10229)).then((m) => m.PolicyPageModule),
                canActivate: [_shared_guards_policy_guard__WEBPACK_IMPORTED_MODULE_3__.PolicyGuard],
            },
            // {
            //   path: 'loading-page',
            //   component: LoadingPageComponent
            // },
            {
                path: 'home-care',
                component: _home_care_home_care_component__WEBPACK_IMPORTED_MODULE_0__.HomeCareComponent,
                canActivate: [_shared_guards_policy_guard__WEBPACK_IMPORTED_MODULE_3__.PolicyGuard]
            },
            {
                path: 'inquiriesHistory',
                component: _inquiries_history_inquiries_history_component__WEBPACK_IMPORTED_MODULE_2__.InquiriesHistoryComponent,
                canActivate: [_shared_guards_policy_guard__WEBPACK_IMPORTED_MODULE_3__.PolicyGuard]
            },
            {
                path: '**',
                redirectTo: 'dashboard',
                pathMatch: 'full',
            }
        ],
    },
];
let HomePageRoutingModule = class HomePageRoutingModule {
};
HomePageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_6__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_6__.RouterModule],
    })
], HomePageRoutingModule);



/***/ }),

/***/ 57994:
/*!*******************************************!*\
  !*** ./src/app/pages/home/home.module.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HomePageModule": () => (/* binding */ HomePageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _claims_history_claims_history_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./claims-history/claims-history.module */ 22702);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _dashboard_dashboard_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./dashboard/dashboard.module */ 18259);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _home_care_home_care_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./home-care/home-care.component */ 94926);
/* harmony import */ var _home_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./home.page */ 10678);
/* harmony import */ var _home_routing_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./home-routing.module */ 96610);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _policy_policy_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./policy/policy.module */ 10229);
/* harmony import */ var src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/shared/shared.module */ 44466);
/* harmony import */ var _inquiries_history_inquiries_history_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./inquiries-history/inquiries-history.component */ 70320);
/* harmony import */ var src_app_register_third_party_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/register-third-party.component */ 8423);
/* harmony import */ var _medication_delivery_medication_delivery_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./medication-delivery/medication-delivery.component */ 48909);
/* harmony import */ var _verloop_chatbot_verloop_chatbot_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./verloop-chatbot/verloop-chatbot.component */ 60601);
















let HomePageModule = class HomePageModule {
};
HomePageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_11__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_12__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_13__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_14__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_15__.IonicModule,
            _home_routing_module__WEBPACK_IMPORTED_MODULE_4__.HomePageRoutingModule,
            src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_6__.SharedModule,
            _dashboard_dashboard_module__WEBPACK_IMPORTED_MODULE_1__.DashboardPageModule,
            _claims_history_claims_history_module__WEBPACK_IMPORTED_MODULE_0__.ClaimsHistoryPageModule,
            _policy_policy_module__WEBPACK_IMPORTED_MODULE_5__.PolicyPageModule,
        ],
        declarations: [
            _home_page__WEBPACK_IMPORTED_MODULE_3__.HomePage,
            _home_care_home_care_component__WEBPACK_IMPORTED_MODULE_2__.HomeCareComponent,
            _inquiries_history_inquiries_history_component__WEBPACK_IMPORTED_MODULE_7__.InquiriesHistoryComponent,
            src_app_register_third_party_component__WEBPACK_IMPORTED_MODULE_8__.RegisterThirdPartyComponent,
            _medication_delivery_medication_delivery_component__WEBPACK_IMPORTED_MODULE_9__.MedicationDeliveryPage,
            _verloop_chatbot_verloop_chatbot_component__WEBPACK_IMPORTED_MODULE_10__.VerloopChatbotPage,
        ],
    })
], HomePageModule);



/***/ }),

/***/ 10678:
/*!*****************************************!*\
  !*** ./src/app/pages/home/home.page.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HomePage": () => (/* binding */ HomePage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _home_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./home.page.html?ngResource */ 8380);
/* harmony import */ var _home_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./home.page.scss?ngResource */ 12260);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! @ionic/storage-angular */ 80190);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/shared/data/constants */ 74676);
/* harmony import */ var src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/shared/data/enum/screen */ 68302);
/* harmony import */ var _service_signin_signin_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../service/signin/signin.service */ 91265);
/* harmony import */ var src_app_shared_components_nextgen_dialog_nextgen_dialog_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/shared/components/nextgen-dialog/nextgen-dialog.service */ 96485);
/* harmony import */ var _switch_policy_switch_policy_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./switch-policy/switch-policy.component */ 48473);
/* harmony import */ var _signup_show_tearms_cookies_show_tearms_cookies_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../signup/show-tearms-cookies/show-tearms-cookies.component */ 46236);
/* harmony import */ var src_app_service_cms_terms_conditions_terms_conditions_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/service/cms/terms-conditions/terms-conditions.service */ 14315);
/* harmony import */ var src_app_service_insurance_insurance_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/service/insurance/insurance.service */ 57072);
/* harmony import */ var _awesome_cordova_plugins_firebase_analytics_ngx__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @awesome-cordova-plugins/firebase-analytics/ngx */ 48852);
/* harmony import */ var src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/app/shared/data/enum/event */ 38570);
/* harmony import */ var src_app_shared_components_insurance_card_member_insurance_card_member_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! src/app/shared/components/insurance-card-member/insurance-card-member.component */ 35586);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! rxjs */ 92218);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! rxjs/operators */ 85921);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! rxjs/operators */ 80522);
/* harmony import */ var _awesome_cordova_plugins_clevertap_ngx__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @awesome-cordova-plugins/clevertap/ngx */ 45363);
/* harmony import */ var src_app_service_user_user_service__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! src/app/service/user/user.service */ 87746);
/* harmony import */ var src_app_service_service_register_service_register_service__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! src/app/service/service-register/service-register.service */ 12829);
/* harmony import */ var src_app_service_utilities_navigator_service__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! src/app/service/utilities/navigator.service */ 38903);
/* harmony import */ var src_app_shared_components_popup_message_popup_message_component__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! src/app/shared/components/popup-message/popup-message.component */ 18290);
/* harmony import */ var src_app_service_utilities_third_party_service__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! src/app/service/utilities/third-party.service */ 47617);
/* harmony import */ var src_app_providers_common_ip_service__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! src/app/providers/common/ip.service */ 10373);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @environments/environment */ 92340);
/* harmony import */ var src_app_providers_api_api_service__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! src/app/providers/api/api.service */ 57985);





























let HomePage = class HomePage {
    constructor(menu, storage, router, authService, dialogSevice, termsConditionsService, route, insuranceService, firebaseAnalytics, modalCtrl, clevertap, userService, registerService, navigatorService, platform, ctr, ipService, navCtrl, thirPartyService, apiService) {
        this.menu = menu;
        this.storage = storage;
        this.router = router;
        this.authService = authService;
        this.dialogSevice = dialogSevice;
        this.termsConditionsService = termsConditionsService;
        this.route = route;
        this.insuranceService = insuranceService;
        this.firebaseAnalytics = firebaseAnalytics;
        this.modalCtrl = modalCtrl;
        this.clevertap = clevertap;
        this.userService = userService;
        this.registerService = registerService;
        this.navigatorService = navigatorService;
        this.platform = platform;
        this.ctr = ctr;
        this.ipService = ipService;
        this.navCtrl = navCtrl;
        this.thirPartyService = thirPartyService;
        this.apiService = apiService;
        this.isSupportBiometric = false;
        this.isMobile = false;
        this.platformName = '';
        this.userLocation = {};
        this.currentTab = 'dashboard';
        this.isShowMandatory = false;
        this.needHelp = false;
        this.versionApp = _environments_environment__WEBPACK_IMPORTED_MODULE_20__.environment.appVersion;
        this.unsubscribe$ = new rxjs__WEBPACK_IMPORTED_MODULE_22__.Subject();
        this.isShowMenu = false;
        this.params = this.route.snapshot.queryParams;
        try {
            this.navigatorService.getAppVersionNative().then(res => {
                this.versionApp = res;
            });
        }
        catch (error) {
            console.log(error);
        }
        ;
        this.storage.set(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_2__.Constants.APP_VERSION, this.versionApp);
        this.initPlatform();
    }
    ionViewWillEnter() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_23__.__awaiter)(this, void 0, void 0, function* () {
            this.isShowMenu = false;
            this.unsubscribe$ = new rxjs__WEBPACK_IMPORTED_MODULE_22__.Subject();
            // this.insuranceService.getPolicy().subscribe(res => {
            //   this.policy = res || this.insuranceService.getPolicyList();
            //   this.insuranceService.setPolicyList(this.policy);
            // })
            this.insuranceService.getPolicyInformation().pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_24__.takeUntil)(this.unsubscribe$)).subscribe((res) => {
                this.policy = this.insuranceService.getPolicyList();
                if (res) {
                    this.currentPolicy = res;
                    const policyDetail = this.insuranceService.getPolicyDetailResponse();
                    if (policyDetail.length > 0) {
                        if (policyDetail[0].ServiceProviderCountryID == 45 && policyDetail[0].ServiceProviderId == 3) {
                            this.actionList = this.actionList.map(obj => {
                                if (obj.key === 'legalInfo') {
                                    return Object.assign(Object.assign({}, obj), { isShow: true }); // update the age field for the object 
                                }
                                return obj; // for all other objects, return them unchanged
                            });
                        }
                        else {
                            this.actionList = this.actionList.map(obj => {
                                if (obj.key === 'legalInfo') {
                                    return Object.assign(Object.assign({}, obj), { isShow: false }); // hide legal info  
                                }
                                return obj;
                            });
                        }
                    }
                    this.loginEvent(policyDetail);
                }
                this.getUserProfile();
                this.getUserContact();
            });
            this.userService.getUserProfileValue().subscribe((res) => {
                this.userImage = res;
            });
            if (!this.userImage) {
                this.userImage = yield this.storage.get(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_2__.Constants.USER_IMAGE);
            }
            if (this.router.url == '/home/dashboard' && this.isShowMenu) {
                // this.onloadAds();
            }
        });
    }
    ionViewWillLeave() {
        this.unsubscribe$.next();
        this.unsubscribe$.complete();
        // this.hideloadAds();
    }
    ngOnInit() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_23__.__awaiter)(this, void 0, void 0, function* () {
            // FirebaseDynamicLinks.addListener('deepLinkOpen', (_) => {
            //   this.moveToTeleconsultationScreen();
            // });
            this.actionList = [
                {
                    title: 'home.profile',
                    classIcon: null,
                    key: 'profile',
                    isShow: true,
                    imageIcon: 'fi_user.svg'
                },
                {
                    title: 'home.notifications',
                    classIcon: null,
                    key: 'notifications',
                    isShow: true,
                    notifications: 3,
                    imageIcon: 'fi_bell.svg'
                },
                {
                    title: 'home.insurance',
                    classIcon: 'file-alt',
                    key: 'insurance',
                    isShow: true
                },
                {
                    title: 'home.help',
                    classIcon: 'question-circle',
                    key: 'help',
                    isShow: true
                },
                {
                    title: 'home.terms',
                    classIcon: 'info-circle',
                    key: 'terms',
                    isShow: true
                },
                {
                    title: 'home.privacy',
                    classIcon: 'lock-alt',
                    key: 'privacy',
                    isShow: true
                },
                {
                    title: 'home.legalInformation',
                    classIcon: null,
                    imageIcon: 'legal-info.svg',
                    key: 'legalInfo',
                    isShow: false
                },
                {
                    title: 'home.cookiesPolicy',
                    classIcon: null,
                    imageIcon: 'fi_user.svg',
                    key: 'cookiesPolicy',
                    isShow: true
                },
                {
                    title: 'home.language',
                    classIcon: null,
                    key: 'language',
                    isShow: true,
                    isShowNavigationIcon: true,
                    imageIcon: 'fi_globe.svg'
                },
                // {
                //   title: 'home.settings',
                //   classIcon: 'setting',
                //   key: 'settings',
                //   isShow: true
                // },
                {
                    title: 'home.logout',
                    classIcon: null,
                    key: 'logout',
                    isShow: true,
                    imageIcon: 'fi_log-out.svg'
                },
            ];
        });
    }
    initPlatform() {
        if (this.platform.is('android')) {
            this.platfrm = 'android';
        }
        else if (this.platform.is('iphone')) {
            this.platfrm = 'iphone';
        }
    }
    openDialog() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_23__.__awaiter)(this, void 0, void 0, function* () {
            this.dialogSevice.open(_switch_policy_switch_policy_component__WEBPACK_IMPORTED_MODULE_6__.SwitchPolicyComponent, {
                position: 'bottom',
                data: {
                    policy: this.policy
                },
                title: 'switchpolicy.title',
                canClose: true,
            }).afterClosed().subscribe((res) => (0,tslib__WEBPACK_IMPORTED_MODULE_23__.__awaiter)(this, void 0, void 0, function* () {
                var _a, _b;
                if (res === undefined && !this.currentPolicy.beneficiaryId) {
                    this.showPopUpClosedPolicy();
                    (_a = window === null || window === void 0 ? void 0 : window._HGW) === null || _a === void 0 ? void 0 : _a.authenticateMember();
                    return;
                }
                if (res && res !== 'link-new-policy') {
                    this.getCommonSetting(res);
                    (_b = window === null || window === void 0 ? void 0 : window._HGW) === null || _b === void 0 ? void 0 : _b.authenticateMember();
                    this.menu.close('profile-menu');
                }
            }));
            yield this.storage.set(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_2__.Constants.OPENNED_POPUP, true);
            this.menu.close('profile-menu');
        });
    }
    getCommonSetting(policyApply) {
        var _a, _b;
        this.currentPolicy = policyApply;
        this.currentPolicy.beneficiaryId = (_b = (_a = policyApply.policiesDetails) === null || _a === void 0 ? void 0 : _a[0]) === null || _b === void 0 ? void 0 : _b.beneficiaryId;
        this.insuranceService.getPayerSetting(policyApply).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_25__.mergeMap)(payersetting => {
            this.insuranceService.setPayerSettingValue(payersetting);
            return this.insuranceService.getMemberList(policyApply);
        })).subscribe(res => {
            this.insuranceService.setMemberListValue(res);
            if (res && res.length > 0) {
                policyApply.dependent = res.length === 1 ? true : false;
            }
            this.insuranceService.setPolicyInformation(policyApply);
            this.storage.set(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_2__.Constants.CURRENT_USER_POLICY_ID, policyApply.userPolicyId);
        });
    }
    showPopUpClosedPolicy() {
        this.dialogSevice.open(src_app_shared_components_popup_message_popup_message_component__WEBPACK_IMPORTED_MODULE_17__.PopupMessageComponent, {
            data: {
                content: 'switchPolicy.pleaseLinkPolicy',
                textYes: 'switchPolicy.linkPolicy',
            },
            position: 'middle',
            title: 'title.wrongTitleMessage',
            width: '90%',
            canClose: true,
        }).afterClosed().subscribe(() => {
            this.openDialog();
        });
    }
    openMenu() {
        console.log('open this this.menu:', this.menu.toggle('profile-menu'));
        // this.menu.enable(true, 'profile-menu');
        this.menu.open('profile-menu').then((res) => {
            this.isShowMenu = res;
        });
        // this.hideloadAds();
    }
    closeMenu() {
        this.menu.close('profile-menu').then((res) => {
            this.isShowMenu = res;
        });
        // this.hideloadAds();
        if (this.router.url == '/home/dashboard') {
            // this.onloadAds();
        }
    }
    onLogOut() {
        this.closeMenu();
        // this.disableBiometricSetting();
        this.authService.logout();
        this.authService.dataUser.next(null);
        // window.location.reload();
    }
    disableBiometricSetting() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_23__.__awaiter)(this, void 0, void 0, function* () {
            yield this.storage.set(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_2__.Constants.BIOMETRIC_READY, 'false');
        });
    }
    settingBiometric() {
        this.moveToBiometricScreen();
    }
    settingLanguage() {
        this.menu.close('profile-menu');
        this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_3__.Screens.LanguageSelection], { queryParams: { redirectTo: 'auth/home' } });
    }
    moveToBiometricScreen() {
        this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_3__.Screens.Biometric]);
    }
    moveToTeleconsultationScreen() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_23__.__awaiter)(this, void 0, void 0, function* () {
            if (this.router.url != '/home/add-policy'
                && this.router.url != '/welcome'
                && this.router.url != '/signin'
                && this.authService.isLoggedIn) {
                yield this.thirPartyService.startTeleconsulutationSDK();
            }
        });
    }
    redirectToNotification() {
        this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_3__.Screens.Notification], { queryParams: { redirectTo: 'homePage' } });
    }
    onNavigate(item) {
        var _a;
        switch (item.key) {
            case 'logout':
                this.onLogOut();
                break;
            case 'language':
                this.settingLanguage();
                break;
            case 'biometric':
                this.settingBiometric();
                this.menu.close('profile-menu');
                break;
            case 'notifications':
                this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_3__.Screens.Notification], { queryParams: { redirectTo: 'side-menu' } });
                this.menu.close('profile-menu');
                break;
            case 'profile':
                this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_3__.Screens.EditProfile]);
                this.menu.close('profile-menu');
                break;
            case 'insurance':
                this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_3__.Screens.MyDocument], { queryParams: { beneficiaryId: (_a = this.currentPolicy) === null || _a === void 0 ? void 0 : _a.beneficiaryId } });
                this.menu.close('profile-menu');
                break;
            case 'help':
                this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_3__.Screens.HelpAndSupport]);
                this.menu.close('profile-menu');
                break;
            case 'privacy':
                this.redirectToPolicy();
                this.menu.close('profile-menu');
                break;
            case 'terms':
                this.showTerms();
                this.menu.close('profile-menu');
                break;
            case 'cookiesPolicy':
                this.redirectToPolicy();
                this.menu.close('profile-menu');
                break;
            case 'legalInfo':
                this.showLegalIno();
                this.menu.close('profile-menu');
                break;
            default:
        }
    }
    onTabChange(e) {
        this.firebaseAnalytics.logEvent(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_11__.GA4Event.HomeNavigationChanged, { category: e.tab });
        this.clevertap.recordEventWithNameAndProps(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_11__.GA4Event.HomeNavigationChanged, { category: e.tab });
        this.currentTab = this.tabs.getSelected();
        this.checkNeedHelp();
    }
    showTerms() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_23__.__awaiter)(this, void 0, void 0, function* () {
            this.termsConditionsService.getTermsConditions().subscribe((data) => {
                this.dialogSevice.open(_signup_show_tearms_cookies_show_tearms_cookies_component__WEBPACK_IMPORTED_MODULE_7__.ShowTearmsCookiesComponent, {
                    data: {
                        text: data[0].description,
                    },
                    title: data[0].title,
                    position: 'middle',
                    width: '90%',
                    height: '80%',
                });
            });
            yield this.storage.set(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_2__.Constants.OPENNED_POPUP, true);
        });
    }
    showLegalIno() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_23__.__awaiter)(this, void 0, void 0, function* () {
            this.termsConditionsService.getLegalInformation().subscribe((data) => {
                this.dialogSevice.open(_signup_show_tearms_cookies_show_tearms_cookies_component__WEBPACK_IMPORTED_MODULE_7__.ShowTearmsCookiesComponent, {
                    data: {
                        text: data[0].description,
                    },
                    title: data[0].title,
                    position: 'middle',
                    width: '90%',
                    height: '80%',
                });
            });
            yield this.storage.set(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_2__.Constants.OPENNED_POPUP, true);
        });
    }
    // async redirectToPolicy() {
    //   const language = await this.storage.get(Constants.PREFERED_LANGUAGE);
    //   this.homeService.getPolicyLanguage().subscribe((data) => {
    //     const description = data.find(e => e.iso == language) || { content: 'This language is not supported.' };
    //     this.dialogSevice.open<ShowTearmsCookiesComponent>(
    //       ShowTearmsCookiesComponent,
    //       {
    //         data: {
    //           text: description.content,
    //         },
    //         title: 'privacyPolicy.policy',
    //         position: 'middle',
    //         width: '90%',
    //         height: '80%',
    //       },
    //     );
    //   });
    // }
    redirectToPolicy() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_23__.__awaiter)(this, void 0, void 0, function* () {
            const request = {
                applicationId: 1,
                cmsUserId: 1
            };
            this.termsConditionsService.getCookiesPolicy(request).subscribe((value) => {
                this.dialogSevice.open(_signup_show_tearms_cookies_show_tearms_cookies_component__WEBPACK_IMPORTED_MODULE_7__.ShowTearmsCookiesComponent, {
                    data: {
                        text: value[0].description
                    },
                    title: value[0].title,
                    position: 'middle',
                    width: '90%',
                    height: '80%'
                });
            });
            yield this.storage.set(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_2__.Constants.OPENNED_POPUP, true);
        });
    }
    showInsuranceCard() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_23__.__awaiter)(this, void 0, void 0, function* () {
            const ref = yield this.modalCtrl.create({
                component: src_app_shared_components_insurance_card_member_insurance_card_member_component__WEBPACK_IMPORTED_MODULE_12__.InsuranceCardMemberComponent,
                componentProps: {
                    beneficiaryId: this.currentPolicy.beneficiaryId,
                },
            });
            ref.present();
        });
    }
    onNextCare() {
        this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_3__.Screens.Home]);
    }
    getUserContact() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_23__.__awaiter)(this, void 0, void 0, function* () {
            const contacts = yield this.storage.get(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_2__.Constants.USER_CONTACT);
            this.userContact = {
                phones: contacts === null || contacts === void 0 ? void 0 : contacts.filter(e => e.type === 'phone' && e.isVerified === 1),
                emails: contacts === null || contacts === void 0 ? void 0 : contacts.filter(e => e.type === 'email' && e.isVerified === 1)
            };
        });
    }
    getUserProfile() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_23__.__awaiter)(this, void 0, void 0, function* () {
            this.userProfile = yield this.storage.get(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_2__.Constants.USER_PROFILE);
            this.ctr.detectChanges();
            // this.DOB = this.userProfile.dateOfBirth;
        });
    }
    onNeedHelp() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_23__.__awaiter)(this, void 0, void 0, function* () {
            this.firebaseAnalytics.logEvent(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_11__.GA4Event.NeedHelpStarted, {
                category_name: this.currentTab,
                category_id: this.currentTab,
                subcategory_name: this.currentTab,
                subcategory_id: this.currentTab
            });
            this.clevertap.recordEventWithNameAndProps(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_11__.GA4Event.NeedHelpStarted, {
                category_name: this.currentTab,
                category_id: this.currentTab,
                subcategory_name: this.currentTab,
                subcategory_id: this.currentTab
            });
            if (this.currentTab == 'policy-page') {
                this.router.navigate(['/' + 'auth/verloop-chatbot'], {
                    queryParams: {
                        pageName: 'PolicyBenefits'
                    }
                });
            }
            else if (this.currentTab == 'claims-history') {
                this.router.navigate(['/' + 'auth/verloop-chatbot'], {
                    queryParams: {
                        pageName: 'Claims'
                    }
                });
            }
            else if (this.currentTab == 'home-care') {
                this.clevertap.recordEventWithName(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_11__.ClevertapEvent.policy_coverage_home_screen_need_help);
                this.router.navigate(['/' + 'auth/verloop-chatbot'], {
                    queryParams: {
                        pageName: 'Care'
                    }
                });
            }
        });
    }
    loginEvent(policyDetail) {
        var _a, _b;
        return (0,tslib__WEBPACK_IMPORTED_MODULE_23__.__awaiter)(this, void 0, void 0, function* () {
            const userId = yield this.storage.get(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_2__.Constants.USERID);
            const userName = yield this.storage.get(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_2__.Constants.USERNAME);
            const contacts = yield this.storage.get(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_2__.Constants.USER_CONTACT);
            const contact = {
                emails: contacts.filter(e => e.type === 'email' && e.isVerified),
                phones: contacts.filter(e => e.type === 'phone' && e.isVerified)
            };
            const userData = {
                BeneficiaryId: this.currentPolicy.policiesDetails[0].beneficiaryId,
                Identity: this.currentPolicy.policiesDetails[0].beneficiaryId,
                PayerId: this.currentPolicy.policiesDetails[0].payerId,
                BeneficiaryType: this.currentPolicy.policiesDetails[0].serviceProvId,
                MasterContractId: this.currentPolicy.policiesDetails[0].mcontractId,
                PolicyEffectiveDate: this.currentPolicy.policiesDetails[0].policyStartDay,
                PolicyExpiryDate: this.currentPolicy.policiesDetails[0].policyEndDay,
                NetworkId: 8,
                Name: policyDetail[0].Beneficiary.firstname,
                Phone: (_a = contact.phones[0]) === null || _a === void 0 ? void 0 : _a.contactInfo,
                Email: (_b = contact.emails[0]) === null || _b === void 0 ? void 0 : _b.contactInfo,
                Gender: policyDetail[0].Beneficiary.gender === 1 ? 'M' : 'F',
                DOB: policyDetail[0].Beneficiary ? (new Date(policyDetail[0].Beneficiary.dob)).toISOString().slice(0, 10).replace('T', ' ') : null,
                PayerCountry: 0,
                City: '',
                PayerName: this.currentPolicy.policiesDetails[0].payerName,
                PolicyHolder: this.currentPolicy.policiesDetails[0].policyHolder,
                FOB: 0,
                DependentNames: this.currentPolicy.policiesDetails[0].firstName,
                Age: policyDetail[0].Beneficiary.Age,
                AcquistionType: '',
                AppVersion: yield this.storage.get(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_2__.Constants.APP_VERSION),
                Platform: yield this.storage.get(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_2__.Constants.PLATFORM),
                MSGEmail: true,
                MSGPush: true,
                MSGSms: true,
                MyNCDeviceId: yield this.storage.get(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_2__.Constants.DEVICE_ID),
                MyNCUserId: userId,
            };
            console.log('User Data: ' + userData.Identity);
            this.clevertap.onUserLogin(userData);
            this.storage.set(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_2__.Constants.CLEVERTAP_PROFILE_INFO, userData);
            this.clevertap.profileSet(userData);
        });
    }
    onloadAds() {
        const element1 = document.getElementById('nextcare-ads');
        element1.style.display = 'block';
        const element2 = document.getElementById('main-content');
        element2.style.marginTop = '180px';
    }
    hideloadAds() {
        const element1 = document.getElementById('nextcare-ads');
        element1.style.display = 'none';
        const element2 = document.getElementById('main-content');
        element2.style.marginTop = 'unset';
    }
    onBack() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_23__.__awaiter)(this, void 0, void 0, function* () {
            this.navCtrl.back();
        });
    }
    checkNeedHelp() {
        this.needHelp = this.insuranceService.checkPayerSetting(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_2__.Constants.ENABLE_Member_Inquiry, true);
        switch (this.currentTab) {
            case 'inquiriesHistory':
                this.needHelp = false;
                break;
            case 'home-care':
                this.needHelp = false;
                break;
            case 'claims-history':
                this.needHelp = this.needHelp;
                break;
            case 'policy-page':
                this.needHelp = this.needHelp;
                break;
        }
        // switch (this.currentTab) {
        //   case 'inquiriesHistory':
        //     this.needHelp = true
        //     break;
        //   case 'claims-history':
        //     this.needHelp = false;
        //     break;
        //   case 'home-care':
        //     this.needHelp = true;
        //     break; 
        //   case 'dashboard':
        //     this.needHelp = false;
        //     break;
        //   case 'policy-page':
        //     this.needHelp = false;
        //     break;
        // }
    }
};
HomePage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_26__.MenuController },
    { type: _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_27__.Storage },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_28__.Router },
    { type: _service_signin_signin_service__WEBPACK_IMPORTED_MODULE_4__.SigninService },
    { type: src_app_shared_components_nextgen_dialog_nextgen_dialog_service__WEBPACK_IMPORTED_MODULE_5__.DialogService },
    { type: src_app_service_cms_terms_conditions_terms_conditions_service__WEBPACK_IMPORTED_MODULE_8__.TermsConditionsService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_28__.ActivatedRoute },
    { type: src_app_service_insurance_insurance_service__WEBPACK_IMPORTED_MODULE_9__.InsuranceService },
    { type: _awesome_cordova_plugins_firebase_analytics_ngx__WEBPACK_IMPORTED_MODULE_10__.FirebaseAnalytics },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_26__.ModalController },
    { type: _awesome_cordova_plugins_clevertap_ngx__WEBPACK_IMPORTED_MODULE_13__.CleverTap },
    { type: src_app_service_user_user_service__WEBPACK_IMPORTED_MODULE_14__.UserService },
    { type: src_app_service_service_register_service_register_service__WEBPACK_IMPORTED_MODULE_15__.ServiceRegisterService },
    { type: src_app_service_utilities_navigator_service__WEBPACK_IMPORTED_MODULE_16__.NavigatorHelperService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_26__.Platform },
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_29__.ChangeDetectorRef },
    { type: src_app_providers_common_ip_service__WEBPACK_IMPORTED_MODULE_19__.IpService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_26__.NavController },
    { type: src_app_service_utilities_third_party_service__WEBPACK_IMPORTED_MODULE_18__.ThirdPartyService },
    { type: src_app_providers_api_api_service__WEBPACK_IMPORTED_MODULE_21__.ApiService }
];
HomePage.propDecorators = {
    tabs: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_29__.ViewChild, args: ['tabs',] }]
};
HomePage = (0,tslib__WEBPACK_IMPORTED_MODULE_23__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_29__.Component)({
        selector: 'app-home',
        template: _home_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_home_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], HomePage);



/***/ }),

/***/ 70320:
/*!*****************************************************************************!*\
  !*** ./src/app/pages/home/inquiries-history/inquiries-history.component.ts ***!
  \*****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "InquiriesHistoryComponent": () => (/* binding */ InquiriesHistoryComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _inquiries_history_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./inquiries-history.component.html?ngResource */ 74154);
/* harmony import */ var _inquiries_history_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./inquiries-history.component.scss?ngResource */ 33745);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs */ 92218);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! rxjs/operators */ 85921);
/* harmony import */ var src_app_model_control_control_model__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/model/control/control.model */ 45482);
/* harmony import */ var src_app_service_inquiries_country_inquiries_country_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/service/inquiries-country/inquiries-country.service */ 34743);
/* harmony import */ var src_app_service_insurance_insurance_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/service/insurance/insurance.service */ 57072);
/* harmony import */ var src_app_service_language_language_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/service/language/language.service */ 11281);
/* harmony import */ var src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/shared/data/enum/screen */ 68302);












let InquiriesHistoryComponent = class InquiriesHistoryComponent {
    constructor(router, inquiriesCountryService, insuranceService, route, languageService) {
        this.router = router;
        this.inquiriesCountryService = inquiriesCountryService;
        this.insuranceService = insuranceService;
        this.route = route;
        this.languageService = languageService;
        this.listFilter = [];
        this.unsubscribe$ = new rxjs__WEBPACK_IMPORTED_MODULE_7__.Subject();
        this.locationCountry = false;
        this.location = '';
        this.TYPE = src_app_model_control_control_model__WEBPACK_IMPORTED_MODULE_2__.ControlType;
        this.lang = 'en';
        this.params = this.route.snapshot.queryParams;
        let countryId = 0;
        if (this.insuranceService.getPolicyDetailResponse()) {
            countryId = this.insuranceService.getPolicyDetailResponse()[0].Payer.Address.countryId;
        }
        if (countryId === 32) {
            this.locationCountry = true;
        }
    }
    ngOnInit() { }
    ionViewWillEnter() {
        this.unsubscribe$ = new rxjs__WEBPACK_IMPORTED_MODULE_7__.Subject();
        this.getInformation();
        this.getLanguage();
    }
    ionViewWillLeave() {
        this.unsubscribe$.next();
        this.unsubscribe$.complete();
    }
    getLanguage() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__awaiter)(this, void 0, void 0, function* () {
            this.lang = this.languageService.getISOLanguageCode();
        });
    }
    getInformation() {
        this.insuranceService.getPolicyInformation().pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_9__.takeUntil)(this.unsubscribe$)).subscribe((res) => {
            if (!res)
                return;
            this.currentPolicy = res;
            this.getInquiriesHistory();
        });
    }
    onChangeCreate() {
        this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_6__.Screens.InquiriesCountry]);
    }
    getInquiriesHistory() {
        const request = {
            userPolicyId: this.currentPolicy.userPolicyId,
        };
        this.inquiriesCountryService.getInquiriesHistory(request).subscribe((res) => {
            this.inquiryHistory = res.map((item) => ({
                sendername: item.sendername,
                reasonofcontactid: item.reasonofcontactid,
                inquirynbr: item.inquirynbr,
                inquirysequencenbr: item.inquirysequencenbr,
                reasonofcall: item.reasonofcall,
                creationdate: item.creationdate,
                inquirystatus: item.inquirystatus
            }));
        });
    }
    onSearchChange(value) {
        if (!value) {
            return;
        }
    }
    onBack() {
        if (this.params.redirectTo == 'login') {
            this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_6__.Screens.SignIn]);
        }
        else if (this.params.redirectTo == 'signup') {
            this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_6__.Screens.SignUp]);
        }
    }
};
InquiriesHistoryComponent.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_10__.Router },
    { type: src_app_service_inquiries_country_inquiries_country_service__WEBPACK_IMPORTED_MODULE_3__.InquiriesCountryService },
    { type: src_app_service_insurance_insurance_service__WEBPACK_IMPORTED_MODULE_4__.InsuranceService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_10__.ActivatedRoute },
    { type: src_app_service_language_language_service__WEBPACK_IMPORTED_MODULE_5__.LanguageService }
];
InquiriesHistoryComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_11__.Component)({
        selector: 'app-inquiries-history',
        template: _inquiries_history_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_inquiries_history_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], InquiriesHistoryComponent);



/***/ }),

/***/ 36307:
/*!******************************************************************!*\
  !*** ./src/app/pages/home/policy/benefits/benefits.component.ts ***!
  \******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "BenefitsComponent": () => (/* binding */ BenefitsComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _benefits_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./benefits.component.html?ngResource */ 83896);
/* harmony import */ var _benefits_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./benefits.component.scss?ngResource */ 71798);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);




let BenefitsComponent = class BenefitsComponent {
    constructor() { }
    ngOnInit() {
    }
};
BenefitsComponent.ctorParameters = () => [];
BenefitsComponent.propDecorators = {
    card: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.Input, args: ['card',] }]
};
BenefitsComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.Component)({
        selector: 'app-benefits',
        template: _benefits_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_benefits_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], BenefitsComponent);



/***/ }),

/***/ 17668:
/*!************************************************************!*\
  !*** ./src/app/pages/home/policy/policy-routing.module.ts ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PolicyPageRoutingModule": () => (/* binding */ PolicyPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _policy_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./policy.page */ 16808);




const routes = [
    {
        path: '',
        component: _policy_page__WEBPACK_IMPORTED_MODULE_0__.PolicyPage
    },
];
let PolicyPageRoutingModule = class PolicyPageRoutingModule {
};
PolicyPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
    })
], PolicyPageRoutingModule);



/***/ }),

/***/ 10229:
/*!****************************************************!*\
  !*** ./src/app/pages/home/policy/policy.module.ts ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PolicyPageModule": () => (/* binding */ PolicyPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/shared/shared.module */ 44466);
/* harmony import */ var _policy_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./policy-routing.module */ 17668);
/* harmony import */ var _policy_page__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./policy.page */ 16808);
/* harmony import */ var _benefits_benefits_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./benefits/benefits.component */ 36307);
/* harmony import */ var _angular_material_expansion__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/material/expansion */ 12928);










let PolicyPageModule = class PolicyPageModule {
};
PolicyPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.NgModule)({
        declarations: [
            _policy_page__WEBPACK_IMPORTED_MODULE_2__.PolicyPage,
            _benefits_benefits_component__WEBPACK_IMPORTED_MODULE_3__.BenefitsComponent,
        ],
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_6__.CommonModule,
            _policy_routing_module__WEBPACK_IMPORTED_MODULE_1__.PolicyPageRoutingModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.IonicModule,
            src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_0__.SharedModule,
            _angular_material_expansion__WEBPACK_IMPORTED_MODULE_9__.MatExpansionModule
        ],
        providers: []
    })
], PolicyPageModule);



/***/ }),

/***/ 16808:
/*!**************************************************!*\
  !*** ./src/app/pages/home/policy/policy.page.ts ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PolicyPage": () => (/* binding */ PolicyPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _policy_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./policy.page.html?ngResource */ 4703);
/* harmony import */ var _policy_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./policy.page.scss?ngResource */ 98156);
/* harmony import */ var _awesome_cordova_plugins_clevertap_ngx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @awesome-cordova-plugins/clevertap/ngx */ 45363);
/* harmony import */ var _awesome_cordova_plugins_firebase_analytics_ngx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @awesome-cordova-plugins/firebase-analytics/ngx */ 48852);
/* harmony import */ var src_app_service_policy_download_document_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/service/policy/download-document.service */ 51828);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var src_app_model_control_control_model__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/model/control/control.model */ 45482);
/* harmony import */ var _search_benifits_search_benifits_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./search-benifits/search-benifits.component */ 66983);
/* harmony import */ var src_app_service_policy_policy_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/service/policy/policy.service */ 34164);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var src_app_service_insurance_insurance_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/service/insurance/insurance.service */ 57072);
/* harmony import */ var _capacitor_filesystem__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @capacitor/filesystem */ 91662);
/* harmony import */ var src_app_providers_common_toast_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/app/providers/common/toast.service */ 42028);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! rxjs */ 92218);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! rxjs/operators */ 85921);
/* harmony import */ var src_app_shared_components_open_document_from_base64_open_document_from_base64_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/app/shared/components/open-document-from-base64/open-document-from-base64.component */ 67619);
/* harmony import */ var _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! @ionic/storage-angular */ 80190);
/* harmony import */ var src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! src/app/shared/data/constants */ 74676);
/* harmony import */ var src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! src/app/shared/data/enum/event */ 38570);
/* harmony import */ var src_app_shared_components_nextgen_dialog_nextgen_dialog_service__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! src/app/shared/components/nextgen-dialog/nextgen-dialog.service */ 96485);
/* harmony import */ var src_app_shared_components_popup_message_popup_message_component__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! src/app/shared/components/popup-message/popup-message.component */ 18290);
/* harmony import */ var _service_language_language_service__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ../../../service/language/language.service */ 11281);
/* harmony import */ var src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! src/app/shared/data/enum/screen */ 68302);
/* harmony import */ var src_app_service_utilities_third_party_service__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! src/app/service/utilities/third-party.service */ 47617);


























let PolicyPage = class PolicyPage {
    constructor(modalCtrl, policyService, router, insuranceService, downloadDocumentService, toastService, storage, firebaseAnalytics, clevertap, dialogService, languageService, platform, thirdPartyService) {
        this.modalCtrl = modalCtrl;
        this.policyService = policyService;
        this.router = router;
        this.insuranceService = insuranceService;
        this.downloadDocumentService = downloadDocumentService;
        this.toastService = toastService;
        this.storage = storage;
        this.firebaseAnalytics = firebaseAnalytics;
        this.clevertap = clevertap;
        this.dialogService = dialogService;
        this.languageService = languageService;
        this.platform = platform;
        this.thirdPartyService = thirdPartyService;
        this.slideOpts = {
            speed: 1000,
            spaceBetween: 10,
            breakpoints: {
                '320': { slidesPerView: 1.2 },
                '360': { slidesPerView: 1.4 },
                '480': { slidesPerView: 1.6 },
                '720': { slidesPerView: 2.2 },
                '1080': { slidesPerView: 2.4 },
                '1440': { slidesPerView: 3.2 },
            },
        };
        this.TYPE = src_app_model_control_control_model__WEBPACK_IMPORTED_MODULE_5__.ControlType;
        this.subs = [];
        this.mimeType = 'data:application/pdf';
        this.unsubscribe$ = new rxjs__WEBPACK_IMPORTED_MODULE_19__.Subject();
        this.lang = 'en';
        this.firebaseAnalytics.logEvent(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_13__.GA4Event.ICCategorySelected, { category_name: 'policy-page', category_id: 'policy-page' });
        this.clevertap.recordEventWithNameAndProps(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_13__.GA4Event.ICCategorySelected, { category: 'policy-page', category_id: 'policy-page' });
    }
    ionViewWillEnter() {
        this.unsubscribe$ = new rxjs__WEBPACK_IMPORTED_MODULE_19__.Subject();
        this.getPolicyInformation();
        this.getLanguage();
    }
    getLanguage() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_20__.__awaiter)(this, void 0, void 0, function* () {
            this.lang = this.languageService.getISOLanguageCode();
        });
    }
    ionViewDidEnter() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_20__.__awaiter)(this, void 0, void 0, function* () {
            this.subscription = this.platform.backButton.subscribeWithPriority(9999, () => (0,tslib__WEBPACK_IMPORTED_MODULE_20__.__awaiter)(this, void 0, void 0, function* () {
                this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_17__.Screens.Home]);
            }));
        });
    }
    ionViewWillLeave() {
        this.unsubscribe$.next();
        this.unsubscribe$.complete();
        this.subscription.unsubscribe();
    }
    onHighlightCard(card) {
        const policy = Object.assign(Object.assign({}, this.currentPolicy), { beneficiaryId: card.beneficiaryId });
        const policyDetailsRequest = {
            userPolicyId: policy.userPolicyId,
            mcontractId: policy.policiesDetails[0].mcontractId,
            beneficiaryId: policy.beneficiaryId,
            contractId: policy.policiesDetails[0].contractId,
        };
        this.selectedBeneficiaryId = policy.beneficiaryId;
        this.insuranceService.getPolicyDetails(policyDetailsRequest).subscribe(res => {
            this.getInformationPolicyDetails(policy, res);
            this.storage.set(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_12__.Constants.RECENTS_BENEFIT, []);
        });
    }
    dowloadTravel() {
        this.clevertap.recordEventWithName(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_13__.ClevertapEvent.policy_coverage_home_screen_travel_certificate);
        const travelCertificateRequest = {
            userPolicyId: this.currentPolicy.userPolicyId,
            mcontractId: this.currentPolicy.policiesDetails[0].mcontractId,
            serviceProvId: this.currentPolicyDetail.serviceProvId,
            endorsementId: this.currentPolicyDetail.endorsementId,
            moralEntity: this.currentPolicyDetail.moralEntity,
            beneficiaryId: this.currentPolicyDetail.beneficiaryId,
        };
        this.downloadDocumentService.getTravelCertificate(travelCertificateRequest).subscribe((value) => (0,tslib__WEBPACK_IMPORTED_MODULE_20__.__awaiter)(this, void 0, void 0, function* () {
            // this.downloadBase64FileMobile(data.base64)
            if (value) {
                const ref = yield this.modalCtrl.create({
                    component: src_app_shared_components_open_document_from_base64_open_document_from_base64_component__WEBPACK_IMPORTED_MODULE_11__.OpenDocumentFromBase64Component,
                    componentProps: {
                        base64: value.base64,
                        name: 'TravelCertificate.pdf',
                        type: 2 // 2==pdf, 1==image
                    },
                });
                ref.present();
                const { data } = yield ref.onWillDismiss();
                if (data) {
                    //
                }
            }
            else if (value == null) {
                this.dialogService.open(src_app_shared_components_popup_message_popup_message_component__WEBPACK_IMPORTED_MODULE_15__.PopupMessageComponent, {
                    data: {
                        content: 'policy.documentNotAvailable',
                        textYes: 'button.ok',
                    },
                    // title: error.status,
                    title: 'title.wrongTitleMessage',
                    position: 'middle',
                    width: '90%',
                });
            }
        }), (error) => (0,tslib__WEBPACK_IMPORTED_MODULE_20__.__awaiter)(this, void 0, void 0, function* () {
            if (error.status == 200 && error.error.text) {
                const ref = yield this.modalCtrl.create({
                    component: src_app_shared_components_open_document_from_base64_open_document_from_base64_component__WEBPACK_IMPORTED_MODULE_11__.OpenDocumentFromBase64Component,
                    componentProps: {
                        base64: error.error.text,
                        name: 'TravelCertificate.pdf',
                        type: 2, // 2==pdf, 1==image
                    },
                });
                ref.present();
                const { data } = yield ref.onWillDismiss();
                if (data) {
                    //
                }
            }
            if (error.status != 200) {
                this.dialogService.open(src_app_shared_components_popup_message_popup_message_component__WEBPACK_IMPORTED_MODULE_15__.PopupMessageComponent, {
                    data: {
                        content: 'policy.documentNotAvailable',
                        textYes: 'button.ok',
                    },
                    // title: error.status,
                    title: 'title.wrongTitleMessage',
                    position: 'middle',
                    width: '90%',
                }).afterClosed()
                    .subscribe((isYes) => {
                    if (isYes) {
                        // TODO
                    }
                    else {
                        //
                    }
                });
            }
        }));
    }
    downloadTOB() {
        this.clevertap.recordEventWithName(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_13__.ClevertapEvent.policy_coverage_home_screen_table_of_benefits);
        const tobdocumentRequest = {
            userPolicyId: this.currentPolicy.userPolicyId,
            mcontractId: this.currentPolicy.policiesDetails[0].mcontractId,
            productId: this.currentPolicyDetail.productId
        };
        this.downloadDocumentService.getTOBDocuments(tobdocumentRequest).subscribe((docRes) => (0,tslib__WEBPACK_IMPORTED_MODULE_20__.__awaiter)(this, void 0, void 0, function* () {
            console.log('docRes', docRes);
            // this.downloadBase64FileMobile(docRes)
            if (docRes) {
                const ref = yield this.modalCtrl.create({
                    component: src_app_shared_components_open_document_from_base64_open_document_from_base64_component__WEBPACK_IMPORTED_MODULE_11__.OpenDocumentFromBase64Component,
                    componentProps: {
                        base64: docRes,
                        name: 'TOB.pdf',
                        type: 2 // 2==pdf, 1==image
                    },
                });
                ref.present();
                const { data } = yield ref.onWillDismiss();
                if (data) {
                    //
                }
            }
            else if (docRes == null) {
                this.dialogService.open(src_app_shared_components_popup_message_popup_message_component__WEBPACK_IMPORTED_MODULE_15__.PopupMessageComponent, {
                    data: {
                        content: 'policy.documentNotAvailable',
                        textYes: 'button.ok',
                    },
                    // title: error.status,
                    title: 'title.wrongTitleMessage',
                    position: 'middle',
                    width: '90%',
                });
            }
        }), (error) => (0,tslib__WEBPACK_IMPORTED_MODULE_20__.__awaiter)(this, void 0, void 0, function* () {
            if (error.status == 200 && error.error.text) {
                const ref = yield this.modalCtrl.create({
                    component: src_app_shared_components_open_document_from_base64_open_document_from_base64_component__WEBPACK_IMPORTED_MODULE_11__.OpenDocumentFromBase64Component,
                    componentProps: {
                        base64: error.error.text,
                        name: 'TOB.pdf',
                        type: 2, // 2==pdf, 1==image
                    },
                });
                ref.present();
                const { data } = yield ref.onWillDismiss();
                if (data) {
                    //
                }
            }
            if (error.status != 200) {
                this.dialogService.open(src_app_shared_components_popup_message_popup_message_component__WEBPACK_IMPORTED_MODULE_15__.PopupMessageComponent, {
                    data: {
                        content: 'policy.documentNotAvailable',
                        textYes: 'button.ok',
                    },
                    // title: error.status,
                    title: 'title.wrongTitleMessage',
                    position: 'middle',
                    width: '90%',
                }).afterClosed()
                    .subscribe((isYes) => {
                    if (isYes) {
                        // TODO
                    }
                    else {
                        //
                    }
                });
            }
        }));
    }
    downloadCertificate() {
        this.clevertap.recordEventWithName(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_13__.ClevertapEvent.policy_coverage_home_screen_coi);
        // const columnname = this.payerSetting?.find(res => res.columnname === 'MyNEXtCAREQRCertificate')
        const qrCertificate = this.insuranceService.checkPayerSetting(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_12__.Constants.QR_CERTIFICATE, false);
        const reportPolicyCertificateRequest = {
            userPolicyId: this.currentPolicy.userPolicyId,
            mcontractId: this.currentPolicy.policiesDetails[0].mcontractId,
            serviceProvId: this.currentPolicyDetail.serviceProvId,
            endorsementId: this.currentPolicyDetail.endorsementId,
            beneficiaryId: this.currentPolicyDetail.beneficiaryId,
            moralEntity: this.currentPolicyDetail.moralEntity,
        };
        if (qrCertificate == true) {
            reportPolicyCertificateRequest.generateQrCode = 1;
        }
        else {
            reportPolicyCertificateRequest.generateQrCode = 0;
        }
        ;
        this.downloadDocumentService.getCertificateDocument(reportPolicyCertificateRequest).subscribe((certRes) => (0,tslib__WEBPACK_IMPORTED_MODULE_20__.__awaiter)(this, void 0, void 0, function* () {
            // this.downloadBase64FileMobile(certRes.base64)
            if (certRes) {
                const ref = yield this.modalCtrl.create({
                    component: src_app_shared_components_open_document_from_base64_open_document_from_base64_component__WEBPACK_IMPORTED_MODULE_11__.OpenDocumentFromBase64Component,
                    componentProps: {
                        mimeType: this.mimeType,
                        base64: certRes.base64,
                        name: 'COI.pdf',
                        type: 2 // 2==pdf, 1==image
                    },
                });
                ref.present();
                const { data } = yield ref.onWillDismiss();
                if (data) {
                    //
                }
            }
            else if (certRes == null) {
                this.dialogService.open(src_app_shared_components_popup_message_popup_message_component__WEBPACK_IMPORTED_MODULE_15__.PopupMessageComponent, {
                    data: {
                        content: 'policy.documentNotAvailable',
                        textYes: 'button.ok',
                    },
                    // title: error.status,
                    title: 'title.wrongTitleMessage',
                    position: 'middle',
                    width: '90%',
                });
            }
        }), (error) => (0,tslib__WEBPACK_IMPORTED_MODULE_20__.__awaiter)(this, void 0, void 0, function* () {
            if (error.status == 200 && error.error.text) {
                const ref = yield this.modalCtrl.create({
                    component: src_app_shared_components_open_document_from_base64_open_document_from_base64_component__WEBPACK_IMPORTED_MODULE_11__.OpenDocumentFromBase64Component,
                    componentProps: {
                        base64: error.error.text,
                        name: 'COI.pdf',
                        type: 2, // 2==pdf, 1==image
                    },
                });
                ref.present();
                const { data } = yield ref.onWillDismiss();
                if (data) {
                    //
                }
            }
            if (error.status != 200) {
                this.dialogService.open(src_app_shared_components_popup_message_popup_message_component__WEBPACK_IMPORTED_MODULE_15__.PopupMessageComponent, {
                    data: {
                        content: 'policy.documentNotAvailable',
                        textYes: 'button.ok',
                    },
                    // title: error.status,
                    title: 'title.wrongTitleMessage',
                    position: 'middle',
                    width: '90%',
                }).afterClosed()
                    .subscribe((isYes) => {
                    if (isYes) {
                        // TODO
                    }
                    else {
                        //
                    }
                });
            }
        }));
    }
    downloadBase64FileMobile(base64) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_20__.__awaiter)(this, void 0, void 0, function* () {
            const fileName = new Date().getTime() + '.pdf';
            const writeFile = () => (0,tslib__WEBPACK_IMPORTED_MODULE_20__.__awaiter)(this, void 0, void 0, function* () {
                yield _capacitor_filesystem__WEBPACK_IMPORTED_MODULE_9__.Filesystem.writeFile({
                    path: fileName,
                    data: base64,
                    directory: _capacitor_filesystem__WEBPACK_IMPORTED_MODULE_9__.FilesystemDirectory.Documents,
                }).then((_res) => {
                    this.toastService.presentToast('Download Successfully');
                }).catch((error) => {
                    if (error) {
                        this.toastService.presentToast(error.message);
                    }
                    else {
                        this.toastService.presentToast('Something went wrong!');
                    }
                });
            });
            writeFile();
        });
    }
    providerHandler() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_20__.__awaiter)(this, void 0, void 0, function* () {
            const ref = yield this.modalCtrl.create({
                component: _search_benifits_search_benifits_component__WEBPACK_IMPORTED_MODULE_6__.SearchBenifitsComponent,
                componentProps: {
                    fobId: null,
                    placeHolderText: 'searchBenifits.noBenefit'
                }
            });
            ref.present();
        });
    }
    getlistBenifits(model) {
        // this.policyService.listBenifits().subscribe((data) => {
        //   const benefits = data.map(a => {
        //     const benefit = model[0].details.plans.find(res => res.fobId == a.fobId);
        //     return benefit;
        //   }).filter(e => e);
        //   const benefitModel = {
        //     structureVersion: model[0].details.structureVersion,
        //     userPolicyId: this.currentPolicy.userPolicyId,
        //     mcontractId: this.currentPolicy.policiesDetails[0].mcontractId,
        //     beneficiaryId: this.currentPolicyDetail.beneficiaryId,
        //     endorsementId: this.currentPolicyDetail.endorsementId,
        //     productId: this.currentPolicyDetail.productId
        //   }
        //   const fetchs = benefits.map(res => {
        //     return this.policyService.getBenefits({ fobId: res.fobId, ...benefitModel })
        //   })
        //   forkJoin(fetchs).subscribe(res => {
        //     this.policyService.setBenefitsValue(res);
        //     data.map(a => {
        //       const benefits = res.find(e => e[0].fobid == a.fobId);
        //       if (benefits) {
        //         a.enable = true;
        //         a.count = benefits.length;
        //         a.fobId = benefits[0].fobid;
        //       }
        //     })
        //     this.listBenifits = data;
        //   })
        // });
        this.policyService.listBenifits().subscribe(data => {
            data.map(a => {
                const benefit = model[0].details.plans.find(res => res.fobId == a.fobId);
                if (benefit) {
                    a.enable = true;
                    a.fobId = benefit.fobId;
                }
                return benefit;
            }).filter(e => e);
            this.listBenifits = data;
        });
    }
    onClickBenifitsCard(item) {
        if (item.textHeader == 'policy.inPatient') {
            this.firebaseAnalytics.logEvent(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_13__.GA4Event.ICInPatientBenefitSubcategorySelected, {
                category_name: 'Insurance Coverage',
                category_id: '',
                subcategory_name: '',
                subcategory_id: '',
                member_name: this.currentPolicyDetail.firstName,
                member_id: this.currentPolicyDetail.payerId,
                card_number: this.currentPolicyDetail.beneficiaryId
            });
            this.clevertap.recordEventWithNameAndProps(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_13__.GA4Event.ICInPatientBenefitSubcategorySelected, {
                category_name: 'Insurance Coverage',
                category_id: '',
                subcategory_name: '',
                subcategory_id: '',
                card_number: this.currentPolicyDetail.beneficiaryId
            });
            this.clevertap.recordEventWithNameAndProps(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_13__.ClevertapEvent.policy_coverage_home_screen_in_patient, {
                category_name: 'Insurance Coverage',
                category_id: '',
                subcategory_name: '',
                subcategory_id: '',
                member_name: this.currentPolicyDetail.firstName,
                member_id: this.currentPolicyDetail.payerId,
                card_number: this.currentPolicyDetail.beneficiaryId
            });
        }
        else if (item.textHeader == 'policy.outPatient') {
            this.firebaseAnalytics.logEvent(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_13__.GA4Event.ICOutPatientBenefitSubcategorySelected, {
                category_name: 'Insurance Coverage',
                category_id: '',
                subcategory_name: '',
                subcategory_id: '',
                member_name: this.currentPolicyDetail.firstName,
                member_id: this.currentPolicyDetail.payerId,
                card_number: this.currentPolicyDetail.beneficiaryId
            });
            this.clevertap.recordEventWithNameAndProps(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_13__.GA4Event.ICOutPatientBenefitSubcategorySelected, {
                category_name: 'Insurance Coverage',
                category_id: '',
                subcategory_name: '',
                subcategory_id: '',
                card_number: this.currentPolicyDetail.beneficiaryId
            });
            this.clevertap.recordEventWithNameAndProps(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_13__.ClevertapEvent.policy_coverage_home_screen_out_patient, {
                category_name: 'Insurance Coverage',
                category_id: '',
                subcategory_name: '',
                subcategory_id: '',
                member_name: this.currentPolicyDetail.firstName,
                member_id: this.currentPolicyDetail.payerId,
                card_number: this.currentPolicyDetail.beneficiaryId
            });
        }
        else if (item.textHeader == 'policy.dental') {
            this.firebaseAnalytics.logEvent(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_13__.GA4Event.ICDentalBenefitSubcategorySelected, {
                category_name: 'Insurance Coverage',
                category_id: '',
                subcategory_name: '',
                subcategory_id: '',
                member_name: this.currentPolicyDetail.firstName,
                member_id: this.currentPolicyDetail.payerId,
                card_number: this.currentPolicyDetail.beneficiaryId
            });
            this.clevertap.recordEventWithNameAndProps(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_13__.GA4Event.ICDentalBenefitSubcategorySelected, {
                category_name: 'Insurance Coverage',
                category_id: '',
                subcategory_name: '',
                subcategory_id: '',
                card_number: this.currentPolicyDetail.beneficiaryId
            });
            this.clevertap.recordEventWithNameAndProps(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_13__.ClevertapEvent.policy_coverage_home_screen_dental, {
                category_name: 'Insurance Coverage',
                category_id: '',
                subcategory_name: '',
                subcategory_id: '',
                member_name: this.currentPolicyDetail.firstName,
                member_id: this.currentPolicyDetail.payerId,
                card_number: this.currentPolicyDetail.beneficiaryId
            });
        }
        else if (item.textHeader == 'policy.optical') {
            this.firebaseAnalytics.logEvent(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_13__.GA4Event.ICOpticalBenefitSubcategorySelected, {
                category_name: 'Insurance Coverage',
                category_id: '',
                subcategory_name: '',
                subcategory_id: '',
                member_name: this.currentPolicyDetail.firstName,
                member_id: this.currentPolicyDetail.payerId,
                card_number: this.currentPolicyDetail.beneficiaryId
            });
            this.clevertap.recordEventWithNameAndProps(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_13__.GA4Event.ICOpticalBenefitSubcategorySelected, {
                category_name: 'Insurance Coverage',
                category_id: '',
                subcategory_name: '',
                subcategory_id: '',
                card_number: this.currentPolicyDetail.beneficiaryId
            });
            this.clevertap.recordEventWithNameAndProps(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_13__.ClevertapEvent.policy_coverage_home_screen_optical, {
                category_name: 'Insurance Coverage',
                category_id: '',
                subcategory_name: '',
                subcategory_id: '',
                member_name: this.currentPolicyDetail.firstName,
                member_id: this.currentPolicyDetail.payerId,
                card_number: this.currentPolicyDetail.beneficiaryId
            });
        }
        const data = {
            structureVersion: this.coveragesResponse[0].details.structureVersion,
            userPolicyId: this.currentPolicy.userPolicyId,
            mcontractId: this.currentPolicy.policiesDetails[0].mcontractId,
            beneficiaryId: this.currentPolicyDetail.beneficiaryId,
            endorsementId: this.currentPolicyDetail.endorsementId,
            productId: this.currentPolicyDetail.productId,
            fobId: item.fobId
        };
        this.policyService.getBenefits(data).subscribe(res => {
            this.policyService.setBenefitsValue(res);
            this.router.navigate(['/' + item.link], {
                queryParams: {
                    redirectTo: 'Dental-Benifits',
                    fobId: item.fobId,
                    name: this.currentPolicyDetail.firstName,
                    id: this.currentPolicyDetail.payerId,
                    subCategory: item.textHeader,
                    searchBenefit: item.searchBenefit,
                }
            });
        });
    }
    getInformationPolicyDetails(policy, policyDetail) {
        if (policy) {
            this.currentPolicyDetail = {
                contractId: policy.policiesDetails[0].contractId,
                mcontractId: policy.policiesDetails[0].mcontractId,
                payerId: policy.policiesDetails[0].payerId,
                payerName: policyDetail[0].Payer.entity.name,
                productId: policyDetail[0].Beneficiary.product.productId,
                policyStartDay: policyDetail[0].Mcontract.STARTDATE,
                policyEndDay: policyDetail[0].Mcontract.EXPDATE,
                policyNumber: policyDetail[0].Contract.EXTERNALREF,
                policyHolder: policyDetail[0].Contract.NAME,
                serviceProvId: policyDetail[0].ServiceProviderId,
                endorsementId: policyDetail[0].Endorsement.ENDORSEMENTID,
                moralEntity: policyDetail[0].Mcontract.MORALENTITY,
                isActive: policyDetail[0].Beneficiary.IsActive,
                beneficiaryId: policyDetail[0].Beneficiary.BeneficiaryID,
                firstName: policyDetail[0].Beneficiary.firstname,
                status: policyDetail[0].Beneficiary.IsActive ? 'active' : 'expired',
            };
            this.onDisplayOrHideDownloadPolicyCert();
            this.status = this.currentPolicy.status;
            this.onDisplayBenefitsHighlight();
            this.getCoverages(policyDetail[0].Beneficiary.BeneficiaryID);
        }
        ;
    }
    onHideDocuments() {
        if (this.displayTOB == false && this.displayTC == false && this.displayPolicyCert == false) {
            this.hideDocuments = true;
        }
    }
    onDisplayOrHideDownloadDocuments() {
        this.displayTOB = this.insuranceService.checkPayerSetting(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_12__.Constants.ENABLE_PRODUCT_TOB_PRINT, true);
        this.displayTC = this.insuranceService.checkPayerSetting(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_12__.Constants.ISSUECOIT, true);
        // const columnname = this.payerSetting?.find(asd => asd.columnname === 'MyNEXtCAREEnableProductTOBPrint');
        // const columnnameTravel = this.payerSetting?.find(asd => asd.columnname === 'ISSUECOIT');
        // // MyNEXtCAREEnableProductTOBPrint
        // if (columnname) {
        //   this.displayTOB = columnname.required
        // }
        // else {
        //   this.displayTOB = false
        // };
        // if (columnnameTravel) {
        //   this.displayTC = columnnameTravel.required
        // } else {
        //   this.displayTC = false
        // }
    }
    onDisplayOrHideDownloadPolicyCert() {
        const policyCertificateRequest = {
            userPolicyId: this.currentPolicy.userPolicyId,
            mcontractId: this.currentPolicy.policiesDetails[0].mcontractId,
            productId: this.currentPolicyDetail.productId
        };
        this.downloadDocumentService.getPolicyCertificateInfo(policyCertificateRequest).subscribe(policyCertRes => {
            if (policyCertRes) {
                if (policyCertRes.enablepolicycertificate === 1) {
                    this.displayPolicyCert = true;
                }
                else {
                    this.displayPolicyCert = false;
                }
            }
            this.onDisplayOrHideDownloadDocuments();
            this.onHideDocuments();
        });
    }
    getPolicyInformation() {
        this.insuranceService.getPolicyInformation().pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_21__.takeUntil)(this.unsubscribe$)).subscribe((res) => {
            if (!res || this.currentPolicy && this.currentPolicy.policyNumber === res.policyNumber)
                return;
            this.currentPolicy = res;
            this.selectedBeneficiaryId = this.currentPolicy.beneficiaryId;
            this.payerSetting = this.insuranceService.getPayerSettingValue();
            this.getListMemberCard();
            const data = this.insuranceService.getPolicyDetailResponse();
            this.getInformationPolicyDetails(res, data);
            this.storage.set(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_12__.Constants.RECENTS_BENEFIT, []);
        });
    }
    getListMemberCard() {
        this.listFamilyMember = this.insuranceService.getMemberListValue();
    }
    onDisplayBenefitsHighlight() {
        this.displayBenefitsHighlight = !this.insuranceService.checkPayerSetting(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_12__.Constants.DISABLE_POLICY_BENEFITS, true);
        // const columnname = this.payerSetting?.find(x => x.columnname === 'MyNEXtCAREDisablePolicyBenefits')
        // if (columnname) {
        //   if (columnname.required == true) {
        //     this.displayBenefitsHighlight = false
        //   } else {
        //     this.displayBenefitsHighlight = true
        //   }
        // }
    }
    getCoverages(beneficiaryId) {
        var _a;
        if (this.displayBenefitsHighlight && ((_a = this.currentPolicy) === null || _a === void 0 ? void 0 : _a.status) !== 'expired') {
            this.policyService.getCoverages({
                userPolicyId: this.currentPolicy.userPolicyId,
                beneficiaryId: beneficiaryId || this.currentPolicyDetail.beneficiaryId,
            }).subscribe(res => {
                this.coveragesResponse = res;
                const benefit = res;
                this.policyService.setHighLightBenefit(benefit[0].details.plans);
                this.getlistBenifits(this.coveragesResponse);
                console.log('getlistBenifits', this.coveragesResponse);
            });
        }
    }
    ngOnDestroy() {
    }
    onExpansionPanel(isPolicyDetail) {
        this.clevertap.recordEventWithName(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_13__.ClevertapEvent.policy_coverage_home_screen_highlights);
        if (isPolicyDetail) {
            this.firebaseAnalytics.logEvent(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_13__.GA4Event.ICPolicyDetailsViewed, {
                category_name: 'policy-page',
                category_id: 'policy-page',
                member_name: this.currentPolicyDetail.firstName,
                card_number: this.currentPolicyDetail.beneficiaryId,
                insurer: this.currentPolicyDetail.firstName,
                policy_holder: this.currentPolicyDetail.policyHolder,
                policy_number: this.currentPolicyDetail.policyNumber,
                policy_start_date: this.currentPolicyDetail.policyStartDay,
                policy_end_date: this.currentPolicyDetail.policyEndDay,
                insurance_status: this.currentPolicyDetail.status,
            });
            this.clevertap.recordEventWithNameAndProps(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_13__.GA4Event.ICPolicyDetailsViewed, {
                category_name: 'policy-page',
                category_id: 'policy-page',
                member_name: this.currentPolicyDetail.firstName,
                card_number: this.currentPolicyDetail.beneficiaryId,
                insurer: this.currentPolicyDetail.firstName,
                policy_holder: this.currentPolicyDetail.policyHolder,
                policy_number: this.currentPolicyDetail.policyNumber,
                policy_start_date: this.currentPolicyDetail.policyStartDay,
                policy_end_date: this.currentPolicyDetail.policyEndDay,
                insurance_status: this.currentPolicy.status
            });
        }
        else {
            this.firebaseAnalytics.logEvent(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_13__.GA4Event.ICDocumentViewed, {
                member_name: this.currentPolicyDetail.firstName,
                card_number: this.currentPolicyDetail.beneficiaryId,
                document_count_available: 0,
                document_types: this.displayTC ? 'TC' : this.displayTOB ? 'TOB' : this.displayPolicyCert ? 'Policy' : ''
            });
            this.clevertap.recordEventWithNameAndProps(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_13__.GA4Event.ICDocumentViewed, {
                member_name: this.currentPolicyDetail.firstName,
                card_number: this.currentPolicyDetail.beneficiaryId,
                document_count_available: 0,
                document_types: this.displayTC ? 'TC' : this.displayTOB ? 'TOB' : this.displayPolicyCert ? 'Policy' : ''
            });
        }
    }
};
PolicyPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_22__.ModalController },
    { type: src_app_service_policy_policy_service__WEBPACK_IMPORTED_MODULE_7__.PolicyService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_23__.Router },
    { type: src_app_service_insurance_insurance_service__WEBPACK_IMPORTED_MODULE_8__.InsuranceService },
    { type: src_app_service_policy_download_document_service__WEBPACK_IMPORTED_MODULE_4__.DownloadDocumentService },
    { type: src_app_providers_common_toast_service__WEBPACK_IMPORTED_MODULE_10__.ToastService },
    { type: _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_24__.Storage },
    { type: _awesome_cordova_plugins_firebase_analytics_ngx__WEBPACK_IMPORTED_MODULE_3__.FirebaseAnalytics },
    { type: _awesome_cordova_plugins_clevertap_ngx__WEBPACK_IMPORTED_MODULE_2__.CleverTap },
    { type: src_app_shared_components_nextgen_dialog_nextgen_dialog_service__WEBPACK_IMPORTED_MODULE_14__.DialogService },
    { type: _service_language_language_service__WEBPACK_IMPORTED_MODULE_16__.LanguageService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_22__.Platform },
    { type: src_app_service_utilities_third_party_service__WEBPACK_IMPORTED_MODULE_18__.ThirdPartyService }
];
PolicyPage = (0,tslib__WEBPACK_IMPORTED_MODULE_20__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_25__.Component)({
        selector: 'policy-page',
        template: _policy_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_policy_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], PolicyPage);



/***/ }),

/***/ 8423:
/*!***************************************************!*\
  !*** ./src/app/register-third-party.component.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RegisterThirdPartyComponent": () => (/* binding */ RegisterThirdPartyComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/storage-angular */ 80190);
/* harmony import */ var _service_insurance_insurance_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./service/insurance/insurance.service */ 57072);





let RegisterThirdPartyComponent = class RegisterThirdPartyComponent {
    constructor(platform, storage, insuranceService) {
        this.platform = platform;
        this.storage = storage;
        this.insuranceService = insuranceService;
        this.location = '';
        const w = window;
        w.mode = this.platform.is('ios') ? 'ios' : 'android';
    }
    ngOnInit() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__awaiter)(this, void 0, void 0, function* () {
            // this.setupAvaamoChat();
            // const cssAds=
            //   {
            //     'text': 'Book Appointment',
            //     'background': '#4ba38c',
            //     'border-radius': '4px',
            //     'border-color': '#4ba38c',
            //     'color': '#ffffff',
            //     'btnPosition': 'bottom-right',
            //     'containerStyle': 'embedded',
            //     'containerRadius': '4px',
            //     'preAuth': true
            //   }
            // this.setupAds(document, 'script','body', 'HGWIDGE00033', 'hg-widget-script',cssAds);
        });
    }
};
RegisterThirdPartyComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.Platform },
    { type: _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_3__.Storage },
    { type: _service_insurance_insurance_service__WEBPACK_IMPORTED_MODULE_0__.InsuranceService }
];
RegisterThirdPartyComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-register-third-party',
        template: ''
    })
], RegisterThirdPartyComponent);



/***/ }),

/***/ 59181:
/*!*******************************************************************************!*\
  !*** ./src/app/pages/home/claims-history/claims-history.page.scss?ngResource ***!
  \*******************************************************************************/
/***/ ((module) => {

module.exports = ":root {\n  --nc-color-nextgen-neutral-grey-50: red;\n  --nc-color-nextgen-white: yellow;\n  --nc-color-nextgen-blue: #0d152e;\n  --nc-color-nextgen-green: #00908d;\n  --nc-color-nextgen-black: #000000;\n  --nc-color-nextgen-grey-background: #c8d3da;\n  --nc-color-nextgen-grey: #92a2ac;\n  --nc-color-nextgen-stone-grey: #fafafa;\n  --nc-color-nextgen-error: #fc1055;\n  --nc-color-nextgen-neutral-grey: #414141;\n  --nc-color-nextgen-fibrant-green: #00bab6;\n  --nc-color-nextgen-warning: #ffd048;\n  --nc-color-nextgen-green-background: #e6f2f2;\n  --nc-color-nextgen-neutral-grey-400: #7a7a7a;\n  --nc-color-nextgen-neutral-grey-100: #eff3f5;\n  --nc-color-nextgen-status-error: #ba0c3f;\n  --nc-color-nextgen-status-error-background: #ffeff4;\n  --nc-color-nextgen-status-warning: #cba127;\n  --nc-color-nextgen-status-warning-background: #fff8e6;\n  --nc-color-nextgen-blue-100: #dfeff2;\n  --nc-color-nextgen-error-red-700: #f62459;\n  --nc-color-nextgen-blue-500: #006192;\n  --nc-color-nextgen-blue-400: #79cdec;\n  --nc-color-nextgen-red-500: #ff6592;\n  --nc-color-nextgen-secondary-blue-300: #13a0d3;\n  --lumi-white-color: #ffffff;\n  --lumi-primary-yellow-color: #fab600;\n}\n\n.ion-color-green {\n  --ion-color-base: var(--nc-color-nextgen-green);\n  --ion-color-base-rgb: var(--nc-color-nextgen-green);\n  --ion-color-contrast: var(--nc-color-nextgen-white);\n  --ion-color-contrast-rgb: var(--nc-color-nextgen-green);\n  --ion-color-shade: var(--nc-color-nextgen-green);\n  --ion-color-tint: var(--nc-color-nextgen-green);\n}\n\n.history-container {\n  background: var(--nc-color-nextgen-neutral-grey-50);\n  padding: 0 5%;\n  padding-bottom: 9vh;\n  min-height: 100%;\n  padding-bottom: 9vh;\n  max-height: max-content;\n}\n\n.segment {\n  width: 100%;\n  height: 3rem;\n  background: var(--nc-color-nextgen-grey-background);\n}\n\n.segment .segment-button {\n  --indicator-color: #00908d;\n  --color-checked: #ffffff;\n}\n\n.segment .segment-button.segment-button-checked ion-label {\n  color: #ffffff;\n  font-weight: 700 !important;\n}\n\n.inputSearch {\n  margin: 2rem 0 2rem 0;\n}\n\n.claim-title {\n  margin: 5% 0;\n}\n\n.claim-title span {\n  color: var(--nc-color-nextgen-blue) !important;\n}\n\n.create-new {\n  justify-content: center;\n  align-items: center;\n  display: flex;\n  position: fixed;\n  bottom: 4vh;\n  right: 0;\n  left: 0;\n}\n\n.plus-icon {\n  padding-right: 12px;\n  color: var(--nc-color-nextgen-white);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFxjb2xvci5zY3NzIiwiY2xhaW1zLWhpc3RvcnkucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0MsdUNBQUE7RUFDQSxnQ0FBQTtFQUNBLGdDQUFBO0VBQ0EsaUNBQUE7RUFDQSxpQ0FBQTtFQUNBLDJDQUFBO0VBQ0EsZ0NBQUE7RUFDQSxzQ0FBQTtFQUNBLGlDQUFBO0VBQ0Esd0NBQUE7RUFDQSx5Q0FBQTtFQUNBLG1DQUFBO0VBQ0EsNENBQUE7RUFDQSw0Q0FBQTtFQUNBLDRDQUFBO0VBQ0Esd0NBQUE7RUFDQSxtREFBQTtFQUNBLDBDQUFBO0VBQ0EscURBQUE7RUFDQSxvQ0FBQTtFQUNBLHlDQUFBO0VBQ0Esb0NBQUE7RUFDQSxvQ0FBQTtFQUNBLG1DQUFBO0VBQ0EsOENBQUE7RUFFQSwyQkFBQTtFQUNBLG9DQUFBO0FDQUQ7O0FEZ0NBO0VBQ0MsK0NBQUE7RUFDQSxtREFBQTtFQUNBLG1EQUFBO0VBQ0EsdURBQUE7RUFDQSxnREFBQTtFQUNBLCtDQUFBO0FDN0JEOztBQW5DQTtFQUNFLG1ERHVDOEI7RUN0QzlCLGFBQUE7RUFDQSxtQkFBQTtFQUNBLGdCQUFBO0VBQ0EsbUJBQUE7RUFDQSx1QkFBQTtBQXNDRjs7QUFuQ0E7RUFDRSxXQUFBO0VBQ0EsWUFBQTtFQUNBLG1ERG9COEI7QUNrQmhDOztBQXJDRTtFQUNFLDBCQUFBO0VBQ0Esd0JBQUE7QUF1Q0o7O0FBckNNO0VBQ0UsY0FBQTtFQUNBLDJCQUFBO0FBdUNSOztBQWxDQTtFQUNFLHFCQUFBO0FBcUNGOztBQW5DQTtFQUNFLFlBQUE7QUFzQ0Y7O0FBckNFO0VBQ0UsOENBQUE7QUF1Q0o7O0FBcENBO0VBQ0UsdUJBQUE7RUFDQSxtQkFBQTtFQUNBLGFBQUE7RUFDQSxlQUFBO0VBQ0EsV0FBQTtFQUNBLFFBQUE7RUFDQSxPQUFBO0FBdUNGOztBQXBDQTtFQUNFLG1CQUFBO0VBQ0Esb0NEZm9CO0FDc0R0QiIsImZpbGUiOiJjbGFpbXMtaGlzdG9yeS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyI6cm9vdCB7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS01MDogcmVkO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi13aGl0ZTogeWVsbG93O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlOiAjMGQxNTJlO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbjogIzAwOTA4ZDtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tYmxhY2s6ICMwMDAwMDA7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWdyZXktYmFja2dyb3VuZDogI2M4ZDNkYTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tZ3JleTogIzkyYTJhYztcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc3RvbmUtZ3JleTogI2ZhZmFmYTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tZXJyb3I6ICNmYzEwNTU7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleTogIzQxNDE0MTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tZmlicmFudC1ncmVlbjogIzAwYmFiNjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4td2FybmluZzogI2ZmZDA0ODtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4tYmFja2dyb3VuZDogI2U2ZjJmMjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTQwMDogIzdhN2E3YTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTEwMDogI2VmZjNmNTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yOiAjYmEwYzNmO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtZXJyb3ItYmFja2dyb3VuZDogI2ZmZWZmNDtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLXdhcm5pbmc6ICNjYmExMjc7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy13YXJuaW5nLWJhY2tncm91bmQ6ICNmZmY4ZTY7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWJsdWUtMTAwOiAjZGZlZmYyO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1lcnJvci1yZWQtNzAwOiAjZjYyNDU5O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlLTUwMDogIzAwNjE5MjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZS00MDA6ICM3OWNkZWM7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXJlZC01MDA6ICNmZjY1OTI7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXNlY29uZGFyeS1ibHVlLTMwMDogIzEzYTBkMztcclxuXHJcblx0LS1sdW1pLXdoaXRlLWNvbG9yOiAjZmZmZmZmO1xyXG5cdC0tbHVtaS1wcmltYXJ5LXllbGxvdy1jb2xvcjogI2ZhYjYwMDtcclxufVxyXG4kY29sb3ItbmV4dGdlbi1ibHVlOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWJsdWUpO1xyXG4kY29sb3ItbmV4dGdlbi1ncmVlbjogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbik7XHJcbiRjb2xvci1uZXh0Z2VuLXdoaXRlOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXdoaXRlKTtcclxuJGNvbG9yLW5leHRnZW4tYmxhY2s6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tYmxhY2spO1xyXG4kY29sb3ItbmV4dGdlbi1ncmV5LWJhY2tncm91bmQ6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JleS1iYWNrZ3JvdW5kKTtcclxuJGNvbG9yLW5leHRnZW4tZ3JleTogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmV5KTtcclxuJGNvbG9yLW5leHRnZW4tc3RvbmUtZ3JleTogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1zdG9uZS1ncmV5KTtcclxuJGNvbG9yLW5leHRnZW4tZXJyb3I6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZXJyb3IpO1xyXG4kY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXk6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5KTtcclxuJGNvbG9yLW5leHRnZW4tZmlicmFudC1ncmVlbjogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1maWJyYW50LWdyZWVuKTtcclxuJGNvbG9yLW5leHRnZW4td2FybmluZzogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi13YXJuaW5nKTtcclxuJGNvbG9yLW5leHRnZW4tZ3JlZW4tYmFja2dyb3VuZDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbi1iYWNrZ3JvdW5kKTtcclxuJGNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTUwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS01MCk7XHJcbiRjb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS00MDA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTQwMCk7XHJcbiRjb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS0xMDA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTEwMCk7XHJcbiRjb2xvci1uZXh0Z2VuLXN0YXR1cy1lcnJvcjogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtZXJyb3IpO1xyXG4kY29sb3ItbmV4dGdlbi1zdGF0dXMtZXJyb3ItYmFja2dyb3VuZDogdmFyKFxyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtZXJyb3ItYmFja2dyb3VuZFxyXG4pO1xyXG4kY29sb3ItbmV4dGdlbi1zdGF0dXMtd2FybmluZzogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtd2FybmluZyk7XHJcbiRjb2xvci1uZXh0Z2VuLXN0YXR1cy13YXJuaW5nLWJhY2tncm91bmQ6IHZhcihcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLXdhcm5pbmctYmFja2dyb3VuZFxyXG4pO1xyXG4kY29sb3ItbmV4dGdlbi1ibHVlLTEwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlLTEwMCk7XHJcbiRjb2xvci1uZXh0Z2VuLWVycm9yLXJlZC03MDA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZXJyb3ItcmVkLTcwMCk7XHJcbiRjb2xvci1uZXh0Z2VuLWJsdWUtNTAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWJsdWUtNTAwKTtcclxuJGNvbG9yLW5leHRnZW4tYmx1ZS00MDA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZS00MDApO1xyXG4kY29sb3ItbmV4dGdlbi1yZWQtNTAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXJlZC01MDApO1xyXG4kY29sb3ItbmV4dGdlbi1zZWNvbmRhcnktYmx1ZS0zMDA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tc2Vjb25kYXJ5LWJsdWUtMzAwKTtcclxuXHJcbi5pb24tY29sb3ItZ3JlZW4ge1xyXG5cdC0taW9uLWNvbG9yLWJhc2U6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4pO1xyXG5cdC0taW9uLWNvbG9yLWJhc2UtcmdiOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuKTtcclxuXHQtLWlvbi1jb2xvci1jb250cmFzdDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi13aGl0ZSk7XHJcblx0LS1pb24tY29sb3ItY29udHJhc3QtcmdiOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuKTtcclxuXHQtLWlvbi1jb2xvci1zaGFkZTogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbik7XHJcblx0LS1pb24tY29sb3ItdGludDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbik7XHJcbn1cclxuIiwiQGltcG9ydCAnLi4vLi4vLi4vLi4vY29sb3Iuc2Nzcyc7XHJcblxyXG4uaGlzdG9yeS1jb250YWluZXIge1xyXG4gIGJhY2tncm91bmQ6ICRjb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS01MDtcclxuICBwYWRkaW5nOiAwIDUlO1xyXG4gIHBhZGRpbmctYm90dG9tOiA5dmg7XHJcbiAgbWluLWhlaWdodDogMTAwJTtcclxuICBwYWRkaW5nLWJvdHRvbTogOXZoO1xyXG4gIG1heC1oZWlnaHQ6IG1heC1jb250ZW50O1xyXG59XHJcblxyXG4uc2VnbWVudCB7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgaGVpZ2h0OiAzcmVtO1xyXG4gIGJhY2tncm91bmQ6ICRjb2xvci1uZXh0Z2VuLWdyZXktYmFja2dyb3VuZDtcclxuICAuc2VnbWVudC1idXR0b24ge1xyXG4gICAgLS1pbmRpY2F0b3ItY29sb3I6ICMwMDkwOGQ7XHJcbiAgICAtLWNvbG9yLWNoZWNrZWQ6ICNmZmZmZmY7XHJcbiAgICAmLnNlZ21lbnQtYnV0dG9uLWNoZWNrZWQge1xyXG4gICAgICBpb24tbGFiZWwge1xyXG4gICAgICAgIGNvbG9yOiAjZmZmZmZmO1xyXG4gICAgICAgIGZvbnQtd2VpZ2h0OiA3MDAgIWltcG9ydGFudDtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH1cclxufVxyXG4uaW5wdXRTZWFyY2h7XHJcbiAgbWFyZ2luOiAycmVtIDAgMnJlbSAwO1xyXG59XHJcbi5jbGFpbS10aXRsZSB7XHJcbiAgbWFyZ2luOiA1JSAwO1xyXG4gIHNwYW57XHJcbiAgICBjb2xvcjogJGNvbG9yLW5leHRnZW4tYmx1ZSAhaW1wb3J0YW50O1xyXG4gIH1cclxufVxyXG4uY3JlYXRlLW5ldyB7XHJcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIHBvc2l0aW9uOiBmaXhlZDtcclxuICBib3R0b206IDR2aDtcclxuICByaWdodDogMDtcclxuICBsZWZ0OiAwO1xyXG59XHJcblxyXG4ucGx1cy1pY29uIHtcclxuICBwYWRkaW5nLXJpZ2h0OiAxMnB4O1xyXG4gIGNvbG9yOiAkY29sb3ItbmV4dGdlbi13aGl0ZTtcclxufSJdfQ== */";

/***/ }),

/***/ 22378:
/*!*****************************************************************************************************!*\
  !*** ./src/app/pages/home/claims-history/history-content/history-content.component.scss?ngResource ***!
  \*****************************************************************************************************/
/***/ ((module) => {

module.exports = "@charset \"UTF-8\";\n:root {\n  --nc-color-nextgen-neutral-grey-50: red;\n  --nc-color-nextgen-white: yellow;\n  --nc-color-nextgen-blue: #0d152e;\n  --nc-color-nextgen-green: #00908d;\n  --nc-color-nextgen-black: #000000;\n  --nc-color-nextgen-grey-background: #c8d3da;\n  --nc-color-nextgen-grey: #92a2ac;\n  --nc-color-nextgen-stone-grey: #fafafa;\n  --nc-color-nextgen-error: #fc1055;\n  --nc-color-nextgen-neutral-grey: #414141;\n  --nc-color-nextgen-fibrant-green: #00bab6;\n  --nc-color-nextgen-warning: #ffd048;\n  --nc-color-nextgen-green-background: #e6f2f2;\n  --nc-color-nextgen-neutral-grey-400: #7a7a7a;\n  --nc-color-nextgen-neutral-grey-100: #eff3f5;\n  --nc-color-nextgen-status-error: #ba0c3f;\n  --nc-color-nextgen-status-error-background: #ffeff4;\n  --nc-color-nextgen-status-warning: #cba127;\n  --nc-color-nextgen-status-warning-background: #fff8e6;\n  --nc-color-nextgen-blue-100: #dfeff2;\n  --nc-color-nextgen-error-red-700: #f62459;\n  --nc-color-nextgen-blue-500: #006192;\n  --nc-color-nextgen-blue-400: #79cdec;\n  --nc-color-nextgen-red-500: #ff6592;\n  --nc-color-nextgen-secondary-blue-300: #13a0d3;\n  --lumi-white-color: #ffffff;\n  --lumi-primary-yellow-color: #fab600;\n}\n.ion-color-green {\n  --ion-color-base: var(--nc-color-nextgen-green);\n  --ion-color-base-rgb: var(--nc-color-nextgen-green);\n  --ion-color-contrast: var(--nc-color-nextgen-white);\n  --ion-color-contrast-rgb: var(--nc-color-nextgen-green);\n  --ion-color-shade: var(--nc-color-nextgen-green);\n  --ion-color-tint: var(--nc-color-nextgen-green);\n}\n.missing,\n.Declined,\n.notUsed {\n  background: var(--nc-color-nextgen-status-error-background);\n  border-radius: 0.125em;\n  color: var(--nc-color-nextgen-status-error);\n  padding: 4px 8px;\n}\n.under {\n  background: var(--nc-color-nextgen-status-warning-background);\n  border-radius: 0.125em;\n  color: var(--nc-color-nextgen-status-warning);\n  padding: 0.25em 0.5em;\n}\n.accepted,\n.Authorized,\n.Autorisé {\n  background: var(--nc-color-nextgen-green-background);\n  border-radius: 0.125em;\n  color: var(--nc-color-nextgen-fibrant-green);\n  padding: 0.25em 0.5em;\n}\n.Authorized,\n.Settled {\n  background: var(--nc-color-nextgen-stone-grey);\n  border-radius: 0.125em;\n  color: var(--nc-color-nextgen-blue-500);\n  padding: 0.25em 0.5em;\n}\n.Pending {\n  background: var(--nc-color-nextgen-status-warning-background);\n  border-radius: 0.125em;\n  color: var(--nc-color-nextgen-warning);\n  padding: 0.25em 0.5em;\n}\n.Initial {\n  background: var(--nc-color-nextgen-neutral-grey-100);\n  border-radius: 0.125em;\n  color: var(--nc-color-nextgen-neutral-grey-400);\n  padding: 0.25em 0.5em;\n}\n.Draft,\n.Registered,\n.Processed {\n  background: var(--nc-color-nextgen-neutral-grey-100);\n  border-radius: 0.125em;\n  color: var(--nc-color-nextgen-neutral-grey-400);\n  padding: 0.25em 0.5em;\n}\n.claim-cards {\n  margin-bottom: 0.6em;\n}\n.card-row {\n  padding: 0.6em 0 0.6em 0;\n  display: flex;\n  justify-content: space-between;\n}\n.card-row .col-left {\n  text-align: left;\n}\n.card-row .col-right {\n  text-align: right;\n}\n.card-row .text-content {\n  margin: 0;\n}\n.sub-title {\n  color: var(--nc-color-nextgen-neutral-grey-400);\n}\n.name {\n  color: var(--nc-color-nextgen-neutral-grey-400);\n}\n.type {\n  color: var(--nc-color-nextgen-neutral-grey-400);\n}\n.icon-next {\n  color: var(--nc-color-nextgen-green);\n}\n.icon-trash {\n  color: var(--nc-color-nextgen-neutral-grey-400);\n  font-size: 1.5rem !important;\n  cursor: pointer;\n}\n.claimRef {\n  color: var(--nc-color-nextgen-neutral-grey-400);\n}\n.noData {\n  padding-top: 20%;\n  text-align: center;\n  color: var(--nc-color-nextgen-neutral-grey-400);\n}\n.reSubmission {\n  color: var(--nc-color-nextgen-status-error);\n}\nion-skeleton-text {\n  width: 95%;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImhpc3RvcnktY29udGVudC5jb21wb25lbnQuc2NzcyIsIi4uXFwuLlxcLi5cXC4uXFwuLlxcY29sb3Iuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxnQkFBZ0I7QUNBaEI7RUFDQyx1Q0FBQTtFQUNBLGdDQUFBO0VBQ0EsZ0NBQUE7RUFDQSxpQ0FBQTtFQUNBLGlDQUFBO0VBQ0EsMkNBQUE7RUFDQSxnQ0FBQTtFQUNBLHNDQUFBO0VBQ0EsaUNBQUE7RUFDQSx3Q0FBQTtFQUNBLHlDQUFBO0VBQ0EsbUNBQUE7RUFDQSw0Q0FBQTtFQUNBLDRDQUFBO0VBQ0EsNENBQUE7RUFDQSx3Q0FBQTtFQUNBLG1EQUFBO0VBQ0EsMENBQUE7RUFDQSxxREFBQTtFQUNBLG9DQUFBO0VBQ0EseUNBQUE7RUFDQSxvQ0FBQTtFQUNBLG9DQUFBO0VBQ0EsbUNBQUE7RUFDQSw4Q0FBQTtFQUVBLDJCQUFBO0VBQ0Esb0NBQUE7QURDRDtBQytCQTtFQUNDLCtDQUFBO0VBQ0EsbURBQUE7RUFDQSxtREFBQTtFQUNBLHVEQUFBO0VBQ0EsZ0RBQUE7RUFDQSwrQ0FBQTtBRDVCRDtBQXBDQTs7O0VBR0MsMkRDeUN1QztFRHhDdkMsc0JBQUE7RUFDQSwyQ0NzQzRCO0VEckM1QixnQkFBQTtBQXVDRDtBQXBDQTtFQUNDLDZEQ3NDeUM7RURyQ3pDLHNCQUFBO0VBQ0EsNkNDbUM4QjtFRGxDOUIscUJBQUE7QUF1Q0Q7QUFyQ0E7OztFQUdDLG9EQ3FCZ0M7RURwQmhDLHNCQUFBO0VBQ0EsNENDaUI2QjtFRGhCN0IscUJBQUE7QUF3Q0Q7QUFyQ0E7O0VBRUMsOENDUTBCO0VEUDFCLHNCQUFBO0VBQ0EsdUNDeUJ3QjtFRHhCeEIscUJBQUE7QUF3Q0Q7QUFyQ0E7RUFDQyw2RENleUM7RURkekMsc0JBQUE7RUFDQSxzQ0NHdUI7RURGdkIscUJBQUE7QUF3Q0Q7QUF0Q0E7RUFDQyxvRENHZ0M7RURGaEMsc0JBQUE7RUFDQSwrQ0FBQTtFQUNBLHFCQUFBO0FBeUNEO0FBdkNBOzs7RUFHQyxvRENMZ0M7RURNaEMsc0JBQUE7RUFDQSwrQ0NSZ0M7RURTaEMscUJBQUE7QUEwQ0Q7QUF4Q0E7RUFDQyxvQkFBQTtBQTJDRDtBQXhDQTtFQUNDLHdCQUFBO0VBQ0EsYUFBQTtFQUNBLDhCQUFBO0FBMkNEO0FBMUNDO0VBQ0MsZ0JBQUE7QUE0Q0Y7QUExQ0M7RUFDQyxpQkFBQTtBQTRDRjtBQXpDQztFQUNDLFNBQUE7QUEyQ0Y7QUF2Q0E7RUFDQywrQ0NoQ2dDO0FEMEVqQztBQXZDQTtFQUNDLCtDQ3BDZ0M7QUQ4RWpDO0FBdkNBO0VBQ0MsK0NDeENnQztBRGtGakM7QUF2Q0E7RUFDQyxvQ0N4RHFCO0FEa0d0QjtBQXhDQTtFQUNDLCtDQy9DZ0M7RURnRGhDLDRCQUFBO0VBQ0EsZUFBQTtBQTJDRDtBQXpDQTtFQUNDLCtDQ3BEZ0M7QURnR2pDO0FBMUNBO0VBQ0MsZ0JBQUE7RUFDQSxrQkFBQTtFQUNBLCtDQ3pEZ0M7QURzR2pDO0FBMUNBO0VBQ0MsMkNDM0Q0QjtBRHdHN0I7QUExQ0E7RUFDQyxVQUFBO0FBNkNEIiwiZmlsZSI6Imhpc3RvcnktY29udGVudC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIkBpbXBvcnQgXCIuLi8uLi8uLi8uLi8uLi9jb2xvci5zY3NzXCI7XHJcblxyXG4ubWlzc2luZyxcclxuLkRlY2xpbmVkLFxyXG4ubm90VXNlZCB7XHJcblx0YmFja2dyb3VuZDogJGNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yLWJhY2tncm91bmQ7XHJcblx0Ym9yZGVyLXJhZGl1czogMC4xMjVlbTtcclxuXHRjb2xvcjogJGNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yO1xyXG5cdHBhZGRpbmc6IDRweCA4cHg7XHJcbn1cclxuXHJcbi51bmRlciB7XHJcblx0YmFja2dyb3VuZDogJGNvbG9yLW5leHRnZW4tc3RhdHVzLXdhcm5pbmctYmFja2dyb3VuZDtcclxuXHRib3JkZXItcmFkaXVzOiAwLjEyNWVtO1xyXG5cdGNvbG9yOiAkY29sb3ItbmV4dGdlbi1zdGF0dXMtd2FybmluZztcclxuXHRwYWRkaW5nOiAwLjI1ZW0gMC41ZW07XHJcbn1cclxuLmFjY2VwdGVkLFxyXG4uQXV0aG9yaXplZCxcclxuLkF1dG9yaXPDqSB7XHJcblx0YmFja2dyb3VuZDogJGNvbG9yLW5leHRnZW4tZ3JlZW4tYmFja2dyb3VuZDtcclxuXHRib3JkZXItcmFkaXVzOiAwLjEyNWVtO1xyXG5cdGNvbG9yOiAkY29sb3ItbmV4dGdlbi1maWJyYW50LWdyZWVuO1xyXG5cdHBhZGRpbmc6IDAuMjVlbSAwLjVlbTtcclxufVxyXG5cclxuLkF1dGhvcml6ZWQsXHJcbi5TZXR0bGVkIHtcclxuXHRiYWNrZ3JvdW5kOiAkY29sb3ItbmV4dGdlbi1zdG9uZS1ncmV5O1xyXG5cdGJvcmRlci1yYWRpdXM6IDAuMTI1ZW07XHJcblx0Y29sb3I6ICRjb2xvci1uZXh0Z2VuLWJsdWUtNTAwO1xyXG5cdHBhZGRpbmc6IDAuMjVlbSAwLjVlbTtcclxufVxyXG5cclxuLlBlbmRpbmcge1xyXG5cdGJhY2tncm91bmQ6ICRjb2xvci1uZXh0Z2VuLXN0YXR1cy13YXJuaW5nLWJhY2tncm91bmQ7XHJcblx0Ym9yZGVyLXJhZGl1czogMC4xMjVlbTtcclxuXHRjb2xvcjogJGNvbG9yLW5leHRnZW4td2FybmluZztcclxuXHRwYWRkaW5nOiAwLjI1ZW0gMC41ZW07XHJcbn1cclxuLkluaXRpYWwge1xyXG5cdGJhY2tncm91bmQ6ICRjb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS0xMDA7XHJcblx0Ym9yZGVyLXJhZGl1czogMC4xMjVlbTtcclxuXHRjb2xvcjogJGNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTQwMDtcclxuXHRwYWRkaW5nOiAwLjI1ZW0gMC41ZW07XHJcbn1cclxuLkRyYWZ0LFxyXG4uUmVnaXN0ZXJlZCxcclxuLlByb2Nlc3NlZCB7XHJcblx0YmFja2dyb3VuZDogJGNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTEwMDtcclxuXHRib3JkZXItcmFkaXVzOiAwLjEyNWVtO1xyXG5cdGNvbG9yOiAkY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNDAwO1xyXG5cdHBhZGRpbmc6IDAuMjVlbSAwLjVlbTtcclxufVxyXG4uY2xhaW0tY2FyZHMge1xyXG5cdG1hcmdpbi1ib3R0b206IDAuNmVtO1xyXG59XHJcblxyXG4uY2FyZC1yb3cge1xyXG5cdHBhZGRpbmc6IDAuNmVtIDAgMC42ZW0gMDtcclxuXHRkaXNwbGF5OiBmbGV4O1xyXG5cdGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcclxuXHQuY29sLWxlZnQge1xyXG5cdFx0dGV4dC1hbGlnbjogbGVmdDtcclxuXHR9XHJcblx0LmNvbC1yaWdodCB7XHJcblx0XHR0ZXh0LWFsaWduOiByaWdodDtcclxuXHR9XHJcblxyXG5cdC50ZXh0LWNvbnRlbnQge1xyXG5cdFx0bWFyZ2luOiAwO1xyXG5cdH1cclxufVxyXG5cclxuLnN1Yi10aXRsZSB7XHJcblx0Y29sb3I6ICRjb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS00MDA7XHJcbn1cclxuXHJcbi5uYW1lIHtcclxuXHRjb2xvcjogJGNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTQwMDtcclxufVxyXG5cclxuLnR5cGUge1xyXG5cdGNvbG9yOiAkY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNDAwO1xyXG59XHJcblxyXG4uaWNvbi1uZXh0IHtcclxuXHRjb2xvcjogJGNvbG9yLW5leHRnZW4tZ3JlZW47XHJcbn1cclxuLmljb24tdHJhc2gge1xyXG5cdGNvbG9yOiAkY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNDAwO1xyXG5cdGZvbnQtc2l6ZTogMS41cmVtICFpbXBvcnRhbnQ7XHJcblx0Y3Vyc29yOiBwb2ludGVyO1xyXG59XHJcbi5jbGFpbVJlZiB7XHJcblx0Y29sb3I6ICRjb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS00MDA7XHJcbn1cclxuLm5vRGF0YSB7XHJcblx0cGFkZGluZy10b3A6IDIwJTtcclxuXHR0ZXh0LWFsaWduOiBjZW50ZXI7XHJcblx0Y29sb3I6ICRjb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS00MDA7XHJcbn1cclxuXHJcbi5yZVN1Ym1pc3Npb24ge1xyXG5cdGNvbG9yOiAkY29sb3ItbmV4dGdlbi1zdGF0dXMtZXJyb3I7XHJcbn1cclxuXHJcbmlvbi1za2VsZXRvbi10ZXh0IHtcclxuXHR3aWR0aDogOTUlO1xyXG59XHJcbiIsIjpyb290IHtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTUwOiByZWQ7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXdoaXRlOiB5ZWxsb3c7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWJsdWU6ICMwZDE1MmU7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuOiAjMDA5MDhkO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ibGFjazogIzAwMDAwMDtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tZ3JleS1iYWNrZ3JvdW5kOiAjYzhkM2RhO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ncmV5OiAjOTJhMmFjO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zdG9uZS1ncmV5OiAjZmFmYWZhO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1lcnJvcjogI2ZjMTA1NTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5OiAjNDE0MTQxO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1maWJyYW50LWdyZWVuOiAjMDBiYWI2O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi13YXJuaW5nOiAjZmZkMDQ4O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbi1iYWNrZ3JvdW5kOiAjZTZmMmYyO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNDAwOiAjN2E3YTdhO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktMTAwOiAjZWZmM2Y1O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtZXJyb3I6ICNiYTBjM2Y7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy1lcnJvci1iYWNrZ3JvdW5kOiAjZmZlZmY0O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtd2FybmluZzogI2NiYTEyNztcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLXdhcm5pbmctYmFja2dyb3VuZDogI2ZmZjhlNjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZS0xMDA6ICNkZmVmZjI7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWVycm9yLXJlZC03MDA6ICNmNjI0NTk7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWJsdWUtNTAwOiAjMDA2MTkyO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlLTQwMDogIzc5Y2RlYztcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tcmVkLTUwMDogI2ZmNjU5MjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc2Vjb25kYXJ5LWJsdWUtMzAwOiAjMTNhMGQzO1xyXG5cclxuXHQtLWx1bWktd2hpdGUtY29sb3I6ICNmZmZmZmY7XHJcblx0LS1sdW1pLXByaW1hcnkteWVsbG93LWNvbG9yOiAjZmFiNjAwO1xyXG59XHJcbiRjb2xvci1uZXh0Z2VuLWJsdWU6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZSk7XHJcbiRjb2xvci1uZXh0Z2VuLWdyZWVuOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuKTtcclxuJGNvbG9yLW5leHRnZW4td2hpdGU6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4td2hpdGUpO1xyXG4kY29sb3ItbmV4dGdlbi1ibGFjazogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ibGFjayk7XHJcbiRjb2xvci1uZXh0Z2VuLWdyZXktYmFja2dyb3VuZDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmV5LWJhY2tncm91bmQpO1xyXG4kY29sb3ItbmV4dGdlbi1ncmV5OiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZXkpO1xyXG4kY29sb3ItbmV4dGdlbi1zdG9uZS1ncmV5OiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXN0b25lLWdyZXkpO1xyXG4kY29sb3ItbmV4dGdlbi1lcnJvcjogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1lcnJvcik7XHJcbiRjb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleTogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXkpO1xyXG4kY29sb3ItbmV4dGdlbi1maWJyYW50LWdyZWVuOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWZpYnJhbnQtZ3JlZW4pO1xyXG4kY29sb3ItbmV4dGdlbi13YXJuaW5nOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXdhcm5pbmcpO1xyXG4kY29sb3ItbmV4dGdlbi1ncmVlbi1iYWNrZ3JvdW5kOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuLWJhY2tncm91bmQpO1xyXG4kY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNTA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTUwKTtcclxuJGNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTQwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNDAwKTtcclxuJGNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTEwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktMTAwKTtcclxuJGNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy1lcnJvcik7XHJcbiRjb2xvci1uZXh0Z2VuLXN0YXR1cy1lcnJvci1iYWNrZ3JvdW5kOiB2YXIoXHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy1lcnJvci1iYWNrZ3JvdW5kXHJcbik7XHJcbiRjb2xvci1uZXh0Z2VuLXN0YXR1cy13YXJuaW5nOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy13YXJuaW5nKTtcclxuJGNvbG9yLW5leHRnZW4tc3RhdHVzLXdhcm5pbmctYmFja2dyb3VuZDogdmFyKFxyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtd2FybmluZy1iYWNrZ3JvdW5kXHJcbik7XHJcbiRjb2xvci1uZXh0Z2VuLWJsdWUtMTAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWJsdWUtMTAwKTtcclxuJGNvbG9yLW5leHRnZW4tZXJyb3ItcmVkLTcwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1lcnJvci1yZWQtNzAwKTtcclxuJGNvbG9yLW5leHRnZW4tYmx1ZS01MDA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZS01MDApO1xyXG4kY29sb3ItbmV4dGdlbi1ibHVlLTQwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlLTQwMCk7XHJcbiRjb2xvci1uZXh0Z2VuLXJlZC01MDA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tcmVkLTUwMCk7XHJcbiRjb2xvci1uZXh0Z2VuLXNlY29uZGFyeS1ibHVlLTMwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1zZWNvbmRhcnktYmx1ZS0zMDApO1xyXG5cclxuLmlvbi1jb2xvci1ncmVlbiB7XHJcblx0LS1pb24tY29sb3ItYmFzZTogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbik7XHJcblx0LS1pb24tY29sb3ItYmFzZS1yZ2I6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4pO1xyXG5cdC0taW9uLWNvbG9yLWNvbnRyYXN0OiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXdoaXRlKTtcclxuXHQtLWlvbi1jb2xvci1jb250cmFzdC1yZ2I6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4pO1xyXG5cdC0taW9uLWNvbG9yLXNoYWRlOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuKTtcclxuXHQtLWlvbi1jb2xvci10aW50OiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuKTtcclxufVxyXG4iXX0= */";

/***/ }),

/***/ 34322:
/*!*********************************************************************!*\
  !*** ./src/app/pages/home/dashboard/dashboard.page.scss?ngResource ***!
  \*********************************************************************/
/***/ ((module) => {

module.exports = ":root {\n  --nc-color-nextgen-neutral-grey-50: red;\n  --nc-color-nextgen-white: yellow;\n  --nc-color-nextgen-blue: #0d152e;\n  --nc-color-nextgen-green: #00908d;\n  --nc-color-nextgen-black: #000000;\n  --nc-color-nextgen-grey-background: #c8d3da;\n  --nc-color-nextgen-grey: #92a2ac;\n  --nc-color-nextgen-stone-grey: #fafafa;\n  --nc-color-nextgen-error: #fc1055;\n  --nc-color-nextgen-neutral-grey: #414141;\n  --nc-color-nextgen-fibrant-green: #00bab6;\n  --nc-color-nextgen-warning: #ffd048;\n  --nc-color-nextgen-green-background: #e6f2f2;\n  --nc-color-nextgen-neutral-grey-400: #7a7a7a;\n  --nc-color-nextgen-neutral-grey-100: #eff3f5;\n  --nc-color-nextgen-status-error: #ba0c3f;\n  --nc-color-nextgen-status-error-background: #ffeff4;\n  --nc-color-nextgen-status-warning: #cba127;\n  --nc-color-nextgen-status-warning-background: #fff8e6;\n  --nc-color-nextgen-blue-100: #dfeff2;\n  --nc-color-nextgen-error-red-700: #f62459;\n  --nc-color-nextgen-blue-500: #006192;\n  --nc-color-nextgen-blue-400: #79cdec;\n  --nc-color-nextgen-red-500: #ff6592;\n  --nc-color-nextgen-secondary-blue-300: #13a0d3;\n  --lumi-white-color: #ffffff;\n  --lumi-primary-yellow-color: #fab600;\n}\n\n.ion-color-green {\n  --ion-color-base: var(--nc-color-nextgen-green);\n  --ion-color-base-rgb: var(--nc-color-nextgen-green);\n  --ion-color-contrast: var(--nc-color-nextgen-white);\n  --ion-color-contrast-rgb: var(--nc-color-nextgen-green);\n  --ion-color-shade: var(--nc-color-nextgen-green);\n  --ion-color-tint: var(--nc-color-nextgen-green);\n}\n\n.home-page-content {\n  background: var(--nc-color-nextgen-neutral-grey-50);\n  min-height: 100%;\n  padding-bottom: 1rem;\n  --background: $color-nextgen-neutral-grey-50;\n}\n\n.swiper-slide {\n  display: block;\n}\n\n.medical {\n  padding-bottom: 0.24rem;\n  padding-right: 0.12rem;\n  padding-left: 0.12rem;\n}\n\n.insurance {\n  padding-bottom: 0.5rem;\n}\n\n.title {\n  color: var(--nc-color-nextgen-blue);\n  padding-top: 16px;\n  padding-bottom: 8px;\n}\n\n.title-menber {\n  color: var(--nc-color-nextgen-blue);\n  padding-top: 16px;\n}\n\n.grid-content {\n  padding: 0 5%;\n  background: var(--nc-color-nextgen-neutral-grey-50) !important;\n}\n\n.grid-member {\n  padding-left: 5%;\n  background: var(--nc-color-nextgen-neutral-grey-50) !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFxjb2xvci5zY3NzIiwiZGFzaGJvYXJkLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNDLHVDQUFBO0VBQ0EsZ0NBQUE7RUFDQSxnQ0FBQTtFQUNBLGlDQUFBO0VBQ0EsaUNBQUE7RUFDQSwyQ0FBQTtFQUNBLGdDQUFBO0VBQ0Esc0NBQUE7RUFDQSxpQ0FBQTtFQUNBLHdDQUFBO0VBQ0EseUNBQUE7RUFDQSxtQ0FBQTtFQUNBLDRDQUFBO0VBQ0EsNENBQUE7RUFDQSw0Q0FBQTtFQUNBLHdDQUFBO0VBQ0EsbURBQUE7RUFDQSwwQ0FBQTtFQUNBLHFEQUFBO0VBQ0Esb0NBQUE7RUFDQSx5Q0FBQTtFQUNBLG9DQUFBO0VBQ0Esb0NBQUE7RUFDQSxtQ0FBQTtFQUNBLDhDQUFBO0VBRUEsMkJBQUE7RUFDQSxvQ0FBQTtBQ0FEOztBRGdDQTtFQUNDLCtDQUFBO0VBQ0EsbURBQUE7RUFDQSxtREFBQTtFQUNBLHVEQUFBO0VBQ0EsZ0RBQUE7RUFDQSwrQ0FBQTtBQzdCRDs7QUFuQ0E7RUFDSSxtRER1QzRCO0VDdEM1QixnQkFBQTtFQUNBLG9CQUFBO0VBQ0EsNENBQUE7QUFzQ0o7O0FBbkNBO0VBQ0ksY0FBQTtBQXNDSjs7QUFuQ0E7RUFDSSx1QkFBQTtFQUNBLHNCQUFBO0VBQ0EscUJBQUE7QUFzQ0o7O0FBbkNBO0VBQ0ksc0JBQUE7QUFzQ0o7O0FBbkNBO0VBQ0ksbUNETWlCO0VDTGpCLGlCQUFBO0VBQ0EsbUJBQUE7QUFzQ0o7O0FBcENBO0VBQ0ksbUNEQ2lCO0VDQWpCLGlCQUFBO0FBdUNKOztBQXBDQTtFQUNJLGFBQUE7RUFDQSw4REFBQTtBQXVDSjs7QUFwQ0E7RUFDSSxnQkFBQTtFQUNBLDhEQUFBO0FBdUNKIiwiZmlsZSI6ImRhc2hib2FyZC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyI6cm9vdCB7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS01MDogcmVkO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi13aGl0ZTogeWVsbG93O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlOiAjMGQxNTJlO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbjogIzAwOTA4ZDtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tYmxhY2s6ICMwMDAwMDA7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWdyZXktYmFja2dyb3VuZDogI2M4ZDNkYTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tZ3JleTogIzkyYTJhYztcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc3RvbmUtZ3JleTogI2ZhZmFmYTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tZXJyb3I6ICNmYzEwNTU7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleTogIzQxNDE0MTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tZmlicmFudC1ncmVlbjogIzAwYmFiNjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4td2FybmluZzogI2ZmZDA0ODtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4tYmFja2dyb3VuZDogI2U2ZjJmMjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTQwMDogIzdhN2E3YTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTEwMDogI2VmZjNmNTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yOiAjYmEwYzNmO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtZXJyb3ItYmFja2dyb3VuZDogI2ZmZWZmNDtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLXdhcm5pbmc6ICNjYmExMjc7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy13YXJuaW5nLWJhY2tncm91bmQ6ICNmZmY4ZTY7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWJsdWUtMTAwOiAjZGZlZmYyO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1lcnJvci1yZWQtNzAwOiAjZjYyNDU5O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlLTUwMDogIzAwNjE5MjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZS00MDA6ICM3OWNkZWM7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXJlZC01MDA6ICNmZjY1OTI7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXNlY29uZGFyeS1ibHVlLTMwMDogIzEzYTBkMztcclxuXHJcblx0LS1sdW1pLXdoaXRlLWNvbG9yOiAjZmZmZmZmO1xyXG5cdC0tbHVtaS1wcmltYXJ5LXllbGxvdy1jb2xvcjogI2ZhYjYwMDtcclxufVxyXG4kY29sb3ItbmV4dGdlbi1ibHVlOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWJsdWUpO1xyXG4kY29sb3ItbmV4dGdlbi1ncmVlbjogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbik7XHJcbiRjb2xvci1uZXh0Z2VuLXdoaXRlOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXdoaXRlKTtcclxuJGNvbG9yLW5leHRnZW4tYmxhY2s6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tYmxhY2spO1xyXG4kY29sb3ItbmV4dGdlbi1ncmV5LWJhY2tncm91bmQ6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JleS1iYWNrZ3JvdW5kKTtcclxuJGNvbG9yLW5leHRnZW4tZ3JleTogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmV5KTtcclxuJGNvbG9yLW5leHRnZW4tc3RvbmUtZ3JleTogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1zdG9uZS1ncmV5KTtcclxuJGNvbG9yLW5leHRnZW4tZXJyb3I6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZXJyb3IpO1xyXG4kY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXk6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5KTtcclxuJGNvbG9yLW5leHRnZW4tZmlicmFudC1ncmVlbjogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1maWJyYW50LWdyZWVuKTtcclxuJGNvbG9yLW5leHRnZW4td2FybmluZzogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi13YXJuaW5nKTtcclxuJGNvbG9yLW5leHRnZW4tZ3JlZW4tYmFja2dyb3VuZDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbi1iYWNrZ3JvdW5kKTtcclxuJGNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTUwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS01MCk7XHJcbiRjb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS00MDA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTQwMCk7XHJcbiRjb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS0xMDA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTEwMCk7XHJcbiRjb2xvci1uZXh0Z2VuLXN0YXR1cy1lcnJvcjogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtZXJyb3IpO1xyXG4kY29sb3ItbmV4dGdlbi1zdGF0dXMtZXJyb3ItYmFja2dyb3VuZDogdmFyKFxyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtZXJyb3ItYmFja2dyb3VuZFxyXG4pO1xyXG4kY29sb3ItbmV4dGdlbi1zdGF0dXMtd2FybmluZzogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtd2FybmluZyk7XHJcbiRjb2xvci1uZXh0Z2VuLXN0YXR1cy13YXJuaW5nLWJhY2tncm91bmQ6IHZhcihcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLXdhcm5pbmctYmFja2dyb3VuZFxyXG4pO1xyXG4kY29sb3ItbmV4dGdlbi1ibHVlLTEwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlLTEwMCk7XHJcbiRjb2xvci1uZXh0Z2VuLWVycm9yLXJlZC03MDA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZXJyb3ItcmVkLTcwMCk7XHJcbiRjb2xvci1uZXh0Z2VuLWJsdWUtNTAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWJsdWUtNTAwKTtcclxuJGNvbG9yLW5leHRnZW4tYmx1ZS00MDA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZS00MDApO1xyXG4kY29sb3ItbmV4dGdlbi1yZWQtNTAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXJlZC01MDApO1xyXG4kY29sb3ItbmV4dGdlbi1zZWNvbmRhcnktYmx1ZS0zMDA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tc2Vjb25kYXJ5LWJsdWUtMzAwKTtcclxuXHJcbi5pb24tY29sb3ItZ3JlZW4ge1xyXG5cdC0taW9uLWNvbG9yLWJhc2U6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4pO1xyXG5cdC0taW9uLWNvbG9yLWJhc2UtcmdiOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuKTtcclxuXHQtLWlvbi1jb2xvci1jb250cmFzdDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi13aGl0ZSk7XHJcblx0LS1pb24tY29sb3ItY29udHJhc3QtcmdiOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuKTtcclxuXHQtLWlvbi1jb2xvci1zaGFkZTogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbik7XHJcblx0LS1pb24tY29sb3ItdGludDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbik7XHJcbn1cclxuIiwiQGltcG9ydCBcIi4uLy4uLy4uLy4uL2NvbG9yLnNjc3NcIjtcclxuXHJcbi5ob21lLXBhZ2UtY29udGVudCB7XHJcbiAgICBiYWNrZ3JvdW5kOiAkY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNTA7XHJcbiAgICBtaW4taGVpZ2h0OiAxMDAlO1xyXG4gICAgcGFkZGluZy1ib3R0b206IDFyZW07XHJcbiAgICAtLWJhY2tncm91bmQ6ICRjb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS01MDtcclxufVxyXG5cclxuLnN3aXBlci1zbGlkZSB7XHJcbiAgICBkaXNwbGF5OiBibG9jaztcclxufVxyXG5cclxuLm1lZGljYWwge1xyXG4gICAgcGFkZGluZy1ib3R0b206IDAuMjRyZW07XHJcbiAgICBwYWRkaW5nLXJpZ2h0OiAwLjEycmVtO1xyXG4gICAgcGFkZGluZy1sZWZ0OiAwLjEycmVtO1xyXG59XHJcblxyXG4uaW5zdXJhbmNlIHtcclxuICAgIHBhZGRpbmctYm90dG9tOiAwLjVyZW07XHJcbn1cclxuXHJcbi50aXRsZSB7XHJcbiAgICBjb2xvcjogJGNvbG9yLW5leHRnZW4tYmx1ZTtcclxuICAgIHBhZGRpbmctdG9wOiAxNnB4O1xyXG4gICAgcGFkZGluZy1ib3R0b206IDhweDtcclxufVxyXG4udGl0bGUtbWVuYmVye1xyXG4gICAgY29sb3I6ICRjb2xvci1uZXh0Z2VuLWJsdWU7XHJcbiAgICBwYWRkaW5nLXRvcDogMTZweDtcclxufVxyXG5cclxuLmdyaWQtY29udGVudCB7XHJcbiAgICBwYWRkaW5nOiAwIDUlO1xyXG4gICAgYmFja2dyb3VuZDogJGNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTUwICAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4uZ3JpZC1tZW1iZXIge1xyXG4gICAgcGFkZGluZy1sZWZ0OiA1JTtcclxuICAgIGJhY2tncm91bmQ6ICRjb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS01MCAgIWltcG9ydGFudDtcclxufSJdfQ== */";

/***/ }),

/***/ 25333:
/*!**********************************************************************************************!*\
  !*** ./src/app/pages/home/dashboard/insurance-card/insurance-card.component.scss?ngResource ***!
  \**********************************************************************************************/
/***/ ((module) => {

module.exports = ":root {\n  --nc-color-nextgen-neutral-grey-50: red;\n  --nc-color-nextgen-white: yellow;\n  --nc-color-nextgen-blue: #0d152e;\n  --nc-color-nextgen-green: #00908d;\n  --nc-color-nextgen-black: #000000;\n  --nc-color-nextgen-grey-background: #c8d3da;\n  --nc-color-nextgen-grey: #92a2ac;\n  --nc-color-nextgen-stone-grey: #fafafa;\n  --nc-color-nextgen-error: #fc1055;\n  --nc-color-nextgen-neutral-grey: #414141;\n  --nc-color-nextgen-fibrant-green: #00bab6;\n  --nc-color-nextgen-warning: #ffd048;\n  --nc-color-nextgen-green-background: #e6f2f2;\n  --nc-color-nextgen-neutral-grey-400: #7a7a7a;\n  --nc-color-nextgen-neutral-grey-100: #eff3f5;\n  --nc-color-nextgen-status-error: #ba0c3f;\n  --nc-color-nextgen-status-error-background: #ffeff4;\n  --nc-color-nextgen-status-warning: #cba127;\n  --nc-color-nextgen-status-warning-background: #fff8e6;\n  --nc-color-nextgen-blue-100: #dfeff2;\n  --nc-color-nextgen-error-red-700: #f62459;\n  --nc-color-nextgen-blue-500: #006192;\n  --nc-color-nextgen-blue-400: #79cdec;\n  --nc-color-nextgen-red-500: #ff6592;\n  --nc-color-nextgen-secondary-blue-300: #13a0d3;\n  --lumi-white-color: #ffffff;\n  --lumi-primary-yellow-color: #fab600;\n}\n\n.ion-color-green {\n  --ion-color-base: var(--nc-color-nextgen-green);\n  --ion-color-base-rgb: var(--nc-color-nextgen-green);\n  --ion-color-contrast: var(--nc-color-nextgen-white);\n  --ion-color-contrast-rgb: var(--nc-color-nextgen-green);\n  --ion-color-shade: var(--nc-color-nextgen-green);\n  --ion-color-tint: var(--nc-color-nextgen-green);\n}\n\n.insurance-card {\n  background: var(--nc-color-nextgen-white);\n  box-shadow: 0px 1px 2px rgba(0, 0, 0, 0.1);\n  border-radius: 8px;\n  padding: 1rem;\n  align-items: center;\n}\n\n.icon {\n  padding-right: 2rem;\n  width: 16px;\n  height: 16px;\n}\n\n.image-card {\n  height: 40px;\n  width: 40px;\n  background-color: var(--nc-color-nextgen-blue-100);\n  border-radius: 50%;\n  justify-content: center;\n  display: flex;\n  align-items: center;\n}\n\n.icon-insurance {\n  padding-left: 2rem;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFwuLlxcY29sb3Iuc2NzcyIsImluc3VyYW5jZS1jYXJkLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0MsdUNBQUE7RUFDQSxnQ0FBQTtFQUNBLGdDQUFBO0VBQ0EsaUNBQUE7RUFDQSxpQ0FBQTtFQUNBLDJDQUFBO0VBQ0EsZ0NBQUE7RUFDQSxzQ0FBQTtFQUNBLGlDQUFBO0VBQ0Esd0NBQUE7RUFDQSx5Q0FBQTtFQUNBLG1DQUFBO0VBQ0EsNENBQUE7RUFDQSw0Q0FBQTtFQUNBLDRDQUFBO0VBQ0Esd0NBQUE7RUFDQSxtREFBQTtFQUNBLDBDQUFBO0VBQ0EscURBQUE7RUFDQSxvQ0FBQTtFQUNBLHlDQUFBO0VBQ0Esb0NBQUE7RUFDQSxvQ0FBQTtFQUNBLG1DQUFBO0VBQ0EsOENBQUE7RUFFQSwyQkFBQTtFQUNBLG9DQUFBO0FDQUQ7O0FEZ0NBO0VBQ0MsK0NBQUE7RUFDQSxtREFBQTtFQUNBLG1EQUFBO0VBQ0EsdURBQUE7RUFDQSxnREFBQTtFQUNBLCtDQUFBO0FDN0JEOztBQW5DQTtFQUNJLHlDRDZCa0I7RUM1QmxCLDBDQUFBO0VBQ0Esa0JBQUE7RUFDQSxhQUFBO0VBQ0EsbUJBQUE7QUFzQ0o7O0FBbkNBO0VBRUksbUJBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtBQXFDSjs7QUFuQ0E7RUFDSSxZQUFBO0VBQ0EsV0FBQTtFQUNBLGtERGtDcUI7RUNqQ3JCLGtCQUFBO0VBQ0EsdUJBQUE7RUFDQSxhQUFBO0VBQ0EsbUJBQUE7QUFzQ0o7O0FBbkNBO0VBQ0ksa0JBQUE7QUFzQ0oiLCJmaWxlIjoiaW5zdXJhbmNlLWNhcmQuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyI6cm9vdCB7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS01MDogcmVkO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi13aGl0ZTogeWVsbG93O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlOiAjMGQxNTJlO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbjogIzAwOTA4ZDtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tYmxhY2s6ICMwMDAwMDA7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWdyZXktYmFja2dyb3VuZDogI2M4ZDNkYTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tZ3JleTogIzkyYTJhYztcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc3RvbmUtZ3JleTogI2ZhZmFmYTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tZXJyb3I6ICNmYzEwNTU7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleTogIzQxNDE0MTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tZmlicmFudC1ncmVlbjogIzAwYmFiNjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4td2FybmluZzogI2ZmZDA0ODtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4tYmFja2dyb3VuZDogI2U2ZjJmMjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTQwMDogIzdhN2E3YTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTEwMDogI2VmZjNmNTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yOiAjYmEwYzNmO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtZXJyb3ItYmFja2dyb3VuZDogI2ZmZWZmNDtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLXdhcm5pbmc6ICNjYmExMjc7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy13YXJuaW5nLWJhY2tncm91bmQ6ICNmZmY4ZTY7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWJsdWUtMTAwOiAjZGZlZmYyO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1lcnJvci1yZWQtNzAwOiAjZjYyNDU5O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlLTUwMDogIzAwNjE5MjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZS00MDA6ICM3OWNkZWM7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXJlZC01MDA6ICNmZjY1OTI7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXNlY29uZGFyeS1ibHVlLTMwMDogIzEzYTBkMztcclxuXHJcblx0LS1sdW1pLXdoaXRlLWNvbG9yOiAjZmZmZmZmO1xyXG5cdC0tbHVtaS1wcmltYXJ5LXllbGxvdy1jb2xvcjogI2ZhYjYwMDtcclxufVxyXG4kY29sb3ItbmV4dGdlbi1ibHVlOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWJsdWUpO1xyXG4kY29sb3ItbmV4dGdlbi1ncmVlbjogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbik7XHJcbiRjb2xvci1uZXh0Z2VuLXdoaXRlOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXdoaXRlKTtcclxuJGNvbG9yLW5leHRnZW4tYmxhY2s6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tYmxhY2spO1xyXG4kY29sb3ItbmV4dGdlbi1ncmV5LWJhY2tncm91bmQ6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JleS1iYWNrZ3JvdW5kKTtcclxuJGNvbG9yLW5leHRnZW4tZ3JleTogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmV5KTtcclxuJGNvbG9yLW5leHRnZW4tc3RvbmUtZ3JleTogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1zdG9uZS1ncmV5KTtcclxuJGNvbG9yLW5leHRnZW4tZXJyb3I6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZXJyb3IpO1xyXG4kY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXk6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5KTtcclxuJGNvbG9yLW5leHRnZW4tZmlicmFudC1ncmVlbjogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1maWJyYW50LWdyZWVuKTtcclxuJGNvbG9yLW5leHRnZW4td2FybmluZzogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi13YXJuaW5nKTtcclxuJGNvbG9yLW5leHRnZW4tZ3JlZW4tYmFja2dyb3VuZDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbi1iYWNrZ3JvdW5kKTtcclxuJGNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTUwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS01MCk7XHJcbiRjb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS00MDA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTQwMCk7XHJcbiRjb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS0xMDA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTEwMCk7XHJcbiRjb2xvci1uZXh0Z2VuLXN0YXR1cy1lcnJvcjogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtZXJyb3IpO1xyXG4kY29sb3ItbmV4dGdlbi1zdGF0dXMtZXJyb3ItYmFja2dyb3VuZDogdmFyKFxyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtZXJyb3ItYmFja2dyb3VuZFxyXG4pO1xyXG4kY29sb3ItbmV4dGdlbi1zdGF0dXMtd2FybmluZzogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtd2FybmluZyk7XHJcbiRjb2xvci1uZXh0Z2VuLXN0YXR1cy13YXJuaW5nLWJhY2tncm91bmQ6IHZhcihcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLXdhcm5pbmctYmFja2dyb3VuZFxyXG4pO1xyXG4kY29sb3ItbmV4dGdlbi1ibHVlLTEwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlLTEwMCk7XHJcbiRjb2xvci1uZXh0Z2VuLWVycm9yLXJlZC03MDA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZXJyb3ItcmVkLTcwMCk7XHJcbiRjb2xvci1uZXh0Z2VuLWJsdWUtNTAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWJsdWUtNTAwKTtcclxuJGNvbG9yLW5leHRnZW4tYmx1ZS00MDA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZS00MDApO1xyXG4kY29sb3ItbmV4dGdlbi1yZWQtNTAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXJlZC01MDApO1xyXG4kY29sb3ItbmV4dGdlbi1zZWNvbmRhcnktYmx1ZS0zMDA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tc2Vjb25kYXJ5LWJsdWUtMzAwKTtcclxuXHJcbi5pb24tY29sb3ItZ3JlZW4ge1xyXG5cdC0taW9uLWNvbG9yLWJhc2U6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4pO1xyXG5cdC0taW9uLWNvbG9yLWJhc2UtcmdiOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuKTtcclxuXHQtLWlvbi1jb2xvci1jb250cmFzdDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi13aGl0ZSk7XHJcblx0LS1pb24tY29sb3ItY29udHJhc3QtcmdiOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuKTtcclxuXHQtLWlvbi1jb2xvci1zaGFkZTogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbik7XHJcblx0LS1pb24tY29sb3ItdGludDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbik7XHJcbn1cclxuIiwiQGltcG9ydCBcIi4uLy4uLy4uLy4uLy4uL2NvbG9yLnNjc3NcIjtcclxuXHJcbi5pbnN1cmFuY2UtY2FyZCB7XHJcbiAgICBiYWNrZ3JvdW5kOiAkY29sb3ItbmV4dGdlbi13aGl0ZTtcclxuICAgIGJveC1zaGFkb3c6IDBweCAxcHggMnB4IHJnYmEoMCwgMCwgMCwgMC4xKTtcclxuICAgIGJvcmRlci1yYWRpdXM6IDhweDtcclxuICAgIHBhZGRpbmc6IDFyZW07XHJcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG59XHJcblxyXG4uaWNvbiB7XHJcbiAgICAvLyBmb250LXNpemU6IDEuNXJlbSAhaW1wb3J0YW50O1xyXG4gICAgcGFkZGluZy1yaWdodDogMnJlbTtcclxuICAgIHdpZHRoOiAxNnB4O1xyXG4gICAgaGVpZ2h0OiAxNnB4O1xyXG59XHJcbi5pbWFnZS1jYXJke1xyXG4gICAgaGVpZ2h0OiA0MHB4O1xyXG4gICAgd2lkdGg6IDQwcHg7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAkY29sb3ItbmV4dGdlbi1ibHVlLTEwMDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDUwJTtcclxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbn1cclxuXHJcbi5pY29uLWluc3VyYW5jZXtcclxuICAgIHBhZGRpbmctbGVmdDogMnJlbTtcclxufVxyXG5cclxuXHJcblxyXG4iXX0= */";

/***/ }),

/***/ 26401:
/*!******************************************************************************************!*\
  !*** ./src/app/pages/home/dashboard/medical-card/medical-card.component.scss?ngResource ***!
  \******************************************************************************************/
/***/ ((module) => {

module.exports = ":root {\n  --nc-color-nextgen-neutral-grey-50: red;\n  --nc-color-nextgen-white: yellow;\n  --nc-color-nextgen-blue: #0d152e;\n  --nc-color-nextgen-green: #00908d;\n  --nc-color-nextgen-black: #000000;\n  --nc-color-nextgen-grey-background: #c8d3da;\n  --nc-color-nextgen-grey: #92a2ac;\n  --nc-color-nextgen-stone-grey: #fafafa;\n  --nc-color-nextgen-error: #fc1055;\n  --nc-color-nextgen-neutral-grey: #414141;\n  --nc-color-nextgen-fibrant-green: #00bab6;\n  --nc-color-nextgen-warning: #ffd048;\n  --nc-color-nextgen-green-background: #e6f2f2;\n  --nc-color-nextgen-neutral-grey-400: #7a7a7a;\n  --nc-color-nextgen-neutral-grey-100: #eff3f5;\n  --nc-color-nextgen-status-error: #ba0c3f;\n  --nc-color-nextgen-status-error-background: #ffeff4;\n  --nc-color-nextgen-status-warning: #cba127;\n  --nc-color-nextgen-status-warning-background: #fff8e6;\n  --nc-color-nextgen-blue-100: #dfeff2;\n  --nc-color-nextgen-error-red-700: #f62459;\n  --nc-color-nextgen-blue-500: #006192;\n  --nc-color-nextgen-blue-400: #79cdec;\n  --nc-color-nextgen-red-500: #ff6592;\n  --nc-color-nextgen-secondary-blue-300: #13a0d3;\n  --lumi-white-color: #ffffff;\n  --lumi-primary-yellow-color: #fab600;\n}\n\n.ion-color-green {\n  --ion-color-base: var(--nc-color-nextgen-green);\n  --ion-color-base-rgb: var(--nc-color-nextgen-green);\n  --ion-color-contrast: var(--nc-color-nextgen-white);\n  --ion-color-contrast-rgb: var(--nc-color-nextgen-green);\n  --ion-color-shade: var(--nc-color-nextgen-green);\n  --ion-color-tint: var(--nc-color-nextgen-green);\n}\n\n.medical-card {\n  text-align: center;\n  padding: 1rem;\n  box-shadow: 0px 1px 2px rgba(0, 0, 0, 0.1);\n  border-radius: 8px;\n  min-height: 140px;\n}\n\n:host ::ng-deep.mat-dialog-container {\n  position: relative;\n  padding: 0 !important;\n}\n\n@media screen and (max-width: 360px) {\n  .medical-card .dynamic-text {\n    font-size: 13px !important;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFwuLlxcY29sb3Iuc2NzcyIsIm1lZGljYWwtY2FyZC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNDLHVDQUFBO0VBQ0EsZ0NBQUE7RUFDQSxnQ0FBQTtFQUNBLGlDQUFBO0VBQ0EsaUNBQUE7RUFDQSwyQ0FBQTtFQUNBLGdDQUFBO0VBQ0Esc0NBQUE7RUFDQSxpQ0FBQTtFQUNBLHdDQUFBO0VBQ0EseUNBQUE7RUFDQSxtQ0FBQTtFQUNBLDRDQUFBO0VBQ0EsNENBQUE7RUFDQSw0Q0FBQTtFQUNBLHdDQUFBO0VBQ0EsbURBQUE7RUFDQSwwQ0FBQTtFQUNBLHFEQUFBO0VBQ0Esb0NBQUE7RUFDQSx5Q0FBQTtFQUNBLG9DQUFBO0VBQ0Esb0NBQUE7RUFDQSxtQ0FBQTtFQUNBLDhDQUFBO0VBRUEsMkJBQUE7RUFDQSxvQ0FBQTtBQ0FEOztBRGdDQTtFQUNDLCtDQUFBO0VBQ0EsbURBQUE7RUFDQSxtREFBQTtFQUNBLHVEQUFBO0VBQ0EsZ0RBQUE7RUFDQSwrQ0FBQTtBQzdCRDs7QUFuQ0E7RUFDRSxrQkFBQTtFQUNBLGFBQUE7RUFDQSwwQ0FBQTtFQUNBLGtCQUFBO0VBQ0EsaUJBQUE7QUFzQ0Y7O0FBbkNBO0VBQ0Usa0JBQUE7RUFDQSxxQkFBQTtBQXNDRjs7QUFwQ0E7RUFFSTtJQUNFLDBCQUFBO0VBc0NKO0FBQ0YiLCJmaWxlIjoibWVkaWNhbC1jYXJkLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiOnJvb3Qge1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNTA6IHJlZDtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4td2hpdGU6IHllbGxvdztcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZTogIzBkMTUyZTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW46ICMwMDkwOGQ7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWJsYWNrOiAjMDAwMDAwO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ncmV5LWJhY2tncm91bmQ6ICNjOGQzZGE7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWdyZXk6ICM5MmEyYWM7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0b25lLWdyZXk6ICNmYWZhZmE7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWVycm9yOiAjZmMxMDU1O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXk6ICM0MTQxNDE7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWZpYnJhbnQtZ3JlZW46ICMwMGJhYjY7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXdhcm5pbmc6ICNmZmQwNDg7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuLWJhY2tncm91bmQ6ICNlNmYyZjI7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS00MDA6ICM3YTdhN2E7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS0xMDA6ICNlZmYzZjU7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy1lcnJvcjogI2JhMGMzZjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yLWJhY2tncm91bmQ6ICNmZmVmZjQ7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy13YXJuaW5nOiAjY2JhMTI3O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtd2FybmluZy1iYWNrZ3JvdW5kOiAjZmZmOGU2O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlLTEwMDogI2RmZWZmMjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tZXJyb3ItcmVkLTcwMDogI2Y2MjQ1OTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZS01MDA6ICMwMDYxOTI7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWJsdWUtNDAwOiAjNzljZGVjO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1yZWQtNTAwOiAjZmY2NTkyO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zZWNvbmRhcnktYmx1ZS0zMDA6ICMxM2EwZDM7XHJcblxyXG5cdC0tbHVtaS13aGl0ZS1jb2xvcjogI2ZmZmZmZjtcclxuXHQtLWx1bWktcHJpbWFyeS15ZWxsb3ctY29sb3I6ICNmYWI2MDA7XHJcbn1cclxuJGNvbG9yLW5leHRnZW4tYmx1ZTogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlKTtcclxuJGNvbG9yLW5leHRnZW4tZ3JlZW46IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4pO1xyXG4kY29sb3ItbmV4dGdlbi13aGl0ZTogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi13aGl0ZSk7XHJcbiRjb2xvci1uZXh0Z2VuLWJsYWNrOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWJsYWNrKTtcclxuJGNvbG9yLW5leHRnZW4tZ3JleS1iYWNrZ3JvdW5kOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZXktYmFja2dyb3VuZCk7XHJcbiRjb2xvci1uZXh0Z2VuLWdyZXk6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JleSk7XHJcbiRjb2xvci1uZXh0Z2VuLXN0b25lLWdyZXk6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tc3RvbmUtZ3JleSk7XHJcbiRjb2xvci1uZXh0Z2VuLWVycm9yOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWVycm9yKTtcclxuJGNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5OiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleSk7XHJcbiRjb2xvci1uZXh0Z2VuLWZpYnJhbnQtZ3JlZW46IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZmlicmFudC1ncmVlbik7XHJcbiRjb2xvci1uZXh0Z2VuLXdhcm5pbmc6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4td2FybmluZyk7XHJcbiRjb2xvci1uZXh0Z2VuLWdyZWVuLWJhY2tncm91bmQ6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4tYmFja2dyb3VuZCk7XHJcbiRjb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS01MDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNTApO1xyXG4kY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNDAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS00MDApO1xyXG4kY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktMTAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS0xMDApO1xyXG4kY29sb3ItbmV4dGdlbi1zdGF0dXMtZXJyb3I6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yKTtcclxuJGNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yLWJhY2tncm91bmQ6IHZhcihcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yLWJhY2tncm91bmRcclxuKTtcclxuJGNvbG9yLW5leHRnZW4tc3RhdHVzLXdhcm5pbmc6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLXdhcm5pbmcpO1xyXG4kY29sb3ItbmV4dGdlbi1zdGF0dXMtd2FybmluZy1iYWNrZ3JvdW5kOiB2YXIoXHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy13YXJuaW5nLWJhY2tncm91bmRcclxuKTtcclxuJGNvbG9yLW5leHRnZW4tYmx1ZS0xMDA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZS0xMDApO1xyXG4kY29sb3ItbmV4dGdlbi1lcnJvci1yZWQtNzAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWVycm9yLXJlZC03MDApO1xyXG4kY29sb3ItbmV4dGdlbi1ibHVlLTUwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlLTUwMCk7XHJcbiRjb2xvci1uZXh0Z2VuLWJsdWUtNDAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWJsdWUtNDAwKTtcclxuJGNvbG9yLW5leHRnZW4tcmVkLTUwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1yZWQtNTAwKTtcclxuJGNvbG9yLW5leHRnZW4tc2Vjb25kYXJ5LWJsdWUtMzAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXNlY29uZGFyeS1ibHVlLTMwMCk7XHJcblxyXG4uaW9uLWNvbG9yLWdyZWVuIHtcclxuXHQtLWlvbi1jb2xvci1iYXNlOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuKTtcclxuXHQtLWlvbi1jb2xvci1iYXNlLXJnYjogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbik7XHJcblx0LS1pb24tY29sb3ItY29udHJhc3Q6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4td2hpdGUpO1xyXG5cdC0taW9uLWNvbG9yLWNvbnRyYXN0LXJnYjogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbik7XHJcblx0LS1pb24tY29sb3Itc2hhZGU6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4pO1xyXG5cdC0taW9uLWNvbG9yLXRpbnQ6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4pO1xyXG59XHJcbiIsIkBpbXBvcnQgXCIuLi8uLi8uLi8uLi8uLi9jb2xvci5zY3NzXCI7XHJcblxyXG4ubWVkaWNhbC1jYXJkIHtcclxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgcGFkZGluZzogMXJlbTtcclxuICBib3gtc2hhZG93OiAwcHggMXB4IDJweCByZ2JhKDAsIDAsIDAsIDAuMSk7XHJcbiAgYm9yZGVyLXJhZGl1czogOHB4O1xyXG4gIG1pbi1oZWlnaHQ6IDE0MHB4O1xyXG59XHJcblxyXG46aG9zdCA6Om5nLWRlZXAubWF0LWRpYWxvZy1jb250YWluZXIge1xyXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICBwYWRkaW5nOiAwICFpbXBvcnRhbnQ7XHJcbn1cclxuQG1lZGlhIHNjcmVlbiBhbmQgKG1heC13aWR0aDogMzYwcHgpIHtcclxuICAubWVkaWNhbC1jYXJke1xyXG4gICAgLmR5bmFtaWMtdGV4dHtcclxuICAgICAgZm9udC1zaXplOiAxM3B4IWltcG9ydGFudDtcclxuICAgIH1cclxuICB9XHJcbn0iXX0= */";

/***/ }),

/***/ 96588:
/*!**************************************************************************!*\
  !*** ./src/app/pages/home/home-care/home-care.component.scss?ngResource ***!
  \**************************************************************************/
/***/ ((module) => {

module.exports = ":root {\n  --nc-color-nextgen-neutral-grey-50: red;\n  --nc-color-nextgen-white: yellow;\n  --nc-color-nextgen-blue: #0d152e;\n  --nc-color-nextgen-green: #00908d;\n  --nc-color-nextgen-black: #000000;\n  --nc-color-nextgen-grey-background: #c8d3da;\n  --nc-color-nextgen-grey: #92a2ac;\n  --nc-color-nextgen-stone-grey: #fafafa;\n  --nc-color-nextgen-error: #fc1055;\n  --nc-color-nextgen-neutral-grey: #414141;\n  --nc-color-nextgen-fibrant-green: #00bab6;\n  --nc-color-nextgen-warning: #ffd048;\n  --nc-color-nextgen-green-background: #e6f2f2;\n  --nc-color-nextgen-neutral-grey-400: #7a7a7a;\n  --nc-color-nextgen-neutral-grey-100: #eff3f5;\n  --nc-color-nextgen-status-error: #ba0c3f;\n  --nc-color-nextgen-status-error-background: #ffeff4;\n  --nc-color-nextgen-status-warning: #cba127;\n  --nc-color-nextgen-status-warning-background: #fff8e6;\n  --nc-color-nextgen-blue-100: #dfeff2;\n  --nc-color-nextgen-error-red-700: #f62459;\n  --nc-color-nextgen-blue-500: #006192;\n  --nc-color-nextgen-blue-400: #79cdec;\n  --nc-color-nextgen-red-500: #ff6592;\n  --nc-color-nextgen-secondary-blue-300: #13a0d3;\n  --lumi-white-color: #ffffff;\n  --lumi-primary-yellow-color: #fab600;\n}\n\n.ion-color-green {\n  --ion-color-base: var(--nc-color-nextgen-green);\n  --ion-color-base-rgb: var(--nc-color-nextgen-green);\n  --ion-color-contrast: var(--nc-color-nextgen-white);\n  --ion-color-contrast-rgb: var(--nc-color-nextgen-green);\n  --ion-color-shade: var(--nc-color-nextgen-green);\n  --ion-color-tint: var(--nc-color-nextgen-green);\n}\n\n.home-care-page {\n  background-color: var(--nc-color-nextgen-neutral-grey-50);\n  min-height: 100%;\n  --background: $color-nextgen-neutral-grey-50;\n}\n\n.home-care-page .grid-content {\n  padding: 0 24px;\n}\n\n.home-care-page .title {\n  color: var(--nc-color-nextgen-blue) !important;\n  padding-top: 1rem;\n  padding-bottom: 1rem;\n}\n\n.home-care-page .home-care-content {\n  position: relative;\n}\n\n.home-care-page .home-care-content .home-care-card {\n  margin-bottom: 0.5rem;\n  padding: 18px 22px;\n  border-radius: 8px;\n  box-shadow: 0px 1px 2px rgba(0, 0, 0, 0.1);\n}\n\n.home-care-page .home-care-content .home-care-card-avt {\n  width: 64px;\n  height: 64px;\n  align-items: center;\n  color: var(--nc-color-nextgen-grey);\n}\n\n.home-care-page .home-care-content .home-care-card-title {\n  color: var(--nc-color-nextgen-blue) !important;\n}\n\n.home-care-page .home-care-content .home-care-card-text {\n  color: var(--nc-color-nextgen-neutral-grey-400) !important;\n}\n\n.home-care-page .home-care-content .home-care-card-icon ion-icon {\n  color: var(--nc-color-nextgen-grey) !important;\n}\n\n.swiper-slide {\n  display: block;\n}\n\n.grid-member {\n  padding-left: 5%;\n  background: var(--nc-color-nextgen-neutral-grey-50) !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFxjb2xvci5zY3NzIiwiaG9tZS1jYXJlLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0MsdUNBQUE7RUFDQSxnQ0FBQTtFQUNBLGdDQUFBO0VBQ0EsaUNBQUE7RUFDQSxpQ0FBQTtFQUNBLDJDQUFBO0VBQ0EsZ0NBQUE7RUFDQSxzQ0FBQTtFQUNBLGlDQUFBO0VBQ0Esd0NBQUE7RUFDQSx5Q0FBQTtFQUNBLG1DQUFBO0VBQ0EsNENBQUE7RUFDQSw0Q0FBQTtFQUNBLDRDQUFBO0VBQ0Esd0NBQUE7RUFDQSxtREFBQTtFQUNBLDBDQUFBO0VBQ0EscURBQUE7RUFDQSxvQ0FBQTtFQUNBLHlDQUFBO0VBQ0Esb0NBQUE7RUFDQSxvQ0FBQTtFQUNBLG1DQUFBO0VBQ0EsOENBQUE7RUFFQSwyQkFBQTtFQUNBLG9DQUFBO0FDQUQ7O0FEZ0NBO0VBQ0MsK0NBQUE7RUFDQSxtREFBQTtFQUNBLG1EQUFBO0VBQ0EsdURBQUE7RUFDQSxnREFBQTtFQUNBLCtDQUFBO0FDN0JEOztBQW5DQTtFQUNFLHlERHVDOEI7RUN0QzlCLGdCQUFBO0VBQ0EsNENBQUE7QUFzQ0Y7O0FBcENFO0VBQ0UsZUFBQTtBQXNDSjs7QUFuQ0U7RUFDRSw4Q0FBQTtFQUNBLGlCQUFBO0VBQ0Esb0JBQUE7QUFxQ0o7O0FBbENFO0VBQ0Usa0JBQUE7QUFvQ0o7O0FBbENJO0VBQ0UscUJBQUE7RUFDQSxrQkFBQTtFQUNBLGtCQUFBO0VBQ0EsMENBQUE7QUFvQ047O0FBbENNO0VBQ0UsV0FBQTtFQUNBLFlBQUE7RUFDQSxtQkFBQTtFQUNBLG1DREthO0FDK0JyQjs7QUFqQ007RUFFRSw4Q0FBQTtBQWtDUjs7QUEvQk07RUFDRSwwREFBQTtBQWlDUjs7QUF6QlE7RUFDRSw4Q0FBQTtBQTJCVjs7QUFsQkE7RUFDRSxjQUFBO0FBcUJGOztBQWxCQTtFQUNFLGdCQUFBO0VBQ0EsOERBQUE7QUFxQkYiLCJmaWxlIjoiaG9tZS1jYXJlLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiOnJvb3Qge1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNTA6IHJlZDtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4td2hpdGU6IHllbGxvdztcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZTogIzBkMTUyZTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW46ICMwMDkwOGQ7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWJsYWNrOiAjMDAwMDAwO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ncmV5LWJhY2tncm91bmQ6ICNjOGQzZGE7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWdyZXk6ICM5MmEyYWM7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0b25lLWdyZXk6ICNmYWZhZmE7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWVycm9yOiAjZmMxMDU1O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXk6ICM0MTQxNDE7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWZpYnJhbnQtZ3JlZW46ICMwMGJhYjY7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXdhcm5pbmc6ICNmZmQwNDg7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuLWJhY2tncm91bmQ6ICNlNmYyZjI7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS00MDA6ICM3YTdhN2E7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS0xMDA6ICNlZmYzZjU7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy1lcnJvcjogI2JhMGMzZjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yLWJhY2tncm91bmQ6ICNmZmVmZjQ7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy13YXJuaW5nOiAjY2JhMTI3O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtd2FybmluZy1iYWNrZ3JvdW5kOiAjZmZmOGU2O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlLTEwMDogI2RmZWZmMjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tZXJyb3ItcmVkLTcwMDogI2Y2MjQ1OTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZS01MDA6ICMwMDYxOTI7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWJsdWUtNDAwOiAjNzljZGVjO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1yZWQtNTAwOiAjZmY2NTkyO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zZWNvbmRhcnktYmx1ZS0zMDA6ICMxM2EwZDM7XHJcblxyXG5cdC0tbHVtaS13aGl0ZS1jb2xvcjogI2ZmZmZmZjtcclxuXHQtLWx1bWktcHJpbWFyeS15ZWxsb3ctY29sb3I6ICNmYWI2MDA7XHJcbn1cclxuJGNvbG9yLW5leHRnZW4tYmx1ZTogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlKTtcclxuJGNvbG9yLW5leHRnZW4tZ3JlZW46IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4pO1xyXG4kY29sb3ItbmV4dGdlbi13aGl0ZTogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi13aGl0ZSk7XHJcbiRjb2xvci1uZXh0Z2VuLWJsYWNrOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWJsYWNrKTtcclxuJGNvbG9yLW5leHRnZW4tZ3JleS1iYWNrZ3JvdW5kOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZXktYmFja2dyb3VuZCk7XHJcbiRjb2xvci1uZXh0Z2VuLWdyZXk6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JleSk7XHJcbiRjb2xvci1uZXh0Z2VuLXN0b25lLWdyZXk6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tc3RvbmUtZ3JleSk7XHJcbiRjb2xvci1uZXh0Z2VuLWVycm9yOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWVycm9yKTtcclxuJGNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5OiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleSk7XHJcbiRjb2xvci1uZXh0Z2VuLWZpYnJhbnQtZ3JlZW46IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZmlicmFudC1ncmVlbik7XHJcbiRjb2xvci1uZXh0Z2VuLXdhcm5pbmc6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4td2FybmluZyk7XHJcbiRjb2xvci1uZXh0Z2VuLWdyZWVuLWJhY2tncm91bmQ6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4tYmFja2dyb3VuZCk7XHJcbiRjb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS01MDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNTApO1xyXG4kY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNDAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS00MDApO1xyXG4kY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktMTAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS0xMDApO1xyXG4kY29sb3ItbmV4dGdlbi1zdGF0dXMtZXJyb3I6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yKTtcclxuJGNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yLWJhY2tncm91bmQ6IHZhcihcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yLWJhY2tncm91bmRcclxuKTtcclxuJGNvbG9yLW5leHRnZW4tc3RhdHVzLXdhcm5pbmc6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLXdhcm5pbmcpO1xyXG4kY29sb3ItbmV4dGdlbi1zdGF0dXMtd2FybmluZy1iYWNrZ3JvdW5kOiB2YXIoXHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy13YXJuaW5nLWJhY2tncm91bmRcclxuKTtcclxuJGNvbG9yLW5leHRnZW4tYmx1ZS0xMDA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZS0xMDApO1xyXG4kY29sb3ItbmV4dGdlbi1lcnJvci1yZWQtNzAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWVycm9yLXJlZC03MDApO1xyXG4kY29sb3ItbmV4dGdlbi1ibHVlLTUwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlLTUwMCk7XHJcbiRjb2xvci1uZXh0Z2VuLWJsdWUtNDAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWJsdWUtNDAwKTtcclxuJGNvbG9yLW5leHRnZW4tcmVkLTUwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1yZWQtNTAwKTtcclxuJGNvbG9yLW5leHRnZW4tc2Vjb25kYXJ5LWJsdWUtMzAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXNlY29uZGFyeS1ibHVlLTMwMCk7XHJcblxyXG4uaW9uLWNvbG9yLWdyZWVuIHtcclxuXHQtLWlvbi1jb2xvci1iYXNlOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuKTtcclxuXHQtLWlvbi1jb2xvci1iYXNlLXJnYjogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbik7XHJcblx0LS1pb24tY29sb3ItY29udHJhc3Q6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4td2hpdGUpO1xyXG5cdC0taW9uLWNvbG9yLWNvbnRyYXN0LXJnYjogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbik7XHJcblx0LS1pb24tY29sb3Itc2hhZGU6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4pO1xyXG5cdC0taW9uLWNvbG9yLXRpbnQ6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4pO1xyXG59XHJcbiIsIkBpbXBvcnQgXCIuLi8uLi8uLi8uLi9jb2xvci5zY3NzXCI7XHJcblxyXG4uaG9tZS1jYXJlLXBhZ2Uge1xyXG4gIGJhY2tncm91bmQtY29sb3I6ICRjb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS01MDtcclxuICBtaW4taGVpZ2h0OiAxMDAlO1xyXG4gIC0tYmFja2dyb3VuZDogJGNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTUwO1xyXG5cclxuICAuZ3JpZC1jb250ZW50IHtcclxuICAgIHBhZGRpbmc6IDAgMjRweDtcclxuICB9XHJcblxyXG4gIC50aXRsZSB7XHJcbiAgICBjb2xvcjogJGNvbG9yLW5leHRnZW4tYmx1ZSAhaW1wb3J0YW50O1xyXG4gICAgcGFkZGluZy10b3A6IDFyZW07XHJcbiAgICBwYWRkaW5nLWJvdHRvbTogMXJlbTtcclxuICB9XHJcblxyXG4gIC5ob21lLWNhcmUtY29udGVudCB7XHJcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcblxyXG4gICAgLmhvbWUtY2FyZS1jYXJkIHtcclxuICAgICAgbWFyZ2luLWJvdHRvbTogMC41cmVtO1xyXG4gICAgICBwYWRkaW5nOiAxOHB4IDIycHg7XHJcbiAgICAgIGJvcmRlci1yYWRpdXM6IDhweDtcclxuICAgICAgYm94LXNoYWRvdzogMHB4IDFweCAycHggcmdiYSgwLCAwLCAwLCAwLjEpO1xyXG5cclxuICAgICAgJi1hdnQge1xyXG4gICAgICAgIHdpZHRoOiA2NHB4O1xyXG4gICAgICAgIGhlaWdodDogNjRweDtcclxuICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgICAgIGNvbG9yOiAkY29sb3ItbmV4dGdlbi1ncmV5O1xyXG4gICAgICB9XHJcblxyXG4gICAgICAmLXRpdGxlIHtcclxuXHJcbiAgICAgICAgY29sb3I6ICRjb2xvci1uZXh0Z2VuLWJsdWUgIWltcG9ydGFudDtcclxuICAgICAgfVxyXG5cclxuICAgICAgJi10ZXh0IHtcclxuICAgICAgICBjb2xvcjogJGNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTQwMCAhaW1wb3J0YW50O1xyXG4gICAgICB9XHJcblxyXG4gICAgICAmLWljb24ge1xyXG4gICAgICAgIC8vIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgICAgICAvLyB0b3A6IDE4cHg7XHJcbiAgICAgICAgLy8gcmlnaHQ6IDIzcHg7XHJcblxyXG4gICAgICAgIGlvbi1pY29uIHtcclxuICAgICAgICAgIGNvbG9yOiAkY29sb3ItbmV4dGdlbi1ncmV5ICFpbXBvcnRhbnQ7XHJcblxyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgfVxyXG5cclxuICB9XHJcbn1cclxuXHJcbi5zd2lwZXItc2xpZGUge1xyXG4gIGRpc3BsYXk6IGJsb2NrO1xyXG59XHJcblxyXG4uZ3JpZC1tZW1iZXIge1xyXG4gIHBhZGRpbmctbGVmdDogNSU7XHJcbiAgYmFja2dyb3VuZDogJGNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTUwICFpbXBvcnRhbnQ7XHJcbn0iXX0= */";

/***/ }),

/***/ 12260:
/*!******************************************************!*\
  !*** ./src/app/pages/home/home.page.scss?ngResource ***!
  \******************************************************/
/***/ ((module) => {

module.exports = ":root {\n  --nc-color-nextgen-neutral-grey-50: red;\n  --nc-color-nextgen-white: yellow;\n  --nc-color-nextgen-blue: #0d152e;\n  --nc-color-nextgen-green: #00908d;\n  --nc-color-nextgen-black: #000000;\n  --nc-color-nextgen-grey-background: #c8d3da;\n  --nc-color-nextgen-grey: #92a2ac;\n  --nc-color-nextgen-stone-grey: #fafafa;\n  --nc-color-nextgen-error: #fc1055;\n  --nc-color-nextgen-neutral-grey: #414141;\n  --nc-color-nextgen-fibrant-green: #00bab6;\n  --nc-color-nextgen-warning: #ffd048;\n  --nc-color-nextgen-green-background: #e6f2f2;\n  --nc-color-nextgen-neutral-grey-400: #7a7a7a;\n  --nc-color-nextgen-neutral-grey-100: #eff3f5;\n  --nc-color-nextgen-status-error: #ba0c3f;\n  --nc-color-nextgen-status-error-background: #ffeff4;\n  --nc-color-nextgen-status-warning: #cba127;\n  --nc-color-nextgen-status-warning-background: #fff8e6;\n  --nc-color-nextgen-blue-100: #dfeff2;\n  --nc-color-nextgen-error-red-700: #f62459;\n  --nc-color-nextgen-blue-500: #006192;\n  --nc-color-nextgen-blue-400: #79cdec;\n  --nc-color-nextgen-red-500: #ff6592;\n  --nc-color-nextgen-secondary-blue-300: #13a0d3;\n  --lumi-white-color: #ffffff;\n  --lumi-primary-yellow-color: #fab600;\n}\n\n.ion-color-green {\n  --ion-color-base: var(--nc-color-nextgen-green);\n  --ion-color-base-rgb: var(--nc-color-nextgen-green);\n  --ion-color-contrast: var(--nc-color-nextgen-white);\n  --ion-color-contrast-rgb: var(--nc-color-nextgen-green);\n  --ion-color-shade: var(--nc-color-nextgen-green);\n  --ion-color-tint: var(--nc-color-nextgen-green);\n}\n\n.home-page-container {\n  font-style: normal;\n  font-size: 17px;\n  line-height: 21px;\n}\n\n.notifications-profile {\n  width: 20px;\n  height: 20px;\n  background-color: #f62459;\n  color: #ffff;\n  padding-top: 3px;\n}\n\n.profile-list-menu {\n  --width: 100%;\n}\n\n.button-policy {\n  height: 30px;\n  --border-radius: 20px;\n  --padding-top: 2px;\n}\n\n.button-policy .policy-text {\n  padding-left: 7px;\n  padding-right: 10px;\n}\n\n.expired {\n  --background: #ffeff4;\n  --background-activated: #ffeff4;\n}\n\n.expired .icon-policy {\n  color: #ff6592;\n}\n\n.active {\n  --background: #e6f2f2;\n  --background-activated: #e6f2f2;\n}\n\n.active .icon-policy {\n  color: #00bab6;\n}\n\n.Email-text {\n  margin: 0;\n  padding-top: 3px;\n  padding-bottom: 15px;\n}\n\n:host ::ng-deep.close-icon {\n  position: absolute;\n  top: 60px;\n  right: 25px;\n  font-size: 27px;\n  color: #92a2ac;\n  z-index: 5;\n  width: 20px;\n  height: 20px;\n}\n\n.profile-image-menu {\n  margin-top: 86px;\n  margin-bottom: 15px;\n  text-align: center;\n}\n\n.profile-image-menu .profile-image {\n  width: 85px;\n  height: 85px;\n  border-radius: 50%;\n  object-fit: cover;\n}\n\n.profile-image-menu .icon-avata {\n  width: 96px;\n  height: 96px;\n  border-radius: 50%;\n  object-fit: cover;\n}\n\n.home-toolbar {\n  padding: 15px 24px;\n  color: #595959;\n  display: flex;\n}\n\n.home-toolbar .start {\n  display: flex;\n  align-items: center;\n  flex: 1;\n  font-family: AllianzNeoW04-Regular, Arial;\n  font-style: normal;\n  font-weight: 600;\n  font-size: 17px;\n  line-height: 21px;\n  min-height: 40px;\n}\n\n.home-toolbar .start .welcome-text {\n  margin-left: 10px;\n}\n\n.home-toolbar .end {\n  display: flex;\n  justify-content: flex-end;\n  align-items: center;\n  flex: 1;\n  float: right;\n}\n\n.home-toolbar .end .profile-image {\n  margin-left: 10px;\n  width: 40px;\n  height: 40px;\n  border-radius: 50%;\n  object-fit: cover;\n}\n\n.home-toolbar .end .notification-icon:hover {\n  background-color: #e6e6e6;\n}\n\n#main-content {\n  background: var(--nc-color-nextgen-neutral-grey-50);\n  width: 100%;\n}\n\n#main-content ion-content {\n  --overflow: hidden;\n  height: calc(100% - 70px);\n}\n\n#main-content ion-content.ios {\n  height: calc(100% - 80px);\n}\n\n#main-content ion-title {\n  background-color: var(--nc-color-nextgen-neutral-grey-50);\n}\n\n.router-wrapper {\n  height: calc(100% - 120px);\n}\n\n.menu-item-container .menu-item {\n  display: flex;\n  margin: auto;\n  width: 90%;\n  height: 60px;\n  padding: 15px;\n  align-items: center;\n  justify-content: center;\n}\n\n.menu-item-container .menu-item .title {\n  display: flex;\n  align-items: center;\n  font-size: 18px;\n  font-weight: 400;\n  margin-left: 10px;\n  width: 90%;\n}\n\n.menu-item-container .menu-item:hover {\n  background: #e6e6e6;\n}\n\n.menu-item-container .menu-item .menu-icon {\n  display: flex;\n  align-items: center;\n  color: #c4c4c4;\n}\n\n.log-out {\n  position: absolute;\n  height: 60px;\n  padding: 15px;\n  left: 5%;\n  bottom: 4%;\n  width: 90%;\n  font-family: AllianzNeoW04-Regular, Arial;\n  font-style: normal;\n  font-weight: 600;\n  font-size: 18px;\n  line-height: 180%;\n  color: #323232;\n}\n\n.log-out:hover {\n  background-color: #e6e6e6;\n}\n\n.log-out-icon {\n  color: #c8d3da !important;\n}\n\n@media only screen and (min-width: 992px) {\n  .close-icon {\n    display: none;\n  }\n}\n\n@media only screen and (max-height: 650px) {\n  .close-icon {\n    display: none;\n  }\n\n  .log-out {\n    position: relative;\n  }\n}\n\n.tab-color {\n  color: var(--nc-color-nextgen-grey);\n}\n\n.tab-size {\n  font-size: 18px !important;\n}\n\n:host .tab-selected .tab-color {\n  color: var(--nc-color-nextgen-green);\n}\n\n:host .tab-selected .tab-size {\n  font-size: 18px !important;\n}\n\n.notification {\n  height: 36px;\n  width: 36px;\n  background-color: var(--nc-color-nextgen-stone-grey);\n  border-radius: 50%;\n  justify-content: center;\n  display: flex;\n  align-items: center;\n  margin-left: 10px;\n}\n\n.notification ion-icon {\n  font-size: 24px !important;\n}\n\n.footer {\n  box-shadow: 0px -4px 6px rgba(0, 0, 0, 0.05);\n  border-radius: 8px;\n  border: none;\n  height: 70px;\n}\n\nion-tab-button {\n  background-color: var(--nc-color-nextgen-neutral-grey-50) !important;\n  max-width: unset !important;\n  justify-content: flex-start !important;\n  padding-top: 10px;\n}\n\n.need-help-text {\n  color: var(--nc-color-nextgen-green);\n}\n\n.version-app {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n}\n\n.icon-language {\n  height: 13px;\n  margin-top: 8px;\n}\n\n.heart-image {\n  width: 100%;\n  max-width: 50px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXGNvbG9yLnNjc3MiLCJob21lLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNDLHVDQUFBO0VBQ0EsZ0NBQUE7RUFDQSxnQ0FBQTtFQUNBLGlDQUFBO0VBQ0EsaUNBQUE7RUFDQSwyQ0FBQTtFQUNBLGdDQUFBO0VBQ0Esc0NBQUE7RUFDQSxpQ0FBQTtFQUNBLHdDQUFBO0VBQ0EseUNBQUE7RUFDQSxtQ0FBQTtFQUNBLDRDQUFBO0VBQ0EsNENBQUE7RUFDQSw0Q0FBQTtFQUNBLHdDQUFBO0VBQ0EsbURBQUE7RUFDQSwwQ0FBQTtFQUNBLHFEQUFBO0VBQ0Esb0NBQUE7RUFDQSx5Q0FBQTtFQUNBLG9DQUFBO0VBQ0Esb0NBQUE7RUFDQSxtQ0FBQTtFQUNBLDhDQUFBO0VBRUEsMkJBQUE7RUFDQSxvQ0FBQTtBQ0FEOztBRGdDQTtFQUNDLCtDQUFBO0VBQ0EsbURBQUE7RUFDQSxtREFBQTtFQUNBLHVEQUFBO0VBQ0EsZ0RBQUE7RUFDQSwrQ0FBQTtBQzdCRDs7QUFuQ0E7RUFDQyxrQkFBQTtFQUNBLGVBQUE7RUFDQSxpQkFBQTtBQXNDRDs7QUFuQ0E7RUFDQyxXQUFBO0VBQ0EsWUFBQTtFQUNBLHlCQUFBO0VBQ0EsWUFBQTtFQUNBLGdCQUFBO0FBc0NEOztBQW5DQTtFQUNDLGFBQUE7QUFzQ0Q7O0FBbkNBO0VBQ0MsWUFBQTtFQUNBLHFCQUFBO0VBQ0Esa0JBQUE7QUFzQ0Q7O0FBcENDO0VBQ0MsaUJBQUE7RUFDQSxtQkFBQTtBQXNDRjs7QUFsQ0E7RUFDQyxxQkFBQTtFQUNBLCtCQUFBO0FBcUNEOztBQW5DQztFQUNDLGNBQUE7QUFxQ0Y7O0FBakNBO0VBQ0MscUJBQUE7RUFDQSwrQkFBQTtBQW9DRDs7QUFsQ0M7RUFDQyxjQUFBO0FBb0NGOztBQWhDQTtFQUNDLFNBQUE7RUFDQSxnQkFBQTtFQUNBLG9CQUFBO0FBbUNEOztBQWhDQTtFQUNDLGtCQUFBO0VBQ0EsU0FBQTtFQUNBLFdBQUE7RUFDQSxlQUFBO0VBQ0EsY0FBQTtFQUNBLFVBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtBQW1DRDs7QUFoQ0E7RUFDQyxnQkFBQTtFQUNBLG1CQUFBO0VBQ0Esa0JBQUE7QUFtQ0Q7O0FBakNDO0VBQ0MsV0FBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtFQUNBLGlCQUFBO0FBbUNGOztBQWhDQztFQUNDLFdBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7RUFDQSxpQkFBQTtBQWtDRjs7QUE5QkE7RUFDQyxrQkFBQTtFQUNBLGNBQUE7RUFDQSxhQUFBO0FBaUNEOztBQS9CQztFQUNDLGFBQUE7RUFDQSxtQkFBQTtFQUNBLE9BQUE7RUFDQSx5Q0FBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxlQUFBO0VBQ0EsaUJBQUE7RUFDQSxnQkFBQTtBQWlDRjs7QUEvQkU7RUFDQyxpQkFBQTtBQWlDSDs7QUE3QkM7RUFDQyxhQUFBO0VBQ0EseUJBQUE7RUFDQSxtQkFBQTtFQUNBLE9BQUE7RUFDQSxZQUFBO0FBK0JGOztBQTdCRTtFQUNDLGlCQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtFQUNBLGlCQUFBO0FBK0JIOztBQTVCRTtFQUNDLHlCQUFBO0FBOEJIOztBQXpCQTtFQUNDLG1ERHZGK0I7RUN3Ri9CLFdBQUE7QUE0QkQ7O0FBMUJDO0VBQ0Msa0JBQUE7RUFDQSx5QkFBQTtBQTRCRjs7QUF6QkM7RUFDQyx5QkFBQTtBQTJCRjs7QUF4QkM7RUFDQyx5RERwRzhCO0FDOEhoQzs7QUF0QkE7RUFDQywwQkFBQTtBQXlCRDs7QUFyQkM7RUFDQyxhQUFBO0VBQ0EsWUFBQTtFQUNBLFVBQUE7RUFDQSxZQUFBO0VBQ0EsYUFBQTtFQUNBLG1CQUFBO0VBQ0EsdUJBQUE7QUF3QkY7O0FBdEJFO0VBQ0MsYUFBQTtFQUNBLG1CQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0VBQ0EsaUJBQUE7RUFDQSxVQUFBO0FBd0JIOztBQWpCRTtFQUNDLG1CQUFBO0FBbUJIOztBQWhCRTtFQUNDLGFBQUE7RUFDQSxtQkFBQTtFQUNBLGNBQUE7QUFrQkg7O0FBYkE7RUFDQyxrQkFBQTtFQUNBLFlBQUE7RUFDQSxhQUFBO0VBRUEsUUFBQTtFQUNBLFVBQUE7RUFDQSxVQUFBO0VBQ0EseUNBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0EsZUFBQTtFQUNBLGlCQUFBO0VBQ0EsY0FBQTtBQWVEOztBQWJDO0VBQ0MseUJBQUE7QUFlRjs7QUFYQTtFQUNDLHlCQUFBO0FBY0Q7O0FBWEE7RUFDQztJQUNDLGFBQUE7RUFjQTtBQUNGOztBQVhBO0VBQ0M7SUFDQyxhQUFBO0VBYUE7O0VBVkQ7SUFDQyxrQkFBQTtFQWFBO0FBQ0Y7O0FBVkE7RUFDQyxtQ0QvTG9CO0FDMk1yQjs7QUFUQTtFQUNDLDBCQUFBO0FBWUQ7O0FBUEU7RUFDQyxvQ0Q3TW1CO0FDdU50Qjs7QUFQRTtFQUNDLDBCQUFBO0FBU0g7O0FBSkE7RUFDQyxZQUFBO0VBQ0EsV0FBQTtFQUNBLG9ERHBOMEI7RUNxTjFCLGtCQUFBO0VBQ0EsdUJBQUE7RUFDQSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSxpQkFBQTtBQU9EOztBQU5DO0VBQ0MsMEJBQUE7QUFRRjs7QUFKQTtFQUNDLDRDQUFBO0VBQ0Esa0JBQUE7RUFDQSxZQUFBO0VBQ0EsWUFBQTtBQU9EOztBQUpBO0VBQ0Msb0VBQUE7RUFDQSwyQkFBQTtFQUNBLHNDQUFBO0VBQ0EsaUJBQUE7QUFPRDs7QUFKQTtFQUNDLG9DRG5QcUI7QUMwUHRCOztBQUpBO0VBQ0MsYUFBQTtFQUNBLG1CQUFBO0VBQ0EsdUJBQUE7QUFPRDs7QUFMQTtFQUNDLFlBQUE7RUFDQSxlQUFBO0FBUUQ7O0FBTEE7RUFDQyxXQUFBO0VBQ0EsZUFBQTtBQVFEIiwiZmlsZSI6ImhvbWUucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiOnJvb3Qge1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNTA6IHJlZDtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4td2hpdGU6IHllbGxvdztcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZTogIzBkMTUyZTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW46ICMwMDkwOGQ7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWJsYWNrOiAjMDAwMDAwO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ncmV5LWJhY2tncm91bmQ6ICNjOGQzZGE7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWdyZXk6ICM5MmEyYWM7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0b25lLWdyZXk6ICNmYWZhZmE7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWVycm9yOiAjZmMxMDU1O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXk6ICM0MTQxNDE7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWZpYnJhbnQtZ3JlZW46ICMwMGJhYjY7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXdhcm5pbmc6ICNmZmQwNDg7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuLWJhY2tncm91bmQ6ICNlNmYyZjI7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS00MDA6ICM3YTdhN2E7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS0xMDA6ICNlZmYzZjU7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy1lcnJvcjogI2JhMGMzZjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yLWJhY2tncm91bmQ6ICNmZmVmZjQ7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy13YXJuaW5nOiAjY2JhMTI3O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtd2FybmluZy1iYWNrZ3JvdW5kOiAjZmZmOGU2O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlLTEwMDogI2RmZWZmMjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tZXJyb3ItcmVkLTcwMDogI2Y2MjQ1OTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZS01MDA6ICMwMDYxOTI7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWJsdWUtNDAwOiAjNzljZGVjO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1yZWQtNTAwOiAjZmY2NTkyO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zZWNvbmRhcnktYmx1ZS0zMDA6ICMxM2EwZDM7XHJcblxyXG5cdC0tbHVtaS13aGl0ZS1jb2xvcjogI2ZmZmZmZjtcclxuXHQtLWx1bWktcHJpbWFyeS15ZWxsb3ctY29sb3I6ICNmYWI2MDA7XHJcbn1cclxuJGNvbG9yLW5leHRnZW4tYmx1ZTogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlKTtcclxuJGNvbG9yLW5leHRnZW4tZ3JlZW46IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4pO1xyXG4kY29sb3ItbmV4dGdlbi13aGl0ZTogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi13aGl0ZSk7XHJcbiRjb2xvci1uZXh0Z2VuLWJsYWNrOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWJsYWNrKTtcclxuJGNvbG9yLW5leHRnZW4tZ3JleS1iYWNrZ3JvdW5kOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZXktYmFja2dyb3VuZCk7XHJcbiRjb2xvci1uZXh0Z2VuLWdyZXk6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JleSk7XHJcbiRjb2xvci1uZXh0Z2VuLXN0b25lLWdyZXk6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tc3RvbmUtZ3JleSk7XHJcbiRjb2xvci1uZXh0Z2VuLWVycm9yOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWVycm9yKTtcclxuJGNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5OiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleSk7XHJcbiRjb2xvci1uZXh0Z2VuLWZpYnJhbnQtZ3JlZW46IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZmlicmFudC1ncmVlbik7XHJcbiRjb2xvci1uZXh0Z2VuLXdhcm5pbmc6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4td2FybmluZyk7XHJcbiRjb2xvci1uZXh0Z2VuLWdyZWVuLWJhY2tncm91bmQ6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4tYmFja2dyb3VuZCk7XHJcbiRjb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS01MDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNTApO1xyXG4kY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNDAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS00MDApO1xyXG4kY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktMTAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS0xMDApO1xyXG4kY29sb3ItbmV4dGdlbi1zdGF0dXMtZXJyb3I6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yKTtcclxuJGNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yLWJhY2tncm91bmQ6IHZhcihcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yLWJhY2tncm91bmRcclxuKTtcclxuJGNvbG9yLW5leHRnZW4tc3RhdHVzLXdhcm5pbmc6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLXdhcm5pbmcpO1xyXG4kY29sb3ItbmV4dGdlbi1zdGF0dXMtd2FybmluZy1iYWNrZ3JvdW5kOiB2YXIoXHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy13YXJuaW5nLWJhY2tncm91bmRcclxuKTtcclxuJGNvbG9yLW5leHRnZW4tYmx1ZS0xMDA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZS0xMDApO1xyXG4kY29sb3ItbmV4dGdlbi1lcnJvci1yZWQtNzAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWVycm9yLXJlZC03MDApO1xyXG4kY29sb3ItbmV4dGdlbi1ibHVlLTUwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlLTUwMCk7XHJcbiRjb2xvci1uZXh0Z2VuLWJsdWUtNDAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWJsdWUtNDAwKTtcclxuJGNvbG9yLW5leHRnZW4tcmVkLTUwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1yZWQtNTAwKTtcclxuJGNvbG9yLW5leHRnZW4tc2Vjb25kYXJ5LWJsdWUtMzAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXNlY29uZGFyeS1ibHVlLTMwMCk7XHJcblxyXG4uaW9uLWNvbG9yLWdyZWVuIHtcclxuXHQtLWlvbi1jb2xvci1iYXNlOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuKTtcclxuXHQtLWlvbi1jb2xvci1iYXNlLXJnYjogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbik7XHJcblx0LS1pb24tY29sb3ItY29udHJhc3Q6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4td2hpdGUpO1xyXG5cdC0taW9uLWNvbG9yLWNvbnRyYXN0LXJnYjogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbik7XHJcblx0LS1pb24tY29sb3Itc2hhZGU6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4pO1xyXG5cdC0taW9uLWNvbG9yLXRpbnQ6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4pO1xyXG59XHJcbiIsIkBpbXBvcnQgXCIuLi8uLi8uLi9jb2xvci5zY3NzXCI7XHJcblxyXG4uaG9tZS1wYWdlLWNvbnRhaW5lciB7XHJcblx0Zm9udC1zdHlsZTogbm9ybWFsO1xyXG5cdGZvbnQtc2l6ZTogMTdweDtcclxuXHRsaW5lLWhlaWdodDogMjFweDtcclxufVxyXG5cclxuLm5vdGlmaWNhdGlvbnMtcHJvZmlsZSB7XHJcblx0d2lkdGg6IDIwcHg7XHJcblx0aGVpZ2h0OiAyMHB4O1xyXG5cdGJhY2tncm91bmQtY29sb3I6ICNmNjI0NTk7XHJcblx0Y29sb3I6ICNmZmZmO1xyXG5cdHBhZGRpbmctdG9wOiAzcHg7XHJcbn1cclxuXHJcbi5wcm9maWxlLWxpc3QtbWVudSB7XHJcblx0LS13aWR0aDogMTAwJTtcclxufVxyXG5cclxuLmJ1dHRvbi1wb2xpY3kge1xyXG5cdGhlaWdodDogMzBweDtcclxuXHQtLWJvcmRlci1yYWRpdXM6IDIwcHg7XHJcblx0LS1wYWRkaW5nLXRvcDogMnB4O1xyXG5cclxuXHQucG9saWN5LXRleHQge1xyXG5cdFx0cGFkZGluZy1sZWZ0OiA3cHg7XHJcblx0XHRwYWRkaW5nLXJpZ2h0OiAxMHB4O1xyXG5cdH1cclxufVxyXG5cclxuLmV4cGlyZWQge1xyXG5cdC0tYmFja2dyb3VuZDogI2ZmZWZmNDtcclxuXHQtLWJhY2tncm91bmQtYWN0aXZhdGVkOiAjZmZlZmY0O1xyXG5cclxuXHQuaWNvbi1wb2xpY3kge1xyXG5cdFx0Y29sb3I6ICNmZjY1OTI7XHJcblx0fVxyXG59XHJcblxyXG4uYWN0aXZlIHtcclxuXHQtLWJhY2tncm91bmQ6ICNlNmYyZjI7XHJcblx0LS1iYWNrZ3JvdW5kLWFjdGl2YXRlZDogI2U2ZjJmMjtcclxuXHJcblx0Lmljb24tcG9saWN5IHtcclxuXHRcdGNvbG9yOiAjMDBiYWI2O1xyXG5cdH1cclxufVxyXG5cclxuLkVtYWlsLXRleHQge1xyXG5cdG1hcmdpbjogMDtcclxuXHRwYWRkaW5nLXRvcDogM3B4O1xyXG5cdHBhZGRpbmctYm90dG9tOiAxNXB4O1xyXG59XHJcblxyXG46aG9zdCA6Om5nLWRlZXAuY2xvc2UtaWNvbiB7XHJcblx0cG9zaXRpb246IGFic29sdXRlO1xyXG5cdHRvcDogNjBweDtcclxuXHRyaWdodDogMjVweDtcclxuXHRmb250LXNpemU6IDI3cHg7XHJcblx0Y29sb3I6ICM5MmEyYWM7XHJcblx0ei1pbmRleDogNTtcclxuXHR3aWR0aDogMjBweDtcclxuXHRoZWlnaHQ6IDIwcHg7XHJcbn1cclxuXHJcbi5wcm9maWxlLWltYWdlLW1lbnUge1xyXG5cdG1hcmdpbi10b3A6IDg2cHg7XHJcblx0bWFyZ2luLWJvdHRvbTogMTVweDtcclxuXHR0ZXh0LWFsaWduOiBjZW50ZXI7XHJcblxyXG5cdC5wcm9maWxlLWltYWdlIHtcclxuXHRcdHdpZHRoOiA4NXB4O1xyXG5cdFx0aGVpZ2h0OiA4NXB4O1xyXG5cdFx0Ym9yZGVyLXJhZGl1czogNTAlO1xyXG5cdFx0b2JqZWN0LWZpdDogY292ZXI7XHJcblx0fVxyXG5cclxuXHQuaWNvbi1hdmF0YSB7XHJcblx0XHR3aWR0aDogOTZweDtcclxuXHRcdGhlaWdodDogOTZweDtcclxuXHRcdGJvcmRlci1yYWRpdXM6IDUwJTtcclxuXHRcdG9iamVjdC1maXQ6IGNvdmVyO1xyXG5cdH1cclxufVxyXG5cclxuLmhvbWUtdG9vbGJhciB7XHJcblx0cGFkZGluZzogMTVweCAyNHB4O1xyXG5cdGNvbG9yOiAjNTk1OTU5O1xyXG5cdGRpc3BsYXk6IGZsZXg7XHJcblxyXG5cdC5zdGFydCB7XHJcblx0XHRkaXNwbGF5OiBmbGV4O1xyXG5cdFx0YWxpZ24taXRlbXM6IGNlbnRlcjtcclxuXHRcdGZsZXg6IDE7XHJcblx0XHRmb250LWZhbWlseTogQWxsaWFuek5lb1cwNC1SZWd1bGFyLCBBcmlhbDtcclxuXHRcdGZvbnQtc3R5bGU6IG5vcm1hbDtcclxuXHRcdGZvbnQtd2VpZ2h0OiA2MDA7XHJcblx0XHRmb250LXNpemU6IDE3cHg7XHJcblx0XHRsaW5lLWhlaWdodDogMjFweDtcclxuXHRcdG1pbi1oZWlnaHQ6IDQwcHg7XHJcblxyXG5cdFx0LndlbGNvbWUtdGV4dCB7XHJcblx0XHRcdG1hcmdpbi1sZWZ0OiAxMHB4O1xyXG5cdFx0fVxyXG5cdH1cclxuXHJcblx0LmVuZCB7XHJcblx0XHRkaXNwbGF5OiBmbGV4O1xyXG5cdFx0anVzdGlmeS1jb250ZW50OiBmbGV4LWVuZDtcclxuXHRcdGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcblx0XHRmbGV4OiAxO1xyXG5cdFx0ZmxvYXQ6IHJpZ2h0O1xyXG5cclxuXHRcdC5wcm9maWxlLWltYWdlIHtcclxuXHRcdFx0bWFyZ2luLWxlZnQ6IDEwcHg7XHJcblx0XHRcdHdpZHRoOiA0MHB4O1xyXG5cdFx0XHRoZWlnaHQ6IDQwcHg7XHJcblx0XHRcdGJvcmRlci1yYWRpdXM6IDUwJTtcclxuXHRcdFx0b2JqZWN0LWZpdDogY292ZXI7XHJcblx0XHR9XHJcblxyXG5cdFx0Lm5vdGlmaWNhdGlvbi1pY29uOmhvdmVyIHtcclxuXHRcdFx0YmFja2dyb3VuZC1jb2xvcjogZGFya2VuKHdoaXRlLCAxMCk7XHJcblx0XHR9XHJcblx0fVxyXG59XHJcblxyXG4jbWFpbi1jb250ZW50IHtcclxuXHRiYWNrZ3JvdW5kOiAkY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNTA7XHJcblx0d2lkdGg6IDEwMCU7XHJcblxyXG5cdGlvbi1jb250ZW50IHtcclxuXHRcdC0tb3ZlcmZsb3c6IGhpZGRlbjtcclxuXHRcdGhlaWdodDogY2FsYygxMDAlIC0gNzBweCk7XHJcblx0fVxyXG5cclxuXHRpb24tY29udGVudC5pb3Mge1xyXG5cdFx0aGVpZ2h0OiBjYWxjKDEwMCUgLSA4MHB4KTtcclxuXHR9XHJcblxyXG5cdGlvbi10aXRsZSB7XHJcblx0XHRiYWNrZ3JvdW5kLWNvbG9yOiAkY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNTA7XHJcblx0fVxyXG59XHJcblxyXG4ucm91dGVyLXdyYXBwZXIge1xyXG5cdGhlaWdodDogY2FsYygxMDAlIC0gMTIwcHgpO1xyXG59XHJcblxyXG4ubWVudS1pdGVtLWNvbnRhaW5lciB7XHJcblx0Lm1lbnUtaXRlbSB7XHJcblx0XHRkaXNwbGF5OiBmbGV4O1xyXG5cdFx0bWFyZ2luOiBhdXRvO1xyXG5cdFx0d2lkdGg6IDkwJTtcclxuXHRcdGhlaWdodDogNjBweDtcclxuXHRcdHBhZGRpbmc6IDE1cHg7XHJcblx0XHRhbGlnbi1pdGVtczogY2VudGVyO1xyXG5cdFx0anVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcblxyXG5cdFx0LnRpdGxlIHtcclxuXHRcdFx0ZGlzcGxheTogZmxleDtcclxuXHRcdFx0YWxpZ24taXRlbXM6IGNlbnRlcjtcclxuXHRcdFx0Zm9udC1zaXplOiAxOHB4O1xyXG5cdFx0XHRmb250LXdlaWdodDogNDAwO1xyXG5cdFx0XHRtYXJnaW4tbGVmdDogMTBweDtcclxuXHRcdFx0d2lkdGg6IDkwJTtcclxuXHRcdH1cclxuXHJcblx0XHQmLm1lbnUtaXRlbTpmaXJzdC1jaGlsZCB7XHJcblx0XHRcdC8vIGJvcmRlci10b3A6IDFweCBzb2xpZCAjZTllOWU5O1xyXG5cdFx0fVxyXG5cclxuXHRcdCY6aG92ZXIge1xyXG5cdFx0XHRiYWNrZ3JvdW5kOiBkYXJrZW4od2hpdGUsIDEwKTtcclxuXHRcdH1cclxuXHJcblx0XHQubWVudS1pY29uIHtcclxuXHRcdFx0ZGlzcGxheTogZmxleDtcclxuXHRcdFx0YWxpZ24taXRlbXM6IGNlbnRlcjtcclxuXHRcdFx0Y29sb3I6ICNjNGM0YzQ7XHJcblx0XHR9XHJcblx0fVxyXG59XHJcblxyXG4ubG9nLW91dCB7XHJcblx0cG9zaXRpb246IGFic29sdXRlO1xyXG5cdGhlaWdodDogNjBweDtcclxuXHRwYWRkaW5nOiAxNXB4O1xyXG5cclxuXHRsZWZ0OiA1JTtcclxuXHRib3R0b206IDQlO1xyXG5cdHdpZHRoOiA5MCU7XHJcblx0Zm9udC1mYW1pbHk6IEFsbGlhbnpOZW9XMDQtUmVndWxhciwgQXJpYWw7XHJcblx0Zm9udC1zdHlsZTogbm9ybWFsO1xyXG5cdGZvbnQtd2VpZ2h0OiA2MDA7XHJcblx0Zm9udC1zaXplOiAxOHB4O1xyXG5cdGxpbmUtaGVpZ2h0OiAxODAlO1xyXG5cdGNvbG9yOiAjMzIzMjMyO1xyXG5cclxuXHQmOmhvdmVyIHtcclxuXHRcdGJhY2tncm91bmQtY29sb3I6IGRhcmtlbih3aGl0ZSwgMTApO1xyXG5cdH1cclxufVxyXG5cclxuLmxvZy1vdXQtaWNvbiB7XHJcblx0Y29sb3I6ICNjOGQzZGEgIWltcG9ydGFudDtcclxufVxyXG5cclxuQG1lZGlhIG9ubHkgc2NyZWVuIGFuZCAobWluLXdpZHRoOiA5OTJweCkge1xyXG5cdC5jbG9zZS1pY29uIHtcclxuXHRcdGRpc3BsYXk6IG5vbmU7XHJcblx0fVxyXG59XHJcblxyXG5AbWVkaWEgb25seSBzY3JlZW4gYW5kIChtYXgtaGVpZ2h0OiA2NTBweCkge1xyXG5cdC5jbG9zZS1pY29uIHtcclxuXHRcdGRpc3BsYXk6IG5vbmU7XHJcblx0fVxyXG5cclxuXHQubG9nLW91dCB7XHJcblx0XHRwb3NpdGlvbjogcmVsYXRpdmU7XHJcblx0fVxyXG59XHJcblxyXG4udGFiLWNvbG9yIHtcclxuXHRjb2xvcjogJGNvbG9yLW5leHRnZW4tZ3JleTtcclxufVxyXG5cclxuLnRhYi1zaXplIHtcclxuXHRmb250LXNpemU6IDE4cHggIWltcG9ydGFudDtcclxufVxyXG5cclxuOmhvc3Qge1xyXG5cdC50YWItc2VsZWN0ZWQge1xyXG5cdFx0LnRhYi1jb2xvciB7XHJcblx0XHRcdGNvbG9yOiAkY29sb3ItbmV4dGdlbi1ncmVlbjtcclxuXHRcdH1cclxuXHJcblx0XHQudGFiLXNpemUge1xyXG5cdFx0XHRmb250LXNpemU6IDE4cHggIWltcG9ydGFudDtcclxuXHRcdH1cclxuXHR9XHJcbn1cclxuXHJcbi5ub3RpZmljYXRpb24ge1xyXG5cdGhlaWdodDogMzZweDtcclxuXHR3aWR0aDogMzZweDtcclxuXHRiYWNrZ3JvdW5kLWNvbG9yOiAkY29sb3ItbmV4dGdlbi1zdG9uZS1ncmV5O1xyXG5cdGJvcmRlci1yYWRpdXM6IDUwJTtcclxuXHRqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuXHRkaXNwbGF5OiBmbGV4O1xyXG5cdGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcblx0bWFyZ2luLWxlZnQ6IDEwcHg7XHJcblx0aW9uLWljb24ge1xyXG5cdFx0Zm9udC1zaXplOiAyNHB4ICFpbXBvcnRhbnQ7XHJcblx0fVxyXG59XHJcblxyXG4uZm9vdGVyIHtcclxuXHRib3gtc2hhZG93OiAwcHggLTRweCA2cHggcmdiYSgwLCAwLCAwLCAwLjA1KTtcclxuXHRib3JkZXItcmFkaXVzOiA4cHg7XHJcblx0Ym9yZGVyOiBub25lO1xyXG5cdGhlaWdodDogNzBweDtcclxufVxyXG5cclxuaW9uLXRhYi1idXR0b24ge1xyXG5cdGJhY2tncm91bmQtY29sb3I6ICRjb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS01MCAhaW1wb3J0YW50O1xyXG5cdG1heC13aWR0aDogdW5zZXQgIWltcG9ydGFudDtcclxuXHRqdXN0aWZ5LWNvbnRlbnQ6IGZsZXgtc3RhcnQgIWltcG9ydGFudDtcclxuXHRwYWRkaW5nLXRvcDogMTBweDtcclxufVxyXG5cclxuLm5lZWQtaGVscC10ZXh0IHtcclxuXHRjb2xvcjogJGNvbG9yLW5leHRnZW4tZ3JlZW47XHJcbn1cclxuXHJcbi52ZXJzaW9uLWFwcCB7XHJcblx0ZGlzcGxheTogZmxleDtcclxuXHRhbGlnbi1pdGVtczogY2VudGVyO1xyXG5cdGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG59XHJcbi5pY29uLWxhbmd1YWdlIHtcclxuXHRoZWlnaHQ6IDEzcHg7XHJcblx0bWFyZ2luLXRvcDogOHB4O1xyXG59XHJcblxyXG4uaGVhcnQtaW1hZ2Uge1xyXG5cdHdpZHRoOiAxMDAlO1xyXG5cdG1heC13aWR0aDogNTBweDtcclxufVxyXG4iXX0= */";

/***/ }),

/***/ 33745:
/*!******************************************************************************************!*\
  !*** ./src/app/pages/home/inquiries-history/inquiries-history.component.scss?ngResource ***!
  \******************************************************************************************/
/***/ ((module) => {

module.exports = ":root {\n  --nc-color-nextgen-neutral-grey-50: red;\n  --nc-color-nextgen-white: yellow;\n  --nc-color-nextgen-blue: #0d152e;\n  --nc-color-nextgen-green: #00908d;\n  --nc-color-nextgen-black: #000000;\n  --nc-color-nextgen-grey-background: #c8d3da;\n  --nc-color-nextgen-grey: #92a2ac;\n  --nc-color-nextgen-stone-grey: #fafafa;\n  --nc-color-nextgen-error: #fc1055;\n  --nc-color-nextgen-neutral-grey: #414141;\n  --nc-color-nextgen-fibrant-green: #00bab6;\n  --nc-color-nextgen-warning: #ffd048;\n  --nc-color-nextgen-green-background: #e6f2f2;\n  --nc-color-nextgen-neutral-grey-400: #7a7a7a;\n  --nc-color-nextgen-neutral-grey-100: #eff3f5;\n  --nc-color-nextgen-status-error: #ba0c3f;\n  --nc-color-nextgen-status-error-background: #ffeff4;\n  --nc-color-nextgen-status-warning: #cba127;\n  --nc-color-nextgen-status-warning-background: #fff8e6;\n  --nc-color-nextgen-blue-100: #dfeff2;\n  --nc-color-nextgen-error-red-700: #f62459;\n  --nc-color-nextgen-blue-500: #006192;\n  --nc-color-nextgen-blue-400: #79cdec;\n  --nc-color-nextgen-red-500: #ff6592;\n  --nc-color-nextgen-secondary-blue-300: #13a0d3;\n  --lumi-white-color: #ffffff;\n  --lumi-primary-yellow-color: #fab600;\n}\n\n.ion-color-green {\n  --ion-color-base: var(--nc-color-nextgen-green);\n  --ion-color-base-rgb: var(--nc-color-nextgen-green);\n  --ion-color-contrast: var(--nc-color-nextgen-white);\n  --ion-color-contrast-rgb: var(--nc-color-nextgen-green);\n  --ion-color-shade: var(--nc-color-nextgen-green);\n  --ion-color-tint: var(--nc-color-nextgen-green);\n}\n\n.history-container {\n  padding: 0 5%;\n  padding-bottom: 9vh;\n  min-height: 100%;\n  padding-bottom: 9vh;\n  max-height: max-content;\n}\n\n.home-care-page {\n  background-color: var(--nc-color-nextgen-neutral-grey-50);\n  min-height: 100%;\n  --background: $color-nextgen-neutral-grey-50;\n}\n\n.search-box {\n  margin: 2rem 0 2rem 0;\n}\n\n.claim-title {\n  margin: 5% 0;\n}\n\n.claim-title span {\n  color: var(--nc-color-nextgen-blue) !important;\n}\n\n.create-new {\n  justify-content: center;\n  align-items: center;\n  display: flex;\n  position: fixed;\n  bottom: 4vh;\n  right: 0;\n  left: 0;\n}\n\n.plus-icon {\n  padding-right: 12px;\n  color: var(--nc-color-nextgen-white);\n}\n\n.phone-center {\n  background-color: var(--nc-color-nextgen-green) !important;\n  color: #000000;\n  padding: unset !important;\n  height: 45px !important;\n  width: 45px !important;\n  border-radius: 50% !important;\n  position: fixed;\n  right: 18px;\n  bottom: 90px;\n}\n\n.content {\n  background: var(--nc-color-nextgen-white);\n  box-shadow: 0px 1px 2px rgba(0, 0, 0, 0.1);\n  border-radius: 8px;\n  padding-left: 1rem;\n  padding-right: 1rem;\n  padding-top: 1rem;\n  margin-bottom: 0.5rem;\n  align-items: center;\n}\n\n.content .date {\n  color: var(--nc-color-nextgen-black);\n  padding-top: 1rem;\n}\n\n.content .name {\n  color: var(--nc-color-nextgen-neutral-grey-400);\n  padding-top: 1rem;\n}\n\n.content .btn-result {\n  padding-top: 1rem;\n  padding-bottom: 1.5rem;\n}\n\n.content .btn-result .text-btn {\n  color: var(--nc-color-nextgen-green);\n}\n\n.status-text {\n  position: absolute;\n  right: 1px;\n  color: var(--nc-color-nextgen-status-warning);\n  background: #EFF3F5;\n  border-radius: 0.125em;\n  padding: 0.25em 0.5em;\n  width: -moz-fit-content;\n  width: fit-content;\n}\n\n.name-call {\n  padding-top: 1rem;\n  padding-bottom: 1rem;\n}\n\n.uil {\n  color: white !important;\n  font-size: 20px;\n}\n\n.uil-phone:before {\n  content: \"\\e9e7\";\n  padding: 0.75rem;\n}\n\n.claim-title {\n  margin: 5% 0;\n  color: var(--nc-color-nextgen-blue) !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFxjb2xvci5zY3NzIiwiaW5xdWlyaWVzLWhpc3RvcnkuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDQyx1Q0FBQTtFQUNBLGdDQUFBO0VBQ0EsZ0NBQUE7RUFDQSxpQ0FBQTtFQUNBLGlDQUFBO0VBQ0EsMkNBQUE7RUFDQSxnQ0FBQTtFQUNBLHNDQUFBO0VBQ0EsaUNBQUE7RUFDQSx3Q0FBQTtFQUNBLHlDQUFBO0VBQ0EsbUNBQUE7RUFDQSw0Q0FBQTtFQUNBLDRDQUFBO0VBQ0EsNENBQUE7RUFDQSx3Q0FBQTtFQUNBLG1EQUFBO0VBQ0EsMENBQUE7RUFDQSxxREFBQTtFQUNBLG9DQUFBO0VBQ0EseUNBQUE7RUFDQSxvQ0FBQTtFQUNBLG9DQUFBO0VBQ0EsbUNBQUE7RUFDQSw4Q0FBQTtFQUVBLDJCQUFBO0VBQ0Esb0NBQUE7QUNBRDs7QURnQ0E7RUFDQywrQ0FBQTtFQUNBLG1EQUFBO0VBQ0EsbURBQUE7RUFDQSx1REFBQTtFQUNBLGdEQUFBO0VBQ0EsK0NBQUE7QUM3QkQ7O0FBbENBO0VBQ0ksYUFBQTtFQUNBLG1CQUFBO0VBQ0EsZ0JBQUE7RUFDQSxtQkFBQTtFQUNBLHVCQUFBO0FBcUNKOztBQWpDQTtFQUNJLHlERDZCNEI7RUM1QjVCLGdCQUFBO0VBQ0EsNENBQUE7QUFvQ0o7O0FBL0JBO0VBQ0kscUJBQUE7QUFrQ0o7O0FBOUJBO0VBQ0UsWUFBQTtBQWlDRjs7QUFoQ0U7RUFDRSw4Q0FBQTtBQWtDSjs7QUE5QkE7RUFDRSx1QkFBQTtFQUNBLG1CQUFBO0VBQ0EsYUFBQTtFQUNBLGVBQUE7RUFDQSxXQUFBO0VBQ0EsUUFBQTtFQUNBLE9BQUE7QUFpQ0Y7O0FBOUJBO0VBQ0UsbUJBQUE7RUFDQSxvQ0Rab0I7QUM2Q3RCOztBQTlCQTtFQUNJLDBEQUFBO0VBQ0EsY0FBQTtFQUNBLHlCQUFBO0VBQ0EsdUJBQUE7RUFDQSxzQkFBQTtFQUNBLDZCQUFBO0VBQ0EsZUFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0FBaUNKOztBQTdCQTtFQUNJLHlDRDdCa0I7RUM4QmxCLDBDQUFBO0VBQ0Esa0JBQUE7RUFDQSxrQkFBQTtFQUNBLG1CQUFBO0VBQ0EsaUJBQUE7RUFDQSxxQkFBQTtFQUNBLG1CQUFBO0FBZ0NKOztBQTlCSTtFQUNJLG9DRHRDYztFQ3VDZCxpQkFBQTtBQWdDUjs7QUE3Qkk7RUFDSSwrQ0RqQ3lCO0VDa0N6QixpQkFBQTtBQStCUjs7QUE1Qkk7RUFDSSxpQkFBQTtFQUNBLHNCQUFBO0FBOEJSOztBQTVCUTtFQUNJLG9DRHREVTtBQ29GdEI7O0FBekJBO0VBQ0ksa0JBQUE7RUFDQSxVQUFBO0VBQ0EsNkNENUMyQjtFQzZDM0IsbUJBQUE7RUFDQSxzQkFBQTtFQUNBLHFCQUFBO0VBQ0EsdUJBQUE7RUFBQSxrQkFBQTtBQTRCSjs7QUF4QkE7RUFDSSxpQkFBQTtFQUNBLG9CQUFBO0FBMkJKOztBQXhCQTtFQUNJLHVCQUFBO0VBQ0EsZUFBQTtBQTJCSjs7QUF4QkE7RUFDSSxnQkFBQTtFQUNBLGdCQUFBO0FBMkJKOztBQXZCQTtFQUNJLFlBQUE7RUFDQSw4Q0FBQTtBQTBCSiIsImZpbGUiOiJpbnF1aXJpZXMtaGlzdG9yeS5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIjpyb290IHtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTUwOiByZWQ7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXdoaXRlOiB5ZWxsb3c7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWJsdWU6ICMwZDE1MmU7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuOiAjMDA5MDhkO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ibGFjazogIzAwMDAwMDtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tZ3JleS1iYWNrZ3JvdW5kOiAjYzhkM2RhO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ncmV5OiAjOTJhMmFjO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zdG9uZS1ncmV5OiAjZmFmYWZhO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1lcnJvcjogI2ZjMTA1NTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5OiAjNDE0MTQxO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1maWJyYW50LWdyZWVuOiAjMDBiYWI2O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi13YXJuaW5nOiAjZmZkMDQ4O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbi1iYWNrZ3JvdW5kOiAjZTZmMmYyO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNDAwOiAjN2E3YTdhO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktMTAwOiAjZWZmM2Y1O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtZXJyb3I6ICNiYTBjM2Y7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy1lcnJvci1iYWNrZ3JvdW5kOiAjZmZlZmY0O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtd2FybmluZzogI2NiYTEyNztcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLXdhcm5pbmctYmFja2dyb3VuZDogI2ZmZjhlNjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZS0xMDA6ICNkZmVmZjI7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWVycm9yLXJlZC03MDA6ICNmNjI0NTk7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWJsdWUtNTAwOiAjMDA2MTkyO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlLTQwMDogIzc5Y2RlYztcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tcmVkLTUwMDogI2ZmNjU5MjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc2Vjb25kYXJ5LWJsdWUtMzAwOiAjMTNhMGQzO1xyXG5cclxuXHQtLWx1bWktd2hpdGUtY29sb3I6ICNmZmZmZmY7XHJcblx0LS1sdW1pLXByaW1hcnkteWVsbG93LWNvbG9yOiAjZmFiNjAwO1xyXG59XHJcbiRjb2xvci1uZXh0Z2VuLWJsdWU6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZSk7XHJcbiRjb2xvci1uZXh0Z2VuLWdyZWVuOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuKTtcclxuJGNvbG9yLW5leHRnZW4td2hpdGU6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4td2hpdGUpO1xyXG4kY29sb3ItbmV4dGdlbi1ibGFjazogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ibGFjayk7XHJcbiRjb2xvci1uZXh0Z2VuLWdyZXktYmFja2dyb3VuZDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmV5LWJhY2tncm91bmQpO1xyXG4kY29sb3ItbmV4dGdlbi1ncmV5OiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZXkpO1xyXG4kY29sb3ItbmV4dGdlbi1zdG9uZS1ncmV5OiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXN0b25lLWdyZXkpO1xyXG4kY29sb3ItbmV4dGdlbi1lcnJvcjogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1lcnJvcik7XHJcbiRjb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleTogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXkpO1xyXG4kY29sb3ItbmV4dGdlbi1maWJyYW50LWdyZWVuOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWZpYnJhbnQtZ3JlZW4pO1xyXG4kY29sb3ItbmV4dGdlbi13YXJuaW5nOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXdhcm5pbmcpO1xyXG4kY29sb3ItbmV4dGdlbi1ncmVlbi1iYWNrZ3JvdW5kOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuLWJhY2tncm91bmQpO1xyXG4kY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNTA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTUwKTtcclxuJGNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTQwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNDAwKTtcclxuJGNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTEwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktMTAwKTtcclxuJGNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy1lcnJvcik7XHJcbiRjb2xvci1uZXh0Z2VuLXN0YXR1cy1lcnJvci1iYWNrZ3JvdW5kOiB2YXIoXHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy1lcnJvci1iYWNrZ3JvdW5kXHJcbik7XHJcbiRjb2xvci1uZXh0Z2VuLXN0YXR1cy13YXJuaW5nOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy13YXJuaW5nKTtcclxuJGNvbG9yLW5leHRnZW4tc3RhdHVzLXdhcm5pbmctYmFja2dyb3VuZDogdmFyKFxyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtd2FybmluZy1iYWNrZ3JvdW5kXHJcbik7XHJcbiRjb2xvci1uZXh0Z2VuLWJsdWUtMTAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWJsdWUtMTAwKTtcclxuJGNvbG9yLW5leHRnZW4tZXJyb3ItcmVkLTcwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1lcnJvci1yZWQtNzAwKTtcclxuJGNvbG9yLW5leHRnZW4tYmx1ZS01MDA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZS01MDApO1xyXG4kY29sb3ItbmV4dGdlbi1ibHVlLTQwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlLTQwMCk7XHJcbiRjb2xvci1uZXh0Z2VuLXJlZC01MDA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tcmVkLTUwMCk7XHJcbiRjb2xvci1uZXh0Z2VuLXNlY29uZGFyeS1ibHVlLTMwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1zZWNvbmRhcnktYmx1ZS0zMDApO1xyXG5cclxuLmlvbi1jb2xvci1ncmVlbiB7XHJcblx0LS1pb24tY29sb3ItYmFzZTogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbik7XHJcblx0LS1pb24tY29sb3ItYmFzZS1yZ2I6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4pO1xyXG5cdC0taW9uLWNvbG9yLWNvbnRyYXN0OiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXdoaXRlKTtcclxuXHQtLWlvbi1jb2xvci1jb250cmFzdC1yZ2I6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4pO1xyXG5cdC0taW9uLWNvbG9yLXNoYWRlOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuKTtcclxuXHQtLWlvbi1jb2xvci10aW50OiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuKTtcclxufVxyXG4iLCJAaW1wb3J0ICcuLi8uLi8uLi8uLi9jb2xvci5zY3NzJztcclxuXHJcblxyXG4uaGlzdG9yeS1jb250YWluZXJ7XHJcbiAgICBwYWRkaW5nOiAwIDUlO1xyXG4gICAgcGFkZGluZy1ib3R0b206IDl2aDtcclxuICAgIG1pbi1oZWlnaHQ6IDEwMCU7XHJcbiAgICBwYWRkaW5nLWJvdHRvbTogOXZoO1xyXG4gICAgbWF4LWhlaWdodDogbWF4LWNvbnRlbnQ7XHJcbn1cclxuXHJcblxyXG4uaG9tZS1jYXJlLXBhZ2Uge1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogJGNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTUwO1xyXG4gICAgbWluLWhlaWdodDogMTAwJTtcclxuICAgIC0tYmFja2dyb3VuZDogJGNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTUwO1xyXG59XHJcblxyXG5cclxuXHJcbi5zZWFyY2gtYm94e1xyXG4gICAgbWFyZ2luOiAycmVtIDAgMnJlbSAwO1xyXG59XHJcblxyXG5cclxuLmNsYWltLXRpdGxlIHtcclxuICBtYXJnaW46IDUlIDA7XHJcbiAgc3BhbntcclxuICAgIGNvbG9yOiAkY29sb3ItbmV4dGdlbi1ibHVlICFpbXBvcnRhbnQ7XHJcbiAgfVxyXG59XHJcblxyXG4uY3JlYXRlLW5ldyB7XHJcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIHBvc2l0aW9uOiBmaXhlZDtcclxuICBib3R0b206IDR2aDtcclxuICByaWdodDogMDtcclxuICBsZWZ0OiAwO1xyXG59XHJcblxyXG4ucGx1cy1pY29uIHtcclxuICBwYWRkaW5nLXJpZ2h0OiAxMnB4O1xyXG4gIGNvbG9yOiAkY29sb3ItbmV4dGdlbi13aGl0ZTtcclxufVxyXG5cclxuLnBob25lLWNlbnRlcntcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICRjb2xvci1uZXh0Z2VuLWdyZWVuICFpbXBvcnRhbnQ7XHJcbiAgICBjb2xvcjogIzAwMDAwMDtcclxuICAgIHBhZGRpbmc6IHVuc2V0ICFpbXBvcnRhbnQ7XHJcbiAgICBoZWlnaHQ6IDQ1cHggIWltcG9ydGFudDtcclxuICAgIHdpZHRoOiA0NXB4ICFpbXBvcnRhbnQ7XHJcbiAgICBib3JkZXItcmFkaXVzOiA1MCUgIWltcG9ydGFudDtcclxuICAgIHBvc2l0aW9uOiBmaXhlZDtcclxuICAgIHJpZ2h0OiAxOHB4O1xyXG4gICAgYm90dG9tOiA5MHB4O1xyXG59XHJcblxyXG5cclxuLmNvbnRlbnQge1xyXG4gICAgYmFja2dyb3VuZDogJGNvbG9yLW5leHRnZW4td2hpdGU7XHJcbiAgICBib3gtc2hhZG93OiAwcHggMXB4IDJweCByZ2JhKDAsIDAsIDAsIDAuMSk7XHJcbiAgICBib3JkZXItcmFkaXVzOiA4cHg7XHJcbiAgICBwYWRkaW5nLWxlZnQ6IDFyZW07XHJcbiAgICBwYWRkaW5nLXJpZ2h0OiAxcmVtO1xyXG4gICAgcGFkZGluZy10b3A6IDFyZW07XHJcbiAgICBtYXJnaW4tYm90dG9tOiAwLjVyZW07XHJcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG5cclxuICAgIC5kYXRlIHtcclxuICAgICAgICBjb2xvcjogJGNvbG9yLW5leHRnZW4tYmxhY2s7XHJcbiAgICAgICAgcGFkZGluZy10b3A6IDFyZW07XHJcbiAgICB9XHJcblxyXG4gICAgLm5hbWUge1xyXG4gICAgICAgIGNvbG9yOiAkY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNDAwO1xyXG4gICAgICAgIHBhZGRpbmctdG9wOiAxcmVtO1xyXG4gICAgfVxyXG5cclxuICAgIC5idG4tcmVzdWx0IHtcclxuICAgICAgICBwYWRkaW5nLXRvcDogMXJlbTtcclxuICAgICAgICBwYWRkaW5nLWJvdHRvbTogMS41cmVtO1xyXG5cclxuICAgICAgICAudGV4dC1idG4ge1xyXG4gICAgICAgICAgICBjb2xvcjogJGNvbG9yLW5leHRnZW4tZ3JlZW47XHJcbiAgICAgICAgfVxyXG4gICAgfSAgXHJcbn1cclxuXHJcbi5zdGF0dXMtdGV4dHtcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIHJpZ2h0OiAxcHg7XHJcbiAgICBjb2xvcjogJGNvbG9yLW5leHRnZW4tc3RhdHVzLXdhcm5pbmc7XHJcbiAgICBiYWNrZ3JvdW5kOiAjRUZGM0Y1O1xyXG4gICAgYm9yZGVyLXJhZGl1czogMC4xMjVlbTtcclxuICAgIHBhZGRpbmc6IDAuMjVlbSAwLjVlbTtcclxuICAgIHdpZHRoOiBmaXQtY29udGVudDtcclxuXHJcbn1cclxuXHJcbi5uYW1lLWNhbGx7XHJcbiAgICBwYWRkaW5nLXRvcDogMXJlbTtcclxuICAgIHBhZGRpbmctYm90dG9tOiAxcmVtO1xyXG59XHJcblxyXG4udWlsIHtcclxuICAgIGNvbG9yOiB3aGl0ZSAhaW1wb3J0YW50O1xyXG4gICAgZm9udC1zaXplOiAyMHB4O1xyXG59XHJcblxyXG4udWlsLXBob25lOmJlZm9yZSB7XHJcbiAgICBjb250ZW50OiAnXFxlOWU3JztcclxuICAgIHBhZGRpbmc6IDAuNzVyZW07XHJcbn1cclxuXHJcblxyXG4uY2xhaW0tdGl0bGUge1xyXG4gICAgbWFyZ2luOiA1JSAwO1xyXG4gICAgY29sb3I6ICRjb2xvci1uZXh0Z2VuLWJsdWUgIWltcG9ydGFudDtcclxuXHJcbiAgfSJdfQ== */";

/***/ }),

/***/ 71798:
/*!*******************************************************************************!*\
  !*** ./src/app/pages/home/policy/benefits/benefits.component.scss?ngResource ***!
  \*******************************************************************************/
/***/ ((module) => {

module.exports = ":root {\n  --nc-color-nextgen-neutral-grey-50: red;\n  --nc-color-nextgen-white: yellow;\n  --nc-color-nextgen-blue: #0d152e;\n  --nc-color-nextgen-green: #00908d;\n  --nc-color-nextgen-black: #000000;\n  --nc-color-nextgen-grey-background: #c8d3da;\n  --nc-color-nextgen-grey: #92a2ac;\n  --nc-color-nextgen-stone-grey: #fafafa;\n  --nc-color-nextgen-error: #fc1055;\n  --nc-color-nextgen-neutral-grey: #414141;\n  --nc-color-nextgen-fibrant-green: #00bab6;\n  --nc-color-nextgen-warning: #ffd048;\n  --nc-color-nextgen-green-background: #e6f2f2;\n  --nc-color-nextgen-neutral-grey-400: #7a7a7a;\n  --nc-color-nextgen-neutral-grey-100: #eff3f5;\n  --nc-color-nextgen-status-error: #ba0c3f;\n  --nc-color-nextgen-status-error-background: #ffeff4;\n  --nc-color-nextgen-status-warning: #cba127;\n  --nc-color-nextgen-status-warning-background: #fff8e6;\n  --nc-color-nextgen-blue-100: #dfeff2;\n  --nc-color-nextgen-error-red-700: #f62459;\n  --nc-color-nextgen-blue-500: #006192;\n  --nc-color-nextgen-blue-400: #79cdec;\n  --nc-color-nextgen-red-500: #ff6592;\n  --nc-color-nextgen-secondary-blue-300: #13a0d3;\n  --lumi-white-color: #ffffff;\n  --lumi-primary-yellow-color: #fab600;\n}\n\n.ion-color-green {\n  --ion-color-base: var(--nc-color-nextgen-green);\n  --ion-color-base-rgb: var(--nc-color-nextgen-green);\n  --ion-color-contrast: var(--nc-color-nextgen-white);\n  --ion-color-contrast-rgb: var(--nc-color-nextgen-green);\n  --ion-color-shade: var(--nc-color-nextgen-green);\n  --ion-color-tint: var(--nc-color-nextgen-green);\n}\n\n.benefits-card {\n  text-align: center;\n  padding: 1rem;\n  box-shadow: 0px 1px 2px rgba(0, 0, 0, 0.1);\n  border-radius: 8px;\n  min-height: 165px;\n}\n\n.textSubHeader {\n  font-size: 14px !important;\n}\n\n.imageCard {\n  position: absolute;\n  padding: 1.25rem 1.1rem 1.25rem 1.1rem;\n}\n\n.backgroundImg {\n  padding: 0.2rem 0.2rem 0.4rem 0.2rem;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFwuLlxcY29sb3Iuc2NzcyIsImJlbmVmaXRzLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0MsdUNBQUE7RUFDQSxnQ0FBQTtFQUNBLGdDQUFBO0VBQ0EsaUNBQUE7RUFDQSxpQ0FBQTtFQUNBLDJDQUFBO0VBQ0EsZ0NBQUE7RUFDQSxzQ0FBQTtFQUNBLGlDQUFBO0VBQ0Esd0NBQUE7RUFDQSx5Q0FBQTtFQUNBLG1DQUFBO0VBQ0EsNENBQUE7RUFDQSw0Q0FBQTtFQUNBLDRDQUFBO0VBQ0Esd0NBQUE7RUFDQSxtREFBQTtFQUNBLDBDQUFBO0VBQ0EscURBQUE7RUFDQSxvQ0FBQTtFQUNBLHlDQUFBO0VBQ0Esb0NBQUE7RUFDQSxvQ0FBQTtFQUNBLG1DQUFBO0VBQ0EsOENBQUE7RUFFQSwyQkFBQTtFQUNBLG9DQUFBO0FDQUQ7O0FEZ0NBO0VBQ0MsK0NBQUE7RUFDQSxtREFBQTtFQUNBLG1EQUFBO0VBQ0EsdURBQUE7RUFDQSxnREFBQTtFQUNBLCtDQUFBO0FDN0JEOztBQXBDQTtFQUNJLGtCQUFBO0VBQ0EsYUFBQTtFQUNBLDBDQUFBO0VBQ0Esa0JBQUE7RUFDQSxpQkFBQTtBQXVDSjs7QUFwQ0E7RUFDSSwwQkFBQTtBQXVDSjs7QUFwQ0E7RUFDSSxrQkFBQTtFQUNBLHNDQUFBO0FBdUNKOztBQXBDQTtFQUNJLG9DQUFBO0FBdUNKIiwiZmlsZSI6ImJlbmVmaXRzLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiOnJvb3Qge1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNTA6IHJlZDtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4td2hpdGU6IHllbGxvdztcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZTogIzBkMTUyZTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW46ICMwMDkwOGQ7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWJsYWNrOiAjMDAwMDAwO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ncmV5LWJhY2tncm91bmQ6ICNjOGQzZGE7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWdyZXk6ICM5MmEyYWM7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0b25lLWdyZXk6ICNmYWZhZmE7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWVycm9yOiAjZmMxMDU1O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXk6ICM0MTQxNDE7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWZpYnJhbnQtZ3JlZW46ICMwMGJhYjY7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXdhcm5pbmc6ICNmZmQwNDg7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuLWJhY2tncm91bmQ6ICNlNmYyZjI7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS00MDA6ICM3YTdhN2E7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS0xMDA6ICNlZmYzZjU7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy1lcnJvcjogI2JhMGMzZjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yLWJhY2tncm91bmQ6ICNmZmVmZjQ7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy13YXJuaW5nOiAjY2JhMTI3O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtd2FybmluZy1iYWNrZ3JvdW5kOiAjZmZmOGU2O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlLTEwMDogI2RmZWZmMjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tZXJyb3ItcmVkLTcwMDogI2Y2MjQ1OTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZS01MDA6ICMwMDYxOTI7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWJsdWUtNDAwOiAjNzljZGVjO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1yZWQtNTAwOiAjZmY2NTkyO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zZWNvbmRhcnktYmx1ZS0zMDA6ICMxM2EwZDM7XHJcblxyXG5cdC0tbHVtaS13aGl0ZS1jb2xvcjogI2ZmZmZmZjtcclxuXHQtLWx1bWktcHJpbWFyeS15ZWxsb3ctY29sb3I6ICNmYWI2MDA7XHJcbn1cclxuJGNvbG9yLW5leHRnZW4tYmx1ZTogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlKTtcclxuJGNvbG9yLW5leHRnZW4tZ3JlZW46IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4pO1xyXG4kY29sb3ItbmV4dGdlbi13aGl0ZTogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi13aGl0ZSk7XHJcbiRjb2xvci1uZXh0Z2VuLWJsYWNrOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWJsYWNrKTtcclxuJGNvbG9yLW5leHRnZW4tZ3JleS1iYWNrZ3JvdW5kOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZXktYmFja2dyb3VuZCk7XHJcbiRjb2xvci1uZXh0Z2VuLWdyZXk6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JleSk7XHJcbiRjb2xvci1uZXh0Z2VuLXN0b25lLWdyZXk6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tc3RvbmUtZ3JleSk7XHJcbiRjb2xvci1uZXh0Z2VuLWVycm9yOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWVycm9yKTtcclxuJGNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5OiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleSk7XHJcbiRjb2xvci1uZXh0Z2VuLWZpYnJhbnQtZ3JlZW46IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZmlicmFudC1ncmVlbik7XHJcbiRjb2xvci1uZXh0Z2VuLXdhcm5pbmc6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4td2FybmluZyk7XHJcbiRjb2xvci1uZXh0Z2VuLWdyZWVuLWJhY2tncm91bmQ6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4tYmFja2dyb3VuZCk7XHJcbiRjb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS01MDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNTApO1xyXG4kY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNDAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS00MDApO1xyXG4kY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktMTAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS0xMDApO1xyXG4kY29sb3ItbmV4dGdlbi1zdGF0dXMtZXJyb3I6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yKTtcclxuJGNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yLWJhY2tncm91bmQ6IHZhcihcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yLWJhY2tncm91bmRcclxuKTtcclxuJGNvbG9yLW5leHRnZW4tc3RhdHVzLXdhcm5pbmc6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLXdhcm5pbmcpO1xyXG4kY29sb3ItbmV4dGdlbi1zdGF0dXMtd2FybmluZy1iYWNrZ3JvdW5kOiB2YXIoXHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy13YXJuaW5nLWJhY2tncm91bmRcclxuKTtcclxuJGNvbG9yLW5leHRnZW4tYmx1ZS0xMDA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZS0xMDApO1xyXG4kY29sb3ItbmV4dGdlbi1lcnJvci1yZWQtNzAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWVycm9yLXJlZC03MDApO1xyXG4kY29sb3ItbmV4dGdlbi1ibHVlLTUwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlLTUwMCk7XHJcbiRjb2xvci1uZXh0Z2VuLWJsdWUtNDAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWJsdWUtNDAwKTtcclxuJGNvbG9yLW5leHRnZW4tcmVkLTUwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1yZWQtNTAwKTtcclxuJGNvbG9yLW5leHRnZW4tc2Vjb25kYXJ5LWJsdWUtMzAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXNlY29uZGFyeS1ibHVlLTMwMCk7XHJcblxyXG4uaW9uLWNvbG9yLWdyZWVuIHtcclxuXHQtLWlvbi1jb2xvci1iYXNlOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuKTtcclxuXHQtLWlvbi1jb2xvci1iYXNlLXJnYjogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbik7XHJcblx0LS1pb24tY29sb3ItY29udHJhc3Q6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4td2hpdGUpO1xyXG5cdC0taW9uLWNvbG9yLWNvbnRyYXN0LXJnYjogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbik7XHJcblx0LS1pb24tY29sb3Itc2hhZGU6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4pO1xyXG5cdC0taW9uLWNvbG9yLXRpbnQ6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4pO1xyXG59XHJcbiIsIkBpbXBvcnQgXCIuLi8uLi8uLi8uLi8uLi9jb2xvci5zY3NzXCI7XHJcbi5iZW5lZml0cy1jYXJkIHtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIHBhZGRpbmc6IDFyZW07XHJcbiAgICBib3gtc2hhZG93OiAwcHggMXB4IDJweCByZ2JhKDAsIDAsIDAsIDAuMSk7XHJcbiAgICBib3JkZXItcmFkaXVzOiA4cHg7XHJcbiAgICBtaW4taGVpZ2h0OiAxNjVweDtcclxufVxyXG5cclxuLnRleHRTdWJIZWFkZXIge1xyXG4gICAgZm9udC1zaXplOiAxNHB4ICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5pbWFnZUNhcmQge1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgcGFkZGluZzogMS4yNXJlbSAxLjFyZW0gMS4yNXJlbSAxLjFyZW07XHJcbn1cclxuXHJcbi5iYWNrZ3JvdW5kSW1nIHtcclxuICAgIHBhZGRpbmc6IDAuMnJlbSAwLjJyZW0gMC40cmVtIDAuMnJlbTtcclxufSJdfQ== */";

/***/ }),

/***/ 98156:
/*!***************************************************************!*\
  !*** ./src/app/pages/home/policy/policy.page.scss?ngResource ***!
  \***************************************************************/
/***/ ((module) => {

module.exports = ":root {\n  --nc-color-nextgen-neutral-grey-50: red;\n  --nc-color-nextgen-white: yellow;\n  --nc-color-nextgen-blue: #0d152e;\n  --nc-color-nextgen-green: #00908d;\n  --nc-color-nextgen-black: #000000;\n  --nc-color-nextgen-grey-background: #c8d3da;\n  --nc-color-nextgen-grey: #92a2ac;\n  --nc-color-nextgen-stone-grey: #fafafa;\n  --nc-color-nextgen-error: #fc1055;\n  --nc-color-nextgen-neutral-grey: #414141;\n  --nc-color-nextgen-fibrant-green: #00bab6;\n  --nc-color-nextgen-warning: #ffd048;\n  --nc-color-nextgen-green-background: #e6f2f2;\n  --nc-color-nextgen-neutral-grey-400: #7a7a7a;\n  --nc-color-nextgen-neutral-grey-100: #eff3f5;\n  --nc-color-nextgen-status-error: #ba0c3f;\n  --nc-color-nextgen-status-error-background: #ffeff4;\n  --nc-color-nextgen-status-warning: #cba127;\n  --nc-color-nextgen-status-warning-background: #fff8e6;\n  --nc-color-nextgen-blue-100: #dfeff2;\n  --nc-color-nextgen-error-red-700: #f62459;\n  --nc-color-nextgen-blue-500: #006192;\n  --nc-color-nextgen-blue-400: #79cdec;\n  --nc-color-nextgen-red-500: #ff6592;\n  --nc-color-nextgen-secondary-blue-300: #13a0d3;\n  --lumi-white-color: #ffffff;\n  --lumi-primary-yellow-color: #fab600;\n}\n\n.ion-color-green {\n  --ion-color-base: var(--nc-color-nextgen-green);\n  --ion-color-base-rgb: var(--nc-color-nextgen-green);\n  --ion-color-contrast: var(--nc-color-nextgen-white);\n  --ion-color-contrast-rgb: var(--nc-color-nextgen-green);\n  --ion-color-shade: var(--nc-color-nextgen-green);\n  --ion-color-tint: var(--nc-color-nextgen-green);\n}\n\n.content-policy {\n  padding: 0 5%;\n  background-color: #f1efef;\n  min-height: 100%;\n  --background: $color-nextgen-neutral-grey-50;\n  background-color: var(--nc-color-nextgen-neutral-grey-50);\n}\n\n.grid-content {\n  padding: 0 24px;\n}\n\n.status-expired {\n  background-color: var(--nc-color-nextgen-status-error-background);\n  color: var(--nc-color-nextgen-status-error);\n  display: inline-block;\n  margin-top: 0.3rem;\n}\n\n.benifits {\n  padding-bottom: 0.24rem;\n  padding-right: 0.12rem;\n  padding-left: 0.12rem;\n}\n\n.medical-card {\n  text-align: center;\n  box-shadow: 0px 1px 2px rgba(0, 0, 0, 0.1);\n  border-radius: 8px;\n  min-height: 140px;\n  height: 176px;\n  width: 157px;\n}\n\n.policy-detail {\n  padding-top: 0.5rem;\n}\n\n.policy-detail .policy-title {\n  color: var(--nc-color-nextgen-neutral-grey-400);\n}\n\n.policy-detail .policy-title .policy-subtitle {\n  color: var(--nc-color-nextgen-blue);\n  display: inline-block;\n  margin-top: 0.3rem;\n}\n\n.policy-detail .policy-title .active-text {\n  background: var(--nc-color-nextgen-green-background);\n  border-radius: 2px;\n  color: var(--nc-color-nextgen-fibrant-green);\n  text-align: center;\n  padding: 0.3rem 0.4rem;\n}\n\n.policy-document {\n  padding-top: 0.5rem;\n}\n\n.policy-document .document-title {\n  color: var(--nc-color-nextgen-blue);\n  display: flex;\n  align-content: space-between;\n  justify-content: space-between;\n  height: 48px;\n  width: 100%;\n  border-radius: 8px;\n  background-color: var(--nc-color-nextgen-neutral-grey-100);\n  border: 1px solid #C8D3DA;\n  align-items: center;\n  padding: 1rem;\n  margin-bottom: 1rem;\n}\n\n.padding-content {\n  padding-bottom: 0.5rem;\n}\n\n.title {\n  padding-top: 2rem;\n  color: var(--nc-color-nextgen-blue);\n}\n\n.title-search {\n  padding-top: 2rem;\n  padding-bottom: 1rem;\n  color: var(--nc-color-nextgen-blue);\n}\n\n:host ::ng-deep .mat-expansion-indicator::after {\n  border-width: 0 1px 1px 0 !important;\n}\n\n.mat-accordion .mat-expansion-panel:last-of-type {\n  background: #FFFFFF !important;\n  box-shadow: 0px 1px 2px rgba(0, 0, 0, 0.1) !important;\n  border-radius: 8px !important;\n}\n\n.mat-expansion-panel-header-title,\n.mat-expansion-panel-header-description {\n  color: var(--nc-color-nextgen-grey);\n  font-weight: 700 !important;\n}\n\n.buyplan-text {\n  background-color: var(--nc-color-nextgen-fibrant-green);\n  border-radius: 4px;\n  width: 126px;\n  text-align: center;\n  position: fixed;\n  right: 5vw;\n  bottom: 4vw;\n}\n\n.buyplan-text .buy-text {\n  color: var(--nc-color-nextgen-white);\n}\n\n.buyplan-text .month-text {\n  color: var(--nc-color-nextgen-white);\n}\n\n.border-box {\n  border-bottom: 1px solid #EFF3F5;\n  width: 100%;\n  margin-bottom: 0.5rem;\n}\n\n.grid-member {\n  padding-left: 5%;\n  background: var(--nc-color-nextgen-neutral-grey-50) !important;\n}\n\n.swiper-slide {\n  display: block;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFxjb2xvci5zY3NzIiwicG9saWN5LnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNDLHVDQUFBO0VBQ0EsZ0NBQUE7RUFDQSxnQ0FBQTtFQUNBLGlDQUFBO0VBQ0EsaUNBQUE7RUFDQSwyQ0FBQTtFQUNBLGdDQUFBO0VBQ0Esc0NBQUE7RUFDQSxpQ0FBQTtFQUNBLHdDQUFBO0VBQ0EseUNBQUE7RUFDQSxtQ0FBQTtFQUNBLDRDQUFBO0VBQ0EsNENBQUE7RUFDQSw0Q0FBQTtFQUNBLHdDQUFBO0VBQ0EsbURBQUE7RUFDQSwwQ0FBQTtFQUNBLHFEQUFBO0VBQ0Esb0NBQUE7RUFDQSx5Q0FBQTtFQUNBLG9DQUFBO0VBQ0Esb0NBQUE7RUFDQSxtQ0FBQTtFQUNBLDhDQUFBO0VBRUEsMkJBQUE7RUFDQSxvQ0FBQTtBQ0FEOztBRGdDQTtFQUNDLCtDQUFBO0VBQ0EsbURBQUE7RUFDQSxtREFBQTtFQUNBLHVEQUFBO0VBQ0EsZ0RBQUE7RUFDQSwrQ0FBQTtBQzdCRDs7QUFuQ0E7RUFDRSxhQUFBO0VBQ0EseUJBQUE7RUFDQSxnQkFBQTtFQUNBLDRDQUFBO0VBQ0EseUREbUM4QjtBQ0doQzs7QUFuQ0E7RUFDRSxlQUFBO0FBc0NGOztBQW5DQTtFQUNFLGlFRCtCc0M7RUM5QnRDLDJDRDZCMkI7RUM1QjNCLHFCQUFBO0VBQ0Esa0JBQUE7QUFzQ0Y7O0FBbkNBO0VBQ0UsdUJBQUE7RUFDQSxzQkFBQTtFQUNBLHFCQUFBO0FBc0NGOztBQW5DQTtFQUNFLGtCQUFBO0VBQ0EsMENBQUE7RUFDQSxrQkFBQTtFQUNBLGlCQUFBO0VBQ0EsYUFBQTtFQUNBLFlBQUE7QUFzQ0Y7O0FBbkNBO0VBQ0UsbUJBQUE7QUFzQ0Y7O0FBcENFO0VBQ0UsK0NERzZCO0FDbUNqQzs7QUFwQ0k7RUFDRSxtQ0RiZTtFQ2NmLHFCQUFBO0VBQ0Esa0JBQUE7QUFzQ047O0FBbkNJO0VBQ0Usb0REUjJCO0VDUzNCLGtCQUFBO0VBQ0EsNENEWndCO0VDYXhCLGtCQUFBO0VBQ0Esc0JBQUE7QUFxQ047O0FBaENBO0VBQ0UsbUJBQUE7QUFtQ0Y7O0FBakNFO0VBQ0UsbUNEaENpQjtFQ2lDakIsYUFBQTtFQUNBLDRCQUFBO0VBQ0EsOEJBQUE7RUFDQSxZQUFBO0VBQ0EsV0FBQTtFQUNBLGtCQUFBO0VBQ0EsMEREekI2QjtFQzBCN0IseUJBQUE7RUFDQSxtQkFBQTtFQUNBLGFBQUE7RUFDQSxtQkFBQTtBQW1DSjs7QUEvQkE7RUFDRSxzQkFBQTtBQWtDRjs7QUEvQkE7RUFDRSxpQkFBQTtFQUNBLG1DRHJEbUI7QUN1RnJCOztBQS9CQTtFQUNFLGlCQUFBO0VBQ0Esb0JBQUE7RUFDQSxtQ0QzRG1CO0FDNkZyQjs7QUEvQkE7RUFDRSxvQ0FBQTtBQWtDRjs7QUEvQkE7RUFDRSw4QkFBQTtFQUNBLHFEQUFBO0VBQ0EsNkJBQUE7QUFrQ0Y7O0FBL0JBOztFQUVFLG1DRHJFbUI7RUNzRW5CLDJCQUFBO0FBa0NGOztBQS9CQTtFQUNFLHVERHRFNEI7RUN1RTVCLGtCQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0VBQ0EsZUFBQTtFQUNBLFVBQUE7RUFDQSxXQUFBO0FBa0NGOztBQWhDRTtFQUNFLG9DRHRGa0I7QUN3SHRCOztBQS9CRTtFQUNFLG9DRDFGa0I7QUMySHRCOztBQTdCQTtFQUNFLGdDQUFBO0VBQ0EsV0FBQTtFQUNBLHFCQUFBO0FBZ0NGOztBQTdCQTtFQUNFLGdCQUFBO0VBQ0EsOERBQUE7QUFnQ0Y7O0FBN0JBO0VBQ0UsY0FBQTtBQWdDRiIsImZpbGUiOiJwb2xpY3kucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiOnJvb3Qge1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNTA6IHJlZDtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4td2hpdGU6IHllbGxvdztcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZTogIzBkMTUyZTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW46ICMwMDkwOGQ7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWJsYWNrOiAjMDAwMDAwO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ncmV5LWJhY2tncm91bmQ6ICNjOGQzZGE7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWdyZXk6ICM5MmEyYWM7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0b25lLWdyZXk6ICNmYWZhZmE7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWVycm9yOiAjZmMxMDU1O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXk6ICM0MTQxNDE7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWZpYnJhbnQtZ3JlZW46ICMwMGJhYjY7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXdhcm5pbmc6ICNmZmQwNDg7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuLWJhY2tncm91bmQ6ICNlNmYyZjI7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS00MDA6ICM3YTdhN2E7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS0xMDA6ICNlZmYzZjU7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy1lcnJvcjogI2JhMGMzZjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yLWJhY2tncm91bmQ6ICNmZmVmZjQ7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy13YXJuaW5nOiAjY2JhMTI3O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtd2FybmluZy1iYWNrZ3JvdW5kOiAjZmZmOGU2O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlLTEwMDogI2RmZWZmMjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tZXJyb3ItcmVkLTcwMDogI2Y2MjQ1OTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZS01MDA6ICMwMDYxOTI7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWJsdWUtNDAwOiAjNzljZGVjO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1yZWQtNTAwOiAjZmY2NTkyO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zZWNvbmRhcnktYmx1ZS0zMDA6ICMxM2EwZDM7XHJcblxyXG5cdC0tbHVtaS13aGl0ZS1jb2xvcjogI2ZmZmZmZjtcclxuXHQtLWx1bWktcHJpbWFyeS15ZWxsb3ctY29sb3I6ICNmYWI2MDA7XHJcbn1cclxuJGNvbG9yLW5leHRnZW4tYmx1ZTogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlKTtcclxuJGNvbG9yLW5leHRnZW4tZ3JlZW46IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4pO1xyXG4kY29sb3ItbmV4dGdlbi13aGl0ZTogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi13aGl0ZSk7XHJcbiRjb2xvci1uZXh0Z2VuLWJsYWNrOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWJsYWNrKTtcclxuJGNvbG9yLW5leHRnZW4tZ3JleS1iYWNrZ3JvdW5kOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZXktYmFja2dyb3VuZCk7XHJcbiRjb2xvci1uZXh0Z2VuLWdyZXk6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JleSk7XHJcbiRjb2xvci1uZXh0Z2VuLXN0b25lLWdyZXk6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tc3RvbmUtZ3JleSk7XHJcbiRjb2xvci1uZXh0Z2VuLWVycm9yOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWVycm9yKTtcclxuJGNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5OiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleSk7XHJcbiRjb2xvci1uZXh0Z2VuLWZpYnJhbnQtZ3JlZW46IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZmlicmFudC1ncmVlbik7XHJcbiRjb2xvci1uZXh0Z2VuLXdhcm5pbmc6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4td2FybmluZyk7XHJcbiRjb2xvci1uZXh0Z2VuLWdyZWVuLWJhY2tncm91bmQ6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4tYmFja2dyb3VuZCk7XHJcbiRjb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS01MDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNTApO1xyXG4kY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNDAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS00MDApO1xyXG4kY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktMTAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS0xMDApO1xyXG4kY29sb3ItbmV4dGdlbi1zdGF0dXMtZXJyb3I6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yKTtcclxuJGNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yLWJhY2tncm91bmQ6IHZhcihcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yLWJhY2tncm91bmRcclxuKTtcclxuJGNvbG9yLW5leHRnZW4tc3RhdHVzLXdhcm5pbmc6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLXdhcm5pbmcpO1xyXG4kY29sb3ItbmV4dGdlbi1zdGF0dXMtd2FybmluZy1iYWNrZ3JvdW5kOiB2YXIoXHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy13YXJuaW5nLWJhY2tncm91bmRcclxuKTtcclxuJGNvbG9yLW5leHRnZW4tYmx1ZS0xMDA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZS0xMDApO1xyXG4kY29sb3ItbmV4dGdlbi1lcnJvci1yZWQtNzAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWVycm9yLXJlZC03MDApO1xyXG4kY29sb3ItbmV4dGdlbi1ibHVlLTUwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlLTUwMCk7XHJcbiRjb2xvci1uZXh0Z2VuLWJsdWUtNDAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWJsdWUtNDAwKTtcclxuJGNvbG9yLW5leHRnZW4tcmVkLTUwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1yZWQtNTAwKTtcclxuJGNvbG9yLW5leHRnZW4tc2Vjb25kYXJ5LWJsdWUtMzAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXNlY29uZGFyeS1ibHVlLTMwMCk7XHJcblxyXG4uaW9uLWNvbG9yLWdyZWVuIHtcclxuXHQtLWlvbi1jb2xvci1iYXNlOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuKTtcclxuXHQtLWlvbi1jb2xvci1iYXNlLXJnYjogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbik7XHJcblx0LS1pb24tY29sb3ItY29udHJhc3Q6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4td2hpdGUpO1xyXG5cdC0taW9uLWNvbG9yLWNvbnRyYXN0LXJnYjogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbik7XHJcblx0LS1pb24tY29sb3Itc2hhZGU6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4pO1xyXG5cdC0taW9uLWNvbG9yLXRpbnQ6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4pO1xyXG59XHJcbiIsIkBpbXBvcnQgXCIuLi8uLi8uLi8uLi9jb2xvci5zY3NzXCI7XHJcblxyXG4uY29udGVudC1wb2xpY3kge1xyXG4gIHBhZGRpbmc6IDAgNSU7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogI2YxZWZlZjtcclxuICBtaW4taGVpZ2h0OiAxMDAlO1xyXG4gIC0tYmFja2dyb3VuZDogJGNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTUwO1xyXG4gIGJhY2tncm91bmQtY29sb3I6ICRjb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS01MDtcclxufVxyXG5cclxuLmdyaWQtY29udGVudCB7XHJcbiAgcGFkZGluZzogMCAyNHB4O1xyXG59XHJcblxyXG4uc3RhdHVzLWV4cGlyZWQge1xyXG4gIGJhY2tncm91bmQtY29sb3I6ICRjb2xvci1uZXh0Z2VuLXN0YXR1cy1lcnJvci1iYWNrZ3JvdW5kO1xyXG4gIGNvbG9yOiAkY29sb3ItbmV4dGdlbi1zdGF0dXMtZXJyb3I7XHJcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xyXG4gIG1hcmdpbi10b3A6IDAuM3JlbTtcclxufVxyXG5cclxuLmJlbmlmaXRzIHtcclxuICBwYWRkaW5nLWJvdHRvbTogMC4yNHJlbTtcclxuICBwYWRkaW5nLXJpZ2h0OiAwLjEycmVtO1xyXG4gIHBhZGRpbmctbGVmdDogMC4xMnJlbTtcclxufVxyXG5cclxuLm1lZGljYWwtY2FyZCB7XHJcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gIGJveC1zaGFkb3c6IDBweCAxcHggMnB4IHJnYmEoMCwgMCwgMCwgMC4xKTtcclxuICBib3JkZXItcmFkaXVzOiA4cHg7XHJcbiAgbWluLWhlaWdodDogMTQwcHg7XHJcbiAgaGVpZ2h0OiAxNzZweDtcclxuICB3aWR0aDogMTU3cHg7XHJcbn1cclxuXHJcbi5wb2xpY3ktZGV0YWlsIHtcclxuICBwYWRkaW5nLXRvcDogMC41cmVtO1xyXG5cclxuICAucG9saWN5LXRpdGxlIHtcclxuICAgIGNvbG9yOiAkY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNDAwO1xyXG5cclxuICAgIC5wb2xpY3ktc3VidGl0bGUge1xyXG4gICAgICBjb2xvcjogJGNvbG9yLW5leHRnZW4tYmx1ZTtcclxuICAgICAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xyXG4gICAgICBtYXJnaW4tdG9wOiAwLjNyZW07XHJcbiAgICB9XHJcblxyXG4gICAgLmFjdGl2ZS10ZXh0IHtcclxuICAgICAgYmFja2dyb3VuZDogJGNvbG9yLW5leHRnZW4tZ3JlZW4tYmFja2dyb3VuZDtcclxuICAgICAgYm9yZGVyLXJhZGl1czogMnB4O1xyXG4gICAgICBjb2xvcjogJGNvbG9yLW5leHRnZW4tZmlicmFudC1ncmVlbjtcclxuICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgICBwYWRkaW5nOiAwLjNyZW0gMC40cmVtO1xyXG4gICAgfVxyXG4gIH1cclxufVxyXG5cclxuLnBvbGljeS1kb2N1bWVudCB7XHJcbiAgcGFkZGluZy10b3A6IDAuNXJlbTtcclxuXHJcbiAgLmRvY3VtZW50LXRpdGxlIHtcclxuICAgIGNvbG9yOiAkY29sb3ItbmV4dGdlbi1ibHVlO1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGFsaWduLWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XHJcbiAgICBoZWlnaHQ6IDQ4cHg7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIGJvcmRlci1yYWRpdXM6IDhweDtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICRjb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS0xMDA7XHJcbiAgICBib3JkZXI6IDFweCBzb2xpZCAjQzhEM0RBO1xyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgIHBhZGRpbmc6IDFyZW07XHJcbiAgICBtYXJnaW4tYm90dG9tOiAxcmVtO1xyXG4gIH1cclxufVxyXG5cclxuLnBhZGRpbmctY29udGVudCB7XHJcbiAgcGFkZGluZy1ib3R0b206IDAuNXJlbTtcclxufVxyXG5cclxuLnRpdGxlIHtcclxuICBwYWRkaW5nLXRvcDogMnJlbTtcclxuICBjb2xvcjogJGNvbG9yLW5leHRnZW4tYmx1ZTtcclxufVxyXG5cclxuLnRpdGxlLXNlYXJjaCB7XHJcbiAgcGFkZGluZy10b3A6IDJyZW07XHJcbiAgcGFkZGluZy1ib3R0b206IDFyZW07XHJcbiAgY29sb3I6ICRjb2xvci1uZXh0Z2VuLWJsdWU7XHJcbn1cclxuXHJcbjpob3N0IDo6bmctZGVlcCAubWF0LWV4cGFuc2lvbi1pbmRpY2F0b3I6OmFmdGVyIHtcclxuICBib3JkZXItd2lkdGg6IDAgMXB4IDFweCAwICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5tYXQtYWNjb3JkaW9uIC5tYXQtZXhwYW5zaW9uLXBhbmVsOmxhc3Qtb2YtdHlwZSB7XHJcbiAgYmFja2dyb3VuZDogI0ZGRkZGRiAhaW1wb3J0YW50O1xyXG4gIGJveC1zaGFkb3c6IDBweCAxcHggMnB4IHJnYigwIDAgMCAvIDEwJSkgIWltcG9ydGFudDtcclxuICBib3JkZXItcmFkaXVzOiA4cHggIWltcG9ydGFudDtcclxufVxyXG5cclxuLm1hdC1leHBhbnNpb24tcGFuZWwtaGVhZGVyLXRpdGxlLFxyXG4ubWF0LWV4cGFuc2lvbi1wYW5lbC1oZWFkZXItZGVzY3JpcHRpb24ge1xyXG4gIGNvbG9yOiAkY29sb3ItbmV4dGdlbi1ncmV5O1xyXG4gIGZvbnQtd2VpZ2h0OiA3MDAgIWltcG9ydGFudDtcclxufVxyXG5cclxuLmJ1eXBsYW4tdGV4dCB7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogJGNvbG9yLW5leHRnZW4tZmlicmFudC1ncmVlbjtcclxuICBib3JkZXItcmFkaXVzOiA0cHg7XHJcbiAgd2lkdGg6IDEyNnB4O1xyXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICBwb3NpdGlvbjogZml4ZWQ7XHJcbiAgcmlnaHQ6IDV2dztcclxuICBib3R0b206IDR2dztcclxuXHJcbiAgLmJ1eS10ZXh0IHtcclxuICAgIGNvbG9yOiAkY29sb3ItbmV4dGdlbi13aGl0ZTtcclxuICB9XHJcblxyXG4gIC5tb250aC10ZXh0IHtcclxuICAgIGNvbG9yOiAkY29sb3ItbmV4dGdlbi13aGl0ZTtcclxuICB9XHJcbn1cclxuXHJcbi5ib3JkZXItYm94IHtcclxuICBib3JkZXItYm90dG9tOiAxcHggc29saWQgI0VGRjNGNTtcclxuICB3aWR0aDogMTAwJTtcclxuICBtYXJnaW4tYm90dG9tOiAwLjVyZW07XHJcbn1cclxuXHJcbi5ncmlkLW1lbWJlciB7XHJcbiAgcGFkZGluZy1sZWZ0OiA1JTtcclxuICBiYWNrZ3JvdW5kOiAkY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNTAgIWltcG9ydGFudDtcclxufVxyXG5cclxuLnN3aXBlci1zbGlkZSB7XHJcbiAgZGlzcGxheTogYmxvY2s7XHJcbn0iXX0= */";

/***/ }),

/***/ 6954:
/*!*******************************************************************************!*\
  !*** ./src/app/pages/home/claims-history/claims-history.page.html?ngResource ***!
  \*******************************************************************************/
/***/ ((module) => {

module.exports = "<ion-content mode=\"ios\"   scrollEvents=\"true\" (ionScrollEnd)=\"logScrolling()\">\r\n  <div class=\"history-container\">\r\n    <ion-segment class=\"segment\" (ionChange)=\"segmentChanged($event)\" [value]='tab'>\r\n      <ion-segment-button class=\"segment-button body-n\" value=5>\r\n        <ion-label>{{ 'claimsHistory.reimbursement' | translate }}</ion-label>\r\n      </ion-segment-button>\r\n      <ion-segment-button class=\"segment-button body-n\" value=4>\r\n        <ion-label>{{ 'claimsHistory.approvals' | translate }}</ion-label>\r\n      </ion-segment-button>\r\n    </ion-segment>\r\n    <div class=\"inputSearch\">\r\n      <!-- search-hisoty component  -->\r\n      <app-history-search [placeholder]=\"'claimsHistory.placeholderSearch'| translate\" *ngIf=\"listFilter\" [showResetButton] = \"true\"\r\n        [showFilterCount]=\"true\" [listFilter]=\"listFilter\" (onSearchChange)=\"onSearch($event)\"></app-history-search>\r\n    </div>\r\n    <div class=\"claim-title\">\r\n      <ion-label class=\"body-l bold\" [ngSwitch]=\"tab\">\r\n        <span class=\"body-l bold\" *ngSwitchCase=\"4\">{{ 'claimsHistory.approvalsTitle' | translate }}</span>\r\n        <span class=\"body-l bold\" *ngSwitchDefault>{{ 'claimsHistory.reimbursementTitle' | translate }}</span>\r\n      </ion-label>\r\n    </div>\r\n\r\n    <!-- history-contents component  -->\r\n    <app-history-contents [details]=\"details\" [isLoading]=\"isLoading\" [type]=\"tab\" [currentPolicy]=\"currentUserPolicy\" [isEnabledApointmentBooking]=\"isEnabledApointmentBooking\"></app-history-contents>\r\n\r\n    <!-- button new-create -->\r\n    <div class=\"create-new\" [ngSwitch]=\"tab\">\r\n      <button (click)=\"onChangeCreate()\"\r\n      [ngStyle]=\"{'display': (isEnabledPreapprovalBtn == false || currentUserPolicy?.status == 'expired' || isActiveMember == false)?'none':'block'}\"\r\n      class=\"btn primary body-l bold\" *ngSwitchCase=\"4\">\r\n        <i class=\"uil uil-plus plus-icon body-n\"></i>\r\n          {{ 'claimsHistory.approvalsBtn' | translate }}\r\n      </button>\r\n      <button (click)=\"onChangeCreate()\"\r\n      [ngStyle]=\"{'display': (isEnabledReimbursmentBtn == false)?'none':'block'}\" \r\n      class=\"btn primary body-l bold\" *ngSwitchDefault>\r\n        <i class=\"uil uil-plus plus-icon body-n\"></i>\r\n          {{ 'claimsHistory.reimbursementBtn' | translate }}\r\n      </button>\r\n    </div>\r\n  </div>\r\n</ion-content>";

/***/ }),

/***/ 69763:
/*!*****************************************************************************************************!*\
  !*** ./src/app/pages/home/claims-history/history-content/history-content.component.html?ngResource ***!
  \*****************************************************************************************************/
/***/ ((module) => {

module.exports = "<ng-container *ngIf=\"!isLoading &&(!details || details.length==0)\">\r\n\t<ion-card-content *ngFor=\"let _ of [].constructor(4)\">\r\n\t\t<ion-grid>\r\n\t\t\t<ion-row class=\"card-row\">\r\n\t\t\t\t<ion-col class=\"col-left\">\r\n\t\t\t\t\t<ion-skeleton-text animated=\"true\" class=\"body-xs\"></ion-skeleton-text>\r\n\t\t\t\t</ion-col>\r\n\t\t\t\t<ion-col class=\"col-right\">\r\n\t\t\t\t\t<ion-skeleton-text animated=\"true\" class=\"\"></ion-skeleton-text>\r\n\t\t\t\t</ion-col>\r\n\t\t\t</ion-row>\r\n\t\t\t<ion-row class=\"card-row\">\r\n\t\t\t\t<ion-col>\r\n\t\t\t\t\t<ion-skeleton-text animated=\"true\" class=\"text-content body-l bold color-black\"></ion-skeleton-text>\r\n\t\t\t\t\t<ion-skeleton-text animated=\"true\" class=\"body-sm sub-title\"></ion-skeleton-text>\r\n\t\t\t\t</ion-col>\r\n\t\t\t</ion-row>\r\n\r\n\t\t\t<ion-row class=\"card-row\">\r\n\t\t\t\t<ion-col class=\"col-left\">\r\n\t\t\t\t\t<div>\r\n\t\t\t\t\t\t<ion-skeleton-text animated=\"true\" class=\"text-content body-n bold color-black\"></ion-skeleton-text>\r\n\t\t\t\t\t\t<ion-skeleton-text animated=\"true\" class=\"body-sm name\"></ion-skeleton-text>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t</ion-col>\r\n\t\t\t\t<ion-col class=\"col-right\">\r\n\t\t\t\t\t<ion-skeleton-text animated=\"true\" class=\"text-content body-n bold color-black\"></ion-skeleton-text>\r\n\t\t\t\t\t<ion-skeleton-text animated=\"true\" class=\"body-sm type\"></ion-skeleton-text>\r\n\t\t\t\t</ion-col>\r\n\t\t\t</ion-row>\r\n\t\t</ion-grid>\r\n\t\t<!-- <ion-row class=\"card-row\">\r\n            <ion-col>\r\n                <ion-skeleton-text animated=\"true\" class=\"btn primary secondary\">\r\n                </ion-skeleton-text>\r\n            </ion-col>\r\n        </ion-row> -->\r\n\t</ion-card-content>\r\n</ng-container>\r\n<ion-card class=\"claim-cards\" *ngFor=\"let detail of details; trackBy:trackById\" trackBy:detailById>\r\n\t<ion-card-content>\r\n\t\t<ion-grid (click)=\"onViewDetail(detail)\">\r\n\t\t\t<ion-row class=\"card-row\">\r\n\t\t\t\t<ion-col class=\"col-left\" *ngIf=\"detail?.status === 'Draft'; else claimstatus\">\r\n\t\t\t\t\t<ion-label class=\"body-xs\" [ngClass]=\"detail.status\">{{ detail.status }}</ion-label>\r\n\t\t\t\t</ion-col>\r\n\t\t\t\t<ng-template #claimstatus>\r\n\t\t\t\t\t<ion-col class=\"col-left\">\r\n\t\t\t\t\t\t<ion-label class=\"body-xs\" [ngClass]=\"detail.claimStatus\">{{ detail.claimStatus }}</ion-label>\r\n\t\t\t\t\t</ion-col>\r\n\t\t\t\t\t<div *ngIf=\"type == 5\">\r\n\t\t\t\t\t\t<ion-label class=\"body-xs reSubmission\" *ngIf=\"detail.resubmission > 0\">{{'claimsHistory.reSubmission' | translate}}</ion-label>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t</ng-template>\r\n\t\t\t\t<ion-col class=\"col-right\" *ngIf=\"detail?.status === 'Draft'\">\r\n\t\t\t\t\t<i (click)=\"onDelete($event,detail)\" class=\"icon-trash uil uil-trash\"></i>\r\n\t\t\t\t</ion-col>\r\n\t\t\t</ion-row>\r\n\t\t\t<ion-row class=\"card-row\">\r\n\t\t\t\t<ion-col>\r\n\t\t\t\t\t<h6 class=\"text-content body-l bold color-black\">{{ detail.treatmentName }}</h6>\r\n\t\t\t\t\t<ion-text class=\"body-sm sub-title\" *ngIf=\"detail.claimRef\"><span class=\"claimRef bold\">{{ detail.claimRef + '/' + detail.asoapplanId}}</span></ion-text>\r\n\t\t\t\t</ion-col>\r\n\t\t\t</ion-row>\r\n\r\n\t\t\t<ion-row class=\"card-row\">\r\n\t\t\t\t<div class=\"col-left\">\r\n\t\t\t\t\t<div>\r\n\t\t\t\t\t\t<h6 class=\"text-content body-n bold color-black\">{{ detail.declarationDate | date:'MMM dd, yyyy' :'' :lang }}</h6>\r\n\t\t\t\t\t\t<ion-text class=\"body-sm name\">{{ detail.benefFullName |replaceMySelf |translate }}</ion-text>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t</div>\r\n\t\t\t\t<div class=\"col-right\">\r\n\t\t\t\t\t<div *ngIf=\"type == 5 && isLoading\">\r\n\t\t\t\t\t\t<h6 class=\"text-content body-n bold color-black\">{{ detail.claimCurrency }} {{ detail.requestestCost }}</h6>\r\n\t\t\t\t\t\t<ion-text class=\"body-sm type\">{{'claimsHistory.claimAmount' | translate}}</ion-text>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t</div>\r\n\t\t\t</ion-row>\r\n\t\t</ion-grid>\r\n\t\t<!-- <ion-row class=\"card-row\" *ngIf=\"type == 4 && isEnabledApointmentBooking == true && detail.status =='Initial'\">\r\n            <ion-col>\r\n                <button class=\"btn primary secondary\" (click)=\"onBookApointment()\">{{ 'claimDetailsApproved.bookAnAppointment' | translate}} <i class=\"uil uil-arrow-right body-l icon-next\"></i></button>\r\n            </ion-col>\r\n        </ion-row> -->\r\n\t</ion-card-content>\r\n</ion-card>\r\n\r\n<div class=\"noData\" *ngIf=\"!details || details.length === 0\" [ngSwitch]=\"type\">\r\n\t<ion-text *ngSwitchDefault class=\"body-l\">{{ 'claimsHistory.dataDefaultClaim' | translate}}</ion-text>\r\n\t<ion-text *ngSwitchCase=\"4\" class=\"body-l\">{{ 'claimsHistory.dataDefaultPreaproval' | translate}}</ion-text>\r\n</div>\r\n";

/***/ }),

/***/ 35045:
/*!*********************************************************************!*\
  !*** ./src/app/pages/home/dashboard/dashboard.page.html?ngResource ***!
  \*********************************************************************/
/***/ ((module) => {

module.exports = "<ion-content class=\"home-page-content\">\r\n    <div class=\"home-page-content\">\r\n        <ion-grid class=\"grid-member\">\r\n            <ion-row>\r\n                <ion-col>\r\n                    <ion-slides [options]=\"slideOpts\">\r\n                        <ion-slide *ngFor=\"let item of listDashboard\">\r\n                            <app-dashboard-card (updateDashboard)=\"item?.callback ? item.callback() : showpopup(item)\" [card]=\"item\">\r\n                            </app-dashboard-card>\r\n                        </ion-slide>\r\n                    </ion-slides>\r\n                </ion-col>\r\n            </ion-row>\r\n        </ion-grid>\r\n        <ion-grid class=\"grid-content\">\r\n            <ion-row>\r\n                <ion-col>\r\n                    <div class=\"h5 bold title\" *ngIf=\"listMedical?.length > 0\">{{'home.medicalServices'|translate}}</div>\r\n                </ion-col>\r\n            </ion-row>\r\n            <ion-row>\r\n                <ion-col size=\"6\" class=\"medical\" *ngFor=\"let item of listMedical\">\r\n                    <app-medical-card (click)=\"item?.callback ? item.callback() : showpopup(item)\" [card]=\"item\"></app-medical-card>\r\n                </ion-col>\r\n            </ion-row>\r\n            <ion-row>\r\n                <ion-col>\r\n                    <div class=\"h5 bold title\" *ngIf=\"listInsurance?.length > 0\">{{'home.insuranceServices'|translate}}</div>\r\n                </ion-col>\r\n            </ion-row>\r\n            <ion-row class=\"insurance\" *ngFor=\"let item of listInsurance\" size=\"1\">\r\n                <ion-col>\r\n                    <app-insurance-card (click)=\"onClickInsuranceCard(item)\" [card]=\"item\"></app-insurance-card>\r\n                </ion-col>\r\n            </ion-row>\r\n            <ion-row>\r\n                <ion-col>\r\n                    <div class=\"h5 bold title-menber\" *ngIf=\"listFamilyMember?.length > 0\" [hidden]=\"currentPolicy?.status == 'expired'\">{{'home.coveredMembers'|translate}}</div>\r\n                </ion-col>\r\n            </ion-row>\r\n        </ion-grid>\r\n        <ion-grid class=\"grid-member\">\r\n            <ion-row>\r\n                <ion-col>\r\n                    <ion-slides [options]=\"slideMemberOpts\">\r\n                        <ion-slide *ngFor=\"let item of listFamilyMember\">\r\n                            <app-member-card [hidden]=\"currentPolicy?.status == 'expired'\" [card]=\"item\" [currentPolicy]=\"currentPolicy\" [currentPolicyDetail]=\"currentPolicyDetail\"></app-member-card>\r\n                        </ion-slide>\r\n                    </ion-slides>\r\n                </ion-col>\r\n            </ion-row>\r\n        </ion-grid>\r\n    </div>\r\n</ion-content>";

/***/ }),

/***/ 30400:
/*!**********************************************************************************************!*\
  !*** ./src/app/pages/home/dashboard/insurance-card/insurance-card.component.html?ngResource ***!
  \**********************************************************************************************/
/***/ ((module) => {

module.exports = "<ion-grid class=\"insurance-card\" [style.background]=\"card.backgroundCard\">\r\n  <ion-row >\r\n    <ion-col class=\"ion-align-self-center\" size=\"2\">\r\n      <span class=\"image-card\"><img [src]=\"card.imageCard\" /></span>\r\n    </ion-col>\r\n    <ion-col class=\"ion-align-self-center\" size=\"8\">\r\n      <div class=\"body-n bold\" [style.color]=\"card.textColorHeader\">{{card.textHeader | translate}}</div>\r\n      <div class=\"body-sm\" [style.color]=\"card.textColorContent\">{{card.textContent |translate}}</div>\r\n    </ion-col>\r\n    <ion-col class=\"ion-align-self-center icon-insurance\" size=\"1\">\r\n        <ion-icon class=\"icon\" [style.color]=\"card.colorIcon\" name=\"arrow-forward-outline\"></ion-icon>\r\n    </ion-col>\r\n  </ion-row>\r\n</ion-grid>";

/***/ }),

/***/ 70935:
/*!******************************************************************************************!*\
  !*** ./src/app/pages/home/dashboard/medical-card/medical-card.component.html?ngResource ***!
  \******************************************************************************************/
/***/ ((module) => {

module.exports = "<div class=\"medical-card\" [style.background]=\"card.backgroundCard\">\r\n    <img [src]=\"card.imageCard\" />\r\n    <div class=\"dynamic-text body-n bold\" [style.color]=\"card.textColorHeader\">{{card.textHeader | translate}}</div>\r\n</div>";

/***/ }),

/***/ 79887:
/*!**************************************************************************!*\
  !*** ./src/app/pages/home/home-care/home-care.component.html?ngResource ***!
  \**************************************************************************/
/***/ ((module) => {

module.exports = "<ion-content class=\"home-care-page\">\r\n  <ion-grid class=\"grid-member\">\r\n    <ion-row>\r\n      <ion-col>\r\n        <ion-slides [options]=\"slideOpts\">\r\n          <ion-slide class=\"slide\" *ngFor=\"let item of listDashboard\">\r\n            <app-dashboard-card (updateDashboard)=\"item?.callback ? item.callback() : showpopup(item)\" [card]=\"item\">\r\n            </app-dashboard-card>\r\n          </ion-slide>\r\n        </ion-slides>\r\n      </ion-col>\r\n    </ion-row>\r\n  </ion-grid>\r\n  <div class=\"grid-content\">\r\n    <ion-grid>\r\n      <ion-row>\r\n        <ion-col>\r\n          <div class=\"h5 bold title\" *ngIf=\"title\">{{'homeCare.title' | translate}}</div>\r\n        </ion-col>\r\n      </ion-row>\r\n    </ion-grid>\r\n    <div class=\"home-care-content\">\r\n      <ion-row *ngFor=\"let careData of careDatas\">\r\n        <ion-col>\r\n          <ion-card class=\"home-care-card\" appIonCLick\r\n            (debounceClick)=\"careData.callback? careData.callback():showpopup(careData)\" [debounceTime]=\"700\">\r\n            <ion-grid>\r\n              <ion-row>\r\n                <ion-col size=\"3\">\r\n                  <ion-img class=\"home-care-card-avt\" [src]=\"careData.avatar\"></ion-img>\r\n                </ion-col>\r\n                <ion-col size=\"8\">\r\n                  <p class=\"home-care-card-title body-n bold \">\r\n                    {{careData.title | translate}}</p>\r\n                  <p class=\"home-care-card-text body-xs\">{{ careData.subtitle | translate}}</p>\r\n                </ion-col>\r\n                <ion-col size=\"1\">\r\n                  <div class=\"home-care-card-icon\">\r\n                    <ion-icon name=\"arrow-forward-outline\"></ion-icon>\r\n                  </div>\r\n                </ion-col>\r\n              </ion-row>\r\n            </ion-grid>\r\n          </ion-card>\r\n        </ion-col>\r\n      </ion-row>\r\n    </div>\r\n  </div>\r\n</ion-content>";

/***/ }),

/***/ 8380:
/*!******************************************************!*\
  !*** ./src/app/pages/home/home.page.html?ngResource ***!
  \******************************************************/
/***/ ((module) => {

module.exports = "<ion-split-pane contentId=\"main-content\" class=\"home-page-container\">\r\n    <ion-menu contentId=\"main-content\" menuId=\"profile-menu\" type=\"overlay\" class=\"profile-list-menu\"\r\n        swipeGesture=\"false\">\r\n        <ion-content>\r\n            <img class=\"profile-image close-icon\" src=\"../../../assets/icon/close-icon.svg\" (click)=\"closeMenu()\" />\r\n            <div class=\"profile-image-menu\">\r\n                <div *ngIf=\"userImage;else noUserImage\">\r\n                    <img class=\"icon-avata\" src=\"data:image/png;base64,{{userImage}}\" />\r\n                </div>\r\n                <ng-template #noUserImage>\r\n                    <img class=\"icon-avata\" src=\"../../../assets/images/user-profile.svg\" />\r\n                </ng-template>\r\n                <div class=\"account-name h3 bold\">{{userProfile?.firstName}} {{userProfile?.lastName}}</div>\r\n                <p class=\"Email-text body-sm\">{{userContact?.emails?.[0]?.contactInfo}}</p>\r\n                <ion-button type=\"button\" class=\"button-policy\"\r\n                    [ngClass]=\"currentPolicy?.status === 'expired' ? 'expired' : 'active'\" (click)=\"openDialog()\">\r\n                    <i class=\"icon-policy uil\"\r\n                        [ngClass]=\"currentPolicy?.status === 'expired' ? 'uil-shield-exclamation' : 'uil-shield-check'\"></i>\r\n                    <span class=\"policy-text body-sm semibold \">{{currentPolicy?.policyNumber}}</span>\r\n                    <i class=\"uil uil-angle-down\"></i>\r\n                </ion-button>\r\n            </div>\r\n            <div class=\"menu-item-container\">\r\n                <div class=\"menu-item\" *ngFor=\"let item of actionList\" (click)=\"onNavigate(item)\"\r\n                    [hidden]=\"!item.isShow\">\r\n                    <i *ngIf=\"item.classIcon\" class=\"uil h3\" [ngClass]=\"'uil-'+ item.classIcon\"></i>\r\n                    <img *ngIf=\"item.imageIcon\" [src]=\"'../../../assets/icon/'+item.imageIcon\" />\r\n                    <span class=\"title body-n bold ion-margin\">{{item.title | translate}}\r\n                        <!-- <ion-badge *ngIf=\"item.notifications\" class=\"notifications-profile ion-margin body-xs\">\r\n                            {{item.notifications}}</ion-badge> -->\r\n                    </span>\r\n                    <div style=\"width: 16px\">\r\n                        <!-- <i *ngIf=\"item.isShowNavigationIcon\" class=\"uil uil-angle-right\"></i> -->\r\n                        <ion-icon *ngIf=\"item.isShowNavigationIcon\" class=\"uil icon-language\" name=\"chevron-forward-outline\"></ion-icon>\r\n                    </div>\r\n                </div>\r\n                <!-- Setting Language -->\r\n                <!-- <div class=\"menu-item\" (click)=\"settingLanguage()\" [hidden]=\"!isMobile\" >\r\n          <img [src]=\"'../../../assets/icon/language.svg'\" />\r\n          <span class=\"title\">{{ 'home.language' | translate }}</span>\r\n        </div> -->\r\n            </div>\r\n\r\n            <p class=\"version-app body-xs\">{{'home.appversion' | translate}} {{versionApp}}</p>\r\n        </ion-content>\r\n    </ion-menu>\r\n\r\n    <div id=\"main-content\">\r\n        <ion-header>\r\n            <ion-toolbar>\r\n                <ion-title>\r\n                    <div class=\"home-toolbar\">\r\n                        <div class=\"start\">\r\n                            <ng-container *ngIf=\"currentTab === 'inquiriesHistory' ;else backDisplay\">\r\n                                <div>\r\n                                    <button class=\"btn btn-circle\" (click)=\"onBack()\">\r\n                                        <ion-icon  class=\"icon-back body-l\" name=\"arrow-back-outline\"></ion-icon>\r\n                                    </button>\r\n                                </div>\r\n                            </ng-container>\r\n                            <ng-template #backDisplay>\r\n                                <div (click)=\"onNextCare()\">\r\n                                    <img class=\"heart-image\" src=\"../../../assets/icon/logo.svg\" width=\"50px\"\r\n                                        height=\"18px\" />\r\n                                </div>\r\n                            </ng-template>\r\n                        </div>\r\n                        <div class=\"end\">\r\n                            <ng-container *ngIf=\"currentTab === 'dashboard';else otherDisplay\">\r\n                                <div class=\"notification\">\r\n                                    <ion-icon name=\"notifications-outline\"\r\n                                        (click)=\"redirectToNotification()\"></ion-icon>\r\n                                </div>\r\n                                <div (click)=\"openMenu()\"> \r\n                                    <div *ngIf=\"userImage;else noUserImage\">\r\n                                        <img class=\"profile-image\"\r\n                                            src=\"data:image/png;base64,{{userImage}}\" />\r\n                                    </div>\r\n                                    <ng-template #noUserImage>\r\n                                        <img class=\"profile-image\" \r\n                                            src=\"../../../assets/images/user-profile.svg\" />\r\n                                    </ng-template>\r\n                                </div>  \r\n                            </ng-container>\r\n                            <ng-template #otherDisplay>\r\n                                <ng-container *ngIf=\"needHelp\">\r\n                                    <span (click)=\"onNeedHelp()\" class=\"need-help-text body-l bold\">\r\n                                        {{ 'home.needHelp' | translate }}</span>\r\n                                </ng-container>\r\n                            </ng-template>\r\n                        </div>\r\n                    </div>\r\n                </ion-title>\r\n            </ion-toolbar>\r\n        </ion-header>\r\n        <ion-content>\r\n            <ion-tabs #tabs (ionTabsDidChange)=\"onTabChange($event)\">\r\n                <ion-tab-bar slot=\"bottom\" class=\"footer\">\r\n                    <ion-tab-button tab=\"dashboard\">\r\n                        <i class=\"uil uil-estate tab-color tab-size\"></i>\r\n                        <ion-label class=\"body-xs bold tab-color\">{{'home.home' |translate}}</ion-label>\r\n                    </ion-tab-button>\r\n                    <ion-tab-button tab=\"home-care\">\r\n                        <i class=\"uil uil-heartbeat tab-color tab-size\"></i>\r\n                        <ion-label class=\"body-xs bold tab-color\">{{'home.care' |translate}}</ion-label>\r\n                    </ion-tab-button>\r\n                    <ion-tab-button tab=\"policy-page\">\r\n                        <i class=\"uil uil-shield-check tab-color tab-size\"></i>\r\n                        <ion-label class=\"body-xs bold tab-color\">{{'home.coverage' |translate}}</ion-label>\r\n                    </ion-tab-button>\r\n                    <ion-tab-button tab=\"claims-history\">\r\n                        <i class=\"uil uil-file-alt tab-color tab-size\"></i>\r\n                        <ion-label class=\"body-xs bold tab-color\">{{'home.claims' |translate}}</ion-label>\r\n                    </ion-tab-button>\r\n                </ion-tab-bar>\r\n            </ion-tabs>\r\n        </ion-content>\r\n    </div>\r\n\r\n</ion-split-pane>\r\n<app-register-third-party></app-register-third-party>";

/***/ }),

/***/ 74154:
/*!******************************************************************************************!*\
  !*** ./src/app/pages/home/inquiries-history/inquiries-history.component.html?ngResource ***!
  \******************************************************************************************/
/***/ ((module) => {

module.exports = "<ion-content class=\"home-care-page\">\r\n  <div class=\"history-container\">\r\n      <!-- <div class=\"search-box\">\r\n        <app-history-search (onSearchChange)=\"onSearchChange($event)\" [showFilterCount]=\"false\"\r\n        [placeholder]=\"'inquiryHistory.search' | translate\" [listFilter]=\"listFilter\"></app-history-search>\r\n      </div> -->\r\n      <div class=\"claim-title body-l bold\"> {{ 'inquiryHistory.inquiryHistory' | translate}} </div>\r\n  \r\n      <ion-row class=\"content\" *ngFor=\"let item of inquiryHistory\">\r\n        <ion-col class=\"ion-align-self-center\" size=\"12\">\r\n          <div class=\"body-sm bold status-text\">{{item?.inquirystatus}}</div>\r\n          <div class=\"body-n name\">{{item?.inquirysequencenbr}}</div>\r\n          <div class=\"body-n bold date\">{{item?.creationdate | date: 'd MMMM y':'':lang}}</div>\r\n          <div class=\"body-sm name-call\">{{item?.reasonofcall}}</div>\r\n        </ion-col>\r\n      </ion-row>\r\n    \r\n    <div class=\"data-default\" *ngIf=\"!inquiryHistory || inquiryHistory.length === 0\">\r\n      <ion-text class=\"body-l\">{{ 'inquiryHistory.noInquiryHistory' | translate}}</ion-text>\r\n    </div>\r\n\r\n      <!-- button new-create -->\r\n      <div class=\"create-new\">\r\n        <button (click)=\"onChangeCreate()\"\r\n        class=\"btn primary body-l bold\">\r\n          <i class=\"uil uil-plus plus-icon body-n\"></i>\r\n            {{ 'inquiryHistory.create' | translate }}\r\n        </button>\r\n      </div>\r\n\r\n      <a *ngIf=\"locationCountry\" class=\"btn btn-circle phone-center\" href=\"tel:+212520486400\"><i class=\"uil uil-phone\"></i></a>\r\n      <a *ngIf=\"!locationCountry\" class=\"btn btn-circle phone-center\"href=\"tel:+966920003055\"><i class=\"uil uil-phone\"></i></a>\r\n  </div>\r\n</ion-content>";

/***/ }),

/***/ 83896:
/*!*******************************************************************************!*\
  !*** ./src/app/pages/home/policy/benefits/benefits.component.html?ngResource ***!
  \*******************************************************************************/
/***/ ((module) => {

module.exports = "<div *ngIf=\"card.enable\"class=\"benefits-card\" [style.background]=\"card.backgroundCard\">\r\n    <img class=\"imageCard\" [src]=\"card.imageCard\" />\r\n    <img class=\"backgroundImg\" [src]=\"card.backgroundImg\">\r\n    <div class=\"body-n bold\" [style.color]=\"card.textColorHeader\">{{card.textHeader | translate}}</div>\r\n    <!-- <div class=\"textSubHeader\" [style.color]=\"card.textColorSubHeader\">{{card.count}} {{'policy.coveredBenefits' | translate}}</div> -->\r\n</div>";

/***/ }),

/***/ 4703:
/*!***************************************************************!*\
  !*** ./src/app/pages/home/policy/policy.page.html?ngResource ***!
  \***************************************************************/
/***/ ((module) => {

module.exports = "<ion-content class=\"content-policy\">\r\n  <ion-grid class=\"grid-member\">\r\n    <ion-row>\r\n      <ion-col>\r\n        <ion-slides [options]=\"slideOpts\">\r\n          <ion-slide class=\"slide-member\" *ngFor=\"let item of listFamilyMember\">\r\n            <app-member-card [hidden]=\"currentPolicy?.status == 'expired'\" [card]=\"item\" [currentPolicy]=\"currentPolicy\"\r\n              [currentPolicyDetail]=\"currentPolicyDetail\" (onHighLight)=\"onHighlightCard($event)\" [selectedBeneficiaryId]=\"selectedBeneficiaryId\"></app-member-card>\r\n          </ion-slide>\r\n        </ion-slides>\r\n      </ion-col>\r\n    </ion-row>\r\n  </ion-grid>\r\n  <div class=\"grid-content\">\r\n    <ion-grid>\r\n      <ion-row>\r\n        <ion-col *ngIf=\"currentPolicyDetail?.firstName\">\r\n          <div class=\"h5 bold title\">{{'policy.viewJennysPolicyDetails' | translate | replace: '{name}':\r\n            currentPolicyDetail?.firstName}}</div>\r\n        </ion-col>\r\n      </ion-row>\r\n      <div class=\"policy-detail\">\r\n        <mat-accordion class=\"example-headers-align\">\r\n          <mat-expansion-panel (opened)=\"onExpansionPanel(true)\">\r\n            <mat-expansion-panel-header>\r\n              <mat-panel-title class=\"body-sm\">\r\n                {{'policy.highlight'|translate}}\r\n              </mat-panel-title>\r\n            </mat-expansion-panel-header>\r\n            <div class=\"border-box\"></div>\r\n            <p class=\"policy-title\">{{'policy.insurer'|translate}}<br>\r\n              <span class=\"policy-subtitle body-n bold\">{{currentPolicyDetail?.payerName}}</span>\r\n            </p>\r\n            <p class=\"policy-title\">{{'policy.policyHolder'|translate}}<br>\r\n              <span class=\"policy-subtitle body-n bold\">{{currentPolicyDetail?.policyHolder}}</span>\r\n            </p>\r\n            <p class=\"policy-title\">{{'policy.policyNumber'|translate}}<br>\r\n              <span class=\"policy-subtitle body-n bold\">{{currentPolicyDetail?.policyNumber}}</span>\r\n            </p>\r\n            <p class=\"policy-title\">{{'policy.policyStartDate'|translate}}<br>\r\n              <span class=\"policy-subtitle body-n bold\">{{currentPolicyDetail?.policyStartDay | date: 'd MMMM y':'':lang}}</span>\r\n            </p>\r\n            <p class=\"policy-title\">{{'policy.policyEndDate'|translate}}<br>\r\n              <span class=\"policy-subtitle body-n bold\">{{currentPolicyDetail?.policyEndDay | date: 'd MMMM y':'':lang}}</span>\r\n            </p>\r\n            <p class=\"policy-title\">{{'policy.insuranceStatus'|translate}} <br>\r\n              <span class=\"policy-subtitle active-text\"\r\n                *ngIf=\"currentPolicy?.status == 'active'; else expried\">{{'switchpolicy.active' |\r\n                translate}} </span>\r\n            </p>\r\n            <ng-template #expried>\r\n              <span class=\"status-expired\">{{'switchpolicy.expired' | translate}}\r\n              </span>\r\n            </ng-template>\r\n          </mat-expansion-panel>\r\n        </mat-accordion>\r\n      </div>\r\n\r\n      <div class=\"policy-document\" [hidden]=\"currentPolicy?.status == 'expired' || hideDocuments\">\r\n        <mat-accordion class=\"example-headers-align\">\r\n          <mat-expansion-panel (opened)=\"onExpansionPanel(false)\">\r\n            <mat-expansion-panel-header>\r\n              <mat-panel-title class=\"body-sm\">\r\n                {{'policy.document'|translate}}\r\n              </mat-panel-title>\r\n            </mat-expansion-panel-header>\r\n            <div class=\"border-box\"></div>\r\n            <div *ngIf=\"displayTOB\" class=\"document-title body-n bold\">\r\n              {{'policy.tableOfBenefits'|translate}}\r\n              <i class=\"uil uil-download-alt\" (click)=\"downloadTOB()\"></i>\r\n            </div>\r\n            <div *ngIf=\"displayTC\" class=\"document-title body-n bold\">\r\n              {{'policy.travelCertificate'|translate}}\r\n              <i class=\"uil uil-download-alt\" (click)=\"dowloadTravel()\"></i>\r\n            </div>\r\n            <div *ngIf=\"displayPolicyCert\" class=\"document-title body-n bold\">\r\n              {{'policy.certificateOfInsurance'|translate}}\r\n              <i class=\"uil uil-download-alt\" (click)=\"downloadCertificate()\"></i>\r\n            </div>\r\n\r\n          </mat-expansion-panel>\r\n        </mat-accordion>\r\n      </div>\r\n\r\n      <ion-row>\r\n        <ion-col>\r\n          <div class=\"h5 bold title-search\" *ngIf=\"displayBenefitsHighlight\" [hidden]=\"currentPolicy?.status == 'expired'\">{{'policy.policyBenefits'|translate}}</div>\r\n        </ion-col>\r\n      </ion-row>\r\n      <!-- <div class=\"padding-content\" [hidden]=\"currentPolicy?.status == 'expired'\">\r\n        <nextgen-control [type]=\"TYPE.INPUT\" [placeholder]=\"'policy.search' | translate\" first-icon=\"uil uil-search\"\r\n          (click)=\"providerHandler()\">\r\n        </nextgen-control>\r\n      </div> -->\r\n      <ion-row *ngIf=\"displayBenefitsHighlight\" [hidden]=\"currentPolicy?.status == 'expired'\">\r\n        <ion-col size=\"6\" class=\"benifits\" *ngFor=\"let items of listBenifits\">\r\n          <app-benefits (click)=\"onClickBenifitsCard(items)\"\r\n            [card]=\"items\"></app-benefits>\r\n        </ion-col>\r\n      </ion-row>\r\n\r\n      <!-- out of scope in this phase (phase 1) -->\r\n      <!-- <div class=\"buyplan-text\">\r\n                <span class=\"buy-text body-n bold\">{{'policy.buyPlan'|translate}}</span> <br>\r\n                <span class=\"month-text body-n\">AED 50/month*</span>\r\n            </div> -->\r\n    </ion-grid>\r\n  </div>\r\n</ion-content>";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_home_home_module_ts.js.map