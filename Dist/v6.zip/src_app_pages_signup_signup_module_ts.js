"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_signup_signup_module_ts"],{

/***/ 43586:
/*!*******************************************************************************!*\
  !*** ./src/app/pages/signup/alert-check-email/alert-check-email.component.ts ***!
  \*******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AlertCheckEmailComponent": () => (/* binding */ AlertCheckEmailComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _alert_check_email_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./alert-check-email.component.html?ngResource */ 2036);
/* harmony import */ var _alert_check_email_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./alert-check-email.component.scss?ngResource */ 50158);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var src_app_shared_components_nextgen_dialog_nextgen_dialog_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/shared/components/nextgen-dialog/nextgen-dialog.service */ 96485);





let AlertCheckEmailComponent = class AlertCheckEmailComponent {
    constructor(data) {
        this.data = data;
        this.nameButton = 'button.ok';
        this.valueContent = 'signup.valueCon';
        this.contentError = 'signup.contenErrorInvalidEmail';
        this.isShowButtonCancel = false;
        this.valueContent = this.data.email;
        this.isShowButtonCancel = this.data.showButtonCancel;
    }
    ngOnInit() { }
    onSubmit() {
        window.location.reload();
    }
};
AlertCheckEmailComponent.ctorParameters = () => [
    { type: undefined, decorators: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.Inject, args: [src_app_shared_components_nextgen_dialog_nextgen_dialog_service__WEBPACK_IMPORTED_MODULE_2__.DIALOG_DATA,] }] }
];
AlertCheckEmailComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-alert-check-email',
        template: _alert_check_email_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_alert_check_email_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], AlertCheckEmailComponent);



/***/ }),

/***/ 90392:
/*!*******************************************************!*\
  !*** ./src/app/pages/signup/signup-routing.module.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SignupPageRoutingModule": () => (/* binding */ SignupPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _signup_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./signup.page */ 64374);




const routes = [
    {
        path: '',
        component: _signup_page__WEBPACK_IMPORTED_MODULE_0__.SignupPage,
    }
];
let SignupPageRoutingModule = class SignupPageRoutingModule {
};
SignupPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], SignupPageRoutingModule);



/***/ }),

/***/ 17110:
/*!***********************************************!*\
  !*** ./src/app/pages/signup/signup.module.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SignupPageModule": () => (/* binding */ SignupPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _signup_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./signup-routing.module */ 90392);
/* harmony import */ var _signup_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./signup.page */ 64374);
/* harmony import */ var _angular_material_progress_bar__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/material/progress-bar */ 60833);
/* harmony import */ var src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/shared/shared.module */ 44466);
/* harmony import */ var _alert_check_email_alert_check_email_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./alert-check-email/alert-check-email.component */ 43586);
/* harmony import */ var _show_tearms_cookies_show_tearms_cookies_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./show-tearms-cookies/show-tearms-cookies.component */ 46236);










let SignupPageModule = class SignupPageModule {
};
SignupPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_7__.CommonModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.IonicModule,
            _signup_routing_module__WEBPACK_IMPORTED_MODULE_0__.SignupPageRoutingModule,
            _angular_material_progress_bar__WEBPACK_IMPORTED_MODULE_9__.MatProgressBarModule,
            src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_2__.SharedModule,
        ],
        declarations: [_signup_page__WEBPACK_IMPORTED_MODULE_1__.SignupPage, _show_tearms_cookies_show_tearms_cookies_component__WEBPACK_IMPORTED_MODULE_4__.ShowTearmsCookiesComponent, _alert_check_email_alert_check_email_component__WEBPACK_IMPORTED_MODULE_3__.AlertCheckEmailComponent],
    })
], SignupPageModule);



/***/ }),

/***/ 64374:
/*!*********************************************!*\
  !*** ./src/app/pages/signup/signup.page.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SignupPage": () => (/* binding */ SignupPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _signup_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./signup.page.html?ngResource */ 45722);
/* harmony import */ var _signup_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./signup.page.scss?ngResource */ 62124);
/* harmony import */ var _angular_animations__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! @angular/animations */ 31631);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _awesome_cordova_plugins_app_version_ngx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @awesome-cordova-plugins/app-version/ngx */ 74582);
/* harmony import */ var _awesome_cordova_plugins_clevertap_ngx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @awesome-cordova-plugins/clevertap/ngx */ 45363);
/* harmony import */ var _awesome_cordova_plugins_firebase_analytics_ngx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @awesome-cordova-plugins/firebase-analytics/ngx */ 48852);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @environments/environment */ 92340);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! @ionic/storage-angular */ 80190);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! rxjs/operators */ 59095);
/* harmony import */ var src_app_model_control_control_model__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/model/control/control.model */ 45482);
/* harmony import */ var src_app_service_cms_terms_conditions_terms_conditions_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/service/cms/terms-conditions/terms-conditions.service */ 14315);
/* harmony import */ var src_app_service_language_language_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/service/language/language.service */ 11281);
/* harmony import */ var src_app_service_service_register_service_register_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/service/service-register/service-register.service */ 12829);
/* harmony import */ var src_app_service_signin_signin_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/app/service/signin/signin.service */ 91265);
/* harmony import */ var src_app_service_signup_signup_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/app/service/signup/signup.service */ 71234);
/* harmony import */ var src_app_service_utilities_navigator_service__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! src/app/service/utilities/navigator.service */ 38903);
/* harmony import */ var src_app_shared_components_nextgen_dialog_nextgen_dialog_service__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! src/app/shared/components/nextgen-dialog/nextgen-dialog.service */ 96485);
/* harmony import */ var src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! src/app/shared/data/constants */ 74676);
/* harmony import */ var src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! src/app/shared/data/enum/event */ 38570);
/* harmony import */ var src_app_shared_data_enum_login_type__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! src/app/shared/data/enum/login-type */ 3674);
/* harmony import */ var src_app_shared_data_enum_platform__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! src/app/shared/data/enum/platform */ 8760);
/* harmony import */ var src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! src/app/shared/data/enum/screen */ 68302);
/* harmony import */ var _language_selection_language_selection_component__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ./language-selection/language-selection.component */ 34658);
/* harmony import */ var _show_tearms_cookies_show_tearms_cookies_component__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ./show-tearms-cookies/show-tearms-cookies.component */ 46236);





























let SignupPage = class SignupPage {
    constructor(router, signupService, storage, navCtrl, dialogSevice, fb, signInService, languageService, navigatorHelperService, route, termsConditionsService, firebaseAnalytics, clevertap, registerService, appVersion, platform) {
        this.router = router;
        this.signupService = signupService;
        this.storage = storage;
        this.navCtrl = navCtrl;
        this.dialogSevice = dialogSevice;
        this.fb = fb;
        this.signInService = signInService;
        this.languageService = languageService;
        this.navigatorHelperService = navigatorHelperService;
        this.route = route;
        this.termsConditionsService = termsConditionsService;
        this.firebaseAnalytics = firebaseAnalytics;
        this.clevertap = clevertap;
        this.registerService = registerService;
        this.appVersion = appVersion;
        this.platform = platform;
        this.versionApp = _environments_environment__WEBPACK_IMPORTED_MODULE_5__.environment.appVersion;
        this.largeToSmallState = 'large';
        this.isShowTitleLarge = false;
        this.TYPE = src_app_model_control_control_model__WEBPACK_IMPORTED_MODULE_6__.ControlType; //type input control
        this.showPassword = false; //status password(hide=false/show)
        this.isMobileApp = false;
        this.progressPassword = {
            key: 'error',
            progress: '0%'
        };
        this.isProgressBarPassword = false; // status progressbar control password (hide=false/show)
        this.secondIcon = 'uil uil-eye-slash';
        this.typeInputPassword = this.TYPE.PASSWORD;
        this.messageValidations = [
            {
                key: 'leastOneNumber',
                text: 'signup.atLeast1Number'
            },
            {
                key: 'specialCharacters',
                text: 'signup.atLeast1Symbol'
            },
            {
                key: 'leastCharecters',
                text: 'signup.atLeast8Charecters'
            },
            {
                key: 'leastOneCap',
                text: 'signup.atLeast1CapitalLetter'
            }
        ];
        this.location = 'Dubai, United Arab Emirates';
        this.customValidation = [
            {
                key: 'pattern',
                message: 'validationSummary.email'
            }
        ];
        this.showValidation = false;
        // Build formGroup
        this.signUpForm = this.fb.group({
            email: [''],
            password: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_21__.Validators.required, this.passwordValidation()]],
            isReadAndAccept: [false, [_angular_forms__WEBPACK_IMPORTED_MODULE_21__.Validators.requiredTrue]]
        });
        this.loadPlatformInformation();
    }
    ngOnInit() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_22__.__awaiter)(this, void 0, void 0, function* () {
            try {
                this.versionApp = yield this.appVersion.getVersionNumber();
            }
            catch (error) {
                console.log(error);
            }
            this.getAllLanguage();
            // this.getCountries();
        });
    }
    ionViewDidEnter() {
        this.subscription = this.platform.backButton.subscribeWithPriority(9999, () => {
            this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_18__.Screens.SignIn]);
        });
    }
    ionViewWillLeave() {
        this.subscription.unsubscribe();
    }
    getAllLanguage() {
        if (src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_14__.Constants.LANGUAGE_LIST.length > 0) {
            this.listLanguages = src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_14__.Constants.LANGUAGE_LIST;
            this.filterLanguages();
        }
        else {
            this.languageService.getLanguages().subscribe((data) => (0,tslib__WEBPACK_IMPORTED_MODULE_22__.__awaiter)(this, void 0, void 0, function* () {
                this.listLanguages = data;
                yield this.filterLanguages();
                src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_14__.Constants.LANGUAGE_LIST = this.listLanguages;
            }));
        }
    }
    filterLanguages() {
        var _a;
        return (0,tslib__WEBPACK_IMPORTED_MODULE_22__.__awaiter)(this, void 0, void 0, function* () {
            this.listLanguages = this.listLanguages.filter(_ => _.id != '6');
            this.currentLanguage = window.localStorage.getItem(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_14__.Constants.PREFERED_LANGUAGE);
            this.currentLanguageName = (_a = this.listLanguages.find((x) => x.culture == this.currentLanguage)) === null || _a === void 0 ? void 0 : _a.name;
        });
    }
    onFocusInputEvent() {
        this.showValidation = false;
        this.signUpForm.controls['email'].clearValidators();
        this.signUpForm.controls['email'].updateValueAndValidity();
        if (this.largeToSmallState == 'large') {
            this.largeToSmallState = 'small';
            setTimeout(() => { this.isShowTitleLarge = true; }, 100);
        }
    }
    onFocusPasswordInputEvent() {
        var _a;
        if (this.largeToSmallState == 'large') {
            this.largeToSmallState = 'small';
            setTimeout(() => { this.isShowTitleLarge = true; }, 100);
        }
        if (((_a = this.signUpForm.value.password) === null || _a === void 0 ? void 0 : _a.length) > 0) {
            this.isProgressBarPassword = true;
        }
        else {
            this.isProgressBarPassword = false;
        }
    }
    openDialogLanguage() {
        this.dialogSevice.open(_language_selection_language_selection_component__WEBPACK_IMPORTED_MODULE_19__.LanguageSelectionComponent, {
            data: {
                currentLanguage: this.currentLanguage,
                listLanguages: this.listLanguages
            },
            title: 'signup.languageSelectionTitle',
        }).afterClosed().subscribe((_) => (0,tslib__WEBPACK_IMPORTED_MODULE_22__.__awaiter)(this, void 0, void 0, function* () {
            yield this.filterLanguages();
        }));
    }
    loadPlatformInformation() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_22__.__awaiter)(this, void 0, void 0, function* () {
            const platform = yield this.storage.get(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_14__.Constants.PLATFORM);
            if (platform == src_app_shared_data_enum_platform__WEBPACK_IMPORTED_MODULE_17__.PlatformEnum.Mobile) {
                this.isMobileApp = true;
            }
        });
    }
    passwordValidation() {
        return (control) => {
            const val = control.value;
            const err = {};
            if (!String(val).match(/[0-9]/g)) {
                err.leastOneNumber = true;
            }
            // eslint-disable-next-line no-useless-escape
            if (!String(val).match(/[\!\@\#\_\$\+\%\-]/g)) {
                err.specialCharacters = true;
            }
            if (String(val).length < 8) {
                err.leastCharecters = true;
            }
            if (!String(val).match(/[A-Z]/g)) {
                err.leastOneCap = true;
            }
            const errorCount = Object.keys(err).length;
            if (errorCount > 2) {
                this.progressPassword = {
                    key: 'error',
                    progress: '10%'
                };
            }
            else if (errorCount == 0) {
                this.progressPassword = {
                    key: 'success',
                    progress: '100%'
                };
            }
            else {
                this.progressPassword = {
                    key: 'warning',
                    progress: '50%'
                };
            }
            return err;
        };
    }
    verifyPass(key) {
        const errors = this.signUpForm.controls['password'].errors;
        if (Object.keys(errors).findIndex(e => e === key) === -1) {
            return true;
        }
        else {
            return false;
        }
    }
    togglePassword() {
        this.showPassword = !this.showPassword;
        if (this.showPassword) {
            this.typeInputPassword = this.TYPE.INPUT;
            this.secondIcon = 'uil uil-eye';
        }
        else {
            this.typeInputPassword = this.TYPE.PASSWORD;
            this.secondIcon = 'uil uil-eye-slash';
        }
    }
    createAccount() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_22__.__awaiter)(this, void 0, void 0, function* () {
            // Stop if form is not in valid state
            if (!this.signUpForm.valid) {
                return;
            }
            // if (email === this.emailValidation) {
            //   this.dialogSevice.open<AlertCheckEmailComponent>(AlertCheckEmailComponent, {
            //     data: {
            //       email: email
            //     },
            //     position: 'middle'
            //   });
            //   return;
            // }
            // Save Signup Information
            const value = this.signUpForm.value;
            const deviceId = yield this.storage.get(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_14__.Constants.DEVICE_ID);
            const OSName = this.navigatorHelperService.getOSName();
            const browser = this.navigatorHelperService.getBowserName();
            const appVersion = this.navigatorHelperService.getAppVersion();
            (yield this.registerService.setDeviceId()).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_23__.switchMap)(res => {
                return this.signupService
                    .register({
                    login: value.email,
                    password: value.password,
                    appID: _environments_environment__WEBPACK_IMPORTED_MODULE_5__.environment.AppID,
                    deviceId: deviceId || res,
                    os: OSName,
                    browser,
                    machineName: appVersion,
                });
            })).subscribe(res => {
                // TODO
                // this.router.navigate(['/' + Screens.VerifiAccount]);
                this.firebaseAnalytics.logEvent(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_15__.GA4Event.SignUpCompleted, { user_email: value.email });
                this.clevertap.recordEventWithNameAndProps(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_15__.ClevertapEvent.registration_create_account, { user_id: 0, user_email: value.email });
                this.clevertap.recordEventWithName(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_15__.ClevertapEvent.login_register);
                this.signInService.setBiomatricService(value);
                this.signInService.saveUserInformation(res);
                this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_18__.Screens.OTPVerification], {
                    queryParams: {
                        type: src_app_shared_data_enum_login_type__WEBPACK_IMPORTED_MODULE_16__.LoginType.Email,
                        login: value.email,
                        redirectTo: src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_18__.Screens.addInsurance,
                        message: 'otpPhoneNumber.verify-email-desc',
                        redirectBack: src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_18__.Screens.Home,
                        isShow: false
                    }
                });
            }, err => {
                this.firebaseAnalytics.logEvent(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_15__.GA4Event.SignUpFailed, { user_email: value.email, signup_failure_reason: err.error.message });
                this.clevertap.recordEventWithNameAndProps(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_15__.GA4Event.SignUpFailed, { user_email: value.email, signup_failure_reason: err.error.message });
            });
        });
    }
    getCountries() {
        this.signupService.getContries().subscribe((data) => {
            data.forEach((item) => {
                this.coutryId = item.id;
                this.getZoeLink();
            });
        });
    }
    getZoeLink() {
        const request = {
            countryId: this.coutryId,
        };
        this.signupService.getZoeLink(request).subscribe(data => {
            console.log(data);
        });
    }
    // async getLocation() {
    //   this.location = await this.storage.get(Constants.LOCATION);
    // }
    onBack() {
        this.navCtrl.back();
    }
    redirectToLogin() {
        this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_18__.Screens.SignIn]).then(() => {
        });
    }
    redirectToNeedHelp() {
        this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_18__.Screens.InquiryBeforeLogin], { queryParams: { redirectTo: 'signup' } });
    }
    redirectToTerms() {
        this.termsConditionsService.getTermsConditions().subscribe((data) => {
            this.dialogSevice.open(_show_tearms_cookies_show_tearms_cookies_component__WEBPACK_IMPORTED_MODULE_20__.ShowTearmsCookiesComponent, {
                data: {
                    text: data[0].description,
                },
                title: data[0].title,
                position: 'middle',
                width: '90%',
                height: '100%',
            });
        });
    }
    redirectToPolicy() {
        const request = {
            applicationId: 1,
            cmsUserId: 2
        };
        this.termsConditionsService.getCookiesPolicy(request).subscribe((value) => {
            this.dialogSevice.open(_show_tearms_cookies_show_tearms_cookies_component__WEBPACK_IMPORTED_MODULE_20__.ShowTearmsCookiesComponent, {
                data: {
                    text: value[0].description
                },
                title: value[0].title,
                position: 'middle',
                width: '90%',
                height: '80%'
            });
        });
    }
    redirectToVerifiAccount() {
        this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_18__.Screens.VerifiAccount]);
    }
    onFocusPasswordControl() {
        // 
    }
    focusoutHandler() {
        this.showValidation = true;
        this.signUpForm.controls['email'].setValidators([_angular_forms__WEBPACK_IMPORTED_MODULE_21__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_21__.Validators.pattern(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/)]);
        this.signUpForm.controls['email'].updateValueAndValidity();
    }
    handleControlChange(value) {
        if (value.length > 0) {
            this.isProgressBarPassword = true;
        }
        else {
            this.isProgressBarPassword = false;
        }
    }
    focusoutPasswordHandler() {
        this.isProgressBarPassword = false;
    }
    onPaste(event) {
        const clipboardData = event.clipboardData;
        let content = clipboardData.getData('text');
        if (content.indexOf(' ') >= 0)
            content = content.replace(/\s/g, '');
        this.signUpForm.controls['email'].setValue(content);
        this.signUpForm.controls['email'].updateValueAndValidity();
        event.preventDefault();
    }
    onInput() {
        if (this.email.indexOf(' ') >= 0) {
            this.email = this.email.replace(/\s/g, '');
        }
    }
};
SignupPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_24__.Router },
    { type: src_app_service_signup_signup_service__WEBPACK_IMPORTED_MODULE_11__.SignupService },
    { type: _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_25__.Storage },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_26__.NavController },
    { type: src_app_shared_components_nextgen_dialog_nextgen_dialog_service__WEBPACK_IMPORTED_MODULE_13__.DialogService },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_21__.FormBuilder },
    { type: src_app_service_signin_signin_service__WEBPACK_IMPORTED_MODULE_10__.SigninService },
    { type: src_app_service_language_language_service__WEBPACK_IMPORTED_MODULE_8__.LanguageService },
    { type: src_app_service_utilities_navigator_service__WEBPACK_IMPORTED_MODULE_12__.NavigatorHelperService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_24__.ActivatedRoute },
    { type: src_app_service_cms_terms_conditions_terms_conditions_service__WEBPACK_IMPORTED_MODULE_7__.TermsConditionsService },
    { type: _awesome_cordova_plugins_firebase_analytics_ngx__WEBPACK_IMPORTED_MODULE_4__.FirebaseAnalytics },
    { type: _awesome_cordova_plugins_clevertap_ngx__WEBPACK_IMPORTED_MODULE_3__.CleverTap },
    { type: src_app_service_service_register_service_register_service__WEBPACK_IMPORTED_MODULE_9__.ServiceRegisterService },
    { type: _awesome_cordova_plugins_app_version_ngx__WEBPACK_IMPORTED_MODULE_2__.AppVersion },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_26__.Platform }
];
SignupPage = (0,tslib__WEBPACK_IMPORTED_MODULE_22__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_27__.Component)({
        selector: 'app-signup',
        template: _signup_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        animations: [
            (0,_angular_animations__WEBPACK_IMPORTED_MODULE_28__.trigger)('aniShowTextSmall', [
                (0,_angular_animations__WEBPACK_IMPORTED_MODULE_28__.state)('large', (0,_angular_animations__WEBPACK_IMPORTED_MODULE_28__.style)({})),
                (0,_angular_animations__WEBPACK_IMPORTED_MODULE_28__.state)('small', (0,_angular_animations__WEBPACK_IMPORTED_MODULE_28__.style)({})),
                (0,_angular_animations__WEBPACK_IMPORTED_MODULE_28__.transition)('large => small', (0,_angular_animations__WEBPACK_IMPORTED_MODULE_28__.animate)('0.1s', (0,_angular_animations__WEBPACK_IMPORTED_MODULE_28__.keyframes)([
                    (0,_angular_animations__WEBPACK_IMPORTED_MODULE_28__.style)({
                        opacity: 0.5,
                        transform: 'scale(0.7) translateY(-7rem) translateX(1rem)',
                        position: 'absolute',
                        transition: 'all 0.5s ease-out',
                    }),
                ]))),
            ]),
        ],
        styles: [_signup_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], SignupPage);



/***/ }),

/***/ 50158:
/*!********************************************************************************************!*\
  !*** ./src/app/pages/signup/alert-check-email/alert-check-email.component.scss?ngResource ***!
  \********************************************************************************************/
/***/ ((module) => {

module.exports = ":root {\n  --nc-color-nextgen-neutral-grey-50: #f1efef;\n  --nc-color-nextgen-white: #ffffff;\n  --nc-color-nextgen-blue: #0d152e;\n  --nc-color-nextgen-green: #00908d;\n  --nc-color-nextgen-black: #000000;\n  --nc-color-nextgen-grey-background: #c8d3da;\n  --nc-color-nextgen-grey: #92a2ac;\n  --nc-color-nextgen-stone-grey: #fafafa;\n  --nc-color-nextgen-error: #fc1055;\n  --nc-color-nextgen-neutral-grey: #414141;\n  --nc-color-nextgen-fibrant-green: #00bab6;\n  --nc-color-nextgen-warning: #ffd048;\n  --nc-color-nextgen-green-background: #e6f2f2;\n  --nc-color-nextgen-neutral-grey-400: #7a7a7a;\n  --nc-color-nextgen-neutral-grey-100: #eff3f5;\n  --nc-color-nextgen-status-error: #ba0c3f;\n  --nc-color-nextgen-status-error-background: #ffeff4;\n  --nc-color-nextgen-status-warning: #cba127;\n  --nc-color-nextgen-status-warning-background: #fff8e6;\n  --nc-color-nextgen-blue-100: #dfeff2;\n  --nc-color-nextgen-error-red-700: #f62459;\n  --nc-color-nextgen-blue-500: #006192;\n  --nc-color-nextgen-blue-400: #79cdec;\n  --nc-color-nextgen-red-500: #ff6592;\n  --nc-color-nextgen-secondary-blue-300: #13a0d3;\n  --lumi-white-color: #ffffff;\n  --lumi-primary-yellow-color: #fab600;\n}\n\n.ion-color-green {\n  --ion-color-base: var(--nc-color-nextgen-green);\n  --ion-color-base-rgb: var(--nc-color-nextgen-green);\n  --ion-color-contrast: var(--nc-color-nextgen-white);\n  --ion-color-contrast-rgb: var(--nc-color-nextgen-green);\n  --ion-color-shade: var(--nc-color-nextgen-green);\n  --ion-color-tint: var(--nc-color-nextgen-green);\n}\n\n.header-email-invalid {\n  justify-content: unset !important;\n  display: unset !important;\n  text-align: center;\n  color: var(--nc-color-nextgen-blue);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFxjb2xvci5zY3NzIiwiYWxlcnQtY2hlY2stZW1haWwuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDQywyQ0FBQTtFQUNBLGlDQUFBO0VBQ0EsZ0NBQUE7RUFDQSxpQ0FBQTtFQUNBLGlDQUFBO0VBQ0EsMkNBQUE7RUFDQSxnQ0FBQTtFQUNBLHNDQUFBO0VBQ0EsaUNBQUE7RUFDQSx3Q0FBQTtFQUNBLHlDQUFBO0VBQ0EsbUNBQUE7RUFDQSw0Q0FBQTtFQUNBLDRDQUFBO0VBQ0EsNENBQUE7RUFDQSx3Q0FBQTtFQUNBLG1EQUFBO0VBQ0EsMENBQUE7RUFDQSxxREFBQTtFQUNBLG9DQUFBO0VBQ0EseUNBQUE7RUFDQSxvQ0FBQTtFQUNBLG9DQUFBO0VBQ0EsbUNBQUE7RUFDQSw4Q0FBQTtFQUVBLDJCQUFBO0VBQ0Esb0NBQUE7QUNBRDs7QURnQ0E7RUFDQywrQ0FBQTtFQUNBLG1EQUFBO0VBQ0EsbURBQUE7RUFDQSx1REFBQTtFQUNBLGdEQUFBO0VBQ0EsK0NBQUE7QUM3QkQ7O0FBbkNBO0VBQ0ksaUNBQUE7RUFDQSx5QkFBQTtFQUNBLGtCQUFBO0VBQ0EsbUNEd0JpQjtBQ2NyQiIsImZpbGUiOiJhbGVydC1jaGVjay1lbWFpbC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIjpyb290IHtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTUwOiAjZjFlZmVmO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi13aGl0ZTogI2ZmZmZmZjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZTogIzBkMTUyZTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW46ICMwMDkwOGQ7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWJsYWNrOiAjMDAwMDAwO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ncmV5LWJhY2tncm91bmQ6ICNjOGQzZGE7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWdyZXk6ICM5MmEyYWM7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0b25lLWdyZXk6ICNmYWZhZmE7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWVycm9yOiAjZmMxMDU1O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXk6ICM0MTQxNDE7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWZpYnJhbnQtZ3JlZW46ICMwMGJhYjY7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXdhcm5pbmc6ICNmZmQwNDg7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuLWJhY2tncm91bmQ6ICNlNmYyZjI7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS00MDA6ICM3YTdhN2E7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS0xMDA6ICNlZmYzZjU7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy1lcnJvcjogI2JhMGMzZjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yLWJhY2tncm91bmQ6ICNmZmVmZjQ7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy13YXJuaW5nOiAjY2JhMTI3O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtd2FybmluZy1iYWNrZ3JvdW5kOiAjZmZmOGU2O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlLTEwMDogI2RmZWZmMjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tZXJyb3ItcmVkLTcwMDogI2Y2MjQ1OTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZS01MDA6ICMwMDYxOTI7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWJsdWUtNDAwOiAjNzljZGVjO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1yZWQtNTAwOiAjZmY2NTkyO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zZWNvbmRhcnktYmx1ZS0zMDA6ICMxM2EwZDM7XHJcblxyXG5cdC0tbHVtaS13aGl0ZS1jb2xvcjogI2ZmZmZmZjtcclxuXHQtLWx1bWktcHJpbWFyeS15ZWxsb3ctY29sb3I6ICNmYWI2MDA7XHJcbn1cclxuJGNvbG9yLW5leHRnZW4tYmx1ZTogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlKTtcclxuJGNvbG9yLW5leHRnZW4tZ3JlZW46IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4pO1xyXG4kY29sb3ItbmV4dGdlbi13aGl0ZTogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi13aGl0ZSk7XHJcbiRjb2xvci1uZXh0Z2VuLWJsYWNrOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWJsYWNrKTtcclxuJGNvbG9yLW5leHRnZW4tZ3JleS1iYWNrZ3JvdW5kOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZXktYmFja2dyb3VuZCk7XHJcbiRjb2xvci1uZXh0Z2VuLWdyZXk6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JleSk7XHJcbiRjb2xvci1uZXh0Z2VuLXN0b25lLWdyZXk6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tc3RvbmUtZ3JleSk7XHJcbiRjb2xvci1uZXh0Z2VuLWVycm9yOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWVycm9yKTtcclxuJGNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5OiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleSk7XHJcbiRjb2xvci1uZXh0Z2VuLWZpYnJhbnQtZ3JlZW46IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZmlicmFudC1ncmVlbik7XHJcbiRjb2xvci1uZXh0Z2VuLXdhcm5pbmc6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4td2FybmluZyk7XHJcbiRjb2xvci1uZXh0Z2VuLWdyZWVuLWJhY2tncm91bmQ6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4tYmFja2dyb3VuZCk7XHJcbiRjb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS01MDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNTApO1xyXG4kY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNDAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS00MDApO1xyXG4kY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktMTAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS0xMDApO1xyXG4kY29sb3ItbmV4dGdlbi1zdGF0dXMtZXJyb3I6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yKTtcclxuJGNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yLWJhY2tncm91bmQ6IHZhcihcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yLWJhY2tncm91bmRcclxuKTtcclxuJGNvbG9yLW5leHRnZW4tc3RhdHVzLXdhcm5pbmc6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLXdhcm5pbmcpO1xyXG4kY29sb3ItbmV4dGdlbi1zdGF0dXMtd2FybmluZy1iYWNrZ3JvdW5kOiB2YXIoXHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy13YXJuaW5nLWJhY2tncm91bmRcclxuKTtcclxuJGNvbG9yLW5leHRnZW4tYmx1ZS0xMDA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZS0xMDApO1xyXG4kY29sb3ItbmV4dGdlbi1lcnJvci1yZWQtNzAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWVycm9yLXJlZC03MDApO1xyXG4kY29sb3ItbmV4dGdlbi1ibHVlLTUwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlLTUwMCk7XHJcbiRjb2xvci1uZXh0Z2VuLWJsdWUtNDAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWJsdWUtNDAwKTtcclxuJGNvbG9yLW5leHRnZW4tcmVkLTUwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1yZWQtNTAwKTtcclxuJGNvbG9yLW5leHRnZW4tc2Vjb25kYXJ5LWJsdWUtMzAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXNlY29uZGFyeS1ibHVlLTMwMCk7XHJcblxyXG4uaW9uLWNvbG9yLWdyZWVuIHtcclxuXHQtLWlvbi1jb2xvci1iYXNlOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuKTtcclxuXHQtLWlvbi1jb2xvci1iYXNlLXJnYjogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbik7XHJcblx0LS1pb24tY29sb3ItY29udHJhc3Q6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4td2hpdGUpO1xyXG5cdC0taW9uLWNvbG9yLWNvbnRyYXN0LXJnYjogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbik7XHJcblx0LS1pb24tY29sb3Itc2hhZGU6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4pO1xyXG5cdC0taW9uLWNvbG9yLXRpbnQ6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4pO1xyXG59XHJcbiIsIkBpbXBvcnQgXCIuLi8uLi8uLi8uLi9jb2xvci5zY3NzXCI7XHJcblxyXG4uaGVhZGVyLWVtYWlsLWludmFsaWR7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IHVuc2V0ICFpbXBvcnRhbnQ7XHJcbiAgICBkaXNwbGF5OiB1bnNldCAhaW1wb3J0YW50O1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgY29sb3I6ICRjb2xvci1uZXh0Z2VuLWJsdWU7XHJcbn1cclxuXHJcbiJdfQ== */";

/***/ }),

/***/ 62124:
/*!**********************************************************!*\
  !*** ./src/app/pages/signup/signup.page.scss?ngResource ***!
  \**********************************************************/
/***/ ((module) => {

module.exports = ":root {\n  --nc-color-nextgen-neutral-grey-50: #f1efef;\n  --nc-color-nextgen-white: #ffffff;\n  --nc-color-nextgen-blue: #0d152e;\n  --nc-color-nextgen-green: #00908d;\n  --nc-color-nextgen-black: #000000;\n  --nc-color-nextgen-grey-background: #c8d3da;\n  --nc-color-nextgen-grey: #92a2ac;\n  --nc-color-nextgen-stone-grey: #fafafa;\n  --nc-color-nextgen-error: #fc1055;\n  --nc-color-nextgen-neutral-grey: #414141;\n  --nc-color-nextgen-fibrant-green: #00bab6;\n  --nc-color-nextgen-warning: #ffd048;\n  --nc-color-nextgen-green-background: #e6f2f2;\n  --nc-color-nextgen-neutral-grey-400: #7a7a7a;\n  --nc-color-nextgen-neutral-grey-100: #eff3f5;\n  --nc-color-nextgen-status-error: #ba0c3f;\n  --nc-color-nextgen-status-error-background: #ffeff4;\n  --nc-color-nextgen-status-warning: #cba127;\n  --nc-color-nextgen-status-warning-background: #fff8e6;\n  --nc-color-nextgen-blue-100: #dfeff2;\n  --nc-color-nextgen-error-red-700: #f62459;\n  --nc-color-nextgen-blue-500: #006192;\n  --nc-color-nextgen-blue-400: #79cdec;\n  --nc-color-nextgen-red-500: #ff6592;\n  --nc-color-nextgen-secondary-blue-300: #13a0d3;\n  --lumi-white-color: #ffffff;\n  --lumi-primary-yellow-color: #fab600;\n}\n\n.ion-color-green {\n  --ion-color-base: var(--nc-color-nextgen-green);\n  --ion-color-base-rgb: var(--nc-color-nextgen-green);\n  --ion-color-contrast: var(--nc-color-nextgen-white);\n  --ion-color-contrast-rgb: var(--nc-color-nextgen-green);\n  --ion-color-shade: var(--nc-color-nextgen-green);\n  --ion-color-tint: var(--nc-color-nextgen-green);\n}\n\n.sign-up-container {\n  background: var(--nc-color-nextgen-neutral-grey-50);\n}\n\n.need-help-text {\n  color: var(--nc-color-nextgen-green);\n  float: right !important;\n}\n\n.sign-up-header {\n  width: 100%;\n  justify-content: space-between;\n  display: flex;\n  align-items: center;\n}\n\n.sign-up-header .need-help-text {\n  color: var(--nc-color-nextgen-green);\n}\n\n.title-text {\n  align-items: center;\n  display: flex;\n  justify-content: center;\n}\n\n.title-text span {\n  color: var(--nc-color-nextgen-blue);\n}\n\n.top-section-focus {\n  justify-content: unset !important;\n}\n\n.sign-up-title {\n  letter-spacing: -1px;\n  color: var(--nc-color-nextgen-black);\n  padding-top: 24px;\n}\n\n.form-sign-up {\n  width: 100%;\n  padding-top: 2rem;\n}\n\n.read-accept {\n  padding-top: 1rem;\n  display: flex;\n}\n\n.text-read-accept {\n  color: color-nextgen-neutral-grey;\n}\n\n.text-account-login {\n  text-align: center;\n  padding-top: 32px;\n}\n\n.button-create-account {\n  text-align: center;\n  padding-top: 24px;\n}\n\n.button-language {\n  text-align: center;\n  justify-content: center;\n  display: flex;\n  align-items: flex-end;\n  padding-top: 120px;\n}\n\n.text-link {\n  color: var(--nc-color-nextgen-green) !important;\n}\n\n.icon-input {\n  color: var(--nc-color-nextgen-grey);\n}\n\n.validation-summary-password {\n  list-style: none;\n}\n\n.validation-summary-password li {\n  display: flex;\n}\n\n.validation-summary-password li .check-place {\n  color: var(--nc-color-nextgen-green) !important;\n}\n\n.text-validation {\n  color: var(--nc-color-nextgen-grey) !important;\n}\n\n.check-place {\n  width: 22px;\n  height: auto;\n}\n\n.check-box-read-accept {\n  display: block;\n  position: relative;\n  cursor: pointer;\n}\n\n/* Hide the browser's default checkbox */\n\n.check-box-read-accept input {\n  position: absolute;\n  opacity: 0;\n  cursor: pointer;\n  height: 0;\n  width: 0;\n}\n\n/* Create a custom checkbox */\n\n.checkmark {\n  position: absolute;\n  height: 18px;\n  width: 18px;\n  border: solid var(--nc-color-nextgen-grey) 2px;\n  border-radius: 3px;\n}\n\n.check-box-read-accept input:checked ~ .checkmark {\n  background-color: var(--nc-color-nextgen-green);\n}\n\n.checkmark:after {\n  content: \"\";\n  position: absolute;\n  display: none;\n}\n\n.check-box-read-accept input:checked ~ .checkmark:after {\n  display: block;\n}\n\n.check-box-read-accept .checkmark:after {\n  left: 5px;\n  top: 1px;\n  width: 5px;\n  height: 10px;\n  border: solid var(--nc-color-nextgen-white);\n  border-width: 0 3px 3px 0;\n  transform: rotate(45deg);\n}\n\n.icon-language {\n  color: var(--nc-color-nextgen-green) !important;\n}\n\n.text-current-language {\n  padding-left: 0.5rem;\n  padding-right: 0.5rem;\n  color: var(--nc-color-nextgen-green) !important;\n}\n\n.control-aria {\n  padding-bottom: 24px;\n}\n\nion-checkbox {\n  size: 18px;\n  --background-checked: #00908d;\n  --checkmark-color: #ffffff;\n  --background: transparent;\n  --checkmark-width: 5px;\n}\n\nion-checkbox::part(container) {\n  border: solid #92a2ac 2px;\n  border-radius: 3px;\n}\n\n.version-app {\n  text-align: center;\n  color: var(--nc-color-nextgen-black);\n  padding-top: 1.8rem;\n}\n\nion-icon {\n  height: 11px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXGNvbG9yLnNjc3MiLCJzaWdudXAucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0MsMkNBQUE7RUFDQSxpQ0FBQTtFQUNBLGdDQUFBO0VBQ0EsaUNBQUE7RUFDQSxpQ0FBQTtFQUNBLDJDQUFBO0VBQ0EsZ0NBQUE7RUFDQSxzQ0FBQTtFQUNBLGlDQUFBO0VBQ0Esd0NBQUE7RUFDQSx5Q0FBQTtFQUNBLG1DQUFBO0VBQ0EsNENBQUE7RUFDQSw0Q0FBQTtFQUNBLDRDQUFBO0VBQ0Esd0NBQUE7RUFDQSxtREFBQTtFQUNBLDBDQUFBO0VBQ0EscURBQUE7RUFDQSxvQ0FBQTtFQUNBLHlDQUFBO0VBQ0Esb0NBQUE7RUFDQSxvQ0FBQTtFQUNBLG1DQUFBO0VBQ0EsOENBQUE7RUFFQSwyQkFBQTtFQUNBLG9DQUFBO0FDQUQ7O0FEZ0NBO0VBQ0MsK0NBQUE7RUFDQSxtREFBQTtFQUNBLG1EQUFBO0VBQ0EsdURBQUE7RUFDQSxnREFBQTtFQUNBLCtDQUFBO0FDN0JEOztBQW5DQTtFQUNJLG1ERHVDNEI7QUNEaEM7O0FBbkNBO0VBQ0ksb0NEd0JrQjtFQ3ZCbEIsdUJBQUE7QUFzQ0o7O0FBbkNBO0VBQ0ksV0FBQTtFQUNJLDhCQUFBO0VBQ0EsYUFBQTtFQUNBLG1CQUFBO0FBc0NSOztBQXJDUTtFQUNJLG9DRGNVO0FDeUJ0Qjs7QUFuQ0E7RUFDSSxtQkFBQTtFQUNBLGFBQUE7RUFDQSx1QkFBQTtBQXNDSjs7QUFyQ0k7RUFDSSxtQ0RJYTtBQ21DckI7O0FBbkNBO0VBQ0ksaUNBQUE7QUFzQ0o7O0FBbkNBO0VBQ0ksb0JBQUE7RUFDQSxvQ0RIa0I7RUNJbEIsaUJBQUE7QUFzQ0o7O0FBbkNBO0VBQ0ksV0FBQTtFQUNBLGlCQUFBO0FBc0NKOztBQW5DQTtFQUNJLGlCQUFBO0VBQ0EsYUFBQTtBQXNDSjs7QUFuQ0E7RUFFSSxpQ0FBQTtBQXFDSjs7QUFsQ0E7RUFDSSxrQkFBQTtFQUNBLGlCQUFBO0FBcUNKOztBQWxDQTtFQUNJLGtCQUFBO0VBQ0EsaUJBQUE7QUFxQ0o7O0FBbENBO0VBQ0ksa0JBQUE7RUFDQSx1QkFBQTtFQUNBLGFBQUE7RUFDQSxxQkFBQTtFQUNBLGtCQUFBO0FBcUNKOztBQWxDQTtFQUNJLCtDQUFBO0FBcUNKOztBQWxDQTtFQUNJLG1DRDNDaUI7QUNnRnJCOztBQWxDQTtFQUNJLGdCQUFBO0FBcUNKOztBQW5DSTtFQUNJLGFBQUE7QUFxQ1I7O0FBbkNRO0VBQ0ksK0NBQUE7QUFxQ1o7O0FBaENBO0VBQ0ksOENBQUE7QUFtQ0o7O0FBaENBO0VBQ0ksV0FBQTtFQUNBLFlBQUE7QUFtQ0o7O0FBOUJBO0VBQ0ksY0FBQTtFQUNBLGtCQUFBO0VBQ0EsZUFBQTtBQWlDSjs7QUE5QkEsd0NBQUE7O0FBQ0E7RUFDSSxrQkFBQTtFQUNBLFVBQUE7RUFDQSxlQUFBO0VBQ0EsU0FBQTtFQUNBLFFBQUE7QUFpQ0o7O0FBOUJBLDZCQUFBOztBQUNBO0VBQ0ksa0JBQUE7RUFDQSxZQUFBO0VBQ0EsV0FBQTtFQUNBLDhDQUFBO0VBQ0Esa0JBQUE7QUFpQ0o7O0FBOUJBO0VBQ0ksK0NEbEdrQjtBQ21JdEI7O0FBOUJBO0VBQ0ksV0FBQTtFQUNBLGtCQUFBO0VBQ0EsYUFBQTtBQWlDSjs7QUE5QkE7RUFDSSxjQUFBO0FBaUNKOztBQTlCQTtFQUNJLFNBQUE7RUFDQSxRQUFBO0VBQ0EsVUFBQTtFQUNBLFlBQUE7RUFDQSwyQ0FBQTtFQUNBLHlCQUFBO0VBQ0Esd0JBQUE7QUFpQ0o7O0FBOUJBO0VBQ0ksK0NBQUE7QUFpQ0o7O0FBOUJBO0VBQ0ksb0JBQUE7RUFDQSxxQkFBQTtFQUNBLCtDQUFBO0FBaUNKOztBQS9CQTtFQUNJLG9CQUFBO0FBa0NKOztBQWhDQTtFQUNJLFVBQUE7RUFDQSw2QkFBQTtFQUNBLDBCQUFBO0VBQ0EseUJBQUE7RUFDQSxzQkFBQTtBQW1DSjs7QUFoQ0U7RUFDRSx5QkFBQTtFQUNBLGtCQUFBO0FBbUNKOztBQWhDRTtFQUNFLGtCQUFBO0VBQ0Esb0NEbEprQjtFQ21KbEIsbUJBQUE7QUFtQ0o7O0FBakNFO0VBQ0UsWUFBQTtBQW9DSiIsImZpbGUiOiJzaWdudXAucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiOnJvb3Qge1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNTA6ICNmMWVmZWY7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXdoaXRlOiAjZmZmZmZmO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlOiAjMGQxNTJlO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbjogIzAwOTA4ZDtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tYmxhY2s6ICMwMDAwMDA7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWdyZXktYmFja2dyb3VuZDogI2M4ZDNkYTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tZ3JleTogIzkyYTJhYztcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc3RvbmUtZ3JleTogI2ZhZmFmYTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tZXJyb3I6ICNmYzEwNTU7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleTogIzQxNDE0MTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tZmlicmFudC1ncmVlbjogIzAwYmFiNjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4td2FybmluZzogI2ZmZDA0ODtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4tYmFja2dyb3VuZDogI2U2ZjJmMjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTQwMDogIzdhN2E3YTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTEwMDogI2VmZjNmNTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yOiAjYmEwYzNmO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtZXJyb3ItYmFja2dyb3VuZDogI2ZmZWZmNDtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLXdhcm5pbmc6ICNjYmExMjc7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy13YXJuaW5nLWJhY2tncm91bmQ6ICNmZmY4ZTY7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWJsdWUtMTAwOiAjZGZlZmYyO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1lcnJvci1yZWQtNzAwOiAjZjYyNDU5O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlLTUwMDogIzAwNjE5MjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZS00MDA6ICM3OWNkZWM7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXJlZC01MDA6ICNmZjY1OTI7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXNlY29uZGFyeS1ibHVlLTMwMDogIzEzYTBkMztcclxuXHJcblx0LS1sdW1pLXdoaXRlLWNvbG9yOiAjZmZmZmZmO1xyXG5cdC0tbHVtaS1wcmltYXJ5LXllbGxvdy1jb2xvcjogI2ZhYjYwMDtcclxufVxyXG4kY29sb3ItbmV4dGdlbi1ibHVlOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWJsdWUpO1xyXG4kY29sb3ItbmV4dGdlbi1ncmVlbjogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbik7XHJcbiRjb2xvci1uZXh0Z2VuLXdoaXRlOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXdoaXRlKTtcclxuJGNvbG9yLW5leHRnZW4tYmxhY2s6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tYmxhY2spO1xyXG4kY29sb3ItbmV4dGdlbi1ncmV5LWJhY2tncm91bmQ6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JleS1iYWNrZ3JvdW5kKTtcclxuJGNvbG9yLW5leHRnZW4tZ3JleTogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmV5KTtcclxuJGNvbG9yLW5leHRnZW4tc3RvbmUtZ3JleTogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1zdG9uZS1ncmV5KTtcclxuJGNvbG9yLW5leHRnZW4tZXJyb3I6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZXJyb3IpO1xyXG4kY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXk6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5KTtcclxuJGNvbG9yLW5leHRnZW4tZmlicmFudC1ncmVlbjogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1maWJyYW50LWdyZWVuKTtcclxuJGNvbG9yLW5leHRnZW4td2FybmluZzogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi13YXJuaW5nKTtcclxuJGNvbG9yLW5leHRnZW4tZ3JlZW4tYmFja2dyb3VuZDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbi1iYWNrZ3JvdW5kKTtcclxuJGNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTUwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS01MCk7XHJcbiRjb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS00MDA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTQwMCk7XHJcbiRjb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS0xMDA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTEwMCk7XHJcbiRjb2xvci1uZXh0Z2VuLXN0YXR1cy1lcnJvcjogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtZXJyb3IpO1xyXG4kY29sb3ItbmV4dGdlbi1zdGF0dXMtZXJyb3ItYmFja2dyb3VuZDogdmFyKFxyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtZXJyb3ItYmFja2dyb3VuZFxyXG4pO1xyXG4kY29sb3ItbmV4dGdlbi1zdGF0dXMtd2FybmluZzogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtd2FybmluZyk7XHJcbiRjb2xvci1uZXh0Z2VuLXN0YXR1cy13YXJuaW5nLWJhY2tncm91bmQ6IHZhcihcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLXdhcm5pbmctYmFja2dyb3VuZFxyXG4pO1xyXG4kY29sb3ItbmV4dGdlbi1ibHVlLTEwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlLTEwMCk7XHJcbiRjb2xvci1uZXh0Z2VuLWVycm9yLXJlZC03MDA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZXJyb3ItcmVkLTcwMCk7XHJcbiRjb2xvci1uZXh0Z2VuLWJsdWUtNTAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWJsdWUtNTAwKTtcclxuJGNvbG9yLW5leHRnZW4tYmx1ZS00MDA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZS00MDApO1xyXG4kY29sb3ItbmV4dGdlbi1yZWQtNTAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXJlZC01MDApO1xyXG4kY29sb3ItbmV4dGdlbi1zZWNvbmRhcnktYmx1ZS0zMDA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tc2Vjb25kYXJ5LWJsdWUtMzAwKTtcclxuXHJcbi5pb24tY29sb3ItZ3JlZW4ge1xyXG5cdC0taW9uLWNvbG9yLWJhc2U6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4pO1xyXG5cdC0taW9uLWNvbG9yLWJhc2UtcmdiOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuKTtcclxuXHQtLWlvbi1jb2xvci1jb250cmFzdDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi13aGl0ZSk7XHJcblx0LS1pb24tY29sb3ItY29udHJhc3QtcmdiOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuKTtcclxuXHQtLWlvbi1jb2xvci1zaGFkZTogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbik7XHJcblx0LS1pb24tY29sb3ItdGludDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbik7XHJcbn1cclxuIiwiQGltcG9ydCBcIi4uLy4uLy4uL2NvbG9yLnNjc3NcIjtcclxuXHJcbi5zaWduLXVwLWNvbnRhaW5lciB7XHJcbiAgICBiYWNrZ3JvdW5kOiAkY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNTA7XHJcbn1cclxuXHJcbi5uZWVkLWhlbHAtdGV4dCB7XHJcbiAgICBjb2xvcjogJGNvbG9yLW5leHRnZW4tZ3JlZW47XHJcbiAgICBmbG9hdDogcmlnaHQgIWltcG9ydGFudDtcclxufVxyXG5cclxuLnNpZ24tdXAtaGVhZGVye1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICAgICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xyXG4gICAgICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgICAgICAubmVlZC1oZWxwLXRleHQge1xyXG4gICAgICAgICAgICBjb2xvcjogJGNvbG9yLW5leHRnZW4tZ3JlZW47XHJcbiAgICAgICAgfVxyXG59XHJcblxyXG4udGl0bGUtdGV4dCB7XHJcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgc3BhbiB7XHJcbiAgICAgICAgY29sb3I6ICRjb2xvci1uZXh0Z2VuLWJsdWU7XHJcbiAgICB9XHJcbn1cclxuXHJcbi50b3Atc2VjdGlvbi1mb2N1cyB7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IHVuc2V0ICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5zaWduLXVwLXRpdGxlIHtcclxuICAgIGxldHRlci1zcGFjaW5nOiAtMXB4O1xyXG4gICAgY29sb3I6ICRjb2xvci1uZXh0Z2VuLWJsYWNrO1xyXG4gICAgcGFkZGluZy10b3A6IDI0cHg7XHJcbn1cclxuXHJcbi5mb3JtLXNpZ24tdXAge1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBwYWRkaW5nLXRvcDogMnJlbTtcclxufVxyXG5cclxuLnJlYWQtYWNjZXB0IHtcclxuICAgIHBhZGRpbmctdG9wOiAxcmVtO1xyXG4gICAgZGlzcGxheTogZmxleDtcclxufVxyXG5cclxuLnRleHQtcmVhZC1hY2NlcHQge1xyXG4gICAgXHJcbiAgICBjb2xvcjogY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXk7XHJcbn1cclxuXHJcbi50ZXh0LWFjY291bnQtbG9naW4ge1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgcGFkZGluZy10b3A6IDMycHg7XHJcbn1cclxuXHJcbi5idXR0b24tY3JlYXRlLWFjY291bnQge1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgcGFkZGluZy10b3A6IDI0cHg7XHJcbn1cclxuXHJcbi5idXR0b24tbGFuZ3VhZ2Uge1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgYWxpZ24taXRlbXM6IGZsZXgtZW5kO1xyXG4gICAgcGFkZGluZy10b3A6MTIwcHg7XHJcbn1cclxuXHJcbi50ZXh0LWxpbmsge1xyXG4gICAgY29sb3I6ICRjb2xvci1uZXh0Z2VuLWdyZWVuICAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4uaWNvbi1pbnB1dCB7XHJcbiAgICBjb2xvcjogJGNvbG9yLW5leHRnZW4tZ3JleTtcclxufVxyXG5cclxuLnZhbGlkYXRpb24tc3VtbWFyeS1wYXNzd29yZCB7XHJcbiAgICBsaXN0LXN0eWxlOiBub25lO1xyXG5cclxuICAgIGxpIHtcclxuICAgICAgICBkaXNwbGF5OiBmbGV4O1xyXG5cclxuICAgICAgICAuY2hlY2stcGxhY2Uge1xyXG4gICAgICAgICAgICBjb2xvcjogJGNvbG9yLW5leHRnZW4tZ3JlZW4gICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59XHJcblxyXG4udGV4dC12YWxpZGF0aW9uIHtcclxuICAgIGNvbG9yOiAkY29sb3ItbmV4dGdlbi1ncmV5ICAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4uY2hlY2stcGxhY2Uge1xyXG4gICAgd2lkdGg6IDIycHg7XHJcbiAgICBoZWlnaHQ6IGF1dG87XHJcbn1cclxuXHJcblxyXG4vL0NoZWNrIGJveFxyXG4uY2hlY2stYm94LXJlYWQtYWNjZXB0IHtcclxuICAgIGRpc3BsYXk6IGJsb2NrO1xyXG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgY3Vyc29yOiBwb2ludGVyO1xyXG59XHJcblxyXG4vKiBIaWRlIHRoZSBicm93c2VyJ3MgZGVmYXVsdCBjaGVja2JveCAqL1xyXG4uY2hlY2stYm94LXJlYWQtYWNjZXB0IGlucHV0IHtcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIG9wYWNpdHk6IDA7XHJcbiAgICBjdXJzb3I6IHBvaW50ZXI7XHJcbiAgICBoZWlnaHQ6IDA7XHJcbiAgICB3aWR0aDogMDtcclxufVxyXG5cclxuLyogQ3JlYXRlIGEgY3VzdG9tIGNoZWNrYm94ICovXHJcbi5jaGVja21hcmsge1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgaGVpZ2h0OiAxOHB4O1xyXG4gICAgd2lkdGg6IDE4cHg7XHJcbiAgICBib3JkZXI6IHNvbGlkICRjb2xvci1uZXh0Z2VuLWdyZXkgMnB4O1xyXG4gICAgYm9yZGVyLXJhZGl1czogM3B4O1xyXG59XHJcblxyXG4uY2hlY2stYm94LXJlYWQtYWNjZXB0IGlucHV0OmNoZWNrZWR+LmNoZWNrbWFyayB7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAkY29sb3ItbmV4dGdlbi1ncmVlbjtcclxufVxyXG5cclxuLmNoZWNrbWFyazphZnRlciB7XHJcbiAgICBjb250ZW50OiBcIlwiO1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgZGlzcGxheTogbm9uZTtcclxufVxyXG5cclxuLmNoZWNrLWJveC1yZWFkLWFjY2VwdCBpbnB1dDpjaGVja2Vkfi5jaGVja21hcms6YWZ0ZXIge1xyXG4gICAgZGlzcGxheTogYmxvY2s7XHJcbn1cclxuXHJcbi5jaGVjay1ib3gtcmVhZC1hY2NlcHQgLmNoZWNrbWFyazphZnRlciB7XHJcbiAgICBsZWZ0OiA1cHg7XHJcbiAgICB0b3A6IDFweDtcclxuICAgIHdpZHRoOiA1cHg7XHJcbiAgICBoZWlnaHQ6IDEwcHg7XHJcbiAgICBib3JkZXI6IHNvbGlkICRjb2xvci1uZXh0Z2VuLXdoaXRlO1xyXG4gICAgYm9yZGVyLXdpZHRoOiAwIDNweCAzcHggMDtcclxuICAgIHRyYW5zZm9ybTogcm90YXRlKDQ1ZGVnKTtcclxufVxyXG5cclxuLmljb24tbGFuZ3VhZ2Uge1xyXG4gICAgY29sb3I6ICRjb2xvci1uZXh0Z2VuLWdyZWVuICAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4udGV4dC1jdXJyZW50LWxhbmd1YWdlIHtcclxuICAgIHBhZGRpbmctbGVmdDogMC41cmVtO1xyXG4gICAgcGFkZGluZy1yaWdodDogMC41cmVtO1xyXG4gICAgY29sb3I6ICRjb2xvci1uZXh0Z2VuLWdyZWVuICAhaW1wb3J0YW50O1xyXG4gIH1cclxuLmNvbnRyb2wtYXJpYXtcclxuICAgIHBhZGRpbmctYm90dG9tIDogMjRweDtcclxufVxyXG5pb24tY2hlY2tib3gge1xyXG4gICAgc2l6ZTogMThweDtcclxuICAgIC0tYmFja2dyb3VuZC1jaGVja2VkOiAjMDA5MDhkO1xyXG4gICAgLS1jaGVja21hcmstY29sb3I6ICNmZmZmZmY7XHJcbiAgICAtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xyXG4gICAgLS1jaGVja21hcmstd2lkdGg6IDVweDtcclxuICB9XHJcbiAgXHJcbiAgaW9uLWNoZWNrYm94OjpwYXJ0KGNvbnRhaW5lcikge1xyXG4gICAgYm9yZGVyOiBzb2xpZCAjOTJhMmFjIDJweDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDNweDtcclxuICB9XHJcblxyXG4gIC52ZXJzaW9uLWFwcHtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIGNvbG9yOiAkY29sb3ItbmV4dGdlbi1ibGFjaztcclxuICAgIHBhZGRpbmctdG9wOiAxLjhyZW07XHJcbiAgfVxyXG4gIGlvbi1pY29ue1xyXG4gICAgaGVpZ2h0OiAxMXB4O1xyXG4gIH1cclxuICAiXX0= */";

/***/ }),

/***/ 2036:
/*!********************************************************************************************!*\
  !*** ./src/app/pages/signup/alert-check-email/alert-check-email.component.html?ngResource ***!
  \********************************************************************************************/
/***/ ((module) => {

module.exports = "<div class=\"container\">\r\n  <div class=\"top-section header-email-invalid\">\r\n    <div class=\"h3 bold\">{{'signup.invalidRegistration' | translate}}</div>\r\n  </div>\r\n  <div class=\"body-section\">\r\n    <body-error-dialog [nameButtonSubmit]=\"nameButton| translate\" [valueContent]=\"valueContent| translate\"\r\n      (onSubmitHandler)=\"onSubmit()\" [contentError]=\"contentError| translate\">\r\n\r\n    </body-error-dialog>\r\n\r\n  </div>";

/***/ }),

/***/ 45722:
/*!**********************************************************!*\
  !*** ./src/app/pages/signup/signup.page.html?ngResource ***!
  \**********************************************************/
/***/ ((module) => {

module.exports = "<div class=\"sign-up-container\">\r\n  <nextcare-layout>\r\n    <ng-template header>\r\n      <ion-row>\r\n        <ng-container *ngIf=\"isShowTitleLarge\">\r\n          <div class=\"sign-up-header\">\r\n            <div  class=\"d-flex\">\r\n              <!-- <button class=\"btn btn-circle\" (click)=\"onBack()\"><i class=\"icon-back body-l\"></i></button> -->\r\n            </div>\r\n            <div  class=\"row\">\r\n              <span class=\"title-text h6 bold\">{{ 'signup.title' | translate }}</span>\r\n            </div>\r\n            <div  class=\"row\">\r\n              <span class=\"need-help-text body-l bold\" (click)=\"redirectToNeedHelp()\">{{\r\n              'signup.needHelp' |\r\n              translate }}</span>\r\n            </div>\r\n          </div>\r\n        </ng-container>\r\n        <ng-container *ngIf=\"!isShowTitleLarge\">\r\n          <ion-col size=\"6\" class=\"d-flex\">\r\n            <!-- <button class=\"btn btn-circle\" (click)=\"onBack()\"><i class=\"icon-back body-l\"></i></button> -->\r\n          </ion-col>\r\n          <ion-col size=\"6\">\r\n            <span class=\"need-help-text body-l bold\" (click)=\"redirectToNeedHelp()\">{{\r\n              'signup.needHelp' |\r\n              translate }}</span>\r\n          </ion-col>\r\n        </ng-container>\r\n      </ion-row>\r\n    </ng-template>\r\n    <ng-template body>\r\n      <div class=\"sign-up-content col-12\">\r\n        <div class=\"col-7\">\r\n          <div class=\"sign-up-title h1 bold\" *ngIf=\"!isShowTitleLarge\" [@aniShowTextSmall]='largeToSmallState'>\r\n            {{'signup.title' | translate}}\r\n          </div>\r\n        </div>\r\n        <div>\r\n          <form class=\"form-sign-up\" [formGroup]=\"signUpForm\">\r\n            <div class=\"control-aria\">\r\n              <nextgen-control [type]=\"TYPE.INPUT\" [label-property]=\"'signup.email' | translate\"\r\n                (focusHandler)=\"onFocusInputEvent()\" [placeholder]=\"'signup.emailPlaceholder' | translate\"\r\n                (focusoutHandler)=\"focusoutHandler()\"\r\n                first-icon=\"uil uil-envelope\" formControlName=\"email\"\r\n                [(ngModel)]=\"email\"\r\n                (keyup)=\"onInput()\"\r\n                (paste)=\"onPaste($event)\"\r\n                [showValidation]=\"showValidation\"\r\n                [custom-validation]=\"customValidation\"                \r\n                >\r\n              </nextgen-control>\r\n            </div>\r\n            <div>\r\n              <nextgen-control [type]=\"typeInputPassword\" [label-property]=\"'signup.password' | translate\"\r\n                [placeholder]=\"'signup.passwordPlaceholder' | translate\" first-icon=\"uil uil-lock-alt\"\r\n                [progress-status]=\"progressPassword\" [has-progress-bar]=\"isProgressBarPassword\"\r\n                [second-icon]=\"secondIcon\" (secondIconHandler)=\"togglePassword()\" formControlName=\"password\"\r\n                (focusHandler)=\"onFocusPasswordInputEvent()\" [native-template]=\"nativeTemplateValidation\"\r\n                (ngModelChange)=\"handleControlChange($event)\"    \r\n                (focusoutHandler)=\"focusoutPasswordHandler()\"             \r\n                >\r\n              </nextgen-control>\r\n              <ng-template #nativeTemplateValidation >\r\n                <ul class=\"validation-summary-password\" *ngIf=\"isProgressBarPassword\">\r\n                  <li *ngFor=\"let val of messageValidations\">\r\n                    <div class=\"check-place\">\r\n                      <i [ngClass]=\"verifyPass(val.key)?'uis uis-check-circle':''\" class=\"check-place mr-1\"></i>\r\n                    </div>\r\n                    <span class=\"text-validation\">{{val.text| translate}}</span>\r\n                  </li>\r\n                </ul>\r\n              </ng-template>\r\n            </div>\r\n            <div class=\"read-accept\">\r\n              <ion-grid>\r\n                <ion-row>\r\n                  <ion-col size=\"1\">\r\n                    <span>\r\n                      <ion-checkbox mode=\"md\"  formControlName=\"isReadAndAccept\"></ion-checkbox>\r\n                    </span>\r\n                  </ion-col>\r\n            <ion-col size=\"11\">\r\n              <span class=\"body-sm text-read-accept\">\r\n                <span>{{'signup.termsAndPolicy1'| translate}}</span>\r\n                <span class=\"text-link\" (click)=\"redirectToTerms()\">{{'signup.termsAndPolicyValue2'| translate}}</span>\r\n                <span>{{'signup.termsAndPolicy3'| translate}}</span>\r\n                <span class=\"text-link\" (click)=\"redirectToPolicy()\">{{'signup.termsAndPolicyValue4'| translate}}</span>\r\n              </span>\r\n              </ion-col>\r\n            </ion-row>\r\n            </ion-grid>\r\n            </div>\r\n            <div class=\"button-create-account\">\r\n              <button class=\"btn btn-large primary bold\" [disabled]=\"signUpForm.invalid\" (click)=\"createAccount()\">{{\r\n                'signup.createAccount' | translate }}</button>\r\n            </div>\r\n            <div class=\"text-account-login\">\r\n              <span class=\"body-n\">{{'signup.haveAnAccount'| translate}}</span>\r\n              <span class=\"body-n bold text-link\" (click)=\"redirectToLogin()\">{{'signup.login'| translate}}</span>\r\n            </div>\r\n          </form>\r\n        </div>\r\n      </div>\r\n      <div class=\"button-language\">\r\n        <button class=\"btn transparent btn-no-space semibold body-sm\" (click)=\"openDialogLanguage()\">\r\n          <i class=\"uil uil-globe icon-language\"></i>\r\n          <span class=\"text-current-language\">{{currentLanguageName}}</span>\r\n          <!-- <img src=\"../../../assets/icon/Polygon.svg\" /> -->\r\n          <ion-icon class=\"uil\" name=\"caret-forward-outline\"></ion-icon>\r\n        </button>\r\n      </div>\r\n      <p class=\"version-app body-xs\">{{'home.appversion' | translate}} {{versionApp}}</p>\r\n    </ng-template>\r\n  </nextcare-layout>\r\n</div>";

/***/ }),

/***/ 60833:
/*!******************************************************************!*\
  !*** ./node_modules/@angular/material/fesm2015/progress-bar.mjs ***!
  \******************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MAT_PROGRESS_BAR_DEFAULT_OPTIONS": () => (/* binding */ MAT_PROGRESS_BAR_DEFAULT_OPTIONS),
/* harmony export */   "MAT_PROGRESS_BAR_LOCATION": () => (/* binding */ MAT_PROGRESS_BAR_LOCATION),
/* harmony export */   "MAT_PROGRESS_BAR_LOCATION_FACTORY": () => (/* binding */ MAT_PROGRESS_BAR_LOCATION_FACTORY),
/* harmony export */   "MatProgressBar": () => (/* binding */ MatProgressBar),
/* harmony export */   "MatProgressBarModule": () => (/* binding */ MatProgressBarModule)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _angular_material_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/material/core */ 88133);
/* harmony import */ var _angular_cdk_coercion__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/cdk/coercion */ 76484);
/* harmony import */ var _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/platform-browser/animations */ 73598);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ 32425);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ 36312);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs/operators */ 59151);









/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */
// Boilerplate for applying mixins to MatProgressBar.

/** @docs-private */

const _c0 = ["primaryValueBar"];

const _MatProgressBarBase = (0,_angular_material_core__WEBPACK_IMPORTED_MODULE_0__.mixinColor)(class {
  constructor(_elementRef) {
    this._elementRef = _elementRef;
  }

}, 'primary');
/**
 * Injection token used to provide the current location to `MatProgressBar`.
 * Used to handle server-side rendering and to stub out during unit tests.
 * @docs-private
 */


const MAT_PROGRESS_BAR_LOCATION = new _angular_core__WEBPACK_IMPORTED_MODULE_1__.InjectionToken('mat-progress-bar-location', {
  providedIn: 'root',
  factory: MAT_PROGRESS_BAR_LOCATION_FACTORY
});
/** @docs-private */

function MAT_PROGRESS_BAR_LOCATION_FACTORY() {
  const _document = (0,_angular_core__WEBPACK_IMPORTED_MODULE_1__.inject)(_angular_common__WEBPACK_IMPORTED_MODULE_2__.DOCUMENT);

  const _location = _document ? _document.location : null;

  return {
    // Note that this needs to be a function, rather than a property, because Angular
    // will only resolve it once, but we want the current path on each call.
    getPathname: () => _location ? _location.pathname + _location.search : ''
  };
}
/** Injection token to be used to override the default options for `mat-progress-bar`. */


const MAT_PROGRESS_BAR_DEFAULT_OPTIONS = new _angular_core__WEBPACK_IMPORTED_MODULE_1__.InjectionToken('MAT_PROGRESS_BAR_DEFAULT_OPTIONS');
/** Counter used to generate unique IDs for progress bars. */

let progressbarId = 0;
/**
 * `<mat-progress-bar>` component.
 */

class MatProgressBar extends _MatProgressBarBase {
  constructor(elementRef, _ngZone, _animationMode,
  /**
   * @deprecated `location` parameter to be made required.
   * @breaking-change 8.0.0
   */
  location, defaults,
  /**
   * @deprecated `_changeDetectorRef` parameter to be made required.
   * @breaking-change 11.0.0
   */
  _changeDetectorRef) {
    super(elementRef);
    this._ngZone = _ngZone;
    this._animationMode = _animationMode;
    this._changeDetectorRef = _changeDetectorRef;
    /** Flag that indicates whether NoopAnimations mode is set to true. */

    this._isNoopAnimation = false;
    this._value = 0;
    this._bufferValue = 0;
    /**
     * Event emitted when animation of the primary progress bar completes. This event will not
     * be emitted when animations are disabled, nor will it be emitted for modes with continuous
     * animations (indeterminate and query).
     */

    this.animationEnd = new _angular_core__WEBPACK_IMPORTED_MODULE_1__.EventEmitter();
    /** Reference to animation end subscription to be unsubscribed on destroy. */

    this._animationEndSubscription = rxjs__WEBPACK_IMPORTED_MODULE_3__.Subscription.EMPTY;
    /**
     * Mode of the progress bar.
     *
     * Input must be one of these values: determinate, indeterminate, buffer, query, defaults to
     * 'determinate'.
     * Mirrored to mode attribute.
     */

    this.mode = 'determinate';
    /** ID of the progress bar. */

    this.progressbarId = `mat-progress-bar-${progressbarId++}`; // We need to prefix the SVG reference with the current path, otherwise they won't work
    // in Safari if the page has a `<base>` tag. Note that we need quotes inside the `url()`,
    // because named route URLs can contain parentheses (see #12338). Also we don't use `Location`
    // since we can't tell the difference between whether the consumer is using the hash location
    // strategy or not, because `Location` normalizes both `/#/foo/bar` and `/foo/bar` to
    // the same thing.

    const path = location ? location.getPathname().split('#')[0] : '';
    this._rectangleFillValue = `url('${path}#${this.progressbarId}')`;
    this._isNoopAnimation = _animationMode === 'NoopAnimations';

    if (defaults) {
      if (defaults.color) {
        this.color = this.defaultColor = defaults.color;
      }

      this.mode = defaults.mode || this.mode;
    }
  }
  /** Value of the progress bar. Defaults to zero. Mirrored to aria-valuenow. */


  get value() {
    return this._value;
  }

  set value(v) {
    var _a;

    this._value = clamp((0,_angular_cdk_coercion__WEBPACK_IMPORTED_MODULE_4__.coerceNumberProperty)(v) || 0); // @breaking-change 11.0.0 Remove null check for _changeDetectorRef.

    (_a = this._changeDetectorRef) === null || _a === void 0 ? void 0 : _a.markForCheck();
  }
  /** Buffer value of the progress bar. Defaults to zero. */


  get bufferValue() {
    return this._bufferValue;
  }

  set bufferValue(v) {
    var _a;

    this._bufferValue = clamp(v || 0); // @breaking-change 11.0.0 Remove null check for _changeDetectorRef.

    (_a = this._changeDetectorRef) === null || _a === void 0 ? void 0 : _a.markForCheck();
  }
  /** Gets the current transform value for the progress bar's primary indicator. */


  _primaryTransform() {
    // We use a 3d transform to work around some rendering issues in iOS Safari. See #19328.
    const scale = this.value / 100;
    return {
      transform: `scale3d(${scale}, 1, 1)`
    };
  }
  /**
   * Gets the current transform value for the progress bar's buffer indicator. Only used if the
   * progress mode is set to buffer, otherwise returns an undefined, causing no transformation.
   */


  _bufferTransform() {
    if (this.mode === 'buffer') {
      // We use a 3d transform to work around some rendering issues in iOS Safari. See #19328.
      const scale = this.bufferValue / 100;
      return {
        transform: `scale3d(${scale}, 1, 1)`
      };
    }

    return null;
  }

  ngAfterViewInit() {
    // Run outside angular so change detection didn't get triggered on every transition end
    // instead only on the animation that we care about (primary value bar's transitionend)
    this._ngZone.runOutsideAngular(() => {
      const element = this._primaryValueBar.nativeElement;
      this._animationEndSubscription = (0,rxjs__WEBPACK_IMPORTED_MODULE_5__.fromEvent)(element, 'transitionend').pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_6__.filter)(e => e.target === element)).subscribe(() => {
        if (this.mode === 'determinate' || this.mode === 'buffer') {
          this._ngZone.run(() => this.animationEnd.next({
            value: this.value
          }));
        }
      });
    });
  }

  ngOnDestroy() {
    this._animationEndSubscription.unsubscribe();
  }

}

MatProgressBar.ɵfac = function MatProgressBar_Factory(t) {
  return new (t || MatProgressBar)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_1__.ElementRef), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_1__.NgZone), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_7__.ANIMATION_MODULE_TYPE, 8), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](MAT_PROGRESS_BAR_LOCATION, 8), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](MAT_PROGRESS_BAR_DEFAULT_OPTIONS, 8), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_1__.ChangeDetectorRef));
};

MatProgressBar.ɵcmp = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({
  type: MatProgressBar,
  selectors: [["mat-progress-bar"]],
  viewQuery: function MatProgressBar_Query(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵviewQuery"](_c0, 5);
    }

    if (rf & 2) {
      let _t;

      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵloadQuery"]()) && (ctx._primaryValueBar = _t.first);
    }
  },
  hostAttrs: ["role", "progressbar", "aria-valuemin", "0", "aria-valuemax", "100", "tabindex", "-1", 1, "mat-progress-bar"],
  hostVars: 4,
  hostBindings: function MatProgressBar_HostBindings(rf, ctx) {
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵattribute"]("aria-valuenow", ctx.mode === "indeterminate" || ctx.mode === "query" ? null : ctx.value)("mode", ctx.mode);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵclassProp"]("_mat-animation-noopable", ctx._isNoopAnimation);
    }
  },
  inputs: {
    color: "color",
    value: "value",
    bufferValue: "bufferValue",
    mode: "mode"
  },
  outputs: {
    animationEnd: "animationEnd"
  },
  exportAs: ["matProgressBar"],
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵInheritDefinitionFeature"]],
  decls: 10,
  vars: 4,
  consts: [["aria-hidden", "true"], ["width", "100%", "height", "4", "focusable", "false", 1, "mat-progress-bar-background", "mat-progress-bar-element"], ["x", "4", "y", "0", "width", "8", "height", "4", "patternUnits", "userSpaceOnUse", 3, "id"], ["cx", "2", "cy", "2", "r", "2"], ["width", "100%", "height", "100%"], [1, "mat-progress-bar-buffer", "mat-progress-bar-element", 3, "ngStyle"], [1, "mat-progress-bar-primary", "mat-progress-bar-fill", "mat-progress-bar-element", 3, "ngStyle"], ["primaryValueBar", ""], [1, "mat-progress-bar-secondary", "mat-progress-bar-fill", "mat-progress-bar-element"]],
  template: function MatProgressBar_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnamespaceSVG"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](1, "svg", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](2, "defs");
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](3, "pattern", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](4, "circle", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](5, "rect", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnamespaceHTML"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](6, "div", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](7, "div", 6, 7);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](9, "div", 8);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    }

    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("id", ctx.progressbarId);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵattribute"]("fill", ctx._rectangleFillValue);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngStyle", ctx._bufferTransform());
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngStyle", ctx._primaryTransform());
    }
  },
  directives: [_angular_common__WEBPACK_IMPORTED_MODULE_2__.NgStyle],
  styles: [".mat-progress-bar{display:block;height:4px;overflow:hidden;position:relative;transition:opacity 250ms linear;width:100%}._mat-animation-noopable.mat-progress-bar{transition:none;animation:none}.mat-progress-bar .mat-progress-bar-element,.mat-progress-bar .mat-progress-bar-fill::after{height:100%;position:absolute;width:100%}.mat-progress-bar .mat-progress-bar-background{width:calc(100% + 10px)}.cdk-high-contrast-active .mat-progress-bar .mat-progress-bar-background{display:none}.mat-progress-bar .mat-progress-bar-buffer{transform-origin:top left;transition:transform 250ms ease}.cdk-high-contrast-active .mat-progress-bar .mat-progress-bar-buffer{border-top:solid 5px;opacity:.5}.mat-progress-bar .mat-progress-bar-secondary{display:none}.mat-progress-bar .mat-progress-bar-fill{animation:none;transform-origin:top left;transition:transform 250ms ease}.cdk-high-contrast-active .mat-progress-bar .mat-progress-bar-fill{border-top:solid 4px}.mat-progress-bar .mat-progress-bar-fill::after{animation:none;content:\"\";display:inline-block;left:0}.mat-progress-bar[dir=rtl],[dir=rtl] .mat-progress-bar{transform:rotateY(180deg)}.mat-progress-bar[mode=query]{transform:rotateZ(180deg)}.mat-progress-bar[mode=query][dir=rtl],[dir=rtl] .mat-progress-bar[mode=query]{transform:rotateZ(180deg) rotateY(180deg)}.mat-progress-bar[mode=indeterminate] .mat-progress-bar-fill,.mat-progress-bar[mode=query] .mat-progress-bar-fill{transition:none}.mat-progress-bar[mode=indeterminate] .mat-progress-bar-primary,.mat-progress-bar[mode=query] .mat-progress-bar-primary{-webkit-backface-visibility:hidden;backface-visibility:hidden;animation:mat-progress-bar-primary-indeterminate-translate 2000ms infinite linear;left:-145.166611%}.mat-progress-bar[mode=indeterminate] .mat-progress-bar-primary.mat-progress-bar-fill::after,.mat-progress-bar[mode=query] .mat-progress-bar-primary.mat-progress-bar-fill::after{-webkit-backface-visibility:hidden;backface-visibility:hidden;animation:mat-progress-bar-primary-indeterminate-scale 2000ms infinite linear}.mat-progress-bar[mode=indeterminate] .mat-progress-bar-secondary,.mat-progress-bar[mode=query] .mat-progress-bar-secondary{-webkit-backface-visibility:hidden;backface-visibility:hidden;animation:mat-progress-bar-secondary-indeterminate-translate 2000ms infinite linear;left:-54.888891%;display:block}.mat-progress-bar[mode=indeterminate] .mat-progress-bar-secondary.mat-progress-bar-fill::after,.mat-progress-bar[mode=query] .mat-progress-bar-secondary.mat-progress-bar-fill::after{-webkit-backface-visibility:hidden;backface-visibility:hidden;animation:mat-progress-bar-secondary-indeterminate-scale 2000ms infinite linear}.mat-progress-bar[mode=buffer] .mat-progress-bar-background{-webkit-backface-visibility:hidden;backface-visibility:hidden;animation:mat-progress-bar-background-scroll 250ms infinite linear;display:block}.mat-progress-bar._mat-animation-noopable .mat-progress-bar-fill,.mat-progress-bar._mat-animation-noopable .mat-progress-bar-fill::after,.mat-progress-bar._mat-animation-noopable .mat-progress-bar-buffer,.mat-progress-bar._mat-animation-noopable .mat-progress-bar-primary,.mat-progress-bar._mat-animation-noopable .mat-progress-bar-primary.mat-progress-bar-fill::after,.mat-progress-bar._mat-animation-noopable .mat-progress-bar-secondary,.mat-progress-bar._mat-animation-noopable .mat-progress-bar-secondary.mat-progress-bar-fill::after,.mat-progress-bar._mat-animation-noopable .mat-progress-bar-background{animation:none;transition-duration:1ms}@keyframes mat-progress-bar-primary-indeterminate-translate{0%{transform:translateX(0)}20%{animation-timing-function:cubic-bezier(0.5, 0, 0.701732, 0.495819);transform:translateX(0)}59.15%{animation-timing-function:cubic-bezier(0.302435, 0.381352, 0.55, 0.956352);transform:translateX(83.67142%)}100%{transform:translateX(200.611057%)}}@keyframes mat-progress-bar-primary-indeterminate-scale{0%{transform:scaleX(0.08)}36.65%{animation-timing-function:cubic-bezier(0.334731, 0.12482, 0.785844, 1);transform:scaleX(0.08)}69.15%{animation-timing-function:cubic-bezier(0.06, 0.11, 0.6, 1);transform:scaleX(0.661479)}100%{transform:scaleX(0.08)}}@keyframes mat-progress-bar-secondary-indeterminate-translate{0%{animation-timing-function:cubic-bezier(0.15, 0, 0.515058, 0.409685);transform:translateX(0)}25%{animation-timing-function:cubic-bezier(0.31033, 0.284058, 0.8, 0.733712);transform:translateX(37.651913%)}48.35%{animation-timing-function:cubic-bezier(0.4, 0.627035, 0.6, 0.902026);transform:translateX(84.386165%)}100%{transform:translateX(160.277782%)}}@keyframes mat-progress-bar-secondary-indeterminate-scale{0%{animation-timing-function:cubic-bezier(0.15, 0, 0.515058, 0.409685);transform:scaleX(0.08)}19.15%{animation-timing-function:cubic-bezier(0.31033, 0.284058, 0.8, 0.733712);transform:scaleX(0.457104)}44.15%{animation-timing-function:cubic-bezier(0.4, 0.627035, 0.6, 0.902026);transform:scaleX(0.72796)}100%{transform:scaleX(0.08)}}@keyframes mat-progress-bar-background-scroll{to{transform:translateX(-8px)}}\n"],
  encapsulation: 2,
  changeDetection: 0
});

(function () {
  (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵsetClassMetadata"](MatProgressBar, [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_1__.Component,
    args: [{
      selector: 'mat-progress-bar',
      exportAs: 'matProgressBar',
      host: {
        'role': 'progressbar',
        'aria-valuemin': '0',
        'aria-valuemax': '100',
        // set tab index to -1 so screen readers will read the aria-label
        // Note: there is a known issue with JAWS that does not read progressbar aria labels on FireFox
        'tabindex': '-1',
        '[attr.aria-valuenow]': '(mode === "indeterminate" || mode === "query") ? null : value',
        '[attr.mode]': 'mode',
        'class': 'mat-progress-bar',
        '[class._mat-animation-noopable]': '_isNoopAnimation'
      },
      inputs: ['color'],
      changeDetection: _angular_core__WEBPACK_IMPORTED_MODULE_1__.ChangeDetectionStrategy.OnPush,
      encapsulation: _angular_core__WEBPACK_IMPORTED_MODULE_1__.ViewEncapsulation.None,
      template: "<!--\n  All children need to be hidden for screen readers in order to support ChromeVox.\n  More context in the issue: https://github.com/angular/components/issues/22165.\n-->\n<div aria-hidden=\"true\">\n  <svg width=\"100%\" height=\"4\" focusable=\"false\" class=\"mat-progress-bar-background mat-progress-bar-element\">\n    <defs>\n      <pattern [id]=\"progressbarId\" x=\"4\" y=\"0\" width=\"8\" height=\"4\" patternUnits=\"userSpaceOnUse\">\n        <circle cx=\"2\" cy=\"2\" r=\"2\"/>\n      </pattern>\n    </defs>\n    <rect [attr.fill]=\"_rectangleFillValue\" width=\"100%\" height=\"100%\"/>\n  </svg>\n  <!--\n    The background div is named as such because it appears below the other divs and is not sized based\n    on values.\n  -->\n  <div class=\"mat-progress-bar-buffer mat-progress-bar-element\" [ngStyle]=\"_bufferTransform()\"></div>\n  <div class=\"mat-progress-bar-primary mat-progress-bar-fill mat-progress-bar-element\" [ngStyle]=\"_primaryTransform()\" #primaryValueBar></div>\n  <div class=\"mat-progress-bar-secondary mat-progress-bar-fill mat-progress-bar-element\"></div>\n</div>\n",
      styles: [".mat-progress-bar{display:block;height:4px;overflow:hidden;position:relative;transition:opacity 250ms linear;width:100%}._mat-animation-noopable.mat-progress-bar{transition:none;animation:none}.mat-progress-bar .mat-progress-bar-element,.mat-progress-bar .mat-progress-bar-fill::after{height:100%;position:absolute;width:100%}.mat-progress-bar .mat-progress-bar-background{width:calc(100% + 10px)}.cdk-high-contrast-active .mat-progress-bar .mat-progress-bar-background{display:none}.mat-progress-bar .mat-progress-bar-buffer{transform-origin:top left;transition:transform 250ms ease}.cdk-high-contrast-active .mat-progress-bar .mat-progress-bar-buffer{border-top:solid 5px;opacity:.5}.mat-progress-bar .mat-progress-bar-secondary{display:none}.mat-progress-bar .mat-progress-bar-fill{animation:none;transform-origin:top left;transition:transform 250ms ease}.cdk-high-contrast-active .mat-progress-bar .mat-progress-bar-fill{border-top:solid 4px}.mat-progress-bar .mat-progress-bar-fill::after{animation:none;content:\"\";display:inline-block;left:0}.mat-progress-bar[dir=rtl],[dir=rtl] .mat-progress-bar{transform:rotateY(180deg)}.mat-progress-bar[mode=query]{transform:rotateZ(180deg)}.mat-progress-bar[mode=query][dir=rtl],[dir=rtl] .mat-progress-bar[mode=query]{transform:rotateZ(180deg) rotateY(180deg)}.mat-progress-bar[mode=indeterminate] .mat-progress-bar-fill,.mat-progress-bar[mode=query] .mat-progress-bar-fill{transition:none}.mat-progress-bar[mode=indeterminate] .mat-progress-bar-primary,.mat-progress-bar[mode=query] .mat-progress-bar-primary{-webkit-backface-visibility:hidden;backface-visibility:hidden;animation:mat-progress-bar-primary-indeterminate-translate 2000ms infinite linear;left:-145.166611%}.mat-progress-bar[mode=indeterminate] .mat-progress-bar-primary.mat-progress-bar-fill::after,.mat-progress-bar[mode=query] .mat-progress-bar-primary.mat-progress-bar-fill::after{-webkit-backface-visibility:hidden;backface-visibility:hidden;animation:mat-progress-bar-primary-indeterminate-scale 2000ms infinite linear}.mat-progress-bar[mode=indeterminate] .mat-progress-bar-secondary,.mat-progress-bar[mode=query] .mat-progress-bar-secondary{-webkit-backface-visibility:hidden;backface-visibility:hidden;animation:mat-progress-bar-secondary-indeterminate-translate 2000ms infinite linear;left:-54.888891%;display:block}.mat-progress-bar[mode=indeterminate] .mat-progress-bar-secondary.mat-progress-bar-fill::after,.mat-progress-bar[mode=query] .mat-progress-bar-secondary.mat-progress-bar-fill::after{-webkit-backface-visibility:hidden;backface-visibility:hidden;animation:mat-progress-bar-secondary-indeterminate-scale 2000ms infinite linear}.mat-progress-bar[mode=buffer] .mat-progress-bar-background{-webkit-backface-visibility:hidden;backface-visibility:hidden;animation:mat-progress-bar-background-scroll 250ms infinite linear;display:block}.mat-progress-bar._mat-animation-noopable .mat-progress-bar-fill,.mat-progress-bar._mat-animation-noopable .mat-progress-bar-fill::after,.mat-progress-bar._mat-animation-noopable .mat-progress-bar-buffer,.mat-progress-bar._mat-animation-noopable .mat-progress-bar-primary,.mat-progress-bar._mat-animation-noopable .mat-progress-bar-primary.mat-progress-bar-fill::after,.mat-progress-bar._mat-animation-noopable .mat-progress-bar-secondary,.mat-progress-bar._mat-animation-noopable .mat-progress-bar-secondary.mat-progress-bar-fill::after,.mat-progress-bar._mat-animation-noopable .mat-progress-bar-background{animation:none;transition-duration:1ms}@keyframes mat-progress-bar-primary-indeterminate-translate{0%{transform:translateX(0)}20%{animation-timing-function:cubic-bezier(0.5, 0, 0.701732, 0.495819);transform:translateX(0)}59.15%{animation-timing-function:cubic-bezier(0.302435, 0.381352, 0.55, 0.956352);transform:translateX(83.67142%)}100%{transform:translateX(200.611057%)}}@keyframes mat-progress-bar-primary-indeterminate-scale{0%{transform:scaleX(0.08)}36.65%{animation-timing-function:cubic-bezier(0.334731, 0.12482, 0.785844, 1);transform:scaleX(0.08)}69.15%{animation-timing-function:cubic-bezier(0.06, 0.11, 0.6, 1);transform:scaleX(0.661479)}100%{transform:scaleX(0.08)}}@keyframes mat-progress-bar-secondary-indeterminate-translate{0%{animation-timing-function:cubic-bezier(0.15, 0, 0.515058, 0.409685);transform:translateX(0)}25%{animation-timing-function:cubic-bezier(0.31033, 0.284058, 0.8, 0.733712);transform:translateX(37.651913%)}48.35%{animation-timing-function:cubic-bezier(0.4, 0.627035, 0.6, 0.902026);transform:translateX(84.386165%)}100%{transform:translateX(160.277782%)}}@keyframes mat-progress-bar-secondary-indeterminate-scale{0%{animation-timing-function:cubic-bezier(0.15, 0, 0.515058, 0.409685);transform:scaleX(0.08)}19.15%{animation-timing-function:cubic-bezier(0.31033, 0.284058, 0.8, 0.733712);transform:scaleX(0.457104)}44.15%{animation-timing-function:cubic-bezier(0.4, 0.627035, 0.6, 0.902026);transform:scaleX(0.72796)}100%{transform:scaleX(0.08)}}@keyframes mat-progress-bar-background-scroll{to{transform:translateX(-8px)}}\n"]
    }]
  }], function () {
    return [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_1__.ElementRef
    }, {
      type: _angular_core__WEBPACK_IMPORTED_MODULE_1__.NgZone
    }, {
      type: undefined,
      decorators: [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_1__.Optional
      }, {
        type: _angular_core__WEBPACK_IMPORTED_MODULE_1__.Inject,
        args: [_angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_7__.ANIMATION_MODULE_TYPE]
      }]
    }, {
      type: undefined,
      decorators: [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_1__.Optional
      }, {
        type: _angular_core__WEBPACK_IMPORTED_MODULE_1__.Inject,
        args: [MAT_PROGRESS_BAR_LOCATION]
      }]
    }, {
      type: undefined,
      decorators: [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_1__.Optional
      }, {
        type: _angular_core__WEBPACK_IMPORTED_MODULE_1__.Inject,
        args: [MAT_PROGRESS_BAR_DEFAULT_OPTIONS]
      }]
    }, {
      type: _angular_core__WEBPACK_IMPORTED_MODULE_1__.ChangeDetectorRef
    }];
  }, {
    value: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_1__.Input
    }],
    bufferValue: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_1__.Input
    }],
    _primaryValueBar: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_1__.ViewChild,
      args: ['primaryValueBar']
    }],
    animationEnd: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_1__.Output
    }],
    mode: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_1__.Input
    }]
  });
})();
/** Clamps a value to be between two numbers, by default 0 and 100. */


function clamp(v, min = 0, max = 100) {
  return Math.max(min, Math.min(max, v));
}
/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */


class MatProgressBarModule {}

MatProgressBarModule.ɵfac = function MatProgressBarModule_Factory(t) {
  return new (t || MatProgressBarModule)();
};

MatProgressBarModule.ɵmod = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineNgModule"]({
  type: MatProgressBarModule,
  declarations: [MatProgressBar],
  imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__.CommonModule, _angular_material_core__WEBPACK_IMPORTED_MODULE_0__.MatCommonModule],
  exports: [MatProgressBar, _angular_material_core__WEBPACK_IMPORTED_MODULE_0__.MatCommonModule]
});
MatProgressBarModule.ɵinj = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjector"]({
  imports: [[_angular_common__WEBPACK_IMPORTED_MODULE_2__.CommonModule, _angular_material_core__WEBPACK_IMPORTED_MODULE_0__.MatCommonModule], _angular_material_core__WEBPACK_IMPORTED_MODULE_0__.MatCommonModule]
});

(function () {
  (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵsetClassMetadata"](MatProgressBarModule, [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_1__.NgModule,
    args: [{
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__.CommonModule, _angular_material_core__WEBPACK_IMPORTED_MODULE_0__.MatCommonModule],
      exports: [MatProgressBar, _angular_material_core__WEBPACK_IMPORTED_MODULE_0__.MatCommonModule],
      declarations: [MatProgressBar]
    }]
  }], null, null);
})();
/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/**
 * Generated bundle index. Do not edit.
 */




/***/ })

}]);
//# sourceMappingURL=src_app_pages_signup_signup_module_ts.js.map