"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_language-selection_language-selection_module_ts"],{

/***/ 32042:
/*!*******************************************************************************!*\
  !*** ./src/app/pages/language-selection/language-selection-routing.module.ts ***!
  \*******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LanguageSelectionPageRoutingModule": () => (/* binding */ LanguageSelectionPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _language_selection_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./language-selection.page */ 27095);




const routes = [
    {
        path: '',
        component: _language_selection_page__WEBPACK_IMPORTED_MODULE_0__.LanguageSelectionPage
    }
];
let LanguageSelectionPageRoutingModule = class LanguageSelectionPageRoutingModule {
};
LanguageSelectionPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], LanguageSelectionPageRoutingModule);



/***/ }),

/***/ 53458:
/*!***********************************************************************!*\
  !*** ./src/app/pages/language-selection/language-selection.module.ts ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LanguageSelectionPageModule": () => (/* binding */ LanguageSelectionPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _language_selection_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./language-selection-routing.module */ 32042);
/* harmony import */ var _language_selection_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./language-selection.page */ 27095);
/* harmony import */ var src_app_service_service_register_service_register_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/service/service-register/service-register.service */ 12829);
/* harmony import */ var src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/shared/shared.module */ 44466);









let LanguageSelectionPageModule = class LanguageSelectionPageModule {
};
LanguageSelectionPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_6__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.IonicModule,
            src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_3__.SharedModule,
            _language_selection_routing_module__WEBPACK_IMPORTED_MODULE_0__.LanguageSelectionPageRoutingModule,
        ],
        declarations: [_language_selection_page__WEBPACK_IMPORTED_MODULE_1__.LanguageSelectionPage],
        providers: [
            src_app_service_service_register_service_register_service__WEBPACK_IMPORTED_MODULE_2__.ServiceRegisterService
        ]
    })
], LanguageSelectionPageModule);



/***/ }),

/***/ 27095:
/*!*********************************************************************!*\
  !*** ./src/app/pages/language-selection/language-selection.page.ts ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LanguageSelectionPage": () => (/* binding */ LanguageSelectionPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _language_selection_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./language-selection.page.html?ngResource */ 98034);
/* harmony import */ var _language_selection_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./language-selection.page.scss?ngResource */ 80109);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ionic/storage-angular */ 80190);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var _awesome_cordova_plugins_clevertap_ngx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @awesome-cordova-plugins/clevertap/ngx */ 45363);
/* harmony import */ var _awesome_cordova_plugins_firebase_analytics_ngx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @awesome-cordova-plugins/firebase-analytics/ngx */ 48852);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var src_app_animations_nav_animation_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/animations/nav-animation.service */ 52707);
/* harmony import */ var src_app_service_language_language_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/service/language/language.service */ 11281);
/* harmony import */ var src_app_service_service_register_service_register_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/service/service-register/service-register.service */ 12829);
/* harmony import */ var src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/shared/data/constants */ 74676);
/* harmony import */ var src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/shared/data/enum/event */ 38570);
/* harmony import */ var src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/shared/data/enum/screen */ 68302);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/common */ 36362);

















let LanguageSelectionPage = class LanguageSelectionPage {
    constructor(storage, router, route, translate, navCtrl, registerService, platform, navAnimationService, languageService, firebaseAnalytics, clevertap, location, menu) {
        this.storage = storage;
        this.router = router;
        this.route = route;
        this.translate = translate;
        this.navCtrl = navCtrl;
        this.registerService = registerService;
        this.platform = platform;
        this.navAnimationService = navAnimationService;
        this.languageService = languageService;
        this.firebaseAnalytics = firebaseAnalytics;
        this.clevertap = clevertap;
        this.location = location;
        this.menu = menu;
    }
    ngOnInit() {
        this.platform.ready().then(() => (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__awaiter)(this, void 0, void 0, function* () {
            this.currentLanguage = yield window.localStorage.getItem(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_7__.Constants.PREFERED_LANGUAGE);
            if (!this.currentLanguage) {
                this.currentLanguage = src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_7__.Constants.DEFAULT_LANGUAGE;
                yield window.localStorage.setItem(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_7__.Constants.PREFERED_LANGUAGE, src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_7__.Constants.DEFAULT_LANGUAGE);
            }
            if (this.registerService.isAvailable()) {
                yield this.registerService.getDeliveredNotifications();
            }
        }));
        this.getLanguages();
    }
    ionViewDidEnter() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__awaiter)(this, void 0, void 0, function* () {
            this.params = this.route.snapshot.queryParams;
            this.subscription = this.platform.backButton.subscribeWithPriority(9999, () => {
                this.location.back();
                this.menu.open('profile-menu');
            });
        });
    }
    ionViewWillLeave() {
        this.subscription.unsubscribe();
    }
    // this.listDashboard = this.listDashboard.filter(
    //   _ => _.code != 'seeDoctor'
    // )
    getLanguages() {
        this.languageService.getLanguages().subscribe((data) => {
            this.languageList = data;
            this.languageList = this.languageList.filter(_ => _.id != '6');
            src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_7__.Constants.LANGUAGE_LIST = this.languageList;
        }, (error) => {
            return error;
        });
    }
    onSelectLanguage(language) {
        this.firebaseAnalytics.logEvent(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_8__.GA4Event.LanguageSelected, { language: language.culture });
        this.clevertap.recordEventWithNameAndProps(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_8__.ClevertapEvent.registration_language_selection, { language: language.culture });
        this.clevertap.recordEventWithNameAndProps(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_8__.ClevertapEvent.login_language_selection, { language: language.culture });
        this.clevertap.profileSet({ Language: language.culture });
        this.onNavigateToNextScreen(language.culture);
    }
    onNavigateToNextScreen(selectedLanguageCode) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__awaiter)(this, void 0, void 0, function* () {
            this.currentLanguage = selectedLanguageCode;
            this.languageService.changeLanguage(selectedLanguageCode);
            //this.registerService.setDeviceId();
            this.navAnimationService.getAnimationSource();
            this.redirectToSignUp();
        });
    }
    redirectToSignUp() {
        var _a;
        if ((_a = this.params) === null || _a === void 0 ? void 0 : _a.redirectTo) {
            this.router.navigate(['/' + this.params.redirectTo]).then(() => {
            });
        }
        else {
            this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_9__.Screens.SignIn]).then(() => {
            });
        }
    }
    onBack() {
        this.navCtrl.back();
        this.menu.open('profile-menu');
    }
};
LanguageSelectionPage.ctorParameters = () => [
    { type: _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_11__.Storage },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_12__.Router },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_12__.ActivatedRoute },
    { type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_13__.TranslateService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_14__.NavController },
    { type: src_app_service_service_register_service_register_service__WEBPACK_IMPORTED_MODULE_6__.ServiceRegisterService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_14__.Platform },
    { type: src_app_animations_nav_animation_service__WEBPACK_IMPORTED_MODULE_4__.NavAnimationService },
    { type: src_app_service_language_language_service__WEBPACK_IMPORTED_MODULE_5__.LanguageService },
    { type: _awesome_cordova_plugins_firebase_analytics_ngx__WEBPACK_IMPORTED_MODULE_3__.FirebaseAnalytics },
    { type: _awesome_cordova_plugins_clevertap_ngx__WEBPACK_IMPORTED_MODULE_2__.CleverTap },
    { type: _angular_common__WEBPACK_IMPORTED_MODULE_15__.Location },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_14__.MenuController }
];
LanguageSelectionPage = (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_16__.Component)({
        selector: 'app-language-selection',
        template: _language_selection_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_language_selection_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], LanguageSelectionPage);



/***/ }),

/***/ 80109:
/*!**********************************************************************************!*\
  !*** ./src/app/pages/language-selection/language-selection.page.scss?ngResource ***!
  \**********************************************************************************/
/***/ ((module) => {

module.exports = ":root {\n  --nc-color-nextgen-neutral-grey-50: #f1efef;\n  --nc-color-nextgen-white: #ffffff;\n  --nc-color-nextgen-blue: #0d152e;\n  --nc-color-nextgen-green: #00908d;\n  --nc-color-nextgen-black: #000000;\n  --nc-color-nextgen-grey-background: #c8d3da;\n  --nc-color-nextgen-grey: #92a2ac;\n  --nc-color-nextgen-stone-grey: #fafafa;\n  --nc-color-nextgen-error: #fc1055;\n  --nc-color-nextgen-neutral-grey: #414141;\n  --nc-color-nextgen-fibrant-green: #00bab6;\n  --nc-color-nextgen-warning: #ffd048;\n  --nc-color-nextgen-green-background: #e6f2f2;\n  --nc-color-nextgen-neutral-grey-400: #7a7a7a;\n  --nc-color-nextgen-neutral-grey-100: #eff3f5;\n  --nc-color-nextgen-status-error: #ba0c3f;\n  --nc-color-nextgen-status-error-background: #ffeff4;\n  --nc-color-nextgen-status-warning: #cba127;\n  --nc-color-nextgen-status-warning-background: #fff8e6;\n  --nc-color-nextgen-blue-100: #dfeff2;\n  --nc-color-nextgen-error-red-700: #f62459;\n  --nc-color-nextgen-blue-500: #006192;\n  --nc-color-nextgen-blue-400: #79cdec;\n  --nc-color-nextgen-red-500: #ff6592;\n  --nc-color-nextgen-secondary-blue-300: #13a0d3;\n  --lumi-white-color: #ffffff;\n  --lumi-primary-yellow-color: #fab600;\n}\n\n.ion-color-green {\n  --ion-color-base: var(--nc-color-nextgen-green);\n  --ion-color-base-rgb: var(--nc-color-nextgen-green);\n  --ion-color-contrast: var(--nc-color-nextgen-white);\n  --ion-color-contrast-rgb: var(--nc-color-nextgen-green);\n  --ion-color-shade: var(--nc-color-nextgen-green);\n  --ion-color-tint: var(--nc-color-nextgen-green);\n}\n\n.language-selection-container {\n  background-color: #FFFFFF;\n}\n\n.language-selection-img {\n  width: 50%;\n  display: block;\n  margin-left: auto;\n  margin-right: auto;\n  margin-top: 100px;\n  margin-bottom: 100px;\n}\n\n.language-selection-prefered-language {\n  text-align: center;\n  font-size: 30px;\n  line-height: 30px;\n  color: #595959;\n  margin: 0 20px 40px 20px;\n}\n\n.language-selection-button {\n  padding: 9px 40px;\n  text-align: center;\n  font-size: 20px;\n  color: #00908D;\n  height: 55px;\n  line-height: 50px;\n  border: 2px solid #00908D;\n  box-sizing: border-box;\n  border-radius: 52px;\n}\n\n.prefered-language {\n  width: 100%;\n  color: var(--nc-color-nextgen-black);\n  padding-top: 2rem;\n}\n\n.continue {\n  text-align: center;\n}\n\n.slect-language {\n  padding-top: 8rem;\n  display: flex;\n  height: max-content;\n  justify-content: center;\n}\n\n.select-area {\n  color: var(--nc-color-nextgen-black);\n  padding-bottom: 56px;\n  display: flex;\n  align-items: center;\n}\n\n.pr-1 {\n  padding-right: 1rem !important;\n  padding-left: 1rem !important;\n}\n\n.ml-1 {\n  padding-left: 1rem !important;\n}\n\n.checked {\n  font-weight: 700 !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXGNvbG9yLnNjc3MiLCJsYW5ndWFnZS1zZWxlY3Rpb24ucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0MsMkNBQUE7RUFDQSxpQ0FBQTtFQUNBLGdDQUFBO0VBQ0EsaUNBQUE7RUFDQSxpQ0FBQTtFQUNBLDJDQUFBO0VBQ0EsZ0NBQUE7RUFDQSxzQ0FBQTtFQUNBLGlDQUFBO0VBQ0Esd0NBQUE7RUFDQSx5Q0FBQTtFQUNBLG1DQUFBO0VBQ0EsNENBQUE7RUFDQSw0Q0FBQTtFQUNBLDRDQUFBO0VBQ0Esd0NBQUE7RUFDQSxtREFBQTtFQUNBLDBDQUFBO0VBQ0EscURBQUE7RUFDQSxvQ0FBQTtFQUNBLHlDQUFBO0VBQ0Esb0NBQUE7RUFDQSxvQ0FBQTtFQUNBLG1DQUFBO0VBQ0EsOENBQUE7RUFFQSwyQkFBQTtFQUNBLG9DQUFBO0FDQUQ7O0FEZ0NBO0VBQ0MsK0NBQUE7RUFDQSxtREFBQTtFQUNBLG1EQUFBO0VBQ0EsdURBQUE7RUFDQSxnREFBQTtFQUNBLCtDQUFBO0FDN0JEOztBQW5DQTtFQUNJLHlCQUFBO0FBc0NKOztBQW5DQTtFQUNJLFVBQUE7RUFDQSxjQUFBO0VBQ0EsaUJBQUE7RUFDQSxrQkFBQTtFQUNBLGlCQUFBO0VBQ0Esb0JBQUE7QUFzQ0o7O0FBbkNBO0VBQ0ksa0JBQUE7RUFDQSxlQUFBO0VBQ0EsaUJBQUE7RUFDQSxjQUFBO0VBQ0Esd0JBQUE7QUFzQ0o7O0FBbkNBO0VBQ0ksaUJBQUE7RUFDQSxrQkFBQTtFQUNBLGVBQUE7RUFDQSxjQUFBO0VBQ0EsWUFBQTtFQUNBLGlCQUFBO0VBQ0EseUJBQUE7RUFDQSxzQkFBQTtFQUNBLG1CQUFBO0FBc0NKOztBQW5DQTtFQUNJLFdBQUE7RUFDQSxvQ0RKa0I7RUNLbEIsaUJBQUE7QUFzQ0o7O0FBbkNBO0VBQ0ksa0JBQUE7QUFzQ0o7O0FBbkNBO0VBQ0ksaUJBQUE7RUFDQSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSx1QkFBQTtBQXNDSjs7QUFuQ0E7RUFDSSxvQ0RwQmtCO0VDcUJsQixvQkFBQTtFQUNBLGFBQUE7RUFDQSxtQkFBQTtBQXNDSjs7QUFuQ0E7RUFDSSw4QkFBQTtFQUNBLDZCQUFBO0FBc0NKOztBQW5DQTtFQUNJLDZCQUFBO0FBc0NKOztBQW5DQTtFQUNJLDJCQUFBO0FBc0NKIiwiZmlsZSI6Imxhbmd1YWdlLXNlbGVjdGlvbi5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyI6cm9vdCB7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS01MDogI2YxZWZlZjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4td2hpdGU6ICNmZmZmZmY7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWJsdWU6ICMwZDE1MmU7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuOiAjMDA5MDhkO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ibGFjazogIzAwMDAwMDtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tZ3JleS1iYWNrZ3JvdW5kOiAjYzhkM2RhO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ncmV5OiAjOTJhMmFjO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zdG9uZS1ncmV5OiAjZmFmYWZhO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1lcnJvcjogI2ZjMTA1NTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5OiAjNDE0MTQxO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1maWJyYW50LWdyZWVuOiAjMDBiYWI2O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi13YXJuaW5nOiAjZmZkMDQ4O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbi1iYWNrZ3JvdW5kOiAjZTZmMmYyO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNDAwOiAjN2E3YTdhO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktMTAwOiAjZWZmM2Y1O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtZXJyb3I6ICNiYTBjM2Y7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy1lcnJvci1iYWNrZ3JvdW5kOiAjZmZlZmY0O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtd2FybmluZzogI2NiYTEyNztcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLXdhcm5pbmctYmFja2dyb3VuZDogI2ZmZjhlNjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZS0xMDA6ICNkZmVmZjI7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWVycm9yLXJlZC03MDA6ICNmNjI0NTk7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWJsdWUtNTAwOiAjMDA2MTkyO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlLTQwMDogIzc5Y2RlYztcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tcmVkLTUwMDogI2ZmNjU5MjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc2Vjb25kYXJ5LWJsdWUtMzAwOiAjMTNhMGQzO1xyXG5cclxuXHQtLWx1bWktd2hpdGUtY29sb3I6ICNmZmZmZmY7XHJcblx0LS1sdW1pLXByaW1hcnkteWVsbG93LWNvbG9yOiAjZmFiNjAwO1xyXG59XHJcbiRjb2xvci1uZXh0Z2VuLWJsdWU6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZSk7XHJcbiRjb2xvci1uZXh0Z2VuLWdyZWVuOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuKTtcclxuJGNvbG9yLW5leHRnZW4td2hpdGU6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4td2hpdGUpO1xyXG4kY29sb3ItbmV4dGdlbi1ibGFjazogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ibGFjayk7XHJcbiRjb2xvci1uZXh0Z2VuLWdyZXktYmFja2dyb3VuZDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmV5LWJhY2tncm91bmQpO1xyXG4kY29sb3ItbmV4dGdlbi1ncmV5OiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZXkpO1xyXG4kY29sb3ItbmV4dGdlbi1zdG9uZS1ncmV5OiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXN0b25lLWdyZXkpO1xyXG4kY29sb3ItbmV4dGdlbi1lcnJvcjogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1lcnJvcik7XHJcbiRjb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleTogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXkpO1xyXG4kY29sb3ItbmV4dGdlbi1maWJyYW50LWdyZWVuOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWZpYnJhbnQtZ3JlZW4pO1xyXG4kY29sb3ItbmV4dGdlbi13YXJuaW5nOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXdhcm5pbmcpO1xyXG4kY29sb3ItbmV4dGdlbi1ncmVlbi1iYWNrZ3JvdW5kOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuLWJhY2tncm91bmQpO1xyXG4kY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNTA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTUwKTtcclxuJGNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTQwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNDAwKTtcclxuJGNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTEwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktMTAwKTtcclxuJGNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy1lcnJvcik7XHJcbiRjb2xvci1uZXh0Z2VuLXN0YXR1cy1lcnJvci1iYWNrZ3JvdW5kOiB2YXIoXHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy1lcnJvci1iYWNrZ3JvdW5kXHJcbik7XHJcbiRjb2xvci1uZXh0Z2VuLXN0YXR1cy13YXJuaW5nOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy13YXJuaW5nKTtcclxuJGNvbG9yLW5leHRnZW4tc3RhdHVzLXdhcm5pbmctYmFja2dyb3VuZDogdmFyKFxyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtd2FybmluZy1iYWNrZ3JvdW5kXHJcbik7XHJcbiRjb2xvci1uZXh0Z2VuLWJsdWUtMTAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWJsdWUtMTAwKTtcclxuJGNvbG9yLW5leHRnZW4tZXJyb3ItcmVkLTcwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1lcnJvci1yZWQtNzAwKTtcclxuJGNvbG9yLW5leHRnZW4tYmx1ZS01MDA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZS01MDApO1xyXG4kY29sb3ItbmV4dGdlbi1ibHVlLTQwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlLTQwMCk7XHJcbiRjb2xvci1uZXh0Z2VuLXJlZC01MDA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tcmVkLTUwMCk7XHJcbiRjb2xvci1uZXh0Z2VuLXNlY29uZGFyeS1ibHVlLTMwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1zZWNvbmRhcnktYmx1ZS0zMDApO1xyXG5cclxuLmlvbi1jb2xvci1ncmVlbiB7XHJcblx0LS1pb24tY29sb3ItYmFzZTogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbik7XHJcblx0LS1pb24tY29sb3ItYmFzZS1yZ2I6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4pO1xyXG5cdC0taW9uLWNvbG9yLWNvbnRyYXN0OiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXdoaXRlKTtcclxuXHQtLWlvbi1jb2xvci1jb250cmFzdC1yZ2I6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4pO1xyXG5cdC0taW9uLWNvbG9yLXNoYWRlOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuKTtcclxuXHQtLWlvbi1jb2xvci10aW50OiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuKTtcclxufVxyXG4iLCJAaW1wb3J0IFwiLi4vLi4vLi4vY29sb3Iuc2Nzc1wiO1xyXG5cclxuLmxhbmd1YWdlLXNlbGVjdGlvbi1jb250YWluZXIge1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogI0ZGRkZGRjtcclxufVxyXG5cclxuLmxhbmd1YWdlLXNlbGVjdGlvbi1pbWcge1xyXG4gICAgd2lkdGg6IDUwJTtcclxuICAgIGRpc3BsYXk6IGJsb2NrO1xyXG4gICAgbWFyZ2luLWxlZnQ6IGF1dG87XHJcbiAgICBtYXJnaW4tcmlnaHQ6IGF1dG87XHJcbiAgICBtYXJnaW4tdG9wOiAxMDBweDtcclxuICAgIG1hcmdpbi1ib3R0b206IDEwMHB4O1xyXG59XHJcblxyXG4ubGFuZ3VhZ2Utc2VsZWN0aW9uLXByZWZlcmVkLWxhbmd1YWdlIHtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIGZvbnQtc2l6ZTogMzBweDtcclxuICAgIGxpbmUtaGVpZ2h0OiAzMHB4O1xyXG4gICAgY29sb3I6ICM1OTU5NTk7XHJcbiAgICBtYXJnaW46IDAgMjBweCA0MHB4IDIwcHg7XHJcbn1cclxuXHJcbi5sYW5ndWFnZS1zZWxlY3Rpb24tYnV0dG9uIHtcclxuICAgIHBhZGRpbmc6IDlweCA0MHB4O1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgZm9udC1zaXplOiAyMHB4O1xyXG4gICAgY29sb3I6ICMwMDkwOEQ7XHJcbiAgICBoZWlnaHQ6IDU1cHg7XHJcbiAgICBsaW5lLWhlaWdodDogNTBweDtcclxuICAgIGJvcmRlcjogMnB4IHNvbGlkICMwMDkwOEQ7XHJcbiAgICBib3gtc2l6aW5nOiBib3JkZXItYm94O1xyXG4gICAgYm9yZGVyLXJhZGl1czogNTJweDtcclxufVxyXG5cclxuLnByZWZlcmVkLWxhbmd1YWdlIHtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgY29sb3I6ICRjb2xvci1uZXh0Z2VuLWJsYWNrO1xyXG4gICAgcGFkZGluZy10b3A6IDJyZW07XHJcbn1cclxuXHJcbi5jb250aW51ZSB7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbn1cclxuXHJcbi5zbGVjdC1sYW5ndWFnZSB7XHJcbiAgICBwYWRkaW5nLXRvcDogOHJlbTtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBoZWlnaHQ6IG1heC1jb250ZW50O1xyXG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbn1cclxuXHJcbi5zZWxlY3QtYXJlYSB7XHJcbiAgICBjb2xvcjokY29sb3ItbmV4dGdlbi1ibGFjaztcclxuICAgIHBhZGRpbmctYm90dG9tOiA1NnB4O1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbn1cclxuXHJcbi5wci0xIHtcclxuICAgIHBhZGRpbmctcmlnaHQ6IDFyZW0gIWltcG9ydGFudDtcclxuICAgIHBhZGRpbmctbGVmdDogMXJlbSAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4ubWwtMSB7XHJcbiAgICBwYWRkaW5nLWxlZnQ6IDFyZW0gIWltcG9ydGFudDtcclxufVxyXG5cclxuLmNoZWNrZWQge1xyXG4gICAgZm9udC13ZWlnaHQ6IDcwMCAhaW1wb3J0YW50O1xyXG59Il19 */";

/***/ }),

/***/ 98034:
/*!**********************************************************************************!*\
  !*** ./src/app/pages/language-selection/language-selection.page.html?ngResource ***!
  \**********************************************************************************/
/***/ ((module) => {

module.exports = "<div class=\"language-selection-container\">\r\n  <nextcare-layout>\r\n    <ng-template header>\r\n      <ion-row>\r\n        <ion-col size=\"6\" class=\"d-flex\">\r\n          <button class=\"btn btn-circle\" (click)=\"onBack()\">\r\n            <ion-icon  class=\"icon-back body-l\" name=\"arrow-back-outline\"></ion-icon>\r\n          </button>\r\n        </ion-col>\r\n        <ion-col size=\"6\">\r\n        </ion-col>\r\n      </ion-row>\r\n    </ng-template>\r\n    <ng-template body>\r\n      <div class=\"prefered-language h1 bold\">\r\n        {{'languageSelection.preferedLanguage' | translate}}\r\n      </div>\r\n      <div class=\"slect-language\">\r\n        <div>\r\n          <div *ngFor=\"let lang of languageList\" (click)=\"onSelectLanguage(lang)\" class=\"select-area body-l\"\r\n            [ngClass]=\"lang.culture === currentLanguage ? 'checked' : ''\">\r\n            <img src=\"data:image/png;base64,{{lang.flag}}\" class=\"pr-1\" />\r\n            {{lang.name}}\r\n            <img class=\"ml-1\" *ngIf=\"lang.culture === currentLanguage\" src=\"../../../assets/icon/checked.svg\" />\r\n          </div>\r\n        </div>\r\n      </div>\r\n    </ng-template>\r\n    <ng-template bottom>\r\n      <div class=\"continue\">\r\n        <button class=\"btn btn-large primary bold\" (click)=\"redirectToSignUp()\">{{ 'button.continue' |\r\n          translate }}</button>\r\n      </div>\r\n    </ng-template>\r\n  </nextcare-layout>\r\n</div>";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_language-selection_language-selection_module_ts.js.map