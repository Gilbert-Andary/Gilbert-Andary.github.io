"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_set-new-password_set-new-password_module_ts"],{

/***/ 17899:
/*!*********************************************************************************!*\
  !*** ./src/app/pages/set-new-password/alert-success/alert-success.component.ts ***!
  \*********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AlertSuccessComponent": () => (/* binding */ AlertSuccessComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _alert_success_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./alert-success.component.html?ngResource */ 34140);
/* harmony import */ var _alert_success_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./alert-success.component.scss?ngResource */ 54670);
/* harmony import */ var _awesome_cordova_plugins_clevertap_ngx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @awesome-cordova-plugins/clevertap/ngx */ 45363);
/* harmony import */ var _awesome_cordova_plugins_firebase_analytics_ngx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @awesome-cordova-plugins/firebase-analytics/ngx */ 48852);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var src_app_shared_components_nextgen_dialog_nextgen_dialog_ref__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/shared/components/nextgen-dialog/nextgen-dialog-ref */ 99922);
/* harmony import */ var src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/shared/data/enum/event */ 38570);








let AlertSuccessComponent = class AlertSuccessComponent {
    constructor(dialogRef, firebaseAnalytics, clevertap) {
        this.dialogRef = dialogRef;
        this.firebaseAnalytics = firebaseAnalytics;
        this.clevertap = clevertap;
        this.header = 'setNewPassWord.success';
        this.nameButton = 'button.ok';
        this.valueContent = 'setNewPassWord.yourPasswordHasResettedSuccesfully';
    }
    ngOnInit() { }
    onSubmit() {
        this.firebaseAnalytics.logEvent(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_5__.GA4Event.PasswordResetCompleted, {});
        this.clevertap.recordEventWithName(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_5__.GA4Event.PasswordResetCompleted);
        this.dialogRef.close();
    }
};
AlertSuccessComponent.ctorParameters = () => [
    { type: src_app_shared_components_nextgen_dialog_nextgen_dialog_ref__WEBPACK_IMPORTED_MODULE_4__.NextgenDialogRef },
    { type: _awesome_cordova_plugins_firebase_analytics_ngx__WEBPACK_IMPORTED_MODULE_3__.FirebaseAnalytics },
    { type: _awesome_cordova_plugins_clevertap_ngx__WEBPACK_IMPORTED_MODULE_2__.CleverTap }
];
AlertSuccessComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Component)({
        selector: 'app-alert-success',
        template: _alert_success_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_alert_success_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], AlertSuccessComponent);



/***/ }),

/***/ 63941:
/*!***************************************************************************!*\
  !*** ./src/app/pages/set-new-password/set-new-password-routing.module.ts ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SetNewPasswordPageRoutingModule": () => (/* binding */ SetNewPasswordPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _set_new_password_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./set-new-password.page */ 45080);




const routes = [
    {
        path: '',
        component: _set_new_password_page__WEBPACK_IMPORTED_MODULE_0__.SetNewPasswordPage
    },
];
let SetNewPasswordPageRoutingModule = class SetNewPasswordPageRoutingModule {
};
SetNewPasswordPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
    })
], SetNewPasswordPageRoutingModule);



/***/ }),

/***/ 33249:
/*!*******************************************************************!*\
  !*** ./src/app/pages/set-new-password/set-new-password.module.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SetNewPasswordPageModule": () => (/* binding */ SetNewPasswordPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _set_new_password_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./set-new-password.page */ 45080);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/shared/shared.module */ 44466);
/* harmony import */ var _set_new_password_routing_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./set-new-password-routing.module */ 63941);
/* harmony import */ var _alert_success_alert_success_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./alert-success/alert-success.component */ 17899);









let SetNewPasswordPageModule = class SetNewPasswordPageModule {
};
SetNewPasswordPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.NgModule)({
        declarations: [_set_new_password_page__WEBPACK_IMPORTED_MODULE_0__.SetNewPasswordPage, _alert_success_alert_success_component__WEBPACK_IMPORTED_MODULE_3__.AlertSuccessComponent],
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_6__.CommonModule,
            _set_new_password_routing_module__WEBPACK_IMPORTED_MODULE_2__.SetNewPasswordPageRoutingModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.IonicModule,
            src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_1__.SharedModule,
        ],
    })
], SetNewPasswordPageModule);



/***/ }),

/***/ 45080:
/*!*****************************************************************!*\
  !*** ./src/app/pages/set-new-password/set-new-password.page.ts ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SetNewPasswordPage": () => (/* binding */ SetNewPasswordPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _set_new_password_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./set-new-password.page.html?ngResource */ 25293);
/* harmony import */ var _set_new_password_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./set-new-password.page.scss?ngResource */ 54510);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @ionic/storage-angular */ 80190);
/* harmony import */ var src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/shared/data/enum/screen */ 68302);
/* harmony import */ var src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/shared/data/constants */ 74676);
/* harmony import */ var src_app_shared_data_enum_platform__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/shared/data/enum/platform */ 8760);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var src_app_model_control_control_model__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/model/control/control.model */ 45482);
/* harmony import */ var src_app_shared_components_nextgen_dialog_nextgen_dialog_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/shared/components/nextgen-dialog/nextgen-dialog.service */ 96485);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var src_app_providers_common_common_helper_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/providers/common/common-helper.service */ 27704);
/* harmony import */ var _alert_success_alert_success_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./alert-success/alert-success.component */ 17899);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @environments/environment */ 92340);
/* harmony import */ var src_app_service_signin_signin_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/app/service/signin/signin.service */ 91265);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/common/http */ 28784);
/* harmony import */ var src_app_service_signup_signup_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/app/service/signup/signup.service */ 71234);




















let SetNewPasswordPage = class SetNewPasswordPage {
    constructor(router, signinService, storage, navCtrl, dialogSevice, translate, fb, commonService, route, signupService, platform) {
        var _a;
        this.router = router;
        this.signinService = signinService;
        this.storage = storage;
        this.navCtrl = navCtrl;
        this.dialogSevice = dialogSevice;
        this.translate = translate;
        this.fb = fb;
        this.commonService = commonService;
        this.route = route;
        this.signupService = signupService;
        this.platform = platform;
        this.TYPE = src_app_model_control_control_model__WEBPACK_IMPORTED_MODULE_5__.ControlType; //type input control
        this.showPassword = false; //status password(hide=false/show)
        this.isMobileApp = false;
        this.secondIcon = 'uil uil-eye-slash';
        this.count = 3;
        this.progressPassword = {
            key: 'error',
            progress: '0%'
        };
        this.typeInputPassword = this.TYPE.PASSWORD;
        this.isProgressBarPassword = false; // status progressbar control password (hide=false/show)
        this.messageValidations = [
            {
                key: 'leastOneNumber',
                text: 'signup.atLeast1Number'
            },
            {
                key: 'specialCharacters',
                text: 'signup.atLeast1Symbol'
            },
            {
                key: 'leastCharecters',
                text: 'signup.atLeast8Charecters'
            },
            {
                key: 'leastOneCap',
                text: 'signup.atLeast1CapitalLetter'
            }
        ];
        // Build formGroup
        this.newPasswordForm = this.fb.group({
            password: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_12__.Validators.required, this.passwordValidation()]],
            otpcode: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_12__.Validators.required],
        });
        this.loadPlatformInformation();
        this.params = this.route.snapshot.queryParams;
        if (!((_a = this.params) === null || _a === void 0 ? void 0 : _a.cancelRequest)) {
            this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__.Screens.SignIn]);
        }
    }
    ngOnInit() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_13__.__awaiter)(this, void 0, void 0, function* () {
        });
    }
    ionViewDidEnter() {
        this.subscription = this.platform.backButton.subscribeWithPriority(9999, () => {
            this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__.Screens.SignIn]);
        });
    }
    ionViewWillLeave() {
        this.subscription.unsubscribe();
    }
    loadPlatformInformation() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_13__.__awaiter)(this, void 0, void 0, function* () {
            const platform = yield this.storage.get(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_3__.Constants.PLATFORM);
            if (platform == src_app_shared_data_enum_platform__WEBPACK_IMPORTED_MODULE_4__.PlatformEnum.Mobile) {
                this.isMobileApp = true;
            }
        });
    }
    passwordValidation() {
        return (control) => {
            const val = control.value;
            const err = {};
            if (!String(val).match(/[0-9]/g)) {
                err.leastOneNumber = true;
            }
            if (!String(val).match(/[^A-Za-z 0-9]/g)) {
                err.specialCharacters = true;
            }
            if (String(val).length < 8) {
                err.leastCharecters = true;
            }
            if (!String(val).match(/[A-Z]/g)) {
                err.leastOneCap = true;
            }
            const errorCount = Object.keys(err).length;
            if (errorCount > 2) {
                this.progressPassword = {
                    key: 'error',
                    progress: '10%'
                };
            }
            else if (errorCount == 0) {
                this.progressPassword = {
                    key: 'success',
                    progress: '100%'
                };
            }
            else {
                this.progressPassword = {
                    key: 'warning',
                    progress: '50%'
                };
            }
            return err;
        };
    }
    verifyPass(key) {
        const errors = this.newPasswordForm.controls['password'].errors;
        if (Object.keys(errors).findIndex(e => e === key) === -1) {
            return true;
        }
        else {
            return false;
        }
    }
    togglePassword() {
        this.showPassword = !this.showPassword;
        if (this.showPassword) {
            this.typeInputPassword = this.TYPE.INPUT;
            this.secondIcon = 'uil uil-eye';
        }
        else {
            this.typeInputPassword = this.TYPE.PASSWORD;
            this.secondIcon = 'uil uil-eye-slash';
        }
    }
    onFocusPasswordControl() {
        this.isProgressBarPassword = true;
    }
    onBack() {
        this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__.Screens.SignIn]);
    }
    confirm() {
        var _a, _b;
        const ResetPassword = {
            type: (_a = this.params) === null || _a === void 0 ? void 0 : _a.type,
            login: (_b = this.params) === null || _b === void 0 ? void 0 : _b.login,
            otpCode: this.newPasswordForm.controls['otpcode'].value,
            password: this.newPasswordForm.controls['password'].value,
            appId: _environments_environment__WEBPACK_IMPORTED_MODULE_9__.environment.AppID,
        };
        this.signinService.ResetPassword(ResetPassword).subscribe((res) => {
            if (!res)
                return;
            this.dialogSevice.open(_alert_success_alert_success_component__WEBPACK_IMPORTED_MODULE_8__.AlertSuccessComponent, {
                position: 'middle',
                height: '380px',
                width: '90%',
            }).afterClosed().subscribe(_ => {
                this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__.Screens.SignIn]).then(() => {
                });
            });
        }, (_) => {
            this.count = this.count - 1;
            console.log(this.count);
        });
    }
    redirectToNeedHelp() {
        this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__.Screens.InquiryBeforeLogin], { queryParams: { redirectTo: 'new-password' } });
    }
    resendOTP() {
        var _a, _b;
        return (0,tslib__WEBPACK_IMPORTED_MODULE_13__.__awaiter)(this, void 0, void 0, function* () {
            const headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_14__.HttpHeaders({
                customErrorAlert: 'true',
            });
            const userId = yield this.storage.get(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_3__.Constants.USERID);
            this.signupService.sendOTP({
                login: (_a = this.params) === null || _a === void 0 ? void 0 : _a.login,
                appID: _environments_environment__WEBPACK_IMPORTED_MODULE_9__.environment.AppID,
                type: (_b = this.params) === null || _b === void 0 ? void 0 : _b.type,
                userId,
            }, headers).subscribe(res => {
                this.count = 3;
                console.log(res);
            });
        });
    }
};
SetNewPasswordPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_15__.Router },
    { type: src_app_service_signin_signin_service__WEBPACK_IMPORTED_MODULE_10__.SigninService },
    { type: _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_16__.Storage },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_17__.NavController },
    { type: src_app_shared_components_nextgen_dialog_nextgen_dialog_service__WEBPACK_IMPORTED_MODULE_6__.DialogService },
    { type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_18__.TranslateService },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_12__.FormBuilder },
    { type: src_app_providers_common_common_helper_service__WEBPACK_IMPORTED_MODULE_7__.CommonHelperService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_15__.ActivatedRoute },
    { type: src_app_service_signup_signup_service__WEBPACK_IMPORTED_MODULE_11__.SignupService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_17__.Platform }
];
SetNewPasswordPage = (0,tslib__WEBPACK_IMPORTED_MODULE_13__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_19__.Component)({
        selector: 'app-set-new-password',
        template: _set_new_password_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_set_new_password_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], SetNewPasswordPage);



/***/ }),

/***/ 54670:
/*!**********************************************************************************************!*\
  !*** ./src/app/pages/set-new-password/alert-success/alert-success.component.scss?ngResource ***!
  \**********************************************************************************************/
/***/ ((module) => {

module.exports = ":root {\n  --nc-color-nextgen-neutral-grey-50: #f1efef;\n  --nc-color-nextgen-white: #ffffff;\n  --nc-color-nextgen-blue: #0d152e;\n  --nc-color-nextgen-green: #00908d;\n  --nc-color-nextgen-black: #000000;\n  --nc-color-nextgen-grey-background: #c8d3da;\n  --nc-color-nextgen-grey: #92a2ac;\n  --nc-color-nextgen-stone-grey: #fafafa;\n  --nc-color-nextgen-error: #fc1055;\n  --nc-color-nextgen-neutral-grey: #414141;\n  --nc-color-nextgen-fibrant-green: #00bab6;\n  --nc-color-nextgen-warning: #ffd048;\n  --nc-color-nextgen-green-background: #e6f2f2;\n  --nc-color-nextgen-neutral-grey-400: #7a7a7a;\n  --nc-color-nextgen-neutral-grey-100: #eff3f5;\n  --nc-color-nextgen-status-error: #ba0c3f;\n  --nc-color-nextgen-status-error-background: #ffeff4;\n  --nc-color-nextgen-status-warning: #cba127;\n  --nc-color-nextgen-status-warning-background: #fff8e6;\n  --nc-color-nextgen-blue-100: #dfeff2;\n  --nc-color-nextgen-error-red-700: #f62459;\n  --nc-color-nextgen-blue-500: #006192;\n  --nc-color-nextgen-blue-400: #79cdec;\n  --nc-color-nextgen-red-500: #ff6592;\n  --nc-color-nextgen-secondary-blue-300: #13a0d3;\n  --lumi-white-color: #ffffff;\n  --lumi-primary-yellow-color: #fab600;\n}\n\n.ion-color-green {\n  --ion-color-base: var(--nc-color-nextgen-green);\n  --ion-color-base-rgb: var(--nc-color-nextgen-green);\n  --ion-color-contrast: var(--nc-color-nextgen-white);\n  --ion-color-contrast-rgb: var(--nc-color-nextgen-green);\n  --ion-color-shade: var(--nc-color-nextgen-green);\n  --ion-color-tint: var(--nc-color-nextgen-green);\n}\n\n.header-invalid {\n  justify-content: unset !important;\n  display: unset !important;\n  text-align: center;\n  color: var(--nc-color-nextgen-blue);\n}\n\n.img-lock {\n  padding-bottom: 1rem;\n}\n\n.body-popup {\n  width: 100%;\n  position: relative;\n}\n\n.popup {\n  position: sticky;\n  top: 2rem !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFxjb2xvci5zY3NzIiwiYWxlcnQtc3VjY2Vzcy5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNDLDJDQUFBO0VBQ0EsaUNBQUE7RUFDQSxnQ0FBQTtFQUNBLGlDQUFBO0VBQ0EsaUNBQUE7RUFDQSwyQ0FBQTtFQUNBLGdDQUFBO0VBQ0Esc0NBQUE7RUFDQSxpQ0FBQTtFQUNBLHdDQUFBO0VBQ0EseUNBQUE7RUFDQSxtQ0FBQTtFQUNBLDRDQUFBO0VBQ0EsNENBQUE7RUFDQSw0Q0FBQTtFQUNBLHdDQUFBO0VBQ0EsbURBQUE7RUFDQSwwQ0FBQTtFQUNBLHFEQUFBO0VBQ0Esb0NBQUE7RUFDQSx5Q0FBQTtFQUNBLG9DQUFBO0VBQ0Esb0NBQUE7RUFDQSxtQ0FBQTtFQUNBLDhDQUFBO0VBRUEsMkJBQUE7RUFDQSxvQ0FBQTtBQ0FEOztBRGdDQTtFQUNDLCtDQUFBO0VBQ0EsbURBQUE7RUFDQSxtREFBQTtFQUNBLHVEQUFBO0VBQ0EsZ0RBQUE7RUFDQSwrQ0FBQTtBQzdCRDs7QUFuQ0E7RUFDSSxpQ0FBQTtFQUNBLHlCQUFBO0VBQ0Esa0JBQUE7RUFDQSxtQ0R3QmlCO0FDY3JCOztBQW5DQTtFQUNJLG9CQUFBO0FBc0NKOztBQXBDQTtFQUNJLFdBQUE7RUFDQSxrQkFBQTtBQXVDSjs7QUFyQ0E7RUFDSSxnQkFBQTtFQUNBLG9CQUFBO0FBd0NKIiwiZmlsZSI6ImFsZXJ0LXN1Y2Nlc3MuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyI6cm9vdCB7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS01MDogI2YxZWZlZjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4td2hpdGU6ICNmZmZmZmY7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWJsdWU6ICMwZDE1MmU7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuOiAjMDA5MDhkO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ibGFjazogIzAwMDAwMDtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tZ3JleS1iYWNrZ3JvdW5kOiAjYzhkM2RhO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ncmV5OiAjOTJhMmFjO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zdG9uZS1ncmV5OiAjZmFmYWZhO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1lcnJvcjogI2ZjMTA1NTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5OiAjNDE0MTQxO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1maWJyYW50LWdyZWVuOiAjMDBiYWI2O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi13YXJuaW5nOiAjZmZkMDQ4O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbi1iYWNrZ3JvdW5kOiAjZTZmMmYyO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNDAwOiAjN2E3YTdhO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktMTAwOiAjZWZmM2Y1O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtZXJyb3I6ICNiYTBjM2Y7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy1lcnJvci1iYWNrZ3JvdW5kOiAjZmZlZmY0O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtd2FybmluZzogI2NiYTEyNztcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLXdhcm5pbmctYmFja2dyb3VuZDogI2ZmZjhlNjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZS0xMDA6ICNkZmVmZjI7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWVycm9yLXJlZC03MDA6ICNmNjI0NTk7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWJsdWUtNTAwOiAjMDA2MTkyO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlLTQwMDogIzc5Y2RlYztcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tcmVkLTUwMDogI2ZmNjU5MjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc2Vjb25kYXJ5LWJsdWUtMzAwOiAjMTNhMGQzO1xyXG5cclxuXHQtLWx1bWktd2hpdGUtY29sb3I6ICNmZmZmZmY7XHJcblx0LS1sdW1pLXByaW1hcnkteWVsbG93LWNvbG9yOiAjZmFiNjAwO1xyXG59XHJcbiRjb2xvci1uZXh0Z2VuLWJsdWU6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZSk7XHJcbiRjb2xvci1uZXh0Z2VuLWdyZWVuOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuKTtcclxuJGNvbG9yLW5leHRnZW4td2hpdGU6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4td2hpdGUpO1xyXG4kY29sb3ItbmV4dGdlbi1ibGFjazogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ibGFjayk7XHJcbiRjb2xvci1uZXh0Z2VuLWdyZXktYmFja2dyb3VuZDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmV5LWJhY2tncm91bmQpO1xyXG4kY29sb3ItbmV4dGdlbi1ncmV5OiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZXkpO1xyXG4kY29sb3ItbmV4dGdlbi1zdG9uZS1ncmV5OiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXN0b25lLWdyZXkpO1xyXG4kY29sb3ItbmV4dGdlbi1lcnJvcjogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1lcnJvcik7XHJcbiRjb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleTogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXkpO1xyXG4kY29sb3ItbmV4dGdlbi1maWJyYW50LWdyZWVuOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWZpYnJhbnQtZ3JlZW4pO1xyXG4kY29sb3ItbmV4dGdlbi13YXJuaW5nOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXdhcm5pbmcpO1xyXG4kY29sb3ItbmV4dGdlbi1ncmVlbi1iYWNrZ3JvdW5kOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuLWJhY2tncm91bmQpO1xyXG4kY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNTA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTUwKTtcclxuJGNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTQwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNDAwKTtcclxuJGNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTEwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktMTAwKTtcclxuJGNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy1lcnJvcik7XHJcbiRjb2xvci1uZXh0Z2VuLXN0YXR1cy1lcnJvci1iYWNrZ3JvdW5kOiB2YXIoXHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy1lcnJvci1iYWNrZ3JvdW5kXHJcbik7XHJcbiRjb2xvci1uZXh0Z2VuLXN0YXR1cy13YXJuaW5nOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy13YXJuaW5nKTtcclxuJGNvbG9yLW5leHRnZW4tc3RhdHVzLXdhcm5pbmctYmFja2dyb3VuZDogdmFyKFxyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtd2FybmluZy1iYWNrZ3JvdW5kXHJcbik7XHJcbiRjb2xvci1uZXh0Z2VuLWJsdWUtMTAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWJsdWUtMTAwKTtcclxuJGNvbG9yLW5leHRnZW4tZXJyb3ItcmVkLTcwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1lcnJvci1yZWQtNzAwKTtcclxuJGNvbG9yLW5leHRnZW4tYmx1ZS01MDA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZS01MDApO1xyXG4kY29sb3ItbmV4dGdlbi1ibHVlLTQwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlLTQwMCk7XHJcbiRjb2xvci1uZXh0Z2VuLXJlZC01MDA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tcmVkLTUwMCk7XHJcbiRjb2xvci1uZXh0Z2VuLXNlY29uZGFyeS1ibHVlLTMwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1zZWNvbmRhcnktYmx1ZS0zMDApO1xyXG5cclxuLmlvbi1jb2xvci1ncmVlbiB7XHJcblx0LS1pb24tY29sb3ItYmFzZTogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbik7XHJcblx0LS1pb24tY29sb3ItYmFzZS1yZ2I6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4pO1xyXG5cdC0taW9uLWNvbG9yLWNvbnRyYXN0OiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXdoaXRlKTtcclxuXHQtLWlvbi1jb2xvci1jb250cmFzdC1yZ2I6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4pO1xyXG5cdC0taW9uLWNvbG9yLXNoYWRlOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuKTtcclxuXHQtLWlvbi1jb2xvci10aW50OiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuKTtcclxufVxyXG4iLCJAaW1wb3J0IFwiLi4vLi4vLi4vLi4vY29sb3Iuc2Nzc1wiO1xyXG5cclxuLmhlYWRlci1pbnZhbGlkIHtcclxuICAgIGp1c3RpZnktY29udGVudDogdW5zZXQgIWltcG9ydGFudDtcclxuICAgIGRpc3BsYXk6IHVuc2V0ICFpbXBvcnRhbnQ7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBjb2xvcjogJGNvbG9yLW5leHRnZW4tYmx1ZTtcclxufVxyXG5cclxuLmltZy1sb2NrIHtcclxuICAgIHBhZGRpbmctYm90dG9tOiAxcmVtO1xyXG59XHJcbi5ib2R5LXBvcHVwe1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbn1cclxuLnBvcHVwe1xyXG4gICAgcG9zaXRpb246IHN0aWNreTtcclxuICAgIHRvcDogMnJlbSAhaW1wb3J0YW50O1xyXG59Il19 */";

/***/ }),

/***/ 54510:
/*!******************************************************************************!*\
  !*** ./src/app/pages/set-new-password/set-new-password.page.scss?ngResource ***!
  \******************************************************************************/
/***/ ((module) => {

module.exports = ":root {\n  --nc-color-nextgen-neutral-grey-50: #f1efef;\n  --nc-color-nextgen-white: #ffffff;\n  --nc-color-nextgen-blue: #0d152e;\n  --nc-color-nextgen-green: #00908d;\n  --nc-color-nextgen-black: #000000;\n  --nc-color-nextgen-grey-background: #c8d3da;\n  --nc-color-nextgen-grey: #92a2ac;\n  --nc-color-nextgen-stone-grey: #fafafa;\n  --nc-color-nextgen-error: #fc1055;\n  --nc-color-nextgen-neutral-grey: #414141;\n  --nc-color-nextgen-fibrant-green: #00bab6;\n  --nc-color-nextgen-warning: #ffd048;\n  --nc-color-nextgen-green-background: #e6f2f2;\n  --nc-color-nextgen-neutral-grey-400: #7a7a7a;\n  --nc-color-nextgen-neutral-grey-100: #eff3f5;\n  --nc-color-nextgen-status-error: #ba0c3f;\n  --nc-color-nextgen-status-error-background: #ffeff4;\n  --nc-color-nextgen-status-warning: #cba127;\n  --nc-color-nextgen-status-warning-background: #fff8e6;\n  --nc-color-nextgen-blue-100: #dfeff2;\n  --nc-color-nextgen-error-red-700: #f62459;\n  --nc-color-nextgen-blue-500: #006192;\n  --nc-color-nextgen-blue-400: #79cdec;\n  --nc-color-nextgen-red-500: #ff6592;\n  --nc-color-nextgen-secondary-blue-300: #13a0d3;\n  --lumi-white-color: #ffffff;\n  --lumi-primary-yellow-color: #fab600;\n}\n\n.ion-color-green {\n  --ion-color-base: var(--nc-color-nextgen-green);\n  --ion-color-base-rgb: var(--nc-color-nextgen-green);\n  --ion-color-contrast: var(--nc-color-nextgen-white);\n  --ion-color-contrast-rgb: var(--nc-color-nextgen-green);\n  --ion-color-shade: var(--nc-color-nextgen-green);\n  --ion-color-tint: var(--nc-color-nextgen-green);\n}\n\n.forgot-password-container {\n  background: var(--nc-color-nextgen-neutral-grey-50);\n}\n\n.set-new-header {\n  justify-content: space-between;\n}\n\n.body-content {\n  padding-top: 2rem;\n  min-height: 85%;\n  padding-bottom: 3rem;\n}\n\n.need-help-text {\n  color: var(--nc-color-nextgen-green);\n  float: right !important;\n}\n\n.text-detail {\n  color: var(--nc-color-nextgen-neutral-grey);\n  padding-top: 2rem;\n}\n\n.form-forgot-pass {\n  width: 100%;\n  padding-top: 2rem;\n}\n\n.resend-text {\n  color: var(--nc-color-nextgen-green);\n}\n\n.send-reset-link {\n  text-align: center;\n  padding-top: 6rem;\n}\n\n.send-new-otp {\n  text-align: center;\n  padding-top: 1rem;\n}\n\n.validation-summary-password {\n  list-style: none;\n}\n\n.validation-summary-password li {\n  display: flex;\n}\n\n.validation-summary-password li .check-place {\n  color: var(--nc-color-nextgen-green) !important;\n}\n\n.text-validation {\n  color: var(--nc-color-nextgen-grey) !important;\n}\n\n.check-place {\n  width: 22px;\n  height: auto;\n}\n\n.input-box {\n  padding-top: 1rem;\n  display: flex;\n  justify-content: space-around;\n  align-items: center;\n}\n\n.input-number {\n  background: #FFFFFF;\n  border: 1px solid #C8D3DA;\n  border-radius: 8px;\n  width: 56px;\n  height: 65px;\n}\n\n.space {\n  margin-left: 1.25rem;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXGNvbG9yLnNjc3MiLCJzZXQtbmV3LXBhc3N3b3JkLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNDLDJDQUFBO0VBQ0EsaUNBQUE7RUFDQSxnQ0FBQTtFQUNBLGlDQUFBO0VBQ0EsaUNBQUE7RUFDQSwyQ0FBQTtFQUNBLGdDQUFBO0VBQ0Esc0NBQUE7RUFDQSxpQ0FBQTtFQUNBLHdDQUFBO0VBQ0EseUNBQUE7RUFDQSxtQ0FBQTtFQUNBLDRDQUFBO0VBQ0EsNENBQUE7RUFDQSw0Q0FBQTtFQUNBLHdDQUFBO0VBQ0EsbURBQUE7RUFDQSwwQ0FBQTtFQUNBLHFEQUFBO0VBQ0Esb0NBQUE7RUFDQSx5Q0FBQTtFQUNBLG9DQUFBO0VBQ0Esb0NBQUE7RUFDQSxtQ0FBQTtFQUNBLDhDQUFBO0VBRUEsMkJBQUE7RUFDQSxvQ0FBQTtBQ0FEOztBRGdDQTtFQUNDLCtDQUFBO0VBQ0EsbURBQUE7RUFDQSxtREFBQTtFQUNBLHVEQUFBO0VBQ0EsZ0RBQUE7RUFDQSwrQ0FBQTtBQzdCRDs7QUFuQ0E7RUFDSSxtRER1QzRCO0FDRGhDOztBQW5DQTtFQUNJLDhCQUFBO0FBc0NKOztBQW5DQTtFQUNJLGlCQUFBO0VBQ0EsZUFBQTtFQUNBLG9CQUFBO0FBc0NKOztBQW5DQTtFQUNJLG9DRGNrQjtFQ2JsQix1QkFBQTtBQXNDSjs7QUFuQ0E7RUFDSSwyQ0RnQnlCO0VDZnpCLGlCQUFBO0FBc0NKOztBQW5DQTtFQUNJLFdBQUE7RUFDQSxpQkFBQTtBQXNDSjs7QUFwQ0E7RUFDSSxvQ0FBQTtBQXVDSjs7QUFyQ0E7RUFDSSxrQkFBQTtFQUNBLGlCQUFBO0FBd0NKOztBQXRDQTtFQUNJLGtCQUFBO0VBQ0EsaUJBQUE7QUF5Q0o7O0FBdkNBO0VBQ0ksZ0JBQUE7QUEwQ0o7O0FBeENJO0VBQ0ksYUFBQTtBQTBDUjs7QUF4Q1E7RUFDSSwrQ0FBQTtBQTBDWjs7QUFyQ0E7RUFDSSw4Q0FBQTtBQXdDSjs7QUFyQ0E7RUFDSSxXQUFBO0VBQ0EsWUFBQTtBQXdDSjs7QUF0Q0E7RUFDSSxpQkFBQTtFQUNBLGFBQUE7RUFDQSw2QkFBQTtFQUNBLG1CQUFBO0FBeUNKOztBQXRDQTtFQUNJLG1CQUFBO0VBQ0EseUJBQUE7RUFDQSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0FBeUNKOztBQXZDQTtFQUNJLG9CQUFBO0FBMENKIiwiZmlsZSI6InNldC1uZXctcGFzc3dvcmQucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiOnJvb3Qge1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNTA6ICNmMWVmZWY7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXdoaXRlOiAjZmZmZmZmO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlOiAjMGQxNTJlO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbjogIzAwOTA4ZDtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tYmxhY2s6ICMwMDAwMDA7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWdyZXktYmFja2dyb3VuZDogI2M4ZDNkYTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tZ3JleTogIzkyYTJhYztcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc3RvbmUtZ3JleTogI2ZhZmFmYTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tZXJyb3I6ICNmYzEwNTU7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleTogIzQxNDE0MTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tZmlicmFudC1ncmVlbjogIzAwYmFiNjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4td2FybmluZzogI2ZmZDA0ODtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4tYmFja2dyb3VuZDogI2U2ZjJmMjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTQwMDogIzdhN2E3YTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTEwMDogI2VmZjNmNTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yOiAjYmEwYzNmO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtZXJyb3ItYmFja2dyb3VuZDogI2ZmZWZmNDtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLXdhcm5pbmc6ICNjYmExMjc7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy13YXJuaW5nLWJhY2tncm91bmQ6ICNmZmY4ZTY7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWJsdWUtMTAwOiAjZGZlZmYyO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1lcnJvci1yZWQtNzAwOiAjZjYyNDU5O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlLTUwMDogIzAwNjE5MjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZS00MDA6ICM3OWNkZWM7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXJlZC01MDA6ICNmZjY1OTI7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXNlY29uZGFyeS1ibHVlLTMwMDogIzEzYTBkMztcclxuXHJcblx0LS1sdW1pLXdoaXRlLWNvbG9yOiAjZmZmZmZmO1xyXG5cdC0tbHVtaS1wcmltYXJ5LXllbGxvdy1jb2xvcjogI2ZhYjYwMDtcclxufVxyXG4kY29sb3ItbmV4dGdlbi1ibHVlOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWJsdWUpO1xyXG4kY29sb3ItbmV4dGdlbi1ncmVlbjogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbik7XHJcbiRjb2xvci1uZXh0Z2VuLXdoaXRlOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXdoaXRlKTtcclxuJGNvbG9yLW5leHRnZW4tYmxhY2s6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tYmxhY2spO1xyXG4kY29sb3ItbmV4dGdlbi1ncmV5LWJhY2tncm91bmQ6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JleS1iYWNrZ3JvdW5kKTtcclxuJGNvbG9yLW5leHRnZW4tZ3JleTogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmV5KTtcclxuJGNvbG9yLW5leHRnZW4tc3RvbmUtZ3JleTogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1zdG9uZS1ncmV5KTtcclxuJGNvbG9yLW5leHRnZW4tZXJyb3I6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZXJyb3IpO1xyXG4kY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXk6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5KTtcclxuJGNvbG9yLW5leHRnZW4tZmlicmFudC1ncmVlbjogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1maWJyYW50LWdyZWVuKTtcclxuJGNvbG9yLW5leHRnZW4td2FybmluZzogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi13YXJuaW5nKTtcclxuJGNvbG9yLW5leHRnZW4tZ3JlZW4tYmFja2dyb3VuZDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbi1iYWNrZ3JvdW5kKTtcclxuJGNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTUwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS01MCk7XHJcbiRjb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS00MDA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTQwMCk7XHJcbiRjb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS0xMDA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTEwMCk7XHJcbiRjb2xvci1uZXh0Z2VuLXN0YXR1cy1lcnJvcjogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtZXJyb3IpO1xyXG4kY29sb3ItbmV4dGdlbi1zdGF0dXMtZXJyb3ItYmFja2dyb3VuZDogdmFyKFxyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtZXJyb3ItYmFja2dyb3VuZFxyXG4pO1xyXG4kY29sb3ItbmV4dGdlbi1zdGF0dXMtd2FybmluZzogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtd2FybmluZyk7XHJcbiRjb2xvci1uZXh0Z2VuLXN0YXR1cy13YXJuaW5nLWJhY2tncm91bmQ6IHZhcihcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLXdhcm5pbmctYmFja2dyb3VuZFxyXG4pO1xyXG4kY29sb3ItbmV4dGdlbi1ibHVlLTEwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlLTEwMCk7XHJcbiRjb2xvci1uZXh0Z2VuLWVycm9yLXJlZC03MDA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZXJyb3ItcmVkLTcwMCk7XHJcbiRjb2xvci1uZXh0Z2VuLWJsdWUtNTAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWJsdWUtNTAwKTtcclxuJGNvbG9yLW5leHRnZW4tYmx1ZS00MDA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZS00MDApO1xyXG4kY29sb3ItbmV4dGdlbi1yZWQtNTAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXJlZC01MDApO1xyXG4kY29sb3ItbmV4dGdlbi1zZWNvbmRhcnktYmx1ZS0zMDA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tc2Vjb25kYXJ5LWJsdWUtMzAwKTtcclxuXHJcbi5pb24tY29sb3ItZ3JlZW4ge1xyXG5cdC0taW9uLWNvbG9yLWJhc2U6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4pO1xyXG5cdC0taW9uLWNvbG9yLWJhc2UtcmdiOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuKTtcclxuXHQtLWlvbi1jb2xvci1jb250cmFzdDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi13aGl0ZSk7XHJcblx0LS1pb24tY29sb3ItY29udHJhc3QtcmdiOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuKTtcclxuXHQtLWlvbi1jb2xvci1zaGFkZTogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbik7XHJcblx0LS1pb24tY29sb3ItdGludDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbik7XHJcbn1cclxuIiwiQGltcG9ydCBcIi4uLy4uLy4uL2NvbG9yLnNjc3NcIjtcclxuXHJcbi5mb3Jnb3QtcGFzc3dvcmQtY29udGFpbmVyIHtcclxuICAgIGJhY2tncm91bmQ6ICRjb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS01MDtcclxufVxyXG5cclxuLnNldC1uZXctaGVhZGVye1xyXG4gICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xyXG59XHJcblxyXG4uYm9keS1jb250ZW50IHtcclxuICAgIHBhZGRpbmctdG9wOiAycmVtO1xyXG4gICAgbWluLWhlaWdodDogODUlO1xyXG4gICAgcGFkZGluZy1ib3R0b206IDNyZW07XHJcbn1cclxuXHJcbi5uZWVkLWhlbHAtdGV4dCB7XHJcbiAgICBjb2xvcjogJGNvbG9yLW5leHRnZW4tZ3JlZW47XHJcbiAgICBmbG9hdDogcmlnaHQgIWltcG9ydGFudDtcclxufVxyXG5cclxuLnRleHQtZGV0YWlsIHtcclxuICAgIGNvbG9yOiAkY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXk7XHJcbiAgICBwYWRkaW5nLXRvcDogMnJlbTtcclxufVxyXG5cclxuLmZvcm0tZm9yZ290LXBhc3Mge1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBwYWRkaW5nLXRvcDogMnJlbTtcclxufVxyXG4ucmVzZW5kLXRleHR7XHJcbiAgICBjb2xvcjogJGNvbG9yLW5leHRnZW4tZ3JlZW47XHJcbn1cclxuLnNlbmQtcmVzZXQtbGluayB7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBwYWRkaW5nLXRvcDogNnJlbTtcclxufVxyXG4uc2VuZC1uZXctb3Rwe1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgcGFkZGluZy10b3A6IDFyZW07XHJcbn1cclxuLnZhbGlkYXRpb24tc3VtbWFyeS1wYXNzd29yZCB7XHJcbiAgICBsaXN0LXN0eWxlOiBub25lO1xyXG5cclxuICAgIGxpIHtcclxuICAgICAgICBkaXNwbGF5OiBmbGV4O1xyXG5cclxuICAgICAgICAuY2hlY2stcGxhY2Uge1xyXG4gICAgICAgICAgICBjb2xvcjogJGNvbG9yLW5leHRnZW4tZ3JlZW4gICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59XHJcblxyXG4udGV4dC12YWxpZGF0aW9uIHtcclxuICAgIGNvbG9yOiAkY29sb3ItbmV4dGdlbi1ncmV5ICAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4uY2hlY2stcGxhY2Uge1xyXG4gICAgd2lkdGg6IDIycHg7XHJcbiAgICBoZWlnaHQ6IGF1dG87XHJcbn1cclxuLmlucHV0LWJveHtcclxuICAgIHBhZGRpbmctdG9wOiAxcmVtO1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGp1c3RpZnktY29udGVudDogc3BhY2UtYXJvdW5kO1xyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxufVxyXG5cclxuLmlucHV0LW51bWJlcntcclxuICAgIGJhY2tncm91bmQ6ICNGRkZGRkY7XHJcbiAgICBib3JkZXI6IDFweCBzb2xpZCAjQzhEM0RBO1xyXG4gICAgYm9yZGVyLXJhZGl1czogOHB4O1xyXG4gICAgd2lkdGg6IDU2cHg7XHJcbiAgICBoZWlnaHQ6IDY1cHg7XHJcbn1cclxuLnNwYWNle1xyXG4gICAgbWFyZ2luLWxlZnQ6IDEuMjVyZW07XHJcbn0iXX0= */";

/***/ }),

/***/ 34140:
/*!**********************************************************************************************!*\
  !*** ./src/app/pages/set-new-password/alert-success/alert-success.component.html?ngResource ***!
  \**********************************************************************************************/
/***/ ((module) => {

module.exports = "<div class=\"popup\">\r\n  <div class=\"header-invalid\">\r\n    <div class=\"img-lock\"><img src=\"../../../../assets/images/lock.svg\" /></div>\r\n    <div class=\"h3 bold\"> {{header| translate}}</div>\r\n  </div>\r\n  <div class=\"body-popup\">\r\n    <body-error-dialog [nameButtonSubmit]=\"nameButton| translate\" (onSubmitHandler)=\"onSubmit()\"\r\n      [valueContent]=\"valueContent|translate\">\r\n    </body-error-dialog>\r\n  </div>\r\n</div>";

/***/ }),

/***/ 25293:
/*!******************************************************************************!*\
  !*** ./src/app/pages/set-new-password/set-new-password.page.html?ngResource ***!
  \******************************************************************************/
/***/ ((module) => {

module.exports = "<div class=\"forgot-password-container\">\r\n    <nextcare-layout>\r\n        <ng-template header>\r\n            <ion-row class=\"set-new-header d-flex\">\r\n                <div>\r\n                    <button class=\"btn btn-circle\" (click)=\"onBack()\">\r\n                        <ion-icon  class=\"icon-back body-l\" name=\"arrow-back-outline\"></ion-icon>\r\n                    </button>\r\n                </div>\r\n                <div>\r\n                    <span class=\"need-help-text body-l bold\" (click)=\"redirectToNeedHelp()\">{{\r\n                        'addInsurance.needHelp' |\r\n                        translate }}</span>\r\n                </div>\r\n            </ion-row>\r\n        </ng-template>\r\n        <ng-template body>\r\n            <div class=\"body-content\">\r\n                <div class=\"h3 bold\">\r\n                    {{'setNewPassWord.title' | translate}}\r\n                </div>\r\n                <div class=\"text-detail body-sm\">\r\n                    {{'setNewPassWord.pleaseEnterYourNewPassword' | translate}}\r\n                </div>\r\n                <div>\r\n                    <form class=\"form-forgot-pass\" [formGroup]=\"newPasswordForm\">\r\n                        <div>\r\n                            <nextgen-control formControlName=\"otpcode\" [type]=\"TYPE.INPUTNUMBER\"\r\n                            [label-property]=\"'otp.verifyCode' | translate\" [placeholder]=\"'otp.enterOTP' | translate\">\r\n                            </nextgen-control>\r\n                            <nextgen-control [type]=\"typeInputPassword\"\r\n                                [label-property]=\"'setNewPassWord.textNewPassword' | translate\"\r\n                                [placeholder]=\"'signup.passwordPlaceholder' | translate\" first-icon=\"uil uil-lock-alt\"\r\n                                [progress-status]=\"progressPassword\" [has-progress-bar]=\"isProgressBarPassword\"\r\n                                [second-icon]=\"secondIcon\" (secondIconHandler)=\"togglePassword()\"\r\n                                formControlName=\"password\" [native-template]=\"nativeTemplateValidation\"\r\n                                (click)=\"onFocusPasswordControl()\">\r\n                            </nextgen-control>\r\n                            <ng-template #nativeTemplateValidation>\r\n                                <ul class=\"validation-summary-password\">\r\n                                    <li *ngFor=\"let val of messageValidations\">\r\n                                        <div class=\"check-place\">\r\n                                            <i [ngClass]=\"verifyPass(val.key)?'uis uis-check-circle':''\"\r\n                                                class=\"check-place mr-1\"></i>\r\n                                        </div>\r\n                                        <span class=\"text-validation\">{{val.text| translate}}</span>\r\n                                    </li>\r\n                                </ul>\r\n                            </ng-template>\r\n                        </div>\r\n                        <div [ngStyle]=\"{'display': count==0 ? 'block': 'none'}\" class=\"send-new-otp\">\r\n                            <div class=\"resend-text body-n bold\" (click)=\"resendOTP()\">\r\n                                {{'setNewPassWord.sendNewOTP'| translate}}\r\n                            </div>\r\n                        </div>\r\n                        <div class=\"send-reset-link\">\r\n                            <button class=\"btn btn-large primary bold\" [disabled]=\"newPasswordForm.invalid\"\r\n                                (click)=\"confirm()\">{{\r\n                                'setNewPassWord.confirm' | translate }}</button>\r\n                        </div>\r\n                    </form>\r\n                </div>\r\n            </div>\r\n        </ng-template>\r\n    </nextcare-layout>\r\n</div>";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_set-new-password_set-new-password_module_ts.js.map