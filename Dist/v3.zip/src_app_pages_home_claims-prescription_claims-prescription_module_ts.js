"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_home_claims-prescription_claims-prescription_module_ts"],{

/***/ 51199:
/*!**************************************************************************************!*\
  !*** ./src/app/pages/home/claims-prescription/claims-prescription-routing.module.ts ***!
  \**************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ClaimsPrescriptionPageRoutingModule": () => (/* binding */ ClaimsPrescriptionPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _claims_prescription_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./claims-prescription.page */ 82967);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);




const routes = [
    {
        path: '',
        component: _claims_prescription_page__WEBPACK_IMPORTED_MODULE_0__.ClaimsPrescriptionPage
    },
];
let ClaimsPrescriptionPageRoutingModule = class ClaimsPrescriptionPageRoutingModule {
};
ClaimsPrescriptionPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], ClaimsPrescriptionPageRoutingModule);



/***/ }),

/***/ 95417:
/*!******************************************************************************!*\
  !*** ./src/app/pages/home/claims-prescription/claims-prescription.module.ts ***!
  \******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ClaimsPrescriptionPageModule": () => (/* binding */ ClaimsPrescriptionPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _claims_prescription_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./claims-prescription.page */ 82967);
/* harmony import */ var _claims_prescription_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./claims-prescription-routing.module */ 51199);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _prescription_content_prescription_content_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./prescription-content/prescription-content.component */ 95930);
/* harmony import */ var _angular_cdk_scrolling__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/cdk/scrolling */ 95752);
/* harmony import */ var src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/shared/shared.module */ 44466);










let ClaimsPrescriptionPageModule = class ClaimsPrescriptionPageModule {
};
ClaimsPrescriptionPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_6__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.IonicModule,
            src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_3__.SharedModule,
            _angular_cdk_scrolling__WEBPACK_IMPORTED_MODULE_9__.ScrollingModule,
            _claims_prescription_routing_module__WEBPACK_IMPORTED_MODULE_1__.ClaimsPrescriptionPageRoutingModule
        ],
        declarations: [
            _claims_prescription_page__WEBPACK_IMPORTED_MODULE_0__.ClaimsPrescriptionPage,
            _prescription_content_prescription_content_component__WEBPACK_IMPORTED_MODULE_2__.PrescriptionContentComponent,
        ]
    })
], ClaimsPrescriptionPageModule);



/***/ }),

/***/ 82967:
/*!****************************************************************************!*\
  !*** ./src/app/pages/home/claims-prescription/claims-prescription.page.ts ***!
  \****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ClaimsPrescriptionPage": () => (/* binding */ ClaimsPrescriptionPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _claims_prescription_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./claims-prescription.page.html?ngResource */ 18181);
/* harmony import */ var _claims_prescription_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./claims-prescription.page.scss?ngResource */ 87651);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var src_app_service_insurance_insurance_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/service/insurance/insurance.service */ 57072);
/* harmony import */ var src_app_service_home_prescription_claims_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/service/home/prescription-claims.service */ 55008);
/* harmony import */ var src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/shared/data/constants */ 74676);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs */ 92218);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! rxjs/operators */ 85921);
/* harmony import */ var src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/shared/data/enum/screen */ 68302);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @ionic/storage-angular */ 80190);
/* harmony import */ var src_app_service_cms_search_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/service/cms/search.service */ 81563);



/* eslint-disable @typescript-eslint/no-unused-vars */












let ClaimsPrescriptionPage = class ClaimsPrescriptionPage {
    constructor(location, insuranceService, claimsService, router, platform, storage, searchService) {
        this.location = location;
        this.insuranceService = insuranceService;
        this.claimsService = claimsService;
        this.router = router;
        this.platform = platform;
        this.storage = storage;
        this.searchService = searchService;
        this.status = src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_4__.Constants.EFERRAL_STATUS;
        this.tab = 'referral';
        this.paging = {
            pageNo: 1,
            pageSize: 5,
            pageCount: null,
        };
        this.unsubscribe$ = new rxjs__WEBPACK_IMPORTED_MODULE_7__.Subject();
    }
    get isOpen() {
        return this.searchService.getIsOpen();
    }
    set isOpen(value) {
        this.searchService.setIsOpen(value);
    }
    ionViewWillEnter() {
        this.unsubscribe$ = new rxjs__WEBPACK_IMPORTED_MODULE_7__.Subject();
        this.getPolicyInformation();
    }
    ionViewWillLeave() {
        this.unsubscribe$.next();
        this.unsubscribe$.complete();
        this.subscription.unsubscribe();
    }
    ionViewDidEnter() {
        this.subscription = this.platform.backButton.subscribeWithPriority(9999, () => (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__awaiter)(this, void 0, void 0, function* () {
            const isClaimsPrescription = yield this.storage.get(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_4__.Constants.OPENNED_CLAIMS_PRESCRIPTION);
            if (this.isOpen == true) {
                this.isOpen = false;
            }
            else {
                if (isClaimsPrescription == true) {
                    yield this.storage.set(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_4__.Constants.OPENNED_CLAIMS_PRESCRIPTION, false);
                    this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_5__.Screens.HomeCare]);
                }
                else {
                    this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_5__.Screens.Home]);
                }
            }
        }));
    }
    onBack() {
        this.location.back();
    }
    getPolicyInformation() {
        this.insuranceService.getPolicyInformation().pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_9__.takeUntil)(this.unsubscribe$)).subscribe((res) => {
            if (!res)
                return;
            this.currentPolicy = res;
            this.getMemberList();
            this.getListFilter();
            this.currentFilter = {
                beneficiaryId: [this.currentPolicy.beneficiaryId]
            };
            this.onSearchChange(this.currentFilter);
        });
    }
    getMemberList() {
        const memberList = this.insuranceService.getMemberListValue();
        this.members = memberList.map((res) => ({
            id: res.beneficiaryId,
            name: res.benefFullName,
        }));
    }
    getListFilter(erxreferenceNbrCondition) {
        if (this.tab === 'referral') {
            this.listFilter = [
                // {
                //   filterName: 'Referral Status',
                //   conditions: this.status,
                //   singleSelections: true,
                //   paramName: 'activeEreferral',
                // },
                {
                    filterName: 'filter.beneficiary',
                    conditions: this.members,
                    required: true,
                    singleSelections: true,
                    paramName: 'beneficiaryId',
                    initValues: [this.currentPolicy.beneficiaryId]
                },
                // {
                //   filterName: 'Referral Number',
                //   conditions: erxreferenceNbrCondition || [],
                //   singleSelections: true,
                //   paramName: 'erxreferenceNbr'
                // },
            ];
        }
        else {
            this.listFilter = [
                {
                    filterName: 'Prescription Status',
                    conditions: this.status,
                    singleSelections: true,
                    paramName: 'activePrescription',
                },
                {
                    filterName: 'filter.beneficiary',
                    conditions: this.members,
                    singleSelections: true,
                    paramName: 'beneficiaryId',
                    initValues: [this.currentPolicy.beneficiaryId]
                },
                {
                    filterName: 'E-Rx Number',
                    conditions: erxreferenceNbrCondition || [],
                    singleSelections: true,
                    paramName: 'erxreferenceNbr'
                },
            ];
        }
    }
    segmentChanged(event) {
        this.tab = event.detail.value;
        this.getListFilter();
        this.onSearchChange(this.currentFilter);
    }
    onSearchChange(model) {
        var _a, _b, _c;
        if (((_a = model === null || model === void 0 ? void 0 : model.keyword) === null || _a === void 0 ? void 0 : _a.length) > 0) {
            model.eReferallNo = model.keyword;
        }
        this.currentFilter = model;
        if (this.tab == 'referral') {
            const searchCondition = Object.assign(Object.assign(Object.assign({}, model), this.paging), { userPolicyId: this.currentPolicy.userPolicyId, beneficiaryId: ((_b = model === null || model === void 0 ? void 0 : model.beneficiaryId) === null || _b === void 0 ? void 0 : _b.length) > 0 && (model === null || model === void 0 ? void 0 : model.beneficiaryId) || this.currentPolicy.beneficiaryId });
            this.claimsService.getEreferral(searchCondition).subscribe((res) => {
                if (res) {
                    this.details = this.details.concat(res.results.map((value) => {
                        const expiryDate = value.expDate;
                        const remainingEreferral = value.remainingEreferral;
                        const member = this.members.find(_ => _.id === value.beneficiaryId);
                        if (expiryDate && new Date().getTime() > new Date(expiryDate).getTime() || ((remainingEreferral - 1) === -1) || remainingEreferral === null) {
                            value.active = false;
                        }
                        else {
                            value.active = true;
                        }
                        return Object.assign({ benefFullName: member.name }, value);
                    }).filter((_) => _).sort((a, b) => new Date(b.expDate).getTime() - new Date(a.expDate).getTime()));
                    const erxreferenceNbrInfo = res.results.map((data) => ({
                        id: data.erxreferenceNbr,
                        name: data.erxreferenceNbr
                    }));
                    const allowedUtilizationFrequency = res.allowedUtilizationFrequency;
                    this.listFilter.find(e => e.paramName === 'erxreferenceNbr').conditions = erxreferenceNbrInfo;
                    this.paging = {
                        pageNo: res.page,
                        pageSize: res.pageSize,
                        pageCount: res.pageCount,
                    };
                }
                else {
                    this.details = [];
                    this.paging = {
                        pageNo: 1,
                        pageSize: 5,
                        pageCount: null,
                    };
                }
                ;
            });
        }
        else {
            this.claimsService.getPrescription(Object.assign(Object.assign(Object.assign({}, model), this.paging), { userPolicyId: this.currentPolicy.userPolicyId, beneficiaryId: ((_c = model === null || model === void 0 ? void 0 : model.beneficiaryId) === null || _c === void 0 ? void 0 : _c.length) > 0 && (model === null || model === void 0 ? void 0 : model.beneficiaryId) || this.currentPolicy.beneficiaryId })).subscribe((res) => {
                if (res) {
                    this.details = res.map((res) => {
                        const expiryDate = res.expiryDate;
                        const remainingEreferral = res.remainingEreferral;
                        if (expiryDate && new Date().getTime() > new Date(expiryDate).getTime() || ((remainingEreferral - 1) === -1) || remainingEreferral === null) {
                            res.active = false;
                        }
                        else {
                            res.active = true;
                        }
                        return res;
                    });
                    const allowedUtilizationFrequency = res.allowedUtilizationFrequency;
                    const erxreferenceNbrInfo = res.map((data) => ({
                        id: data.erxreferenceNbr,
                        name: data.erxreferenceNbr
                    }));
                    this.listFilter.find(e => e.paramName === 'erxreferenceNbr').conditions = erxreferenceNbrInfo;
                    this.paging = {
                        pageNo: res.page,
                        pageSize: res.pageSize,
                        pageCount: res.pageCount,
                    };
                }
                else {
                    this.details = [];
                    this.paging = {
                        pageNo: 1,
                        pageSize: 5,
                        pageCount: null,
                    };
                }
                ;
            });
        }
    }
    logScrolling() {
        this.detectBottom();
    }
    refreshReferralHistory() {
        this.onSearchChange(this.currentFilter);
    }
    detectBottom() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__awaiter)(this, void 0, void 0, function* () {
            const scrollElement = yield this.content.getScrollElement(); // get scroll element
            // calculate if max bottom was reached
            if (scrollElement.scrollTop ===
                scrollElement.scrollHeight - scrollElement.clientHeight - 1) {
                console.info('max bottom was reached!');
                this.paging.pageNo = this.paging.pageNo + 1;
                this.onSearchChange(this.currentFilter);
            }
        });
    }
};
ClaimsPrescriptionPage.ctorParameters = () => [
    { type: _angular_common__WEBPACK_IMPORTED_MODULE_10__.Location },
    { type: src_app_service_insurance_insurance_service__WEBPACK_IMPORTED_MODULE_2__.InsuranceService },
    { type: src_app_service_home_prescription_claims_service__WEBPACK_IMPORTED_MODULE_3__.PrescriptionClaimsService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_11__.Router },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_12__.Platform },
    { type: _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_13__.Storage },
    { type: src_app_service_cms_search_service__WEBPACK_IMPORTED_MODULE_6__.SearchService }
];
ClaimsPrescriptionPage.propDecorators = {
    content: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_14__.ViewChild, args: [_ionic_angular__WEBPACK_IMPORTED_MODULE_12__.IonContent,] }]
};
ClaimsPrescriptionPage = (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_14__.Component)({
        selector: 'app-claims-prescription',
        template: _claims_prescription_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_claims_prescription_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], ClaimsPrescriptionPage);



/***/ }),

/***/ 95930:
/*!*******************************************************************************************************!*\
  !*** ./src/app/pages/home/claims-prescription/prescription-content/prescription-content.component.ts ***!
  \*******************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PrescriptionContentComponent": () => (/* binding */ PrescriptionContentComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _prescription_content_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./prescription-content.component.html?ngResource */ 19638);
/* harmony import */ var _prescription_content_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./prescription-content.component.scss?ngResource */ 89785);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/shared/data/enum/screen */ 68302);
/* harmony import */ var src_app_service_utilities_third_party_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/service/utilities/third-party.service */ 47617);
/* harmony import */ var src_app_service_insurance_insurance_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/service/insurance/insurance.service */ 57072);
/* harmony import */ var src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/shared/data/constants */ 74676);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/shared/data/enum/event */ 38570);
/* harmony import */ var _awesome_cordova_plugins_clevertap_ngx__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @awesome-cordova-plugins/clevertap/ngx */ 45363);
/* harmony import */ var _awesome_cordova_plugins_firebase_analytics_ngx__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @awesome-cordova-plugins/firebase-analytics/ngx */ 48852);



// import { InAppBrowser } from '@awesome-cordova-plugins/in-app-browser/ngx';










// import { environment } from '@environments/environment';
let PrescriptionContentComponent = class PrescriptionContentComponent {
    constructor(router, thirdPartyService, insuranceService, modalCtrl, clevertap, firebaseAnalytics) {
        this.router = router;
        this.thirdPartyService = thirdPartyService;
        this.insuranceService = insuranceService;
        this.modalCtrl = modalCtrl;
        this.clevertap = clevertap;
        this.firebaseAnalytics = firebaseAnalytics;
        this.bookApointmentBtn = false;
        this.orderOnlineBtn = false;
    }
    ngOnChanges() {
    }
    ngOnInit() {
        this.bookApointmentOrderOnline();
    }
    onBookApointment() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__awaiter)(this, void 0, void 0, function* () {
            this.clevertap.recordEventWithName(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_6__.GA4Event.ReferralAppointmentBookingStarted);
            this.firebaseAnalytics.logEvent(src_app_shared_data_enum_event__WEBPACK_IMPORTED_MODULE_6__.GA4Event.ReferralAppointmentBookingStarted, {});
            this.thirdPartyService.openBookAppointment();
        });
    }
    onOrderOnline() {
    }
    onViewDetail(item) {
        this.router.navigate(['/' + src_app_shared_data_enum_screen__WEBPACK_IMPORTED_MODULE_2__.Screens.PrescriptionDetails], { queryParams: item });
    }
    trackById(_, detail) {
        return detail.id;
    }
    bookApointmentOrderOnline() {
        this.bookApointmentBtn = this.insuranceService.checkPayerSetting(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_5__.Constants.APPOINTMENT_BOOKING, true);
        // const columnname = this.payerSetting?.find(res => res.columnname === 'MyNCEnableAppointmentBooking');
        // if (columnname && columnname.required === true) {
        //   this.bookApointmentBtn = true;
        // } else {
        //   this.bookApointmentBtn = false;
        // }
        this.orderOnlineBtn = this.insuranceService.checkPayerSetting(src_app_shared_data_constants__WEBPACK_IMPORTED_MODULE_5__.Constants.ENABLE_DRUG_DELIVERY, true);
        // const columnnameOrder = this.payerSetting?.find(res => res.columnname === 'MyNCDrugDelivery');
        // if (columnnameOrder && columnnameOrder.required === true) {
        //   this.orderOnlineBtn = true;
        // } else {
        //   this.orderOnlineBtn = false;
        // }
    }
};
PrescriptionContentComponent.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_10__.Router },
    { type: src_app_service_utilities_third_party_service__WEBPACK_IMPORTED_MODULE_3__.ThirdPartyService },
    { type: src_app_service_insurance_insurance_service__WEBPACK_IMPORTED_MODULE_4__.InsuranceService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_11__.ModalController },
    { type: _awesome_cordova_plugins_clevertap_ngx__WEBPACK_IMPORTED_MODULE_7__.CleverTap },
    { type: _awesome_cordova_plugins_firebase_analytics_ngx__WEBPACK_IMPORTED_MODULE_8__.FirebaseAnalytics }
];
PrescriptionContentComponent.propDecorators = {
    type: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_12__.Input }],
    details: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_12__.Input }]
};
PrescriptionContentComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_12__.Component)({
        selector: 'app-prescription-content',
        template: _prescription_content_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_prescription_content_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], PrescriptionContentComponent);



/***/ }),

/***/ 55008:
/*!*************************************************************!*\
  !*** ./src/app/service/home/prescription-claims.service.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PrescriptionClaimsService": () => (/* binding */ PrescriptionClaimsService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 28784);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @environments/environment */ 92340);




let PrescriptionClaimsService = class PrescriptionClaimsService {
    constructor(http) {
        this.http = http;
        this.url = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.ApiURL;
    }
    getEreferral(params) {
        return this.http.get(`${this.url}/mds/api/claim/v1.0/ereferral`, {
            params: Object.assign({}, params)
        });
    }
    getPrescription(params) {
        return this.http.get(`${this.url}/mds/api/claim/v1.0/prescriptions`, {
            params: Object.assign({}, params)
        });
    }
};
PrescriptionClaimsService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient }
];
PrescriptionClaimsService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root'
    })
], PrescriptionClaimsService);



/***/ }),

/***/ 87651:
/*!*****************************************************************************************!*\
  !*** ./src/app/pages/home/claims-prescription/claims-prescription.page.scss?ngResource ***!
  \*****************************************************************************************/
/***/ ((module) => {

module.exports = ":root {\n  --nc-color-nextgen-neutral-grey-50: #f1efef;\n  --nc-color-nextgen-white: #ffffff;\n  --nc-color-nextgen-blue: #0d152e;\n  --nc-color-nextgen-green: #00908d;\n  --nc-color-nextgen-black: #000000;\n  --nc-color-nextgen-grey-background: #c8d3da;\n  --nc-color-nextgen-grey: #92a2ac;\n  --nc-color-nextgen-stone-grey: #fafafa;\n  --nc-color-nextgen-error: #fc1055;\n  --nc-color-nextgen-neutral-grey: #414141;\n  --nc-color-nextgen-fibrant-green: #00bab6;\n  --nc-color-nextgen-warning: #ffd048;\n  --nc-color-nextgen-green-background: #e6f2f2;\n  --nc-color-nextgen-neutral-grey-400: #7a7a7a;\n  --nc-color-nextgen-neutral-grey-100: #eff3f5;\n  --nc-color-nextgen-status-error: #ba0c3f;\n  --nc-color-nextgen-status-error-background: #ffeff4;\n  --nc-color-nextgen-status-warning: #cba127;\n  --nc-color-nextgen-status-warning-background: #fff8e6;\n  --nc-color-nextgen-blue-100: #dfeff2;\n  --nc-color-nextgen-error-red-700: #f62459;\n  --nc-color-nextgen-blue-500: #006192;\n  --nc-color-nextgen-blue-400: #79cdec;\n  --nc-color-nextgen-red-500: #ff6592;\n  --nc-color-nextgen-secondary-blue-300: #13a0d3;\n  --lumi-white-color: #ffffff;\n  --lumi-primary-yellow-color: #fab600;\n}\n\n.ion-color-green {\n  --ion-color-base: var(--nc-color-nextgen-green);\n  --ion-color-base-rgb: var(--nc-color-nextgen-green);\n  --ion-color-contrast: var(--nc-color-nextgen-white);\n  --ion-color-contrast-rgb: var(--nc-color-nextgen-green);\n  --ion-color-shade: var(--nc-color-nextgen-green);\n  --ion-color-tint: var(--nc-color-nextgen-green);\n}\n\n/*\n * 1. Custom CSS \n * ----------------------------------------------------------------------------\n */\n\n:root {\n  --nc-color-nextgen-neutral-grey-50: #f1efef;\n  --nc-color-nextgen-white: #ffffff;\n  --nc-color-nextgen-blue: #0d152e;\n  --nc-color-nextgen-green: #00908d;\n  --nc-color-nextgen-black: #000000;\n  --nc-color-nextgen-grey-background: #c8d3da;\n  --nc-color-nextgen-grey: #92a2ac;\n  --nc-color-nextgen-stone-grey: #fafafa;\n  --nc-color-nextgen-error: #fc1055;\n  --nc-color-nextgen-neutral-grey: #414141;\n  --nc-color-nextgen-fibrant-green: #00bab6;\n  --nc-color-nextgen-warning: #ffd048;\n  --nc-color-nextgen-green-background: #e6f2f2;\n  --nc-color-nextgen-neutral-grey-400: #7a7a7a;\n  --nc-color-nextgen-neutral-grey-100: #eff3f5;\n  --nc-color-nextgen-status-error: #ba0c3f;\n  --nc-color-nextgen-status-error-background: #ffeff4;\n  --nc-color-nextgen-status-warning: #cba127;\n  --nc-color-nextgen-status-warning-background: #fff8e6;\n  --nc-color-nextgen-blue-100: #dfeff2;\n  --nc-color-nextgen-error-red-700: #f62459;\n  --nc-color-nextgen-blue-500: #006192;\n  --nc-color-nextgen-blue-400: #79cdec;\n  --nc-color-nextgen-red-500: #ff6592;\n  --nc-color-nextgen-secondary-blue-300: #13a0d3;\n  --lumi-white-color: #ffffff;\n  --lumi-primary-yellow-color: #fab600;\n}\n\n.ion-color-green {\n  --ion-color-base: var(--nc-color-nextgen-green);\n  --ion-color-base-rgb: var(--nc-color-nextgen-green);\n  --ion-color-contrast: var(--nc-color-nextgen-white);\n  --ion-color-contrast-rgb: var(--nc-color-nextgen-green);\n  --ion-color-shade: var(--nc-color-nextgen-green);\n  --ion-color-tint: var(--nc-color-nextgen-green);\n}\n\n.display-xl {\n  font-size: 41px !important;\n  font-weight: 400 !important;\n  line-height: 120% !important;\n}\n\n.display-md {\n  font-size: 36px !important;\n  font-weight: 400 !important;\n  line-height: 120% !important;\n}\n\n.h1 {\n  font-size: 31px !important;\n  font-weight: 400 !important;\n  line-height: 120% !important;\n}\n\n.h2 {\n  font-size: 28px !important;\n  font-weight: 400 !important;\n  line-height: 120% !important;\n}\n\n.h3 {\n  font-size: 25px !important;\n  font-weight: 400 !important;\n  line-height: 120% !important;\n}\n\n.h4 {\n  font-size: 22px !important;\n  font-weight: 400 !important;\n  line-height: 120% !important;\n}\n\n.h5 {\n  font-size: 19px !important;\n  font-weight: 400 !important;\n  line-height: 120% !important;\n}\n\n.h6 {\n  font-size: 17px !important;\n  font-weight: 400 !important;\n  line-height: 120% !important;\n}\n\n.body-l {\n  font-size: 17px !important;\n  font-weight: 400 !important;\n  line-height: 120% !important;\n}\n\n.body-n {\n  font-size: 15px !important;\n  font-weight: 400 !important;\n  line-height: 120% !important;\n}\n\n.body-sm {\n  font-size: 13px !important;\n  font-weight: 400 !important;\n  line-height: 120% !important;\n}\n\n.body-xs {\n  font-size: 12px !important;\n  font-weight: 400 !important;\n  line-height: 120% !important;\n}\n\n.semibold.display-xl {\n  font-weight: 600 !important;\n}\n\n.semibold.display-md {\n  font-weight: 600 !important;\n}\n\n.semibold.h1 {\n  font-weight: 600 !important;\n}\n\n.semibold.h2 {\n  font-weight: 600 !important;\n}\n\n.semibold.h3 {\n  font-weight: 600 !important;\n}\n\n.semibold.h4 {\n  font-weight: 600 !important;\n}\n\n.semibold.h5 {\n  font-weight: 600 !important;\n}\n\n.semibold.h6 {\n  font-weight: 600 !important;\n}\n\n.semibold.body-l {\n  font-weight: 600 !important;\n}\n\n.semibold.body-n {\n  font-weight: 600 !important;\n}\n\n.semibold.body-sm {\n  font-weight: 600 !important;\n}\n\n.semibold.body-xs {\n  font-weight: 600 !important;\n}\n\n.bold.display-xl {\n  font-weight: 700 !important;\n}\n\n.bold.display-md {\n  font-weight: 700 !important;\n}\n\n.bold.h1 {\n  font-weight: 700 !important;\n}\n\n.bold.h2 {\n  font-weight: 700 !important;\n}\n\n.bold.h3 {\n  font-weight: 700 !important;\n}\n\n.bold.h4 {\n  font-weight: 700 !important;\n}\n\n.bold.h5 {\n  font-weight: 700 !important;\n}\n\n.bold.h6 {\n  font-weight: 700 !important;\n}\n\n.bold.body-l {\n  font-weight: 700 !important;\n}\n\n.bold.body-n {\n  font-weight: 700 !important;\n}\n\n.bold.body-sm {\n  font-weight: 700 !important;\n}\n\n.bold.body-xs {\n  font-weight: 700 !important;\n}\n\n@font-face {\n  font-family: \"Allianz Neo\";\n  font-style: normal;\n  font-weight: 300;\n  font-display: swap;\n  src: url('AllianzNeoW04-Light.woff2') format(\"woff2\"), url('AllianzNeoW04-Light.woff') format(\"woff\");\n}\n\n@font-face {\n  font-family: \"Allianz Neo\";\n  font-style: italic;\n  font-weight: 300;\n  font-display: swap;\n  src: url('AllianzNeoW04-LightItalic.woff2') format(\"woff2\"), url('AllianzNeoW04-LightItalic.woff') format(\"woff\");\n}\n\n@font-face {\n  font-family: \"Allianz Neo\";\n  font-style: normal;\n  font-weight: 400;\n  font-display: swap;\n  src: url('AllianzNeoW04-Regular.woff2') format(\"woff2\"), url('AllianzNeoW04-Regular.woff') format(\"woff\");\n}\n\n@font-face {\n  font-family: \"Allianz Neo\";\n  font-style: italic;\n  font-weight: 400;\n  font-display: swap;\n  src: url('AllianzNeoW04-Italic.woff2') format(\"woff2\"), url('AllianzNeoW04-Italic.woff') format(\"woff\");\n}\n\n@font-face {\n  font-family: \"Allianz Neo\";\n  font-style: normal;\n  font-weight: 600;\n  font-display: swap;\n  src: url('AllianzNeoW04-SemiBold.woff2') format(\"woff2\"), url('AllianzNeoW04-SemiBold.woff') format(\"woff\");\n}\n\n@font-face {\n  font-family: \"Allianz Neo\";\n  font-style: italic;\n  font-weight: 600;\n  font-display: swap;\n  src: url('AllianzNeoW04-SemiBoldIt.woff2') format(\"woff2\"), url('AllianzNeoW04-SemiBoldIt.woff') format(\"woff\");\n}\n\n@font-face {\n  font-family: \"Allianz Neo\";\n  font-style: normal;\n  font-weight: 700;\n  font-display: swap;\n  src: url('AllianzNeoW04-Bold.woff2') format(\"woff2\"), url('AllianzNeoW04-Bold.woff') format(\"woff\");\n}\n\n@font-face {\n  font-family: \"Allianz Neo\";\n  font-style: italic;\n  font-weight: 700;\n  font-display: swap;\n  src: url('AllianzNeoW04-BoldItalic.woff2') format(\"woff2\"), url('AllianzNeoW04-BoldItalic.woff') format(\"woff\");\n}\n\n* {\n  color: var(--nc-color-nextgen-neutral-grey);\n  font-family: \"Allianz Neo\", sans-serif;\n  font-weight: 400;\n  font-size: 16px;\n}\n\nhtml {\n  --ion-safe-area-top: 0px;\n}\n\n.col-1 {\n  width: 8.33%;\n}\n\n.col-2 {\n  width: 16.66%;\n}\n\n.col-3 {\n  width: 25%;\n}\n\n.col-4 {\n  width: 33.33%;\n}\n\n.col-5 {\n  width: 41.66%;\n}\n\n.col-6 {\n  width: 50%;\n}\n\n.col-7 {\n  width: 58.33%;\n}\n\n.col-8 {\n  width: 66.66%;\n}\n\n.col-9 {\n  width: 75%;\n}\n\n.col-10 {\n  width: 83.33%;\n}\n\n.col-11 {\n  width: 91.66%;\n}\n\n.col-12 {\n  width: 100%;\n}\n\n@media only screen and (max-width: 576px) {\n  /* For tablets: */\n  .col-sm-1 {\n    width: 8.33%;\n  }\n\n  .col-sm-2 {\n    width: 16.66%;\n  }\n\n  .col-sm-3 {\n    width: 25%;\n  }\n\n  .col-sm-4 {\n    width: 33.33%;\n  }\n\n  .col-sm-5 {\n    width: 41.66%;\n  }\n\n  .col-sm-6 {\n    width: 50%;\n  }\n\n  .col-sm-7 {\n    width: 58.33%;\n  }\n\n  .col-sm-8 {\n    width: 66.66%;\n  }\n\n  .col-sm-9 {\n    width: 75%;\n  }\n\n  .col-sm-10 {\n    width: 83.33%;\n  }\n\n  .col-sm-11 {\n    width: 91.66%;\n  }\n\n  .col-sm-12 {\n    width: 100%;\n  }\n}\n\n@media only screen and (max-width: 768px) and (min-width: 577px) {\n  /* For tablets: */\n  .col-md-1 {\n    width: 8.33%;\n  }\n\n  .col-md-2 {\n    width: 16.66%;\n  }\n\n  .col-md-3 {\n    width: 25%;\n  }\n\n  .col-md-4 {\n    width: 33.33%;\n  }\n\n  .col-md-5 {\n    width: 41.66%;\n  }\n\n  .col-md-6 {\n    width: 50%;\n  }\n\n  .col-md-7 {\n    width: 58.33%;\n  }\n\n  .col-md-8 {\n    width: 66.66%;\n  }\n\n  .col-md-9 {\n    width: 75%;\n  }\n\n  .col-md-10 {\n    width: 83.33%;\n  }\n\n  .col-md-11 {\n    width: 91.66%;\n  }\n\n  .col-md-12 {\n    width: 100%;\n  }\n}\n\n@media only screen and (min-width: 769px) {\n  /* For tablets: */\n  .col-lg-1 {\n    width: 8.33%;\n  }\n\n  .col-lg-2 {\n    width: 16.66%;\n  }\n\n  .col-lg-3 {\n    width: 25%;\n  }\n\n  .col-lg-4 {\n    width: 33.33%;\n  }\n\n  .col-lg-5 {\n    width: 41.66%;\n  }\n\n  .col-lg-6 {\n    width: 50%;\n  }\n\n  .col-lg-7 {\n    width: 58.33%;\n  }\n\n  .col-lg-8 {\n    width: 66.66%;\n  }\n\n  .col-lg-9 {\n    width: 75%;\n  }\n\n  .col-lg-10 {\n    width: 83.33%;\n  }\n\n  .col-lg-11 {\n    width: 91.66%;\n  }\n\n  .col-lg-12 {\n    width: 100%;\n  }\n}\n\n.row {\n  display: flex;\n  justify-content: center;\n  align-items: center;\n}\n\n.custom-toast {\n  --max-width: fit-content;\n}\n\n/*\n * 2. Custom CSS for compatibility with Edge\n * ----------------------------------------------------------------------------\n */\n\ninput::-ms-reveal,\ninput::-ms-clear {\n  display: none;\n}\n\n.swal2-popup {\n  margin-top: 20px;\n}\n\n/*\n * 3. Custom CSS for loading controller\n * ----------------------------------------------------------------------------\n */\n\n.transparent-loading-class {\n  --background: transparent;\n  --spinner-color: #47e6b1;\n}\n\n.loading-wrapper.sc-ion-loading-md {\n  box-shadow: unset;\n  -webkit-box-shadow: unset;\n}\n\n.uil {\n  color: var(--nc-color-nextgen-grey);\n}\n\n.btn {\n  height: 48px;\n  border-radius: 28px;\n  padding: 0px 41px 0px 41px;\n  box-shadow: none;\n}\n\n.btn.btn-circle {\n  background-color: var(--nc-color-nextgen-stone-grey) !important;\n  color: var(--nc-color-nextgen-black);\n  padding: unset !important;\n  height: 36px !important;\n  width: 36px !important;\n  border-radius: 50% !important;\n}\n\n.btn.btn-circle i {\n  color: var(--nc-color-nextgen-black);\n}\n\n.btn.primary {\n  background: var(--nc-color-nextgen-green);\n  color: var(--nc-color-nextgen-white);\n}\n\n.btn.primary .uil {\n  color: var(--nc-color-nextgen-white);\n}\n\n.btn.primary:disabled {\n  background-color: var(--nc-color-nextgen-grey-background) !important;\n  color: var(--nc-color-nextgen-grey) !important;\n}\n\n.btn.secondary {\n  background: var(--nc-color-nextgen-white) !important;\n  border-color: var(--nc-color-nextgen-green);\n  border: solid 1px;\n  color: var(--nc-color-nextgen-green);\n}\n\n.btn.secondary .uil {\n  color: var(--nc-color-nextgen-green);\n}\n\n.btn.secondary:disabled {\n  background-color: var(--nc-color-nextgen-white) !important;\n  color: var(--nc-color-nextgen-grey) !important;\n  border-color: var(--nc-color-nextgen-grey-background) !important;\n}\n\n.btn.transparent {\n  background: transparent !important;\n  border-color: var(--nc-color-nextgen-green);\n  border: solid 1px;\n  color: var(--nc-color-nextgen-green);\n}\n\n.btn.transparent .uil {\n  color: var(--nc-color-nextgen-green);\n}\n\n.btn.transparent:disabled {\n  background-color: transparent !important;\n  color: var(--nc-color-nextgen-grey) !important;\n  border-color: var(--nc-color-nextgen-grey-background) !important;\n}\n\n.btn.btn-large {\n  height: 56px !important;\n  width: 100%;\n}\n\n.btn.bold {\n  font-weight: 700 !important;\n}\n\n.btn.semibold {\n  font-weight: 600 !important;\n}\n\n.btn-no-space {\n  padding: 5px !important;\n  height: -moz-fit-content;\n  height: fit-content;\n}\n\n.btn-back {\n  width: 31px;\n  height: 28px;\n  background-color: transparent;\n  padding: 0;\n  color: var(--nc-color-nextgen-green);\n}\n\n.container {\n  padding: 2rem;\n  height: 100%;\n}\n\n.body-section {\n  width: 100%;\n  height: 95%;\n  overflow-y: auto;\n  position: relative;\n}\n\n.top-section {\n  width: 100%;\n  height: 10%;\n  justify-content: space-between;\n  display: flex;\n  align-items: center;\n}\n\n.form-control {\n  position: relative;\n  height: 85px;\n  margin-bottom: 8px;\n}\n\n.control {\n  border-radius: 8px;\n  height: 56px;\n  border: 1px solid var(--nc-color-nextgen-grey-background);\n  width: 100%;\n  position: absolute;\n  top: 32px;\n  background-color: var(--nc-color-nextgen-white);\n}\n\n.control table {\n  table-layout: fixed;\n  border-collapse: unset;\n}\n\n.control input {\n  height: 54px;\n  border: unset;\n  border-radius: 8px;\n  width: max-content;\n  width: 100%;\n  pointer-events: auto;\n  background-color: var(--nc-color-nextgen-white);\n}\n\n.control.textarea {\n  height: 108px;\n}\n\n.control textarea {\n  height: 106px;\n  border: unset;\n  border-radius: 8px;\n  width: max-content;\n  width: 100%;\n  pointer-events: auto;\n  resize: none;\n  background-color: var(--nc-color-nextgen-white);\n}\n\n.control input:focus {\n  outline: none;\n}\n\n.control:focus-within {\n  border-color: var(--nc-color-nextgen-green);\n}\n\n.control:focus-within .first-icon {\n  display: none;\n}\n\n.control:focus-within .first-icon.non-hidden {\n  display: table-cell;\n}\n\n.control .first-icon {\n  width: 32px;\n  text-align: center;\n  padding-left: 8px;\n}\n\n.control .first-icon i {\n  font-size: 24px !important;\n}\n\n.control .second-icon {\n  width: 32px;\n  text-align: center;\n}\n\n.control .second-icon i {\n  font-size: 24px !important;\n}\n\n.control:focus-within ~ div .control-label {\n  color: var(--nc-color-nextgen-green);\n}\n\n.control-error .control {\n  border-color: var(--nc-color-nextgen-error);\n}\n\n.control-error .control-label {\n  color: var(--nc-color-nextgen-error) !important;\n}\n\n.validation-summary li {\n  color: var(--nc-color-nextgen-error) !important;\n  list-style: none;\n}\n\n.validation-summary li i {\n  color: var(--nc-color-nextgen-error) !important;\n}\n\n.mr-1 {\n  margin-right: 0.5rem;\n}\n\n.mb-1 {\n  margin-bottom: 0.5rem;\n}\n\n.dialog-pane {\n  position: absolute;\n  pointer-events: auto;\n  box-sizing: border-box;\n  z-index: 1000;\n  display: block;\n  max-width: 100%;\n  max-height: 100%;\n}\n\n.overlay-backdrop {\n  background-color: var(--nc-color-nextgen-neutral-grey);\n  opacity: 0.2 !important;\n}\n\n.dialog-container {\n  animation: fadeIn 0.5s linear;\n  background-color: var(--nc-color-nextgen-white);\n}\n\n@keyframes fadeIn {\n  from {\n    transform: translateY(100%);\n  }\n  to {\n    transform: translateY(0%);\n  }\n}\n\n.error {\n  color: var(--nc-color-nextgen-error);\n}\n\n.error.background {\n  background-color: var(--nc-color-nextgen-error);\n}\n\n.success {\n  color: var(--nc-color-nextgen-fibrant-green);\n}\n\n.success.background {\n  background-color: var(--nc-color-nextgen-fibrant-green);\n}\n\n.warning {\n  color: var(--nc-color-nextgen-warning);\n}\n\n.warning.background {\n  background-color: var(--nc-color-nextgen-warning);\n}\n\n.select {\n  width: 100%;\n  height: 54px;\n  border: unset;\n  border-radius: 8px;\n  display: grid;\n  -webkit-appearance: none;\n          appearance: none;\n  grid-template-areas: \"select\";\n}\n\n.select:focus {\n  outline: unset;\n}\n\n.color-black {\n  color: var(--nc-color-nextgen-black);\n}\n\n.modal-default {\n  --width: 100%;\n  --height: 100%;\n}\n\n.integration-panel {\n  width: 100%;\n  height: 100%;\n  max-width: 100% !important;\n}\n\n.verloop-button {\n  visibility: hidden;\n}\n\n.back-area {\n  position: fixed;\n  top: 0;\n  right: 0;\n  height: 50px;\n  width: 100%;\n  background-color: var(--nc-color-nextgen-neutral-grey-50);\n  z-index: 9999999;\n}\n\n.back-area.ios {\n  height: 80px;\n}\n\n.title-widget {\n  text-align: center;\n  position: sticky;\n  top: 48px;\n}\n\n.button-back {\n  background-color: #fafafa;\n  height: 36px;\n  width: 36px;\n  border-radius: 50%;\n  position: absolute;\n  left: 18px;\n  bottom: 4px;\n}\n\n.icon-close-widget {\n  position: absolute;\n  z-index: 250;\n  left: 11px;\n  bottom: 13px;\n}\n\n.data-default {\n  position: absolute;\n  top: 50%;\n  left: 50%;\n  transform: translate(-50%, -50%);\n  text-align: center;\n  color: var(--nc-color-nextgen-neutral-grey-400);\n  z-index: 1000;\n}\n\n.avaamo__icon {\n  visibility: hidden !important;\n}\n\n.avaamo__chat__widget.ios #avaamo__popup {\n  padding-top: 40px;\n}\n\n.d-flex {\n  display: flex;\n}\n\nnextcare-layout {\n  left: 0;\n  right: 0;\n  top: 0;\n  bottom: 0;\n  display: flex;\n  position: absolute;\n  flex-direction: column;\n  justify-content: space-between;\n  contain: layout size style;\n  overflow: hidden;\n  background-color: var(--nc-color-nextgen-neutral-grey-50);\n  padding-right: 24px;\n  padding-left: 24px;\n}\n\nion-header.ios.header-ios {\n  margin-top: 40px;\n}\n\n.header-ios ion-toolbar:last-of-type {\n  --border-width: 0px !important;\n}\n\n.header-md.md::after {\n  display: none;\n}\n\nion-toolbar {\n  padding-right: unset !important;\n  padding-left: unset !important;\n}\n\ni.icon-back {\n  content: url('long-arrow-left-icon.svg');\n}\n\n.verloop-widget.ios .verloop-container.visible {\n  height: calc(100% - 40px);\n  top: 40px;\n}\n\n#nextcare-ads {\n  display: none;\n  overflow: scroll;\n  height: 180px;\n}\n\n.d-block {\n  display: block;\n}\n\n.title-text {\n  color: var(--nc-color-nextgen-blue);\n}\n\n:host ion-datetime #shadow-root .datetime-calendar .calendar-header .calendar-action-buttons .calendar-month-year {\n  align-items: center;\n  justify-content: center;\n  display: flex;\n  width: 100%;\n}\n\n:host ion-datetime #shadow-root .datetime-calendar .calendar-header .calendar-action-buttons .calendar-month-year ion-icon {\n  display: none;\n}\n\n:host ion-datetime #shadow-root .datetime-calendar .calendar-header .calendar-action-buttons .calendar-next-prev {\n  position: absolute;\n  width: 100%;\n  right: 0;\n}\n\n:host ion-datetime #shadow-root .datetime-calendar .calendar-header .calendar-action-buttons .calendar-next-prev ion-buttons {\n  display: flex;\n  justify-content: space-between;\n  width: 100%;\n}\n\n.mat-dialog-container {\n  padding: unset !important;\n}\n\n/* Change autocomplete styles in WebKit */\n\ninput:-webkit-autofill,\ninput:-webkit-autofill:hover,\ninput:-webkit-autofill:focus,\ntextarea:-webkit-autofill,\ntextarea:-webkit-autofill:hover,\ntextarea:-webkit-autofill:focus,\nselect:-webkit-autofill,\nselect:-webkit-autofill:hover,\nselect:-webkit-autofill:focus {\n  -webkit-text-fill-color: black;\n  -webkit-box-shadow: 0 0 0px 1000px white inset;\n  -webkit-transition: background-color 5000s ease-in-out 0s;\n  transition: background-color 5000s ease-in-out 0s;\n}\n\n.force-update-popup + .cdk-global-overlay-wrapper .save-btn {\n  background: var(--lumi-primary-yellow-color) !important;\n  color: var(--lumi-white-color) !important;\n  font-weight: bold !important;\n}\n\n.force-update-popup + .cdk-global-overlay-wrapper .cancel-btn {\n  color: var(--lumi-primary-yellow-color) !important;\n}\n\n@keyframes slideInRight {\n  0% {\n    transform: translate3d(100%, 0, 0);\n    visibility: visible;\n  }\n  to {\n    transform: translateZ(0);\n  }\n}\n\n.animate__slideInRight {\n  animation-name: slideInRight;\n}\n\n.animate__animated {\n  animation-duration: 0.5s;\n  animation-duration: 0.5s;\n  animation-fill-mode: both;\n}\n\n.prescription-container {\n  background: var(--nc-color-nextgen-neutral-grey-50);\n  --width: 100%;\n  --height: 100%;\n  padding-bottom: 9vh;\n}\n\n.top-prescription {\n  width: 100%;\n  height: 10%;\n  justify-content: space-between;\n  display: flex;\n  align-items: center;\n}\n\n.title-text {\n  color: var(--nc-color-nextgen-blue) !important;\n}\n\n.icon-question {\n  font-size: 2rem !important;\n  color: var(--nc-color-nextgen-neutral-grey);\n}\n\n.segment {\n  width: 100%;\n  height: 3rem;\n  background: var(--nc-color-nextgen-grey-background);\n}\n\n.segment .segment-button {\n  --indicator-color: #00908d;\n  --color-checked: #ffffff;\n}\n\n.segment .segment-button.segment-button-checked ion-label {\n  color: #ffffff;\n  font-weight: 700 !important;\n}\n\n.claim-title {\n  margin: 5% 0;\n}\n\n.claim-title span {\n  color: var(--nc-color-nextgen-blue) !important;\n}\n\n.inputSearch {\n  margin: 2rem 0 2rem 0;\n}\n\nion-content {\n  --background: $color-nextgen-neutral-grey-50;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFxjb2xvci5zY3NzIiwiY2xhaW1zLXByZXNjcmlwdGlvbi5wYWdlLnNjc3MiLCIuLlxcLi5cXC4uXFwuLlxcc3R5bGUuc2NzcyIsIi4uXFwuLlxcLi5cXC4uXFxmb250LXNpemUuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNDLDJDQUFBO0VBQ0EsaUNBQUE7RUFDQSxnQ0FBQTtFQUNBLGlDQUFBO0VBQ0EsaUNBQUE7RUFDQSwyQ0FBQTtFQUNBLGdDQUFBO0VBQ0Esc0NBQUE7RUFDQSxpQ0FBQTtFQUNBLHdDQUFBO0VBQ0EseUNBQUE7RUFDQSxtQ0FBQTtFQUNBLDRDQUFBO0VBQ0EsNENBQUE7RUFDQSw0Q0FBQTtFQUNBLHdDQUFBO0VBQ0EsbURBQUE7RUFDQSwwQ0FBQTtFQUNBLHFEQUFBO0VBQ0Esb0NBQUE7RUFDQSx5Q0FBQTtFQUNBLG9DQUFBO0VBQ0Esb0NBQUE7RUFDQSxtQ0FBQTtFQUNBLDhDQUFBO0VBRUEsMkJBQUE7RUFDQSxvQ0FBQTtBQ0FEOztBRGdDQTtFQUNDLCtDQUFBO0VBQ0EsbURBQUE7RUFDQSxtREFBQTtFQUNBLHVEQUFBO0VBQ0EsZ0RBQUE7RUFDQSwrQ0FBQTtBQzdCRDs7QUNyQ0E7OztFQUFBOztBRkFBO0VBQ0MsMkNBQUE7RUFDQSxpQ0FBQTtFQUNBLGdDQUFBO0VBQ0EsaUNBQUE7RUFDQSxpQ0FBQTtFQUNBLDJDQUFBO0VBQ0EsZ0NBQUE7RUFDQSxzQ0FBQTtFQUNBLGlDQUFBO0VBQ0Esd0NBQUE7RUFDQSx5Q0FBQTtFQUNBLG1DQUFBO0VBQ0EsNENBQUE7RUFDQSw0Q0FBQTtFQUNBLDRDQUFBO0VBQ0Esd0NBQUE7RUFDQSxtREFBQTtFQUNBLDBDQUFBO0VBQ0EscURBQUE7RUFDQSxvQ0FBQTtFQUNBLHlDQUFBO0VBQ0Esb0NBQUE7RUFDQSxvQ0FBQTtFQUNBLG1DQUFBO0VBQ0EsOENBQUE7RUFFQSwyQkFBQTtFQUNBLG9DQUFBO0FDMkNEOztBRFhBO0VBQ0MsK0NBQUE7RUFDQSxtREFBQTtFQUNBLG1EQUFBO0VBQ0EsdURBQUE7RUFDQSxnREFBQTtFQUNBLCtDQUFBO0FDY0Q7O0FFaEZBO0VBQ0ksMEJBQUE7RUFDQSwyQkFBQTtFQUNBLDRCQUFBO0FGbUZKOztBRWhGQTtFQUNJLDBCQUFBO0VBQ0EsMkJBQUE7RUFDQSw0QkFBQTtBRm1GSjs7QUVoRkE7RUFDSSwwQkFBQTtFQUNBLDJCQUFBO0VBQ0EsNEJBQUE7QUZtRko7O0FFaEZBO0VBQ0ksMEJBQUE7RUFDQSwyQkFBQTtFQUNBLDRCQUFBO0FGbUZKOztBRWhGQTtFQUNJLDBCQUFBO0VBQ0EsMkJBQUE7RUFDQSw0QkFBQTtBRm1GSjs7QUVoRkE7RUFDSSwwQkFBQTtFQUNBLDJCQUFBO0VBQ0EsNEJBQUE7QUZtRko7O0FFaEZBO0VBQ0ksMEJBQUE7RUFDQSwyQkFBQTtFQUNBLDRCQUFBO0FGbUZKOztBRWhGQTtFQUNJLDBCQUFBO0VBQ0EsMkJBQUE7RUFDQSw0QkFBQTtBRm1GSjs7QUVoRkE7RUFDSSwwQkFBQTtFQUNBLDJCQUFBO0VBQ0EsNEJBQUE7QUZtRko7O0FFaEZBO0VBQ0ksMEJBQUE7RUFDQSwyQkFBQTtFQUNBLDRCQUFBO0FGbUZKOztBRWhGQTtFQUNJLDBCQUFBO0VBQ0EsMkJBQUE7RUFDQSw0QkFBQTtBRm1GSjs7QUVoRkE7RUFDSSwwQkFBQTtFQUNBLDJCQUFBO0VBQ0EsNEJBQUE7QUZtRko7O0FFL0VJO0VBQ0ksMkJBQUE7QUZrRlI7O0FFaEZJO0VBQ0ksMkJBQUE7QUZrRlI7O0FFaEZJO0VBQ0ksMkJBQUE7QUZrRlI7O0FFaEZJO0VBQ0ksMkJBQUE7QUZrRlI7O0FFaEZJO0VBQ0ksMkJBQUE7QUZrRlI7O0FFaEZJO0VBQ0ksMkJBQUE7QUZrRlI7O0FFaEZJO0VBQ0ksMkJBQUE7QUZrRlI7O0FFaEZJO0VBQ0ksMkJBQUE7QUZrRlI7O0FFaEZJO0VBQ0ksMkJBQUE7QUZrRlI7O0FFaEZJO0VBQ0ksMkJBQUE7QUZrRlI7O0FFaEZJO0VBQ0ksMkJBQUE7QUZrRlI7O0FFaEZJO0VBQ0ksMkJBQUE7QUZrRlI7O0FFN0VJO0VBQ0ksMkJBQUE7QUZnRlI7O0FFOUVJO0VBQ0ksMkJBQUE7QUZnRlI7O0FFOUVJO0VBQ0ksMkJBQUE7QUZnRlI7O0FFOUVJO0VBQ0ksMkJBQUE7QUZnRlI7O0FFOUVJO0VBQ0ksMkJBQUE7QUZnRlI7O0FFOUVJO0VBQ0ksMkJBQUE7QUZnRlI7O0FFOUVJO0VBQ0ksMkJBQUE7QUZnRlI7O0FFOUVJO0VBQ0ksMkJBQUE7QUZnRlI7O0FFOUVJO0VBQ0ksMkJBQUE7QUZnRlI7O0FFOUVJO0VBQ0ksMkJBQUE7QUZnRlI7O0FFOUVJO0VBQ0ksMkJBQUE7QUZnRlI7O0FFOUVJO0VBQ0ksMkJBQUE7QUZnRlI7O0FDdk5BO0VBQ0MsMEJBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0Esa0JBQUE7RUFDQSxxR0FBQTtBRDBORDs7QUNwTkE7RUFDQywwQkFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrQkFBQTtFQUNBLGlIQUFBO0FEc05EOztBQ2hOQTtFQUNDLDBCQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtFQUNBLGtCQUFBO0VBQ0EseUdBQUE7QURrTkQ7O0FDNU1BO0VBQ0MsMEJBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0Esa0JBQUE7RUFDQSx1R0FBQTtBRDhNRDs7QUN4TUE7RUFDQywwQkFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrQkFBQTtFQUNBLDJHQUFBO0FEME1EOztBQ3BNQTtFQUNDLDBCQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtFQUNBLGtCQUFBO0VBQ0EsK0dBQUE7QURzTUQ7O0FDaE1BO0VBQ0MsMEJBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0Esa0JBQUE7RUFDQSxtR0FBQTtBRGtNRDs7QUM1TEE7RUFDQywwQkFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrQkFBQTtFQUNBLCtHQUFBO0FEOExEOztBQ3hMQTtFQUNDLDJDRjlENEI7RUUrRDVCLHNDQUFBO0VBQ0EsZ0JBQUE7RUFDQSxlQUFBO0FEMExEOztBQ3ZMQTtFQUNDLHdCQUFBO0FEMExEOztBQ3ZMQTtFQUNDLFlBQUE7QUQwTEQ7O0FDdkxBO0VBQ0MsYUFBQTtBRDBMRDs7QUN2TEE7RUFDQyxVQUFBO0FEMExEOztBQ3ZMQTtFQUNDLGFBQUE7QUQwTEQ7O0FDdkxBO0VBQ0MsYUFBQTtBRDBMRDs7QUN2TEE7RUFDQyxVQUFBO0FEMExEOztBQ3ZMQTtFQUNDLGFBQUE7QUQwTEQ7O0FDdkxBO0VBQ0MsYUFBQTtBRDBMRDs7QUN2TEE7RUFDQyxVQUFBO0FEMExEOztBQ3ZMQTtFQUNDLGFBQUE7QUQwTEQ7O0FDdkxBO0VBQ0MsYUFBQTtBRDBMRDs7QUN2TEE7RUFDQyxXQUFBO0FEMExEOztBQ3ZMQTtFQUNDLGlCQUFBO0VBQ0E7SUFDQyxZQUFBO0VEMExBOztFQ3ZMRDtJQUNDLGFBQUE7RUQwTEE7O0VDdkxEO0lBQ0MsVUFBQTtFRDBMQTs7RUN2TEQ7SUFDQyxhQUFBO0VEMExBOztFQ3ZMRDtJQUNDLGFBQUE7RUQwTEE7O0VDdkxEO0lBQ0MsVUFBQTtFRDBMQTs7RUN2TEQ7SUFDQyxhQUFBO0VEMExBOztFQ3ZMRDtJQUNDLGFBQUE7RUQwTEE7O0VDdkxEO0lBQ0MsVUFBQTtFRDBMQTs7RUN2TEQ7SUFDQyxhQUFBO0VEMExBOztFQ3ZMRDtJQUNDLGFBQUE7RUQwTEE7O0VDdkxEO0lBQ0MsV0FBQTtFRDBMQTtBQUNGOztBQ3ZMQTtFQUNDLGlCQUFBO0VBQ0E7SUFDQyxZQUFBO0VEeUxBOztFQ3RMRDtJQUNDLGFBQUE7RUR5TEE7O0VDdExEO0lBQ0MsVUFBQTtFRHlMQTs7RUN0TEQ7SUFDQyxhQUFBO0VEeUxBOztFQ3RMRDtJQUNDLGFBQUE7RUR5TEE7O0VDdExEO0lBQ0MsVUFBQTtFRHlMQTs7RUN0TEQ7SUFDQyxhQUFBO0VEeUxBOztFQ3RMRDtJQUNDLGFBQUE7RUR5TEE7O0VDdExEO0lBQ0MsVUFBQTtFRHlMQTs7RUN0TEQ7SUFDQyxhQUFBO0VEeUxBOztFQ3RMRDtJQUNDLGFBQUE7RUR5TEE7O0VDdExEO0lBQ0MsV0FBQTtFRHlMQTtBQUNGOztBQ3RMQTtFQUNDLGlCQUFBO0VBQ0E7SUFDQyxZQUFBO0VEd0xBOztFQ3JMRDtJQUNDLGFBQUE7RUR3TEE7O0VDckxEO0lBQ0MsVUFBQTtFRHdMQTs7RUNyTEQ7SUFDQyxhQUFBO0VEd0xBOztFQ3JMRDtJQUNDLGFBQUE7RUR3TEE7O0VDckxEO0lBQ0MsVUFBQTtFRHdMQTs7RUNyTEQ7SUFDQyxhQUFBO0VEd0xBOztFQ3JMRDtJQUNDLGFBQUE7RUR3TEE7O0VDckxEO0lBQ0MsVUFBQTtFRHdMQTs7RUNyTEQ7SUFDQyxhQUFBO0VEd0xBOztFQ3JMRDtJQUNDLGFBQUE7RUR3TEE7O0VDckxEO0lBQ0MsV0FBQTtFRHdMQTtBQUNGOztBQ3JMQTtFQUNDLGFBQUE7RUFDQSx1QkFBQTtFQUNBLG1CQUFBO0FEdUxEOztBQ25MQTtFQUNDLHdCQUFBO0FEc0xEOztBQ25MQTs7O0VBQUE7O0FBSUE7O0VBRUMsYUFBQTtBRHNMRDs7QUNuTEE7RUFDQyxnQkFBQTtBRHNMRDs7QUNuTEE7OztFQUFBOztBQUlBO0VBQ0MseUJBQUE7RUFDQSx3QkFBQTtBRHNMRDs7QUNuTEE7RUFDQyxpQkFBQTtFQUNBLHlCQUFBO0FEc0xEOztBQ25MQTtFQUNDLG1DRjNUb0I7QUNpZnJCOztBQ25MQTtFQUNDLFlBQUE7RUFDQSxtQkFBQTtFQUNBLDBCQUFBO0VBQ0EsZ0JBQUE7QURzTEQ7O0FDcExDO0VBQ0MsK0RBQUE7RUFDQSxvQ0Z4VW9CO0VFeVVwQix5QkFBQTtFQUNBLHVCQUFBO0VBQ0Esc0JBQUE7RUFDQSw2QkFBQTtBRHNMRjs7QUNwTEU7RUFDQyxvQ0YvVW1CO0FDcWdCdEI7O0FDbExDO0VBQ0MseUNGdFZvQjtFRXVWcEIsb0NGdFZvQjtBQzBnQnRCOztBQ2xMRTtFQUNDLG9DRnpWbUI7QUM2Z0J0Qjs7QUNqTEU7RUFDQyxvRUFBQTtFQUNBLDhDQUFBO0FEbUxIOztBQy9LQztFQUNDLG9EQUFBO0VBQ0EsMkNGcldvQjtFRXNXcEIsaUJBQUE7RUFDQSxvQ0Z2V29CO0FDd2hCdEI7O0FDL0tFO0VBQ0Msb0NGMVdtQjtBQzJoQnRCOztBQzlLRTtFQUNDLDBEQUFBO0VBQ0EsOENBQUE7RUFDQSxnRUFBQTtBRGdMSDs7QUM1S0M7RUFDQyxrQ0FBQTtFQUNBLDJDRnRYb0I7RUV1WHBCLGlCQUFBO0VBQ0Esb0NGeFhvQjtBQ3NpQnRCOztBQzVLRTtFQUNDLG9DRjNYbUI7QUN5aUJ0Qjs7QUMzS0U7RUFDQyx3Q0FBQTtFQUNBLDhDQUFBO0VBQ0EsZ0VBQUE7QUQ2S0g7O0FDektDO0VBQ0MsdUJBQUE7RUFDQSxXQUFBO0FEMktGOztBQ3hLQztFQUNDLDJCQUFBO0FEMEtGOztBQ3ZLQztFQUNDLDJCQUFBO0FEeUtGOztBQ3JLQTtFQUNDLHVCQUFBO0VBQ0Esd0JBQUE7RUFBQSxtQkFBQTtBRHdLRDs7QUNyS0E7RUFDQyxXQUFBO0VBQ0EsWUFBQTtFQUNBLDZCQUFBO0VBQ0EsVUFBQTtFQUNBLG9DRjdacUI7QUNxa0J0Qjs7QUNyS0E7RUFDQyxhQUFBO0VBQ0EsWUFBQTtBRHdLRDs7QUNyS0E7RUFDQyxXQUFBO0VBQ0EsV0FBQTtFQUNBLGdCQUFBO0VBQ0Esa0JBQUE7QUR3S0Q7O0FDcktBO0VBQ0MsV0FBQTtFQUNBLFdBQUE7RUFDQSw4QkFBQTtFQUNBLGFBQUE7RUFDQSxtQkFBQTtBRHdLRDs7QUNyS0E7RUFDQyxrQkFBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtBRHdLRDs7QUNyS0E7RUFDQyxrQkFBQTtFQUNBLFlBQUE7RUFDQSx5REFBQTtFQUNBLFdBQUE7RUFDQSxrQkFBQTtFQUNBLFNBQUE7RUFDQSwrQ0ZoY3FCO0FDd21CdEI7O0FDdEtDO0VBQ0MsbUJBQUE7RUFDQSxzQkFBQTtBRHdLRjs7QUNyS0M7RUFDQyxZQUFBO0VBQ0EsYUFBQTtFQUNBLGtCQUFBO0VBQ0Esa0JBQUE7RUFDQSxXQUFBO0VBQ0Esb0JBQUE7RUFDQSwrQ0Y5Y29CO0FDcW5CdEI7O0FDcEtDO0VBQ0MsYUFBQTtBRHNLRjs7QUNuS0M7RUFDQyxhQUFBO0VBQ0EsYUFBQTtFQUNBLGtCQUFBO0VBQ0Esa0JBQUE7RUFDQSxXQUFBO0VBQ0Esb0JBQUE7RUFDQSxZQUFBO0VBQ0EsK0NGN2RvQjtBQ2tvQnRCOztBQ2xLQztFQUNDLGFBQUE7QURvS0Y7O0FDaktDO0VBQ0MsMkNGdGVvQjtBQ3lvQnRCOztBQ2pLRTtFQUNDLGFBQUE7QURtS0g7O0FDaEtFO0VBQ0MsbUJBQUE7QURrS0g7O0FDOUpDO0VBQ0MsV0FBQTtFQUNBLGtCQUFBO0VBQ0EsaUJBQUE7QURnS0Y7O0FDOUpFO0VBQ0MsMEJBQUE7QURnS0g7O0FDNUpDO0VBQ0MsV0FBQTtFQUNBLGtCQUFBO0FEOEpGOztBQzNKRTtFQUNDLDBCQUFBO0FENkpIOztBQ3hKQTtFQUNDLG9DRnZnQnFCO0FDa3FCdEI7O0FDdkpDO0VBQ0MsMkNGdGdCb0I7QUNncUJ0Qjs7QUN2SkM7RUFDQywrQ0FBQTtBRHlKRjs7QUNwSkM7RUFDQywrQ0FBQTtFQUNBLGdCQUFBO0FEdUpGOztBQ3JKRTtFQUNDLCtDQUFBO0FEdUpIOztBQ2xKQTtFQUNDLG9CQUFBO0FEcUpEOztBQ2xKQTtFQUNDLHFCQUFBO0FEcUpEOztBQ2xKQTtFQUNDLGtCQUFBO0VBQ0Esb0JBQUE7RUFDQSxzQkFBQTtFQUNBLGFBQUE7RUFDQSxjQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0FEcUpEOztBQ2xKQTtFQUNDLHNERjNpQjRCO0VFNGlCNUIsdUJBQUE7QURxSkQ7O0FDbEpBO0VBQ0MsNkJBQUE7RUFDQSwrQ0Z2akJxQjtBQzRzQnRCOztBQ2xKQTtFQUNDO0lBQ0MsMkJBQUE7RURxSkE7RUNsSkQ7SUFDQyx5QkFBQTtFRG9KQTtBQUNGOztBQ2pKQTtFQUNDLG9DRmhrQnFCO0FDbXRCdEI7O0FDakpDO0VBQ0MsK0NGbmtCb0I7QUNzdEJ0Qjs7QUMvSUE7RUFDQyw0Q0Z0a0I2QjtBQ3d0QjlCOztBQ2hKQztFQUNDLHVERnprQjRCO0FDMnRCOUI7O0FDOUlBO0VBQ0Msc0NGN2tCdUI7QUM4dEJ4Qjs7QUMvSUM7RUFDQyxpREZobEJzQjtBQ2l1QnhCOztBQzdJQTtFQUNDLFdBQUE7RUFDQSxZQUFBO0VBQ0EsYUFBQTtFQUNBLGtCQUFBO0VBQ0EsYUFBQTtFQUNBLHdCQUFBO1VBQUEsZ0JBQUE7RUFDQSw2QkFBQTtBRGdKRDs7QUM5SUM7RUFDQyxjQUFBO0FEZ0pGOztBQzVJQTtFQUNDLG9DRjFtQnFCO0FDeXZCdEI7O0FDNUlBO0VBQ0MsYUFBQTtFQUNBLGNBQUE7QUQrSUQ7O0FDNUlBO0VBQ0MsV0FBQTtFQUNBLFlBQUE7RUFDQSwwQkFBQTtBRCtJRDs7QUM1SUE7RUFDQyxrQkFBQTtBRCtJRDs7QUM1SUE7RUFDQyxlQUFBO0VBQ0EsTUFBQTtFQUNBLFFBQUE7RUFDQSxZQUFBO0VBQ0EsV0FBQTtFQUNBLHlERnpuQitCO0VFMG5CL0IsZ0JBQUE7QUQrSUQ7O0FDN0lDO0VBQ0MsWUFBQTtBRCtJRjs7QUMzSUE7RUFDQyxrQkFBQTtFQUNBLGdCQUFBO0VBQ0EsU0FBQTtBRDhJRDs7QUMzSUE7RUFDQyx5QkFBQTtFQUNBLFlBQUE7RUFDQSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSxrQkFBQTtFQUNBLFVBQUE7RUFDQSxXQUFBO0FEOElEOztBQzNJQTtFQUNDLGtCQUFBO0VBQ0EsWUFBQTtFQUNBLFVBQUE7RUFDQSxZQUFBO0FEOElEOztBQzNJQTtFQUNDLGtCQUFBO0VBQ0EsUUFBQTtFQUNBLFNBQUE7RUFDQSxnQ0FBQTtFQUNBLGtCQUFBO0VBQ0EsK0NGN3BCZ0M7RUU4cEJoQyxhQUFBO0FEOElEOztBQzNJQTtFQUNDLDZCQUFBO0FEOElEOztBQzFJQztFQUNDLGlCQUFBO0FENklGOztBQ3pJQTtFQUNDLGFBQUE7QUQ0SUQ7O0FDeklBO0VBQ0MsT0FBQTtFQUNBLFFBQUE7RUFDQSxNQUFBO0VBQ0EsU0FBQTtFQUNBLGFBQUE7RUFDQSxrQkFBQTtFQUNBLHNCQUFBO0VBQ0EsOEJBQUE7RUFDQSwwQkFBQTtFQUNBLGdCQUFBO0VBQ0EseURGM3JCK0I7RUU0ckIvQixtQkFBQTtFQUNBLGtCQUFBO0FENElEOztBQ3pJQTtFQUNDLGdCQUFBO0FENElEOztBQ3pJQTtFQUNDLDhCQUFBO0FENElEOztBQ3pJQTtFQUNDLGFBQUE7QUQ0SUQ7O0FDeklBO0VBQ0MsK0JBQUE7RUFDQSw4QkFBQTtBRDRJRDs7QUN6SUE7RUFDQyx3Q0FBQTtBRDRJRDs7QUN4SUM7RUFDQyx5QkFBQTtFQUNBLFNBQUE7QUQySUY7O0FDdklBO0VBQ0MsYUFBQTtFQUNBLGdCQUFBO0VBQ0EsYUFBQTtBRDBJRDs7QUN2SUE7RUFDQyxjQUFBO0FEMElEOztBQ3ZJQTtFQUNDLG1DRm52Qm9CO0FDNjNCckI7O0FDbklJO0VBQ0MsbUJBQUE7RUFDQSx1QkFBQTtFQUNBLGFBQUE7RUFDQSxXQUFBO0FEc0lMOztBQ3BJSztFQUNDLGFBQUE7QURzSU47O0FDbElJO0VBQ0Msa0JBQUE7RUFDQSxXQUFBO0VBQ0EsUUFBQTtBRG9JTDs7QUNsSUs7RUFDQyxhQUFBO0VBQ0EsOEJBQUE7RUFDQSxXQUFBO0FEb0lOOztBQzVIQTtFQUNDLHlCQUFBO0FEK0hEOztBQzVIQSx5Q0FBQTs7QUFDQTs7Ozs7Ozs7O0VBU0MsOEJBQUE7RUFDQSw4Q0FBQTtFQUNBLHlEQUFBO0VBQUEsaURBQUE7QUQrSEQ7O0FDM0hDO0VBQ0MsdURBQUE7RUFDQSx5Q0FBQTtFQUNBLDRCQUFBO0FEOEhGOztBQzNIQztFQUNDLGtEQUFBO0FENkhGOztBQzVHQTtFQUNDO0lBRUMsa0NBQUE7SUFDQSxtQkFBQTtFRDBIQTtFQ3ZIRDtJQUVDLHdCQUFBO0VEeUhBO0FBQ0Y7O0FDdEhBO0VBRUMsNEJBQUE7QUR3SEQ7O0FDckhBO0VBRUMsd0JBQUE7RUFFQSx3QkFBQTtFQUVBLHlCQUFBO0FEd0hEOztBQTcrQkE7RUFDRSxtRER1QzhCO0VDdEM5QixhQUFBO0VBQ0EsY0FBQTtFQUNBLG1CQUFBO0FBZy9CRjs7QUE5K0JBO0VBQ0UsV0FBQTtFQUNBLFdBQUE7RUFDQSw4QkFBQTtFQUNBLGFBQUE7RUFDQSxtQkFBQTtBQWkvQkY7O0FBLytCQTtFQUNFLDhDQUFBO0FBay9CRjs7QUEvK0JBO0VBQ0UsMEJBQUE7RUFDQSwyQ0RpQjJCO0FDaStCN0I7O0FBLytCQTtFQUNFLFdBQUE7RUFDQSxZQUFBO0VBQ0EsbURETzhCO0FDMitCaEM7O0FBai9CRTtFQUNFLDBCQUFBO0VBQ0Esd0JBQUE7QUFtL0JKOztBQWovQk07RUFDRSxjQUFBO0VBQ0EsMkJBQUE7QUFtL0JSOztBQTcrQkE7RUFDRSxZQUFBO0FBZy9CRjs7QUEvK0JFO0VBQ0UsOENBQUE7QUFpL0JKOztBQTcrQkE7RUFDRSxxQkFBQTtBQWcvQkY7O0FBOStCQTtFQUNFLDRDQUFBO0FBaS9CRiIsImZpbGUiOiJjbGFpbXMtcHJlc2NyaXB0aW9uLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIjpyb290IHtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTUwOiAjZjFlZmVmO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi13aGl0ZTogI2ZmZmZmZjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZTogIzBkMTUyZTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW46ICMwMDkwOGQ7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWJsYWNrOiAjMDAwMDAwO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ncmV5LWJhY2tncm91bmQ6ICNjOGQzZGE7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWdyZXk6ICM5MmEyYWM7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0b25lLWdyZXk6ICNmYWZhZmE7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWVycm9yOiAjZmMxMDU1O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXk6ICM0MTQxNDE7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWZpYnJhbnQtZ3JlZW46ICMwMGJhYjY7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXdhcm5pbmc6ICNmZmQwNDg7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuLWJhY2tncm91bmQ6ICNlNmYyZjI7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS00MDA6ICM3YTdhN2E7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS0xMDA6ICNlZmYzZjU7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy1lcnJvcjogI2JhMGMzZjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yLWJhY2tncm91bmQ6ICNmZmVmZjQ7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy13YXJuaW5nOiAjY2JhMTI3O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtd2FybmluZy1iYWNrZ3JvdW5kOiAjZmZmOGU2O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlLTEwMDogI2RmZWZmMjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tZXJyb3ItcmVkLTcwMDogI2Y2MjQ1OTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZS01MDA6ICMwMDYxOTI7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWJsdWUtNDAwOiAjNzljZGVjO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1yZWQtNTAwOiAjZmY2NTkyO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zZWNvbmRhcnktYmx1ZS0zMDA6ICMxM2EwZDM7XHJcblxyXG5cdC0tbHVtaS13aGl0ZS1jb2xvcjogI2ZmZmZmZjtcclxuXHQtLWx1bWktcHJpbWFyeS15ZWxsb3ctY29sb3I6ICNmYWI2MDA7XHJcbn1cclxuJGNvbG9yLW5leHRnZW4tYmx1ZTogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlKTtcclxuJGNvbG9yLW5leHRnZW4tZ3JlZW46IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4pO1xyXG4kY29sb3ItbmV4dGdlbi13aGl0ZTogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi13aGl0ZSk7XHJcbiRjb2xvci1uZXh0Z2VuLWJsYWNrOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWJsYWNrKTtcclxuJGNvbG9yLW5leHRnZW4tZ3JleS1iYWNrZ3JvdW5kOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZXktYmFja2dyb3VuZCk7XHJcbiRjb2xvci1uZXh0Z2VuLWdyZXk6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JleSk7XHJcbiRjb2xvci1uZXh0Z2VuLXN0b25lLWdyZXk6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tc3RvbmUtZ3JleSk7XHJcbiRjb2xvci1uZXh0Z2VuLWVycm9yOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWVycm9yKTtcclxuJGNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5OiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleSk7XHJcbiRjb2xvci1uZXh0Z2VuLWZpYnJhbnQtZ3JlZW46IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZmlicmFudC1ncmVlbik7XHJcbiRjb2xvci1uZXh0Z2VuLXdhcm5pbmc6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4td2FybmluZyk7XHJcbiRjb2xvci1uZXh0Z2VuLWdyZWVuLWJhY2tncm91bmQ6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4tYmFja2dyb3VuZCk7XHJcbiRjb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS01MDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNTApO1xyXG4kY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNDAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS00MDApO1xyXG4kY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktMTAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS0xMDApO1xyXG4kY29sb3ItbmV4dGdlbi1zdGF0dXMtZXJyb3I6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yKTtcclxuJGNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yLWJhY2tncm91bmQ6IHZhcihcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yLWJhY2tncm91bmRcclxuKTtcclxuJGNvbG9yLW5leHRnZW4tc3RhdHVzLXdhcm5pbmc6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLXdhcm5pbmcpO1xyXG4kY29sb3ItbmV4dGdlbi1zdGF0dXMtd2FybmluZy1iYWNrZ3JvdW5kOiB2YXIoXHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy13YXJuaW5nLWJhY2tncm91bmRcclxuKTtcclxuJGNvbG9yLW5leHRnZW4tYmx1ZS0xMDA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZS0xMDApO1xyXG4kY29sb3ItbmV4dGdlbi1lcnJvci1yZWQtNzAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWVycm9yLXJlZC03MDApO1xyXG4kY29sb3ItbmV4dGdlbi1ibHVlLTUwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlLTUwMCk7XHJcbiRjb2xvci1uZXh0Z2VuLWJsdWUtNDAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWJsdWUtNDAwKTtcclxuJGNvbG9yLW5leHRnZW4tcmVkLTUwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1yZWQtNTAwKTtcclxuJGNvbG9yLW5leHRnZW4tc2Vjb25kYXJ5LWJsdWUtMzAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXNlY29uZGFyeS1ibHVlLTMwMCk7XHJcblxyXG4uaW9uLWNvbG9yLWdyZWVuIHtcclxuXHQtLWlvbi1jb2xvci1iYXNlOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuKTtcclxuXHQtLWlvbi1jb2xvci1iYXNlLXJnYjogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbik7XHJcblx0LS1pb24tY29sb3ItY29udHJhc3Q6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4td2hpdGUpO1xyXG5cdC0taW9uLWNvbG9yLWNvbnRyYXN0LXJnYjogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbik7XHJcblx0LS1pb24tY29sb3Itc2hhZGU6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4pO1xyXG5cdC0taW9uLWNvbG9yLXRpbnQ6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4pO1xyXG59XHJcbiIsIkBpbXBvcnQgJy4uLy4uLy4uLy4uL2NvbG9yLnNjc3MnO1xyXG5AaW1wb3J0ICcuLi8uLi8uLi8uLi9zdHlsZS5zY3NzJztcclxuLnByZXNjcmlwdGlvbi1jb250YWluZXIge1xyXG4gIGJhY2tncm91bmQ6ICRjb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS01MDtcclxuICAtLXdpZHRoOiAxMDAlO1xyXG4gIC0taGVpZ2h0OiAxMDAlO1xyXG4gIHBhZGRpbmctYm90dG9tOiA5dmg7XHJcbn1cclxuLnRvcC1wcmVzY3JpcHRpb24ge1xyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIGhlaWdodDogMTAlO1xyXG4gIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbn1cclxuLnRpdGxlLXRleHQge1xyXG4gIGNvbG9yOiAkY29sb3ItbmV4dGdlbi1ibHVlICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5pY29uLXF1ZXN0aW9uIHtcclxuICBmb250LXNpemU6IDJyZW0gIWltcG9ydGFudDtcclxuICBjb2xvcjogJGNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5O1xyXG59XHJcblxyXG4uc2VnbWVudCB7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgaGVpZ2h0OiAzcmVtO1xyXG4gIGJhY2tncm91bmQ6ICRjb2xvci1uZXh0Z2VuLWdyZXktYmFja2dyb3VuZDtcclxuICAuc2VnbWVudC1idXR0b24ge1xyXG4gICAgLS1pbmRpY2F0b3ItY29sb3I6ICMwMDkwOGQ7XHJcbiAgICAtLWNvbG9yLWNoZWNrZWQ6ICNmZmZmZmY7XHJcbiAgICAmLnNlZ21lbnQtYnV0dG9uLWNoZWNrZWQge1xyXG4gICAgICBpb24tbGFiZWwge1xyXG4gICAgICAgIGNvbG9yOiAjZmZmZmZmO1xyXG4gICAgICAgIGZvbnQtd2VpZ2h0OiA3MDAgIWltcG9ydGFudDtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH1cclxufVxyXG5cclxuLmNsYWltLXRpdGxlIHtcclxuICBtYXJnaW46IDUlIDA7XHJcbiAgc3BhbiB7XHJcbiAgICBjb2xvcjogJGNvbG9yLW5leHRnZW4tYmx1ZSAhaW1wb3J0YW50O1xyXG4gIH1cclxufVxyXG5cclxuLmlucHV0U2VhcmNoe1xyXG4gIG1hcmdpbjogMnJlbSAwIDJyZW0gMDtcclxufVxyXG5pb24tY29udGVudCB7XHJcbiAgLS1iYWNrZ3JvdW5kOiAkY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNTA7XHJcbn0iLCIvKlxyXG4gKiAxLiBDdXN0b20gQ1NTIFxyXG4gKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcbiAqL1xyXG5cclxuLy8gY29sb3IgdmFyaWFibGVcclxuQGltcG9ydCBcIi4vY29sb3Iuc2Nzc1wiO1xyXG4vLyB0eXBvZ3JhcGh5XHJcbkBpbXBvcnQgXCIuL2ZvbnQtc2l6ZS5zY3NzXCI7XHJcblxyXG4vLyBGb250c1xyXG5AZm9udC1mYWNlIHtcclxuXHRmb250LWZhbWlseTogXCJBbGxpYW56IE5lb1wiO1xyXG5cdGZvbnQtc3R5bGU6IG5vcm1hbDtcclxuXHRmb250LXdlaWdodDogMzAwO1xyXG5cdGZvbnQtZGlzcGxheTogc3dhcDtcclxuXHRzcmM6IHVybChcIi4vYXNzZXRzL2ZvbnRzL0FsbGlhbnpOZW8vQWxsaWFuel9OZW9fd2ViZm9udHMvd29mZjIvQWxsaWFuek5lb1cwNC1MaWdodC53b2ZmMlwiKVxyXG5cdFx0XHRmb3JtYXQoXCJ3b2ZmMlwiKSxcclxuXHRcdHVybChcIi4vYXNzZXRzL2ZvbnRzL0FsbGlhbnpOZW8vQWxsaWFuel9OZW9fd2ViZm9udHMvd29mZi9BbGxpYW56TmVvVzA0LUxpZ2h0LndvZmZcIilcclxuXHRcdFx0Zm9ybWF0KFwid29mZlwiKTtcclxufVxyXG5cclxuQGZvbnQtZmFjZSB7XHJcblx0Zm9udC1mYW1pbHk6IFwiQWxsaWFueiBOZW9cIjtcclxuXHRmb250LXN0eWxlOiBpdGFsaWM7XHJcblx0Zm9udC13ZWlnaHQ6IDMwMDtcclxuXHRmb250LWRpc3BsYXk6IHN3YXA7XHJcblx0c3JjOiB1cmwoXCIuL2Fzc2V0cy9mb250cy9BbGxpYW56TmVvL0FsbGlhbnpfTmVvX3dlYmZvbnRzL3dvZmYyL0FsbGlhbnpOZW9XMDQtTGlnaHRJdGFsaWMud29mZjJcIilcclxuXHRcdFx0Zm9ybWF0KFwid29mZjJcIiksXHJcblx0XHR1cmwoXCIuL2Fzc2V0cy9mb250cy9BbGxpYW56TmVvL0FsbGlhbnpfTmVvX3dlYmZvbnRzL3dvZmYvQWxsaWFuek5lb1cwNC1MaWdodEl0YWxpYy53b2ZmXCIpXHJcblx0XHRcdGZvcm1hdChcIndvZmZcIik7XHJcbn1cclxuXHJcbkBmb250LWZhY2Uge1xyXG5cdGZvbnQtZmFtaWx5OiBcIkFsbGlhbnogTmVvXCI7XHJcblx0Zm9udC1zdHlsZTogbm9ybWFsO1xyXG5cdGZvbnQtd2VpZ2h0OiA0MDA7XHJcblx0Zm9udC1kaXNwbGF5OiBzd2FwO1xyXG5cdHNyYzogdXJsKFwiLi9hc3NldHMvZm9udHMvQWxsaWFuek5lby9BbGxpYW56X05lb193ZWJmb250cy93b2ZmMi9BbGxpYW56TmVvVzA0LVJlZ3VsYXIud29mZjJcIilcclxuXHRcdFx0Zm9ybWF0KFwid29mZjJcIiksXHJcblx0XHR1cmwoXCIuL2Fzc2V0cy9mb250cy9BbGxpYW56TmVvL0FsbGlhbnpfTmVvX3dlYmZvbnRzL3dvZmYvQWxsaWFuek5lb1cwNC1SZWd1bGFyLndvZmZcIilcclxuXHRcdFx0Zm9ybWF0KFwid29mZlwiKTtcclxufVxyXG5cclxuQGZvbnQtZmFjZSB7XHJcblx0Zm9udC1mYW1pbHk6IFwiQWxsaWFueiBOZW9cIjtcclxuXHRmb250LXN0eWxlOiBpdGFsaWM7XHJcblx0Zm9udC13ZWlnaHQ6IDQwMDtcclxuXHRmb250LWRpc3BsYXk6IHN3YXA7XHJcblx0c3JjOiB1cmwoXCIuL2Fzc2V0cy9mb250cy9BbGxpYW56TmVvL0FsbGlhbnpfTmVvX3dlYmZvbnRzL3dvZmYyL0FsbGlhbnpOZW9XMDQtSXRhbGljLndvZmYyXCIpXHJcblx0XHRcdGZvcm1hdChcIndvZmYyXCIpLFxyXG5cdFx0dXJsKFwiLi9hc3NldHMvZm9udHMvQWxsaWFuek5lby9BbGxpYW56X05lb193ZWJmb250cy93b2ZmL0FsbGlhbnpOZW9XMDQtSXRhbGljLndvZmZcIilcclxuXHRcdFx0Zm9ybWF0KFwid29mZlwiKTtcclxufVxyXG5cclxuQGZvbnQtZmFjZSB7XHJcblx0Zm9udC1mYW1pbHk6IFwiQWxsaWFueiBOZW9cIjtcclxuXHRmb250LXN0eWxlOiBub3JtYWw7XHJcblx0Zm9udC13ZWlnaHQ6IDYwMDtcclxuXHRmb250LWRpc3BsYXk6IHN3YXA7XHJcblx0c3JjOiB1cmwoXCIuL2Fzc2V0cy9mb250cy9BbGxpYW56TmVvL0FsbGlhbnpfTmVvX3dlYmZvbnRzL3dvZmYyL0FsbGlhbnpOZW9XMDQtU2VtaUJvbGQud29mZjJcIilcclxuXHRcdFx0Zm9ybWF0KFwid29mZjJcIiksXHJcblx0XHR1cmwoXCIuL2Fzc2V0cy9mb250cy9BbGxpYW56TmVvL0FsbGlhbnpfTmVvX3dlYmZvbnRzL3dvZmYvQWxsaWFuek5lb1cwNC1TZW1pQm9sZC53b2ZmXCIpXHJcblx0XHRcdGZvcm1hdChcIndvZmZcIik7XHJcbn1cclxuXHJcbkBmb250LWZhY2Uge1xyXG5cdGZvbnQtZmFtaWx5OiBcIkFsbGlhbnogTmVvXCI7XHJcblx0Zm9udC1zdHlsZTogaXRhbGljO1xyXG5cdGZvbnQtd2VpZ2h0OiA2MDA7XHJcblx0Zm9udC1kaXNwbGF5OiBzd2FwO1xyXG5cdHNyYzogdXJsKFwiLi9hc3NldHMvZm9udHMvQWxsaWFuek5lby9BbGxpYW56X05lb193ZWJmb250cy93b2ZmMi9BbGxpYW56TmVvVzA0LVNlbWlCb2xkSXQud29mZjJcIilcclxuXHRcdFx0Zm9ybWF0KFwid29mZjJcIiksXHJcblx0XHR1cmwoXCIuL2Fzc2V0cy9mb250cy9BbGxpYW56TmVvL0FsbGlhbnpfTmVvX3dlYmZvbnRzL3dvZmYvQWxsaWFuek5lb1cwNC1TZW1pQm9sZEl0LndvZmZcIilcclxuXHRcdFx0Zm9ybWF0KFwid29mZlwiKTtcclxufVxyXG5cclxuQGZvbnQtZmFjZSB7XHJcblx0Zm9udC1mYW1pbHk6IFwiQWxsaWFueiBOZW9cIjtcclxuXHRmb250LXN0eWxlOiBub3JtYWw7XHJcblx0Zm9udC13ZWlnaHQ6IDcwMDtcclxuXHRmb250LWRpc3BsYXk6IHN3YXA7XHJcblx0c3JjOiB1cmwoXCIuL2Fzc2V0cy9mb250cy9BbGxpYW56TmVvL0FsbGlhbnpfTmVvX3dlYmZvbnRzL3dvZmYyL0FsbGlhbnpOZW9XMDQtQm9sZC53b2ZmMlwiKVxyXG5cdFx0XHRmb3JtYXQoXCJ3b2ZmMlwiKSxcclxuXHRcdHVybChcIi4vYXNzZXRzL2ZvbnRzL0FsbGlhbnpOZW8vQWxsaWFuel9OZW9fd2ViZm9udHMvd29mZi9BbGxpYW56TmVvVzA0LUJvbGQud29mZlwiKVxyXG5cdFx0XHRmb3JtYXQoXCJ3b2ZmXCIpO1xyXG59XHJcblxyXG5AZm9udC1mYWNlIHtcclxuXHRmb250LWZhbWlseTogXCJBbGxpYW56IE5lb1wiO1xyXG5cdGZvbnQtc3R5bGU6IGl0YWxpYztcclxuXHRmb250LXdlaWdodDogNzAwO1xyXG5cdGZvbnQtZGlzcGxheTogc3dhcDtcclxuXHRzcmM6IHVybChcIi4vYXNzZXRzL2ZvbnRzL0FsbGlhbnpOZW8vQWxsaWFuel9OZW9fd2ViZm9udHMvd29mZjIvQWxsaWFuek5lb1cwNC1Cb2xkSXRhbGljLndvZmYyXCIpXHJcblx0XHRcdGZvcm1hdChcIndvZmYyXCIpLFxyXG5cdFx0dXJsKFwiLi9hc3NldHMvZm9udHMvQWxsaWFuek5lby9BbGxpYW56X05lb193ZWJmb250cy93b2ZmL0FsbGlhbnpOZW9XMDQtQm9sZEl0YWxpYy53b2ZmXCIpXHJcblx0XHRcdGZvcm1hdChcIndvZmZcIik7XHJcbn1cclxuXHJcbioge1xyXG5cdGNvbG9yOiAkY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXk7XHJcblx0Zm9udC1mYW1pbHk6IFwiQWxsaWFueiBOZW9cIiwgc2Fucy1zZXJpZjtcclxuXHRmb250LXdlaWdodDogNDAwO1xyXG5cdGZvbnQtc2l6ZTogMTZweDtcclxufVxyXG5cclxuaHRtbCB7XHJcblx0LS1pb24tc2FmZS1hcmVhLXRvcDogMHB4O1xyXG59XHJcblxyXG4uY29sLTEge1xyXG5cdHdpZHRoOiA4LjMzJTtcclxufVxyXG5cclxuLmNvbC0yIHtcclxuXHR3aWR0aDogMTYuNjYlO1xyXG59XHJcblxyXG4uY29sLTMge1xyXG5cdHdpZHRoOiAyNSU7XHJcbn1cclxuXHJcbi5jb2wtNCB7XHJcblx0d2lkdGg6IDMzLjMzJTtcclxufVxyXG5cclxuLmNvbC01IHtcclxuXHR3aWR0aDogNDEuNjYlO1xyXG59XHJcblxyXG4uY29sLTYge1xyXG5cdHdpZHRoOiA1MCU7XHJcbn1cclxuXHJcbi5jb2wtNyB7XHJcblx0d2lkdGg6IDU4LjMzJTtcclxufVxyXG5cclxuLmNvbC04IHtcclxuXHR3aWR0aDogNjYuNjYlO1xyXG59XHJcblxyXG4uY29sLTkge1xyXG5cdHdpZHRoOiA3NSU7XHJcbn1cclxuXHJcbi5jb2wtMTAge1xyXG5cdHdpZHRoOiA4My4zMyU7XHJcbn1cclxuXHJcbi5jb2wtMTEge1xyXG5cdHdpZHRoOiA5MS42NiU7XHJcbn1cclxuXHJcbi5jb2wtMTIge1xyXG5cdHdpZHRoOiAxMDAlO1xyXG59XHJcblxyXG5AbWVkaWEgb25seSBzY3JlZW4gYW5kIChtYXgtd2lkdGg6IDU3NnB4KSB7XHJcblx0LyogRm9yIHRhYmxldHM6ICovXHJcblx0LmNvbC1zbS0xIHtcclxuXHRcdHdpZHRoOiA4LjMzJTtcclxuXHR9XHJcblxyXG5cdC5jb2wtc20tMiB7XHJcblx0XHR3aWR0aDogMTYuNjYlO1xyXG5cdH1cclxuXHJcblx0LmNvbC1zbS0zIHtcclxuXHRcdHdpZHRoOiAyNSU7XHJcblx0fVxyXG5cclxuXHQuY29sLXNtLTQge1xyXG5cdFx0d2lkdGg6IDMzLjMzJTtcclxuXHR9XHJcblxyXG5cdC5jb2wtc20tNSB7XHJcblx0XHR3aWR0aDogNDEuNjYlO1xyXG5cdH1cclxuXHJcblx0LmNvbC1zbS02IHtcclxuXHRcdHdpZHRoOiA1MCU7XHJcblx0fVxyXG5cclxuXHQuY29sLXNtLTcge1xyXG5cdFx0d2lkdGg6IDU4LjMzJTtcclxuXHR9XHJcblxyXG5cdC5jb2wtc20tOCB7XHJcblx0XHR3aWR0aDogNjYuNjYlO1xyXG5cdH1cclxuXHJcblx0LmNvbC1zbS05IHtcclxuXHRcdHdpZHRoOiA3NSU7XHJcblx0fVxyXG5cclxuXHQuY29sLXNtLTEwIHtcclxuXHRcdHdpZHRoOiA4My4zMyU7XHJcblx0fVxyXG5cclxuXHQuY29sLXNtLTExIHtcclxuXHRcdHdpZHRoOiA5MS42NiU7XHJcblx0fVxyXG5cclxuXHQuY29sLXNtLTEyIHtcclxuXHRcdHdpZHRoOiAxMDAlO1xyXG5cdH1cclxufVxyXG5cclxuQG1lZGlhIG9ubHkgc2NyZWVuIGFuZCAobWF4LXdpZHRoOiA3NjhweCkgYW5kIChtaW4td2lkdGg6IDU3N3B4KSB7XHJcblx0LyogRm9yIHRhYmxldHM6ICovXHJcblx0LmNvbC1tZC0xIHtcclxuXHRcdHdpZHRoOiA4LjMzJTtcclxuXHR9XHJcblxyXG5cdC5jb2wtbWQtMiB7XHJcblx0XHR3aWR0aDogMTYuNjYlO1xyXG5cdH1cclxuXHJcblx0LmNvbC1tZC0zIHtcclxuXHRcdHdpZHRoOiAyNSU7XHJcblx0fVxyXG5cclxuXHQuY29sLW1kLTQge1xyXG5cdFx0d2lkdGg6IDMzLjMzJTtcclxuXHR9XHJcblxyXG5cdC5jb2wtbWQtNSB7XHJcblx0XHR3aWR0aDogNDEuNjYlO1xyXG5cdH1cclxuXHJcblx0LmNvbC1tZC02IHtcclxuXHRcdHdpZHRoOiA1MCU7XHJcblx0fVxyXG5cclxuXHQuY29sLW1kLTcge1xyXG5cdFx0d2lkdGg6IDU4LjMzJTtcclxuXHR9XHJcblxyXG5cdC5jb2wtbWQtOCB7XHJcblx0XHR3aWR0aDogNjYuNjYlO1xyXG5cdH1cclxuXHJcblx0LmNvbC1tZC05IHtcclxuXHRcdHdpZHRoOiA3NSU7XHJcblx0fVxyXG5cclxuXHQuY29sLW1kLTEwIHtcclxuXHRcdHdpZHRoOiA4My4zMyU7XHJcblx0fVxyXG5cclxuXHQuY29sLW1kLTExIHtcclxuXHRcdHdpZHRoOiA5MS42NiU7XHJcblx0fVxyXG5cclxuXHQuY29sLW1kLTEyIHtcclxuXHRcdHdpZHRoOiAxMDAlO1xyXG5cdH1cclxufVxyXG5cclxuQG1lZGlhIG9ubHkgc2NyZWVuIGFuZCAobWluLXdpZHRoOiA3NjlweCkge1xyXG5cdC8qIEZvciB0YWJsZXRzOiAqL1xyXG5cdC5jb2wtbGctMSB7XHJcblx0XHR3aWR0aDogOC4zMyU7XHJcblx0fVxyXG5cclxuXHQuY29sLWxnLTIge1xyXG5cdFx0d2lkdGg6IDE2LjY2JTtcclxuXHR9XHJcblxyXG5cdC5jb2wtbGctMyB7XHJcblx0XHR3aWR0aDogMjUlO1xyXG5cdH1cclxuXHJcblx0LmNvbC1sZy00IHtcclxuXHRcdHdpZHRoOiAzMy4zMyU7XHJcblx0fVxyXG5cclxuXHQuY29sLWxnLTUge1xyXG5cdFx0d2lkdGg6IDQxLjY2JTtcclxuXHR9XHJcblxyXG5cdC5jb2wtbGctNiB7XHJcblx0XHR3aWR0aDogNTAlO1xyXG5cdH1cclxuXHJcblx0LmNvbC1sZy03IHtcclxuXHRcdHdpZHRoOiA1OC4zMyU7XHJcblx0fVxyXG5cclxuXHQuY29sLWxnLTgge1xyXG5cdFx0d2lkdGg6IDY2LjY2JTtcclxuXHR9XHJcblxyXG5cdC5jb2wtbGctOSB7XHJcblx0XHR3aWR0aDogNzUlO1xyXG5cdH1cclxuXHJcblx0LmNvbC1sZy0xMCB7XHJcblx0XHR3aWR0aDogODMuMzMlO1xyXG5cdH1cclxuXHJcblx0LmNvbC1sZy0xMSB7XHJcblx0XHR3aWR0aDogOTEuNjYlO1xyXG5cdH1cclxuXHJcblx0LmNvbC1sZy0xMiB7XHJcblx0XHR3aWR0aDogMTAwJTtcclxuXHR9XHJcbn1cclxuXHJcbi5yb3cge1xyXG5cdGRpc3BsYXk6IGZsZXg7XHJcblx0anVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcblx0YWxpZ24taXRlbXM6IGNlbnRlcjtcclxufVxyXG5cclxuLy8gQ1NTXHJcbi5jdXN0b20tdG9hc3Qge1xyXG5cdC0tbWF4LXdpZHRoOiBmaXQtY29udGVudDtcclxufVxyXG5cclxuLypcclxuICogMi4gQ3VzdG9tIENTUyBmb3IgY29tcGF0aWJpbGl0eSB3aXRoIEVkZ2VcclxuICogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG4gKi9cclxuaW5wdXQ6Oi1tcy1yZXZlYWwsXHJcbmlucHV0OjotbXMtY2xlYXIge1xyXG5cdGRpc3BsYXk6IG5vbmU7XHJcbn1cclxuXHJcbi5zd2FsMi1wb3B1cCB7XHJcblx0bWFyZ2luLXRvcDogMjBweDtcclxufVxyXG5cclxuLypcclxuICogMy4gQ3VzdG9tIENTUyBmb3IgbG9hZGluZyBjb250cm9sbGVyXHJcbiAqIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuICovXHJcbi50cmFuc3BhcmVudC1sb2FkaW5nLWNsYXNzIHtcclxuXHQtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xyXG5cdC0tc3Bpbm5lci1jb2xvcjogIzQ3ZTZiMTtcclxufVxyXG5cclxuLmxvYWRpbmctd3JhcHBlci5zYy1pb24tbG9hZGluZy1tZCB7XHJcblx0Ym94LXNoYWRvdzogdW5zZXQ7XHJcblx0LXdlYmtpdC1ib3gtc2hhZG93OiB1bnNldDtcclxufVxyXG5cclxuLnVpbCB7XHJcblx0Y29sb3I6ICRjb2xvci1uZXh0Z2VuLWdyZXk7XHJcbn1cclxuXHJcbi5idG4ge1xyXG5cdGhlaWdodDogNDhweDtcclxuXHRib3JkZXItcmFkaXVzOiAyOHB4O1xyXG5cdHBhZGRpbmc6IDBweCA0MXB4IDBweCA0MXB4O1xyXG5cdGJveC1zaGFkb3c6IG5vbmU7XHJcblxyXG5cdCYuYnRuLWNpcmNsZSB7XHJcblx0XHRiYWNrZ3JvdW5kLWNvbG9yOiAkY29sb3ItbmV4dGdlbi1zdG9uZS1ncmV5ICFpbXBvcnRhbnQ7XHJcblx0XHRjb2xvcjogJGNvbG9yLW5leHRnZW4tYmxhY2s7XHJcblx0XHRwYWRkaW5nOiB1bnNldCAhaW1wb3J0YW50O1xyXG5cdFx0aGVpZ2h0OiAzNnB4ICFpbXBvcnRhbnQ7XHJcblx0XHR3aWR0aDogMzZweCAhaW1wb3J0YW50O1xyXG5cdFx0Ym9yZGVyLXJhZGl1czogNTAlICFpbXBvcnRhbnQ7XHJcblxyXG5cdFx0aSB7XHJcblx0XHRcdGNvbG9yOiAkY29sb3ItbmV4dGdlbi1ibGFjaztcclxuXHRcdH1cclxuXHR9XHJcblxyXG5cdCYucHJpbWFyeSB7XHJcblx0XHRiYWNrZ3JvdW5kOiAkY29sb3ItbmV4dGdlbi1ncmVlbjtcclxuXHRcdGNvbG9yOiAkY29sb3ItbmV4dGdlbi13aGl0ZTtcclxuXHJcblx0XHQudWlsIHtcclxuXHRcdFx0Y29sb3I6ICRjb2xvci1uZXh0Z2VuLXdoaXRlO1xyXG5cdFx0fVxyXG5cclxuXHRcdCY6ZGlzYWJsZWQge1xyXG5cdFx0XHRiYWNrZ3JvdW5kLWNvbG9yOiAkY29sb3ItbmV4dGdlbi1ncmV5LWJhY2tncm91bmQgIWltcG9ydGFudDtcclxuXHRcdFx0Y29sb3I6ICRjb2xvci1uZXh0Z2VuLWdyZXkgIWltcG9ydGFudDtcclxuXHRcdH1cclxuXHR9XHJcblxyXG5cdCYuc2Vjb25kYXJ5IHtcclxuXHRcdGJhY2tncm91bmQ6ICRjb2xvci1uZXh0Z2VuLXdoaXRlICFpbXBvcnRhbnQ7XHJcblx0XHRib3JkZXItY29sb3I6ICRjb2xvci1uZXh0Z2VuLWdyZWVuO1xyXG5cdFx0Ym9yZGVyOiBzb2xpZCAxcHg7XHJcblx0XHRjb2xvcjogJGNvbG9yLW5leHRnZW4tZ3JlZW47XHJcblxyXG5cdFx0LnVpbCB7XHJcblx0XHRcdGNvbG9yOiAkY29sb3ItbmV4dGdlbi1ncmVlbjtcclxuXHRcdH1cclxuXHJcblx0XHQmOmRpc2FibGVkIHtcclxuXHRcdFx0YmFja2dyb3VuZC1jb2xvcjogJGNvbG9yLW5leHRnZW4td2hpdGUgIWltcG9ydGFudDtcclxuXHRcdFx0Y29sb3I6ICRjb2xvci1uZXh0Z2VuLWdyZXkgIWltcG9ydGFudDtcclxuXHRcdFx0Ym9yZGVyLWNvbG9yOiAkY29sb3ItbmV4dGdlbi1ncmV5LWJhY2tncm91bmQgIWltcG9ydGFudDtcclxuXHRcdH1cclxuXHR9XHJcblxyXG5cdCYudHJhbnNwYXJlbnQge1xyXG5cdFx0YmFja2dyb3VuZDogdHJhbnNwYXJlbnQgIWltcG9ydGFudDtcclxuXHRcdGJvcmRlci1jb2xvcjogJGNvbG9yLW5leHRnZW4tZ3JlZW47XHJcblx0XHRib3JkZXI6IHNvbGlkIDFweDtcclxuXHRcdGNvbG9yOiAkY29sb3ItbmV4dGdlbi1ncmVlbjtcclxuXHJcblx0XHQudWlsIHtcclxuXHRcdFx0Y29sb3I6ICRjb2xvci1uZXh0Z2VuLWdyZWVuO1xyXG5cdFx0fVxyXG5cclxuXHRcdCY6ZGlzYWJsZWQge1xyXG5cdFx0XHRiYWNrZ3JvdW5kLWNvbG9yOiB0cmFuc3BhcmVudCAhaW1wb3J0YW50O1xyXG5cdFx0XHRjb2xvcjogJGNvbG9yLW5leHRnZW4tZ3JleSAhaW1wb3J0YW50O1xyXG5cdFx0XHRib3JkZXItY29sb3I6ICRjb2xvci1uZXh0Z2VuLWdyZXktYmFja2dyb3VuZCAhaW1wb3J0YW50O1xyXG5cdFx0fVxyXG5cdH1cclxuXHJcblx0Ji5idG4tbGFyZ2Uge1xyXG5cdFx0aGVpZ2h0OiA1NnB4ICFpbXBvcnRhbnQ7XHJcblx0XHR3aWR0aDogMTAwJTtcclxuXHR9XHJcblxyXG5cdCYuYm9sZCB7XHJcblx0XHRmb250LXdlaWdodDogNzAwICFpbXBvcnRhbnQ7XHJcblx0fVxyXG5cclxuXHQmLnNlbWlib2xkIHtcclxuXHRcdGZvbnQtd2VpZ2h0OiA2MDAgIWltcG9ydGFudDtcclxuXHR9XHJcbn1cclxuXHJcbi5idG4tbm8tc3BhY2Uge1xyXG5cdHBhZGRpbmc6IDVweCAhaW1wb3J0YW50O1xyXG5cdGhlaWdodDogZml0LWNvbnRlbnQ7XHJcbn1cclxuXHJcbi5idG4tYmFjayB7XHJcblx0d2lkdGg6IDMxcHg7XHJcblx0aGVpZ2h0OiAyOHB4O1xyXG5cdGJhY2tncm91bmQtY29sb3I6IHRyYW5zcGFyZW50O1xyXG5cdHBhZGRpbmc6IDA7XHJcblx0Y29sb3I6ICRjb2xvci1uZXh0Z2VuLWdyZWVuO1xyXG59XHJcblxyXG4uY29udGFpbmVyIHtcclxuXHRwYWRkaW5nOiAycmVtO1xyXG5cdGhlaWdodDogMTAwJTtcclxufVxyXG5cclxuLmJvZHktc2VjdGlvbiB7XHJcblx0d2lkdGg6IDEwMCU7XHJcblx0aGVpZ2h0OiA5NSU7XHJcblx0b3ZlcmZsb3cteTogYXV0bztcclxuXHRwb3NpdGlvbjogcmVsYXRpdmU7XHJcbn1cclxuXHJcbi50b3Atc2VjdGlvbiB7XHJcblx0d2lkdGg6IDEwMCU7XHJcblx0aGVpZ2h0OiAxMCU7XHJcblx0anVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xyXG5cdGRpc3BsYXk6IGZsZXg7XHJcblx0YWxpZ24taXRlbXM6IGNlbnRlcjtcclxufVxyXG5cclxuLmZvcm0tY29udHJvbCB7XHJcblx0cG9zaXRpb246IHJlbGF0aXZlO1xyXG5cdGhlaWdodDogODVweDtcclxuXHRtYXJnaW4tYm90dG9tOiA4cHg7XHJcbn1cclxuXHJcbi5jb250cm9sIHtcclxuXHRib3JkZXItcmFkaXVzOiA4cHg7XHJcblx0aGVpZ2h0OiA1NnB4O1xyXG5cdGJvcmRlcjogMXB4IHNvbGlkICRjb2xvci1uZXh0Z2VuLWdyZXktYmFja2dyb3VuZDtcclxuXHR3aWR0aDogMTAwJTtcclxuXHRwb3NpdGlvbjogYWJzb2x1dGU7XHJcblx0dG9wOiAzMnB4O1xyXG5cdGJhY2tncm91bmQtY29sb3I6ICRjb2xvci1uZXh0Z2VuLXdoaXRlO1xyXG5cclxuXHQmIHRhYmxlIHtcclxuXHRcdHRhYmxlLWxheW91dDogZml4ZWQ7XHJcblx0XHRib3JkZXItY29sbGFwc2U6IHVuc2V0O1xyXG5cdH1cclxuXHJcblx0JiBpbnB1dCB7XHJcblx0XHRoZWlnaHQ6IDU0cHg7XHJcblx0XHRib3JkZXI6IHVuc2V0O1xyXG5cdFx0Ym9yZGVyLXJhZGl1czogOHB4O1xyXG5cdFx0d2lkdGg6IG1heC1jb250ZW50O1xyXG5cdFx0d2lkdGg6IDEwMCU7XHJcblx0XHRwb2ludGVyLWV2ZW50czogYXV0bztcclxuXHRcdGJhY2tncm91bmQtY29sb3I6ICRjb2xvci1uZXh0Z2VuLXdoaXRlO1xyXG5cdH1cclxuXHJcblx0Ji50ZXh0YXJlYSB7XHJcblx0XHRoZWlnaHQ6IDEwOHB4O1xyXG5cdH1cclxuXHJcblx0JiB0ZXh0YXJlYSB7XHJcblx0XHRoZWlnaHQ6IDEwNnB4O1xyXG5cdFx0Ym9yZGVyOiB1bnNldDtcclxuXHRcdGJvcmRlci1yYWRpdXM6IDhweDtcclxuXHRcdHdpZHRoOiBtYXgtY29udGVudDtcclxuXHRcdHdpZHRoOiAxMDAlO1xyXG5cdFx0cG9pbnRlci1ldmVudHM6IGF1dG87XHJcblx0XHRyZXNpemU6IG5vbmU7XHJcblx0XHRiYWNrZ3JvdW5kLWNvbG9yOiAkY29sb3ItbmV4dGdlbi13aGl0ZTtcclxuXHR9XHJcblxyXG5cdCYgaW5wdXQ6Zm9jdXMge1xyXG5cdFx0b3V0bGluZTogbm9uZTtcclxuXHR9XHJcblxyXG5cdCY6Zm9jdXMtd2l0aGluIHtcclxuXHRcdGJvcmRlci1jb2xvcjogJGNvbG9yLW5leHRnZW4tZ3JlZW47XHJcblxyXG5cdFx0LmZpcnN0LWljb24ge1xyXG5cdFx0XHRkaXNwbGF5OiBub25lO1xyXG5cdFx0fVxyXG5cclxuXHRcdC5maXJzdC1pY29uLm5vbi1oaWRkZW4ge1xyXG5cdFx0XHRkaXNwbGF5OiB0YWJsZS1jZWxsO1xyXG5cdFx0fVxyXG5cdH1cclxuXHJcblx0LmZpcnN0LWljb24ge1xyXG5cdFx0d2lkdGg6IDMycHg7XHJcblx0XHR0ZXh0LWFsaWduOiBjZW50ZXI7XHJcblx0XHRwYWRkaW5nLWxlZnQ6IDhweDtcclxuXHJcblx0XHRpIHtcclxuXHRcdFx0Zm9udC1zaXplOiAyNHB4ICFpbXBvcnRhbnQ7XHJcblx0XHR9XHJcblx0fVxyXG5cclxuXHQuc2Vjb25kLWljb24ge1xyXG5cdFx0d2lkdGg6IDMycHg7XHJcblx0XHR0ZXh0LWFsaWduOiBjZW50ZXI7XHJcblx0XHQvLyBwYWRkaW5nLXJpZ2h0OiA4cHg7XHJcblxyXG5cdFx0aSB7XHJcblx0XHRcdGZvbnQtc2l6ZTogMjRweCAhaW1wb3J0YW50O1xyXG5cdFx0fVxyXG5cdH1cclxufVxyXG5cclxuLmNvbnRyb2w6Zm9jdXMtd2l0aGluIH4gZGl2IC5jb250cm9sLWxhYmVsIHtcclxuXHRjb2xvcjogJGNvbG9yLW5leHRnZW4tZ3JlZW47XHJcbn1cclxuXHJcbi5jb250cm9sLWVycm9yIHtcclxuXHQuY29udHJvbCB7XHJcblx0XHRib3JkZXItY29sb3I6ICRjb2xvci1uZXh0Z2VuLWVycm9yO1xyXG5cdH1cclxuXHJcblx0LmNvbnRyb2wtbGFiZWwge1xyXG5cdFx0Y29sb3I6ICRjb2xvci1uZXh0Z2VuLWVycm9yICFpbXBvcnRhbnQ7XHJcblx0fVxyXG59XHJcblxyXG4udmFsaWRhdGlvbi1zdW1tYXJ5IHtcclxuXHRsaSB7XHJcblx0XHRjb2xvcjogJGNvbG9yLW5leHRnZW4tZXJyb3IgIWltcG9ydGFudDtcclxuXHRcdGxpc3Qtc3R5bGU6IG5vbmU7XHJcblxyXG5cdFx0aSB7XHJcblx0XHRcdGNvbG9yOiAkY29sb3ItbmV4dGdlbi1lcnJvciAhaW1wb3J0YW50O1xyXG5cdFx0fVxyXG5cdH1cclxufVxyXG5cclxuLm1yLTEge1xyXG5cdG1hcmdpbi1yaWdodDogMC41cmVtO1xyXG59XHJcblxyXG4ubWItMSB7XHJcblx0bWFyZ2luLWJvdHRvbTogMC41cmVtO1xyXG59XHJcblxyXG4uZGlhbG9nLXBhbmUge1xyXG5cdHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuXHRwb2ludGVyLWV2ZW50czogYXV0bztcclxuXHRib3gtc2l6aW5nOiBib3JkZXItYm94O1xyXG5cdHotaW5kZXg6IDEwMDA7XHJcblx0ZGlzcGxheTogYmxvY2s7XHJcblx0bWF4LXdpZHRoOiAxMDAlO1xyXG5cdG1heC1oZWlnaHQ6IDEwMCU7XHJcbn1cclxuXHJcbi5vdmVybGF5LWJhY2tkcm9wIHtcclxuXHRiYWNrZ3JvdW5kLWNvbG9yOiAkY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXk7XHJcblx0b3BhY2l0eTogMC4yICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5kaWFsb2ctY29udGFpbmVyIHtcclxuXHRhbmltYXRpb246IGZhZGVJbiAwLjVzIGxpbmVhcjtcclxuXHRiYWNrZ3JvdW5kLWNvbG9yOiAkY29sb3ItbmV4dGdlbi13aGl0ZTtcclxufVxyXG5cclxuQGtleWZyYW1lcyBmYWRlSW4ge1xyXG5cdGZyb20ge1xyXG5cdFx0dHJhbnNmb3JtOiB0cmFuc2xhdGVZKDEwMCUpO1xyXG5cdH1cclxuXHJcblx0dG8ge1xyXG5cdFx0dHJhbnNmb3JtOiB0cmFuc2xhdGVZKDAlKTtcclxuXHR9XHJcbn1cclxuXHJcbi5lcnJvciB7XHJcblx0Y29sb3I6ICRjb2xvci1uZXh0Z2VuLWVycm9yO1xyXG5cclxuXHQmLmJhY2tncm91bmQge1xyXG5cdFx0YmFja2dyb3VuZC1jb2xvcjogJGNvbG9yLW5leHRnZW4tZXJyb3I7XHJcblx0fVxyXG59XHJcblxyXG4uc3VjY2VzcyB7XHJcblx0Y29sb3I6ICRjb2xvci1uZXh0Z2VuLWZpYnJhbnQtZ3JlZW47XHJcblxyXG5cdCYuYmFja2dyb3VuZCB7XHJcblx0XHRiYWNrZ3JvdW5kLWNvbG9yOiAkY29sb3ItbmV4dGdlbi1maWJyYW50LWdyZWVuO1xyXG5cdH1cclxufVxyXG5cclxuLndhcm5pbmcge1xyXG5cdGNvbG9yOiAkY29sb3ItbmV4dGdlbi13YXJuaW5nO1xyXG5cclxuXHQmLmJhY2tncm91bmQge1xyXG5cdFx0YmFja2dyb3VuZC1jb2xvcjogJGNvbG9yLW5leHRnZW4td2FybmluZztcclxuXHR9XHJcbn1cclxuXHJcbi5zZWxlY3Qge1xyXG5cdHdpZHRoOiAxMDAlO1xyXG5cdGhlaWdodDogNTRweDtcclxuXHRib3JkZXI6IHVuc2V0O1xyXG5cdGJvcmRlci1yYWRpdXM6IDhweDtcclxuXHRkaXNwbGF5OiBncmlkO1xyXG5cdGFwcGVhcmFuY2U6IG5vbmU7XHJcblx0Z3JpZC10ZW1wbGF0ZS1hcmVhczogXCJzZWxlY3RcIjtcclxuXHJcblx0Jjpmb2N1cyB7XHJcblx0XHRvdXRsaW5lOiB1bnNldDtcclxuXHR9XHJcbn1cclxuXHJcbi5jb2xvci1ibGFjayB7XHJcblx0Y29sb3I6ICRjb2xvci1uZXh0Z2VuLWJsYWNrO1xyXG59XHJcblxyXG4ubW9kYWwtZGVmYXVsdCB7XHJcblx0LS13aWR0aDogMTAwJTtcclxuXHQtLWhlaWdodDogMTAwJTtcclxufVxyXG5cclxuLmludGVncmF0aW9uLXBhbmVsIHtcclxuXHR3aWR0aDogMTAwJTtcclxuXHRoZWlnaHQ6IDEwMCU7XHJcblx0bWF4LXdpZHRoOiAxMDAlICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi52ZXJsb29wLWJ1dHRvbiB7XHJcblx0dmlzaWJpbGl0eTogaGlkZGVuO1xyXG59XHJcblxyXG4uYmFjay1hcmVhIHtcclxuXHRwb3NpdGlvbjogZml4ZWQ7XHJcblx0dG9wOiAwO1xyXG5cdHJpZ2h0OiAwO1xyXG5cdGhlaWdodDogNTBweDtcclxuXHR3aWR0aDogMTAwJTtcclxuXHRiYWNrZ3JvdW5kLWNvbG9yOiAkY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNTA7XHJcblx0ei1pbmRleDogOTk5OTk5OTtcclxuXHJcblx0Ji5pb3Mge1xyXG5cdFx0aGVpZ2h0OiA4MHB4O1xyXG5cdH1cclxufVxyXG5cclxuLnRpdGxlLXdpZGdldCB7XHJcblx0dGV4dC1hbGlnbjogY2VudGVyO1xyXG5cdHBvc2l0aW9uOiBzdGlja3k7XHJcblx0dG9wOiA0OHB4O1xyXG59XHJcblxyXG4uYnV0dG9uLWJhY2sge1xyXG5cdGJhY2tncm91bmQtY29sb3I6ICNmYWZhZmE7XHJcblx0aGVpZ2h0OiAzNnB4O1xyXG5cdHdpZHRoOiAzNnB4O1xyXG5cdGJvcmRlci1yYWRpdXM6IDUwJTtcclxuXHRwb3NpdGlvbjogYWJzb2x1dGU7XHJcblx0bGVmdDogMThweDtcclxuXHRib3R0b206IDRweDtcclxufVxyXG5cclxuLmljb24tY2xvc2Utd2lkZ2V0IHtcclxuXHRwb3NpdGlvbjogYWJzb2x1dGU7XHJcblx0ei1pbmRleDogMjUwO1xyXG5cdGxlZnQ6IDExcHg7XHJcblx0Ym90dG9tOiAxM3B4O1xyXG59XHJcblxyXG4uZGF0YS1kZWZhdWx0IHtcclxuXHRwb3NpdGlvbjogYWJzb2x1dGU7XHJcblx0dG9wOiA1MCU7XHJcblx0bGVmdDogNTAlO1xyXG5cdHRyYW5zZm9ybTogdHJhbnNsYXRlKC01MCUsIC01MCUpO1xyXG5cdHRleHQtYWxpZ246IGNlbnRlcjtcclxuXHRjb2xvcjogJGNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTQwMDtcclxuXHR6LWluZGV4OiAxMDAwO1xyXG59XHJcblxyXG4uYXZhYW1vX19pY29uIHtcclxuXHR2aXNpYmlsaXR5OiBoaWRkZW4gIWltcG9ydGFudDtcclxufVxyXG5cclxuLmF2YWFtb19fY2hhdF9fd2lkZ2V0LmlvcyB7XHJcblx0I2F2YWFtb19fcG9wdXAge1xyXG5cdFx0cGFkZGluZy10b3A6IDQwcHg7XHJcblx0fVxyXG59XHJcblxyXG4uZC1mbGV4IHtcclxuXHRkaXNwbGF5OiBmbGV4O1xyXG59XHJcblxyXG5uZXh0Y2FyZS1sYXlvdXQge1xyXG5cdGxlZnQ6IDA7XHJcblx0cmlnaHQ6IDA7XHJcblx0dG9wOiAwO1xyXG5cdGJvdHRvbTogMDtcclxuXHRkaXNwbGF5OiBmbGV4O1xyXG5cdHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuXHRmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG5cdGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcclxuXHRjb250YWluOiBsYXlvdXQgc2l6ZSBzdHlsZTtcclxuXHRvdmVyZmxvdzogaGlkZGVuO1xyXG5cdGJhY2tncm91bmQtY29sb3I6ICRjb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS01MDtcclxuXHRwYWRkaW5nLXJpZ2h0OiAyNHB4O1xyXG5cdHBhZGRpbmctbGVmdDogMjRweDtcclxufVxyXG5cclxuaW9uLWhlYWRlci5pb3MuaGVhZGVyLWlvcyB7XHJcblx0bWFyZ2luLXRvcDogNDBweDtcclxufVxyXG5cclxuLmhlYWRlci1pb3MgaW9uLXRvb2xiYXI6bGFzdC1vZi10eXBlIHtcclxuXHQtLWJvcmRlci13aWR0aDogMHB4ICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5oZWFkZXItbWQubWQ6OmFmdGVyIHtcclxuXHRkaXNwbGF5OiBub25lO1xyXG59XHJcblxyXG5pb24tdG9vbGJhciB7XHJcblx0cGFkZGluZy1yaWdodDogdW5zZXQgIWltcG9ydGFudDtcclxuXHRwYWRkaW5nLWxlZnQ6IHVuc2V0ICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbmkuaWNvbi1iYWNrIHtcclxuXHRjb250ZW50OiB1cmwoYXNzZXRzL2ljb24vbG9uZy1hcnJvdy1sZWZ0LWljb24uc3ZnKTtcclxufVxyXG5cclxuLnZlcmxvb3Atd2lkZ2V0LmlvcyB7XHJcblx0LnZlcmxvb3AtY29udGFpbmVyLnZpc2libGUge1xyXG5cdFx0aGVpZ2h0OiBjYWxjKDEwMCUgLSA0MHB4KTtcclxuXHRcdHRvcDogNDBweDtcclxuXHR9XHJcbn1cclxuXHJcbiNuZXh0Y2FyZS1hZHMge1xyXG5cdGRpc3BsYXk6IG5vbmU7XHJcblx0b3ZlcmZsb3c6IHNjcm9sbDtcclxuXHRoZWlnaHQ6IDE4MHB4O1xyXG59XHJcblxyXG4uZC1ibG9jayB7XHJcblx0ZGlzcGxheTogYmxvY2s7XHJcbn1cclxuXHJcbi50aXRsZS10ZXh0IHtcclxuXHRjb2xvcjogJGNvbG9yLW5leHRnZW4tYmx1ZTtcclxufVxyXG5cclxuOmhvc3QgaW9uLWRhdGV0aW1lICNzaGFkb3ctcm9vdCB7XHJcblx0LmRhdGV0aW1lLWNhbGVuZGFyIHtcclxuXHRcdC5jYWxlbmRhci1oZWFkZXIge1xyXG5cdFx0XHQuY2FsZW5kYXItYWN0aW9uLWJ1dHRvbnMge1xyXG5cdFx0XHRcdC5jYWxlbmRhci1tb250aC15ZWFyIHtcclxuXHRcdFx0XHRcdGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcblx0XHRcdFx0XHRqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuXHRcdFx0XHRcdGRpc3BsYXk6IGZsZXg7XHJcblx0XHRcdFx0XHR3aWR0aDogMTAwJTtcclxuXHJcblx0XHRcdFx0XHRpb24taWNvbiB7XHJcblx0XHRcdFx0XHRcdGRpc3BsYXk6IG5vbmU7XHJcblx0XHRcdFx0XHR9XHJcblx0XHRcdFx0fVxyXG5cclxuXHRcdFx0XHQuY2FsZW5kYXItbmV4dC1wcmV2IHtcclxuXHRcdFx0XHRcdHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuXHRcdFx0XHRcdHdpZHRoOiAxMDAlO1xyXG5cdFx0XHRcdFx0cmlnaHQ6IDA7XHJcblxyXG5cdFx0XHRcdFx0aW9uLWJ1dHRvbnMge1xyXG5cdFx0XHRcdFx0XHRkaXNwbGF5OiBmbGV4O1xyXG5cdFx0XHRcdFx0XHRqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XHJcblx0XHRcdFx0XHRcdHdpZHRoOiAxMDAlO1xyXG5cdFx0XHRcdFx0fVxyXG5cdFx0XHRcdH1cclxuXHRcdFx0fVxyXG5cdFx0fVxyXG5cdH1cclxufVxyXG5cclxuLm1hdC1kaWFsb2ctY29udGFpbmVyIHtcclxuXHRwYWRkaW5nOiB1bnNldCAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4vKiBDaGFuZ2UgYXV0b2NvbXBsZXRlIHN0eWxlcyBpbiBXZWJLaXQgKi9cclxuaW5wdXQ6LXdlYmtpdC1hdXRvZmlsbCxcclxuaW5wdXQ6LXdlYmtpdC1hdXRvZmlsbDpob3ZlcixcclxuaW5wdXQ6LXdlYmtpdC1hdXRvZmlsbDpmb2N1cyxcclxudGV4dGFyZWE6LXdlYmtpdC1hdXRvZmlsbCxcclxudGV4dGFyZWE6LXdlYmtpdC1hdXRvZmlsbDpob3ZlcixcclxudGV4dGFyZWE6LXdlYmtpdC1hdXRvZmlsbDpmb2N1cyxcclxuc2VsZWN0Oi13ZWJraXQtYXV0b2ZpbGwsXHJcbnNlbGVjdDotd2Via2l0LWF1dG9maWxsOmhvdmVyLFxyXG5zZWxlY3Q6LXdlYmtpdC1hdXRvZmlsbDpmb2N1cyB7XHJcblx0LXdlYmtpdC10ZXh0LWZpbGwtY29sb3I6IGJsYWNrO1xyXG5cdC13ZWJraXQtYm94LXNoYWRvdzogMCAwIDBweCAxMDAwcHggd2hpdGUgaW5zZXQ7XHJcblx0dHJhbnNpdGlvbjogYmFja2dyb3VuZC1jb2xvciA1MDAwcyBlYXNlLWluLW91dCAwcztcclxufVxyXG5cclxuLmZvcmNlLXVwZGF0ZS1wb3B1cCArIC5jZGstZ2xvYmFsLW92ZXJsYXktd3JhcHBlciB7XHJcblx0LnNhdmUtYnRuIHtcclxuXHRcdGJhY2tncm91bmQ6IHZhcigtLWx1bWktcHJpbWFyeS15ZWxsb3ctY29sb3IpICFpbXBvcnRhbnQ7XHJcblx0XHRjb2xvcjogdmFyKC0tbHVtaS13aGl0ZS1jb2xvcikgIWltcG9ydGFudDtcclxuXHRcdGZvbnQtd2VpZ2h0OiBib2xkICFpbXBvcnRhbnQ7XHJcblx0fVxyXG5cclxuXHQuY2FuY2VsLWJ0biB7XHJcblx0XHRjb2xvcjogdmFyKC0tbHVtaS1wcmltYXJ5LXllbGxvdy1jb2xvcikgIWltcG9ydGFudDtcclxuXHR9XHJcbn1cclxuXHJcbkAtd2Via2l0LWtleWZyYW1lcyBzbGlkZUluUmlnaHQge1xyXG5cdDAlIHtcclxuXHRcdC13ZWJraXQtdHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgxMDAlLCAwLCAwKTtcclxuXHRcdHRyYW5zZm9ybTogdHJhbnNsYXRlM2QoMTAwJSwgMCwgMCk7XHJcblx0XHR2aXNpYmlsaXR5OiB2aXNpYmxlO1xyXG5cdH1cclxuXHJcblx0dG8ge1xyXG5cdFx0LXdlYmtpdC10cmFuc2Zvcm06IHRyYW5zbGF0ZVooMCk7XHJcblx0XHR0cmFuc2Zvcm06IHRyYW5zbGF0ZVooMCk7XHJcblx0fVxyXG59XHJcblxyXG5Aa2V5ZnJhbWVzIHNsaWRlSW5SaWdodCB7XHJcblx0MCUge1xyXG5cdFx0LXdlYmtpdC10cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKDEwMCUsIDAsIDApO1xyXG5cdFx0dHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgxMDAlLCAwLCAwKTtcclxuXHRcdHZpc2liaWxpdHk6IHZpc2libGU7XHJcblx0fVxyXG5cclxuXHR0byB7XHJcblx0XHQtd2Via2l0LXRyYW5zZm9ybTogdHJhbnNsYXRlWigwKTtcclxuXHRcdHRyYW5zZm9ybTogdHJhbnNsYXRlWigwKTtcclxuXHR9XHJcbn1cclxuXHJcbi5hbmltYXRlX19zbGlkZUluUmlnaHQge1xyXG5cdC13ZWJraXQtYW5pbWF0aW9uLW5hbWU6IHNsaWRlSW5SaWdodDtcclxuXHRhbmltYXRpb24tbmFtZTogc2xpZGVJblJpZ2h0O1xyXG59XHJcblxyXG4uYW5pbWF0ZV9fYW5pbWF0ZWQge1xyXG5cdC13ZWJraXQtYW5pbWF0aW9uLWR1cmF0aW9uOiAwLjVzO1xyXG5cdGFuaW1hdGlvbi1kdXJhdGlvbjogMC41cztcclxuXHQtd2Via2l0LWFuaW1hdGlvbi1kdXJhdGlvbjogMC41cztcclxuXHRhbmltYXRpb24tZHVyYXRpb246IDAuNXM7XHJcblx0LXdlYmtpdC1hbmltYXRpb24tZmlsbC1tb2RlOiBib3RoO1xyXG5cdGFuaW1hdGlvbi1maWxsLW1vZGU6IGJvdGg7XHJcbn1cclxuIiwiLmRpc3BsYXkteGwge1xyXG4gICAgZm9udC1zaXplOiA0MXB4ICFpbXBvcnRhbnQ7XHJcbiAgICBmb250LXdlaWdodDogNDAwICFpbXBvcnRhbnQ7XHJcbiAgICBsaW5lLWhlaWdodDogMTIwJSAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4uZGlzcGxheS1tZCB7XHJcbiAgICBmb250LXNpemU6IDM2cHggIWltcG9ydGFudDtcclxuICAgIGZvbnQtd2VpZ2h0OiA0MDAgIWltcG9ydGFudDtcclxuICAgIGxpbmUtaGVpZ2h0OiAxMjAlICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5oMSB7XHJcbiAgICBmb250LXNpemU6IDMxcHggIWltcG9ydGFudDtcclxuICAgIGZvbnQtd2VpZ2h0OiA0MDAgIWltcG9ydGFudDtcclxuICAgIGxpbmUtaGVpZ2h0OiAxMjAlICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5oMiB7XHJcbiAgICBmb250LXNpemU6IDI4cHggIWltcG9ydGFudDtcclxuICAgIGZvbnQtd2VpZ2h0OiA0MDAgIWltcG9ydGFudDtcclxuICAgIGxpbmUtaGVpZ2h0OiAxMjAlICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5oMyB7XHJcbiAgICBmb250LXNpemU6IDI1cHggIWltcG9ydGFudDtcclxuICAgIGZvbnQtd2VpZ2h0OiA0MDAgIWltcG9ydGFudDtcclxuICAgIGxpbmUtaGVpZ2h0OiAxMjAlICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5oNCB7XHJcbiAgICBmb250LXNpemU6IDIycHggIWltcG9ydGFudDtcclxuICAgIGZvbnQtd2VpZ2h0OiA0MDAgIWltcG9ydGFudDtcclxuICAgIGxpbmUtaGVpZ2h0OiAxMjAlICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5oNSB7XHJcbiAgICBmb250LXNpemU6IDE5cHggIWltcG9ydGFudDtcclxuICAgIGZvbnQtd2VpZ2h0OiA0MDAgIWltcG9ydGFudDtcclxuICAgIGxpbmUtaGVpZ2h0OiAxMjAlICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5oNiB7XHJcbiAgICBmb250LXNpemU6IDE3cHggIWltcG9ydGFudDtcclxuICAgIGZvbnQtd2VpZ2h0OiA0MDAgIWltcG9ydGFudDtcclxuICAgIGxpbmUtaGVpZ2h0OiAxMjAlICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5ib2R5LWwge1xyXG4gICAgZm9udC1zaXplOiAxN3B4ICFpbXBvcnRhbnQ7XHJcbiAgICBmb250LXdlaWdodDogNDAwICFpbXBvcnRhbnQ7XHJcbiAgICBsaW5lLWhlaWdodDogMTIwJSAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4uYm9keS1uIHtcclxuICAgIGZvbnQtc2l6ZTogMTVweCAhaW1wb3J0YW50O1xyXG4gICAgZm9udC13ZWlnaHQ6IDQwMCAhaW1wb3J0YW50O1xyXG4gICAgbGluZS1oZWlnaHQ6IDEyMCUgIWltcG9ydGFudDtcclxufVxyXG5cclxuLmJvZHktc20ge1xyXG4gICAgZm9udC1zaXplOiAxM3B4ICFpbXBvcnRhbnQ7XHJcbiAgICBmb250LXdlaWdodDogNDAwICFpbXBvcnRhbnQ7XHJcbiAgICBsaW5lLWhlaWdodDogMTIwJSAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4uYm9keS14cyB7XHJcbiAgICBmb250LXNpemU6IDEycHggIWltcG9ydGFudDtcclxuICAgIGZvbnQtd2VpZ2h0OiA0MDAgIWltcG9ydGFudDtcclxuICAgIGxpbmUtaGVpZ2h0OiAxMjAlICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5zZW1pYm9sZCB7XHJcbiAgICAmLmRpc3BsYXkteGwge1xyXG4gICAgICAgIGZvbnQtd2VpZ2h0OiA2MDAgIWltcG9ydGFudDtcclxuICAgIH1cclxuICAgICYuZGlzcGxheS1tZCB7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IDYwMCAhaW1wb3J0YW50O1xyXG4gICAgfVxyXG4gICAgJi5oMSB7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IDYwMCAhaW1wb3J0YW50O1xyXG4gICAgfVxyXG4gICAgJi5oMiB7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IDYwMCAhaW1wb3J0YW50O1xyXG4gICAgfVxyXG4gICAgJi5oMyB7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IDYwMCAhaW1wb3J0YW50O1xyXG4gICAgfVxyXG4gICAgJi5oNCB7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IDYwMCAhaW1wb3J0YW50O1xyXG4gICAgfVxyXG4gICAgJi5oNSB7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IDYwMCAhaW1wb3J0YW50O1xyXG4gICAgfVxyXG4gICAgJi5oNiB7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IDYwMCAhaW1wb3J0YW50O1xyXG4gICAgfVxyXG4gICAgJi5ib2R5LWwge1xyXG4gICAgICAgIGZvbnQtd2VpZ2h0OiA2MDAgIWltcG9ydGFudDtcclxuICAgIH1cclxuICAgICYuYm9keS1uIHtcclxuICAgICAgICBmb250LXdlaWdodDogNjAwICFpbXBvcnRhbnQ7XHJcbiAgICB9XHJcbiAgICAmLmJvZHktc20ge1xyXG4gICAgICAgIGZvbnQtd2VpZ2h0OiA2MDAgIWltcG9ydGFudDtcclxuICAgIH1cclxuICAgICYuYm9keS14cyB7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IDYwMCAhaW1wb3J0YW50O1xyXG4gICAgfVxyXG59XHJcblxyXG4uYm9sZCB7XHJcbiAgICAmLmRpc3BsYXkteGwge1xyXG4gICAgICAgIGZvbnQtd2VpZ2h0OiA3MDAgIWltcG9ydGFudDtcclxuICAgIH1cclxuICAgICYuZGlzcGxheS1tZCB7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IDcwMCAhaW1wb3J0YW50O1xyXG4gICAgfVxyXG4gICAgJi5oMSB7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IDcwMCAhaW1wb3J0YW50O1xyXG4gICAgfVxyXG4gICAgJi5oMiB7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IDcwMCAhaW1wb3J0YW50O1xyXG4gICAgfVxyXG4gICAgJi5oMyB7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IDcwMCAhaW1wb3J0YW50O1xyXG4gICAgfVxyXG4gICAgJi5oNCB7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IDcwMCAhaW1wb3J0YW50O1xyXG4gICAgfVxyXG4gICAgJi5oNSB7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IDcwMCAhaW1wb3J0YW50O1xyXG4gICAgfVxyXG4gICAgJi5oNiB7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IDcwMCAhaW1wb3J0YW50O1xyXG4gICAgfVxyXG4gICAgJi5ib2R5LWwge1xyXG4gICAgICAgIGZvbnQtd2VpZ2h0OiA3MDAgIWltcG9ydGFudDtcclxuICAgIH1cclxuICAgICYuYm9keS1uIHtcclxuICAgICAgICBmb250LXdlaWdodDogNzAwICFpbXBvcnRhbnQ7XHJcbiAgICB9XHJcbiAgICAmLmJvZHktc20ge1xyXG4gICAgICAgIGZvbnQtd2VpZ2h0OiA3MDAgIWltcG9ydGFudDtcclxuICAgIH1cclxuICAgICYuYm9keS14cyB7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IDcwMCAhaW1wb3J0YW50O1xyXG4gICAgfVxyXG59Il19 */";

/***/ }),

/***/ 89785:
/*!********************************************************************************************************************!*\
  !*** ./src/app/pages/home/claims-prescription/prescription-content/prescription-content.component.scss?ngResource ***!
  \********************************************************************************************************************/
/***/ ((module) => {

module.exports = ":root {\n  --nc-color-nextgen-neutral-grey-50: #f1efef;\n  --nc-color-nextgen-white: #ffffff;\n  --nc-color-nextgen-blue: #0d152e;\n  --nc-color-nextgen-green: #00908d;\n  --nc-color-nextgen-black: #000000;\n  --nc-color-nextgen-grey-background: #c8d3da;\n  --nc-color-nextgen-grey: #92a2ac;\n  --nc-color-nextgen-stone-grey: #fafafa;\n  --nc-color-nextgen-error: #fc1055;\n  --nc-color-nextgen-neutral-grey: #414141;\n  --nc-color-nextgen-fibrant-green: #00bab6;\n  --nc-color-nextgen-warning: #ffd048;\n  --nc-color-nextgen-green-background: #e6f2f2;\n  --nc-color-nextgen-neutral-grey-400: #7a7a7a;\n  --nc-color-nextgen-neutral-grey-100: #eff3f5;\n  --nc-color-nextgen-status-error: #ba0c3f;\n  --nc-color-nextgen-status-error-background: #ffeff4;\n  --nc-color-nextgen-status-warning: #cba127;\n  --nc-color-nextgen-status-warning-background: #fff8e6;\n  --nc-color-nextgen-blue-100: #dfeff2;\n  --nc-color-nextgen-error-red-700: #f62459;\n  --nc-color-nextgen-blue-500: #006192;\n  --nc-color-nextgen-blue-400: #79cdec;\n  --nc-color-nextgen-red-500: #ff6592;\n  --nc-color-nextgen-secondary-blue-300: #13a0d3;\n  --lumi-white-color: #ffffff;\n  --lumi-primary-yellow-color: #fab600;\n}\n\n.ion-color-green {\n  --ion-color-base: var(--nc-color-nextgen-green);\n  --ion-color-base-rgb: var(--nc-color-nextgen-green);\n  --ion-color-contrast: var(--nc-color-nextgen-white);\n  --ion-color-contrast-rgb: var(--nc-color-nextgen-green);\n  --ion-color-shade: var(--nc-color-nextgen-green);\n  --ion-color-tint: var(--nc-color-nextgen-green);\n}\n\n.expired {\n  background: var(--nc-color-nextgen-status-error-background);\n  border-radius: 0.125em;\n  color: var(--nc-color-nextgen-status-error);\n  padding: 4px 8px;\n}\n\n.active {\n  background: var(--nc-color-nextgen-green-background);\n  border-radius: 0.125em;\n  color: var(--nc-color-nextgen-fibrant-green);\n  padding: 0.25em 0.5em;\n}\n\n.claim-cards {\n  margin-bottom: 0.6em;\n  background-color: white;\n}\n\n.card-row {\n  display: flex;\n  justify-content: space-between;\n  padding: 0.6em 0 0.6em 0;\n}\n\n.card-row .col-left {\n  text-align: left;\n}\n\n.card-row .col-right {\n  text-align: right;\n}\n\n.card-row .text-content {\n  margin: 0;\n}\n\n.sub-title {\n  color: var(--nc-color-nextgen-neutral-grey-400);\n}\n\n.name {\n  color: var(--nc-color-nextgen-neutral-grey-400);\n}\n\n.type {\n  color: var(--nc-color-nextgen-neutral-grey-400);\n}\n\n.icon-next {\n  color: var(--nc-color-nextgen-green);\n}\n\n.noData {\n  padding-top: 20%;\n  text-align: center;\n  color: var(--nc-color-nextgen-neutral-grey-400);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFwuLlxcY29sb3Iuc2NzcyIsInByZXNjcmlwdGlvbi1jb250ZW50LmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0MsMkNBQUE7RUFDQSxpQ0FBQTtFQUNBLGdDQUFBO0VBQ0EsaUNBQUE7RUFDQSxpQ0FBQTtFQUNBLDJDQUFBO0VBQ0EsZ0NBQUE7RUFDQSxzQ0FBQTtFQUNBLGlDQUFBO0VBQ0Esd0NBQUE7RUFDQSx5Q0FBQTtFQUNBLG1DQUFBO0VBQ0EsNENBQUE7RUFDQSw0Q0FBQTtFQUNBLDRDQUFBO0VBQ0Esd0NBQUE7RUFDQSxtREFBQTtFQUNBLDBDQUFBO0VBQ0EscURBQUE7RUFDQSxvQ0FBQTtFQUNBLHlDQUFBO0VBQ0Esb0NBQUE7RUFDQSxvQ0FBQTtFQUNBLG1DQUFBO0VBQ0EsOENBQUE7RUFFQSwyQkFBQTtFQUNBLG9DQUFBO0FDQUQ7O0FEZ0NBO0VBQ0MsK0NBQUE7RUFDQSxtREFBQTtFQUNBLG1EQUFBO0VBQ0EsdURBQUE7RUFDQSxnREFBQTtFQUNBLCtDQUFBO0FDN0JEOztBQW5DQTtFQUNFLDJERDJDc0M7RUMxQ3RDLHNCQUFBO0VBQ0EsMkNEd0MyQjtFQ3ZDM0IsZ0JBQUE7QUFzQ0Y7O0FBcENBO0VBQ0Usb0REZ0MrQjtFQy9CL0Isc0JBQUE7RUFDQSw0Q0Q0QjRCO0VDM0I1QixxQkFBQTtBQXVDRjs7QUFyQ0E7RUFDRSxvQkFBQTtFQUNBLHVCQUFBO0FBd0NGOztBQXJDQTtFQUNFLGFBQUE7RUFDQSw4QkFBQTtFQUNBLHdCQUFBO0FBd0NGOztBQXZDRTtFQUNFLGdCQUFBO0FBeUNKOztBQXZDRTtFQUNFLGlCQUFBO0FBeUNKOztBQXRDRTtFQUNFLFNBQUE7QUF3Q0o7O0FBcENBO0VBQ0UsK0NETytCO0FDZ0NqQzs7QUFwQ0E7RUFDRSwrQ0RHK0I7QUNvQ2pDOztBQXBDQTtFQUNFLCtDREQrQjtBQ3dDakM7O0FBcENBO0VBQ0Usb0NEakJvQjtBQ3dEdEI7O0FBckNBO0VBQ0UsZ0JBQUE7RUFDQSxrQkFBQTtFQUNBLCtDRFYrQjtBQ2tEakMiLCJmaWxlIjoicHJlc2NyaXB0aW9uLWNvbnRlbnQuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyI6cm9vdCB7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS01MDogI2YxZWZlZjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4td2hpdGU6ICNmZmZmZmY7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWJsdWU6ICMwZDE1MmU7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuOiAjMDA5MDhkO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ibGFjazogIzAwMDAwMDtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tZ3JleS1iYWNrZ3JvdW5kOiAjYzhkM2RhO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ncmV5OiAjOTJhMmFjO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zdG9uZS1ncmV5OiAjZmFmYWZhO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1lcnJvcjogI2ZjMTA1NTtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5OiAjNDE0MTQxO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1maWJyYW50LWdyZWVuOiAjMDBiYWI2O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi13YXJuaW5nOiAjZmZkMDQ4O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbi1iYWNrZ3JvdW5kOiAjZTZmMmYyO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNDAwOiAjN2E3YTdhO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktMTAwOiAjZWZmM2Y1O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtZXJyb3I6ICNiYTBjM2Y7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy1lcnJvci1iYWNrZ3JvdW5kOiAjZmZlZmY0O1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtd2FybmluZzogI2NiYTEyNztcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc3RhdHVzLXdhcm5pbmctYmFja2dyb3VuZDogI2ZmZjhlNjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZS0xMDA6ICNkZmVmZjI7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWVycm9yLXJlZC03MDA6ICNmNjI0NTk7XHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLWJsdWUtNTAwOiAjMDA2MTkyO1xyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlLTQwMDogIzc5Y2RlYztcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tcmVkLTUwMDogI2ZmNjU5MjtcclxuXHQtLW5jLWNvbG9yLW5leHRnZW4tc2Vjb25kYXJ5LWJsdWUtMzAwOiAjMTNhMGQzO1xyXG5cclxuXHQtLWx1bWktd2hpdGUtY29sb3I6ICNmZmZmZmY7XHJcblx0LS1sdW1pLXByaW1hcnkteWVsbG93LWNvbG9yOiAjZmFiNjAwO1xyXG59XHJcbiRjb2xvci1uZXh0Z2VuLWJsdWU6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZSk7XHJcbiRjb2xvci1uZXh0Z2VuLWdyZWVuOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuKTtcclxuJGNvbG9yLW5leHRnZW4td2hpdGU6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4td2hpdGUpO1xyXG4kY29sb3ItbmV4dGdlbi1ibGFjazogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ibGFjayk7XHJcbiRjb2xvci1uZXh0Z2VuLWdyZXktYmFja2dyb3VuZDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmV5LWJhY2tncm91bmQpO1xyXG4kY29sb3ItbmV4dGdlbi1ncmV5OiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZXkpO1xyXG4kY29sb3ItbmV4dGdlbi1zdG9uZS1ncmV5OiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXN0b25lLWdyZXkpO1xyXG4kY29sb3ItbmV4dGdlbi1lcnJvcjogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1lcnJvcik7XHJcbiRjb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleTogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXkpO1xyXG4kY29sb3ItbmV4dGdlbi1maWJyYW50LWdyZWVuOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWZpYnJhbnQtZ3JlZW4pO1xyXG4kY29sb3ItbmV4dGdlbi13YXJuaW5nOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXdhcm5pbmcpO1xyXG4kY29sb3ItbmV4dGdlbi1ncmVlbi1iYWNrZ3JvdW5kOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuLWJhY2tncm91bmQpO1xyXG4kY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNTA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTUwKTtcclxuJGNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTQwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNDAwKTtcclxuJGNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTEwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktMTAwKTtcclxuJGNvbG9yLW5leHRnZW4tc3RhdHVzLWVycm9yOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy1lcnJvcik7XHJcbiRjb2xvci1uZXh0Z2VuLXN0YXR1cy1lcnJvci1iYWNrZ3JvdW5kOiB2YXIoXHJcblx0LS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy1lcnJvci1iYWNrZ3JvdW5kXHJcbik7XHJcbiRjb2xvci1uZXh0Z2VuLXN0YXR1cy13YXJuaW5nOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXN0YXR1cy13YXJuaW5nKTtcclxuJGNvbG9yLW5leHRnZW4tc3RhdHVzLXdhcm5pbmctYmFja2dyb3VuZDogdmFyKFxyXG5cdC0tbmMtY29sb3ItbmV4dGdlbi1zdGF0dXMtd2FybmluZy1iYWNrZ3JvdW5kXHJcbik7XHJcbiRjb2xvci1uZXh0Z2VuLWJsdWUtMTAwOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWJsdWUtMTAwKTtcclxuJGNvbG9yLW5leHRnZW4tZXJyb3ItcmVkLTcwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1lcnJvci1yZWQtNzAwKTtcclxuJGNvbG9yLW5leHRnZW4tYmx1ZS01MDA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tYmx1ZS01MDApO1xyXG4kY29sb3ItbmV4dGdlbi1ibHVlLTQwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ibHVlLTQwMCk7XHJcbiRjb2xvci1uZXh0Z2VuLXJlZC01MDA6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tcmVkLTUwMCk7XHJcbiRjb2xvci1uZXh0Z2VuLXNlY29uZGFyeS1ibHVlLTMwMDogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1zZWNvbmRhcnktYmx1ZS0zMDApO1xyXG5cclxuLmlvbi1jb2xvci1ncmVlbiB7XHJcblx0LS1pb24tY29sb3ItYmFzZTogdmFyKC0tbmMtY29sb3ItbmV4dGdlbi1ncmVlbik7XHJcblx0LS1pb24tY29sb3ItYmFzZS1yZ2I6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4pO1xyXG5cdC0taW9uLWNvbG9yLWNvbnRyYXN0OiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLXdoaXRlKTtcclxuXHQtLWlvbi1jb2xvci1jb250cmFzdC1yZ2I6IHZhcigtLW5jLWNvbG9yLW5leHRnZW4tZ3JlZW4pO1xyXG5cdC0taW9uLWNvbG9yLXNoYWRlOiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuKTtcclxuXHQtLWlvbi1jb2xvci10aW50OiB2YXIoLS1uYy1jb2xvci1uZXh0Z2VuLWdyZWVuKTtcclxufVxyXG4iLCJAaW1wb3J0ICcuLi8uLi8uLi8uLi8uLi9jb2xvci5zY3NzJztcclxuXHJcbi5leHBpcmVkIHtcclxuICBiYWNrZ3JvdW5kOiAkY29sb3ItbmV4dGdlbi1zdGF0dXMtZXJyb3ItYmFja2dyb3VuZDtcclxuICBib3JkZXItcmFkaXVzOiAwLjEyNWVtO1xyXG4gIGNvbG9yOiAkY29sb3ItbmV4dGdlbi1zdGF0dXMtZXJyb3I7XHJcbiAgcGFkZGluZzogNHB4IDhweDtcclxufVxyXG4uYWN0aXZlIHtcclxuICBiYWNrZ3JvdW5kOiAkY29sb3ItbmV4dGdlbi1ncmVlbi1iYWNrZ3JvdW5kO1xyXG4gIGJvcmRlci1yYWRpdXM6IDAuMTI1ZW07XHJcbiAgY29sb3I6ICRjb2xvci1uZXh0Z2VuLWZpYnJhbnQtZ3JlZW47XHJcbiAgcGFkZGluZzogMC4yNWVtIDAuNWVtO1xyXG59XHJcbi5jbGFpbS1jYXJkcyB7XHJcbiAgbWFyZ2luLWJvdHRvbTogMC42ZW07XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogd2hpdGU7XHJcbn1cclxuXHJcbi5jYXJkLXJvdyB7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XHJcbiAgcGFkZGluZzogMC42ZW0gMCAwLjZlbSAwO1xyXG4gIC5jb2wtbGVmdCB7XHJcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xyXG4gIH1cclxuICAuY29sLXJpZ2h0IHtcclxuICAgIHRleHQtYWxpZ246IHJpZ2h0O1xyXG4gIH1cclxuXHJcbiAgLnRleHQtY29udGVudCB7XHJcbiAgICBtYXJnaW46IDA7XHJcbiAgfVxyXG59XHJcblxyXG4uc3ViLXRpdGxlIHtcclxuICBjb2xvcjogJGNvbG9yLW5leHRnZW4tbmV1dHJhbC1ncmV5LTQwMDtcclxufVxyXG5cclxuLm5hbWUge1xyXG4gIGNvbG9yOiAkY29sb3ItbmV4dGdlbi1uZXV0cmFsLWdyZXktNDAwO1xyXG59XHJcblxyXG4udHlwZSB7XHJcbiAgY29sb3I6ICRjb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS00MDA7XHJcbn1cclxuXHJcbi5pY29uLW5leHQge1xyXG4gIGNvbG9yOiAkY29sb3ItbmV4dGdlbi1ncmVlbjtcclxufVxyXG4ubm9EYXRhe1xyXG4gIHBhZGRpbmctdG9wOjIwJTtcclxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgY29sb3I6ICRjb2xvci1uZXh0Z2VuLW5ldXRyYWwtZ3JleS00MDA7XHJcbn0iXX0= */";

/***/ }),

/***/ 18181:
/*!*****************************************************************************************!*\
  !*** ./src/app/pages/home/claims-prescription/claims-prescription.page.html?ngResource ***!
  \*****************************************************************************************/
/***/ ((module) => {

module.exports = "<div class=\"prescription-container\">\r\n  <nextcare-layout>\r\n    <ng-template header>\r\n      <ion-row>\r\n        <ion-col size=\"2\" class=\"d-flex\">\r\n          <button class=\"btn btn-circle\" (click)=\"onBack()\">\r\n            <ion-icon  class=\"icon-back body-l\" name=\"arrow-back-outline\"></ion-icon>\r\n          </button>\r\n        </ion-col>\r\n        <ion-col size=\"8\" class=\"row\">\r\n          <span (click)=\"refreshReferralHistory()\" class=\"title-text h6 bold\">{{'prescriptionClaim.title' | translate}}</span>\r\n        </ion-col>\r\n        <ion-col size=\"2\">\r\n        </ion-col>\r\n      </ion-row>\r\n    </ng-template>\r\n\r\n    <ng-template body>\r\n      <ion-content mode=\"ios\" scrollEvents=\"true\" (ionScrollEnd)=\"logScrolling()\">\r\n        <div class=\"prescription-container\">\r\n          <!-- <ion-segment class=\"segment\" (ionChange)=\"segmentChanged($event)\" value=\"referral\">\r\n            <ion-segment-button class=\"segment-button body-n\" value=\"referral\">\r\n              <ion-label>{{ 'prescriptionClaim.referral'| translate }}</ion-label>\r\n            </ion-segment-button>\r\n            <ion-segment-button class=\"segment-button body-n\" value=\"prescription\">\r\n              <ion-label>{{ 'prescriptionClaim.prescription'| translate }}</ion-label>\r\n            </ion-segment-button>\r\n          </ion-segment> -->\r\n\r\n          <!-- search-hisoty component  -->\r\n          <!-- <div class=\"inputSearch\"> -->\r\n            <!-- <app-history-search screen=\"prescription\" [placeholder]=\"'symptomChecker.search'| translate\"\r\n              (onSearchChange)=\"onSearchChange($event)\" [showFilterCount]=\"true\" [listFilter]=\"listFilter\"\r\n              *ngIf=\"listFilter\"></app-history-search>\r\n          </div> -->\r\n\r\n          <div class=\"claim-title\">\r\n            <ion-label class=\"body-l bold\" [ngSwitch]=\"tab\">\r\n              <!-- <span class=\"body-l bold\" *ngSwitchCase=\"'prescription'\">{{ 'prescriptionClaim.prescriptionTitle'|\r\n                translate }}</span> -->\r\n              <span class=\"body-l bold\" *ngSwitchDefault>\r\n                {{ 'prescriptionClaim.referralsTitle'| translate }}</span>\r\n            </ion-label>\r\n          </div>\r\n          <div class=\"inputSearch\">\r\n            <!-- search-hisoty component  -->\r\n            <app-history-search [placeholder]=\"'prescriptionClaim.placeholderSearch'| translate\" *ngIf=\"listFilter\"\r\n              [showFilterCount]=\"false\" [listFilter]=\"listFilter\" [showResetButton] = \"false\" (onSearchChange)=\"onSearchChange($event)\"></app-history-search>\r\n          </div>\r\n          <!-- history-contents component  -->\r\n          <app-prescription-content [details]=\"details\" [type]=\"tab\"></app-prescription-content>\r\n        </div>\r\n      </ion-content>\r\n    </ng-template>\r\n  </nextcare-layout>\r\n</div>";

/***/ }),

/***/ 19638:
/*!********************************************************************************************************************!*\
  !*** ./src/app/pages/home/claims-prescription/prescription-content/prescription-content.component.html?ngResource ***!
  \********************************************************************************************************************/
/***/ ((module) => {

module.exports = "<ion-card class=\"claim-cards\" *ngFor=\"let detail of details;  trackBy:trackById\" trackBy:detailById >\r\n  <ion-card-content  >\r\n      <ion-grid>\r\n          <ion-row class=\"card-row\">\r\n            <div class=\"col-left\">\r\n                <div [ngSwitch]=\"type\">\r\n                    <ion-text class=\"body-sm name\" *ngSwitchDefault> {{'claimDetailReferral.referral' | translate}} </ion-text>\r\n                    <ion-text class=\"body-sm name\" *ngSwitchCase=\"'prescription'\">{{'claimDetailReferral.prescription' | translate}}</ion-text>\r\n                    <h6 class=\"text-content body-n bold color-black\">{{ detail.erxreferenceNbr }}</h6>\r\n                </div>\r\n            </div>\r\n            <div class=\"col-right\">\r\n                <div>\r\n                    <ion-label class=\"body-xs\"  [ngClass]=\"detail.active?'active':'expired'\"> {{detail.active?'Active':'Expired'}}\r\n                    </ion-label>\r\n                </div>\r\n            </div>\r\n        </ion-row>\r\n\r\n          <ion-row class=\"card-row\">\r\n              <div class=\"col-left\">\r\n                  <div>\r\n                    <ion-text class=\"body-sm name\">{{'claimDetailReferral.member' | translate}}</ion-text>\r\n                    <h6 class=\"text-content body-n bold color-black\">{{ detail?.benefFullName ??detail.beneficiaryId.toString()|replaceMySelf |translate}}</h6>\r\n                    \r\n                  </div>\r\n              </div>\r\n              <div class=\"col-right\">\r\n                  <div [ngSwitch]=\"type\"> \r\n                    <ion-text class=\"body-sm type\" *ngSwitchDefault>{{'claimDetailReferral.validUntil' | translate}}</ion-text>\r\n                    <ion-text class=\"body-sm type\" *ngSwitchCase=\"'prescription'\">{{'claimDetailReferral.date' | translate}}</ion-text>\r\n                    <h6 class=\"text-content body-n bold color-black\">{{ detail.expiryDate| date:'dd MMMM yyyy'}}</h6>\r\n                  </div>\r\n              </div>\r\n          </ion-row>\r\n          <ion-row class=\"card-row\">\r\n            <ion-col [ngSwitch]=\"type\">\r\n                <ion-text class=\"body-sm sub-title\" >{{'claimDetailReferral.numberOfUser' | translate}} </ion-text>\r\n                <h6 class=\"text-content body-l bold color-black\">{{ detail.remainingEreferral}}/{{ detail.allowedUtilizationFrequency }}</h6>\r\n               \r\n            </ion-col>\r\n        </ion-row>\r\n          <ion-row class=\"card-row\">\r\n            <ion-col [ngSwitch]=\"type\">\r\n                <ion-text class=\"body-sm sub-title\" *ngSwitchDefault>{{'claimDetailReferral.referred' | translate}} </ion-text>\r\n                <ion-text class=\"body-sm sub-title\" *ngSwitchCase=\"'prescription'\">{{'claimDetailReferral.doctor' | translate}}</ion-text>\r\n                <h6 class=\"text-content body-l bold color-black\">{{ detail?.physician?.physicianName}}</h6>\r\n               \r\n            </ion-col>\r\n        </ion-row>\r\n        <ion-row class=\"card-row\">\r\n          <ion-col [ngSwitch]=\"type\">\r\n              <ion-text class=\"body-sm sub-title\">{{'claimDetailReferral.specialty' | translate}} </ion-text>\r\n              <h6 class=\"text-content body-l bold color-black\">{{ detail.referringSpecialtyRefDesc}}</h6>\r\n             \r\n          </ion-col>\r\n      </ion-row>     \r\n            \r\n      </ion-grid>      \r\n      <ion-row class=\"card-row\" *ngIf=\"detail.active\">\r\n        <ion-col [ngSwitch]=\"type\">\r\n          <button  [hidden]=\"!bookApointmentBtn\" class=\"btn primary secondary\"  *ngSwitchDefault (click)=\"onBookApointment()\" >{{'claimDetailReferral.bookAnAppointment' | translate}} <i class=\"uil uil-arrow-right body-l icon-next\"></i></button>\r\n          <button [hidden]=\"orderOnlineBtn == false\" class=\"btn primary secondary\"  (click)=\"onOrderOnline()\" *ngSwitchCase=\"'prescription'\" >{{'claimDetailReferral.buttonOrderOnline' | translate}} <i class=\"uil uil-arrow-right body-l icon-next\"></i></button>\r\n        </ion-col>\r\n      </ion-row>\r\n  </ion-card-content>\r\n</ion-card>\r\n\r\n<div class=\"noData\" *ngIf=\"!details || details.length === 0\" [ngSwitch]=\"type\">\r\n  <ion-text *ngSwitchDefault class=\"body-l\">{{ 'prescriptionClaim.dataDefaultReferral' | translate}}</ion-text>\r\n  <ion-text *ngSwitchCase=\"'prescription'\" class=\"body-l\">{{ 'prescriptionClaim.dataDefaultPrescription' | translate}}</ion-text>\r\n</div>";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_home_claims-prescription_claims-prescription_module_ts.js.map